# st-engine：独立电路结构变换工具

2026-10-12 Cascode 下一步：用户已选 `Copy_PT_FUNC_703`（125°C、AVDD=1.14、iout=10m）。新增 `server/site/preflight_cascode_bench.py` 从 READ_OK 配置缓存保持变量大小写并使用真实 `config_presim` 在独立目录生成网表；只回传核心路径、源激励与参数摘要，原始文件留服务器。本批不运行 Spectre、不生成 VBIAS，不需要重编 C++ 或重扫 PDK。完整 DC 接入的 FinFET 参数约束、可靠性与激励设置仍需补齐，当前不能说全部开发仅剩验收。


2026-10-12 服务器进展：用户返回 `check_structure_result.py` 的四次真实只读导出、`RESULT=PASS`、`FAILED_CHECKS=0` 和退出 0；该次 Source 电阻/三管共栅 Stack 的结构已验证。电气、GUI 外观及显式 OA 属性独立校验仍未完成。同型/不同 master Cascode 和自动 VBIAS 尚未完成真实服务器验收。

新增 `server/site/read_maestro_setup.py`：从现有会话的实际 cds.lib，只读打开用户指定 Bench 的 Maestro view，读取测试设计、模型/section、变量及 Corner 覆盖/启用标志。完整报告保留服务器，摘要最多 190 行；不保存、不生成网表、不仿真、不把 config 改为 schematic、不创建或修改 simulation profile。已验证本地 Python 调度与结果门禁，真实 Maestro API 尚待服务器执行。当前服务器只需新增这一个 Python 文件，无需重编。

```bash
python3 server/site/read_maestro_setup.py --session "$st_work" --bench-lib HiAplatRV500_ldo_sim --bench-cell ldo1_1_stb_dc_sim_cbb --setup-view maestro_pvt_ea --expected-library-path /tmpdata/maau_epc/users/k00981589/maau_cbb/HiAplatRV500_ldo_sim --output "$st_setup"
```

2026-10-10 当前完整包：**`LDO服务器测试包_物化日志完整保留_2026-10-10.zip`**，包含此前原 MOS 显式属性保留等全部修复。本批仅修复成功 materialize 日志被截为前 240 行的问题，完整保留后面的属性复制证据；C++/电路生成/回读与发布规则不改，已编译服务器无需重编。用户当前只回传 grep 退出 1，不能据此判定生成失败；先按 [日志缺失检查](docs/服务器结构测试_物化日志缺失检查_2026-10-10.md) 读取当前 validation.txt，不重复 generate 或删除会话。属性保留实际 OA/发布验收仍以服务器报告为准。

**此前 CDF 类型修复：** 已确认符号列表与同名 OA 字符串的区别，严格 reader 转换名称表示后继续校验端子数量、名称和唯一性。本批所需扫描政策、日志及验证文件均在当前完整源码包中；真实 OA 运行结果仍须由服务器提供。


当前版本支持自动识别 PDK、无 Bench 的 `structure_only` 电阻/共栅 Stack 结构生成，以及没有性能 Spec 时的名义 DC 求参。结构模式仍验证真实 OA/CDF、源图及父子图回读并整组发布，但 DC/PVT/Sizing 为 false；不能据此声称改后电路工作正常。用户已回传 R3 真实 PDK 发现成功，本批真实 OA 生成/发布以及 Spectre 求参仍待服务器验收。

这是一个独立 C++17 工程。Maau 代码只用于参考已有网表化流程，默认构建不依赖 Maau。工具接收 Virtuoso 工程的 `cds.lib + 核心 library/cell/view`，由服务器适配器自动生成原始网表，不要求用户手工提供网表。

2026-10-08 当前产品入口见 [自动 PDK 识别与服务器验证](docs/standalone-pdk-server-validation.md)，手工命令见 [逐步命令与预期输出](docs/服务器测试_逐步命令与预期输出_2026-10-09_R3.md)：
`server/site/standalone.py` 默认从所选源电路的工艺关联和注册路径发现 PDK，解析实际 OA/CDF 和模型，并恢复独立仿真上下文。`--pdk-root` 是可选覆盖；工具 init.il 默认随包提供。
工作点默认直接调用 Cadence/OCEAN/Spectre。`integration/maau` 与 `server/site/maau_*` 是可选历史接入。
本页后面的原 C++ 命令说明其结构命令和产物；使用真实自动 VBIAS 时通过独立入口保存和恢复本次 PDK/仿真配置。

工具支持：

1. 同型 Cascode；
2. 同极性、不同真实 PDK master 的 Cascode；
3. 保留 MOS，并在其电气 Source 路径串联 PDK 电阻；
4. 2～100 级同型 MOS Stack。

同一会话可连续“确认变换”，最后只生成一个派生电路；`undo` 撤销上次修改，`fresh` 恢复初始逻辑结构。源 schematic、config 和网表不会被覆盖。

## 当前真正实现的流程

```text
核心 library/cell/schematic
  -> 后端调用 Virtuoso/OCEAN 生成 before/core_before.scs
  -> 导出 PDK/CDF/termOrder 和当前层实例坐标
  -> 只列核心 cell 当前层直接 MOS
  -> Confirm / Undo / Fresh 维护一个 Change Set
  -> 在结构化网表上执行四类变换
  -> 每个独立变换区域封装为子 schematic + symbol
  -> 多次修改同一派生区域时合并为一个封装
  -> expected/core_expected.scs
  -> baseline/expected diff 生成 materialization/plan.json
  -> 克隆源 schematic 到 staging
  -> SKILL 创建封装子Cell中的真实PDK器件、端口和symbol
  -> 父 schematic 只删除原管并放置一个wrapper实例
  -> check/save
  -> source 和 staging 分别重新生成网表
  -> 验证源图未变，expected 与 after/core_roundtrip.scs 等价
  -> 发布最终派生 library/cell/schematic
```

工具不会从 testbench 开始递归扫描整个工程。它只显示所选核心 cell 当前层的 MOS；若要修改子模块内部的 MOS，请把该子模块重新作为核心 L/C/V 建立会话。

## 一键编译与测试

本机没有 CMake 也能编译：

```bash
cd "/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau"
./scripts/build.sh
./scripts/test.sh
```

这两个命令默认只编译和测试独立工具，不读取 `integration/maau`。如需额外验证旧 Maau 接入兼容层，可显式执行：

```bash
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

生成的程序在：

```text
build/bin/st_circuit_tool
```

有 CMake 时也可以：

```bash
cmake -S . -B build-cmake
cmake --build build-cmake
ctest --test-dir build-cmake --output-on-failure
```

默认 CMake 构建不包含 Maau 兼容层。只有需要验证旧接入契约时才增加：

```bash
cmake -S . -B build-cmake -DST_BUILD_MAAU_COMPAT=ON
```

## 实际使用

第一步，从 Virtuoso 核心电路建立工作会话：

```bash
./build/bin/st_circuit_tool inspect \
  --backend /path/to/st-engine-maau/server/st_virtuoso_backend.sh \
  --cds-lib /project/cds.lib \
  --lib LDO_LIB \
  --cell capless_ldo \
  --view schematic \
  --core-subckt capless_ldo \
  --bench-lib LDO_BENCH \
  --bench-cell capless_ldo_tb \
  --bench-view schematic \
  --simulator spectre \
  --nominal-corner tt \
  --vbias-vhigh-net AVDD \
  --vbias-vlow-net VSS \
  --work-dir /project/result/ldo_structure_session \
  --variant-lib LDO_DERIVED \
  --variant-cell capless_ldo__TV0001 \
  --variant-id TV0001 \
  --skill /path/to/st-engine-maau/skill/standalone_topology_variant.il
```

`--bench-*` 声明真实测试台，`--vbias-vhigh-net/--vbias-vlow-net` 声明父层轨网。上述底层 C++ CLI 的只读发现可省略这两组成组选项；Bench 缺失时不能 `generate`，Cascode 还需要真实高低轨；两项电流上限可同时省略。它们从本次电路配置与 OA/仿真环境核对。当前自动 PDK 配置入口为 `standalone.py inspect --simulation-profile`（只读发现用 `standalone.py discover-pdk`），会设置并恢复独立 Provider 上下文；见文首链接。
暂无性能 Spec 时省略 `--max-branch-current-error` 和 `--max-vbias-current`，求解名义 DC 可行的器件与参数，不填写虚构指标。将来有实际要求时，两项一起提供为有限正数；候选及最终 DC/PVT 都按这些上限拒绝超限结果。这里的 Case 表示普通电路配置，不要求 Maau Case 文件。可选 `--pvt-corners tt,ss,ff` 声明 PVT 角。会话 Manifest（schema=3）记录扫描目录内容 hash；generate 重扫后同时比对版本和内容。

它会先按当前 DUT 扫描真实 PDK，再由扫描结果生成本会话的 OA 端序/CDF 策略并导出结构网表。Capless 演示用的 `server/config/device_policy.tsv` 不参与产品 CLI 的器件选择。它会打印可修改 MOS，并生成：

```text
before/core_before.scs
before/device_catalog.tsv
before/geometry.tsv
before/mos_inventory.tsv
analysis/device_policy.tsv
analysis/pdk_scan/inspect/raw_catalog.tsv
analysis/pdk_scan/inspect/pdk_identity.tsv
analysis/pdk_catalog.json
analysis/cross_flavor_candidates.json
session.conf
```

第二步，确认一项修改。四类示例位于 `examples/operations/`，其中器件名和
master 必须替换为当前真实电路数据；Cascode 的偏置电压和工作点**不需要**
用户填写，由 generate 时的自动 VBIAS 求解器从基线直流仿真自动取得：

```bash
./build/bin/st_circuit_tool confirm \
  --session /project/result/ldo_structure_session \
  --operation examples/operations/same_type_cascode.conf
```

产品路径的固定规则是：

- 同型/异型 Cascode 保留原 MOS 的 Gate，只把新增 Cascode MOS 的 Gate 接到工具自动生成的 VBIAS；
- VBIAS 不复用原图网络，固定展开 `VBIAS_N_CASCODE_AUTO` 或 `VBIAS_P_CASCODE_AUTO` 自给电 Mirror+Replica 模板（接父层声明的轨网，无 IREF 外部参考端口）；模板内部 MOS 与偏置参数由工具从当前 PDK/Case 目录按极性和电压域自动选择并经 Spectre 候选复验求解，用户不选模板内部管子、不填偏置电压；
- MOS Stack 的所有级 Gate 共用原 MOS Gate，不使用分压 Gate；
- MOS Source 串联电阻保留原 MOS；阻值优先用户填值，其次 Case 预置，最后使用 PDK 有限正合法区间的几何中点，不从 DC 工作点计算；
- Stack 的 Drain 侧保留原实例名，向 Source 侧依次命名为 `_S1`、`_S2`…；
- NMOS Cascode 放在原 Drain 侧，PMOS Cascode 放在原 Source 侧（标准原理图中通常是原管上方）；同型与跨 Flavor Cascode 均保持原 MOS Gate 不变；
- 新增 MOS、电阻和 Bias 模板的 master、terminal order、CDF 参数及范围都必须来自 `device_catalog.tsv`，超出 PDK 边界时拒绝生成。

需要时执行：

```bash
./build/bin/st_circuit_tool list --session /project/result/ldo_structure_session
./build/bin/st_circuit_tool undo --session /project/result/ldo_structure_session
./build/bin/st_circuit_tool fresh --session /project/result/ldo_structure_session
```

第三步，确认最终修改并生成电路：

```bash
./build/bin/st_circuit_tool generate --session /project/result/ldo_structure_session
```

generate 自动完成闭环：PDK 重扫比对 → 基线直流工作点（身份一致才复用
`analysis/baseline_op/`）→ 对每个 FixedBias Cascode 操作运行自动 VBIAS
求解（每候选完整装配"原管改线 + 新增 Cascode + 独立 VBIAS 模板"，经
clone → materialize 物化成唯一临时 OA CellView，再从该候选 CellView
回读网表并 run-op；候选独立目录 `analysis/candidates/candidate_NNN/`
留档审计网表、计划、身份和工作点；轨迹写入
`analysis/solver_trace.jsonl`，逐操作参数写入
`analysis/resolved_parameters.json`）→ 封装与 OA 计划 → SKILL 物化到
staging → 对 staging 变体做名义 DC 检查（`analysis/variant_op/`）→
源图、父图与全部封装子 Cell 回读一致 → 发布。

任何候选无解时：保留非空求解轨迹和逐项拒绝原因，不写 OA 计划、不 clone、
不发布，`reports/validation.txt` 明确 `ready_for_sizing=false`。

全部通过才会输出四状态和放行结论：

```text
structural_ready=true
nominal_dc_ready=true
pvt_ready=false
parameters_quantized=true
ready_for_sizing=true
派生电路=LDO_DERIVED/capless_ldo__TV0001/schematic
```

`pvt_ready` 在配置了 `--pvt-corners` 且全部 Corner 复验通过时才为 true
（任一 Corner 失败都会使 `pvt_ready=false`、`ready_for_sizing=false` 并
阻止发布）；未配置时恒为 false。它不表示 AC、瞬态、PSRR、噪声已签核。

打开派生原理图：

```bash
./build/bin/st_circuit_tool open --session /project/result/ldo_structure_session
```

## 已实现的服务器后端

仓库内的 `server/st_virtuoso_backend.sh` 已实现八个子命令：

- `scan-pdk`：扫描真实 PDK，生成模板器件目录并给出 pdk_version；
- `run-op`：对指定 OA DUT L/C/V（DUT 基线或已物化的候选 CellView）跑直流工作点，身份七字段随请求透传；
- `snapshot`：从源 L/C/V 生成基线网表、PDK/CDF 器件目录和根层坐标；
- `clone`：复制 source cellview 到 staging；
- `materialize`：加载 SKILL 和 JSON 计划，执行 CDF、端口、连线及 check/save；
- `netlist`：从指定 L/C/V 生成指定 `.scs`；
- `publish`：把已验证 staging 发布成最终派生 cellview；
- `open`：在 Virtuoso 打开最终派生 L/C/V。

八个 Runner 按参数数组处理，不使用 `eval`。`server/setup_backend.csh` 负责加载服务器环境，`server/prepare_session.sh` 负责创建不覆盖源项目的独立 `cds.lib`、派生库和 staging 库。真实 LDO 的逐步命令见 `server/README.md`。

`scan-pdk` 输出的 `device_catalog.tsv` 必须提供真实 terminal order/role、OA master、CDF 参数语义、电压域和工艺限制。只有 D/G/S 三个外部端子的 MOS 也进入当前层清单并可选择 Source 串电阻，Bulk 留空；四端及以上器件仍须证明 Bulk 语义。代码不会把实例数组位置直接猜成 D/G/S/B，也不会根据 `M` 开头猜器件类型。

`server/skill/pdk_adapter.il` 为 `standalone_topology_variant.il` 提供以下 PDK/版本适配入口：

```text
StTopologyParseJsonFile
StTopologyApplyCdfParameters
StTopologyCreatePort
StTopologyCreateWrapperSymbol
StTopologyCheckAndSave
```

启动 `materialize` 所用的 Cadence/SKILL 进程前，还必须设置工程根目录：

```bash
export ST_ENGINE_ROOT=/path/to/st-engine-maau
```

八个 Runner 从 `server/setup_backend.csh` 继承该环境变量。若未设置，SKILL 会直接报错退出，不会继续操作 schematic。

这是必须的工程边界：不同 PDK 的 CDF callback、pin master 和检查入口不能由通用代码安全猜出。

## 会话输出

```text
before/core_before.scs              源 schematic 自动生成的基线
analysis/pdk_catalog.json           scan-pdk 扫描出的模板器件目录
analysis/cross_flavor_candidates.json  同极性不同 master 候选（保留内部文件名）
analysis/baseline_op.json           基线直流工作点（含身份哈希）
analysis/baseline_op/               基线 OP 原始产物
analysis/candidates/candidate_NNN/  每个求解候选的独立目录：审计网表
                                    flat_candidate.scs、plan.json、identity.tsv、
                                    mos.tsv；候选 OA CellView 在候选库中唯一命名
analysis/solver_trace.jsonl         逐候选、逐约束的求解轨迹
analysis/resolved_parameters.json   逐操作求解结果与逐 Corner 复验结论
analysis/variant_op/                派生变体名义 DC 检查产物
expected/core_expected.scs          结构变换核心生成的期望网表
materialization/plan.json           SKILL/OA 差异计划
after/source_roundtrip.scs          源图保护回读
after/core_roundtrip.scs            派生 schematic 回读
after/package_XXXX_*.scs            每个封装子Cell的独立回读
reports/validation.txt              最终状态、L/C/V、路径、hash、VBIAS支路电流
logs/                               八个后端阶段日志
```

`expected/core_expected.scs` 包含核心电路中的 wrapper 和每个生成子Cell的层级网表。`after/core_roundtrip.scs` 保存核心父图回读；每个子Cell还会额外生成 `after/package_XXXX_*.scs`，再与期望子电路逐一比较。父图或任一子Cell的端口、master、连线或参数不一致，都不会发布，也不会输出 `ready_for_sizing=true`。

`ready_for_sizing=true` 说明结构回读、名义 DC、已提供的两项电流门禁和参数量化通过；配置 PVT 时还要求相应复验通过。报告同时保存 `validation_scope=dc_operating_point`、`performance_verified=false`、`current_limits_applied=true/false`。它不说明完整 LDO 性能或整机 IQ 已签核，也不会自动启动 Sizing。

## 当前验证边界

本地可以验证 C++ 编译、四类结构算法、当前层 MOS 清单、Change Set、命令行工作流、后端调用顺序、OA 计划和网表回读比较。当前机器没有真实 Virtuoso、目标 PDK 和许可证，因此真实服务器上的以下项目仍为 `planned_not_run`：

- 仓库内八动词后端在 ICADVM18.1 上的首次真实执行；
- 目标 PDK 的 CDF callback、symbol terminal、额外 Well/Bulk 端子；
- 真实 schematic 的局部摆放显示和 check/save；
- 真实源图、派生父图与每个封装子Cell的网表化、打开和截图。

这些项目必须以服务器命令、退出码、日志、派生 L/C/V 和三份网表为证据，不能只凭“脚本已生成”判定完成。

完整设计与实施计划见：

- `docs/superpowers/specs/2026-09-15-standalone-virtuoso-flow-design.md`
- `docs/superpowers/plans/2026-09-15-standalone-virtuoso-flow.md`
- `docs/superpowers/specs/2026-09-16-server-backend-design.md`
- `docs/superpowers/plans/2026-09-16-server-backend.md`
