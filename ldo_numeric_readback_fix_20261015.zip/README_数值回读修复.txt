电阻数值回读修复（2026-10-15）
适用：已安装 ldo_minimum_vbias_20261015.zip 的现有会话。

在 /tmpdata/maau_epc/users/k00981589 目录复制下面一整行执行：
unzip -o ldo_numeric_readback_fix_20261015.zip && bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs

完成后分别执行：
set st_rc = $status
echo "退出码=$st_rc"

修复：376426.75199999998和376.426752K这类等价工程数值不再因为浮点尾差被判成回读不同；真实阻值、几何和接线变化仍检查。日志若仍发现真实差异，将直接打印“要求值=...，实读值=...”或<MISSING>，无需单独读取诊断文件。

预期：仍显示AUTO_VBIAS_SEARCH=true及AUTO_VBIAS_MAX_DC_EVALUATIONS=16。若195段原生实读值只是上述格式差异，第2点应进入DC并打印converged=true/false，而不是在回读时停止；已收敛但未满足工作区则继续自动试下一点，不需要输入阻值。最多16个搜索点，选中后另做一次同参数最终验证。
最终RESULT=EXPERIMENT_DC_PASS，或RESULT=OPTIMIZATION_CANDIDATE_READY（未全部满足、留待优化），两种完整交付退出0。执行/读取失败仍返回INCOMPLETE及退出2，不能把未知结果当成合格。

现场日志没有实读值，不能事先保证没有其它实际CDF差异。已完成本地282项C++检查（含800个段数单位转换和候选更新/最终回读流程）、17项Python测试及工具编译；实际Cadence待服务器。
