同名子电路合并修复（2026-10-15）

适用于已经安装 ldo_focused_trials_20261015.zip 并编译成功的现有会话。
仅替换 st-engine-maau/server/site/op_provider.py；不需要再编译 C++。

改动：候选与测试平台同名的依赖子电路分别保留，候选定义和对应引用一起改名。
不要求两份文本完全相同；不覆盖测试平台定义，不丢弃候选定义。
实例路径、端口顺序、接线、参数和原语模型名保留。

在 /tmpdata/maau_epc/users/k00981589 下执行（csh，每行分别执行）：
unzip -o ldo_shared_subckt_fix_20261015.zip && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs --reference-resistor-scales 8,4,16
set st_rc = $status
echo "退出码=$st_rc"

预期：conflicting shared subckt 不再拦截此类同名依赖；OP日志新增 SHARED_SUBCKTS_ISOLATED=<数量>。
继续使用成功基线和器件资料，不重建会话、不重新扫描。最多三个参数点，首个可行点即停止；软件执行或读取错误立即停止其余试点。
只有真实电气与既有验证通过才会显示 RESULT=EXPERIMENT_DC_PASS、EXPERIMENTAL_DC_READY=true，退出码0。
若真实DC有结果但饱和失败，仍显示对应saturation原因；若执行失败，显示evaluation_failed，不能当成电气无解。
本补丁本地114项Python测试通过；没有在本机运行Cadence/Spectre，不保证此次电路参数可行。

回传：TRIAL_RESULT行、RESULT行及退出码；如仍有evaluation_failed，加上第一条具体错误即可，不必贴整份日志。
