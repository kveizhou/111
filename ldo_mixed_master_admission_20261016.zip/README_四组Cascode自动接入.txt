四组 Cascode 自动接入、生成与撤销

适用：已部署四组测试版本，I21 单管实验已通过，但 four 提示没有已准入的同极性异型型号。
本包更新 Python/Shell，不需要重编译 C++。本地已通过 98 项相关测试；实际新增器件及四组组合电气结果仍由服务器验证。

一、把 ldo_mixed_master_admission_20261016.zip 上传到服务器工作目录，然后执行下面一整行：

unzip -o ldo_mixed_master_admission_20261016.zip && bash st-engine-maau/scripts/test_mixed_cascode.sh four "$st_batch/candidate_I21_xbb892w0"

程序复用已有 PDK 扫描，从原电路已经使用的其他真实 MOS Master 中自动寻找异型候选。一次只读 OCEAN 调用读取实际 CDF、模型极性和保存的工作点，不重新仿真原始基线。异型仍为同极性、不同真实 OA Master，不将 NMOS 和 PMOS 互换。
它会自动准备测试会话，选择四个不同的原管，生成四组并运行候选 DC。无需手选型号、阻值，也不需要手动更换会话路径。

接入成功时可见：
MIXED_FOUR_READY=true
MIXED_ADMISSION=PASS

只有四组最终生成及最低 DC 均通过，末尾才会出现：
TEST_GROUPS=4
GENERATED_SUBCELLS=8
MIXED_CASCODE_TEST=PASS

二、第一步 PASS 后，撤销第 4 组（异型 NMOS），重新生成三组：

bash st-engine-maau/scripts/test_mixed_cascode.sh three "$st_batch/candidate_I21_xbb892w0"

通过时预期：TEST_GROUPS=3、GENERATED_SUBCELLS=6、MIXED_CASCODE_TEST=PASS。

三、第二步 PASS 后，撤销第 3 组（同型 PMOS），重新生成两组：

bash st-engine-maau/scripts/test_mixed_cascode.sh two "$st_batch/candidate_I21_xbb892w0"

通过时预期：
TEST_GROUPS=2
GENERATED_SUBCELLS=4
MIXED_CASCODE_TEST=PASS
FINAL_RETAINED=same_type_NMOS,cross_flavor_PMOS

到此停止撤销。保留第 1 组同型 NMOS（优先 I21）和第 2 组异型 PMOS（优先 I105）。
同型/异型均在原管 D 侧加管，原 G/S/B 接线保持。

四、打开最后生成的 Virtuoso 结果：

bash st-engine-maau/scripts/test_mixed_cascode.sh open "$st_batch/candidate_I21_xbb892w0"

说明：
- 同一时刻只执行一个测试命令。three、two 各执行一次，依次等待前一步 PASS。
- 接入不足或真实电路不满足最低 DC 时会明确报告 INCOMPLETE/未通过；上述 PASS 是条件性预期，不保证所有 PDK 型号与组合一定可用。
- 本轮范围是已有电路中已使用的候选 Master，不是扫描并承诺整个 PDK 所有 MOS 都可用于变换。
- 每个操作沿用最多 16 次自动 DC 搜索。四组成功还需要最终组合电路验证，不能由单管通过替代。
- 若任一步未通过，不执行下一次撤销，也不要重复启动同一个长任务。保留末尾 ISSUE 及结果段即可，不需要先手动排查型号或阻值。
