# 示例数据的性质

`examples/plan.json` 与 `examples/variants/plan_*.json` 是为了展示四种 MOS 结构变换和多层级 clone-on-write 的合成样例；`DESIGN_LIB`、`PDK_LIB`、`MAAU_WORK`、`CELL_L12` 都是**占位符**，不会指向你们实际 OA 库。

`core_actual_good.scs`、`actual_*.scs` **是人工编制的离线样例**，不是从真实 Virtuoso 克隆回读的网表。测试通过只能证明本包离线计划验证与拓扑比较算法在覆盖的语法/用例中工作。不要将其复制成实际 OA 的验证结果。

`device_catalog_demo.json` 与 `device_catalog_normalized_demo.tsv` 是假的器件数据。要在现场真实运行：请用 `tools/catalog_tsv_to_json.py` 将实际 `device_catalog.tsv` 归一化为对应 JSON，并用 PDK 实际 CDF + Spectre 输出核实器件序、参数映射、模型。

`plan_generated.il` 是从演示 JSON 生成的 SKILL **纯数据**，不应指向真实 OA 环境执行。请用 C++ 实际计划重新生成 `work/maau_plan.il`。
