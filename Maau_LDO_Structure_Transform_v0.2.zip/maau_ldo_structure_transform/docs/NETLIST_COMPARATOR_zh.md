# Python 网表比对器：验证“结构、模型、参数、端子网络”

## 1. 为什么不使用 diff？

Virtuoso 克隆后可能更换 subckt 定义名，重新编号匿名 net，按不同顺序输出 instance，或将 `2u` 输出为 `2e-6`。逐行 diff 在这些情况下给出假阳性；更危险的是，仅按设备数量或 master 统计会漏掉 MOS D/G/S/B 接错。

本包的 `tools/netlist_compare.py` 采用：

1. 解析常见 Spectre `subckt NAME (ports...)`、`ends` 与实例语句 `M1 (D G S B) model w=... l=...`，保留 ports 顺序、master、参数；
2. 指定源 DUT top 后，从顶层沿每个 `subckt` 实例路径递归，建立**逻辑平铺**的 leaf path，例如 `ldo/ldo_ls/l12/M1`；clone subckt 的**定义名**不会进入实例路径，所以克隆前后的子电路同名实例路径仍可比；
3. 为每个器件端子分配稳定 endpoint `ldo/ldo_ls/l12/M1#0`、`#1`、`#2`、`#3`（终端位置必须由上游正确映射）；
4. 将每条电气 net 表达成 endpoint 集合（hyperedge）。顶层端口 `@PORT:OUT`、公共 global nets `@GLOBAL:vdd!` 作为锚点，而子模块内部匿名 net 的编号不重要；
5. 对比 leaf instance 增/删、master、参数、端子数量；比较所有 net 的 endpoint 成员关系；比较子电路调用参数与根参数默认值；
6. 可选输出与 `core_before.scs` 的 transform delta；PASS/FAIL 同时输出 JSON 和文本报告。

## 2. 跨子电路网络别名展开举例

若 `LDO_TOP.ldo` 的本地 OUT 连接根 OUT，而 `CELL_LDO.ldo_ls` 的 OUT 又连接 parent OUT，那么 `ldo/ldo_ls/l12/M1_CAS#0` 会归入与 `@PORT:OUT` 同一 net 集合。若 M1_CAS Source 误接 GND，本算法会发现该端子与 `@PORT:GND` 同组，而期望它只与 `M1#0` 同组。

这里的比较不是按 net 字符串逐项对照，而是按**同一网络上的端子成员**判断拓扑是否一致；对于 anonymous net 重编号更稳定。

## 3. 命令和报告

```bash
python3 tools/netlist_compare.py \
  --before examples/netlists/core_before.scs \
  --expected examples/netlists/core_expected.scs \
  --actual examples/netlists/core_actual_good.scs \
  --top-before LDO_TOP --top-expected LDO_TOP \
  --top-actual LDO_TOP__MAAU_DEMO \
  --leaf-catalog examples/device_catalog_demo.json \
  --json-out work/verification.json --text-out work/verification.txt
```

验证模式：

- 默认 `connectivity-equivalent`：只允许内部网络重编号、子电路命名变化、实例/参数输出次序变化、等值物理数字后缀变化，不允许端子成员关系变化。
- `--strict-net-names`：所有网络标识符都必须精确匹配，匿名内部 net 重编号也会 FAIL。

报告 `differences` 中包括：`missing_devices`、`extra_devices`、`modified_devices`、`modified_hierarchy_calls`、`changed_nets`、`root_pin_order`、`renamed_nets`。其中 `changed_nets` 是核心闭环证据，列出每个受影响端子在 expected 和 actual 中所属的 endpoint 集合。

## 4. 离线测试示例

`examples/netlists/core_expected.scs` 的变换是：

```
M1       (N_CAS CTRL GND GND) nch_180 l=180n w=2u
M1_CAS   (OUT BIAS N_CAS GND) nch_180 l=180n w=2u
```

`core_actual_good.scs` 将 N_CAS 改成自动生成的 `net13`，但端子成员相同，结果 **PASS**。  
`core_actual_bad.scs` 将 `M1_CAS.S` 连到 `GND`，结果 **FAIL**，具体错误定位到 `ldo/ldo_ls/l12/M1_CAS#2`。  
`ldo_spare` 仍引用原始 `CELL_LDO`，检测能确认这条兄弟支路没有受影响。

## 5. 比对边界：必须先做哪些规范化？

此解析器支持项目中常见的 Spectre core 语句，但**不是完整 Spectre parser**；对于以下情况请用你们 C++ 已有 AST/netlist 解析器输出中性 JSON 做同等算法比对，或者扩充 parser：

- PDK 模型 include 中定义真实 `subckt`、加密语句或宏，或 netlisting 时 `inline subckt` 语法变形；
- `bsource` 等具有复杂行为表达式的内部节点，或 Verilog-A / AMS 混合语义；
- 参数表达式依赖父级变量、全局 expression、corner/model section 中的数学求值。比较器保留子调用参数并做**文本/数值规范化**，但不执行 Spectre 求值；相同符号表达式并不意味着 PDK 模型完全等效；
- 某些 master 的 `termOrder` 不同，或 CDF callback 映射 master/model 名称发生变化。这应先按 device_catalog 验证；
- 用户希望对**不可达、从未实例化的孤立 subckt 定义**进行 diff：本工具有意只比较给定 top 可达的电路，以避免 PDK 其他未用定义导致假阳性。

解析器对不支持的内部语句默认 FAIL，而不会默默跳过漏掉的器件。对被识别的顶层分析/模型/include 语句做可审计 `skipped_top_statements` 报告；不要把带完整 testbench 的 input.scs 和仅含 DUT 的 core_expected 直接比较而不先确定设计边界。

## 6. 推荐生产化扩展

将 C++ netlist parser 的 AST 直接输出为一份稳定的中间 JSON：每个 subckt `name/pins/instances`，每个 instance `name/master/terminal_order/nets/params`，加上 `global_nets`、`hierarchical_instance_binding`、`model_aliases`、`numeric_param_resolution`。然后 Python 只实现 logical flatten + graph compare。这会比在 Python 中重复实现完整 Spectre/PDK 文法稳健得多。

## 发布安全约束（v0.2）

结构比较存在一个容易忽略的假阳性：如果 `expected.scs` 和 `actual.scs` **同时遗漏某个子模块的 `subckt` 定义**，普通层级展开器可能将其视为一个同名的“基本器件”，从而错误地给出 PASS。因此，生产运行**必须**指定 `--leaf-catalog real_pdk_catalog.json`，解析到没有 `subckt` 定义的 master 时，只有当它出现在已审核 PDK 叶子 master 白名单中才允许继续，否则退出码 2。离线不提供该参数只能用于探索，不构成最终验收。

在物化之前额外运行 `tools/plan_expected_precheck.py`。它使用独立 catalog 的 symbol terminal order，把每只 create MOS 的 `D/G/S/B` 映射到期望 Spectre 的位置，并核对名为 `M1_CAS` 的设备实际期望 master/flavor 与各个 net。输入方案通过前置校验，不代表 OA 中已完成任何操作。

最终 `scripts/finalize_verify.sh` 还应接收一份**真实 source OA 物化后重新导出的网表**，与 C++ 变换前基线结构比较，防止源电路意外变化。
