# IC 6.1.8 + 真实 PDK 的现场验收清单

此文档是 **现场验收协议**，不是“已在 Cadence 上跑通”的证明。随包的 Python 测试只证明 plan 契约和示例 Spectre 网表比较器的行为；没有目标 OA / PDK / Cadence 授权时，不能离线证明 SKILL 物化成功。

## 0. 环境与基线

在验收前固定版本、环境和证据目录：

| 证据 | 必须记录的信息 |
|---|---|
| 工具 | `virtuoso -W` 版本、IC6.1.8 ISR、Spectre 版本、license 特性、`cds.lib` 哈希 |
| PDK | tech library、模型 corner、CDF 及关键回调函数、四种器件的 symbol/termOrder |
| 源 | 原始 top(lib/cell/view)、源库只读状态、原始 top 从 **OA** 生成的 netlist 及 SHA256 |
| 期望 | `core_before.scs`、`core_expected.scs`、`device_catalog.tsv`、C++ 变换日志、job_id |
| 物化输入 | `materialize_plan_v2.json`、层级 `geometry_all.tsv`、`maau_plan.il`、SHA256 |
| 验证输出 | `virtuoso_materialize.log`、各 cell `MAAU_CHECK_PASS`、clone OA netlist、JSON+TXT diff |

除非特别注明，应选一个每级都存在有效 `schematic+symbol` 的四级层级测试 LDO，且不引入新外部端口，避免把“新增接口”混入第一阶段验收。

## 1. 快速打通的标准用例

对原始路径 `ldo/ldo_ls/l12/M1`：

1. 导出真实 cell 内 M1 的 **local** 原点、symbol pin `D/G/S/B` 坐标、各端子当前 net，确认 `geometry_all.tsv` 的 owner path 恰为 `/ldo/ldo_ls/l12`。
2. 用 C++ generic builder 生成全路径 `clone_on_write`：`/`、`/ldo`、`/ldo/ldo_ls`、`/ldo/ldo_ls/l12`；每个 target cell 唯一且先前不存在。
3. 指定原始 `M1` 的 D/G/S/B 旧线锚点和新 `M1`、`M1_CAS` 的端子连通表；在目标 cell 本地空白区域选位置。
4. 在 Virtuoso 加载项目 PDK adapter 和计划；运行 batch runner。所有 clone 的 `MAAU_CHECK_PASS` 必须出现，而且错误数=0、警告数=0（有合法旧警告须编制逐条 waiver，并重写站点 adapter）。
5. 用 GUI 分别打开 source `LDO_TOP` 和 clone `LDO_TOP__JOB`，沿实例路径 descend 到 `l12`。原始 M1 不变，clone 内看到 M1 + M1_CAS 及对应导线、网标。
6. 从 **clone OA top** 重新运行官方 Spectre netlister；不允许拷贝/复用 `core_expected.scs` 冒充 OA 输出。
7. 使用 `netlist_compare.py --expected ... --actual ...` 比较。只有退出码=0、报告 PASS 才允许出最终结果。
8. 再一次从 **source OA top** 生成 netlist，和最初的源 OA 基线比较应 PASS；同时 source oa 文件的版本/哈希应保持一致（如果有外部进程运行导致变动，应从独立对照库验证）。
9. 将 clone top 的 PDK model include、corner、配置视图绑定和设计规范复核，确认不是“拓扑对了但实际 master/参数回调错了”。

## 2. 逐项验收矩阵

| 编号 | 用例 | 必须验证 | 预期结果 |
|---|---|---|---|
| T01 | 四层级同型 Cascode | 新 MOS 与旧 MOS 串联；中间网、D/G/S/B，bulk 正确 | materialize + compare PASS |
| T02 | 四层级异型 Cascode | 新 MOS 低 Vt symbol/CDF/model 和 terminalOrder | PASS，无 master 错误 |
| T03 | Source 串电阻 | 电阻串入 Source，不擅自改 bulk | PASS |
| T04 | Stack N=3 | 节点链 `D->S`，内部两条独立 net | PASS |
| T05 | 同一 subckt 被不同实例路径共享 | 仅改 `/ldo/...`，`/ldo_spare/...` 不变 | PASS，源 OA 不变 |
| T06 | 每层独立克隆 | 4 个不同 target cell，source master 映射正确 | PASS |
| T07 | 在新 MOS 中间线故意改错接 GND | `M1_CAS.S` 不在 `N_CAS` | compare 必须 FAIL |
| T08 | 故意错 master/flavor | netlist 为错误器件型号 | compare 必须 FAIL |
| T09 | PDK CDF callback 未配置 | 创建实例带 `params` | engine 必须报错，不能标 PASS |
| T10 | 父子 master 不符合计划 | path 指向错误 source cell | preflight 必须失败且无目标源损坏 |
| T11 | 克隆 target 已存在 | 防止覆盖同名 cell | preflight 必须失败 |
| T12 | 子 cell 新增外部 port | 无 symbol interface 更新 | plan bridge 必须拒绝 |
| T13 | 节点网名改变但连通不变 | `N_CAS` → `N_INTERNAL_...` | 默认 PASS / strict 模式 FAIL |
| T14 | 原图 wire 穿过器件 pin 的复杂重连 | 单靠 stub 导致短路 | 必须 FAIL 或由 PDK/site router 修复后 PASS |
| T15 | 旋转 R90 或 MX 的 MOS | pin XY 必须用 symbol~>bBox + inst transform | 正确连通 PASS |
| T16 | 原 cell 自带 warning | `schCheck` 得到警告数 | 默认 FAIL；除非逐条批准并留日志 |
| T17 | batch 异常中断 | SKILL error、Virtuoso 内部问题 | 非零退出或 `FAILED`，不可出现 `VERIFIED_PASS` |
| T18 | 子 cell 路径超出 geometry maxDepth | 不能静默忽略深层 MOS | 导出必须 FAIL |

## 3. 无界面执行与报告闸门

在含 `cds.lib` 的项目目录：

```bash
# 先在 skill/maau_runner.il 配置站点 PDK adapter
bash scripts/prepare_and_materialize_ic618.sh materialize_plan_v2.json \
  core_before.scs core_expected.scs /path/real_pdk_catalog.json
cat work/materialize.status   # MATERIALIZED_UNVERIFIED；不是 PASS
```

`skill/maau_runner_batch.il` 会将 SKILL 异常转换为退出状态。`MaauTopologyCheckAndSave` 的默认实现要求 `schCheck(cv)` 的 `(errors warnings)` 均为 0，并检查 `dbSave`。现场可升级成 check 结果 JSON/TSV 或项目的 checker/log parser。即使 check=0 仍必须**独立 OA 网表导出 + compare**。

```bash
# actual.scs 必须由 MAAU_WORK clone top 重新 netlist 得到。
EXPECTED_TOP=LDO_TOP ACTUAL_TOP=LDO_TOP__MAAU_JOB123 \
  bash scripts/finalize_verify.sh /path/clone_from_OA.scs core_expected.scs \
    core_before.scs /path/source_after_from_OA.scs /path/real_pdk_catalog.json

# 源 OA 不变性复核不是可选项：上面的发布闸门已强制执行。单独诊断亦可执行：
python3 tools/netlist_compare.py \
  --expected /baseline/source_oa_before.scs \
  --actual /fresh/source_oa_after.scs \
  --top-expected LDO_TOP --top-actual LDO_TOP \
  --leaf-catalog /path/real_pdk_catalog.json \
  --json-out work/source_integrity.json --text-out work/source_integrity.txt
```

**最终 PASS 需要四份独立证据**：多层级 remaster + check 无错误/警告，clone OA 产生的实际 netlist 结构 PASS，源 OA 无变化，PDK 模型/端子/CDF 适配确认。自动比较不能代替 PDK 适配确认，也不能取代电路功能仿真（例如 LDO 稳定性/相位裕度、瞬态负载响应）。

## 4. 失败时如何恢复

- 未产生 clone：停在输入校验，修改 C++ plan/geometry/catalog。
- clone 生成一部分后失败：状态 `FAILED`；保留该 job 的 staging cell 和日志作证据，换 job id 重新运行。
- `schCheck` 失败：检查原 cell 警告基线与新增浮空/重叠/断线；不要忽略警告直接保存。
- netlist FAIL：打开 JSON `changed_nets`/`modified_devices`，按精确实例路径查看 clone schematic pin 和线；不要从文本行序猜测错误。
- 网表 parser ERROR：属于语法覆盖缺口、netlister 环境或子电路缺失，**不是验证 PASS**。应使用已有 C++ Spectre AST 预先规范化后再次比较，或扩展 parser。

**验收责任边界：** 此打包提供离线可执行 Python + 现场 SKILL 参考实现与验收流程；真实 IC6.1.8/PDK 的回调、symbol、连接、SI 配置和特殊 view binding 仍须现场联调验证。
