# Virtuoso IC 6.1.8：API、层级打开、布线、Spectre 网表生成

## A. API 清单（SKILL）

| 目标 | 推荐命令/属性 | 备注 |
|---|---|---|
| 只读打开源 schematic | `dbOpenCellViewByType(lib cell "schematic" "schematic" "r")` | **第四个参数是 viewType，第五个参数是 access mode** |
| 可写打开已复制目标 | `dbOpenCellViewByType(lib cell "schematic" "schematic" "a")` | `"a"` 编辑已存在内容；`"w"` 用在现有 cellview 上可能覆盖内容，禁止用于源 |
| 克隆特定 OA view | `dbCopyCellView(srcCv dstLib dstCell "schematic")` | 默认不覆盖已有目标；对子 cell 还要复制 `symbol` |
| 克隆 base CDF | `cdfCopyCDF(ddGetObj(dstLib dstCell) "baseCellData" cdfGetBaseCellCDF(ddGetObj(srcLib srcCell)))`，随后 `cdfSaveCDF` | 必须避免已有目标 CDF 覆盖/冲突 |
| 遍历 direct instance | `cv~>instances`, `inst~>name`, `inst~>libName`, `inst~>cellName` | 路径每一段是实例名，不应直接作为 cell 名 |
| 获取实例引用 symbol | `inst~>master` | 应为 symbol master；用 `inst~>cellName` 打开同名 schematic |
| 替换单实例 master | `inst~>master = newSymbolCv` | 比 `dbSetInstHeaderMasterName` 更适合“同一 master 仅改一个实例” |
| 创建 instance | `schCreateInst(cv master name xy "R0" 1)` 或 `dbCreateInst(cv master name xy "R0" 1)` | 这里用 `schCreateInst` 以匹配 schematic 语义；纯 db API 使用时需注意 instTerm 构造 |
| 删除 instance | `dbDeleteObject(inst)` | 删除时原有 wires 可能成为悬挂线；要保留/重连 |
| 重写实例属性 | `dbReplaceProp(inst "w" "string" "2u")` | PDK `CDF` 参数名、类型、回调规则各不相同；不能止于改 prop |
| 取 symbol pin 坐标 | `dbFindTermByName(inst~>master "D")` + pin fig bbox + `dbTransformPoint(... inst~>transform)` | 考虑实例的旋转、镜像和 Symbol 真实 terminal pin 位置 |
| 画导线 | `schCreateWire(cv "route" "full" list(p1 p2) grid grid 0.0)` | 按 PDK/grid/cellview 调整 spacing；必要时画多段 |
| 加网络名 | `schCreateWireLabel(cv car(wires) point netName "lowerLeft" "R0" "stick" 0.0625 nil)` | 标签真正落在所对应的 wire 上；只能用已返回的有效 wire ID |
| 添加 visible port | `schCreatePin(cv pinMaster name direction nil xy "R0")` | `pinMaster` 可以打开 `basic/ipin|opin|iopin/symbol` |
| schematic 检查 | `schCheck(cv)` | 返回 `(errors warnings)` 或 nil；默认 adapter 拒绝非零错误及警告，不是 `dbCheck` |
| 保存/关闭 | `dbSave(cv)`, `dbClose(cv)` | 逐目标 cell 检查并保存；注意保存和日志错误 |
| 打开 GUI 设计 | `geOpen(?lib "LIB" ?cell "CELL" ?view "schematic" ?mode "r")` | `dbOpenCellViewByType` 只是获取 DB 对象，不创建 GUI 窗口 |

相关依据：见 [SOURCES.md](SOURCES.md)，包括 Cadence 官方社区中 Andrew Beckett 对 `dbCopyCellView`、`schCheck`、`inst~>master`、`schCreateWire` 和 OCEAN 网表化的示例。

## B. 具体的 copy/remaster/Check & Save

```lisp
; 源只读
srcSch=dbOpenCellViewByType("DESIGN_LIB" "CELL_L12" "schematic" "schematic" "r")
; 目标唯一 cell，已事先在 cds.lib 中定义好 MAAU_WORK
newSch=dbCopyCellView(srcSch "MAAU_WORK" "CELL_L12__MAAU_JOB123" "schematic")
dbSave(newSch)
dbClose(newSch)
dbClose(srcSch)

srcSym=dbOpenCellViewByType("DESIGN_LIB" "CELL_L12" "symbol" "schematicSymbol" "r")
newSym=dbCopyCellView(srcSym "MAAU_WORK" "CELL_L12__MAAU_JOB123" "symbol")
dbSave(newSym)
dbClose(newSym)
dbClose(srcSym)

; 完成对应 base CDF 复制，并验证外部 symbol ports 完全兼容。

parentSch=dbOpenCellViewByType("MAAU_WORK" "CELL_LDO_LS__MAAU_JOB123"
                               "schematic" "schematic" "a")
newSym=dbOpenCellViewByType("MAAU_WORK" "CELL_L12__MAAU_JOB123"
                             "symbol" "schematicSymbol" "r")
; l12Instance 必须在 parentSch~>instances 中按实例名精确查找
l12Instance~>master=newSym
schCheck(parentSch)
dbSave(parentSch)
dbClose(parentSch)
dbClose(newSym)
```

> 上述代码片段展示 API 调用关系；`l12Instance` 的确定、source master 断言、clone 目标存在性、symbol interface 校验和异常处理请使用 `maau_engine.il`，不要原样执行未定义 `l12Instance` 的片段。

## C. 打开源电路/克隆电路与逐级浏览

先加载已注册的 library。`cds.lib` 本身不是 `geOpen` 的参数；Virtuoso 必须先在运行目录解析 `cds.lib`（包含 source 与 `MAAU_WORK` 两套库），然后：

```lisp
geOpen(?lib "DESIGN_LIB" ?cell "LDO_TOP" ?view "schematic" ?mode "r")
geOpen(?lib "MAAU_WORK" ?cell "LDO_TOP__MAAU_JOB123" ?view "schematic" ?mode "r")
```

如果要从 top 进入任意子模块，有两种不同用途：

1. **GUI 交互式进入：** 先打开克隆 top，再选对应 instance，使用 Virtuoso 的 Descend 命令；这样导航栈知道父级上下文。
2. **路径定位/独立显示：** 通过 `cv~>instances` 按名字逐层查找，使用对应 `inst~>libName/inst~>cellName` 打开子 schematic，再对最终子 cell 调用 `geOpen`。`skill/maau_open.il` 提供此实现。独立打开子 cell 不会自动形成“返回父级”的导航栈。

`deOpenCellView` 也可在适当编辑器场景使用；这里明确区分 `dbOpenCellViewByType`（DB）、`geOpen`（GUI），避免程序认为 dbOpen 就能在屏幕显示。

## D. 真实端子坐标与局部避碰

已有实例：

```lisp
inst~>xy
inst~>orient
inst~>bBox
```

获取终端（真实符号 pin）：

```lisp
symTerm=dbFindTermByName(inst~>master "D")
pin=car(symTerm~>pins)
fig=pin~>fig
; 一些 symbol 上 pin 图形可能通过 ~>figs 暴露，请按实际对象检查。
pLocal=centerBox(fig~>bBox)
pInSchematic=dbTransformPoint(pLocal inst~>transform)
```

`inst~>xy` 是实例 origin，**通常不等于 bounding box 中心，更不等于 MOS D/S 引脚坐标**。旋转/镜像时必须使用 `inst~>transform`。`skill/maau_geometry.il` 已包含主干导出流程；输出每一层级路径的**局部** xy、orient、bBox、pin 坐标、OA net 名。

为新器件选位置：读取目标 cell 的所有 instance bBox，将候选新 symbol 的本地 bbox 用 `xy` 与 orient 变换，在 grid（如 0.0625，具体以项目原理图设置为准）上移动，直到与既有实例 bBox 至少保留 halo。`tools/place_candidates.py` 给出只支持 `R0` 的离线示例，**仅避开已有实例，不检查 wire、net label、sheet 边界、crossing 或器件 pin 接触**；投产需在 Virtuoso 中再验证。

复杂情况务必采用 target cell 的真实 wire/label 几何快照。如果原有 MOS 引脚是已有导线端点，删除实例后原线仍可能存在；需在 pin 原坐标维护该 network，而不是基于 `inst~>xy` 随便画一条线。

## E. 导出 Spectre 网表：层级网表优于依赖“直接扁平化”

**推荐 OCEAN：**

```lisp
simulator('spectre)
design("MAAU_WORK" "LDO_TOP__MAAU_JOB123" "schematic")
actualNetlist=createNetlist(?recreateAll t ?display nil)
printf("Netlist: %L\n" actualNetlist)
```

在 GUI ADE 里也可通过 `Simulation -> Netlist -> Create` 产生 Spectre 层级网表。

**无头 `si` 批处理（需配置正确 `si.env`）：**

在实际 netlisting run 目录准备类似文件：

```text
simLibName = "MAAU_WORK"
simCellName = "LDO_TOP__MAAU_JOB123"
simViewName = "schematic"
simSimulator = "spectre"
simNotIncremental = 't
simReNetlistAll = 't
simViewList = '("spectre" "config" "schematic" "veriloga")
simStopList = '("spectre")
simNetlistHier = 't
nlFormatterClass = 'spectreFormatter
nlCreateAmap = 't
nlDesignVarNameList = nil
```

然后使用：

```bash
si -batch -command nl
```

以上 `si.env` 只是 Cadence 社区中的已知用法模板，不是所有 PDK/config 的通用文件。Site 需验证 model path、`simViewList`/`simStopList`、`config`、netlisting session 变量和生成的实际文件路径。若你们有已验证的 ADE/ocean/si 会话，优先复制那份的 view-list、simulator 和 corners 配置，而不是原样照搬模板。

**为什么不直接追求“flat Spectre”：** Cadence 社区明确指出常规 Spectre（以及 hspiceD） netlister 没有普适的 flat 输出模式；CDL 可采用 `cdlNetlistType='fnl` 生成扁平 CDL，但其语法、器件参数以及命名不等同于 Spectre。故此项目使用**原生层级 Spectre + Python 逻辑平铺**完成比较，不依赖不稳定/不等价的导出格式。这里的 Python 平铺是结构连通展开，而不是产生一个能交给 Spectre 仿真的单层 SPICE deck。

## F. 终端顺序和网络语义

`device_catalog.tsv` 必须定义/验证以下信息（这里只列建议字段）：

- 真实 device `symbol master lib/cell/view`；
- 符号 pin name（`D/G/S/B`、`d/g/s/b`、三端器件等），及 Spectre 输出顺序；
- CDF 参数名和类型（不同 flavor 可能 `w/l/nf` 不同）；
- 需按次序执行的 callback，以及回调后实际 netlist 中的 master/model/param 映射；
- 数字后缀和表达式处理规则；
- `gnd!`、`vdd!`、`0` 等 global nets 与 `termOrder`。

默认 SKILL 引擎通过**端子名**连接真实 symbol pin；Python 比较器使用**Spectre 实例的端子位置**识别电气连通。若 PDK 两种 flavor netlist pin order 不同，必须在上游 `core_expected` 或独立 catalog-normalizer 中统一端子映射再比对。

## G. CDF 回调：必须有站点级适配

只做 `inst~>w="2u"` 或 `dbReplaceProp` 不会自动触发所有 GUI CDF callbacks。Cadence 社区有 `CCSinvokeInstCdfCallbacks`/`abInvokeInstCdfCallbacks` 的参考，但具体 callback 顺序、PCell master 行为、派生宽度参数等依赖 PDK。

因此：

1. 先用实际 `cdfGetInstCDF(inst)` 验证有效参数、默认值、类型及 termOrder；
2. 设置参数后触发该 PDK 的适当 CDF callbacks；
3. 校验生成的 Spectre instance master、D/G/S/B、w/l/nf/m/fingers 与 `core_expected`；
4. 默认 adapter 对存在参数但未配置回调的情况直接报错；不可用“照样保存”代替正确性。

## H. 重要不支持范围

- 未打开 PDK/真实 OA 的现场运行：包内并无已验证的 IC6.1.8 SKILL runtime 记录；
- 在克隆 leaf 增加外部 port 而未重新生成对应 symbol、父实例/上级 ports；
- 任意复杂 wire 删除/切割/避让、标签自动消歧、跨 sheet 或 inherited/global-net 修复；
- 由 Spectre 参数表达式/模型回调决定的器件等价性（结构比较不能替代 Spectre/PDK 模型解析与 LVS/ERC）；
- 任意 Spectre 语法（`bsource`/`inline subckt`/`model` sections、加密 PDK include、以及复杂宏语法）均解析完全；这些需要扩展解析器或由 C++ 的既有 netlist AST 统一规范化后输入比较器。

遇到上述情况必须显式 fail 或切到对应 PDK/site adapter，不能误报 PASS。

## I. 避免结构比对假 PASS 的 PDK 叶子白名单

`examples/device_catalog_demo.json` 定义目标工艺每个器件 symbol 的 `lib/cell/view`、`spectre_master`、按 Spectre netlist 顺序排列的 `terminal_order` 和能够**安全直接比对**的 CDF→Spectre 参数映射。它只是演示，不能用 `nch_180` 等占位器件描述真实 PDK。生产时应以 `device_catalog.tsv`、实例的有效 CDF、真实 PDK netlister 产生的网表验证后转换。

`tools/plan_expected_precheck.py` 在写入 OA 前对每个新增器件进行端子网名、spectre master、部分可直比参数核对，并对 `preserve_anchors` 和原始网表进行检查。`tools/netlist_compare.py --leaf-catalog ...` 在展开过程中禁止把任意未定义 subckt 误认成 PDK primitive。对于 `resistor`、`capacitor` 等内置原语也需要显式白名单，不能让比较器默认猜测。
