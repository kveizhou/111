# PDK/device_catalog 接入说明

此项目**不能凭 MOS symbol 名称猜测 Spectre 的端子顺序或 netlist master**，否则一个 D/S 接反的物化计划可能在物化前校验中被误判为正确。你们已有的 `device_catalog.tsv` 可以被 C++ 归一化成这里的 TSV 表，再转换为 JSON。

## 1. 归一化输入格式

`examples/device_catalog_normalized_demo.tsv` 的表头：

| 字段 | 作用 |
|---|---|
| `lib`, `cell`, `view` | OA 里实例所引用的 PDK symbol master，如 `PDK_LIB / nch_180 / symbol` |
| `spectre_master` | 使用该 CDF 和 netlister 时，Spectre 实例行真正输出的器件名称，例如 `nch_180`，或者原语 `resistor` |
| `terminal_order` | **按 Spectre 输出顺序**排列的 symbol terminal names，以逗号分隔，例如 `D,G,S,B` 或 `PLUS,MINUS` |
| `cdf_to_spectre_params` | 安全可直接检查的 CDF → Spectre 参数名 JSON，例如 `{"w":"w","l":"l"}`。复杂回调不能一对一对应的参数可暂不映射，但真实 OA 网表最终仍必须结构化对比。 |

归一化示例**不是**真实 PDK 数据。对于 TSMC 180nm / SMIC 55nm，要通过已确认的 MOS/电阻 symbol `termOrder`、有效 CDF (`cdfGetInstCDF`)、实际 Spectre Netlist 命令生成真实对照，不可直接复用 demo 中的端子或模型名。

## 2. TSV → JSON 转换

```bash
python3 tools/catalog_tsv_to_json.py \
  --tsv examples/device_catalog_normalized_demo.tsv \
  --out work/device_catalog_from_tsv_demo.json
```

`--additional-leaf` 可以显式允许 PDK 里不在此 TSV 里的 primitive，例如经过核实的电容模型；但不得把缺失的**设计子模块**加入 primitive 白名单来绕过网表展开失败。

## 3. 为什么必须在写 OA 前使用此 catalog？

`plan_expected_precheck.py` 逐实例把 `terminal_nets` 中 `D/G/S/B` 按 catalog 转成 Spectre node list，与 `core_expected.scs` 中该实例的 node list 比较。它还会检查 flavor/master 和可直比参数、旧端子 wire anchor net。真正从 OA 回读后，`netlist_compare.py --leaf-catalog` 阻止未知的层级 master 被错误地当作叶子原语。

这些步骤**不能**替代 IC6.1.8 PDK CDF callbacks、模型 include、config view binding 和功能仿真。
