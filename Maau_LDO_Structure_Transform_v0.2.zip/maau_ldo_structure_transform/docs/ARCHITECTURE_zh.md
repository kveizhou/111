# 技术方案：把“任意嵌套路径的 MOS”真正物化到 Virtuoso OA

## 1. 用什么模型替换现有 root-only wrapper？

**结论：根层 wrapper 与子层原位改造是两种不同变换模型，不能混用。** 原模型 `BuildPackagedOaMaterializationPlan` 假设修改对象是根 cell 的直接实例，因此当目标路径为 `ldo/ldo_ls/l12/M1` 时查不到 `M1`。这不是简单的“递归遍历少了一层”，而是“目标改写位置以及父级引用模型错误”。

应采用已存在的 `BuildOaMaterializationPlan` 作为计算入口，继续使用 `ValidateOaPlan` 的 clone-on-write 多层级路径契约。再由 v2 adapter 将计划传到 SKILL：

```
LDO_TOP/schematic                         LDO_TOP__JOB/schematic (cloned)
  |-- ldo  -> CELL_LDO/symbol                |-- ldo  -> CELL_LDO__JOB/symbol
  `-- ldo_spare -> CELL_LDO/symbol           `-- ldo_spare -> CELL_LDO/symbol (不变)
                |                                         |
       CELL_LDO/schematic                       CELL_LDO__JOB/schematic
           | ldo_ls                                 | ldo_ls -> NEW symbol
       CELL_LDO_LS/schematic                    CELL_LDO_LS__JOB/schematic
           | l12                                    | l12 -> NEW symbol
       CELL_L12/schematic                       CELL_L12__JOB/schematic
           | M1                                     | M1 + M1_CAS
```

对于“只修改实例路径中的某一个 branch”，必须按**实例路径**（例如 `/ldo/ldo_ls/l12`）而不是按 subckt 定义名唯一化克隆。否则同一个 `CELL_L12` 被多处实例化时，会误改兄弟分支。

## 2. 多层级目标的准确定位

`ldo/ldo_ls/l12/M1` 中前三段是 instance name，最后一段是本层 MOS 实例名。具体 traversal（只读）：

1. `cv0 = dbOpenCellViewByType(topLib, topCell, "schematic", "schematic", "r")`
2. 在 `cv0~>instances` 中按 `inst~>name == "ldo"` 找顶层实例，而不是把 `"ldo"` 当作 cell 名。
3. 子实例的 `inst~>master` 是 **symbol**；通过 `inst~>libName/inst~>cellName` 去 `dbOpenCellViewByType(..., "schematic", "schematic", "r")` 查对应设计 schematic。注意不同 config/view binding 可改变真实仿真选用 view，必须在生产中将该绑定单独记录。
4. 对 `ldo_ls`、`l12` 重复上述步骤，最终从 `CELL_L12/schematic` 中找到 `M1`。
5. 每级记录 `source(lib,cell,schematic,symbol)`、`instance name`、`parent path`、`ports`、`CDF`、`placement local xy` 与 `top-to-local net aliases`。

失败规则：任何一级实例未找到、master 不匹配、缺少 schematic 或 symbol、出现递归电路但未显式支持，都应在拷贝前 FAIL。不能回退成 root-only 遍历。

## 3. 必须克隆哪些对象？

每个路径级变更都要复制：

- `schematic`（受修改电路图和父级重绑定发生于此）；
- `symbol`（供上一级 parent instance 的 `~>master` 引用）；
- `base cell CDF`（部分继承的 netlist 参数、回调、端口顺序或命名策略在这里定义）；
- 工艺环境所需的 tech binding / netlisting viewList（复制 library 不等于自动具备兼容配置）。

**无需克隆 PDK MOS cell 本身。** 新 MOS/resistor 仍引用 PDK 原有的 symbol master；克隆的是设计层级的模块 cell。仅当有特殊自定义 hierarchical CDF/model 时才考虑额外的 wrapper netlisting model 映射。

推荐的 target cell 命名：`<origCell>__MAAU_<jobid>_<pathHash>`。不同路径即使引用同一个 source cell 也要生成不同的 target，以隔离实例差异。不同 job 不能复用 target 名称，且 `dbCopyCellView` 不得使用 overwrite 参数覆盖源或老 job。

## 4. 为什么必须自底向上？

SKILL 实现采用两阶段，见 `skill/maau_engine.il`：

**阶段 1：只读克隆。** 对所有 `clone_on_write` 映射执行 `dbOpenCellViewByType(...,"r")` → `dbCopyCellView()` → `dbSave` → `dbClose`。同时拷贝目标 cell 的 symbol 与 CDF。所有目标 view 只存在于 job staging library。

**阶段 2：深度优先回填。** 在最深层目标 `CELL_L12__JOB/schematic` 删除重建 M1、创建 M1_CAS、绘制网络；`schCheck` + `dbSave`。然后打开 `CELL_LDO_LS__JOB/schematic`，把其中名叫 `l12` 的 instance master 从 `DESIGN_LIB/CELL_L12/symbol` 改为 `MAAU_WORK/CELL_L12__JOB/symbol`；再 check/save。继续上层直到根层。父实例变更必须与计划中的 `parent_instance` 完全一致，绝不能使用“一次修改所有 instHeader 指向同一 master”的方法。

**Symbol interface invariant**：默认情形下，拷贝前后的 symbol 端子集合、方向、symbol 局部 pin 坐标必须相同。本包 `MaauValidatePinCompatibility` 对端子数量、名称、pin 坐标执行基础检查。若要加父级外部 port，必须另行实现生成新 symbol 并更新全链路连线（默认引擎拒绝）。

## 5. C++ 后端推荐改动（伪代码）

```cpp
TransformResult tr = RunLdoStructureTransform(design, targetPath, op);
// tr.before: core_before.scs, tr.expected: core_expected.scs

// 不能在有非根修改时调用 root-only BuildPackagedOaMaterializationPlan。
OaPlan raw = BuildOaMaterializationPlan(tr.before, tr.expected,
                                        deviceCatalog, fullHierarchyGeometry);

std::set<InstancePath> modifiedPaths = FindModifiedInstancePaths(raw);
std::set<InstancePath> clonedPaths = {InstancePath("/")};
for (const auto& path : modifiedPaths) {
    for (const auto& ancestor : AllInstancePathPrefixes(path))
        clonedPaths.insert(ancestor);
}

for (const auto& path : clonedPaths) {
    auto src = ResolveSourceCellByInstancePath(sourceTop, path);
    auto dst = MakeUniqueTargetCellName(jobId, path, src);
    plan.clone_on_write.push_back({path, src, dst,
      ParentPath(path), LastInstanceName(path)});
}

// 各 item.path 必须是承载删除/新增实例的 CELL 路径，
// 即 "/ldo/ldo_ls/l12"，不是完整的 MOS "/.../M1"。
plan.operations = NormalizeOperationsByOwnerCell(raw);
ValidateOaPlan(plan);
WriteNormalizedV2Json(plan, "materialize_plan_v2.json");
```

`FindModifiedInstancePaths` 不能只依据 subckt 定义名，要保留 C++ 变换引擎产生的“逻辑实例路径 → 对应定义实例”映射；否则一个 subckt 多处复用时，预期网表也会重复变化，进而破坏独立性。

### 保留现有 wrapper 功能的建议

可以保留 root-only package 模式用于直接实例包装，但把入口改成明确分流：

- `target.ownerCellPath == "/" && mode == "new_wrapper"` → legacy packaged 计划；
- 任意层级 + `mode == "in_place_clone"` → generic multi-level OA 计划；
- 非根层级 + `mode == "new_wrapper"`，若没有专用的 child-local wrapper 合成器则明确 `UNSUPPORTED`，不得误调用 root-only。

对于你们当前问题，直接设置 `mode="in_place_clone"` 是工作量最小的修复。

## 6. 四种拓扑变换如何在同一个计划里表达？

关键原则：所有电路拓扑变换已经由 C++ 给出**明确端子网络表**，SKILL 只是把器件和导线做出来，不再推断 MOS 的电气含义。

| 变换 | C++ 期望 netlist 的核心变化 | SKILL OA 动作 |
|---|---|---|
| 同型 Cascode | `M1.D = N_INT`，新增 `M1_CAS.D=OLD_D, S=N_INT`，G/B 按计划指定 | delete/recreate M1 + create 同 master flavor 新管 + 悬挂旧线锚点与中间线 |
| 异型 Cascode | 同上，但新管 `master` 换成低 Vt/另一 flavor，CDF 也可能不同 | `create_instances.master` 指向另一个 PDK symbol；验证真正在 Spectre 中 netlist 成所需 model |
| MOS Source 串电阻 | `M1.S = N_RS`，新增 `R1(N_RS, OLD_S)`；MOS B 是否随 Source 变化必须明确 | 保留/重建 MOS + 增电阻器件 + 端子接线（不能偷换 bulk） |
| Stack N 管 | `M0.D=OLD_D, M0.S=N1, M1.D=N1 ... M(N-1).S=OLD_S`，各 G/B 必须各自定义 | delete 旧 MOS，按数量创建新 MOS，生成内部 net 并连线 |

**不要泛化“同型 Cascode 就一定 Gate 相同”或者“Stack 一定所有 Bulk 都接 Source”。** 必须由设计规则和 `core_expected.scs` 指定每只 MOS 的 D/G/S/B。示例 Cascode 使用 `BIAS` 作为既有端口，不添加新外部端口。

## 7. 删除 MOS 后的悬挂导线问题

仅对 `inst~>instTerms` 写 `net` 属性，并不能保证 check-and-save 之后的可视 schematic 物理连线准确。模型必须处理：

1. **保留旧引脚的导线接点。** 删除 M1 前读取 `M1` 的 `instTerm~>net~>name` 和经变换后的 symbol pin 全局位置。v2 JSON 中的 `preserve_anchors` 就是每个旧 D/G/S/B 端子的“预期旧网络 + 局部坐标方向”契约。
2. 删除实例后保留旧 wire shapes，在原端子点画小段 wire 并标注其旧 net 名，保证原导线段的网络名不会丢。
3. 创建新 MOS，在真实 pin 坐标处出 short stub + label；需要跨器件直接连接的网络由 `create_direct_wires` 连接。整条路径由 `schCreateWire` 和 `schCreateWireLabel` 表达。
4. `schCheck(cv)` 重新提取和检查电气连接，再 `dbSave(cv)`。默认 checker 对 schCheck 的 error 和 warning 都直接失败；如出现错连、悬空端子、未连接 pin、重复 label，则不得发布。
5. 从重新网表化的 **clone top** 获取真实 Spectre device connectivity。Python 比较器检查每个端子的全局连通集合，确保与 C++ expected 相同。

**重要限制：** 当前默认 adapter 是结构化样例，不是完整的自动布线/拆线器。对于旧 wire 直接穿过多个 MOS pin、标签跨网、多段交叉、必须删除某段导线、需按源图连线重新布线的情况，必须扩展 `MaauTopologyConnectTerminal` 等 site hook，并为旧 wire 增加分段指令。此类情况不应通过“重复画小短线”凑成功。

## 8. Check & Save 与验收

每个 cloned schematic：

```lisp
cv=dbOpenCellViewByType(dstLib dstCell "schematic" "schematic" "a")
; 对 cv 完成指定 delete/create/rebind/wiring 操作
schCheck(cv)
dbSave(cv)
dbClose(cv)
```

`dbCheck` 不是现代 IC61X 的 schematic check 替代品。IC6.1 参考中 `schCheck` 返回 `(errors warnings)` 或 nil。本包默认执行严格拒绝任何 error/warning；具体 ISR、PDK 中仍需要核对 CIW/log，并为已有合法警告编制明确 waiver。**`schCheck` 完成不代表网表正确；重新从 OA netlist 并比较，才是闭环。**

## 9. 出错恢复与源电路保障

- Source library 全程只读打开；只在唯一的 `MAAU_WORK` target 上执行 `dbCreateInst`/`schCreateInst`、`dbDeleteObject`、`inst~>master=...`、`dbSave`。
- 克隆前验证目标 cell 不存在；禁止 `"w"` 覆盖旧 source 或旧 target。
- OA 跨多个 cellview 的修改不支持“整体事务回滚”。中途失败的 cell 可能留在 staging，按 job 标记失败；再运行换新的 job ID，或手动删除特定失败 job 的 staging cells（**不能按原 cell 名粗暴删除**）。
- 建议 C++ 保存 `SHA256(plan JSON + core_before + core_expected + device_catalog + geometry.tsv)` 以便审计、重现。
- 验证过的结果可绑定给 GUI 浏览；未验证克隆只允许调试展示，不能代替原电路。
