# 物化计划 v2 契约（C++ → SKILL）

## 1. 基本类型与实例路径

`schema_version=2`，唯一 `job_id`，`clone_on_write[]` 映射，以及 `operations[]`。本包暂不直接在 SKILL 中解 JSON，而是先运行 `tools/plan_bridge.py`：检查外部输入约束后，把纯 JSON 值安全序列化成 SKILL `list(list(key value)...)`，运行时由 `MaauGet(alist, key)` 读取。

**路径统一规范：** root 是 `"/"`；任一子 cell 实例路径是 `"/ldo/ldo_ls/l12"`；待处理 MOS 是完整路径 `"/ldo/ldo_ls/l12/M1"`；operation 的 `path` 是**持有器件 M1 的 cellview owner 路径**，所以 operation.path 为 `"/ldo/ldo_ls/l12"`，器件名另写在 `delete_instances`、`create_instances.name`。

## 2. JSON 架构示意

```json
{
  "schema_version": 2,
  "job_id": "JOB123",
  "top_path": "/",
  "clone_on_write": [
    {
      "path": "/",
      "source": { "lib": "DESIGN_LIB", "cell": "LDO_TOP", "view": "schematic", "symbol_view": "symbol" },
      "target": { "lib": "MAAU_WORK", "cell": "LDO_TOP__MAAU_JOB123", "view": "schematic", "symbol_view": "symbol" }
    },
    {
      "path": "/ldo",
      "parent_path": "/",
      "parent_instance": "ldo",
      "source": { "lib": "DESIGN_LIB", "cell": "CELL_LDO", "view": "schematic", "symbol_view": "symbol" },
      "target": { "lib": "MAAU_WORK", "cell": "CELL_LDO__MAAU_JOB123", "view": "schematic", "symbol_view": "symbol" }
    }
  ],
  "operations": [
    {
      "path": "/ldo/ldo_ls/l12",
      "delete_instances": ["M1"],
      "preserve_anchors": [
        {"instance":"M1", "terminal":"D", "expected_net":"OUT", "offset":[-1.0,0.0]}
      ],
      "create_instances": [
        {
          "name":"M1_CAS",
          "master":{"lib":"PDK_LIB", "cell":"nch_180", "view":"symbol"},
          "xy":[10.0, 14.0],
          "orient":"R0",
          "params":{"w":{"type":"string", "value":"2u"}, "l":{"type":"string", "value":"180n"}},
          "terminal_nets":{"D":"OUT", "G":"BIAS", "S":"N_CAS", "B":"GND"},
          "terminal_offset":[1.0,0.0]
        }
      ],
      "create_direct_wires": [
        {"a":{"instance":"M1", "terminal":"D"}, "b":{"instance":"M1_CAS", "terminal":"S"}, "net":"N_CAS"}
      ],
      "create_wires": [],
      "create_ports": []
    }
  ]
}
```

> 此处是字段说明的**裁剪示例**，故省略了其余两级 `clone_on_write` 映射和重建后的 M1。**不要直接执行**。完整且能通过 bridge 校验的四级 JSON 见 `examples/plan.json`。

## 3. Clone 层级映射字段

`clone_on_write` 每一项：

- `path`：当前 cloned **instance-path prefix**；每个不同路径只出现一次。
- `source.lib/cell/view`：待复制的设计 cell；source view 必须为 `schematic`，只读。
- `target.lib/cell/view`：新的 OA staging cell；与 source **不能**是同一 `(lib,cell)`，任意 clone path 的 target `(lib,cell)` 不能重复。
- `source/target.symbol_view`：当前引擎支持 `symbol`；子模块必须存在对应 source symbol，复制后供父级 remaster。
- 非 root 路径需要 `parent_path`（直接父 owner path）以及 `parent_instance`（其在 parent schematic 中的 instance name）。它必须等于 `path` 的最后一段，例如 `/ldo/ldo_ls/l12` 的 `parent_path=/ldo/ldo_ls`, `parent_instance=l12`。
- 整条祖先链**必须完整**，根 `/` 映射不能省略。

路径级 target 和 parent rebind 由 C++ 执行前确定，并用 `ValidateOaPlan` 验证；SKILL 也会在 remaster 前二次确认实例旧 master 与契约 source 匹配。

## 4. 具体编辑操作字段

| 字段 | 作用/约束 |
|---|---|
| `path` | 哪个克隆 schematic 应用本操作。不是完整 `/.../M1` |
| `delete_instances` | 该层被删除的原有 direct instance 名称；不存在必须 FAIL |
| `preserve_anchors` | 删除前从原 MOS symbol terminal 读取旧 net/引脚坐标；删除后在同点补 wire + net label，保留旧导线网络（对于已有线段有效；未连接的原始 pin 必须特别处理） |
| `create_instances` | `name`、PDK/设计 `master`、本地 `xy`、`orient`、`params`、`terminal_nets`、`terminal_offset` |
| `create_direct_wires` | 通过 `(instance,terminal)` 两端真实 symbol pin 位置连接，并用 `net` 标注 |
| `create_wires` | 拟制的显式多点 polyline，`points` 坐标必须是当前 cellview **局部**坐标，`net` 是网络名 |
| `create_ports` | `name`、`direction`、`xy`。本版仅在 root 允许调用；子模块新增外部 port 需扩展 symbol 接口，不会悄悄放行 |

本版 `params` 使用 `{ "w":{"type":"string","value":"2u"} }`，防止跨 PDK 时 CDF 参数数据类型丢失。参数值不是统一数值；有些 CDF 参数是字符串、数字、boolean，必须以 `device_catalog.tsv` 为准。

**四种结构变换不写在 SKILL 条件分支中。** C++ 输出“真正要有哪些实例，它们接哪条网”，由同一个 generic SKILL engine 执行。这样 topology 算法与 OA API 分层，测试清晰。

## 5. 物化计划校验强制的安全条件

`tools/plan_bridge.py` 默认拒绝：

1. 非版本 2 JSON，缺少 root clone，缺少任何祖先 clone；
2. 同一个 `path` 多次定义，或者两个 instance path 共用同一 target cell；
3. source 与 target `(lib,cell)` 相同（源损坏风险）；
4. parent_path/parent_instance 与 path 实际父子关系不一致；
5. operation 路径不存在于 clone map；
6. 重复实例创建、重复实例删除、未知参数类型、坐标/导线字段不合法；
7. 旧引脚保护锚点指向根本未删除的实例；
8. 子模块新增对外端口但没有 symbol 接口更新 adapter。

**也必须由 SKILL 现场校验：** 所有 target cell 在 OA 中事先不存在；source 打得开；父级确有该实例且 master 与 source 匹配；device catalog 中的 symbol 真正存在；可计算 symbol pin xy；CDF callbacks 按该 PDK 正确执行。

## 6. 字段尚未实现/必须二期扩展的情况

- **需要切除旧导线的一部分**：仅仅保存旧引脚 anchors 不够，要新增 `delete_wire_segments`，以 local wire shape ID 的稳定几何指纹（points、net、layer、bBox）定位要删除的 segment，拷贝后重新建线路。默认引擎不包含此项，因此该模式应从 C++ planner 拒绝，不得靠默默擦掉旁边的线路。
- **子模块新增外部端口**：追加 `create_symbol_ports`，更新 cloned symbol 的终端和图形位置；如果需把新信号传到更高层，则每个 parent cloned schematic 也要新增导线/端口甚至修改上级 symbol。
- **多 view binding**：特殊 mixed schematic/config/Verilog-A/PCell 的真实 master 绑定应通过 config/si 对照，不应假设所有 cell 都用默认 schematic。
- **多层反复引用同一 cell 的实例属性覆盖**：上游 `core_expected` 须遵循“实例路径级不同 clone 名”原则，否则实物 clone top 和 expected 的可达电路可能不是同一结构。

## 7. 关键阶段与状态

```
plan validation -> clone creation -> leaf materialization -> parent remaster
       -> schCheck and dbSave all cloned schematic
       -> MATERIALIZED_UNVERIFIED
       -> OA Spectre netlisting -> structured netlist compare
       -> PASS or FAIL -> only PASS can publish
```

`materialize.status` 不是验证结果。只有 Python 比较器退出码为 0 且 schematic/netlisting 无未处理错误时才能生成 `VERIFIED_PASS` 文件/推送 UI 成功态。

## 6. v0.2 加强的失败条件

- 未知的顶层 JSON 字段、错误 root `top_path`、没有任何 operation、坐标 NaN/Inf、错误 dtype 会在运行 SKILL 前失败。
- `create_direct_wires` 两端**必须**出现在本次 `create_instances` 中，且各端子的 `terminal_nets` 与 direct wire 的 `net` 一致；旧实例需要另行规范化后重建或交给经审查的 site adapter。
- 子电路新增端口仍属于未实现的 symbol interface change，本引擎会拒绝。
- 完整计划还需使用 `plan_expected_precheck.py` + **真实** PDK catalog 验证 master、Spectre 端子顺序和 old wire anchors，然后才能送到 Virtuoso 执行。
