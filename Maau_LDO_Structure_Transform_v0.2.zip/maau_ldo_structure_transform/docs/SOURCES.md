# Cadence / Virtuoso SKILL 参考依据

以下链接用于核实 **API 名称、入参、行为边界**。Cadence 不同 IC6.1.8 ISR、技术库、PDK 脚本或许可证组合可能差异；部署时请以本地 `cdnshelp` / `getd` / function reference 和实际 smoke test 最终确认。

| 参考资料 | 与本方案有关的依据 |
|---|---|
| [Cadence: dbCopyCellView 可复制 OA database cellview](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/19106/skill-code-for-copying-a-view) | `dbCopyCellView(srcCv lib cell view)`；不要误以为自动复制 CDF |
| [Cadence: 创建/打开 schematic](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/36448/skill-command-to-create-the-cell-view) | `dbOpenCellViewByType(lib cell view "schematic" "a")` 第四参 viewType、第五码 access mode |
| [Cadence: schCreateInst 参数](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/13164/skill-code-to-add-instance) | `schCreateInst(cv master name origin orient magnification)` |
| [Cadence: 单个 instance 更改 master](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/56736/how-to-fetch-all-the-instances-in-from-a-top-cell-hierarchy) | 对单实例的 `inst~>master` 绑定；不得批量改所有共享 instHeader |
| [Cadence: cdfCopyCDF 与 cdfSaveCDF](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/57746/creating-a-new-pcell-wrapper-from-a-base-pcell) | CDF 与 cellview 独立，`cdfCopyCDF(ddGetObj(dst) "baseCellData" cdfGetBaseCellCDF(...))` |
| [Cadence: schematic wire + label 实例](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/62957/how-to-assign-net-names-correctly-in-skill-code-for-schematic-generation) | `schCreateWire` 返回 wire dbIds；`schCreateWireLabel` 要以有效 wire id/point 连接；原答也指出错误参数传法 |
| [Cadence: 端子 pin 坐标和 inst transform](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/28124/pin-terminal-locations-on-symbol) | 用 master symbol terminal pin figure、`dbTransformPoint(... inst~>transform)` 取得 schematic 坐标 |
| [Cadence: schCheck 能返回错误和警告数](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/37706/schcheckhier-return-warnings) | 每个修改的 schematic 单独 `schCheck`；source 为只读，不要 check/save source |
| [Cadence: schCheck 返回值语义，详细参考](https://picture.iczhiku.com/resource/eetop/ShKGaYfpItGrUmvc.pdf) | IC6.1 reference：返回 `(errors warnings)` 或 nil；不同版本务必现场确认 |
| [Cadence: `for` 只支持 +1，建议 `while`](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/14282/for-loop) | 深度倒序处理用 `while(depth>=0 ...)` 而非 `for(... -1 ...)` |
| [Cadence: Virtuoso non-GUI batch 的 exit(0/1)](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/59814/how-to-get-exit-code-0-when-there-is-a-skill-error-in-a-skill-script) | `errset` 包围执行并明确 `exit(1)`，不能单靠 shell $? |
| [Cadence: 启动 batch 后需要显式 exit](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/13889/using-tcl-script-to-execute-virtuoso) | `virtuoso -nograph -restore ...` 的 `-restore` 脚本末尾应结束进程 |
| [Cadence: CDF callback 调用背景](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/26566/triggering-callbacks-on-specific-devices) | `dbReplaceProp` 不等于真正按工艺 CDF 回调改变实例 |
| [Cadence: Spectre 网表不提供普遍 flat 选项](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/34898/generate-flattened-spectre-netlist) | 使用层级 Spectre 网表、在比较器中逻辑展开，不等同于 `CDL flat` |
| [Cadence: `schCheck` 输出报告](https://www.thecadforums.com/threads/confused-about-schcheck.36171/) | 可重定向 `poport` 捕获检查信息，按现场 QA 需要扩展 |

## 关于资料可信度

这里既有 Cadence 官方社区的实际用例，也有在外部镜像托管的旧版 SKILL API 手册。旧文档帮助确定调用形态，但**不能证明 IC6.1.8 某个 PDK 的有效调用**。真实签名、输入参数和回调效果必须在目标环境复核。网络链接可能随论坛迁移而变化。
