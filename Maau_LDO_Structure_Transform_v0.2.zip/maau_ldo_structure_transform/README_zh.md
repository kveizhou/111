# Maau LDO 结构变换：多层级 OA 物化与验证方案

**工程包版本：** 2026-10-21 / 参考实现 v0.2  
**目标环境：** Cadence Virtuoso IC 6.1.8、OpenAccess、SKILL、Spectre、C++（Maau）  
**状态：** Python 核心校验及网表比较已在当前离线环境通过 37 项自动测试。SKILL 采用经 Cadence 资料核实的 API 编写，但**未在真实 IC 6.1.8 + 目标 PDK 环境执行，不能宣称已物化到 OA**。生产接入需根据真实 `device_catalog.tsv`、`geometry.tsv`、PDK CDF 和 OA 原理图完成适配及验收。

## 0. 问题定位与正确修复方式

当前 C++ 主程序在非根层级错误调用 `BuildPackagedOaMaterializationPlan`，它只知道顶层 wrapper 模型，于是 `ldo/ldo_ls/l12/M1` 找不到直接实例。

**修复：** 非根目标改走已存在的 `BuildOaMaterializationPlan`。在其输出中组装实例路径级别的 clone-on-write 映射，克隆每个受影响的 schematic（子 cell 还需匹配 symbol 与 CDF），在 `/ldo/ldo_ls/l12` 的克隆 schematic 中改写 M1，随后自底向上把父 schematic 里的 `ldo`、`ldo_ls`、`l12` 实例 master 指向各自克隆的 **symbol**。根 clone 命名独立，可从 Virtuoso 打开查看。

**不能忽略：** 父层级 schematic 实例 `~>master` 通常指向子模块 `symbol`，不是它的 `schematic`；克隆单个 schematic 不足以形成可打开、可网表化的隔离链。`dbCopyCellView` 也不自动保证 cell 级 CDF 被完整复制。

## 1. 工程包目录

| 文件 | 用途 |
|---|---|
| `skill/maau_engine.il` | 克隆源 schematic/symbol、复制 base CDF、操作删除/新增/布线/端口、父实例 remaster、逐 cell `schCheck` + `dbSave` |
| `skill/maau_adapter_default.il` | PDK 无关 schematic 连接与放置默认实现；**未配置 CDF callback 时拒绝带 CDF 参数的操作** |
| `skill/maau_pdk_adapter_template.il` | PDK/site 专用参数、回调、端子映射、连线策略接入点 |
| `skill/maau_geometry.il` | 从顶层递归读取所有允许的设计库子模块实例 xy、bBox、symbol pin 的最终坐标、原 net，导出 TSV |
| `skill/maau_open.il` | 打开克隆前/后 top，按层级路径定位并显示子 schematic |
| `skill/maau_runner.il` / `maau_runner_batch.il` | GUI/无界面物化入口：出错写 `FAILED`；成功仅写 `MATERIALIZED_UNVERIFIED`，batch 版明确 `exit(0/1)` |
| `skill/maau_ocean_netlist.ocn` | OCEAN 创建层级 Spectre 网表的备用方案 |
| `tools/plan_bridge.py` | 校验多层级 JSON 物化计划，安全转换为 Virtuoso `load()` 可用的 SKILL 数据 |
| `tools/netlist_compare.py` | 解析常见 Spectre `subckt`/MOS/电阻/实例，递归按路径展开，比较主器件、参数、端子连通超边 |
| `tools/place_candidates.py` | 根据指定子 cell 的局部 bBox 快速计算 R0 实例候选坐标（仅避开已有实例包围盒） |
| `examples/plan.json` | 四层级路径、保留旧引脚导线锚点、两个 MOS 构成 Cascode 的结构化计划 |
| `examples/netlists/*.scs` | 原始、期望、等价克隆（PASS）、故意接错 Cascode S 端（FAIL） |
| `tests/test_workflow.py` | 离线回归测试（37 项） |
| `docs/*` | C++ 集成、API、数据契约、验收、限制及技术来源 |

## 2. 现在就能运行的离线演示

**不需要 Virtuoso，不修改任何 OA 数据库：**

```bash
cd maau_ldo_structure_transform
bash scripts/run_offline_demo.sh
```

预期结果：

- `plan_bridge.py` 接受包含 `/`、`/ldo`、`/ldo/ldo_ls`、`/ldo/ldo_ls/l12` 的完整 clone 契约；若某层祖先缺失或目标等于源则报错。
- `core_expected.scs` 与 `core_actual_good.scs` 比较：**PASS**。即使子电路克隆名称和内部临时 net 名称变化，拓扑一致就通过。
- `core_expected.scs` 与 `core_actual_bad.scs` 比较：**FAIL**。因为 `M1_CAS` Source 误连 `GND`，而期望是 `N_CAS`。
- 37 项 Python 单元测试通过；日志/JSON 位于 `work/`。

## 3. 在 IC 6.1.8 中落地的步骤

### A. 准备 OA 隔离库（一次性）

1. 在含 `cds.lib` 的项目目录中，以 `DEFINE MAAU_WORK /abs/path/maau_staging_lib` 的方式注册新的可写 OA 库（建议通过 Virtuoso Library Manager 创建，并 attach 与原设计兼容的 tech library）。
2. 原 `DESIGN_LIB` 和 PDK 库只读，**切勿**让 `MAAU_WORK` 路径覆盖任何原有 OA 库目录。
3. 将本包拷贝到该项目工作目录内；检查 `cds.lib` 中所有 source/PDK library 均可解析。
4. 在 Maau C++ 中把生产计划转成 `docs/PLAN_SCHEMA_zh.md` 的 v2 JSON。调整 target clone 唯一名称，例如 `CELL_L12__MAAU_JOB123`。

### B. 导出真正的全层级坐标

在 Virtuoso CIW（或一个加载相同 cds.lib 的 SKILL 会话）执行：

```lisp
load("skill/maau_geometry.il")
MaauExportGeometry("DESIGN_LIB" "LDO_TOP" "work/geometry_all.tsv"
                   list("DESIGN_LIB" "IP_LIB") 12)
```

`hierarchy_path` 是**实例路径**；`/ldo/ldo_ls/l12` 中 M1 的 `xy` 是**该 l12 cell 自身的局部坐标**，不要从顶层平铺图形估算。在 SKILL 内部基于 symbol pin bbox 加 `dbTransformPoint(... inst~>transform)` 获取 D/G/S/B 的真实位置。

### C. 接入 CDF/PDK adapter（必须）

参考 `skill/maau_pdk_adapter_template.il`，实现 `MaauTopologyApplyCdfParameters` 中的真实 PDK 参数映射与回调（例如 `CCSinvokeInstCdfCallbacks` 或工艺提供的 callback）。将自定义 adapter 路径填入 `skill/maau_runner.il` 的 `maauSiteAdapterFile`。**默认脚本故意阻止未运行 CDF 回调的有参 MOS 物化**，这是防止参数看似正确但 Spectre 模型错误的重要防线。

同时根据 PDK 的 pin 位置和原 schematic 的已有线段，选择合适的 `terminal_offset`、旧端子 `preserve_anchors` 和布线策略。默认 stub + wire label 是可阅读的基础路径，不是任何复杂模拟 schematic 的普适布线器。

### D. 转换物化计划并运行 OA 克隆

```bash
# 在包含 cds.lib 且包含本包的目录执行
python3 tools/plan_bridge.py --plan /absolute/path/to/materialize_plan_v2.json \
  --out work/maau_plan.il

# 方式一：由 runner 调用（修改其中的 PDK adapter 路径）
virtuoso -nograph -restore skill/maau_runner_batch.il

# 或安全 shell 模板（会自行转计划并检查 work/materialize.status）
# bash scripts/prepare_and_materialize_ic618.sh /absolute/path/to/materialize_plan_v2.json
```

注意：如果 `work/materialize.status` 是 `MATERIALIZED_UNVERIFIED`，含义是 **OA staged clone 已完成且默认 schCheck 的 errors/warnings 均为 0**，**绝不是最终 PASS**。仍必须重新网表化并独立验证。默认 checker 对任何警告都报错；如果原始设计包含合法历史警告，必须先建立有记录的站点 waiver，不得静默跳过。失败后可保留 staging 库供审计，下一次尝试建议换一个新 job id；绝不覆盖旧目标。

### E. 打开改造前后电路

```lisp
load("skill/maau_open.il")
MaauOpenSchematic("DESIGN_LIB" "LDO_TOP")
MaauOpenSchematic("MAAU_WORK" "LDO_TOP__MAAU_DEMO")
MaauOpenHierarchyPath("MAAU_WORK" "LDO_TOP__MAAU_DEMO" "/ldo/ldo_ls/l12")
```

也可用 `geOpen(?lib "..." ?cell "..." ?view "schematic" ?mode "r")`。先打开 top，在图形界面选实例并 Descend 可保留可返回的上下文；从数据库路径直接 `geOpen` 子 cell 只是独立打开，不自动创建父级导航栈。

### F. 由**克隆 OA** 重新生成 Spectre 网表（不能复用 C++ expected）

OCEAN 方案：

```lisp
simulator('spectre)
design("MAAU_WORK" "LDO_TOP__MAAU_DEMO" "schematic")
netlistFile = createNetlist(?recreateAll t ?display nil)
```

或使用 `si.env` 配好仿真器和 config/view list，从相应 run directory 调用 `si -batch -command nl`（见 `docs/API_AND_LIMITS_zh.md`）。**当前 Spectre netlister 一般保留 subckt 层级，不保证输出物理扁平网表；本包比较器会在 Python 中逻辑展开层级。** 比较前排除 testbench 激励、分析控制，只保留同一 DUT 所需 netlist 范围；不得截断 DUT 的必要子电路定义。

### G. 结构化比较和最终发布闸门

```bash
python3 tools/netlist_compare.py \
  --before examples/netlists/core_before.scs \
  --expected examples/netlists/core_expected.scs \
  --actual /real/netlist/from/MAAU_WORK/core_actual.scs \
  --top-before LDO_TOP --top-expected LDO_TOP \
  --top-actual LDO_TOP__MAAU_DEMO \
  --json-out work/verification.json --text-out work/verification.txt
```

退出码 0 表示 PASS、1 表示结构差异、2 表示输入/语法未被覆盖。**只有退出码 0 且 schematic check 均无错误/未批准警告，PDK 参数适配完成**才允许向用户展示“已验证的变换结果”。需要网名完全一致时再加 `--strict-net-names`；默认模式允许局部匿名网络被重新编号，但不允许任何端子连接拓扑改变。

## 4. 关键文件阅读顺序

1. `docs/ARCHITECTURE_zh.md`：设计取舍、C++ 入口切换、自底向上 remaster、四种变换及失败恢复。
2. `docs/PLAN_SCHEMA_zh.md`：建议交给 `BuildOaMaterializationPlan` 输出模块的 JSON 规范。
3. `docs/API_AND_LIMITS_zh.md`：Virtuoso API、网表导出、开放接口、几何与风险边界。
4. `docs/IC618_ACCEPTANCE_zh.md`：现场验收测试矩阵和 PASS 准则。
5. `docs/SOURCES.md`：Cadence API 参考资料及链接。

## 5. 不应误认为已经解决的环境依赖

- 无法从这里运行 IC 6.1.8，也没有你们真实 OA 库、真实四种变换计划、PDK symbol/CDF 和几何快照。本包的 SKILL 是参考落地实现，不是已通过真实 PDK 验收的即插即用插件。
- `CDF` callbacks、复杂线段切断、自动 label、symbol 接口变更、PDK stop view/config binding、全工艺模型 include/角落参数都必须现场验证。
- 对于在子 cell 引入**全新外部 bias 端口**的变换，单纯复制 symbol 不够：需生成匹配的 symbol pin，再更新每层父实例的连接及端口。本参考版**对这类接口改变直接拒绝执行**；四种变换可先选择不改变外部端口的基线用例。
- 多 cell OA 操作不是跨 cell 的原子事务。隔离 target library + 新 job id + 不发布未验证结果是本方案的事务边界。

**推荐交付判定：** `C++ expected` 正确 + `SKILL staged OA` 完成 + `schCheck/dbSave` 全部通过（默认 errors/warnings 都为 0） + `从 OA 重新 Spectre netlist` 成功 + `结构化 compare PASS` + `源 OA 保持不变`，六项全部具备，才算真正解决封装闭环。
