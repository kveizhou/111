# Release v0.2 · 2026-10-21

## 已提供

- 任意实例路径的多层级 schematic/symbol clone-on-write 参考引擎、自底向上的单实例 remaster，并在目标 cloned cell `schCheck + dbSave`；source 只读打开，target job 独立命名。
- 实际 cellview 内任意层级 `xy/bBox/terminal net/pin XY` 导出与可选 `R0` bbox 避碰工具。
- PDK adapter 留出 CDF 参数、回调、端子顺序/符号路径、wire、pin 的工艺定制点；缺少 MOS 有参回调时默认拒绝操作。
- 通用 Spectre `subckt` 网表结构比较器，按实例路径平铺并比较 master/参数/端子连通关系，忽略实例行顺序和内部网名重编号。
- 强化预检：从 C++ `device_catalog.tsv` 正规化到 catalog JSON，再用真实 PDK terminal order 检查每个 plan `terminal_nets` 与 `core_expected.scs` 一致。
- 双重发布闸门：**克隆 OA readback vs expected**、**源 OA postread vs before baseline** 全部 PASS，且所有克隆的 Check & Save 有完整日志与文件哈希。
- 离线自动测试（37 项）：正常 Cascode、异型 LVT、Source 串电阻、Stack N=3，以及错误接线、缺失 subckt、非法计划、安全边界回归。

## 尚不能凭本包验证/完成

- 未在真实 IC 6.1.8、真实 OA、所选 PDK/ISR 上运行或签署验收。
- 无法从占位 PDK 自动生成真实器件参数回调或万能 schematic router；相交导线、断线、旧 label/anchor、额外 symbol 外部 pin 等必须按现场 adapter 实现并重新网表化对比。
- Spectre parser 不是完整模拟语言解释器；模型 include、表达式、parameter inheritance 和物理功能仿真需要用真实 netlister/C++ AST+Spectre 完成。

## 优先使用

`README_zh.md` → `docs/PDK_CATALOG_GUIDE_zh.md` → `docs/PLAN_SCHEMA_zh.md` → `docs/IC618_ACCEPTANCE_zh.md`。
