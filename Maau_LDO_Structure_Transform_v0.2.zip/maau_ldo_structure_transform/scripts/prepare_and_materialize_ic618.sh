#!/usr/bin/env bash
# Run in an ISOLATED per-job directory exposing cds.lib; adapt SKILL runner paths.
# Usage: prepare_and_materialize_ic618.sh plan_v2.json core_before.scs core_expected.scs device_catalog.json
# Never run on production OA work directories without reviewing clone targets.
set -euo pipefail
if [[ $# -ne 4 ]]; then
  echo "Usage: $0 <plan_v2.json> <before.scs> <expected.scs> <PDK_leaf_catalog.json>" >&2
  exit 2
fi
if [[ ! -f cds.lib ]]; then
  echo "ERROR: cds.lib must exist in CURRENT working directory" >&2; exit 2
fi
mkdir -p work
if [[ -e work/materialize.status || -e work/materialize_plan_v2.json ]]; then
  echo "ERROR: existing job files; use a unique job working directory" >&2; exit 2
fi
python3 tools/plan_bridge.py --plan "$1" --out work/maau_plan.il
python3 tools/plan_expected_precheck.py \
  --plan "$1" --catalog "$4" --before "$2" --expected "$3" \
  --top-before "${BEFORE_TOP:-LDO_TOP}" --top-expected "${EXPECTED_TOP:-LDO_TOP}" \
  --json-out work/plan_preflight.json
cp -- "$1" work/materialize_plan_v2.json
# IMPORTANT: site-specific CDF callback adapter must be configured in runner.
# Virtuoso can exit with 0 despite script failure; status file is authoritative.
virtuoso -nograph -restore skill/maau_runner_batch.il 2>&1 | tee work/virtuoso_materialize.log
if [[ ! -f work/materialize.status ]] || ! grep -Fxq MATERIALIZED_UNVERIFIED work/materialize.status; then
  echo "ERROR: SKILL OA materialization incomplete; inspect work/virtuoso_materialize.log" >&2
  exit 1
fi
echo "STAGED ONLY: clone OA views exist, NOT VERIFIED. Re-netlist BOTH source and cloned top."
