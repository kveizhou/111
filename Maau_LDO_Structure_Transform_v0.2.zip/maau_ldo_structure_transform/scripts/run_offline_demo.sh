#!/usr/bin/env bash
# End-to-end OFFLINE plan contract + expected-netlist + comparator demo.
# This never opens/modifies any OA database. Do not treat offline PASS as release.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p work
CATALOG=examples/device_catalog_demo.json
python3 tools/plan_bridge.py --plan examples/plan.json --out work/maau_plan.il
python3 tools/plan_expected_precheck.py \
  --plan examples/plan.json --catalog "$CATALOG" \
  --before examples/netlists/core_before.scs \
  --expected examples/netlists/core_expected.scs \
  --json-out work/plan_preflight_demo.json
for variant in cascode_lvt source_resistor stack3; do
  python3 tools/plan_expected_precheck.py \
    --plan "examples/variants/plan_${variant}.json" --catalog "$CATALOG" \
    --before examples/netlists/core_before.scs \
    --expected "examples/variants/netlists/expected_${variant}.scs" \
    --json-out "work/preflight_${variant}.json"
done
python3 tools/netlist_compare.py \
  --before examples/netlists/core_before.scs \
  --expected examples/netlists/core_expected.scs \
  --actual examples/netlists/core_actual_good.scs \
  --top-before LDO_TOP --top-expected LDO_TOP --top-actual LDO_TOP__MAAU_DEMO \
  --leaf-catalog "$CATALOG" \
  --json-out work/offline_pass.json --text-out work/offline_pass.txt
set +e
python3 tools/netlist_compare.py \
  --expected examples/netlists/core_expected.scs \
  --actual examples/netlists/core_actual_bad.scs \
  --top-expected LDO_TOP --top-actual LDO_TOP__MAAU_DEMO \
  --leaf-catalog "$CATALOG" \
  --json-out work/offline_fail.json --text-out work/offline_fail.txt
bad_rc=$?
set -e
if [[ $bad_rc -ne 1 ]]; then
  echo "ERROR: deliberately bad wiring must return FAIL (1), got $bad_rc" >&2
  exit 1
fi
echo 'Expected: incorrect Cascode terminal connection produced compare FAIL (exit 1).'
python3 -m unittest discover -s tests -v
echo 'OFFLINE REGRESSION OK. OA has NOT been accessed. Site-specific acceptance is still required.'
