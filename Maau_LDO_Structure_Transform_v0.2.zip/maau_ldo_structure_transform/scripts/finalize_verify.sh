#!/usr/bin/env bash
# Verified release gate: both clone structure and source immutability checked.
# Usage: finalize_verify.sh actual_clone.scs expected.scs original_before.scs source_after.scs leaf_catalog.json
# Every actual_*.scs must be exported freshly from the real OA library.
set -euo pipefail
if [[ $# -ne 5 ]]; then
  echo "Usage: $0 <clone_from_OA.scs> <expected.scs> <before.scs> <source_after_OA.scs> <PDK_leaf_catalog.json>" >&2
  exit 2
fi
mkdir -p work
rm -f work/VERIFIED_PASS
if [[ ! -f work/materialize.status ]] || ! grep -Fxq MATERIALIZED_UNVERIFIED work/materialize.status; then
  echo "ERROR: OA staging has not completed successfully" >&2; exit 2
fi
if [[ ! -f work/plan_preflight.json || ! -f work/maau_plan.il || ! -f work/materialize_plan_v2.json ]]; then
  echo "ERROR: missing plan/preflight audit artifacts" >&2; exit 2
fi
if [[ ! -f work/virtuoso_materialize.log ]]; then
  echo "ERROR: missing real Virtuoso materialization log" >&2; exit 2
fi
# Verify that the real Virtuoso log contains one completed schCheck+dbSave
# for every cloned cellview, before asserting that the staging is check-clean.
EXPECTED_CLONES=$(python3 - <<'PY'
import json
with open('work/materialize_plan_v2.json', encoding='utf-8') as f:
    plan=json.load(f)
with open('work/plan_preflight.json', encoding='utf-8') as f:
    preflight=json.load(f)
if preflight.get('status')!='PASS':
    raise SystemExit('PRECHECK NOT PASS')
print(len(plan['clone_on_write']))
PY
)
if ! [[ "$EXPECTED_CLONES" =~ ^[0-9]+$ ]] || [[ "$EXPECTED_CLONES" == 0 ]]; then
  echo 'ERROR: could not count cloned cellviews' >&2; exit 2
fi
ACTUAL_CHECKS=$(grep -c '^MAAU_CHECK_PASS ' work/virtuoso_materialize.log || true)
if [[ "$EXPECTED_CLONES" -ne "$ACTUAL_CHECKS" ]]; then
  echo "ERROR: expected $EXPECTED_CLONES schematic checks, Virtuoso log has $ACTUAL_CHECKS" >&2
  exit 1
fi
EXPECTED_TOP="${EXPECTED_TOP:-LDO_TOP}"
ACTUAL_TOP="${ACTUAL_TOP:-LDO_TOP__MAAU_DEMO}"
BEFORE_TOP="${BEFORE_TOP:-$EXPECTED_TOP}"
SOURCE_AFTER_TOP="${SOURCE_AFTER_TOP:-$BEFORE_TOP}"
# DUT check (0=PASS, 1=FAIL, 2=parsing/IO error).
python3 tools/netlist_compare.py \
  --before "$3" --expected "$2" --actual "$1" \
  --top-before "$BEFORE_TOP" --top-expected "$EXPECTED_TOP" --top-actual "$ACTUAL_TOP" \
  --leaf-catalog "$5" \
  --json-out work/verification.json --text-out work/verification.txt
# Independently prove source OA has not changed since the baseline netlist.
python3 tools/netlist_compare.py \
  --expected "$3" --actual "$4" \
  --top-expected "$BEFORE_TOP" --top-actual "$SOURCE_AFTER_TOP" \
  --leaf-catalog "$5" \
  --json-out work/source_integrity.json --text-out work/source_integrity.txt
sha256sum "$1" "$2" "$3" "$4" "$5" \
  work/maau_plan.il work/materialize_plan_v2.json \
  work/virtuoso_materialize.log > work/verification_inputs.sha256
printf 'PASS\n' > work/VERIFIED_PASS
echo 'VERIFIED_PASS: clone matches expected; source OA matches baseline; all staged check/save operations logged.'
echo 'IMPORTANT: confirm PDK callbacks/models, view binding, and circuit-level simulation separately.'
