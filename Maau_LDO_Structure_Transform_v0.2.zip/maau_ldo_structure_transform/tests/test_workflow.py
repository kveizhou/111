import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'tools'))
from netlist_compare import compare_expanded, expand, parse_netlist, NetlistError, logical_lines
from plan_bridge import validate_plan, ContractError, to_skill
from plan_expected_precheck import load_catalog, check_consistency
import subprocess

FIX = BASE / 'examples' / 'netlists'


def parsed(name, top):
    return expand(parse_netlist(FIX / name), top)


def skill_parentheses(path):
    """Checks delimiter balance and dangling string; NOT SKILL evaluation."""
    data = path.read_text()
    depth = 0
    quote = False
    escape = False
    comment = False
    for line in data.splitlines(keepends=True):
        comment = False
        for ch in line:
            if comment:
                continue
            if quote:
                if escape:
                    escape = False
                elif ch == '\\':
                    escape = True
                elif ch == '"':
                    quote = False
                elif ch == '\n':
                    raise AssertionError(f"newline inside quoted string {path}")
                continue
            if ch == ';':
                comment = True
            elif ch == '"':
                quote = True
            elif ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth < 0:
                    raise AssertionError(f"Unexpected ) in {path}")
    if quote or depth:
        raise AssertionError(f"Unbalanced SKILL {path}: quote={quote} parentheses={depth}")


class ComparatorTests(unittest.TestCase):
    def setUp(self):
        self.expected = parsed('core_expected.scs', 'LDO_TOP')
        self.good = parsed('core_actual_good.scs', 'LDO_TOP__MAAU_DEMO')
        self.bad = parsed('core_actual_bad.scs', 'LDO_TOP__MAAU_DEMO')

    def test_good_semantic_equivalence(self):
        r = compare_expanded(self.expected, self.good)
        self.assertEqual(r['status'], 'PASS')
        self.assertEqual(r['counts']['actual_devices'], 3)
        self.assertTrue(r['differences']['renamed_nets'])

    def test_strict_name_mode(self):
        r = compare_expanded(self.expected, self.good, strict_names=True)
        self.assertEqual(r['status'], 'FAIL')
        self.assertEqual(len(r['differences']['changed_nets']), 0)

    def test_wrong_cascode_source_detected(self):
        r = compare_expanded(self.expected, self.bad)
        self.assertEqual(r['status'], 'FAIL')
        self.assertTrue(any('M1_CAS#2' in row['endpoint'] for row in r['differences']['changed_nets']))

    def test_cloned_branch_not_sibling(self):
        self.assertIn('ldo_spare/ldo_ls/l12/M1', self.expected.devices)
        self.assertEqual(self.expected.devices['ldo_spare/ldo_ls/l12/M1'].nets,
                         self.good.devices['ldo_spare/ldo_ls/l12/M1'].nets)

    def test_missing_device(self):
        changed = copy.deepcopy(self.good)
        changed.devices.pop('ldo/ldo_ls/l12/M1_CAS')
        self.assertEqual(compare_expanded(self.expected, changed)['status'], 'FAIL')

    def test_wrong_master(self):
        from netlist_compare import FlatInst
        changed = copy.deepcopy(self.good)
        key = 'ldo/ldo_ls/l12/M1_CAS'
        d = changed.devices[key]
        changed.devices[key] = FlatInst(key, 'pMOS_WRONG', d.nets, d.params)
        self.assertTrue(compare_expanded(self.expected, changed)['differences']['modified_devices'])

    def test_different_subckt_call_parameters(self):
        a = copy.deepcopy(self.good)
        a.calls['ldo'] = (('scale', '2'),)
        self.assertEqual(compare_expanded(self.expected, a)['status'], 'FAIL')

    def test_top_default_parameter_is_compared(self):
        a = copy.deepcopy(self.good)
        a.calls['@ROOT_DEFAULTS'] = (('VREF', '1.2'),)
        self.assertEqual(compare_expanded(self.expected, a)['status'], 'FAIL')

    def test_missing_subckt_is_not_a_primitive(self):
        from netlist_compare import Parsed, Subckt, Inst
        s = Parsed()
        s.subckts['LDO_TOP'] = Subckt('LDO_TOP', ('OUT',),
            instances={'ldo': Inst('ldo', ('OUT',), 'CELL_LDO_NOT_DEFINED')})
        _, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        with self.assertRaises(NetlistError):
            expand(s, 'LDO_TOP', leaf_masters=leaves)

    def test_catalog_based_verification_is_clean(self):
        _, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        a = expand(parse_netlist(FIX / 'core_expected.scs'), 'LDO_TOP', leaf_masters=leaves)
        b = expand(parse_netlist(FIX / 'core_actual_good.scs'),
                   'LDO_TOP__MAAU_DEMO', leaf_masters=leaves)
        self.assertEqual(compare_expanded(a, b)['status'], 'PASS')

    def test_fail_closed_on_unknown_internal_line(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'broken.scs'
            path.write_text('subckt X (a b)\nTHIS_IS_NOT_A_DEVICE\nends X\n')
            with self.assertRaises(NetlistError):
                parse_netlist(path)

    def test_unknown_top_level_not_silently_ignored(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'broken.scs'
            path.write_text('BROKEN_LINE a b\nsubckt X (a b)\nR0 (a b) resistor r=1k\nends X\n')
            with self.assertRaises(NetlistError):
                parse_netlist(path)

    def test_continuations(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'continued.scs'
            path.write_text('subckt X (a b)\\\n parameters N=3\nR1 (a b) resistor\\\n r=1k\n+ m=2\nends X\n')
            result = parse_netlist(path)
            self.assertEqual(result.subckts['X'].defaults['N'], '3')
            self.assertEqual(dict(result.subckts['X'].instances['R1'].params)['r'], '1E+3')


class VariantComparisonTests(unittest.TestCase):
    def test_three_more_transform_classes(self):
        base = BASE / "examples" / "variants" / "netlists"
        for kind in ("cascode_lvt", "source_resistor", "stack3"):
            with self.subTest(kind=kind):
                want = expand(parse_netlist(base / f"expected_{kind}.scs"), "LDO_TOP")
                got = expand(parse_netlist(base / f"actual_{kind}.scs"),
                             f"LDO_TOP__MAAU_{kind.upper()}")
                self.assertEqual(compare_expanded(want, got)["status"], "PASS")

    def test_catalog_tsv_refuses_existing_output(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d) / 'keep.json'
            dest.write_text('KEEP ME', encoding='utf-8')
            p = subprocess.run([
                sys.executable, str(BASE / 'tools' / 'catalog_tsv_to_json.py'),
                '--tsv', str(BASE / 'examples' / 'device_catalog_normalized_demo.tsv'),
                '--out', str(dest)], text=True, capture_output=True)
            self.assertNotEqual(p.returncode, 0)
            self.assertEqual(dest.read_text(encoding='utf-8'), 'KEEP ME')

    def test_catalog_tsv_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = subprocess.run([
                sys.executable, str(BASE / 'tools' / 'catalog_tsv_to_json.py'),
                '--tsv', str(BASE / 'examples' / 'device_catalog_normalized_demo.tsv'),
                '--out', str(Path(d) / 'catalog.json')],
                text=True, capture_output=True)
            self.assertEqual(p.returncode, 0, p.stderr)
            catalog, models = load_catalog(Path(d) / 'catalog.json')
            self.assertEqual(len(catalog), 3)
            self.assertIn('resistor', models)

    def test_all_variant_plan_matches_expected(self):
        catalog, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        before = expand(parse_netlist(FIX / 'core_before.scs'), 'LDO_TOP', leaf_masters=leaves)
        for kind in ('cascode_lvt', 'source_resistor', 'stack3'):
            with self.subTest(kind=kind):
                plan = json.loads((BASE / 'examples' / 'variants' / f'plan_{kind}.json').read_text())
                expected = expand(parse_netlist(BASE / 'examples' / 'variants' / 'netlists' /
                                                f'expected_{kind}.scs'), 'LDO_TOP', leaf_masters=leaves)
                self.assertEqual(check_consistency(plan, before, expected, catalog)['status'], 'PASS')

    def test_all_variant_plans_valid(self):
        for f in (BASE / "examples" / "variants").glob("plan_*.json"):
            with self.subTest(path=f.name):
                validate_plan(json.loads(f.read_text()))


class PlanTests(unittest.TestCase):
    def setUp(self):
        self.plan = json.loads((BASE / 'examples' / 'plan.json').read_text())

    def test_valid(self):
        self.assertIs(validate_plan(self.plan), self.plan)

    def test_source_mutation_refused(self):
        x = copy.deepcopy(self.plan)
        x['clone_on_write'][0]['target'] = x['clone_on_write'][0]['source']
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_missing_cloned_ancestor(self):
        x = copy.deepcopy(self.plan)
        x['clone_on_write'].pop(1)
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_duplicate_path(self):
        x = copy.deepcopy(self.plan)
        x['clone_on_write'].append(copy.deepcopy(x['clone_on_write'][-1]))
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_rebinding_contract(self):
        x = copy.deepcopy(self.plan)
        x['clone_on_write'][-1]['parent_instance'] = 'OTHER'
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_unimplemented_interface_change_fails_closed(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_ports'].append({'name': 'NEW', 'direction': 'input', 'xy': [0,0]})
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_reject_unsupported_oA_edit_actions(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['delete_wire_segments'] = [{'net':'OUT'}]
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_reject_nan_coordinate(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_instances'][0]['xy'] = [float('nan'), 3.0]
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_reject_param_type_mismatch(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_instances'][0]['params']['w'] = {'type':'int', 'value':'2u'}
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_anchor_must_be_on_deleted_instance(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['preserve_anchors'][0]['instance'] = 'not_deleted'
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_escaping_no_code_injection(self):
        value = to_skill({'str': '" ) system("touch HACKED") ;'})
        self.assertIn('\\"', value)
        self.assertIn('list(', value)

    def test_direct_wire_net_must_match_terminal_declarations(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_direct_wires'][0]['net'] = 'GND'
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_unknown_schema_field_rejected(self):
        x = copy.deepcopy(self.plan)
        x['arbitrary_custom_skill'] = 'evil'
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_invalid_net_label_rejected(self):
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_instances'][0]['terminal_nets']['D'] = 'NET\nINJECTED'
        with self.assertRaises(ContractError):
            validate_plan(x)

    def test_plan_expected_cascode_passes(self):
        catalog, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        before = expand(parse_netlist(FIX / 'core_before.scs'), 'LDO_TOP', leaf_masters=leaves)
        expected = expand(parse_netlist(FIX / 'core_expected.scs'), 'LDO_TOP', leaf_masters=leaves)
        self.assertEqual(check_consistency(self.plan, before, expected, catalog)['status'], 'PASS')

    def test_plan_expected_wrong_terminal_fails(self):
        catalog, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        before = expand(parse_netlist(FIX / 'core_before.scs'), 'LDO_TOP', leaf_masters=leaves)
        expected = expand(parse_netlist(FIX / 'core_expected.scs'), 'LDO_TOP', leaf_masters=leaves)
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_instances'][1]['terminal_nets']['S'] = 'GND'
        x['operations'][0]['create_direct_wires'] = []
        result = check_consistency(x, before, expected, catalog)
        self.assertEqual(result['status'], 'FAIL')
        self.assertTrue(any('terminal nets expected' in e for e in result['issues']))

    def test_plan_expected_wrong_pdk_master_fails(self):
        catalog, leaves = load_catalog(BASE / 'examples' / 'device_catalog_demo.json')
        before = expand(parse_netlist(FIX / 'core_before.scs'), 'LDO_TOP', leaf_masters=leaves)
        expected = expand(parse_netlist(FIX / 'core_expected.scs'), 'LDO_TOP', leaf_masters=leaves)
        x = copy.deepcopy(self.plan)
        x['operations'][0]['create_instances'][1]['master']['cell'] = 'nch_lvt_180'
        self.assertEqual(check_consistency(x, before, expected, catalog)['status'], 'FAIL')

    def test_release_gate_without_oa_log_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            call = ["bash", str(BASE / 'scripts' / 'finalize_verify.sh')]
            call += [str(FIX / 'core_actual_good.scs'), str(FIX / 'core_expected.scs'),
                     str(FIX / 'core_before.scs'), str(FIX / 'core_before.scs'),
                     str(BASE / 'examples' / 'device_catalog_demo.json')]
            p = subprocess.run(call, cwd=d, capture_output=True, text=True)
            self.assertNotEqual(p.returncode, 0)
            self.assertFalse((Path(d) / 'work' / 'VERIFIED_PASS').exists())

    def test_skill_sources_balanced(self):
        for path in (BASE / 'skill').glob('*.il'):
            with self.subTest(path=path.name):
                skill_parentheses(path)
        skill_parentheses(BASE / 'examples' / 'plan_generated.il')


if __name__ == '__main__':
    unittest.main()
