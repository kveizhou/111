#!/usr/bin/env python3
"""Convert a REVIEWED normal-form device_catalog.tsv into strict catalog JSON.

Not a PDK introspection tool. It cannot infer terminal order or Spectre model
from symbol names; those must be explicitly supplied/verified by the integrator.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys
import os
import tempfile

from plan_expected_precheck import load_catalog


def main() -> int:
    ap = argparse.ArgumentParser(description="Convert a normalized PDK master/termOrder TSV to a verified-layout JSON catalog")
    ap.add_argument('--tsv', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--additional-leaf', action='append', default=[],
                    help='Leaf Spectre master also allowed as a verified primitive (repeatable)')
    args = ap.parse_args()
    needed = {'lib', 'cell', 'view', 'spectre_master', 'terminal_order', 'cdf_to_spectre_params'}
    temporary_path = None
    try:
        if args.out.exists():
            raise ValueError(f'Refusing to overwrite existing catalog output: {args.out}')
        with args.tsv.open(encoding='utf-8', newline='') as file:
            reader = csv.DictReader(file, delimiter='\t')
            if not reader.fieldnames or not needed.issubset(set(reader.fieldnames)):
                raise ValueError(f'Missing normalized TSV fields: {sorted(needed - set(reader.fieldnames or []))}')
            entries = []
            for line, row in enumerate(reader, 2):
                terminal_order = [s.strip() for s in row['terminal_order'].split(',')]
                raw_params = row['cdf_to_spectre_params'].strip()
                entry = {k: row[k].strip() for k in ('lib', 'cell', 'view', 'spectre_master')}
                entry['terminal_order'] = terminal_order
                entry['cdf_to_spectre_params'] = json.loads(raw_params) if raw_params else {}
                if not isinstance(entry['cdf_to_spectre_params'], dict):
                    raise ValueError(f'line {line}: parameter map is not a JSON object')
                entries.append(entry)
        obj = {'schema_version': 1, 'masters': entries,
               'additional_leaf_masters': args.additional_leaf}
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         prefix='.catalog-', suffix='.json',
                                         dir=args.out.parent, delete=False) as f:
            temporary_path = Path(f.name)
            f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
        catalog, models = load_catalog(temporary_path)
        # Destination was checked above; never replace a user-owned catalog.
        if args.out.exists():
            raise ValueError(f'Catalog output appeared concurrently: {args.out}')
        os.rename(temporary_path, args.out)
        temporary_path = None
        print(f'CATALOG: {len(catalog)} validated OA masters, {len(models)} Spectre leaf masters. Output: {args.out}')
        return 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print('CATALOG ERROR:', exc, file=sys.stderr)
        return 2
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


if __name__ == '__main__':
    sys.exit(main())
