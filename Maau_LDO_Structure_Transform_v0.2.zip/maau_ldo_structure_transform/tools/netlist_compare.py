#!/usr/bin/env python3
"""Spectre core-netlist structural comparator (no Cadence dependency).

Covers the common Spectre `subckt ... ends` / `name (nodes) master params`
subset. Unknown statements INSIDE subckts fail closed; top-level simulator,
analysis and model statements are reported as skipped, never silently treated
as devices. It does NOT resolve PDK includes, model evaluation or behavioral
expression semantics.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import re
import sys
from typing import Any


class NetlistError(ValueError):
    pass


@dataclass(frozen=True)
class Inst:
    name: str
    nodes: tuple[str, ...]
    master: str
    params: tuple[tuple[str, str], ...] = ()


@dataclass
class Subckt:
    name: str
    ports: tuple[str, ...]
    defaults: dict[str, str] = field(default_factory=dict)
    instances: dict[str, Inst] = field(default_factory=dict)


@dataclass
class Parsed:
    subckts: dict[str, Subckt] = field(default_factory=dict)
    globals: set[str] = field(default_factory=lambda: {"0"})
    top_statements_skipped: list[dict[str, Any]] = field(default_factory=list)
    top_instances: dict[str, Inst] = field(default_factory=dict)


SUFFIXES = {
    "t": "1e12", "g": "1e9", "meg": "1e6", "k": "1e3", "m": "1e-3",
    "u": "1e-6", "n": "1e-9", "p": "1e-12", "f": "1e-15", "a": "1e-18",
}
VALUE_RE = re.compile(r"^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)(meg|[TGMkmunpfa])$", re.I)


def norm_value(s: str) -> str:
    raw = s.strip().strip('"').strip("'")
    m = VALUE_RE.fullmatch(raw)
    try:
        if m:
            return str((Decimal(m.group(1)) * Decimal(SUFFIXES[m.group(2).lower()])).normalize())
        return str(Decimal(raw).normalize())
    except (InvalidOperation, KeyError):
        return re.sub(r"\s+", "", raw)


def strip_comment(line: str) -> str:
    quote = None
    escaped = False
    for i, c in enumerate(line):
        if escaped:
            escaped = False
            continue
        if quote and c == "\\":
            escaped = True
            continue
        if c in ('"', "'"):
            if quote == c:
                quote = None
            elif not quote:
                quote = c
        if not quote and line[i:i+2] == "//":
            return line[:i]
    return line


def logical_lines(path: Path) -> list[tuple[int, str]]:
    result: list[tuple[int, str]] = []
    text = path.read_text(encoding="utf-8-sig")
    pending = ""
    first = 0
    expects_next = False
    for lineno, physical in enumerate(text.splitlines(), 1):
        s = strip_comment(physical).strip()
        if not s or s.startswith("*"):
            continue
        is_plus = s.startswith("+")
        if is_plus:
            if not pending:
                raise NetlistError(f"{path}:{lineno}: orphan + continuation")
            s = s[1:].strip()
        if pending and not (is_plus or expects_next):
            result.append((first, pending))
            pending = ""
        if not pending:
            first = lineno
        trailing_slash = s.endswith("\\")
        if trailing_slash:
            s = s[:-1].rstrip()
        pending = (pending + " " + s).strip() if pending else s
        expects_next = trailing_slash
    if expects_next:
        raise NetlistError(f"{path}: dangling backslash continuation")
    if pending:
        result.append((first, pending))
    return result


def split_top(text: str) -> list[str]:
    """Whitespace lexer respecting quotes and (), {}, [] (not expression parser)."""
    result: list[str] = []
    buf: list[str] = []
    stack: list[str] = []
    quote: str | None = None
    previous = ""
    pairs = {')': '(', '}': '{', ']': '['}
    for c in text:
        if quote:
            buf.append(c)
            if c == quote and previous != "\\":
                quote = None
        elif c in ('"', "'"):
            quote = c
            buf.append(c)
        elif c in "({[":
            stack.append(c)
            buf.append(c)
        elif c in ")}]":
            if not stack or stack.pop() != pairs[c]:
                raise NetlistError(f"Unbalanced parameter delimiters: {text}")
            buf.append(c)
        elif c.isspace() and not stack:
            if buf:
                result.append("".join(buf))
                buf.clear()
        else:
            buf.append(c)
        previous = c
    if quote or stack:
        raise NetlistError(f"Unterminated quote/delimiter: {text}")
    if buf:
        result.append("".join(buf))
    return result


def parse_params(text: str) -> dict[str, str]:
    toks = split_top(text)
    result: dict[str, str] = {}
    for token in toks:
        if token.lower() == "parameters":
            continue
        if "=" not in token:
            raise NetlistError(f"Unexpected parameter token {token!r} (expect key=value)")
        k, v = token.split("=", 1)
        if not k or not v or k in result:
            raise NetlistError(f"Invalid/duplicate parameter token: {token}")
        result[k] = norm_value(v)
    return result


def parse_head(body: str, what: str) -> tuple[str, tuple[str, ...], str]:
    m = re.match(r"^([^\s(]+)\s+\(([^()]*)\)\s*(.*)$", body)
    if not m:
        raise NetlistError(f"Unsupported {what} header (expected NAME (nodes) ...): {body}")
    return m.group(1), tuple(m.group(2).split()), m.group(3).strip()


def parse_netlist(path: Path) -> Parsed:
    res = Parsed()
    current: Subckt | None = None
    for lineno, s in logical_lines(path):
        where = f"{path}:{lineno}"
        first = s.split(None, 1)[0].lower()
        try:
            if first == "subckt":
                if current:
                    raise NetlistError("Nested subckt definitions unsupported")
                name, ports, extra = parse_head(s[len("subckt"):].strip(), "subckt")
                if name in res.subckts:
                    raise NetlistError(f"Duplicate subckt definition {name}")
                defaults = parse_params(extra) if extra else {}
                current = Subckt(name, ports, defaults)
                res.subckts[name] = current
            elif first == "ends":
                if not current:
                    raise NetlistError("ends without subckt")
                tokens = s.split()
                if len(tokens) > 1 and tokens[1] != current.name:
                    raise NetlistError(f"ends {tokens[1]} does not match {current.name}")
                current = None
            elif first == "parameters":
                if current:
                    for k, v in parse_params(s[len("parameters"):].strip()).items():
                        if k in current.defaults:
                            raise NetlistError(f"duplicate parameter {k}")
                        current.defaults[k] = v
                else:
                    res.top_statements_skipped.append({"line": lineno, "text": s, "reason": "design variable"})
            elif first == "global":
                res.globals.update(s.split()[1:])
            elif first in {"simulator", "include", "ahdl_include", "model", "library", "endlibrary", "section", "endsection"}:
                if current:
                    raise NetlistError(f"Non-device statement inside subckt is not covered: {s}")
                res.top_statements_skipped.append({"line": lineno, "text": s, "reason": "external/model directive not expanded"})
            else:
                # Recognize only actual Spectre instance syntax. In a subckt an
                # unrecognized line is fatal; don't accidentally skip a device.
                try:
                    name, nodes, extra = parse_head(s, "instance")
                    tokens = split_top(extra)
                    if not tokens:
                        raise NetlistError("Missing master")
                    master = tokens[0]
                    params = parse_params(" ".join(tokens[1:])) if len(tokens) > 1 else {}
                    instance = Inst(name, nodes, master, tuple(sorted(params.items())))
                    items = current.instances if current else res.top_instances
                    if name in items:
                        raise NetlistError(f"Duplicate instance {name}")
                    items[name] = instance
                except NetlistError:
                    if current:
                        raise
                    # Nonstructural top-level sim options/analysis: report skip.
                    fields = s.split()
                    known_nonstructural = {
                        "options", "tran", "dc", "ac", "stb", "noise", "pss", "pac",
                        "pnoise", "xf", "sweep", "montecarlo", "save", "saveoptions",
                        "info", "alter", "pz", "sp", "oppoint", "assert", "checklimit",
                    }
                    if (len(fields) >= 2 and fields[1].lower() in known_nonstructural):
                        res.top_statements_skipped.append({"line": lineno, "text": s, "reason": "explicitly recognized analysis directive"})
                    else:
                        raise
        except NetlistError as e:
            raise NetlistError(f"{where}: {e}") from e
    if current:
        raise NetlistError(f"{path}: unterminated subckt {current.name}")
    if not res.subckts and not res.top_instances:
        raise NetlistError(f"No instances/subckt found in {path}")
    return res


@dataclass(frozen=True)
class FlatInst:
    path: str
    master: str
    nets: tuple[str, ...]
    params: tuple[tuple[str, str], ...]


@dataclass
class Expanded:
    devices: dict[str, FlatInst] = field(default_factory=dict)
    calls: dict[str, tuple[tuple[str, str], ...]] = field(default_factory=dict)
    groups: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    device_node_names: dict[str, tuple[str, ...]] = field(default_factory=dict)
    ports: tuple[str, ...] = ()
    warnings: list[str] = field(default_factory=list)


def expand(src: Parsed, top: str, max_depth: int = 128,
           leaf_masters: set[str] | None = None) -> Expanded:
    if top not in src.subckts:
        raise NetlistError(f"Top {top!r} absent; options: {', '.join(sorted(src.subckts))}")
    result = Expanded()
    result.ports = src.subckts[top].ports
    result.calls["@ROOT_DEFAULTS"] = tuple(sorted(src.subckts[top].defaults.items()))

    def port_or_local(raw: str, namespace: str, mapping: dict[str, str]) -> str:
        if raw in mapping:
            return mapping[raw]
        if raw in src.globals or raw.endswith("!"):
            return f"GLOBAL::{raw}"
        return f"{namespace}::{raw}"

    root = src.subckts[top]
    top_map = {p: f"TOP::{p}" for p in root.ports}

    def visit(block: Subckt, prefix: str, mapping: dict[str, str], stack: tuple[str, ...], env: dict[str, str]):
        if len(stack) > max_depth:
            raise NetlistError(f"Excess hierarchy depth, possible recursion: {stack}")
        for inst in block.instances.values():
            path = f"{prefix}/{inst.name}" if prefix else inst.name
            nets = tuple(port_or_local(n, prefix or "@root", mapping) for n in inst.nodes)
            params = dict(inst.params)
            if inst.master in src.subckts:
                child = src.subckts[inst.master]
                if inst.master in stack:
                    raise NetlistError(f"Recursive instance hierarchy: {stack} -> {inst.master}")
                if len(nets) != len(child.ports):
                    raise NetlistError(f"{path}: {len(nets)} connections, {len(child.ports)} subckt pins")
                resolved_env = dict(child.defaults)
                resolved_env.update(params)
                # Include effective subckt call parameters: silent changes in
                # inherited/overridden parameters must not pass unnoticed.
                result.calls[path] = tuple(sorted(resolved_env.items()))
                visit(child, path, dict(zip(child.ports, nets)), stack + (inst.master,), resolved_env)
            else:
                # If a subckt definition was omitted from BOTH expected and
                # actual, treating it as a primitive would create a false PASS.
                # Production verification therefore supplies an explicit PDK
                # leaf/model catalog and fails closed on unknown masters.
                if leaf_masters is not None and inst.master not in leaf_masters:
                    raise NetlistError(
                        f"{path}: unresolved master {inst.master!r}; missing subckt "
                        "definition or unregistered PDK primitive")
                if path in result.devices:
                    raise NetlistError(f"Duplicate flattened path {path}")
                result.devices[path] = FlatInst(path, inst.master, nets, inst.params)
                result.device_node_names[path] = inst.nodes
                for idx, net in enumerate(nets):
                    result.groups[net].add(f"{path}#{idx}")
    for p in root.ports:
        result.groups[f"TOP::{p}"].add(f"@PORT:{p}")
    visit(root, "", top_map, (top,), root.defaults)
    if not result.devices:
        raise NetlistError(f"Top {top} contains no resolved device instances")
    for net, endpoints in result.groups.items():
        if net.startswith("GLOBAL::"):
            endpoints.add(f"@GLOBAL:{net.split('::', 1)[1]}")
    return result


def groups_for_endpoints(e: Expanded) -> dict[str, tuple[str, ...]]:
    result: dict[str, tuple[str, ...]] = {}
    for members in e.groups.values():
        signature = tuple(sorted(members))
        for endpoint in members:
            if endpoint in result and result[endpoint] != signature:
                raise NetlistError(f"Endpoint {endpoint} attached to multiple nets")
            result[endpoint] = signature
    return result


def compare_expanded(expected: Expanded, actual: Expanded, strict_names: bool = False) -> dict[str, Any]:
    ekeys = set(expected.devices)
    akeys = set(actual.devices)
    changed: list[dict[str, Any]] = []
    for path in sorted(ekeys & akeys):
        e = expected.devices[path]
        a = actual.devices[path]
        fields: dict[str, Any] = {}
        if e.master != a.master:
            fields["master"] = {"expected": e.master, "actual": a.master}
        if len(e.nets) != len(a.nets):
            fields["terminal_count"] = {"expected": len(e.nets), "actual": len(a.nets)}
        if e.params != a.params:
            ep = dict(e.params)
            ap = dict(a.params)
            fields["parameters"] = {
                k: {"expected": ep.get(k), "actual": ap.get(k)}
                for k in sorted(set(ep) | set(ap)) if ep.get(k) != ap.get(k)
            }
        if fields:
            changed.append({"path": path, **fields})
    changed_calls = [
        {"path": p, "expected": dict(expected.calls.get(p, ())), "actual": dict(actual.calls.get(p, ())) }
        for p in sorted(set(expected.calls) | set(actual.calls))
        if expected.calls.get(p) != actual.calls.get(p)
    ]
    egroup = groups_for_endpoints(expected)
    agroup = groups_for_endpoints(actual)
    net_changes: list[dict[str, Any]] = []
    for endpoint in sorted(set(egroup) | set(agroup)):
        if egroup.get(endpoint) != agroup.get(endpoint):
            net_changes.append({
                "endpoint": endpoint,
                "expected_connected_to": list(egroup.get(endpoint, ())),
                "actual_connected_to": list(agroup.get(endpoint, ())),
            })
    ename = {member: net for net, members in expected.groups.items() for member in members}
    aname = {member: net for net, members in actual.groups.items() for member in members}
    renamed: list[dict[str, str]] = []
    for endpoint in sorted(set(ename) & set(aname)):
        if ename[endpoint] != aname[endpoint] and egroup.get(endpoint) == agroup.get(endpoint):
            renamed.append({"endpoint": endpoint, "expected": ename[endpoint], "actual": aname[endpoint]})
    # Fold names per original/actual net pair for less noisy reporting.
    renamed = [r for i, r in enumerate(renamed)
               if not any((x["expected"], x["actual"]) == (r["expected"], r["actual"]) for x in renamed[:i])]
    differences = {
        "missing_devices": sorted(ekeys - akeys),
        "extra_devices": sorted(akeys - ekeys),
        "modified_devices": changed,
        "modified_hierarchy_calls": changed_calls,
        "changed_nets": net_changes,
        "root_pin_order": [] if expected.ports == actual.ports else [{"expected": expected.ports, "actual": actual.ports}],
        "renamed_nets": renamed,
    }
    failing = sum(bool(v) for k, v in differences.items() if k != "renamed_nets")
    if strict_names and renamed:
        failing += 1
    return {
        "status": "PASS" if not failing else "FAIL",
        "mode": "strict-net-names" if strict_names else "connectivity-equivalent",
        "counts": {
            "expected_devices": len(expected.devices), "actual_devices": len(actual.devices),
            "expected_hierarchy_calls": len(expected.calls), "actual_hierarchy_calls": len(actual.calls),
            "different_categories": failing,
        },
        "differences": differences,
        "limitations": [
            "Connectivity uses instance path + terminal position; master pin order must be consistent.",
            "Expressions, inherited symbolic parameters and PDK CDF evaluations are not calculated by this parser.",
            "External include/model directives are not expanded; run Spectre netlister and verify PDK/corner separately.",
        ],
    }


def summarize_delta(before: Expanded, after: Expanded) -> dict[str, Any]:
    bk, ak = set(before.devices), set(after.devices)
    before_nodes = {member: net for net, members in before.groups.items() for member in members}
    after_nodes = {member: net for net, members in after.groups.items() for member in members}
    rewired = [endpoint for endpoint in sorted(set(before_nodes) & set(after_nodes))
               if "#" in endpoint and before_nodes[endpoint] != after_nodes[endpoint]]
    return {
        "added": sorted(ak - bk), "deleted": sorted(bk - ak),
        "replaced_masters": [p for p in sorted(bk & ak) if before.devices[p].master != after.devices[p].master],
        "modified_parameters": [p for p in sorted(bk & ak) if before.devices[p].params != after.devices[p].params],
        "reconnected_existing_terminals": rewired,
    }


def render_text(report: dict[str, Any]) -> str:
    lines = [f"RESULT: {report['status']}", f"MODE: {report['mode']}", f"COUNTS: {json.dumps(report['counts'], ensure_ascii=False)}"]
    for name, records in report["differences"].items():
        lines.append(f"\n{name} ({len(records)}):")
        for item in records[:100]:
            lines.append("  " + json.dumps(item, ensure_ascii=False, sort_keys=True))
        if len(records) > 100:
            lines.append(f"  ... {len(records) - 100} more, see JSON")
    if "planned_transform" in report:
        lines.append("\nExpected before->after changes:")
        lines.append(json.dumps(report["planned_transform"], indent=2, ensure_ascii=False))
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Compare hierarchical Spectre core netlists by flattened instance paths and electrical connectivity")
    p.add_argument("--expected", type=Path, required=True)
    p.add_argument("--actual", type=Path, required=True)
    p.add_argument("--before", type=Path, help="Optional before netlist for transformation delta")
    p.add_argument("--top-expected", required=True)
    p.add_argument("--top-actual", required=True)
    p.add_argument("--top-before")
    p.add_argument("--json-out", type=Path)
    p.add_argument("--text-out", type=Path)
    p.add_argument("--strict-net-names", action="store_true")
    p.add_argument("--leaf-catalog", type=Path,
                   help="Validated PDK leaf-model JSON; REQUIRED for trusted/release verification")
    args = p.parse_args(argv)
    try:
        leaf_masters = None
        if args.leaf_catalog:
            # Import here to keep the pure parser independent of plan files.
            from plan_expected_precheck import load_catalog
            _, leaf_masters = load_catalog(args.leaf_catalog)
        ep = parse_netlist(args.expected)
        ap = parse_netlist(args.actual)
        expected = expand(ep, args.top_expected, leaf_masters=leaf_masters)
        actual = expand(ap, args.top_actual, leaf_masters=leaf_masters)
        report = compare_expanded(expected, actual, args.strict_net_names)
        report["verification_catalog"] = str(args.leaf_catalog) if args.leaf_catalog else None
        report["trusted_release_gate"] = bool(args.leaf_catalog)
        report["sources"] = {
            "expected": str(args.expected), "actual": str(args.actual),
            "expected_top": args.top_expected, "actual_top": args.top_actual,
        }
        report["skipped_top_statements"] = {
            "expected": ep.top_statements_skipped, "actual": ap.top_statements_skipped,
        }
        if args.before:
            before = expand(parse_netlist(args.before), args.top_before or args.top_expected,
                            leaf_masters=leaf_masters)
            report["planned_transform"] = summarize_delta(before, expected)
        text_output = render_text(report)
        if args.json_out:
            args.json_out.parent.mkdir(parents=True, exist_ok=True)
            args.json_out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        if args.text_out:
            args.text_out.parent.mkdir(parents=True, exist_ok=True)
            args.text_out.write_text(text_output, encoding="utf-8")
        print(text_output, end="")
        return 0 if report["status"] == "PASS" else 1
    except (NetlistError, OSError, UnicodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
