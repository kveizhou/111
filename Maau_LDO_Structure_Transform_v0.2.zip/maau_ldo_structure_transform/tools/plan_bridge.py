#!/usr/bin/env python3
"""Validate Maau normalized materialization plan v2, serialize as SKILL data.

Intentionally NO eval()/SKILL JSON parser. All strings are escaped, data
can be loaded with load("plan.il") in Virtuoso IC6.1.8.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from typing import Any


class ContractError(ValueError):
    pass


RE_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.$<>!\[\]:-]*$")
# Conservative Spectre/schematic net labels; spaces, quotes and SKILL delimiters
# are forbidden in the generic adapter. Extend through a reviewed PDK adapter.
RE_NET = re.compile(r"^[a-zA-Z0-9_.$<>!\[\]:/\-]+$")


def need(obj: dict, key: str, cls: type, location: str) -> Any:
    value = obj.get(key)
    if not isinstance(value, cls):
        raise ContractError(f"{location}.{key}: expected {cls.__name__}")
    return value


def validate_name(name: str, where: str):
    if not RE_NAME.fullmatch(name):
        raise ContractError(f"Unsafe/unsupported OA identifier {where}: {name!r}")


def validate_ref(obj: Any, where: str):
    if not isinstance(obj, dict):
        raise ContractError(f"{where}: expected object")
    for key in ("lib", "cell"):
        validate_name(need(obj, key, str, where), where + "." + key)
    for key in ("view", "symbol_view"):
        if key in obj:
            validate_name(need(obj, key, str, where), where + "." + key)


def validate_plan(data: Any) -> dict:
    if not isinstance(data, dict):
        raise ContractError("Top-level JSON must be an object")
    permitted = {"schema_version", "job_id", "top_path", "clone_on_write", "operations", "allow_interface_change"}
    if set(data) - permitted:
        raise ContractError(f"Unsupported plan fields: {sorted(set(data) - permitted)}")
    if data.get("schema_version") != 2:
        raise ContractError("schema_version must equal 2")
    if data.get("top_path") != "/":
        raise ContractError("top_path must be root '/' in this engine")
    job = need(data, "job_id", str, "plan")
    validate_name(job, "job_id")
    entries = need(data, "clone_on_write", list, "plan")
    if not entries:
        raise ContractError("clone_on_write must not be empty")
    by_path: dict[str, dict] = {}
    targets: set[tuple[str, str]] = set()
    for i, entry in enumerate(entries):
        w = f"clone_on_write[{i}]"
        if not isinstance(entry, dict):
            raise ContractError(f"{w} must be an object")
        path = need(entry, "path", str, w)
        if path in by_path:
            raise ContractError(f"Duplicate clone path: {path}")
        if path != "/":
            if not path.startswith("/") or path.endswith("/") or "//" in path:
                raise ContractError(f"Bad absolute hierarchy path {path}")
            for part in path.strip("/").split("/"):
                validate_name(part, path)
        source = need(entry, "source", dict, w)
        target = need(entry, "target", dict, w)
        validate_ref(source, w + ".source")
        validate_ref(target, w + ".target")
        if (source["lib"], source["cell"]) == (target["lib"], target["cell"]):
            raise ContractError(f"SOURCE MUTATION HAZARD: source and target identical at {path}")
        pair = (target["lib"], target["cell"])
        if pair in targets:
            raise ContractError(f"Targets must be unique per path: {pair}")
        targets.add(pair)
        if (source.get("view", "schematic") != "schematic" or
                target.get("view", "schematic") != "schematic"):
            raise ContractError("Engine only clones schematic view named 'schematic'")
        if (source.get("symbol_view", "symbol") != "symbol" or
                target.get("symbol_view", "symbol") != "symbol"):
            raise ContractError("Engine only clones symbol view named 'symbol'")
        if path == "/":
            if entry.get("parent_path") is not None or entry.get("parent_instance") is not None:
                raise ContractError("root must have no parent")
        else:
            pp = need(entry, "parent_path", str, w)
            pi = need(entry, "parent_instance", str, w)
            validate_name(pi, w + ".parent_instance")
            expected_pp = path.rsplit("/", 1)[0] or "/"
            if pp != expected_pp or pi != path.rsplit("/", 1)[1]:
                raise ContractError(f"Broken parent rebinding contract at {path}: expected {expected_pp}/{pi}")
        by_path[path] = entry
    if "/" not in by_path:
        raise ContractError("Missing root clone mapping /")
    for path, entry in by_path.items():
        if path != "/" and entry["parent_path"] not in by_path:
            raise ContractError(f"Missing cloned ancestor of {path}")
    operations = need(data, "operations", list, "plan")
    if not operations:
        raise ContractError("At least one edit operation is required")
    seen_operations: set[str] = set()
    for idx, op in enumerate(operations):
        w = f"operations[{idx}]"
        if not isinstance(op, dict):
            raise ContractError(f"{w}: expected object")
        allowed_keys = {
            "path", "delete_instances", "create_instances", "preserve_anchors",
            "create_direct_wires", "create_wires", "create_ports",
        }
        unknown_keys = set(op) - allowed_keys
        if unknown_keys:
            raise ContractError(f"{w}: unsupported OA edit actions: {sorted(unknown_keys)}")
        path = need(op, "path", str, w)
        if path not in by_path:
            raise ContractError(f"{w}.path {path} has no clone mapping")
        if path in seen_operations:
            raise ContractError(f"Duplicate operations block for {path}")
        seen_operations.add(path)
        delete_names = need(op, "delete_instances", list, w)
        for name in delete_names:
            if not isinstance(name, str):
                raise ContractError("delete_instances must contain instance-name strings")
            validate_name(name, w + ".delete_instances")
        if len(set(delete_names)) != len(delete_names):
            raise ContractError(f"Duplicate instance deletion in {w}")
        creates = need(op, "create_instances", list, w)
        names = set()
        for j, item in enumerate(creates):
            loc = f"{w}.create_instances[{j}]"
            if not isinstance(item, dict):
                raise ContractError(f"{loc}: expected object")
            name = need(item, "name", str, loc)
            validate_name(name, loc + ".name")
            if name in names:
                raise ContractError(f"Duplicate new instance {name} in {w}")
            names.add(name)
            validate_ref(need(item, "master", dict, loc), loc + ".master")
            xy = need(item, "xy", list, loc)
            if len(xy) != 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in xy):
                raise ContractError(f"{loc}.xy must be 2 finite numbers")
            need(item, "orient", str, loc)
            if item["orient"] not in {"R0", "R90", "R180", "R270", "MX", "MY", "MXR90", "MYR90"}:
                raise ContractError(f"{loc}.orient not supported")
            params = need(item, "params", dict, loc)
            for pn, pv in params.items():
                validate_name(pn, loc + ".params key")
                if not isinstance(pv, dict) or pv.get("type") not in ("string", "float", "int", "boolean") or "value" not in pv:
                    raise ContractError(f"{loc}.params.{pn} must have type and value")
                allowed_types = {"string": str, "float": (float, int), "int": int, "boolean": bool}
                kind = pv["type"]
                val = pv["value"]
                if kind == "int" and type(val) is not int:
                    raise ContractError(f"{loc}.params.{pn} type/value mismatch")
                if kind == "boolean" and type(val) is not bool:
                    raise ContractError(f"{loc}.params.{pn} type/value mismatch")
                if kind == "float" and (type(val) not in (int, float) or not math.isfinite(val)):
                    raise ContractError(f"{loc}.params.{pn} type/value mismatch")
                if kind == "string" and not isinstance(val, str):
                    raise ContractError(f"{loc}.params.{pn} type/value mismatch")
            term_nets = need(item, "terminal_nets", dict, loc)
            if not term_nets:
                raise ContractError(f"{loc}.terminal_nets is required for verification")
            for t, n in term_nets.items():
                validate_name(t, loc + ".terminal")
                if not isinstance(n, str) or not n or not RE_NET.fullmatch(n):
                    raise ContractError(f"{loc} terminal {t} missing/unsafe net: {n!r}")
            # For generic default adapter, all external nets get labelled
            # stubs. An explicit terminal_offset can guide schematic spacing.
            if "terminal_offset" in item:
                off = item["terminal_offset"]
                if not isinstance(off, list) or len(off) != 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in off):
                    raise ContractError(f"{loc}.terminal_offset must be two numbers")
        for key in ("preserve_anchors", "create_direct_wires", "create_wires", "create_ports"):
            if not isinstance(op.get(key), list):
                raise ContractError(f"{w}.{key} must be a list")
        for anchor in op["preserve_anchors"]:
            if not isinstance(anchor, dict):
                raise ContractError(f"{w}.preserve_anchors must be objects")
            if anchor.get("instance") not in delete_names:
                raise ContractError("Anchors must refer to a deleted instance")
            if (not isinstance(anchor.get("terminal"), str) or
                not isinstance(anchor.get("expected_net"), str) or
                not RE_NET.fullmatch(anchor["expected_net"])):
                raise ContractError("Anchors need a valid terminal and expected_net")
            off = anchor.get("offset")
            if not isinstance(off, list) or len(off) != 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in off):
                raise ContractError("Anchor offset must be two numbers")
        created_by_name = {item["name"]: item for item in creates}
        for direct in op["create_direct_wires"]:
            if not isinstance(direct, dict) or not all(k in direct for k in ("a", "b", "net")):
                raise ContractError(f"{w}.create_direct_wires must have a,b,net")
            if not isinstance(direct["net"], str) or not RE_NET.fullmatch(direct["net"]):
                raise ContractError(f"{w}.create_direct_wires.net must be a valid net name")
            for k in ("a", "b"):
                end = direct[k]
                if not isinstance(end, dict) or not isinstance(end.get("instance"), str) or not isinstance(end.get("terminal"), str):
                    raise ContractError(f"{w}.create_direct_wires.{k} must be instance/terminal")
                # Unchanged existing instances cannot be safely wired by name
                # without a resolved OA terminal and a corresponding net contract.
                if end["instance"] not in created_by_name:
                    raise ContractError(f"{w}.create_direct_wires.{k} refers to an instance not recreated in plan")
                expected_net = created_by_name[end["instance"]]["terminal_nets"].get(end["terminal"])
                if expected_net != direct["net"]:
                    raise ContractError(f"{w}.create_direct_wires {end['instance']}.{end['terminal']} has "
                                        f"{expected_net!r}, but direct wire says {direct['net']!r}")
        for wire in op["create_wires"]:
            if not isinstance(wire, dict) or not isinstance(wire.get("points"), list) or len(wire["points"]) < 2:
                raise ContractError(f"{w}.create_wires points requires >=2 points")
            for pt in wire["points"]:
                if not isinstance(pt, list) or len(pt) != 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in pt):
                    raise ContractError("Bad wire point")
            if not isinstance(wire.get("net"), str) or not RE_NET.fullmatch(wire["net"]):
                raise ContractError(f"{w}.create_wires net missing or invalid")
        for port in op["create_ports"]:
            if not isinstance(port, dict) or not isinstance(port.get("name"), str) or port.get("direction") not in ("input", "output", "inputOutput") or not isinstance(port.get("xy"), list) or len(port["xy"]) != 2 or any(type(v) not in (int, float) or not math.isfinite(v) for v in port["xy"]):
                raise ContractError(f"{w}.create_ports requires name,direction,xy")
        # Crucial interface invariant: intermediate schematic ports require
        # accompanying symbol modification; default engine prohibits them.
        if op["create_ports"] and path != "/" and not data.get("allow_interface_change", False):
            raise ContractError(f"{w}: child ports changed without explicit allow_interface_change (needs symbol regeneration)")
    if data.get("allow_interface_change", False):
        raise ContractError("Interface-changing plans require a custom symbol/port adapter and are blocked in this reference engine")
    return data


def skill_string(s: str) -> str:
    # Data is embedded as escaped SKILL string literals (never as source code).
    # Reject embedded control chars; pass UTF-8 through unchanged for names
    # explicitly supported by the target site's IC6.1.8 process encoding.
    if any(ord(c) < 32 and c not in "\t\n" for c in s):
        raise ContractError("Control character in SKILL string")
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t') + '"'


def to_skill(value: Any) -> str:
    if value is None or value is False:
        return "nil"
    if value is True:
        return "t"
    if isinstance(value, str):
        return skill_string(value)
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            raise ContractError("Non-finite numeric value is forbidden")
        return repr(value)
    if isinstance(value, list):
        return "list(" + " ".join(map(to_skill, value)) + ")" if value else "nil"
    if isinstance(value, dict):
        return "list(" + " ".join(f"list({skill_string(k)} {to_skill(v)})" for k, v in value.items()) + ")" if value else "nil"
    raise ContractError(f"Unsupported JSON type: {type(value)}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Maau OA normalized plan JSON -> SKILL data file (with contract checks)")
    ap.add_argument("--plan", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args(argv)
    try:
        raw = args.plan.read_bytes()
        plan = validate_plan(json.loads(raw))
        sha = hashlib.sha256(raw).hexdigest()
        body = "; Auto-generated by plan_bridge.py. Load as DATA, never eval untrusted SKILL code.\n"
        body += f"; input SHA256: {sha}\n"
        body += f"maauPlan = {to_skill(plan)}\n"
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(body, encoding="utf-8")
        print(f"OK plan contract: {len(plan['clone_on_write'])} clone paths, {len(plan['operations'])} edits\nWrote {args.out}\nSHA256 {sha}")
        return 0
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print("PLAN ERROR:", exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
