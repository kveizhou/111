#!/usr/bin/env python3
"""Read hierarchy-local geometry TSV and suggest an R0 placement origin.

This solves rectangle (instance bbox) spacing only; it CANNOT guarantee
schematic wire/label clearance or electrically correct routing.
"""
import argparse
import csv
import json
from pathlib import Path
import sys


def snap(v: float, grid: float) -> float:
    return round(v / grid) * grid


def conflict(a, b, halo):
    return not (a[2] + halo <= b[0] or b[2] + halo <= a[0] or
                a[3] + halo <= b[1] or b[3] + halo <= a[1])


def main() -> int:
    p = argparse.ArgumentParser(description="Suggest nonoverlapping local schematic XY using hierarchy geometry snapshot")
    p.add_argument('--geometry', type=Path, required=True)
    p.add_argument('--hierarchy-path', required=True, help='e.g. /ldo/ldo_ls/l12 (cell owning M1)')
    p.add_argument('--reference-inst', required=True)
    p.add_argument('--master-bbox', nargs=4, type=float, required=True,
                   metavar=('LLX','LLY','URX','URY'), help='new SYMBOL master bbox relative to its origin (R0)')
    p.add_argument('--grid', type=float, default=0.0625)
    p.add_argument('--clearance', type=float, default=1.0)
    a = p.parse_args()
    if a.grid <= 0 or a.clearance < 0:
        p.error('grid > 0 and clearance >= 0 required')
    records = {}
    try:
        with a.geometry.open(newline='', encoding='utf-8') as fp:
            for r in csv.DictReader(fp, delimiter='\t'):
                if r['hierarchy_path'] != a.hierarchy_path:
                    continue
                name = r['instance']
                records[name] = (float(r['bbox_llx']), float(r['bbox_lly']),
                                 float(r['bbox_urx']), float(r['bbox_ury']))
    except (OSError, ValueError, KeyError) as e:
        print('Geometry read ERROR:', e, file=sys.stderr)
        return 2
    if a.reference_inst not in records:
        print(f'ERROR: instance {a.reference_inst!r} not found at {a.hierarchy_path}. Available: {list(records)}', file=sys.stderr)
        return 2
    mb = a.master_bbox
    if mb[2] <= mb[0] or mb[3] <= mb[1]:
        print('ERROR: invalid master bbox', file=sys.stderr)
        return 2
    ref = records[a.reference_inst]
    center_y = (ref[1] + ref[3]) / 2.0
    max_right = max(b[2] for b in records.values())
    x = snap(max_right + a.clearance - mb[0] + a.grid, a.grid)
    y = snap(center_y - (mb[1]+mb[3])/2.0, a.grid)
    for attempt in range(1000):
        bbox = [x+mb[0], y+mb[1], x+mb[2], y+mb[3]]
        if not any(conflict(bbox, obstacle, a.clearance) for obstacle in records.values()):
            print(json.dumps({
                'origin_xy_R0': [round(x, 6), round(y, 6)],
                'bbox': [round(v, 6) for v in bbox],
                'same_cell_hierarchy_path': a.hierarchy_path,
                'assumptions': ['R0 orientation', 'bbox only; wires/pins/labels not checked', 'local schematic coordinates']
            }, indent=2))
            return 0
        y += 2*a.clearance + (mb[3]-mb[1]) + a.grid
        y = snap(y, a.grid)
    print('No placement found after 1000 candidates', file=sys.stderr)
    return 1


if __name__ == '__main__':
    sys.exit(main())
