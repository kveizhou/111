#!/usr/bin/env python3
"""Offline plan / expected-netlist consistency check BEFORE touching OpenAccess.

This does NOT replace OA read-back verification. A catalog maps symbol terminal
names to Spectre positional pin order, and PDK masters to netlisted device names.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from netlist_compare import NetlistError, expand, norm_value, parse_netlist
from plan_bridge import ContractError, validate_plan


class PlanExpectationError(ValueError):
    pass


def load_catalog(path: Path) -> tuple[dict[tuple[str, str, str], dict], set[str]]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if obj.get("schema_version") != 1 or not isinstance(obj.get("masters"), list):
        raise PlanExpectationError("Catalog must have schema_version=1 and masters[]")
    lookup: dict[tuple[str, str, str], dict] = {}
    leaf_models: set[str] = set()
    for i, entry in enumerate(obj["masters"]):
        try:
            key = (entry["lib"], entry["cell"], entry.get("view", "symbol"))
            model = entry["spectre_master"]
            terminals = entry["terminal_order"]
            param_map = entry.get("cdf_to_spectre_params", {})
        except (KeyError, TypeError) as exc:
            raise PlanExpectationError(f"Bad catalog entry {i}: {exc}") from exc
        if (not all(isinstance(x, str) and x for x in key + (model,))
                or not isinstance(terminals, list) or not terminals
                or not all(isinstance(x, str) and x for x in terminals)
                or len(set(terminals)) != len(terminals)
                or not isinstance(param_map, dict)):
            raise PlanExpectationError(f"Bad catalog fields for {key}")
        if key in lookup:
            raise PlanExpectationError(f"Duplicate catalog master: {key}")
        lookup[key] = entry
        leaf_models.add(model)
    extras = obj.get("additional_leaf_masters", [])
    if not isinstance(extras, list) or not all(isinstance(x, str) and x for x in extras):
        raise PlanExpectationError("additional_leaf_masters must be strings")
    leaf_models.update(extras)
    if not leaf_models:
        raise PlanExpectationError("No leaf masters in catalog; refusing to verify")
    return lookup, leaf_models


def check_consistency(plan: dict, before: Any, expected: Any, catalog: dict) -> dict:
    errors: list[str] = []
    checked: list[str] = []
    if before.ports != expected.ports:
        errors.append("top-level interface changed; this engine does not support interface changes")

    covered: set[str] = set()
    deleted: set[str] = set()
    for op in plan["operations"]:
        owner = op["path"].strip("/")
        qualify = lambda name: (owner + "/" if owner else "") + name
        new_names = {item["name"] for item in op["create_instances"]}
        old_names = set(op["delete_instances"])
        for name in old_names:
            path = qualify(name)
            deleted.add(path)
            if path not in before.devices:
                errors.append(f"{path}: delete target absent from before netlist")
            if path in expected.devices and name not in new_names:
                errors.append(f"{path}: expected still contains deleted instance but plan does not rebuild it")
        for item in op["create_instances"]:
            path = qualify(item["name"])
            covered.add(path)
            if path in before.devices and item["name"] not in old_names:
                errors.append(f"{path}: editing an existing instance requires explicit delete/recreate")
            model_ref = item["master"]
            key = (model_ref["lib"], model_ref["cell"], model_ref.get("view", "symbol"))
            meta = catalog.get(key)
            if meta is None:
                errors.append(f"{path}: device master not in PDK catalog: {key}")
                continue
            actual = expected.devices.get(path)
            if actual is None:
                errors.append(f"{path}: plan creates device but core_expected has no such instance")
                continue
            if actual.master != meta["spectre_master"]:
                errors.append(f"{path}: expected Spectre master {actual.master!r} != catalog {meta['spectre_master']!r}")
            order = meta["terminal_order"]
            net_map = item["terminal_nets"]
            if set(order) != set(net_map):
                errors.append(f"{path}: terminal keys differ from PDK catalog: {sorted(set(order)^set(net_map))}")
                continue
            expected_nodes = expected.device_node_names[path]
            planned_nodes = tuple(net_map[term] for term in order)
            if tuple(expected_nodes) != planned_nodes:
                errors.append(f"{path}: terminal nets expected {expected_nodes} != planned {planned_nodes}; order={order}")
            netlist_params = dict(actual.params)
            for cdf_param, spec in item["params"].items():
                spectre_param = meta.get("cdf_to_spectre_params", {}).get(cdf_param)
                if spectre_param:
                    expected_val = netlist_params.get(spectre_param)
                    declared_val = norm_value(str(spec["value"]))
                    if expected_val != declared_val:
                        errors.append(f"{path}: CDF {cdf_param}={spec['value']} maps to {spectre_param}, "
                                      f"but expected netlist value is {expected_val}")
            checked.append(path)

        for anchor in op["preserve_anchors"]:
            path = qualify(anchor["instance"])
            old_device = before.devices.get(path)
            if old_device is None:
                continue
            catalog_candidates = [e for e in catalog.values()
                                  if e["spectre_master"] == old_device.master]
            matches = [e for e in catalog_candidates if anchor["terminal"] in e["terminal_order"]]
            if len(matches) == 1:
                loc = matches[0]["terminal_order"].index(anchor["terminal"])
                old_node = before.device_node_names[path][loc]
                if old_node != anchor["expected_net"]:
                    errors.append(f"{path}.{anchor['terminal']}: preserve_anchors net {anchor['expected_net']} "
                                  f"!= before net {old_node}")
            elif len(matches) > 1:
                signatures = {tuple(e["terminal_order"]) for e in matches}
                if len(signatures) > 1:
                    errors.append(f"{path}: ambiguous PDK terminal order for old master {old_device.master}")
            else:
                errors.append(f"{path}: before master {old_device.master} not covered by catalog")

    bpaths = set(before.devices)
    epaths = set(expected.devices)
    for path in sorted(epaths - bpaths):
        if path not in covered:
            errors.append(f"{path}: expected adds a device absent from plan")
    for path in sorted(bpaths - epaths):
        if path not in deleted:
            errors.append(f"{path}: expected removes a device absent from plan")
    for path in sorted(epaths & bpaths):
        b, e = before.devices[path], expected.devices[path]
        if (b.master, b.params) != (e.master, e.params) and path not in covered:
            errors.append(f"{path}: expected changes master/parameters but plan does not rebuild it")

    return {
        "status": "PASS" if not errors else "FAIL",
        "checked_created_instances": checked,
        "count_checked": len(checked),
        "issues": errors,
        "note": "This checks plan-to-C++ consistency only; it has NOT created or verified OA views."
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Compare a v2 clone plan against C++ expected Spectre connectivity using PDK pin-order catalog")
    p.add_argument("--plan", type=Path, required=True)
    p.add_argument("--catalog", type=Path, required=True)
    p.add_argument("--before", type=Path, required=True)
    p.add_argument("--expected", type=Path, required=True)
    p.add_argument("--top-before", default="LDO_TOP")
    p.add_argument("--top-expected", default="LDO_TOP")
    p.add_argument("--json-out", type=Path)
    args = p.parse_args(argv)
    try:
        plan = validate_plan(json.loads(args.plan.read_text(encoding="utf-8")))
        catalog, leaf = load_catalog(args.catalog)
        before = expand(parse_netlist(args.before), args.top_before, leaf_masters=leaf)
        expected = expand(parse_netlist(args.expected), args.top_expected, leaf_masters=leaf)
        result = check_consistency(plan, before, expected, catalog)
        if args.json_out:
            args.json_out.parent.mkdir(parents=True, exist_ok=True)
            args.json_out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"PLAN EXPECTED CHECK: {result['status']} ({result['count_checked']} instances)")
        for issue in result["issues"]:
            print("  ISSUE:", issue)
        return 0 if result["status"] == "PASS" else 1
    except (OSError, ValueError, ContractError, NetlistError) as exc:
        print(f"PLAN EXPECTED ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
