; =============================================================================
; st_multi_level_materializer.il
; 多层级 clone-on-write OA 物化引擎（适配 C++ OaMaterializationPlan v3 JSON）。
;
; 由 materialize.il 经 stBackendRequiredEnv("ST_REQ_MATERIALIZER_SKILL") 加载，
; 必须定义 StTopologyVariantMaterialize(planPath)。plan 由 st_init.il 的
; StTopologyParseJsonFile 从 stPreparedJsonData 读出（C++ JsonWriter 输出）。
;
; v3 plan 结构（C++ OaPlan.h / JsonWriter.cpp）：
;   { schema_version: 3,
;     source/target: {library,cell,view,storage_path,revision},
;     clone_on_write: [ {source, target, hierarchy_path,
;                        parent_hierarchy_path, parent_instance_name} ],
;     generated_cells: [ ... ],
;     delete_instances: [ {hierarchy_path, name} ],
;     create_instances: [ {hierarchy_path, name, master, location,
;                          orientation, expected_terminal_count,
;                          connections:[{semantic_terminal,pdk_terminal,net}],
;                          cdf_parameter_list:[{name,value}],
;                          copy_properties_from, allowed_extra_cdf_parameters} ],
;     create_ports: [ {hierarchy_path,name,direction,net,location} ],
;     direct_wires: [ {hierarchy_path,net,from_instance,from_terminal,
;                      to_instance,to_terminal} ],
;     wires: [ {hierarchy_path,net,points} ],
;     check_and_save: true, preview: {...}, topology_hash: "..." }
;
; PDK/site 特异部分复用 opt_algo 的 st_pdk_adapter.il（StTopology* 与
; MaauTopology* adapter）。若某 adapter 未由 st_pdk_adapter 提供，宿主必须
; 另行加载，禁止用 return t 代替。
; =============================================================================

procedure(stMlGet(obj key)
  let((pair)
    cond(
      (tablep(obj) obj[key])
      (listp(obj)
        pair = assoc(key obj)
        if(pair then cadr(pair) else nil)
      )
      (t nil)
    )
  )
)

procedure(stMlFindInst(cv name)
  let((hit inst)
    hit = nil
    foreach(inst cv~>instances
      when(equal(inst~>name name) hit = inst)
    )
    hit
  )
)

procedure(stMlFindEntryByPath(entries path)
  let((found entry)
    found = nil
    foreach(entry entries
      when(equal(stMlGet(entry "hierarchy_path") path) found = entry)
    )
    found
  )
)

procedure(stMlDepth(path)
  if(equal(path "/") then 0 else length(parseString(path "/")))
)

procedure(stMlOpenTarget(entry)
  let((target cv)
    target = stMlGet(entry "target")
    cv = dbOpenCellViewByType(stMlGet(target "library") stMlGet(target "cell")
                              stMlGet(target "view") "" "a")
    unless(cv error("ST_ML: cannot open cloned target %s/%s\n"
                    stMlGet(target "library") stMlGet(target "cell")))
    cv
  )
)

procedure(stMlCopySourceToClone(entry)
  let((source target srccv dstcv srcsym dstsym srcCell dstCell srcCDF dstCDF)
    source = stMlGet(entry "source")
    target = stMlGet(entry "target")
    srccv = dbOpenCellViewByType(stMlGet(source "library") stMlGet(source "cell")
                                 stMlGet(source "view") "" "r")
    unless(srccv error("ST_ML: no readable source schematic %L\n" source))
    dstcv = dbCopyCellView(srccv stMlGet(target "library") stMlGet(target "cell")
                           stMlGet(target "view") nil nil nil)
    unless(dstcv error("ST_ML: clone schematic failed %L\n" target))
    dbSave(dstcv)
    dbClose(dstcv)
    dbClose(srccv)
    ; 子模块克隆必须复制配套 symbol，父级实例 ~>master 引用的是 symbol。
    ; 但同 lib/cell + 新 view 模式下 symbol 已存在于同一 cell, 无需复制。
    unless(and(equal(stMlGet(source "library") stMlGet(target "library"))
               equal(stMlGet(source "cell") stMlGet(target "cell")))
      srcsym = dbOpenCellViewByType(stMlGet(source "library") stMlGet(source "cell")
                                    "symbol" "schematicSymbol" "r")
      when(srcsym
        dstsym = dbCopyCellView(srcsym stMlGet(target "library") stMlGet(target "cell")
                                "symbol" nil nil nil)
        unless(dstsym error("ST_ML: symbol clone failed %L\n" target))
        dbSave(dstsym)
        dbClose(dstsym)
        dbClose(srcsym)
      )
    )
    ; cell 级 CDF 不是 cellview 属性，需显式复制。
    ; 但同 lib/cell + 新 view 模式下源与目标共享同一 cell, CDF 已存在, 跳过。
    srcCell = ddGetObj(stMlGet(source "library") stMlGet(source "cell"))
    dstCell = ddGetObj(stMlGet(target "library") stMlGet(target "cell"))
    unless(dstCell error("ST_ML: cloned cell missing ddObj\n"))
    ; 源 cell 与目标 cell 为同一 ddObj 时无需复制 CDF。
    unless(equal(srcCell dstCell)
      srcCDF = cdfGetBaseCellCDF(srcCell)
      when(srcCDF
        when(cdfGetBaseCellCDF(dstCell)
          error("ST_ML: destination unexpectedly has CDF; refusing overwrite\n")
        )
        dstCDF = cdfCopyCDF(dstCell "baseCellData" srcCDF)
        unless(dstCDF error("ST_ML: CDF clone failed %L\n" target))
        unless(cdfSaveCDF(dstCDF) error("ST_ML: CDF save failed\n"))
      )
    )
    printf("ST_ML CLONED: %s -> %s/%s\n" stMlGet(entry "hierarchy_path")
           stMlGet(target "library") stMlGet(target "cell"))
    t
  )
)

procedure(stMlValidatePinCompatibility(oldSym newSym)
  let((other oldPin newPin oldFig newFig term)
    unless(equal(length(oldSym~>terminals) length(newSym~>terminals))
      error("ST_ML: remaster symbol has different terminal count\n")
    )
    foreach(term oldSym~>terminals
      other = dbFindTermByName(newSym term~>name)
      unless(other error("ST_ML: remaster symbol lost port %s\n" term~>name))
      oldPin = car(term~>pins)
      newPin = car(other~>pins)
      unless(and(oldPin newPin) error("ST_ML: missing symbol pin %s\n" term~>name))
      oldFig = oldPin~>fig
      unless(oldFig oldFig = car(oldPin~>figs))
      newFig = newPin~>fig
      unless(newFig newFig = car(newPin~>figs))
      unless(and(oldFig newFig) error("ST_ML: missing symbol pin figure %s\n" term~>name))
      unless(equal(centerBox(oldFig~>bBox) centerBox(newFig~>bBox))
        error("ST_ML: symbol port %s changed location; parent remaster unsafe\n" term~>name)
      )
    )
    t
  )
)

procedure(stMlRebindChild(cv childEntry)
  let((source target inst oldSym newSym childName)
    source = stMlGet(childEntry "source")
    target = stMlGet(childEntry "target")
    childName = stMlGet(childEntry "parent_instance_name")
    inst = stMlFindInst(cv childName)
    unless(inst error("ST_ML: parent %s lacks instance %s\n" cv~>cellName childName))
    unless(equal(inst~>cellName stMlGet(source "cell"))
      error("ST_ML: expected source instance master mismatch at %s/%s\n" cv~>cellName childName)
    )
    oldSym = inst~>master
    newSym = dbOpenCellViewByType(stMlGet(target "library") stMlGet(target "cell")
                                  "symbol" "schematicSymbol" "r")
    unless(newSym error("ST_ML: no cloned symbol for child %s\n" childName))
    stMlValidatePinCompatibility(oldSym newSym)
    inst~>master = newSym
    ; 同 lib/cell + 新 view 模式下, 必须显式设置 viewName 指向子层级变体 view,
    ; 否则层次展开仍会打开原始 schematic 而非克隆的 variant view.
    inst~>viewName = stMlGet(target "view")
    printf("ST_ML REBOUND: parent=%s instance=%s to %s/%s/%s\n"
           cv~>cellName childName stMlGet(target "library")
           stMlGet(target "cell") stMlGet(target "view"))
    ; 父级 check-and-save 前不能关新 symbol。
    newSym
  )
)

procedure(stMlMasterRef(master)
  dbOpenCellViewByType(stMlGet(master "library") stMlGet(master "cell")
                       stMlGet(master "view") "" "r")
)

; 修改原因：封装原 MOS 时保留实际 master/属性和父层外部网络，按端子名连接。
procedure(stMlApplyCreateInstance(cv item @optional offset)
  let((masterCv inst params connection terminalName netName propSource sourceCv sourceInst prop)
    printf("ST_ML_CREATE scope=%s owner=%s/%s/%s instance=%s master=%L\n"
      stMlGet(item "hierarchy_path") cv~>libName cv~>cellName cv~>viewName
      stMlGet(item "name") stMlGet(item "master"))
    propSource = stMlGet(item "copy_properties_from")
    when(propSource
      sourceCv = stMlMasterRef(stMlGet(propSource "cellview"))
      unless(sourceCv error("ST_ML: original property source absent"))
      sourceInst = stMlFindInst(sourceCv stMlGet(propSource "instance"))
      unless(sourceInst error("ST_ML: original instance absent before packaging")))
    ; 修改原因：原 MOS 的库/cell/view 直接来自原图，不能被工艺别名覆盖。
    masterCv = if(sourceInst then sourceInst~>master else stMlMasterRef(stMlGet(item "master")))
    unless(masterCv error("ST_ML: device master missing\n"))
    inst = schCreateInst(cv masterCv stMlGet(item "name")
                         list(car(stMlGet(item "location")) + if(offset then car(offset) else 0.0)
                              cadr(stMlGet(item "location")) + if(offset then cadr(offset) else 0.0))
                         stMlGet(item "orientation")
                         if(stMlGet(item "bit_count") then stMlGet(item "bit_count") else 1))
    unless(inst error("ST_ML: cannot create instance %s\n" stMlGet(item "name")))
    when(sourceInst dbCopyPropList(sourceInst inst))
    ; CDF 参数：v3 用 cdf_parameter_list [{name,value}]，经 adapter 应用并触发回调。
    ; 修改原因：计划只列出新增器件参数或明确变更的尺寸；原管其它属性已经完整复制。
    when(stMlGet(item "cdf_parameter_list")
      StTopologyApplyCdfParameters(inst stMlGet(item "cdf_parameter_list")))
    ; 端子连接：connections [{semantic_terminal,pdk_terminal,net}]
    foreach(connection stMlGet(item "connections")
      printf("ST_ML_CONNECT instance=%s terminal=%s net=%s\n"
        stMlGet(item "name") stMlGet(connection "pdk_terminal") stMlGet(connection "net"))
      MaauTopologyConnectTerminal(cv inst stMlGet(connection "pdk_terminal")
                                  stMlGet(connection "net"))
    )
    if(sourceCv then dbClose(sourceCv) else dbClose(masterCv))
    inst
  )
)

procedure(stMlApplyDeleteInstance(cv item)
  let((inst)
    inst = stMlFindInst(cv stMlGet(item "name"))
    unless(inst error("ST_ML: delete target instance %s not found\n" stMlGet(item "name")))
    dbDeleteObject(inst)
    t
  )
)

procedure(stMlApplyDirectWire(cv item)
  let((fromInst toInst fromTerm toTerm)
    fromInst = stMlFindInst(cv stMlGet(item "from_instance"))
    toInst = stMlFindInst(cv stMlGet(item "to_instance"))
    unless(and(fromInst toInst) error("ST_ML: direct-wire instance missing\n"))
    when(getd('MaauTopologyConnectInstances)
      MaauTopologyConnectInstances(cv fromInst stMlGet(item "from_terminal")
                                   toInst stMlGet(item "to_terminal")
                                   stMlGet(item "net"))
    )
    t
  )
)

procedure(stMlApplyWire(cv item)
  let((points pointList)
    ; v3 wires 的 points 是 [[x,y],...] 局部坐标。逐段画线并打标。
    points = stMlGet(item "points")
    pointList = nil
    foreach(point points
      pointList = cons(list(car(point) cadr(point)) pointList)
    )
    pointList = reverse(pointList)
    when(and(pointList greaterp(length(pointList) 1))
      let((wire labelNet i)
        wire = schCreateWire(cv "draw" "full" pointList 0.0625 0.0625 0.0)
        unless(wire
          error("ST_ML: cannot create wire for net %s\n" stMlGet(item "net"))
        )
        labelNet = stMlGet(item "net")
        schCreateWireLabel(cv car(wire) car(pointList) labelNet
                           "centerCenter" "R0" "stick" 0.0625 nil)
      )
    )
    t
  )
)

procedure(stMlApplyCreatePort(cv item)
  when(getd('StTopologyCreatePort)
    StTopologyCreatePort(cv item)
  )
  t
)

; 修改原因：封装移到空白位置后，给原连线保留网名，避免 schCheck 把 net18 改名造成断接。
procedure(stMlKeepBoundaryNet(cv net deletedNames path)
  let((wire labeled fig label remaining it method point)
    foreach(fig net~>figs
      when(member(fig~>objType list("line" "path" "pathSeg"))
        unless(wire wire = fig)
        foreach(label fig~>children
          when(and(equal(label~>objType "label") equal(label~>theLabel net~>name))
            labeled = t)))
      when(and(equal(fig~>objType "label") equal(fig~>theLabel net~>name)) labeled = t))
    cond(
      (labeled method = "existing_label")
      (wire
        point = if(wire~>points then car(wire~>points) else centerBox(wire~>bBox))
        unless(schCreateWireLabel(cv wire point net~>name
                 "centerCenter" "R0" "stick" 0.0625 nil)
          error("ST_ML: cannot preserve boundary net %s at %s" net~>name path))
        method = "original_wire_label")
      (t
        ; Pins can touch without an intervening wire. Anchor the name on a
        ; surviving instance, not on a label attached to the soon-deleted MOS.
        foreach(it net~>instTerms
          when(and(not(remaining) not(member(it~>inst~>name deletedNames))) remaining = it))
        if(remaining then
          MaauTopologyConnectTerminal(cv remaining~>inst remaining~>term~>name net~>name)
          method = "surviving_pin_label"
        else
          method = "no_remaining_endpoint")))
    printf("ST_ML_PRESERVE_NET scope=%s owner=%s/%s net=%s method=%s\n"
      path cv~>libName cv~>cellName net~>name method)
    t
  )
)

procedure(stMlPreserveBoundaryNets(cv plan path)
  let((deletedNames boundaryNames seen item connection inst it net name)
    foreach(item stMlGet(plan "delete_instances")
      when(equal(stMlGet(item "hierarchy_path") path)
        deletedNames = cons(stMlGet(item "name") deletedNames)))
    when(deletedNames
      foreach(item stMlGet(plan "create_instances")
        when(equal(stMlGet(item "hierarchy_path") path)
          foreach(connection stMlGet(item "connections")
            boundaryNames = cons(stMlGet(connection "net") boundaryNames))))
      ; Capture/label all boundary nets before ANY deletion in this owner.
      foreach(name deletedNames
        inst = stMlFindInst(cv name)
        unless(inst error("ST_ML: cannot preserve missing instance %s at %s" name path))
        foreach(it inst~>instTerms
          net = it~>net
          when(and(net member(net~>name boundaryNames) not(member(net~>name seen)))
            seen = cons(net~>name seen)
            stMlKeepBoundaryNet(cv net deletedNames path)))))
    t
  )
)

; 修改原因：封装保留外部网名并放在原图右侧，不改变上层引用规则。
procedure(stMlApplyOperations(cv plan path)
  let((item offset bbox)
    stMlPreserveBoundaryNets(cv plan path)
    ; 修改原因：父层封装放在原图边界外，不能使用固定坐标压住原来的线和器件。
    when(stMlGet(plan "delete_instances")
      bbox = cv~>bBox
      when(bbox offset = list(car(cadr(bbox)) + 12.0 cadr(cadr(bbox)))))
    foreach(item stMlGet(plan "delete_instances")
      when(equal(stMlGet(item "hierarchy_path") path)
        stMlApplyDeleteInstance(cv item)
      )
    )
    foreach(item stMlGet(plan "create_instances")
      when(equal(stMlGet(item "hierarchy_path") path)
        stMlApplyCreateInstance(cv item offset)
      )
    )
    foreach(item stMlGet(plan "direct_wires")
      when(equal(stMlGet(item "hierarchy_path") path)
        stMlApplyDirectWire(cv item)
      )
    )
    ; placeholder wires 由 FillPlaceholderLocations 生成, 间距过密导致网格
    ; snap 后不同网络短路。stMLApplyCreateInstance 已通过
    ; MaauTopologyConnectTerminal 从实际 pin center 创建连线, 占位导线冗余。
    foreach(item stMlGet(plan "create_ports")
      when(equal(stMlGet(item "hierarchy_path") path)
        stMlApplyCreatePort(cv item)
      )
    )
    t
  )
)

procedure(stMlPreflight(plan)
  let((maps entry path targetLib parent parentSource parentCv childName
       actualInst srcLibObj)
    maps = stMlGet(plan "clone_on_write")
    unless(maps error("ST_ML: plan has no clone_on_write\n"))
    foreach(entry maps
      path = stMlGet(entry "hierarchy_path")
      targetLib = stMlGet(stMlGet(entry "target") "library")
      printf("ST_ML PREFLIGHT ENTRY: path=%s targetLib=%s\n" path targetLib)
      ; 目标 staging 库不存在时自动创建（attach 源库的 tech），
      ; 免去部署时手工建库。cds.lib 需可写（skill_bridge 启动的工作目录）。
      unless(ddGetObj(targetLib)
        unless(getd('ddCreateLib)
          error("ST_ML: ddCreateLib not available in this Virtuoso; "
                "create staging library %s in cds.lib first\n" targetLib))
        srcLibObj = ddGetObj(stMlGet(stMlGet(entry "source") "library"))
        unless(ddCreateLib(targetLib)
          error("ST_ML: cannot create target OA library %s\n" targetLib))
        when(and(srcLibObj getd('ddGetLibProp) getd('ddSetLibProp))
          let((techName)
            techName = ddGetLibProp(srcLibObj "techLibName")
            when(techName
              ddSetLibProp(targetLib "techLibName" techName)
            )
          )
        )
        printf("ST_ML CREATED LIB: %s\n" targetLib)
      )
      ; 修改原因：这里仅预检查，不删除已成功的 view；全部模块检查完成后再重建。
      ; 诊断日志: 打印当前检查的 source lib/cell/view
      printf("ST_ML PREFLIGHT: path=%s source=%s/%s/%s\n" path
             stMlGet(stMlGet(entry "source") "library")
             stMlGet(stMlGet(entry "source") "cell")
             stMlGet(stMlGet(entry "source") "view"))
      unless(ddGetObj(stMlGet(stMlGet(entry "source") "library")
                      stMlGet(stMlGet(entry "source") "cell")
                      stMlGet(stMlGet(entry "source") "view"))
        error("ST_ML: missing source view %s/%s/%s\n"
              stMlGet(stMlGet(entry "source") "library")
              stMlGet(stMlGet(entry "source") "cell")
              stMlGet(stMlGet(entry "source") "view")))
      unless(equal(path "/")
        ; 非根层级必须有已克隆父层级 + 实例重绑定契约。
        parent = stMlFindEntryByPath(maps stMlGet(entry "parent_hierarchy_path"))
        unless(parent error("ST_ML: missing parent clone mapping at %s\n" path))
        childName = stMlGet(entry "parent_instance_name")
        ; 在父级 SOURCE view 中验证子实例存在且 master 匹配。
        ; preflight 在克隆前执行，已有 target view 暂时保留。
        parentSource = stMlGet(parent "source")
        parentCv = dbOpenCellViewByType(stMlGet(parentSource "library")
                         stMlGet(parentSource "cell")
                         stMlGet(parentSource "view") "" "r")
        unless(parentCv error("ST_ML: cannot open parent source at %s\n" path))
        actualInst = stMlFindInst(parentCv childName)
        unless(actualInst
          error("ST_ML: missing direct child %s at %s\n" childName path))
        unless(equal(actualInst~>cellName stMlGet(stMlGet(entry "source") "cell"))
          error("ST_ML: path %s master mismatch\n" path))
        dbClose(parentCv)
      )
    )
    t
  )
)

procedure(stMlCheckAndSave(cv)
  when(getd('StTopologyCheckAndSave)
    unless(StTopologyCheckAndSave(cv)
      error("ST_ML: schematic check/save failed for %s\n" cv~>cellName)
    )
  )
  t
)

; 修改原因：物化 generated_cells 并检查真实端子连接，确保新 Cell 包含变换内容。
procedure(stMlVerifyConnections(cv plan path)
  let((item inst connection actual it)
    foreach(item stMlGet(plan "create_instances")
      when(equal(stMlGet(item "hierarchy_path") path)
        inst = stMlFindInst(cv stMlGet(item "name"))
        unless(inst error("ST_ML: created instance missing %s" stMlGet(item "name")))
        foreach(connection stMlGet(item "connections")
          actual = nil
          foreach(it inst~>instTerms
            when(equal(it~>term~>name stMlGet(connection "pdk_terminal"))
              actual = if(it~>net then it~>net~>name else nil)))
          unless(equal(actual stMlGet(connection "net"))
            error("ST_ML: connection mismatch scope=%s instance=%s terminal=%s expected=%s actual=%L"
              path inst~>name stMlGet(connection "pdk_terminal") stMlGet(connection "net") actual)))))
    printf("ST_ML_CONNECTIONS_PASS scope=%s cell=%s/%s/%s\n"
      path cv~>libName cv~>cellName cv~>viewName)
    t
  )
)

; 修改原因：物化 generated_cells 并检查真实端子连接，确保新 Cell 包含变换内容。
procedure(stMlCreateGenerated(item)
  let((ref cv path viewObj view)
    ref = stMlGet(item "schematic")
    printf("ST_ML_GENERATED package=%s cell=%L\n" stMlGet(item "package_id") ref)
    foreach(view list("schematic" "symbol")
      viewObj = ddGetObj(stMlGet(ref "library") stMlGet(ref "cell") view)
      when(viewObj ddDeleteObj(viewObj)))
    cv = dbOpenCellViewByType(stMlGet(ref "library") stMlGet(ref "cell")
                               stMlGet(ref "view") "schematic" "w")
    unless(cv error("ST_ML: cannot create generated schematic %L" ref))
    path = strcat("/@generated/" stMlGet(item "package_id"))
    stMlApplyOperations(cv item path)
    stMlCheckAndSave(cv)
    stMlVerifyConnections(cv item path)
    dbClose(cv)
    StTopologyCreateWrapperSymbol(item)
    printf("ST_PACKAGE_READY cell=%s/%s/%s\n"
      stMlGet(ref "library") stMlGet(ref "cell") stMlGet(ref "view"))
    t
  )
)

; 修改原因：从已解析、已通过预检查的局部计划执行物化，不再误删后才发现另一模块无效。
procedure(stMlMaterializePlan(plan)
  let((maps ops maxDepth entry path cv symRefs depth childEntry newSym
       createdSyms item target existingObj)
    maps = stMlGet(plan "clone_on_write")
    foreach(entry maps
      target = stMlGet(entry "target")
      existingObj = ddGetObj(stMlGet(target "library") stMlGet(target "cell") stMlGet(target "view"))
      when(existingObj
        printf("ST_ML REPLACE_VIEW: %s/%s/%s\n"
          stMlGet(target "library") stMlGet(target "cell") stMlGet(target "view"))
        ddDeleteObj(existingObj)))
    ; 阶段 1：克隆全部 schematic/symbol（含 cell 级 CDF）。
    foreach(entry maps stMlCopySourceToClone(entry))
    ; 修改原因：先创建封装 schematic/symbol，再删除 owner 原 MOS；复制属性时原 MOS 仍存在。
    foreach(item stMlGet(plan "generated_cells") stMlCreateGenerated(item))
    ; 阶段 2：自底向上——最深层级先编辑，再在父克隆中重绑定子实例。
    maxDepth = 0
    foreach(entry maps
      when(stMlDepth(stMlGet(entry "hierarchy_path")) > maxDepth
        maxDepth = stMlDepth(stMlGet(entry "hierarchy_path"))
      )
    )
    depth = maxDepth
    while(depth >= 0
      foreach(entry maps
        path = stMlGet(entry "hierarchy_path")
        when(equal(stMlDepth(path) depth)
          cv = stMlOpenTarget(entry)
          stMlApplyOperations(cv plan path)
          ; 只重绑定本层级路径下命名的子实例，不污染兄弟分支。
          createdSyms = nil
          foreach(childEntry maps
            when(equal(stMlGet(childEntry "parent_hierarchy_path") path)
              createdSyms = cons(stMlRebindChild(cv childEntry) createdSyms)
            )
          )
          stMlCheckAndSave(cv)
          ; 修改原因：仅核对本次创建的封装外部端子，不改变整个电路的校验流程。
          stMlVerifyConnections(cv plan path)
          dbClose(cv)
          foreach(newSym createdSyms dbClose(newSym))
        )
      )
      depth = depth - 1
    )
    printf("ST_ML MATERIALIZED_UNVERIFIED: %s. Netlist compare still REQUIRED.\n"
           stMlGet(plan "topology_hash"))
    list(list("ok" t) list("stage" "complete")
         list("message" "multi-level materialization staged; netlist compare required"))
  )
)

; 修改原因：不同 owner 是独立模块，各自根路径为 /；保持旧单计划与 Python 调用兼容。
procedure(StTopologyVariantMaterialize(planPath)
  let((document plans plan target)
    document = StTopologyParseJsonFile(planPath)
    plans = stMlGet(document "module_plans")
    unless(plans plans = list(document))
    foreach(plan plans stMlPreflight(plan))
    printf("ST_MODULE_PREFLIGHT=PASS count=%d\n" length(plans))
    foreach(plan plans
      target = stMlGet(plan "target")
      printf("ST_MODULE_BEGIN cell=%s/%s/%s\n"
        stMlGet(target "library") stMlGet(target "cell") stMlGet(target "view"))
      stMlMaterializePlan(plan)
      printf("ST_MODULE_COMPLETE cell=%s/%s/%s\n"
        stMlGet(target "library") stMlGet(target "cell") stMlGet(target "view")))
    list(list("ok" t) list("stage" "complete")
         list("message" "module materialization staged; netlist compare required"))
  )
)
