// =============================================================
// AutoBias.cpp — 单复制原管＋单 R_BIAS 的 N/P 互补连接与器件选择
// 电阻初值与调阻由 DC 求解器决定；本文件不出现任何固定 PDK Cell 名。
// =============================================================
#include "st/AutoBias.h"

#include "st/Netlist.h"
#include "st/PdkCatalog.h"

#include "securec.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <set>

namespace st {
namespace {

bool supportsDomain(const DeviceDescriptor& descriptor, const std::string& domain,
                    bool experimental = false)
{
    if (domain.empty()) {
        return experimental || !descriptor.voltage_domain.empty() ||
        !descriptor.allowed_voltage_domains.empty();
    }
    if (!descriptor.allowed_voltage_domains.empty()) {
        return descriptor.allowed_voltage_domains.count(domain) != 0;
    }
    return (experimental && descriptor.voltage_domain.empty()) ||
           descriptor.voltage_domain == domain;
}

bool hasMosTerminals(const DeviceDescriptor& descriptor)
{
    return descriptor.terminal_count >= 4 &&
           descriptor.terminal_names_by_index.size() == descriptor.terminal_count &&
           descriptor.terminal_index.count(TerminalRole::Drain) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Gate) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Source) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Bulk) != 0;
}

// 修改原因：VBIAS 只选择复制原管和真实电阻，不再扫描镜像 MOS。
bool validParameterMetadata(const DeviceDescriptor& descriptor, bool experimental = false)
{
    if (descriptor.native_parameter_trials && (!experimental || descriptor.parameter_constraints.empty())) {
        return false;
    }
    std::set<std::string> cdfNames;
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        const std::string semantic = constraint.semantic_name.empty()
            ? name : constraint.semantic_name;
        const auto mapping = descriptor.normalized_to_cdf.find(semantic);
        if ((descriptor.native_parameter_trials && constraint.discrete_values.empty()) ||
            constraint.cdf_name.empty() ||
            !ValidateParameterConstraint(constraint) ||
            !cdfNames.insert(constraint.cdf_name).second ||
            (mapping != descriptor.normalized_to_cdf.end() &&
             mapping->second != constraint.cdf_name)) {
            return false;
        }
    }
    return true;
}

bool mosUsable(const DeviceDescriptor& descriptor, DeviceKind kind,
               const std::string& domain, bool experimental)
{
    return descriptor.kind == kind && (experimental || descriptor.reliability_complete) &&
           validParameterMetadata(descriptor, experimental) &&
           descriptor.bulk_rule_complete &&
           !descriptor.oa_library.empty() && !descriptor.oa_cell.empty() &&
           !descriptor.oa_view.empty() && hasMosTerminals(descriptor) &&
           supportsDomain(descriptor, domain, experimental);
}

bool resistorUsable(const DeviceDescriptor& descriptor, const std::string& domain,
                     bool experimental)
{
    bool hasResistance = false;
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        const std::string semantic = constraint.semantic_name.empty()
            ? name : constraint.semantic_name;
        if (semantic == "resistance" && !constraint.cdf_name.empty() &&
            ValidateParameterConstraint(constraint)) {
            hasResistance = true;
        }
    }
    return descriptor.kind == DeviceKind::Resistor &&
           validParameterMetadata(descriptor, experimental) &&
           !descriptor.oa_library.empty() && !descriptor.oa_cell.empty() &&
           !descriptor.oa_view.empty() &&
           descriptor.terminal_index.count(TerminalRole::Positive) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Negative) != 0 &&
           hasResistance &&
           supportsDomain(descriptor, domain, experimental);
}

// 修改原因：镜像选型已删除，VBIAS 只保留一只复制原管和 R_BIAS。
std::vector<const DeviceDescriptor*> selectResistor(const DeviceCatalog& catalog,
                                       const std::string& domain,
                                       const std::string& controlLibrary, bool experimental)
{
    std::vector<const DeviceDescriptor*> candidates;
    for (const auto& [name, descriptor] : catalog.Descriptors()) {
        if (resistorUsable(descriptor, domain, experimental)) {
            candidates.push_back(&descriptor);
        }
    }
    std::sort(candidates.begin(), candidates.end(),
        [&controlLibrary](const DeviceDescriptor* left,
                          const DeviceDescriptor* right) {
            const bool leftSame = left->oa_library == controlLibrary;
            const bool rightSame = right->oa_library == controlLibrary;
            if (leftSame != rightSame) {
                return leftSame;
            }
            return left->master < right->master;
        });
    return candidates;
}

// Bulk/Well：目录规则完整是前置条件；孤立阱源衬相连，否则 NMOS→VLOW、PMOS→VHIGH。
std::string mosBulkNet(const DeviceDescriptor& descriptor, DeviceKind polarity,
                       const std::string& sourceNet, const std::string& vhighNet,
                       const std::string& vlowNet)
{
    if (descriptor.isolated_well) {
        return sourceNet;
    }
    return polarity == DeviceKind::MosN ? vlowNet : vhighNet;
}

struct MosNetBinding {
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
};

bool buildMosNets(const DeviceDescriptor& descriptor,
                  const MosNetBinding& binding, std::vector<std::string>& nets)
{
    nets.assign(descriptor.terminal_count, std::string{});
    const std::pair<TerminalRole, const std::string*> bindings[] = {
        {TerminalRole::Drain, &binding.drain},
        {TerminalRole::Gate, &binding.gate},
        {TerminalRole::Source, &binding.source},
        {TerminalRole::Bulk, &binding.bulk},
    };
    for (const auto& [role, net] : bindings) {
        const auto found = descriptor.terminal_index.find(role);
        if (found == descriptor.terminal_index.end() ||
            found->second >= nets.size()) {
            return false;
        }
        nets[found->second] = *net;
    }
    return std::find(nets.begin(), nets.end(), std::string{}) == nets.end();
}

struct ResistorNetBinding {
    std::string positive;
    std::string negative;
    std::string vhigh;
    std::string vlow;
};

bool buildResistorNets(const DeviceDescriptor& descriptor,
                       const ResistorNetBinding& binding,
                       std::vector<std::string>& nets)
{
    nets.assign(descriptor.terminal_count, std::string{});
    for (std::size_t index = 0; index < descriptor.terminal_count; ++index) {
        const auto role = index < descriptor.terminal_roles_by_index.size()
            ? descriptor.terminal_roles_by_index[index] : TerminalRole::Other;
        switch (role) {
        case TerminalRole::Positive: nets[index] = binding.positive; break;
        case TerminalRole::Negative: nets[index] = binding.negative; break;
        case TerminalRole::Substrate: nets[index] = binding.vlow; break;
        case TerminalRole::Well: nets[index] = binding.vhigh; break;
        default: return false;
        }
    }
    return std::find(nets.begin(), nets.end(), std::string{}) == nets.end();
}

bool sameParameterValue(double left, double right)
{
    return std::fabs(left - right) <= 1e-12 * std::max(std::fabs(left), std::fabs(right));
}

// 所有写入值均须登记真实CDF约束；量化未改变数值时保留原文。
bool quantizeElementParams(const DeviceDescriptor& descriptor,
                           const std::map<std::string, std::string>& roleParams,
                           const std::string& roleName,
                           std::map<std::string, std::string>& out,
                           Diagnostic& diagnostic,
                           bool requireUnchanged = false,
                           bool experimental = false)
{
    out.clear();
    if (!validParameterMetadata(descriptor, experimental)) {
        diagnostic = {DiagCode::BadParam,
            "role " + roleName + " CDF mapping or parameter constraint invalid: " + descriptor.master};
        return false;
    }
    for (const auto& [cdfName, text] : roleParams) {
        const ParameterConstraint* constraint = nullptr;
        for (const auto& [semantic, candidate] : descriptor.parameter_constraints) {
            if (candidate.cdf_name == cdfName) {
                constraint = &candidate;
                break;
            }
        }
        if (constraint == nullptr) {
            diagnostic = {DiagCode::BadParam,
                "role " + roleName + " parameter " + cdfName +
                " not registered with a real CDF numeric constraint: " + descriptor.master};
            return false;
        }
        bool parsed = false;
        const double value = parseSuffixValue(text, parsed);
        if (!parsed || !std::isfinite(value)) {
            diagnostic = {DiagCode::BadParam,
                "role " + roleName + " parameter " + cdfName + " is not a valid number: " + text};
            return false;
        }
        if ((value < constraint->minimum && !sameParameterValue(value, constraint->minimum)) ||
            (value > constraint->maximum && !sameParameterValue(value, constraint->maximum)) ||
            (constraint->integer_only &&
             std::fabs(value - std::round(value)) >
                 1e-12 * std::max(1.0, std::fabs(value)))) {
            diagnostic = {DiagCode::BadParam,
                "role " + roleName + " parameter " + cdfName +
                " does not match CDF type or range: " + text};
            return false;
        }
        try {
            const double quantized = QuantizeParameter(value, *constraint);
            if ((requireUnchanged || descriptor.native_parameter_trials) &&
                !sameParameterValue(quantized, value)) {
                diagnostic = {DiagCode::BadParam,
                    "role " + roleName + " parameter " + cdfName +
                    " out of the real CDF quantization domain; refusing to change the original Replica: " + text};
                return false;
            }
            const bool unchangedWithinRoundoff = sameParameterValue(quantized, value);
            out[cdfName] = requireUnchanged || unchangedWithinRoundoff
                ? text : FormatAutoBiasParameter(quantized);
        } catch (const std::exception&) {
            diagnostic = {DiagCode::BadParam,
                "role " + roleName + " parameter " + cdfName +
                " cannot be quantized to a valid PDK value: " + text};
            return false;
        }
    }
    return true;
}

struct RoleSpec {
    std::string name;
    const DeviceDescriptor* descriptor;
    std::string drain_or_positive;
    std::string gate;
    std::string source_or_negative;
    std::string bulk;
    bool is_resistor = false;
};

struct RailNets {
    std::string vhigh;
    std::string vlow;
};

struct BuiltElement {
    bool ok = false;
    BiasElementPlan element;
    Diagnostic diagnostic;
};

BuiltElement buildElement(const RoleSpec& spec, const RailNets& rails,
                          const BiasSizing& sizing, bool experimental)
{
    BuiltElement result;
    const auto params = sizing.element_parameters.find(spec.name);
    if (params == sizing.element_parameters.end()) {
        result.diagnostic = {DiagCode::MissingInput,
            "BiasSizing missing solve parameters for role " + spec.name};
        return result;
    }
    result.element.name = spec.name;
    result.element.model = spec.descriptor->master;
    const bool netsOk = spec.is_resistor
        ? buildResistorNets(*spec.descriptor,
                            {spec.drain_or_positive, spec.source_or_negative,
                             rails.vhigh, rails.vlow},
                            result.element.nets)
        : buildMosNets(*spec.descriptor,
                       {spec.drain_or_positive, spec.gate,
                        spec.source_or_negative, spec.bulk},
                       result.element.nets);
    if (!netsOk) {
        result.diagnostic = {DiagCode::InvalidTerminalMap,
            "terminals of role " + spec.name + " cannot be fully connected per PDK roles"};
        return result;
    }
    result.ok = quantizeElementParams(*spec.descriptor, params->second, spec.name,
                                      result.element.params, result.diagnostic, false, experimental);
    return result;
}

} // namespace

std::string FormatAutoBiasParameter(double value)
{
    const std::string compact = formatEngineering(value);
    bool parsed = false;
    const double roundTrip = parseSuffixValue(compact, parsed);
    if (parsed && roundTrip == value) {
        return compact;
    }
    char buffer[64];
    snprintf_s(buffer, sizeof(buffer), sizeof(buffer), "%.17g", value);
    return buffer;
}

QuantizeAutoBiasResult QuantizeAutoBiasParameters(
    const DeviceDescriptor& descriptor,
    const std::map<std::string, std::string>& parameters,
    const std::string& role,
    const QuantizeAutoBiasOptions& options)
{
    QuantizeAutoBiasResult result;
    result.ok = quantizeElementParams(descriptor, parameters, role, result.out,
                                      result.diagnostic,
                                      options.require_unchanged, options.experimental_dc);
    return result;
}

bool SelectAutoBiasDeviceCandidates(const AutoBiasTemplateRequest& request,
                                    const DeviceCatalog& catalog,
                                    std::vector<AutoBiasDevicePlan>& plans,
                                    Diagnostic& diagnostic)
{
    plans.clear();
    AutoBiasDevicePlan plan;
    if (request.polarity != DeviceKind::MosN &&
        request.polarity != DeviceKind::MosP) {
        diagnostic = {DiagCode::BadParam,
                      "VBIAS template polarity only allows NMOS or PMOS"};
        return false;
    }
    if (request.vhigh_net.empty() || request.vlow_net.empty() ||
        request.original_source_net.empty() || request.control_gate_net.empty()) {
        diagnostic = {DiagCode::MissingInput,
                      "external nets requested by the VBIAS template are incomplete"};
        return false;
    }
    plan.control = catalog.Find(request.control_master);
    if (plan.control == nullptr) {
        diagnostic = {DiagCode::NotFound,
                      "control device master not in the current PDK catalog: " + request.control_master};
        return false;
    }
    plan.cascode = catalog.Find(request.cascode_master);
    if (plan.cascode == nullptr) {
        diagnostic = {DiagCode::NotFound,
                      "Cascode master not in the current PDK catalog: " + request.cascode_master};
        return false;
    }
    if (plan.control->kind != request.polarity ||
        plan.cascode->kind != request.polarity) {
        diagnostic = {DiagCode::PolarityMismatch,
                      "control device/Cascode inconsistent with the requested template polarity"};
        return false;
    }
    if (!mosUsable(*plan.control, request.polarity, request.voltage_domain, request.experimental_dc)) {
        diagnostic = {DiagCode::MissingInput,
                      "control device missing reliability, Bulk rule, terminal or voltage domain data: " +
                          request.control_master};
        return false;
    }
    if (!mosUsable(*plan.cascode, request.polarity, request.voltage_domain, request.experimental_dc)) {
        diagnostic = {DiagCode::MissingInput,
                      "Cascode device missing reliability, Bulk rule, terminal or voltage domain data: " +
                          request.cascode_master};
        return false;
    }

    if (!HaveCompatibleVoltageDomains({plan.control, plan.cascode})) {
        diagnostic = {DiagCode::BadParam, "control device and Cascode have conflicting existing voltage domain data"};
        return false;
    }
    const auto resistors = selectResistor(catalog, request.voltage_domain,
                                          plan.control->oa_library, request.experimental_dc);
    if (resistors.empty()) {
        diagnostic = {DiagCode::MissingInput,
                      "no usable real resistor in the current PDK catalog"};
        return false;
    }
    // 只绑定原管、Cascode 和一只真实电阻；电气性能不参与器件排名。
    for (const auto* resistor : resistors) {
        if (!HaveCompatibleVoltageDomains({plan.control, plan.cascode, resistor})) {
            continue;
        }
        plan.resistor = resistor;
        plans.push_back(plan);
        return true;
    }
    diagnostic = {DiagCode::BadParam, "control device, Cascode and resistor have no common compatible voltage domain"};
    return false;
}

bool SelectAutoBiasDevices(const AutoBiasTemplateRequest& request,
                           const DeviceCatalog& catalog,
                           AutoBiasDevicePlan& plan,
                           Diagnostic& diagnostic)
{
    std::vector<AutoBiasDevicePlan> plans;
    if (!SelectAutoBiasDeviceCandidates(request, catalog, plans, diagnostic)) {
        return false;
    }
    plan = plans.front();
    return true;
}

// 修改原因：旧适配层只填 cascode_parameters，VBIAS 角色缺参数时无法生成模板。
// 这里仅选结构初值（沿用已知尺寸，否则取配置域中点），不是 DC 搜索或电气通过证明。
bool InitialStructuralBias(const AutoBiasTemplateRequest& request, const DeviceCatalog& catalog,
        const Instance& original, BiasSizing& sizing, Diagnostic& diagnostic)
{
    AutoBiasDevicePlan devices;
    if (!SelectAutoBiasDevices(request, catalog, devices, diagnostic)) return false;
    const auto parameters = [&](const DeviceDescriptor& desc, bool preserve,
                                bool inheritOriginal) {
        std::map<std::string, std::string> result;
        for (const auto& pair : desc.parameter_constraints) {
            const auto& c = pair.second;
            auto value = original.params.end();
            if (preserve || inheritOriginal) {
                const auto sourceName = devices.control->normalized_to_cdf.find(pair.first);
                if (sourceName != devices.control->normalized_to_cdf.end()) {
                    value = original.params.find(sourceName->second);
                }
                if (value == original.params.end()) value = original.params.find(c.cdf_name);
            }
            bool parsed = false;
            const double sourceValue = value == original.params.end() ? 0.0 : parseSuffixValue(value->second, parsed);
            if (preserve) {
                if (value != original.params.end()) result[c.cdf_name] = value->second;
            } else {
                const double initial = inheritOriginal && parsed && std::isfinite(sourceValue)
                    ? sourceValue : c.minimum > 0.0 && std::isfinite(c.maximum)
                    ? std::sqrt(c.minimum * c.maximum)
                    : c.minimum + (c.maximum - c.minimum) * 0.5;
                result[c.cdf_name] = FormatAutoBiasParameter(QuantizeParameter(initial, c));
            }
        }
        return result;
    };
    try {
        sizing.cascode_parameters = parameters(*devices.cascode,
            devices.control->master == devices.cascode->master, true);
        const auto control = parameters(*devices.control, true, true);
        // 电阻只使用自己的 CDF 域，不能把原管 W/L 或 WF/NF/L 当成电阻初值。
        const auto resistor = parameters(*devices.resistor, false, false);
        const bool n = request.polarity == DeviceKind::MosN;
        sizing.element_parameters[n ? "R_BIAS_N" : "R_BIAS_P"] = resistor;
        sizing.element_parameters[n ? "N_CTRL_REP_N" : "P_CTRL_REP_P"] = control;
        sizing.resistor_master = devices.resistor->master;
    } catch (const std::exception& error) {
        diagnostic = {DiagCode::BadParam, std::string("VBIAS structural initial parameters: ") + error.what()};
        return false;
    }
    return true;
}

AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest& request,
    const BiasSizing& sizing,
    const DeviceCatalog& catalog)
{
    AutoBiasTemplateResult result;
    AutoBiasDevicePlan plan;
    std::vector<AutoBiasDevicePlan> plans;
    Diagnostic selectionDiagnostic;
    if (!SelectAutoBiasDeviceCandidates(request, catalog, plans, selectionDiagnostic)) {
        result.diagnostics.push_back(std::move(selectionDiagnostic));
        return result;
    }
    plan = plans.front();
    if (!sizing.resistor_master.empty()) {
        // 求解后显式绑定的电阻身份必须原样用于重建和 PVT。
        const auto* resistor = catalog.Find(sizing.resistor_master);
        if (resistor == nullptr ||
            !resistorUsable(*resistor, request.voltage_domain, request.experimental_dc) ||
            !HaveCompatibleVoltageDomains({plan.control, plan.cascode, resistor})) {
            result.diagnostics.push_back({DiagCode::BadParam,
                "BiasSizing-selected resistor is not legal in the current PDK combination: " +
                sizing.resistor_master});
            return result;
        }
        plan.resistor = resistor;
    }
    const DeviceDescriptor* control = plan.control;
    const DeviceDescriptor* cascode = plan.cascode;
    const DeviceDescriptor* resistor = plan.resistor;
    const auto cascodeQuantized = QuantizeAutoBiasParameters(
        *cascode, sizing.cascode_parameters, "actual_cascode",
        {true, request.experimental_dc});
    if (!cascodeQuantized.ok) {
        result.diagnostics.push_back(std::move(cascodeQuantized.diagnostic));
        return result;
    }

    const bool isN = request.polarity == DeviceKind::MosN;
    // 模板是独立子电路：内部所有连接只能引用固定端口名（VHIGH/VLOW/VS_ORIG/
    // VG_CTRL），请求里的父层网络名只用于非空校验，由实例化阶段映射。
    result.template_id = isN ? "VBIAS_N_CASCODE_AUTO" : "VBIAS_P_CASCODE_AUTO";
    result.output_net = isN ? "VBIAS_N" : "VBIAS_P";
    const std::string& range = request.array_range;
    const std::string outputPin = result.output_net + range;
    const std::string sourcePin = "VS_ORIG" + range;
    const std::string gatePin = "VG_CTRL" + range;
    result.ports = {"VHIGH", "VLOW", sourcePin, gatePin, outputPin};

    // 复制原管 Source 直接输出 VBIAS，再经唯一一只 R_BIAS 回到原 Source。
    // NMOS 的 Drain 接 VHIGH，PMOS 的 Drain 接 VLOW，形成完整直流回路。
    std::vector<RoleSpec> roles;
    if (isN) {
        roles = {
            {"N_CTRL_REP_N", control, "VHIGH", gatePin, outputPin,
             mosBulkNet(*control, DeviceKind::MosN, sourcePin, "VHIGH", "VLOW")},
            {"R_BIAS_N", resistor, outputPin, {}, sourcePin, {}, true},
        };
    } else {
        roles = {
            {"P_CTRL_REP_P", control, "VLOW", gatePin, outputPin,
             mosBulkNet(*control, DeviceKind::MosP, sourcePin, "VHIGH", "VLOW")},
            {"R_BIAS_P", resistor, outputPin, {}, sourcePin, {}, true},
        };
    }

    for (const auto& spec : roles) {
        const auto built = buildElement(spec, {"VHIGH", "VLOW"}, sizing, request.experimental_dc);
        if (!built.ok) {
            result.diagnostics.push_back(std::move(built.diagnostic));
            return result;
        }
        auto element = built.element;
        element.name += range;
        result.elements.push_back(std::move(element));
    }
    result.ok = true;
    return result;
}

} // namespace st
