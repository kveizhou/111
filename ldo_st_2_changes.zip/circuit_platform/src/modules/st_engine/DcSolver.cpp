// =============================================================
// DcSolver.cpp — 单复制原管＋单 R_BIAS 的 DC 工作区硬约束
// 只评估候选 OP；最多 20 次调 R 的名义搜索见 ResistanceBiasSolver.cc。
// =============================================================
#include "st/DcSolver.h"

#include "st/ResistanceBiasSolver.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace st {
namespace {

constexpr double kContinuityTolerance = 1e-3;

const std::vector<std::string> kConstraintOrder = {
    "converged", "complete", "params_legal",
    "reliability_vgs", "reliability_vds", "reliability_vgb",
    "original_region", "cascode_saturation", "saturation", "vbias_range",
    "bias_conduction", "branch_direction", "branch_continuity",
    "current_limits_valid", "branch_current_limit", "bias_current_limit",
    "resistor_stress", "preceding_groups",
};

bool endsWithRole(const std::string& candidate, const std::string& leaf)
{
    if (candidate.size() <= leaf.size() ||
        candidate.compare(candidate.size() - leaf.size(), leaf.size(), leaf) != 0) {
        return false;
    }
    const char delimiter = candidate[candidate.size() - leaf.size() - 1];
    return delimiter == '.' || delimiter == '/' || delimiter == ':';
}

const MosOperatingPoint* resolveRole(const OperatingPointSnapshot& snapshot,
                                     const ElectricalMosRole& role)
{
    if (role.leaf_name.empty()) return nullptr;
    if (!role.container_instance.empty()) {
        for (const char delimiter : {'.', '/', ':'}) {
            const auto scoped = snapshot.mos.find(
                role.container_instance + delimiter + role.leaf_name);
            if (scoped != snapshot.mos.end()) return &scoped->second;
        }
    } else {
        const auto exact = snapshot.mos.find(role.leaf_name);
        if (exact != snapshot.mos.end()) return &exact->second;
    }
    const MosOperatingPoint* unique = nullptr;
    for (const auto& [name, op] : snapshot.mos) {
        if (!endsWithRole(name, role.leaf_name)) continue;
        if (!role.container_instance.empty()) {
            const auto parent = name.substr(0, name.size() - role.leaf_name.size() - 1);
            if (parent != role.container_instance &&
                !endsWithRole(parent, role.container_instance)) {
                continue;
            }
        }
        if (unique != nullptr) return nullptr;
        unique = &op;
    }
    if (unique != nullptr || role.container_instance.empty()) return unique;
    for (const auto& [name, op] : snapshot.mos) {
        (void)op;
        if (endsWithRole(name, role.leaf_name)) return nullptr;
    }
    const auto exact = snapshot.mos.find(role.leaf_name);
    return exact == snapshot.mos.end() ? nullptr : &exact->second;
}

std::string reasonName(const std::string& constraint)
{
    if (constraint == "converged") return "not_converged";
    if (constraint == "complete") return "incomplete_snapshot";
    if (constraint == "current_limits_valid") return "current_limits_invalid";
    return constraint;
}

bool finitePoint(const MosOperatingPoint& point)
{
    if (!HasValidIntrinsicVoltages(point) || !std::isfinite(point.vg - point.vb)) {
        return false;
    }
    for (const double value : {point.vd, point.vg, point.vs, point.vb,
             point.id, point.vgs, point.vds, point.vbs, point.vth,
             point.vdsat, point.cgg}) {
        if (!std::isfinite(value)) return false;
    }
    return true;
}

double saturationMargin(const MosOperatingPoint& point)
{
    return std::fabs(point.intrinsic_vds.value_or(point.vds)) - std::fabs(point.vdsat);
}

bool sameNonzeroDirection(double current, double reference)
{
    return std::isfinite(current) && std::isfinite(reference) &&
        current != 0.0 && reference != 0.0 &&
        std::signbit(current) == std::signbit(reference);
}

} // namespace

ElectricalConstraintResult EvaluateElectricalConstraints(
    const OperatingPointSnapshot& snapshot,
    const ElectricalConstraintRequest& request,
    bool converged)
{
    ElectricalConstraintResult result;
    result.unverified_constraints = request.unverified_constraints;
    for (const auto& name : kConstraintOrder) result.constraints[name] = true;
    result.constraints["converged"] = converged;

    const bool limitsConfigured = request.max_branch_current_error.has_value() &&
        request.max_vbias_current.has_value() &&
        std::isfinite(*request.max_branch_current_error) &&
        std::isfinite(*request.max_vbias_current) &&
        *request.max_branch_current_error > 0.0 && *request.max_vbias_current > 0.0;
    const bool anyCurrentLimit = request.max_branch_current_error.has_value() ||
        request.max_vbias_current.has_value();
    result.constraints["current_limits_valid"] = !anyCurrentLimit || limitsConfigured;

    std::vector<ResistorStressResult> resistorResults;
    if (!request.bias_resistor.leaf_name.empty()) {
        auto expected = request.bias_resistor;
        expected.experimental_dc = request.experimental_dc;
        auto stress = EvaluateResistorStress(snapshot, expected);
        if (stress.measurements_available) {
            result.stress_measurements["bias_resistor.voltage"] = stress.voltage;
            result.stress_measurements["bias_resistor.current"] = stress.current;
            result.stress_measurements["bias_resistor.power"] = stress.power;
        }
        for (const auto& item : stress.unverified_constraints) {
            result.unverified_constraints.push_back("bias_resistor." + item);
        }
        result.constraints["resistor_stress"] = converged && stress.ok;
        resistorResults.push_back(std::move(stress));
    }

    const MosOperatingPoint* ctrlRep = nullptr;
    const MosOperatingPoint* actualControl = nullptr;
    const MosOperatingPoint* actualCascode = nullptr;
    if (converged) {
        ctrlRep = resolveRole(snapshot, request.control_replica);
        actualControl = resolveRole(snapshot, request.actual_control);
        actualCascode = resolveRole(snapshot, request.actual_cascode);
    }
    result.constraints["complete"] = converged && ctrlRep != nullptr &&
        actualControl != nullptr && actualCascode != nullptr &&
        finitePoint(request.baseline_control) && !resistorResults.empty();
    for (const auto& stress : resistorResults) {
        result.constraints["complete"] = result.constraints["complete"] &&
            stress.measurements_available && stress.failed_constraint != "resistor_rating_invalid";
    }
    if (result.constraints["complete"]) {
        for (const auto* point : {ctrlRep, actualControl, actualCascode}) {
            result.constraints["complete"] = result.constraints["complete"] && finitePoint(*point);
        }
    }

    if (result.constraints["complete"]) {
        const std::pair<const MosOperatingPoint*, const ElectricalMosRole*> roles[] = {
            {ctrlRep, &request.control_replica}, {actualControl, &request.actual_control},
            {actualCascode, &request.actual_cascode},
        };
        double reliabilityMargin = std::numeric_limits<double>::infinity();
        for (const auto& [op, role] : roles) {
            const double voltages[] = {op->vgs, op->vds, op->vg - op->vb};
            const double limits[] = {role->limits.max_abs_vgs, role->limits.max_abs_vds,
                                     role->limits.max_abs_vgb};
            const char* names[] = {"reliability_vgs", "reliability_vds", "reliability_vgb"};
            const char* quantities[] = {"vgs", "vds", "vgb"};
            if (!role->reliability_complete) {
                result.unverified_constraints.push_back(role->leaf_name + ".reliability_metadata");
                if (!request.experimental_dc) result.constraints["reliability_vgs"] = false;
            }
            for (std::size_t index = 0; index < 3; ++index) {
                result.stress_measurements[role->leaf_name + "." + quantities[index]] = voltages[index];
                if (!std::isfinite(limits[index])) {
                    result.unverified_constraints.push_back(role->leaf_name + "." + names[index]);
                    if (!request.experimental_dc) result.constraints[names[index]] = false;
                    continue;
                }
                const double margin = limits[index] - std::fabs(voltages[index]);
                result.constraints[names[index]] = result.constraints[names[index]] &&
                    limits[index] > 0.0 && margin >= 0.0;
                reliabilityMargin = std::min(reliabilityMargin, margin);
            }
            const double margin = saturationMargin(*op);
            result.stress_measurements[role->leaf_name + ".intrinsic_vds"] =
                op->intrinsic_vds.value_or(op->vds);
            result.stress_measurements[role->leaf_name + ".vdsat"] = op->vdsat;
            result.stress_measurements[role->leaf_name + ".saturation_margin"] = margin;
        }

        const double baselineMargin = saturationMargin(request.baseline_control);
        const bool originalWasSaturated = baselineMargin >= 0.0;
        const double originalMargin = saturationMargin(*actualControl);
        const double replicaMargin = saturationMargin(*ctrlRep);
        const auto regionMatches = [originalWasSaturated](double margin) {
            return originalWasSaturated ? margin >= 0.0 : margin < 0.0;
        };
        result.constraints["original_region"] =
            regionMatches(originalMargin) && regionMatches(replicaMargin);
        const double cascodeMargin = saturationMargin(*actualCascode);
        result.constraints["cascode_saturation"] = cascodeMargin >= 0.0;
        result.constraints["saturation"] = cascodeMargin >= 0.0;
        result.metrics.saturation_margin = cascodeMargin;
        result.metrics.saturation_deficit = std::max(0.0, -cascodeMargin) /
            std::max(std::fabs(actualCascode->vdsat), 1e-6);

        result.vbias_voltage = ctrlRep->vs;
        result.stress_measurements["vbias"] = ctrlRep->vs;
        const double vbiasLow = request.polarity == DeviceKind::MosN
            ? request.baseline_control.vs : ctrlRep->vd;
        const double vbiasHigh = request.polarity == DeviceKind::MosN
            ? ctrlRep->vd : request.baseline_control.vs;
        result.constraints["vbias_range"] = vbiasLow <= ctrlRep->vs && ctrlRep->vs <= vbiasHigh;
        result.constraints["bias_conduction"] =
            sameNonzeroDirection(ctrlRep->id, request.baseline_control.id);
        result.constraints["branch_direction"] = request.baseline_control.id == 0.0 ||
            (sameNonzeroDirection(ctrlRep->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualControl->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualCascode->id, request.baseline_control.id));
        const double continuityError = std::fabs(std::fabs(actualControl->id) -
            std::fabs(actualCascode->id)) / std::max(std::fabs(actualControl->id), 1e-30);
        result.constraints["branch_continuity"] = continuityError <= kContinuityTolerance;

        const double originalCurrent = std::fabs(request.baseline_control.id);
        result.metrics.branch_current_error = std::max(
            std::fabs(std::fabs(ctrlRep->id) - originalCurrent),
            std::fabs(std::fabs(actualControl->id) - originalCurrent)) /
            std::max(originalCurrent, 1e-30);
        result.metrics.control_op_error = std::fabs(actualControl->vgs - request.baseline_control.vgs) +
            std::fabs(actualControl->vds - request.baseline_control.vds);
        result.metrics.iq_delta = std::fabs(ctrlRep->id);
        result.constraints["branch_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.branch_current_error <= *request.max_branch_current_error);
        result.constraints["bias_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.iq_delta <= *request.max_vbias_current);
        result.metrics.reliability_margin = std::isfinite(reliabilityMargin)
            ? reliabilityMargin : std::numeric_limits<double>::quiet_NaN();
    } else {
        for (const auto& name : kConstraintOrder) {
            if (name != "converged" && name != "complete" && name != "params_legal" &&
                name != "current_limits_valid") {
                result.constraints[name] = false;
            }
        }
    }

    for (const auto& name : kConstraintOrder) {
        const auto found = result.constraints.find(name);
        if (found != result.constraints.end() && !found->second) {
            result.first_failed_constraint = reasonName(name);
            if (name == "resistor_stress") {
                for (const auto& stress : resistorResults) {
                    if (!stress.failed_constraint.empty()) {
                        result.first_failed_constraint = stress.failed_constraint;
                        break;
                    }
                }
            }
            return result;
        }
    }
    result.ok = true;
    result.reliability_verified = !request.experimental_dc && result.unverified_constraints.empty();
    return result;
}

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest& request,
                                  const DeviceCatalog& catalog,
                                  DcEvaluationHost& host)
{
    return SolveCascodeResistanceBias(request, catalog, host);
}

} // namespace st
