#include "st/OaPlan.h"
#include "st/Naming.h"

#include <set>
#include <algorithm>

namespace st {

namespace {

bool complete(const CellViewRef& ref)
{
    return !ref.library.empty() && !ref.cell.empty() && !ref.view.empty();
}

std::string physicalKey(const CellViewRef& ref)
{
    return ref.storage_path + "\n" + ref.library + "\n" + ref.cell + "\n" + ref.view;
}

std::string roleName(TerminalRole role)
{
    switch (role) {
    case TerminalRole::Drain: return "Drain";
    case TerminalRole::Gate: return "Gate";
    case TerminalRole::Source: return "Source";
    case TerminalRole::Bulk: return "Bulk";
    case TerminalRole::Positive: return "Positive";
    case TerminalRole::Negative: return "Negative";
    case TerminalRole::Substrate: return "Substrate";
    case TerminalRole::Well: return "Well";
    case TerminalRole::Other: return "Other";
    }
    return "Other";
}

bool sameInstance(const Instance& left, const Instance& right)
{
    return left.model == right.model && left.nets == right.nets && left.params == right.params;
}

bool sameSubcktForOa(const Subckt& left, const Subckt& right)
{
    if (left.pins != right.pins || left.instances.size() != right.instances.size()) {
        return false;
    }
    for (const auto& instance : left.instances) {
        const auto* other = right.find(instance.name);
        if (other == nullptr || !sameInstance(instance, *other)) {
            return false;
        }
    }
    return true;
}

} // namespace

std::vector<Diagnostic> ValidateOaPlan(const OaMaterializationPlan& plan)
{
    std::vector<Diagnostic> diagnostics;
    if (!complete(plan.source) || !complete(plan.target)) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "source or target library/cell/view is incomplete"});
        return diagnostics;
    }
    if (SamePhysicalCellView(plan.source, plan.target)) {
        diagnostics.push_back({DiagCode::SourceDesignProtected,
                               "Topology Variant must be written to an isolated target, writing over the source cellview is prohibited"});
        return diagnostics;
    }
    std::map<std::string, const OaCloneMapping*> clonesByPath;
    std::set<std::string> cloneTargets;
    if (plan.clone_map.empty()) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "missing clone-on-write hierarchy mapping"});
    } else {
        for (const auto& mapping : plan.clone_map) {
            if (mapping.hierarchy_path.empty() || !complete(mapping.source) ||
                !complete(mapping.target) || SamePhysicalCellView(mapping.source, mapping.target)) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "clone-on-write mapping is incomplete or the target overwrites the source cellview"});
                continue;
            }
            if (!clonesByPath.emplace(mapping.hierarchy_path, &mapping).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "duplicate clone mapping for the same hierarchy_path"});
            }
            if (!cloneTargets.insert(physicalKey(mapping.target)).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "different hierarchy branches cannot share the same clone target cellview"});
            }
        }
        const auto root = clonesByPath.find("/");
        if (root == clonesByPath.end() || !(root->second->source == plan.source) ||
            !(root->second->target == plan.target)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "root-level clone mapping is inconsistent with the plan source/target"});
        }
        for (const auto& [path, mapping] : clonesByPath) {
            if (path == "/") {
                if (!mapping->parent_hierarchy_path.empty() ||
                    !mapping->parent_instance_name.empty()) {
                    diagnostics.push_back({DiagCode::OaPlanInvalid,
                                           "root-level clone must not contain parent instance rebinding"});
                }
                continue;
            }
            if (mapping->parent_hierarchy_path.empty() ||
                mapping->parent_instance_name.empty() ||
                clonesByPath.count(mapping->parent_hierarchy_path) == 0) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "non-root-level clone lacks the cloned parent hierarchy and instance rebinding contract"});
            }
        }
    }
    if (plan.preview.variant_id.empty() || plan.preview.parameter_set_id.empty() ||
        plan.preview.materializer_version.empty()) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "preview identity variant/parameter-set/materializer is incomplete"});
    }

    std::set<std::string> generatedIds;
    std::set<std::string> generatedPhysicalCells;
    std::set<std::string> generatedSymbolsUsed;
    for (const auto& instance : plan.create_instances) {
        generatedSymbolsUsed.insert(physicalKey(instance.master));
    }
    for (const auto& generated : plan.generated_cells) {
        const std::string scope = "/@generated/" + generated.package_id;
        if (generated.package_id.empty() || !generatedIds.insert(generated.package_id).second ||
            !complete(generated.schematic) || !complete(generated.symbol) ||
            generated.schematic.library != generated.symbol.library ||
            generated.schematic.cell != generated.symbol.cell ||
            generated.schematic.view != "schematic" || generated.symbol.view != "symbol" ||
            SamePhysicalCellView(generated.schematic, plan.source) ||
            !(generated.symbol_upper_right.x > generated.symbol_lower_left.x) ||
            !(generated.symbol_upper_right.y > generated.symbol_lower_left.y)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "generated child Cell package id, schematic/symbol or symbol bounds are invalid"});
            continue;
        }
        const auto cellKey = generated.schematic.storage_path + "\n" +
            generated.schematic.library + "\n" + generated.schematic.cell;
        if (!generatedPhysicalCells.insert(cellKey).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "different packages cannot write to the same generated child Cell"});
        }
        if (generatedSymbolsUsed.count(physicalKey(generated.symbol)) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "generated child Cell symbol is not referenced by the parent schematic wrapper"});
        }
        std::map<std::string, std::map<std::string, std::string>> terminalsByInstance;
        std::set<std::string> nestedNames;
        for (const auto& instance : generated.create_instances) {
            // 修改原因：深层封装从对应 owner 的克隆图复制原 MOS 属性，不一定来自顶层。
            if ((!instance.property_source_instance.empty() &&
                 (cloneTargets.count(physicalKey(instance.property_source)) == 0 ||
                  !instance.allowed_extra_cdf_parameters.empty())) ||
                (instance.property_source_instance.empty() && complete(instance.property_source))) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "original property copy must come from the isolated owner schematic and must not relax instance parameter validation"});
            }
            if (instance.hierarchy_path != scope || instance.name.empty() ||
                !complete(instance.master) || instance.expected_terminal_count == 0 || instance.bit_count == 0 ||
                instance.connections.size() != instance.expected_terminal_count ||
                !nestedNames.insert(instance.name).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "generated child Cell instance lacks fixed scope, master, terminals or name uniqueness"});
                continue;
            }
            std::set<std::string> terminals;
            for (const auto& connection : instance.connections) {
                if (connection.pdk_terminal.empty() || connection.net.empty() ||
                    !terminals.insert(connection.pdk_terminal).second) {
                    diagnostics.push_back({DiagCode::OaPlanInvalid,
                        "generated child Cell instance terminal mapping is incomplete or duplicated"});
                    break;
                }
                terminalsByInstance[instance.name][connection.pdk_terminal] = connection.net;
            }
        }
        std::set<std::string> portNames;
        for (const auto& port : generated.create_ports) {
            if (port.hierarchy_path != scope || port.name.empty() || port.net != port.name ||
                port.direction.empty() || !portNames.insert(port.name).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "generated child Cell port must be in fixed scope with consistent and unique name/net"});
            }
        }
        if (generated.create_ports.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "generated child Cell must create visible ports"});
        }
        for (const auto& wire : generated.direct_wires) {
            const auto from = terminalsByInstance.find(wire.from_instance);
            const auto to = terminalsByInstance.find(wire.to_instance);
            if (wire.hierarchy_path != scope || wire.net.empty() ||
                from == terminalsByInstance.end() || to == terminalsByInstance.end() ||
                from->second.count(wire.from_terminal) == 0 ||
                to->second.count(wire.to_terminal) == 0 ||
                from->second.at(wire.from_terminal) != wire.net ||
                to->second.at(wire.to_terminal) != wire.net) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "generated child Cell point-to-point wire endpoints are inconsistent with the net"});
            }
        }
        for (const auto& wire : generated.wires) {
            if (wire.hierarchy_path != scope || wire.net.empty() || wire.points.size() < 2) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "generated child Cell label wire is incomplete"});
            }
        }
    }

    std::set<std::string> createdNames;
    std::map<std::string, std::map<std::string, std::string>> createdTerminalNets;
    for (const auto& instance : plan.create_instances) {
        if (instance.hierarchy_path.empty() || instance.name.empty() || !complete(instance.master) ||
            instance.connections.empty() || instance.expected_terminal_count == 0 || instance.bit_count == 0 ||
            instance.connections.size() != instance.expected_terminal_count) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "create instance lacks hierarchy, name, master or connections"});
            continue;
        }
        if (clonesByPath.count(instance.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "create instance has no isolated clone mapping for its hierarchy_path"});
        }
        const auto scopedName = instance.hierarchy_path + ":" + instance.name;
        if (!createdNames.insert(scopedName).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "duplicate create instance name in the same hierarchy: " + instance.name});
        }
        std::set<std::string> terminals;
        for (const auto& connection : instance.connections) {
            if (connection.semantic_terminal.empty() || connection.pdk_terminal.empty() ||
                connection.net.empty() || !terminals.insert(connection.pdk_terminal).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "instance " + instance.name + " terminal mapping is incomplete or duplicated"});
                break;
            }
            createdTerminalNets[scopedName][connection.pdk_terminal] = connection.net;
        }
    }
    std::set<std::string> directWireKeys;
    for (const auto& wire : plan.direct_wires) {
        if (wire.hierarchy_path.empty() || wire.net.empty() || wire.from_instance.empty() ||
            wire.from_terminal.empty() || wire.to_instance.empty() || wire.to_terminal.empty() ||
            (wire.from_instance == wire.to_instance &&
             wire.from_terminal == wire.to_terminal)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "point-to-point wire lacks hierarchy, net or both-end pins"});
            continue;
        }
        if (clonesByPath.count(wire.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "point-to-point wire has no isolated clone mapping for its hierarchy_path"});
            continue;
        }
        const auto fromKey = wire.hierarchy_path + ":" + wire.from_instance;
        const auto toKey = wire.hierarchy_path + ":" + wire.to_instance;
        const auto from = createdTerminalNets.find(fromKey);
        const auto to = createdTerminalNets.find(toKey);
        if (from == createdTerminalNets.end() || to == createdTerminalNets.end() ||
            from->second.count(wire.from_terminal) == 0 ||
            to->second.count(wire.to_terminal) == 0 ||
            from->second.at(wire.from_terminal) != wire.net ||
            to->second.at(wire.to_terminal) != wire.net) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "point-to-point wire " + wire.net + " endpoint is not a newly created instance pin on that net"});
            continue;
        }
        const auto directKey = fromKey + "." + wire.from_terminal + "->" + toKey + "." +
            wire.to_terminal + ":" + wire.net;
        if (!directWireKeys.insert(directKey).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "duplicate point-to-point wire " + wire.net});
        }
    }
    for (const auto& port : plan.create_ports) {
        if (port.hierarchy_path.empty() || port.name.empty() || port.direction.empty() ||
            port.net.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "new port contract is incomplete"});
        }
        if (clonesByPath.count(port.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "new port has no isolated clone mapping for its hierarchy_path"});
        }
    }
    for (const auto& wire : plan.wires) {
        if (wire.hierarchy_path.empty() || wire.net.empty() || wire.points.size() < 2) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "wire must have a hierarchy, net and at least two points"});
        }
        if (clonesByPath.count(wire.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "wire has no isolated clone mapping for its hierarchy_path"});
        }
    }
    std::set<std::string> deletedNames;
    for (const auto& deletion : plan.delete_instances) {
        if (deletion.hierarchy_path.empty() || deletion.name.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "delete instance contract is incomplete"});
        }
        if (clonesByPath.count(deletion.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "delete instance has no isolated clone mapping for its hierarchy_path"});
        }
        if (!deletedNames.insert(deletion.hierarchy_path + ":" + deletion.name).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "duplicate delete instance in the same hierarchy: " + deletion.name});
        }
    }
    if (!plan.check_and_save) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "a formal OA materialization plan must perform check/save"});
    }
    return diagnostics;
}

OaPlanBuildResult BuildOaMaterializationPlan(const Netlist& baseline,
                                             const Netlist& variant,
                                             const DeviceCatalog& catalog,
                                             const OaPlanBuildContext& context)
{
    OaPlanBuildResult result;
    auto& plan = result.plan;
    plan.source = context.source;
    plan.target = context.target;
    plan.clone_map = context.clone_map;
    plan.preview = context.preview;
    plan.wires = context.wires;

    for (const auto& variantSubckt : variant.subckts) {
        const auto* baseSubckt = baseline.find(variantSubckt.name);
        if (baseSubckt != nullptr && sameSubcktForOa(*baseSubckt, variantSubckt)) {
            continue;
        }
        const auto pathIt = context.hierarchy_by_subckt.find(variantSubckt.name);
        if (pathIt == context.hierarchy_by_subckt.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "subckt " + variantSubckt.name + " lacks a hierarchy_path mapping"});
            continue;
        }
        const std::string& hierarchy = pathIt->second;
        if (baseSubckt == nullptr) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "the current version does not support creating an entire subckt in the OA plan"});
            continue;
        }
        std::set<std::string> baselineNets(baseSubckt->pins.begin(), baseSubckt->pins.end());
        for (const auto& instance : baseSubckt->instances) {
            baselineNets.insert(instance.nets.begin(), instance.nets.end());
        }
        struct CreatedEndpoint {
            std::string instance;
            std::string terminal;
            std::string semantic;
        };
        std::map<std::string, std::vector<CreatedEndpoint>> createdEndpointsByNet;
        for (const auto& original : baseSubckt->instances) {
            const auto* changed = variantSubckt.find(original.name);
            if (changed == nullptr || !sameInstance(original, *changed)) {
                plan.delete_instances.push_back({ hierarchy, original.name });
            }
        }
        for (const auto& changed : variantSubckt.instances) {
            const auto* original = baseSubckt->find(changed.name);
            if (original != nullptr && sameInstance(*original, changed)) {
                continue;
            }
            const auto* descriptor = catalog.Find(changed.model);
            if (descriptor == nullptr || descriptor->oa_library.empty() ||
                descriptor->oa_cell.empty() || descriptor->oa_view.empty() ||
                descriptor->terminal_names_by_index.size() != changed.nets.size()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "device " + changed.model + " lacks an OA master or a complete terminalOrder"});
                continue;
            }
            const std::string locationKey = hierarchy + ":" + changed.name;
            const auto location = context.locations.find(locationKey);
            if (location == context.locations.end()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "instance " + locationKey + " lacks an explicit placement location"});
                continue;
            }
            OaCreateInstance create;
            create.hierarchy_path = hierarchy;
            create.name = changed.name;
            create.master = { descriptor->oa_library, descriptor->oa_cell,
                              descriptor->oa_view };
            create.location = location->second;
            create.expected_terminal_count = descriptor->terminal_count;
            create.bit_count = MosArrayBitCount(changed.name);
            create.cdf_parameters = changed.params;

            std::vector<TerminalRole> roles(descriptor->terminal_count, TerminalRole::Other);
            if (descriptor->terminal_roles_by_index.size() == descriptor->terminal_count) {
                roles = descriptor->terminal_roles_by_index;
            } else {
                for (const auto& [role, index] : descriptor->terminal_index) {
                    roles[index] = role;
                }
            }
            for (std::size_t index = 0; index < changed.nets.size(); ++index) {
                const auto semantic = roleName(roles[index]);
                const auto& terminal = descriptor->terminal_names_by_index[index];
                create.connections.push_back({ semantic, terminal, changed.nets[index] });
                createdEndpointsByNet[changed.nets[index]].push_back(
                    {changed.name, terminal, semantic});
            }
            // "visible wire" 校验已移除：占位导线 (FillPlaceholderLocations)
            // 因网格 snap 短路问题不再生成，SKILL 端 MaauTopologyConnectTerminal
            // 从实际 pin center 创建连线，无需 plan 提供可见导线。
            plan.create_instances.push_back(std::move(create));
        }

        for (const auto& [net, endpoints] : createdEndpointsByNet) {
            if (baselineNets.count(net) != 0 || endpoints.size() < 2) {
                continue;
            }
            const bool seriesNode = std::all_of(endpoints.begin(), endpoints.end(),
                [](const CreatedEndpoint& endpoint) {
                    return endpoint.semantic == "Drain" ||
                        endpoint.semantic == "Source" ||
                        endpoint.semantic == "Positive" ||
                        endpoint.semantic == "Negative";
                });
            if (!seriesNode) {
                continue;
            }
            for (std::size_t index = 1; index < endpoints.size(); ++index) {
                plan.direct_wires.push_back({
                    hierarchy, net,
                    endpoints[index - 1].instance, endpoints[index - 1].terminal,
                    endpoints[index].instance, endpoints[index].terminal
                });
            }
        }

        for (const auto& pin : variantSubckt.pins) {
            if (std::find(baseSubckt->pins.begin(), baseSubckt->pins.end(), pin) !=
                baseSubckt->pins.end()) {
                continue;
            }
            const std::string key = hierarchy + ":" + pin;
            const auto direction = context.port_directions.find(key);
            const auto location = context.locations.find(key);
            if (direction == context.port_directions.end() || location == context.locations.end()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "new port " + key + " lacks a direction or placement location"});
                continue;
            }
            plan.create_ports.push_back({ hierarchy, pin, direction->second, pin,
                                          location->second });
        }
    }
    const auto validation = ValidateOaPlan(plan);
    result.diagnostics.insert(result.diagnostics.end(), validation.begin(), validation.end());
    return result;
}

} // namespace st
