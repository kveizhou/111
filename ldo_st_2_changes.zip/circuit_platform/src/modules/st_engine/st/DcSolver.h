#pragma once
// =============================================================
// DcSolver.h — Cascode 单复制原管＋单偏置电阻的 DC 闭环求解器
// 每个候选只量化 R_BIAS，固定复制管与新增管尺寸；重建完整 Cascode
// 候选后交给宿主 DC，再检查原管/复制管工作区、Cascode 饱和及可靠性。
// 最多 20 次调 R 的名义 DC，无可行解不接受；入选 R 逐 PVT Corner 固定复验。
// =============================================================
#include "AutoBias.h"
#include "Netlist.h"
#include "OperatingPoint.h"
#include "ResistorStress.h"
#include "Types.h"

#include <string>
#include <map>
#include <optional>
#include <vector>

namespace st {

// 诊断指标，仅供求解轨迹及最终报告使用，不能代替通过判据。
struct DcCandidateMetrics {
    double branch_current_error = 0.0;
    double control_op_error = 0.0;
    double iq_delta = 0.0;
    double reliability_margin = 0.0;
    double saturation_margin = 0.0;
    double area_estimate = 0.0;
    double saturation_deficit = 0.0;
};

// 一个待校验 MOS 的逻辑角色。leaf_name 是器件在未封装候选中的实例名；
// container_instance 非空时表示最终 Virtuoso 封装实例。OP 提取器可以输出
// leaf_name，也可以输出 container.leaf/container/leaf/container:leaf，校验器
// 只在唯一匹配时接受，避免多套 VBIAS 角色同名时串读工作点。
struct ElectricalMosRole {
    std::string container_instance;
    std::string leaf_name;
    DeviceLimits limits;
    bool reliability_complete = true;
};

// 候选和最终 staging 共用的电气硬约束输入。所有字段均为值对象，便于把
// 求解时选中的真实 PDK 限值原样带到最终物化门禁。
struct ElectricalConstraintRequest {
    std::string operation_id;
    DeviceKind polarity = DeviceKind::Other;
    ElectricalMosRole control_replica;
    ElectricalMosRole actual_control;
    ElectricalMosRole actual_cascode;
    ExpectedResistor bias_resistor;  // 复制原管 Source 与 VS_ORIG 之间的 R_BIAS
    MosOperatingPoint baseline_control;
    // 两项上限可同时省略做 DC 可行性求参；提供时须成对、有限且为正数。
    std::optional<double> max_branch_current_error; // 相对基线电流的无量纲偏差
    std::optional<double> max_vbias_current;        // 单条 VBIAS 支路电流，单位 A
    bool experimental_dc = false;
    bool native_parameter_trials = false;
    std::vector<std::string> unverified_constraints;
};

struct ElectricalConstraintResult {
    bool ok = false;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    std::string first_failed_constraint;
    // Missing keys are unverified, not a true/false verdict; trace serializes them as null.
    std::map<std::string, bool> constraints;
    DcCandidateMetrics metrics;
    double vbias_voltage = 0.0;
};

// 对真实主通路、一只模板复制 MOS 和一只 R_BIAS 执行同一套硬约束。
// converged=false 返回 not_converged；缺少或不唯一的层级实例返回 incomplete_snapshot。
ElectricalConstraintResult EvaluateElectricalConstraints(
    const OperatingPointSnapshot& snapshot,
    const ElectricalConstraintRequest& request,
    bool converged = true);

// 交给宿主的单次 DC 评估请求。candidate = 基线网表 + VBIAS 模板子电路
// （含当前量化参数）+ 顶层模板实例；identity 为名义 Corner 身份。
struct DcEvaluationRequest {
    Netlist candidate;
    std::string root_subckt;
    std::string target_instance;
    std::string cascode_instance;
    AnalysisIdentity identity;
    std::string operation_id;
};

// 宿主契约：对候选网表运行名义 DC 工作点。
// 返回 false 且 diagnostic 非空表示执行/读取失败，停止搜索，不判电气无解。
// 已确认不收敛时返回 false、diagnostic 留空；允许继续其它参数点。
// 返回快照可用唯一复制管角色名（如 "N_CTRL_REP_N"）定位；
// R_BIAS 必须出现在 snapshot.resistors 中，包含实际端电位、电流及
// 当前 master/几何/Corner 的 PDK 额定值。真实宿主先核对 OA 回读再仿真。
class DcEvaluationHost {
public:
    virtual ~DcEvaluationHost() = default;
    virtual bool Evaluate(const DcEvaluationRequest&,
                          OperatingPointSnapshot&,
                          Diagnostic&) = 0;
};

// 单个 PVT Corner 的复验结论：固定名义可行参数，复用全部硬约束。
// ok=false 时 failed_constraint 给出第一个失败的约束名
// （如 reliability_vgs，对应规格举例的 max_abs_vgs 类约束）。
struct PvtCornerResult {
    std::string corner;
    bool ok = false;
    std::string failed_constraint;
};

struct AutoBiasSolveResult {
    bool ok = false;
    bool best_effort = false; // 有完整收敛点，但未通过最低DC条件
    bool evaluation_failed = false;
    std::size_t selected_candidate = 0; // 与trace的candidate一致，0表示未选中
    std::vector<std::string> failed_constraints;
    bool native_parameter_trials = false;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    BiasSizing sizing;                 // 首个可行或自动选出的待优化候选参数
    DcCandidateMetrics metrics;        // 可行候选的诊断指标
    std::vector<std::string> trace_lines; // 确定性 JSONL，两次运行字节一致
    std::vector<Diagnostic> diagnostics;
    // pvt_corners 非空时逐 Corner 复验（不换参数、不重排名）；
    // 配置了 PVT 且全部 Corner 通过时 pvt_ready=true，未配置恒 false。
    std::vector<PvtCornerResult> pvt_results;
    bool pvt_ready = false;
    // 求解成功时给最终 staging 复用；容器实例名由封装阶段补齐。
    ElectricalConstraintRequest electrical_check;
    std::size_t device_combinations = 0;
    std::size_t searched_device_combinations = 0;
    std::size_t nominal_evaluations = 0;
    std::size_t pvt_evaluations = 0;
    bool parameter_search_truncated = false;
};

struct AutoBiasSolveRequest {
    Netlist baseline;                  // 基线网表（提供原管实例参数）
    std::string root_subckt;
    std::string target_instance;       // 原 MOS 实例名
    AutoBiasTemplateRequest template_request;
    OperatingPointSnapshot baseline_op; // 基线 DC 工作点（含目标实例）
    AnalysisIdentity nominal_identity;
    // 候选电路必须按与最终生成相同的 Bulk 策略实际执行
    // Cascode 变换，不允许只仿真一个脱离主电路的 VBIAS 模板。
    std::string nmos_bulk_net;
    bool tie_isolated_pmos_to_source = true;
    // 与 CascodeTransformRequest 相同：求解候选和最终生成共用尺寸覆盖。
    std::optional<double> custom_width;
    std::optional<double> custom_finger_width;
    std::optional<double> custom_fingers;
    std::optional<double> custom_length;
    std::vector<std::string> pvt_corners; // Task 9 使用；Task 6 只求名义 Corner
    // 两项上限可同时省略做 DC 可行性求参；提供时须成对、有限且为正数。
    std::optional<double> max_branch_current_error;
    std::optional<double> max_vbias_current;
    // These groups retain their selected parameters in baseline. Experimental
    // search defers their electrical checks to final full-circuit validation;
    // non-experimental search checks them in each current-trial DC snapshot.
    std::vector<ElectricalConstraintRequest> preceding_checks;
};

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest&,
                                  const DeviceCatalog&,
                                  DcEvaluationHost&);

} // namespace st
