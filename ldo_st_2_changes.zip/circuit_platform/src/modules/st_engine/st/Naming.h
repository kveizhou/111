#pragma once

#include "Netlist.h"

#include <map>
#include <set>
#include <string>

namespace st {

enum class NameKind {
    Instance,
    Net,
    Subckt,
};

// 识别名称中的完整_vectored范围（如 I82<29:0>_CAS）。单个下标 I7<0>
// 不属于范围阵列，继续按普通标量名称清洗。返回值保留尖括号，
// 便于 Spectre、OA 计划和 SKILL 使用同一阵列语法。
// 把 GUI/Virtuoso 的方括号统一为内部和 Spectre 使用的尖括号；层次分隔符不变。
std::string NormalizeMosArrayName(std::string name);
std::string MosArrayRange(const std::string& name);
std::size_t MosArrayBitCount(const std::string& name);

// 为一次物化分配可重复、无冲突的名称。同样的原电路和操作顺序
// 必须得到完全相同的结果，因此这里不使用随机数、时间戳或进程号。
class NameAllocator {
public:
    explicit NameAllocator(const Netlist& netlist, const std::string& subcktScope = {});

    std::string Allocate(NameKind kind, const std::string& base);

private:
    std::set<std::string>& Names(NameKind kind);

    std::set<std::string> instanceNames_;
    std::set<std::string> netNames_;
    std::set<std::string> subcktNames_;
};

} // namespace st
