#pragma once
// =============================================================
// AutoBias.h — 单复制原管＋单偏置电阻的 VBIAS 模板
// 每个 Cascode 操作生成独立模板，不接收 IREF 或手工 VBIAS。
// 复制原管保持原 Gate，Source 输出 VBIAS，并经 R_BIAS 接回原 Source；
// 不使用镜像 MOS、参考电阻或固定 PDK Cell 名。
// =============================================================
#include "Bias.h"
#include "Types.h"

#include <map>
#include <string>
#include <vector>

namespace st {

// 求解结果：新增 Cascode 管参数 + 模板内复制管和 R_BIAS 参数。
// element_parameters 必须按角色名存取，禁止按实例顺序对应。
struct BiasSizing {
    std::map<std::string, std::string> cascode_parameters;
    std::map<std::string, std::map<std::string, std::string>> element_parameters;
    double nominal_voltage = 0.0;
    double iq_delta = 0.0;
    // 求解选中的真实电阻 master，重建、PVT、封装必须保持该身份。
    std::string resistor_master;
};

struct AutoBiasTemplateRequest {
    std::string operation_id;
    DeviceKind polarity = DeviceKind::Other;   // 只允许 MosN / MosP
    std::string voltage_domain;
    std::string vhigh_net;
    std::string vlow_net;
    std::string original_source_net;           // 变换前原 MOS 的 Source 网络
    std::string control_gate_net;              // 原 MOS Gate 网络（只感知，不改写）
    std::string control_master;                // 原管 master（Control Replica 使用）
    std::string cascode_master;                // 新增管 master
    // 原目标为 I82<29:0> 时填 "<29:0>"，模板各角色保持同一阵列范围；
    // 标量或单下标器件留空。
    std::string array_range;
    bool experimental_dc = false;
};

// 求解器预检与模板构建共享选型规则，防止两处口径分叉。
struct AutoBiasDevicePlan {
    const DeviceDescriptor* control = nullptr;
    const DeviceDescriptor* cascode = nullptr;
    const DeviceDescriptor* resistor = nullptr;
};

// 校验原管、新增管及真实电阻，返回三类器件的兼容组合。
bool SelectAutoBiasDevices(const AutoBiasTemplateRequest& request,
                           const DeviceCatalog& catalog,
                           AutoBiasDevicePlan& plan,
                           Diagnostic& diagnostic);

// 电阻优先控制管来源 Library，同级按稳定 master 名选择，不按性能排名。
bool SelectAutoBiasDeviceCandidates(const AutoBiasTemplateRequest& request,
                                    const DeviceCatalog& catalog,
                                    std::vector<AutoBiasDevicePlan>& plans,
                                    Diagnostic& diagnostic);

// 只接受目录明确登记的数值CDF参数，校验映射、类型与范围后量化。
// require_unchanged 用于原管Replica，任何量化改值都应拒绝以保持与原管一致。
// native_parameter_trials 仅 experimental_dc 接受，输入必须已属于有限试点集合。
struct QuantizeAutoBiasOptions {
    bool require_unchanged = false;
    bool experimental_dc = false;
};

struct QuantizeAutoBiasResult {
    bool ok = false;
    std::map<std::string, std::string> out;
    Diagnostic diagnostic;
};

QuantizeAutoBiasResult QuantizeAutoBiasParameters(
    const DeviceDescriptor& descriptor,
    const std::map<std::string, std::string>& parameters,
    const std::string& role,
    const QuantizeAutoBiasOptions& options = {});

struct Instance;

// 给齐一只复制原管与一只偏置电阻的结构初值；该初值不代表 DC 通过。
bool InitialStructuralBias(const AutoBiasTemplateRequest& request, const DeviceCatalog& catalog,
                           const Instance& original, BiasSizing& sizing, Diagnostic& diagnostic);

// 工程格式不能精确回读时使用17位有效数字，保持量化值的double往返精度。
std::string FormatAutoBiasParameter(double value);

struct AutoBiasTemplateResult {
    bool ok = false;
    std::string template_id;                   // VBIAS_N_CASCODE_AUTO / VBIAS_P_CASCODE_AUTO
    std::string output_net;                    // VBIAS_N / VBIAS_P
    std::vector<std::string> ports;            // 固定端口顺序
    std::vector<BiasElementPlan> elements;     // 严格一只复制原管＋一只 R_BIAS
    std::vector<Diagnostic> diagnostics;
};

// 从动态 PDK 目录选择真实电阻，按单 MOS＋单 R 构造固定拓扑。
// 失败时 ok=false 且 diagnostics 给出第一个原因；不做任何猜测性降级。
AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest& request,
    const BiasSizing& sizing,
    const DeviceCatalog& catalog);

} // namespace st
