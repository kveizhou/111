#pragma once

#include "DcSolver.h"

#include <cstddef>
#include <optional>
#include <string>

namespace st {

// 仅决定下一次真实 DC 的 R，不估算工作区，也不把结构检查当作仿真。
struct ResistanceBiasSearchConfig {
    DeviceKind polarity = DeviceKind::Other;
    bool original_was_saturated = true;
    double initial_vds = 0.0;
    double initial_current = 0.0;
    ParameterConstraint resistance;
    // 最多 20 个调 R 的名义 DC 候选；固定 R 的 PVT 复验不计入此上限。
    std::size_t max_evaluations = 20;
};

struct ResistanceBiasFeedback {
    bool converged = false;
    bool original_region_ok = false;
    bool cascode_saturated = false;
};

class ResistanceBiasSearch {
public:
    explicit ResistanceBiasSearch(const ResistanceBiasSearchConfig& config);

    bool valid() const { return valid_; }
    bool finished() const { return finished_; }
    bool solved() const { return solved_; }
    double next() const { return next_; }
    std::size_t evaluations() const { return evaluations_; }
    const std::string& reason() const { return reason_; }
    void Update(const ResistanceBiasFeedback& feedback);

private:
    DeviceKind polarity_ = DeviceKind::Other;
    bool originalWasSaturated_ = true;
    bool valid_ = false;
    bool finished_ = false;
    bool solved_ = false;
    double next_ = 0.0;
    double previous_ = 0.0;
    std::optional<double> lower_;
    std::optional<double> upper_;
    std::optional<int> lastDirection_;
    std::size_t evaluations_ = 0;
    std::size_t maxEvaluations_ = 0;
    ParameterConstraint constraint_;
    std::string reason_;
};

// 固定 MOS 尺寸，只迭代 R_BIAS；每次均构建完整候选并调用真实宿主 DC。
AutoBiasSolveResult SolveCascodeResistanceBias(const AutoBiasSolveRequest& request,
                                               const DeviceCatalog& catalog,
                                               DcEvaluationHost& host);

} // namespace st
