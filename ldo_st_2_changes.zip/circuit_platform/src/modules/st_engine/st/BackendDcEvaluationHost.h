#pragma once

#include "DcSolver.h"
#include "Packaging.h"
#include "Standalone.h"
#include "VirtuosoBackend.h"

#include <filesystem>
#include <map>
#include <ostream>
#include <string>

namespace st::standalone {

struct CellViewRefs {
    CellViewRef source;
    CellViewRef bench;
};

struct CandidateHostConfig {
    Netlist baseline;
    const DeviceCatalog& catalog;
    RootGeometry geometry;
    std::string rootSubckt;
    std::string candidateLibrary;
    std::string candidatePrefix;
    std::filesystem::path skillScript;
    std::filesystem::path candidateDir;
    bool reuseTemplate = true;
};

// 真实候选 DC：OA 物化与回读验证成功后，才允许后端运行 OP。
class BackendDcEvaluationHost : public DcEvaluationHost {
public:
    BackendDcEvaluationHost(ProcessVirtuosoBackend& backend, CellViewRefs views,
                            CandidateHostConfig config, std::ostream& progress);

    void SetPreceding(const Netlist& variant, const ChangeSet& changes,
                      const ReplayResult& replay);

    bool Evaluate(const DcEvaluationRequest& request,
                  OperatingPointSnapshot& snapshot, Diagnostic& diagnostic) override;

private:
    static std::string PlanStructure(OaMaterializationPlan plan);

    std::string templateCell_;
    OaMaterializationPlan templatePlan_;
    Netlist parentReadback_;
    std::map<std::string, Netlist> childReadbacks_;
    ProcessVirtuosoBackend& backend_;
    CellViewRef source_;
    CellViewRef bench_;
    Netlist baseline_;
    Netlist precedingVariant_;
    ChangeSet precedingChanges_;
    ReplayResult precedingReplay_;
    const DeviceCatalog& catalog_;
    RootGeometry geometry_;
    std::string rootSubckt_;
    std::string candidateLibrary_;
    std::string candidatePrefix_;
    std::filesystem::path skillScript_;
    std::filesystem::path candidateDir_;
    bool reuseTemplate_;
    std::ostream& progress_;
    std::size_t counter_ = 0;
};

} // namespace st::standalone
