#include "st/VirtuosoBackend.h"
#include "st/Standalone.h"
#include "st/JsonWriter.h"
#include "st/PdkCatalog.h"

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace st::standalone {
namespace {

void addCellView(std::vector<std::string>& arguments, const std::string& prefix,
                 const CellViewRef& cellView)
{
    arguments.push_back("--" + prefix + "-lib");
    arguments.push_back(cellView.library);
    arguments.push_back("--" + prefix + "-cell");
    arguments.push_back(cellView.cell);
    arguments.push_back("--" + prefix + "-view");
    arguments.push_back(cellView.view);
    if (!cellView.storage_path.empty()) {
        arguments.push_back("--" + prefix + "-storage");
        arguments.push_back(cellView.storage_path);
    }
}

HostStatus missingArtifact(const std::filesystem::path& path,
                           const std::filesystem::path& logPath)
{
    return {false, "backend did not generate the expected file or the file is empty: " + path.string(),
            logPath.string(), path.string()};
}

std::string safeArtifactName(const std::string& value)
{
    std::string result;
    result.reserve(value.size());
    for (const unsigned char character : value) {
        result.push_back(std::isalnum(character) || character == '_'
            ? static_cast<char>(character) : '_');
    }
    return result.empty() ? "subckt" : result;
}

bool canonicalOutputPath(const std::filesystem::path& requested,
                         std::filesystem::path& resolved,
                         std::string& message)
{
    std::error_code error;
    auto absolute = std::filesystem::absolute(requested, error);
    if (error) {
        message = error.message();
        return false;
    }
    resolved = std::filesystem::weakly_canonical(absolute, error);
    if (error) {
        message = error.message();
        return false;
    }
    resolved = resolved.lexically_normal();
    return true;
}

bool outputPathsConflict(const std::vector<std::filesystem::path>& paths)
{
    for (std::size_t left = 0; left < paths.size(); ++left) {
        for (std::size_t right = left + 1; right < paths.size(); ++right) {
            if (paths[left] == paths[right]) {
                return true;
            }
            std::error_code error;
            const bool leftExists = std::filesystem::exists(paths[left], error);
            if (error || !leftExists) {
                continue;
            }
            error.clear();
            const bool rightExists = std::filesystem::exists(paths[right], error);
            if (error || !rightExists) {
                continue;
            }
            error.clear();
            if (std::filesystem::equivalent(paths[left], paths[right], error) && !error) {
                return true;
            }
        }
    }
    return false;
}

bool pathObjectExists(const std::filesystem::path& path, std::error_code& error)
{
    const auto status = std::filesystem::symlink_status(path, error);
    if (error == std::errc::no_such_file_or_directory) {
        error.clear();
        return false;
    }
    return !error && status.type() != std::filesystem::file_type::not_found;
}

bool protectedArtifactType(const std::filesystem::path& path,
                           std::string& message)
{
    std::error_code error;
    const auto status = std::filesystem::symlink_status(path, error);
    if (error == std::errc::no_such_file_or_directory) {
        error.clear();
        return true;
    }
    if (error) {
        message = "cannot check old operating point output " + path.string() + ": " +
            error.message();
        return false;
    }
    if (status.type() == std::filesystem::file_type::not_found ||
        status.type() == std::filesystem::file_type::regular ||
        status.type() == std::filesystem::file_type::symlink) {
        return true;
    }
    message = "operating point output path only permits regular files or protected symlinks: " +
        path.string();
    return false;
}

bool generatedRegularFile(const std::filesystem::path& path,
                          std::error_code& error)
{
    const auto status = std::filesystem::symlink_status(path, error);
    return !error && status.type() == std::filesystem::file_type::regular;
}

bool completeCellView(const CellViewRef& cellView)
{
    return !cellView.library.empty() && !cellView.cell.empty() &&
        !cellView.view.empty();
}

struct MovedArtifact {
    std::filesystem::path path;
    std::filesystem::path backup;
    bool moved = false;
};

class ArtifactTransaction {
public:
    explicit ArtifactTransaction(std::vector<std::filesystem::path> paths)
    {
        artifacts_.reserve(paths.size());
        for (auto& path : paths) {
            artifacts_.push_back({std::move(path), {}, false});
        }
    }

    bool Begin(std::string& message)
    {
        for (const auto& artifact : artifacts_) {
            if (!protectedArtifactType(artifact.path, message)) {
                return false;
            }
        }
        for (std::size_t index = 0; index < artifacts_.size(); ++index) {
            auto& artifact = artifacts_[index];
            std::error_code error;
            const bool exists = pathObjectExists(artifact.path, error);
            if (error) {
                message = "cannot check old operating point output: " + error.message();
                Rollback();
                return false;
            }
            if (!exists) {
                continue;
            }
            artifact.backup = uniqueBackupPath(artifact.path, index);
            std::filesystem::rename(artifact.path, artifact.backup, error);
            if (error) {
                message = "cannot protect old operating point output: " + error.message();
                Rollback();
                return false;
            }
            artifact.moved = true;
        }
        active_ = true;
        return true;
    }

    void Rollback()
    {
        for (auto iterator = artifacts_.rbegin(); iterator != artifacts_.rend(); ++iterator) {
            std::error_code error;
            std::filesystem::remove(iterator->path, error);
            if (error) {
                // A provider may have produced a non-empty directory or other
                // unexpected object.  Preserve it under a quarantine name so
                // the caller's protected artifact can still be restored.
                error.clear();
                std::filesystem::rename(
                    iterator->path, uniqueRejectedPath(iterator->path), error);
            }
            if (!iterator->moved) {
                continue;
            }
            error.clear();
            std::filesystem::rename(iterator->backup, iterator->path, error);
        }
        active_ = false;
    }

    bool Commit(std::string& message)
    {
        // Publishing is irreversible at this point.  Disable destructor
        // rollback before best-effort backup cleanup so a cleanup failure can
        // never delete the newly committed artifacts.
        active_ = false;
        std::vector<std::filesystem::path> retainedBackups;
        for (auto& artifact : artifacts_) {
            if (!artifact.moved) {
                continue;
            }
            std::error_code error;
            std::filesystem::remove(artifact.backup, error);
            if (error) {
                retainedBackups.push_back(artifact.backup);
                continue;
            }
            artifact.moved = false;
        }
        if (retainedBackups.empty()) {
            return true;
        }
        std::ostringstream details;
        details << "new operating point output committed, but backup could not be deleted; manually inspect the retained path: ";
        for (std::size_t index = 0; index < retainedBackups.size(); ++index) {
            if (index != 0) {
                details << ", ";
            }
            details << retainedBackups[index].string();
        }
        message = details.str();
        return false;
    }

    ~ArtifactTransaction()
    {
        if (active_) {
            Rollback();
        }
    }

private:
    static std::filesystem::path uniqueBackupPath(
        const std::filesystem::path& path, std::size_t index)
    {
        const auto stem = path.string() + ".st-op-backup-" +
            std::to_string(static_cast<long long>(getpid())) + "-" +
            std::to_string(index);
        std::filesystem::path candidate(stem);
        std::size_t attempt = 0;
        std::error_code error;
        while (pathObjectExists(candidate, error) && !error) {
            candidate = stem + "-" + std::to_string(++attempt);
        }
        return candidate;
    }

    static std::filesystem::path uniqueRejectedPath(
        const std::filesystem::path& path)
    {
        const auto stem = path.string() + ".st-op-rejected-" +
            std::to_string(static_cast<long long>(getpid()));
        std::filesystem::path candidate(stem);
        std::size_t attempt = 0;
        std::error_code error;
        while (pathObjectExists(candidate, error) && !error) {
            candidate = stem + "-" + std::to_string(++attempt);
        }
        return candidate;
    }

    std::vector<MovedArtifact> artifacts_;
    bool active_ = false;
};

std::vector<std::string> splitTsv(const std::string& line)
{
    std::vector<std::string> fields;
    std::size_t begin = 0;
    while (true) {
        const auto end = line.find('\t', begin);
        fields.push_back(line.substr(begin, end - begin));
        if (end == std::string::npos) {
            break;
        }
        begin = end + 1;
    }
    return fields;
}

std::set<std::string> splitCommaSet(const std::string& value)
{
    std::set<std::string> result;
    std::size_t begin = 0;
    while (begin <= value.size()) {
        const auto end = value.find(',', begin);
        const auto item = value.substr(begin, end - begin);
        if (!item.empty()) {
            result.insert(item);
        }
        if (end == std::string::npos) {
            break;
        }
        begin = end + 1;
    }
    return result;
}

struct ScanIdentityEvidence {
    std::string process_identity;
    std::string pdk_name;
    std::string pdk_version;
    std::set<std::string> candidate_libraries;
};

bool loadCompleteScanIdentity(const std::filesystem::path& path,
                              ScanIdentityEvidence& evidence,
                              std::string& message)
{
    std::ifstream input(path);
    std::string headerLine;
    std::string rowLine;
    if (!std::getline(input, headerLine) || !std::getline(input, rowLine)) {
        message = "PDK identity missing header or data record";
        return false;
    }
    const auto header = splitTsv(headerLine);
    const auto row = splitTsv(rowLine);
    const auto field = [&header, &row](const std::string& name) -> std::string {
        const auto found = std::find(header.begin(), header.end(), name);
        if (found == header.end()) {
            return {};
        }
        const auto index = static_cast<std::size_t>(found - header.begin());
        return index < row.size() ? row[index] : std::string{};
    };
    evidence.process_identity = field("process_identity");
    evidence.pdk_name = field("pdk_name");
    evidence.pdk_version = field("pdk_version");
    if (evidence.process_identity.empty() ||
        field("context_complete") != "true") {
        message = "PDK identity source tech context incomplete";
        return false;
    }
    if (evidence.pdk_name.empty() || evidence.pdk_version.empty()) {
        message = "PDK identity missing pdk_name or pdk_version";
        return false;
    }
    if (field("scan_complete") != "true") {
        message = "PDK identity does not declare scan_complete=true";
        const auto diagnostic = field("diagnostic");
        if (!diagnostic.empty()) {
            message += ": " + diagnostic;
        }
        return false;
    }
    evidence.candidate_libraries =
        splitCommaSet(field("candidate_libraries"));
    if (evidence.candidate_libraries.empty()) {
        message = "PDK identity has no proven candidate_libraries";
        return false;
    }
    return true;
}

bool provenSource(const std::string& value)
{
    if (value.empty()) {
        return false;
    }
    std::string lower;
    lower.reserve(value.size());
    std::transform(value.begin(), value.end(), std::back_inserter(lower),
                   [](unsigned char character) {
                       return static_cast<char>(std::tolower(character));
                   });
    return lower != "missing" && lower != "unknown" &&
        lower.find("inference") == std::string::npos &&
        lower.find("guess") == std::string::npos;
}
bool validateCatalogEvidence(const std::filesystem::path& path,
                             const ScanIdentityEvidence& identity,
                             std::string& message, bool structureOnly, bool experimentalDc)
{
    if (structureOnly && experimentalDc) {
        message = "structure_only and experimental_dc must not be combined";
        return false;
    }
    std::ifstream input(path);
    std::string headerLine;
    if (!std::getline(input, headerLine)) {
        message = "PDK catalog missing header";
        return false;
    }
    const auto header = splitTsv(headerLine);
    const auto indexOf = [&header](const std::string& name) {
        const auto found = std::find(header.begin(), header.end(), name);
        return found == header.end()
            ? header.size()
            : static_cast<std::size_t>(found - header.begin());
    };
    const std::vector<std::string> required = {
        "master", "kind", "oa_library", "pdk_name", "pdk_version",
        "parameter_constraints", "reliability_complete", "bulk_rule_complete",
        "process_identity", "kind_source", "terminal_source", "cdf_source",
        "reliability_source", "bulk_source", "domain_source", "corner_source",
        "device_proof_source"};
    for (const auto& name : required) {
        if (indexOf(name) == header.size()) {
            message = "PDK catalog missing evidence column: " + name;
            return false;
        }
    }
    bool hasDevice = false;
    std::string line;
    std::size_t rowNumber = 1;
    while (std::getline(input, line)) {
        ++rowNumber;
        if (line.empty()) {
            continue;
        }
        const auto row = splitTsv(line);
        const auto field = [&indexOf, &row](const std::string& name) -> std::string {
            const auto index = indexOf(name);
            return index < row.size() ? row[index] : std::string{};
        };
        const std::string master = field("master");
        if (master.empty()) {
            message = "line " + std::to_string(rowNumber) +
                " of PDK catalog has empty master";
            return false;
        }
        if (!identity.candidate_libraries.count(field("oa_library"))) {
            message = "PDK catalog includes unproven device library: " +
                field("oa_library");
            return false;
        }
        if (field("process_identity") != identity.process_identity ||
            field("pdk_name") != identity.pdk_name ||
            field("pdk_version") != identity.pdk_version) {
            message = "PDK catalog device does not belong to the current DUT process: " + master;
            return false;
        }
        const auto kind = field("kind");
        std::vector<std::string> requiredSources{
            "kind_source", "terminal_source", "device_proof_source"};
        if (kind == "resistor") {
            requiredSources.push_back("cdf_source");
            if (!structureOnly && !experimentalDc) {
                requiredSources.insert(requiredSources.end(), {"domain_source", "corner_source"});
            }
        } else if (kind == "mos_n" || kind == "mos_p" || (structureOnly && kind == "mos")) {
            // Inventory may include devices unsuitable for automatic biasing.
            // Do not manufacture MOS rules for resistors or three-pin MOS.
            if (field("reliability_complete") == "true") {
                requiredSources.push_back("reliability_source");
            }
            if (field("bulk_rule_complete") == "true") {
                requiredSources.push_back("bulk_source");
            }
        } else {
            message = "PDK catalog includes unsupported device type: " + master;
            return false;
        }
        for (const auto& source : requiredSources) {
            if (!provenSource(field(source))) {
                message = "PDK catalog device " + std::string(source) +
                    " has no verifiable source: " + master;
                return false;
            }
        }
        if (kind == "resistor" && !structureOnly) {
            if (field("parameter_constraints").find("resistance:") ==
                std::string::npos) {
                message = "PDK resistor missing resistance parameter constraint: " + master;
                return false;
            }
        }
        hasDevice = true;
    }
    if (!hasDevice) {
        message = "PDK catalog must contain proven devices";
        return false;
    }
    DeviceCatalog catalog;
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(path, catalog, diagnostics)) {
        message = diagnostics.empty() ? "PDK catalog unparseable" : diagnostics.front().message;
        return false;
    }
    for (const auto& entry : catalog.Descriptors()) {
        const auto& device = entry.second;
        if (device.native_parameter_trials && !experimentalDc) {
            message = "native parameter trials catalog only allows experimental_dc: " + device.master;
            return false;
        }
        const auto count = [&device](TerminalRole role) {
            return std::count(device.terminal_roles_by_index.begin(),
                              device.terminal_roles_by_index.end(), role);
        };
        const auto& names = device.terminal_names_by_index;
        if (std::set<std::string>(names.begin(), names.end()).size() != names.size() ||
            std::find(names.begin(), names.end(), "") != names.end() ||
            (isMosKind(device.kind) && (count(TerminalRole::Drain) != 1 ||
                count(TerminalRole::Gate) != 1 || count(TerminalRole::Source) != 1 ||
                (names.size() == 3 ? count(TerminalRole::Bulk) != 0 :
                                    count(TerminalRole::Bulk) != 1))) ||
            (device.kind == DeviceKind::Resistor &&
                (count(TerminalRole::Positive) != 1 || count(TerminalRole::Negative) != 1))) {
            message = "PDK catalog terminal role evidence incomplete: " + device.master;
            return false;
        }
        if (device.kind == DeviceKind::Resistor) {
            const auto constraint = device.parameter_constraints.find("resistance");
            const auto mapping = device.normalized_to_cdf.find("resistance");
            if (mapping == device.normalized_to_cdf.end() || mapping->second.empty() ||
                (constraint == device.parameter_constraints.end() ? !structureOnly :
                 (mapping->second != constraint->second.cdf_name || !ValidateParameterConstraint(constraint->second)))) {
                message = "PDK resistor missing valid resistance mapping and constraint: " + device.master;
                return false;
            }
        } else if (device.reliability_complete &&
                   (!std::isfinite(device.limits.max_abs_vgs) ||
                    !std::isfinite(device.limits.max_abs_vds) ||
                    !std::isfinite(device.limits.max_abs_vgb) ||
                    device.limits.max_abs_vgs <= 0 ||
                    device.limits.max_abs_vds <= 0 ||
                    device.limits.max_abs_vgb <= 0)) {
            message = "PDK MOS declares full reliability but lacks valid voltage limits: " + device.master;
            return false;
        }
    }
    return true;
}

} // namespace

bool LoadPdkVersionFromScanIdentity(const std::filesystem::path& path,
                                    std::string& version, std::string& message)
{
    ScanIdentityEvidence evidence;
    if (!loadCompleteScanIdentity(path, evidence, message)) return false;
    version = evidence.pdk_version;
    return true;
}

ProcessResult PosixProcessRunner::Run(const std::vector<std::string>& arguments,
                                     const std::filesystem::path& logPath)
{
    if (arguments.empty() || arguments.front().empty()) {
        return {-1, "backend program path is empty"};
    }
    std::error_code error;
    std::filesystem::create_directories(logPath.parent_path(), error);
    if (error) {
        return {-1, "cannot create log directory: " + error.message()};
    }

    const pid_t child = fork();
    if (child < 0) {
        return {-1, "fork failed: " + std::string(std::strerror(errno))};
    }
    if (child == 0) {
        const int descriptor = open(logPath.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (descriptor < 0) {
            _exit(126);
        }
        if (dup2(descriptor, STDOUT_FILENO) < 0 || dup2(descriptor, STDERR_FILENO) < 0) {
            close(descriptor);
            _exit(126);
        }
        close(descriptor);
        std::vector<std::string> argvStorage = arguments;
        std::vector<char*> argv;
        argv.reserve(argvStorage.size() + 1);
        for (auto& argument : argvStorage) {
            argv.push_back(argument.data());
        }
        argv.push_back(nullptr);
        execv(argv.front(), argv.data());
        _exit(errno == ENOENT ? 127 : 126);
    }

    int status = 0;
    if (waitpid(child, &status, 0) < 0) {
        return {-1, "waitpid failed: " + std::string(std::strerror(errno))};
    }
    if (WIFEXITED(status)) {
        const int exitCode = WEXITSTATUS(status);
        return {exitCode, exitCode == 0 ? std::string{} :
            "backend exit code=" + std::to_string(exitCode)};
    }
    if (WIFSIGNALED(status)) {
        return {128 + WTERMSIG(status),
                "backend terminated by signal: " + std::to_string(WTERMSIG(status))};
    }
    return {-1, "backend process status unknown"};
}

ProcessVirtuosoBackend::ProcessVirtuosoBackend(std::filesystem::path executable,
                                               BackendPaths paths,
                                               ProcessRunner& runner)
    : executable_(std::move(executable)), paths_(std::move(paths)), runner_(runner)
{
}

HostStatus ProcessVirtuosoBackend::Snapshot(const CellViewRef& source,
                                            const std::string& coreSubckt,
                                            const SnapshotOutputs& outputs)
{
    std::error_code error;
    std::filesystem::create_directories(outputs.netlist.parent_path(), error);
    if (error) {
        return {false, "cannot create snapshot directory: " + error.message(), {}, {}};
    }
    std::filesystem::remove(outputs.netlist, error);
    error.clear();
    std::filesystem::remove(outputs.catalog, error);
    error.clear();
    std::filesystem::remove(outputs.geometry, error);
    std::vector<std::string> arguments = {
        "--cds-lib", paths_.cds_lib.string(),
        "--lib", source.library,
        "--cell", source.cell,
        "--view", source.view,
        "--core-subckt", coreSubckt,
        "--netlist-output", outputs.netlist.string(),
        "--catalog-output", outputs.catalog.string(),
        "--geometry-output", outputs.geometry.string(),
    };
    if (!paths_.device_policy.empty()) {
        arguments.insert(arguments.end(),
                         {"--device-policy", paths_.device_policy.string()});
    }
    auto status = Run("snapshot", std::move(arguments), paths_.log_dir / "snapshot.log");
    if (!status.ok) {
        return status;
    }
    const std::filesystem::path artifacts[] = {
        outputs.netlist, outputs.catalog, outputs.geometry,
    };
    for (const auto& artifact : artifacts) {
        error.clear();
        if (!std::filesystem::exists(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            return missingArtifact(artifact, paths_.log_dir / "snapshot.log");
        }
    }
    return {true, {}, (paths_.log_dir / "snapshot.log").string(),
            outputs.netlist.string()};
}

HostStatus ProcessVirtuosoBackend::ScanPdk(const CellViewRef& source,
                                           const PdkScanOutputs& outputs)
{
    const auto logPath = paths_.log_dir / "scan_pdk.log";
    std::error_code error;
    if (outputs.raw_catalog_tsv.empty() || outputs.pdk_identity_tsv.empty()) {
        return {false, "PDK scan output path must not be empty", logPath.string(), {}};
    }
    std::filesystem::path catalogPath;
    std::string pathMessage;
    if (!canonicalOutputPath(outputs.raw_catalog_tsv, catalogPath, pathMessage)) {
        return {false, "cannot canonicalize PDK catalog path: " + pathMessage,
                logPath.string(), {}};
    }
    std::filesystem::path identityPath;
    if (!canonicalOutputPath(outputs.pdk_identity_tsv, identityPath, pathMessage)) {
        return {false, "cannot canonicalize PDK identity path: " + pathMessage,
                logPath.string(), {}};
    }
    const auto artifactRoot = catalogPath.parent_path();
    std::filesystem::path catalogTempPath;
    if (!canonicalOutputPath(catalogPath.string() + ".tmp",
                             catalogTempPath, pathMessage)) {
        return {false, "cannot canonicalize PDK catalog temporary path: " + pathMessage,
                logPath.string(), artifactRoot.string()};
    }
    std::filesystem::path identityTempPath;
    if (!canonicalOutputPath(identityPath.string() + ".tmp",
                             identityTempPath, pathMessage)) {
        return {false, "cannot canonicalize PDK identity temporary path: " + pathMessage,
                logPath.string(), artifactRoot.string()};
    }
    if (outputPathsConflict({catalogPath, identityPath,
                             catalogTempPath, identityTempPath})) {
        return {false, "PDK catalog, identity and their temporary output paths must not conflict",
                logPath.string(), artifactRoot.string()};
    }

    const std::filesystem::path parents[] = {
        catalogPath.parent_path(), identityPath.parent_path(),
    };
    for (const auto& parent : parents) {
        if (parent.empty()) {
            continue;
        }
        error.clear();
        std::filesystem::create_directories(parent, error);
        if (error) {
            return {false, "cannot create PDK scan output directory: " + error.message(),
                    logPath.string(), artifactRoot.string()};
        }
    }
    error.clear();
    std::filesystem::remove(catalogPath, error);
    error.clear();
    std::filesystem::remove(identityPath, error);

    std::vector<std::string> arguments = {
        "--cds-lib", paths_.cds_lib.string(),
        "--lib", source.library,
        "--cell", source.cell,
        "--view", source.view,
        "--catalog-output", catalogPath.string(),
        "--identity-output", identityPath.string(),
    };
    auto status = Run("scan-pdk", std::move(arguments), logPath);
    status.artifact_path = artifactRoot.string();
    if (!status.ok) {
        return status;
    }

    const std::filesystem::path artifacts[] = {
        catalogPath, identityPath,
    };
    for (const auto& artifact : artifacts) {
        error.clear();
        if (!std::filesystem::exists(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            return {false, "backend did not generate the expected file or the file is empty: " + artifact.string(),
                    logPath.string(), artifactRoot.string()};
        }
    }

    DeviceCatalog catalog;
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(catalogPath, catalog, diagnostics) ||
        catalog.Descriptors().empty()) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, "PDK catalog has no parseable device data records",
                logPath.string(), artifactRoot.string()};
    }
    ScanIdentityEvidence identityEvidence;
    std::string identityMessage;
    if (!loadCompleteScanIdentity(identityPath, identityEvidence, identityMessage)) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, identityMessage, logPath.string(), artifactRoot.string()};
    }
    if (!validateCatalogEvidence(catalogPath, identityEvidence, identityMessage, paths_.structure_only, paths_.experimental_dc)) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, identityMessage, logPath.string(), artifactRoot.string()};
    }
    return {true, {}, logPath.string(), artifactRoot.string()};
}

void ProcessVirtuosoBackend::UseOperatingPointCatalog(const std::filesystem::path& catalog)
{
    paths_.operating_point_catalog = catalog;
}

HostStatus ProcessVirtuosoBackend::RunOperatingPoint(
    const CellViewRef& dut,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const OperatingPointOutputs& outputs)
{
    const auto logPath = paths_.log_dir /
        ("run_op_" + safeArtifactName(identity.corner) + "_" +
         safeArtifactName(identity.topology_hash) + "_" +
         safeArtifactName(identity.parameter_hash) + ".log");
    if (!completeCellView(dut)) {
        return {false, "DUT L/C/V incomplete", logPath.string(), {}};
    }
    if (!completeCellView(bench)) {
        return {false, "Bench L/C/V incomplete", logPath.string(), {}};
    }
    if (identity.dut_hash.empty() || identity.bench_hash.empty() ||
        identity.pdk_version.empty() || identity.corner.empty() ||
        identity.topology_hash.empty() || identity.parameter_hash.empty() ||
        identity.solver_version.empty()) {
        return {false, "operating point seven-field identity incomplete", logPath.string(), {}};
    }
    if (outputs.identity_tsv.empty() || outputs.mos_tsv.empty()) {
        return {false, "operating point output path must not be empty", logPath.string(), {}};
    }

    std::filesystem::path identityPath;
    std::filesystem::path mosPath;
    std::filesystem::path resistorPath;
    std::filesystem::path identityTempPath;
    std::filesystem::path mosTempPath;
    std::filesystem::path resistorTempPath;
    std::string pathMessage;
    if (!canonicalOutputPath(outputs.identity_tsv, identityPath, pathMessage) ||
        !canonicalOutputPath(outputs.mos_tsv, mosPath, pathMessage) ||
        !canonicalOutputPath(identityPath.string() + ".tmp",
                             identityTempPath, pathMessage) ||
        !canonicalOutputPath(mosPath.string() + ".tmp", mosTempPath, pathMessage)) {
        return {false, "cannot canonicalize operating point output path: " + pathMessage,
                logPath.string(), {}};
    }
    if (!outputs.resistor_tsv.empty() &&
        (!canonicalOutputPath(outputs.resistor_tsv, resistorPath, pathMessage) ||
         !canonicalOutputPath(resistorPath.string() + ".tmp",
                              resistorTempPath, pathMessage))) {
        return {false, "cannot canonicalize resistor operating point output path: " + pathMessage,
                logPath.string(), {}};
    }
    const auto artifactRoot = identityPath.parent_path();
    std::vector<std::filesystem::path> artifacts = {
        identityPath, mosPath, identityTempPath, mosTempPath};
    if (!resistorPath.empty()) {
        artifacts.push_back(resistorPath);
        artifacts.push_back(resistorTempPath);
    }
    if (outputPathsConflict(artifacts)) {
        return {false, "operating point identity, MOS and their temporary output paths must not conflict",
                logPath.string(), artifactRoot.string()};
    }

    std::error_code error;
    for (const auto& parent : {identityPath.parent_path(), mosPath.parent_path(),
                               resistorPath.parent_path()}) {
        if (parent.empty()) {
            continue;
        }
        error.clear();
        std::filesystem::create_directories(parent, error);
        if (error) {
            return {false, "cannot create operating point output directory: " + error.message(),
                    logPath.string(), artifactRoot.string()};
        }
    }

    ArtifactTransaction transaction(artifacts);
    std::string transactionMessage;
    if (!transaction.Begin(transactionMessage)) {
        return {false, transactionMessage, logPath.string(), artifactRoot.string()};
    }

    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string()};
    addCellView(arguments, "dut", dut);
    addCellView(arguments, "bench", bench);
    arguments.insert(arguments.end(), {
        "--corner", identity.corner,
        "--dut-hash", identity.dut_hash,
        "--bench-hash", identity.bench_hash,
        "--pdk-version", identity.pdk_version,
        "--topology-hash", identity.topology_hash,
        "--parameter-hash", identity.parameter_hash,
        "--solver-version", identity.solver_version,
        "--identity-output", identityPath.string(),
        "--mos-output", mosPath.string(),
    });
    if (!resistorPath.empty()) {
        arguments.insert(arguments.end(),
                         {"--resistor-output", resistorPath.string()});
    }
    if (!paths_.operating_point_catalog.empty()) {
        arguments.insert(arguments.end(),
            {"--device-catalog", paths_.operating_point_catalog.string()});
    }
    auto status = Run("run-op", std::move(arguments), logPath);
    status.artifact_path = artifactRoot.string();
    if (!status.ok) {
        transaction.Rollback();
        return status;
    }

    std::vector<std::filesystem::path> finalArtifacts = {identityPath, mosPath};
    if (!resistorPath.empty()) {
        finalArtifacts.push_back(resistorPath);
    }
    for (const auto& artifact : finalArtifacts) {
        error.clear();
        if (!generatedRegularFile(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            transaction.Rollback();
            return {false, "backend did not generate this round's expected non-empty regular operating point file: " +
                    artifact.string(), logPath.string(), artifactRoot.string()};
        }
    }
    std::vector<std::filesystem::path> temporaryArtifacts = {
        identityTempPath, mosTempPath};
    if (!resistorTempPath.empty()) {
        temporaryArtifacts.push_back(resistorTempPath);
    }
    for (const auto& temporary : temporaryArtifacts) {
        error.clear();
        if (pathObjectExists(temporary, error) || error) {
            transaction.Rollback();
            return {false, "temporary output still left after successful operating point backend run: " +
                    temporary.string(), logPath.string(), artifactRoot.string()};
        }
    }

    OperatingPointSnapshot snapshot;
    std::vector<Diagnostic> diagnostics;
    if (!LoadOperatingPointTsv(identityPath, mosPath, resistorPath,
                               snapshot, diagnostics)) {
        const auto message = diagnostics.empty() ? std::string("unknown parse failure")
                                                 : diagnostics.front().message;
        transaction.Rollback();
        return {false, "operating point output validation failed: " + message,
                logPath.string(), artifactRoot.string()};
    }
    if (!IsReusable(snapshot, identity)) {
        transaction.Rollback();
        return {false, "operating point output DUT/Bench/PDK/Corner/Topology/Parameter/Solver identity inconsistent with request",
                logPath.string(), artifactRoot.string()};
    }
    if (!transaction.Commit(transactionMessage)) {
        return {false, transactionMessage, logPath.string(), artifactRoot.string()};
    }
    return {true, {}, logPath.string(), artifactRoot.string()};
}

HostStatus ProcessVirtuosoBackend::RunVariantOperatingPoint(
    const CellViewRef& target,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const std::string& identityTsvPath,
    const std::string& mosTsvPath)
{
    const OperatingPointOutputs outputs{
        std::filesystem::path(identityTsvPath), std::filesystem::path(mosTsvPath)};
    return RunOperatingPoint(target, bench, identity, outputs);
}

HostStatus ProcessVirtuosoBackend::RunVariantOperatingPoint(
    const CellViewRef& target,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const OperatingPointTsvPaths& tsvPaths)
{
    const OperatingPointOutputs outputs{tsvPaths.identity, tsvPaths.mos,
                                         tsvPaths.resistor};
    return RunOperatingPoint(target, bench, identity, outputs);
}

HostStatus ProcessVirtuosoBackend::Run(const std::string& verb,
                                       std::vector<std::string> arguments,
                                       const std::filesystem::path& logPath)
{
    std::vector<std::string> command;
    command.push_back(executable_.string());
    command.push_back(verb);
    command.insert(command.end(), arguments.begin(), arguments.end());
    if (paths_.experimental_dc) {
        command.insert(command.end(), {"--validation-scope", "experimental_dc"});
    }
    const auto result = runner_.Run(command, logPath);
    return {result.exit_code == 0,
            result.exit_code == 0 ? std::string{} : result.message,
            logPath.string(), {}};
}

HostStatus ProcessVirtuosoBackend::CopyCircuits(
    const std::vector<OaCloneMapping>& cloneMap)
{
    if (cloneMap.empty()) {
        return {false, "clone map is empty", {}, {}};
    }
    for (std::size_t index = 0; index < cloneMap.size(); ++index) {
        const auto& mapping = cloneMap[index];
        std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                              "--hierarchy", mapping.hierarchy_path};
        addCellView(arguments, "source", mapping.source);
        addCellView(arguments, "target", mapping.target);
        auto status = Run("clone", std::move(arguments),
                          paths_.log_dir / ("clone_" + std::to_string(index) + ".log"));
        if (!status.ok) {
            return status;
        }
    }
    return {true, {}, {}, {}};
}

HostStatus ProcessVirtuosoBackend::WritePlanFile(const std::string& path,
                                                 const std::string& json)
{
    const std::filesystem::path target(path);
    std::error_code error;
    std::filesystem::create_directories(target.parent_path(), error);
    if (error) {
        return {false, "cannot create materialization plan directory: " + error.message(), {}, path};
    }
    const auto temporary = target.string() + ".tmp";
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        output << json;
        if (!output) {
            return {false, "failed to write materialization plan", {}, path};
        }
    }
    std::filesystem::rename(temporary, target, error);
    if (error) {
        std::filesystem::remove(temporary);
        return {false, "failed to publish materialization plan: " + error.message(), {}, path};
    }
    return {true, {}, {}, path};
}

HostStatus ProcessVirtuosoBackend::ExecuteSkill(const std::string& workDir,
                                                const std::string& skillScriptPath,
                                                const std::string& planPath)
{
    return Run("materialize", {"--cds-lib", paths_.cds_lib.string(),
            "--work-dir", workDir, "--skill", skillScriptPath, "--plan", planPath},
        paths_.log_dir / "materialize.log");
}

HostStatus ProcessVirtuosoBackend::RegenerateNetlist(const CellViewRef& target,
                                                     const std::string& logicalSubckt,
                                                     Netlist& netlist)
{
    const auto callIndex = netlist_call_count_++;
    std::filesystem::path output;
    std::filesystem::path log;
    if (callIndex == 0) {
        output = paths_.source_roundtrip;
        log = paths_.log_dir / "netlist_source.log";
    } else if (callIndex == 1) {
        output = paths_.target_roundtrip;
        log = paths_.log_dir / "netlist_target.log";
    } else {
        std::ostringstream number;
        number << std::setw(4) << std::setfill('0') << (callIndex - 1);
        const auto stem = "package_" + number.str() + "_" +
            safeArtifactName(logicalSubckt.empty() ? target.cell : logicalSubckt);
        output = paths_.target_roundtrip.parent_path() / (stem + ".scs");
        log = paths_.log_dir / ("netlist_" + stem + ".log");
    }
    return RegenerateNetlistTo(target, logicalSubckt, output, log, netlist);
}

HostStatus ProcessVirtuosoBackend::RegenerateNetlistTo(
    const CellViewRef& target, const std::string& logicalSubckt,
    const std::filesystem::path& output, const std::filesystem::path& log,
    Netlist& netlist)
{
    if (output.empty() || log.empty()) {
        return {false, "readback netlist or log path is empty", log.string(), output.string()};
    }
    std::error_code error;
    std::filesystem::create_directories(output.parent_path(), error);
    if (!error) {
        std::filesystem::create_directories(log.parent_path(), error);
    }
    if (!error) {
        std::filesystem::remove(output, error);
    }
    if (error) {
        return {false, "failed to prepare readback artifacts: " + error.message(),
                log.string(), output.string()};
    }
    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                          "--lib", target.library,
                                          "--cell", target.cell,
                                          "--view", target.view,
                                          "--core-subckt", logicalSubckt.empty()
                                              ? paths_.core_subckt : logicalSubckt,
                                          "--output", output.string()};
    if (!paths_.device_policy.empty()) {
        arguments.insert(arguments.end(),
                         {"--device-policy", paths_.device_policy.string()});
    }
    auto status = Run("netlist", std::move(arguments), log);
    status.artifact_path = output.string();
    if (!status.ok) {
        return status;
    }
    if (!std::filesystem::exists(output, error) || error ||
        std::filesystem::file_size(output, error) == 0 || error) {
        return missingArtifact(output, log);
    }
    std::ifstream input(output, std::ios::binary);
    const std::string text((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());
    std::vector<Diagnostic> diagnostics;
    netlist = parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) {
        return {false, "readback netlist parsing failed: " + diagnostics.front().message,
                log.string(), output.string()};
    }
    return {true, {}, log.string(), output.string()};
}

HostStatus ProcessVirtuosoBackend::PublishCircuits(
    const std::vector<OaCloneMapping>& publishMap)
{
    if (paths_.experimental_dc) {
        return {false, "experimental_dc forbids publishing staging", {}, {}};
    }
    if (!paths_.operating_point_catalog.empty()) {
        DeviceCatalog catalog;
        std::vector<Diagnostic> diagnostics;
        if (!LoadDeviceCatalogTsv(paths_.operating_point_catalog, catalog, diagnostics)) {
            return {false, "cannot verify the fixed PDK catalog before publishing", {}, {}};
        }
        for (const auto& entry : catalog.Descriptors()) {
            if (entry.second.native_parameter_trials) {
                return {false, "native parameter trials catalog must not be published", {}, {}};
            }
        }
    }
    if (publishMap.empty()) {
        return {false, "publish map is empty", {}, {}};
    }
    OaMaterializationPlan plan;
    plan.source = publishMap.front().source;
    plan.target = publishMap.front().target;
    plan.clone_map = publishMap;
    const auto planPath = paths_.log_dir / "publish_plan.json";
    auto status = WritePlanFile(planPath.string(), WritePlanJson(plan));
    if (!status.ok) {
        return status;
    }
    return Run("publish", {"--cds-lib", paths_.cds_lib.string(),
                           "--publish-plan", planPath.string()},
               paths_.log_dir / "publish.log");
}

HostStatus ProcessVirtuosoBackend::Open(const CellViewRef& target)
{
    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                          "--lib", target.library,
                                          "--cell", target.cell,
                                          "--view", target.view};
    return Run("open", std::move(arguments), paths_.log_dir / "open.log");
}

} // namespace st::standalone
