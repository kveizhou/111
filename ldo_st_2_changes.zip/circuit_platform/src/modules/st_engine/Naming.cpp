#include "st/Naming.h"

#include <algorithm>
#include <cctype>
#include <limits>
#include <stdexcept>

namespace st {

namespace {

struct ArrayRangeInfo {
    std::size_t open = std::string::npos;
    std::size_t close = std::string::npos;
    std::size_t bits = 1;
};

ArrayRangeInfo findArrayRange(const std::string& name)
{
    ArrayRangeInfo info;
    const auto open = name.find('<');
    if (open == std::string::npos) return info;
    const auto close = name.find('>', open + 1);
    if (close == std::string::npos) return info;
    const auto colon = name.find(':', open + 1);
    if (colon == std::string::npos || colon >= close) return info;
    try {
        std::size_t highEnd = 0;
        std::size_t lowEnd = 0;
        const long long high = std::stoll(name.substr(open + 1, colon - open - 1), &highEnd);
        const long long low = std::stoll(name.substr(colon + 1, close - colon - 1), &lowEnd);
        if (highEnd != colon - open - 1 || lowEnd != close - colon - 1) return info;
        const auto unsignedBits = high >= low
            ? static_cast<unsigned long long>(high) - static_cast<unsigned long long>(low) + 1ULL
            : static_cast<unsigned long long>(low) - static_cast<unsigned long long>(high) + 1ULL;
        if (unsignedBits < 2 || unsignedBits > std::numeric_limits<std::size_t>::max()) return info;
        info.open = open;
        info.close = close;
        info.bits = static_cast<std::size_t>(unsignedBits);
    } catch (...) {
        return info;
    }
    return info;
}

std::string scalarName(const std::string& base)
{
    std::string stem = base;
    for (char& ch : stem) {
        if (!std::isalnum(static_cast<unsigned char>(ch)) && ch != '_') ch = '_';
    }
    return stem;
}

void collectSubcktNames(const Subckt& subckt,
                        std::set<std::string>& instanceNames,
                        std::set<std::string>& netNames)
{
    netNames.insert(subckt.pins.begin(), subckt.pins.end());
    for (const auto& instance : subckt.instances) {
        instanceNames.insert(instance.name);
        netNames.insert(instance.nets.begin(), instance.nets.end());
    }
}

} // namespace

std::string NormalizeMosArrayName(std::string name)
{
    std::replace(name.begin(), name.end(), '[', '<');
    std::replace(name.begin(), name.end(), ']', '>');
    return name;
}

std::string MosArrayRange(const std::string& name)
{
    const auto range = findArrayRange(name);
    return range.open == std::string::npos ? std::string{}
        : name.substr(range.open, range.close - range.open + 1);
}

std::size_t MosArrayBitCount(const std::string& name)
{
    return findArrayRange(name).bits;
}

NameAllocator::NameAllocator(const Netlist& netlist, const std::string& subcktScope)
{
    for (const auto& subckt : netlist.subckts) {
        subcktNames_.insert(subckt.name);
        if (subcktScope.empty() || subckt.name == subcktScope) {
            collectSubcktNames(subckt, instanceNames_, netNames_);
        }
    }
    if (subcktScope.empty()) {
        for (const auto& instance : netlist.topInstances) {
            instanceNames_.insert(instance.name);
            netNames_.insert(instance.nets.begin(), instance.nets.end());
        }
    }
}

std::set<std::string>& NameAllocator::Names(NameKind kind)
{
    switch (kind) {
    case NameKind::Instance:
        return instanceNames_;
    case NameKind::Net:
        return netNames_;
    case NameKind::Subckt:
        return subcktNames_;
    }
    throw std::logic_error("unknown NameKind");
}

std::string NameAllocator::Allocate(NameKind kind, const std::string& base)
{
    // 阵列后缀必须放在范围之前：I82<29:0>_CAS -> I82_CAS<29:0>。
    // 唯一化后缀同样放在范围之前；Subckt/Cell 名则始终使用标量字符。
    const auto range = kind == NameKind::Subckt ? ArrayRangeInfo{} : findArrayRange(base);
    const bool vectored = range.open != std::string::npos;
    const std::string stem = scalarName(vectored
        ? base.substr(0, range.open) + base.substr(range.close + 1) : base);
    const std::string suffixRange = vectored
        ? base.substr(range.open, range.close - range.open + 1) : std::string{};
    auto& names = Names(kind);
    const auto withRange = [&suffixRange](const std::string& value) {
        return value + suffixRange;
    };
    if (names.insert(withRange(stem)).second) {
        return withRange(stem);
    }
    for (std::size_t suffix = 2;; ++suffix) {
        const auto candidate = withRange(stem + "_" + std::to_string(suffix));
        if (names.insert(candidate).second) {
            return candidate;
        }
    }
}

} // namespace st
