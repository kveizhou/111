#include "st/ResistanceBiasSolver.h"

#include "st/PdkCatalog.h"
#include "st/Transform.h"
#include "st/VariantVerifier.h"

#include <algorithm>
#include <cmath>
#include <set>
#include <sstream>

namespace st {
namespace {

bool sameValue(double left, double right)
{
    return std::fabs(left - right) <=
        1e-12 * std::max({1.0, std::fabs(left), std::fabs(right)});
}

} // namespace

ResistanceBiasSearch::ResistanceBiasSearch(const ResistanceBiasSearchConfig& config)
    : polarity_(config.polarity), originalWasSaturated_(config.original_was_saturated),
      maxEvaluations_(config.max_evaluations), constraint_(config.resistance)
{
    std::string constraintError;
    if ((polarity_ != DeviceKind::MosN && polarity_ != DeviceKind::MosP) ||
        !ValidateParameterConstraint(constraint_, &constraintError)) {
        reason_ = "invalid_polarity_or_resistance_constraint: " + constraintError;
        return;
    }
    if (constraint_.minimum <= 0.0 || constraint_.cdf_name.empty() ||
        !std::isfinite(config.initial_vds) || !std::isfinite(config.initial_current) ||
        std::fabs(config.initial_current) <= 1e-30 ||
        std::fabs(config.initial_vds) <= 0.0 || maxEvaluations_ == 0) {
        reason_ = "baseline_op_invalid: finite nonzero VDS/ID and positive resistance range are required";
        return;
    }
    try {
        next_ = QuantizeParameter(
            std::fabs(config.initial_vds) / std::fabs(config.initial_current), constraint_);
    } catch (const std::exception& error) {
        reason_ = std::string("resistance_seed_quantization_failed: ") + error.what();
        return;
    }
    valid_ = next_ > 0.0 && std::isfinite(next_);
    if (!valid_) reason_ = "resistance_seed_quantization_failed";
}

void ResistanceBiasSearch::Update(const ResistanceBiasFeedback& feedback)
{
    if (!valid_ || finished_) return;
    ++evaluations_;
    if (feedback.converged && feedback.original_region_ok && feedback.cascode_saturated) {
        finished_ = solved_ = true;
        reason_ = "ok";
        return;
    }
    if (evaluations_ >= maxEvaluations_) {
        finished_ = true;
        reason_ = "evaluation_limit";
        return;
    }

    int direction = lastDirection_.value_or(1);
    if (feedback.converged) {
        if (!feedback.original_region_ok) {
            // NMOS 增大 R 会降低原管 |VDS|；PMOS 极性相反。
            direction = originalWasSaturated_ ? 1 : -1;
        } else {
            // 原管已符合原工作区，需要给新增 Cascode 更多 |VDS|。
            direction = -1;
        }
        if (polarity_ == DeviceKind::MosP) direction = -direction;
    }
    const double old = next_;
    if (lastDirection_.has_value() && direction != *lastDirection_) {
        lower_ = std::min(previous_, old);
        upper_ = std::max(previous_, old);
    } else if (lower_.has_value() && upper_.has_value() && feedback.converged) {
        if (direction > 0) lower_ = old;
        else upper_ = old;
    }

    double proposal = 0.0;
    if (lower_.has_value() && upper_.has_value()) {
        if (!(*lower_ < *upper_)) {
            finished_ = true;
            reason_ = "no_feasible_resistance_window";
            return;
        }
        proposal = std::sqrt(*lower_ * *upper_);
    } else {
        proposal = direction > 0 ? old * 2.0 : old * 0.5;
    }
    previous_ = old;
    lastDirection_ = direction;
    try {
        next_ = QuantizeParameter(proposal, constraint_);
    } catch (const std::exception& error) {
        finished_ = true;
        reason_ = std::string("resistance_quantization_failed: ") + error.what();
        return;
    }
    if (sameValue(next_, old)) {
        finished_ = true;
        reason_ = "quantized_candidate_exhausted_or_resistance_boundary";
    }
}

namespace {

struct BiasRoleLayout {
    std::string control_replica;
    std::string bias_resistor;
};

BiasRoleLayout biasRoles(DeviceKind polarity, const std::string& range)
{
    const bool n = polarity == DeviceKind::MosN;
    return {(n ? "N_CTRL_REP_N" : "P_CTRL_REP_P") + range,
            (n ? "R_BIAS_N" : "R_BIAS_P") + range};
}

const ParameterConstraint* resistanceConstraint(const DeviceDescriptor& descriptor)
{
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        const std::string semantic = constraint.semantic_name.empty() ? name : constraint.semantic_name;
        if (semantic == "resistance") return &constraint;
    }
    return nullptr;
}

std::string jsonEscape(const std::string& text)
{
    std::string escaped;
    for (const char ch : text) {
        if (ch == '"' || ch == '\\') escaped += '\\';
        escaped += ch < 0x20 ? '?' : ch;
    }
    return escaped;
}

std::string traceMeasurement(const ElectricalConstraintResult& assessed,
                             const std::string& role, const char* quantity)
{
    const auto found = assessed.stress_measurements.find(role + "." + quantity);
    return found == assessed.stress_measurements.end() || !std::isfinite(found->second)
        ? "null" : FormatAutoBiasParameter(found->second);
}

std::string resistanceTrace(std::size_t candidate, const std::string& corner,
                            double resistance, bool converged, bool hostCalled,
                            const ElectricalConstraintResult& assessed,
                            const ElectricalConstraintRequest& check,
                            const std::string& reason, bool selected)
{
    std::ostringstream line;
    line << "{\"candidate\":" << candidate
         << ",\"corner\":\"" << jsonEscape(corner)
         << "\",\"r_bias\":" << FormatAutoBiasParameter(resistance)
         << ",\"host_called\":" << (hostCalled ? "true" : "false")
         << ",\"converged\":" << (converged ? "true" : "false")
         << ",\"original_intrinsic_vds\":"
         << traceMeasurement(assessed, check.actual_control.leaf_name, "intrinsic_vds")
         << ",\"original_vdsat\":"
         << traceMeasurement(assessed, check.actual_control.leaf_name, "vdsat")
         << ",\"control_replica_intrinsic_vds\":"
         << traceMeasurement(assessed, check.control_replica.leaf_name, "intrinsic_vds")
         << ",\"control_replica_vdsat\":"
         << traceMeasurement(assessed, check.control_replica.leaf_name, "vdsat")
         << ",\"cascode_intrinsic_vds\":"
         << traceMeasurement(assessed, check.actual_cascode.leaf_name, "intrinsic_vds")
         << ",\"cascode_vdsat\":"
         << traceMeasurement(assessed, check.actual_cascode.leaf_name, "vdsat")
         << ",\"reason\":\"" << jsonEscape(reason)
         << "\",\"selected\":" << (selected ? "true" : "false") << '}';
    return line.str();
}

bool constraintValue(const ElectricalConstraintResult& assessed, const std::string& name)
{
    const auto found = assessed.constraints.find(name);
    return found != assessed.constraints.end() && found->second;
}

} // namespace

AutoBiasSolveResult SolveCascodeResistanceBias(const AutoBiasSolveRequest& request,
                                               const DeviceCatalog& catalog,
                                               DcEvaluationHost& host)
{
    AutoBiasSolveResult result;
    AutoBiasDevicePlan plan;
    Diagnostic diagnostic;
    if (!SelectAutoBiasDevices(request.template_request, catalog, plan, diagnostic)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    result.device_combinations = 1;
    result.searched_device_combinations = 1;
    const auto* root = request.baseline.find(request.root_subckt);
    const auto* target = root == nullptr ? nullptr : root->find(request.target_instance);
    if (target == nullptr) {
        result.diagnostics.push_back({DiagCode::NotFound,
            "target instance not found in baseline netlist: " + request.root_subckt + "/" + request.target_instance});
        return result;
    }
    if (target->model != request.template_request.control_master) {
        result.diagnostics.push_back({DiagCode::BadParam,
            "baseline target master inconsistent with Control Replica master"});
        return result;
    }
    const auto* baseline = FindMosOp(request.baseline_op, request.target_instance);
    if (baseline == nullptr) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "baseline DC snapshot missing operating point of target instance: " + request.target_instance});
        return result;
    }
    const double baselineVds = baseline->intrinsic_vds.value_or(baseline->vds);
    if (!std::isfinite(baselineVds) || !std::isfinite(baseline->vdsat) ||
        !std::isfinite(baseline->id) || std::fabs(baselineVds) <= 0.0 ||
        std::fabs(baseline->id) <= 1e-30) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "baseline_op_invalid: finite nonzero VDS/ID and finite VDSAT are required before resistance search"});
        return result;
    }
    const auto* resistance = resistanceConstraint(*plan.resistor);
    if (resistance == nullptr) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "selected resistor has no real resistance CDF constraint: " + plan.resistor->master});
        return result;
    }

    ResistanceBiasSearchConfig searchConfig;
    searchConfig.polarity = request.template_request.polarity;
    searchConfig.original_was_saturated =
        std::fabs(baselineVds) >= std::fabs(baseline->vdsat);
    searchConfig.initial_vds = baselineVds;
    searchConfig.initial_current = baseline->id;
    searchConfig.resistance = *resistance;
    ResistanceBiasSearch search(searchConfig);
    if (!search.valid()) {
        result.diagnostics.push_back({DiagCode::BadParam, search.reason()});
        return result;
    }

    BiasSizing sizing;
    if (!InitialStructuralBias(request.template_request, catalog, *target, sizing, diagnostic) ||
        !ApplyCustomMosParameters(*plan.cascode, request.custom_width,
            request.custom_finger_width, request.custom_fingers, request.custom_length,
            sizing.cascode_parameters, diagnostic)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    const auto roles = biasRoles(request.template_request.polarity,
                                 request.template_request.array_range);
    const bool experimental = request.template_request.experimental_dc;
    ElectricalConstraintRequest check;
    check.operation_id = request.template_request.operation_id;
    check.polarity = request.template_request.polarity;
    check.experimental_dc = experimental;
    check.control_replica = {{}, roles.control_replica, plan.control->limits, plan.control->reliability_complete};
    check.actual_control = {{}, request.target_instance, plan.control->limits, plan.control->reliability_complete};
    check.actual_cascode = {{}, {}, plan.cascode->limits, plan.cascode->reliability_complete};
    check.bias_resistor = {request.template_request.operation_id, {}, roles.bias_resistor,
                           plan.resistor->master, experimental};
    check.baseline_control = *baseline;
    check.max_branch_current_error = request.max_branch_current_error;
    check.max_vbias_current = request.max_vbias_current;
    for (const auto* device : {plan.control, plan.cascode, plan.resistor}) {
        if (device->native_parameter_trials) {
            check.native_parameter_trials = true;
            check.unverified_constraints.push_back(device->master + ".complete_parameter_domain");
        }
        if (device->voltage_domain.empty() && device->allowed_voltage_domains.empty()) {
            check.unverified_constraints.push_back(device->master + ".voltage_domain");
        }
    }

    auto assessSnapshot = [&request, experimental](const OperatingPointSnapshot& snapshot,
                                                   const ElectricalConstraintRequest& current,
                                                   bool converged) {
        auto assessed = EvaluateElectricalConstraints(snapshot, current, converged);
        if (experimental) {
            if (!request.preceding_checks.empty()) {
                assessed.constraints["preceding_groups"] = true;
                assessed.unverified_constraints.push_back("preceding_groups");
            }
        } else if (converged) {
            bool precedingOk = true;
            for (const auto& previous : request.preceding_checks) {
                const auto prior = EvaluateElectricalConstraints(snapshot, previous, true);
                precedingOk = precedingOk && prior.ok;
            }
            assessed.constraints["preceding_groups"] = precedingOk;
            if (!precedingOk && assessed.first_failed_constraint.empty()) {
                assessed.first_failed_constraint = "preceding_groups";
            }
            if (assessed.ok && !precedingOk) {
                assessed.ok = false;
                assessed.first_failed_constraint = "preceding_groups";
            }
        }
        return assessed;
    };

    auto assemble = [&request, &catalog, experimental](
        const BiasSizing& candidateSizing, ElectricalConstraintRequest& candidateCheck,
        Netlist& candidate, DcEvaluationRequest& evaluation, std::string& error) {
        const auto built = BuildAutoBiasTemplate(request.template_request, candidateSizing, catalog);
        if (!built.ok) {
            error = built.diagnostics.empty() ? "VBIAS template build failed" : built.diagnostics.front().message;
            return false;
        }
        candidate = request.baseline;
        AutoBiasSolveResult resolved;
        resolved.ok = true;
        resolved.sizing = candidateSizing;
        resolved.electrical_check = candidateCheck;
        CascodeTransformRequest transform;
        transform.subckt = request.root_subckt;
        transform.target = request.target_instance;
        transform.new_master = request.template_request.cascode_master;
        transform.gate_policy = GatePolicy::FixedBias;
        transform.custom_width = request.custom_width;
        transform.custom_finger_width = request.custom_finger_width;
        transform.custom_fingers = request.custom_fingers;
        transform.custom_length = request.custom_length;
        transform.experimental_dc = experimental;
        transform.solved_bias = std::move(resolved);
        transform.bias_template = built;
        transform.vbias_vhigh_net = request.template_request.vhigh_net;
        transform.vbias_vlow_net = request.template_request.vlow_net;
        transform.voltage_domain = request.template_request.voltage_domain;
        transform.nmos_bulk_net = request.nmos_bulk_net;
        transform.tie_isolated_pmos_to_source = request.tie_isolated_pmos_to_source;
        const auto outcome = applyCascode(candidate, transform, catalog);
        if (!outcome.ok() || outcome.addedInstances.empty()) {
            error = "complete Cascode candidate construction failed";
            for (const auto& item : outcome.diags) error += "; " + item.message;
            return false;
        }
        candidateCheck.actual_cascode.leaf_name = outcome.addedInstances.front();
        if (!outcome.bias_instances.empty()) {
            const auto& container = outcome.bias_instances.front();
            candidateCheck.control_replica.container_instance = container;
            candidateCheck.bias_resistor.container_instance = container;
        }
        evaluation.candidate = candidate;
        evaluation.root_subckt = request.root_subckt;
        evaluation.target_instance = request.target_instance;
        evaluation.cascode_instance = candidateCheck.actual_cascode.leaf_name;
        evaluation.operation_id = request.template_request.operation_id;
        evaluation.identity = request.nominal_identity;
        evaluation.identity.topology_hash = ComputeNetlistTopologyHash(candidate);
        evaluation.identity.parameter_hash = ComputeNetlistParameterHash(candidate);
        return true;
    };

    std::size_t candidateId = 0;
    DcEvaluationRequest selectedRequest;
    ElectricalConstraintRequest selectedCheck;
    ElectricalConstraintResult lastAssessed;
    while (!search.finished()) {
        ++candidateId;
        const double r = search.next();
        sizing.element_parameters[roles.bias_resistor][resistance->cdf_name] =
            FormatAutoBiasParameter(r);
        Netlist candidate;
        DcEvaluationRequest evaluation;
        ElectricalConstraintRequest candidateCheck = check;
        std::string constructionError;
        if (!assemble(sizing, candidateCheck, candidate, evaluation, constructionError)) {
            result.diagnostics.push_back({DiagCode::BadParam, constructionError});
            return result;
        }
        OperatingPointSnapshot snapshot;
        Diagnostic hostDiagnostic;
        ++result.nominal_evaluations;
        const bool converged = host.Evaluate(evaluation, snapshot, hostDiagnostic);
        if (!converged && !hostDiagnostic.message.empty()) {
            result.evaluation_failed = true;
            result.diagnostics.push_back(hostDiagnostic);
            result.trace_lines.push_back(resistanceTrace(candidateId,
                request.nominal_identity.corner, r, false, true, {}, candidateCheck,
                "evaluation_failed: " + hostDiagnostic.message, false));
            return result;
        }
        auto assessed = assessSnapshot(snapshot, candidateCheck, converged);
        lastAssessed = assessed;
        if (converged && !constraintValue(assessed, "complete")) {
            result.evaluation_failed = true;
            result.diagnostics.push_back({DiagCode::MissingInput,
                "DC snapshot incomplete or invalid; stopping resistance search: " + assessed.first_failed_constraint});
            result.trace_lines.push_back(resistanceTrace(candidateId,
                request.nominal_identity.corner, r, true, true, assessed, candidateCheck,
                "incomplete_snapshot", false));
            return result;
        }
        if (assessed.ok) {
            result.ok = true;
            result.selected_candidate = candidateId;
            result.sizing = sizing;
            result.sizing.nominal_voltage = assessed.vbias_voltage;
            result.sizing.iq_delta = assessed.metrics.iq_delta;
            result.metrics = assessed.metrics;
            result.reliability_verified = assessed.reliability_verified;
            result.unverified_constraints = assessed.unverified_constraints;
            result.stress_measurements = assessed.stress_measurements;
            result.electrical_check = candidateCheck;
            result.native_parameter_trials = candidateCheck.native_parameter_trials;
            selectedRequest = std::move(evaluation);
            selectedCheck = candidateCheck;
            result.trace_lines.push_back(resistanceTrace(candidateId,
                request.nominal_identity.corner, r, true, true, assessed, candidateCheck,
                "ok", true));
            search.Update({true, true, true});
            break;
        }
        const bool originalRegion = constraintValue(assessed, "original_region");
        const bool cascodeSaturated = constraintValue(assessed, "cascode_saturation");
        if (converged && originalRegion && cascodeSaturated) {
            result.failed_constraints.clear();
            for (const auto& [name, passed] : assessed.constraints) {
                if (!passed) result.failed_constraints.push_back(name);
            }
            result.diagnostics.push_back({DiagCode::BadParam,
                "non_region_constraint_failed: " + assessed.first_failed_constraint});
            result.trace_lines.push_back(resistanceTrace(candidateId,
                request.nominal_identity.corner, r, true, true, assessed, candidateCheck,
                assessed.first_failed_constraint, false));
            return result;
        }
        result.trace_lines.push_back(resistanceTrace(candidateId,
            request.nominal_identity.corner, r, converged, true, assessed, candidateCheck,
            converged ? assessed.first_failed_constraint : "not_converged", false));
        search.Update({converged, originalRegion, cascodeSaturated});
    }

    if (!result.ok) {
        result.sizing = sizing;
        result.parameter_search_truncated = search.reason() == "evaluation_limit";
        for (const auto& [name, passed] : lastAssessed.constraints) {
            if (!passed) result.failed_constraints.push_back(name);
        }
        result.diagnostics.push_back({DiagCode::BadParam,
            "no_feasible_resistance_bias: " + search.reason() +
            "; evaluated=" + std::to_string(result.nominal_evaluations) + "; no candidate is accepted"});
        return result;
    }

    result.pvt_ready = request.pvt_corners.empty() ? false : true;
    for (const auto& corner : request.pvt_corners) {
        DcEvaluationRequest cornerRequest = selectedRequest;
        cornerRequest.identity.corner = corner;
        OperatingPointSnapshot snapshot;
        Diagnostic hostDiagnostic;
        ++result.pvt_evaluations;
        const bool converged = host.Evaluate(cornerRequest, snapshot, hostDiagnostic);
        if (!converged && !hostDiagnostic.message.empty()) {
            result.evaluation_failed = true;
            result.ok = false;
            result.pvt_ready = false;
            result.pvt_results.push_back({corner, false, "evaluation_failed"});
            result.diagnostics.push_back(hostDiagnostic);
            break;
        }
        auto assessed = assessSnapshot(snapshot, selectedCheck, converged);
        const bool passed = converged && assessed.ok;
        result.pvt_results.push_back({corner, passed,
            passed ? std::string{} : converged ? assessed.first_failed_constraint : "not_converged"});
        result.trace_lines.push_back(resistanceTrace(++candidateId, corner,
            search.next(), converged, true, assessed, selectedCheck,
            passed ? "ok" : converged ? assessed.first_failed_constraint : "not_converged", false));
        result.reliability_verified = result.reliability_verified && assessed.reliability_verified;
        for (const auto& unknown : assessed.unverified_constraints) {
            result.unverified_constraints.push_back(corner + "." + unknown);
        }
        result.pvt_ready = result.pvt_ready && passed;
        if (!passed) {
            result.ok = false;
            result.diagnostics.push_back({DiagCode::BadParam,
                "fixed-resistance PVT check failed at " + corner});
            break;
        }
    }
    return result;
}

} // namespace st
