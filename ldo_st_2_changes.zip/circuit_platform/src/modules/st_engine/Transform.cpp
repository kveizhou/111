// =============================================================
// Transform.cpp — 四类结构变换实现
// 前置校验（headroom / 天花板 / 极性 / bulk）不过则拒绝并返回诊断，
// 不做任何修改；通过才改写网表，保证"生成即合法"。
// =============================================================
#include "st/Transform.h"
#include "st/LegacyPrototype.h"
#include "st/Naming.h"
#include "st/PdkCatalog.h"
#include "st/Solver.h"
#include "st/Transaction.h"
#include "st/Validate.h"

#include <cmath>
#include <sstream>
#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <set>

namespace st {

namespace {

bool engineeringMos(const DeviceDescriptor* descriptor)
{
    return descriptor != nullptr &&
        isMosKind(descriptor->kind);
}

struct MosNets {
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
};

bool readMosNets(const Instance& instance, const DeviceCatalog& catalog,
                 MosNets& nets, Diagnostic& diagnostic)
{
    return getTerminalNet(instance, catalog, TerminalRole::Drain, nets.drain, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Gate, nets.gate, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Source, nets.source, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Bulk, nets.bulk, diagnostic);
}

bool writeMosNets(Instance& instance, const DeviceCatalog& catalog,
                  const MosNets& nets, Diagnostic& diagnostic)
{
    return setTerminalNet(instance, catalog, TerminalRole::Drain, nets.drain, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Gate, nets.gate, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Source, nets.source, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Bulk, nets.bulk, diagnostic);
}

bool supportsVoltageDomain(const DeviceDescriptor& descriptor,
                           const std::string& voltageDomain, bool experimentalDc = false)
{
    if (experimentalDc && (voltageDomain.empty() ||
        (descriptor.allowed_voltage_domains.empty() && descriptor.voltage_domain.empty()))) {
        return true;
    }
    if (voltageDomain.empty()) {
        return false;
    }
    if (!descriptor.allowed_voltage_domains.empty()) {
        return descriptor.allowed_voltage_domains.count(voltageDomain) != 0;
    }
    return descriptor.voltage_domain == voltageDomain;
}

bool parseEngineeringNumber(const std::string& text, double& value)
{
    if (text.empty()) {
        return false;
    }
    char* end = nullptr;
    errno = 0;
    const double base = std::strtod(text.c_str(), &end);
    if (errno != 0 || end == text.c_str()) {
        return false;
    }
    std::string suffix(end);
    double multiplier = 1.0;
    if (suffix.empty()) {
        multiplier = 1.0;
    } else if (suffix == "T" || suffix == "t") {
        multiplier = 1e12;
    } else if (suffix == "G" || suffix == "g") {
        multiplier = 1e9;
    } else if (suffix == "MEG" || suffix == "meg") {
        multiplier = 1e6;
    } else if (suffix == "K" || suffix == "k") {
        multiplier = 1e3;
    } else if (suffix == "M") {
        multiplier = 1e6;
    } else if (suffix == "m") {
        multiplier = 1e-3;
    } else if (suffix == "U" || suffix == "u") {
        multiplier = 1e-6;
    } else if (suffix == "N" || suffix == "n") {
        multiplier = 1e-9;
    } else if (suffix == "P" || suffix == "p") {
        multiplier = 1e-12;
    } else if (suffix == "F" || suffix == "f") {
        multiplier = 1e-15;
    } else {
        return false;
    }
    value = base * multiplier;
    return std::isfinite(value);
}

const ParameterConstraint* findParameterConstraint(const DeviceDescriptor& descriptor,
                                                   const std::string& semantic)
{
    const auto direct = descriptor.parameter_constraints.find(semantic);
    if (direct != descriptor.parameter_constraints.end()) {
        return &direct->second;
    }
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        if (constraint.semantic_name == semantic) {
            return &constraint;
        }
    }
    return nullptr;
}

bool mapInheritedParameters(const Instance& original,
                            const DeviceDescriptor& originalDescriptor,
                            const DeviceDescriptor& targetDescriptor,
                            std::map<std::string, std::string>& mapped,
                            Diagnostic& diagnostic)
{
    if (originalDescriptor.master == targetDescriptor.master) {
        mapped = original.params;
        if (targetDescriptor.normalized_to_cdf.empty()) {
            return true; // 固定几何 master，保持所有原参数，不虚构 W/L。
        }
    } else {
        if (targetDescriptor.normalized_to_cdf.empty()) {
            mapped.clear();
            return true;
        }
        const bool sourceFingerWidth =
            originalDescriptor.normalized_to_cdf.count("finger_width") != 0;
        const bool targetFingerWidth =
            targetDescriptor.normalized_to_cdf.count("finger_width") != 0;
        const bool sourceWidth = originalDescriptor.normalized_to_cdf.count("width") != 0;
        const bool targetWidth = targetDescriptor.normalized_to_cdf.count("width") != 0;
        if (sourceFingerWidth != targetFingerWidth || sourceWidth != targetWidth) {
            diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                "cross-master W/L and WF/NF/L parameter modes cannot be mixed implicitly"};
            return false;
        }
        std::vector<std::string> required = {"length", targetWidth ? "width" : "finger_width"};
        for (const auto& semantic : {"fingers", "multi"}) {
            if (originalDescriptor.normalized_to_cdf.count(semantic) != 0 ||
                targetDescriptor.normalized_to_cdf.count(semantic) != 0) {
                required.push_back(semantic);
            }
        }
        for (const auto& semantic : required) {
            const auto sourceName = originalDescriptor.normalized_to_cdf.find(semantic);
            const auto targetName = targetDescriptor.normalized_to_cdf.find(semantic);
            if (sourceName == originalDescriptor.normalized_to_cdf.end() ||
                targetName == targetDescriptor.normalized_to_cdf.end()) {
                diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                    "cross-master parameter mapping is missing " + semantic + " semantics"};
                return false;
            }
            const auto value = original.params.find(sourceName->second);
            if (value == original.params.end()) {
                diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                    "original device is missing " + sourceName->second + " parameter"};
                return false;
            }
            mapped[targetName->second] = value->second;
        }
    }

    for (const auto& semantic : {"length", "width", "finger_width"}) {
        const auto name = targetDescriptor.normalized_to_cdf.find(semantic);
        if (name == targetDescriptor.normalized_to_cdf.end()) continue;
        const auto text = mapped.find(name->second);
        double value = 0.0;
        if (text == mapped.end() || !parseEngineeringNumber(text->second, value)) {
            diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                std::string("cannot parse inherited ") + semantic + "; expressions must be evaluated by the host"};
            return false;
        }
        const auto* constraint = findParameterConstraint(targetDescriptor, semantic);
        if (constraint != nullptr && ValidateParameterConstraint(*constraint) &&
            QuantizeParameter(value, *constraint) != value) {
            diagnostic = {DiagCode::DeviceParameterOutOfRange,
                std::string("inherited ") + semantic + " is outside the target master's legal CDF domain"};
            return false;
        }
    }
    const auto lengthName = targetDescriptor.normalized_to_cdf.find("length");
    if (lengthName == targetDescriptor.normalized_to_cdf.end()) {
        diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
            "target master does not declare a length CDF parameter"};
        return false;
    }
    return true;
}

bool validateFixedBiasInputs(const CascodeTransformRequest& request,
                             Diagnostic& diagnostic)
{
    if (!request.solved_bias.has_value() ||
        !request.solved_bias->ok ||
        (!request.experimental_dc && (request.solved_bias->electrical_check.experimental_dc ||
         request.solved_bias->electrical_check.native_parameter_trials)) ||
        !request.bias_template.has_value() || !request.bias_template->ok ||
        request.bias_template->ports.size() != 5 ||
        request.bias_template->elements.size() != 2 ||
        request.vbias_vhigh_net.empty() || request.vbias_vlow_net.empty()) {
        diagnostic = {DiagCode::BiasUnavailable,
            "FixedBias requires a successful DC solve and a two-device, five-port VBIAS template"};
        return false;
    }
    diagnostic = {};
    return true;
}

} // namespace

std::string MosParameterMode(const DeviceDescriptor& descriptor)
{
    const auto& p = descriptor.normalized_to_cdf;
    const bool hasLength = p.count("length") != 0;
    const bool hasWidth = p.count("width") != 0;
    const bool hasFingerWidth = p.count("finger_width") != 0;
    const bool hasFingers = p.count("fingers") != 0;
    if (hasLength && hasWidth && !hasFingerWidth) return "w_l";
    if (hasLength && hasFingerWidth && hasFingers && !hasWidth) return "wf_nf_l";
    return "unsupported";
}

bool ApplyCustomMosParameters(const DeviceDescriptor& descriptor,
                              const std::optional<double>& width,
                              const std::optional<double>& fingerWidth,
                              const std::optional<double>& fingers,
                              const std::optional<double>& length,
                              std::map<std::string, std::string>& parameters,
                              Diagnostic& diagnostic)
{
    const std::pair<const char*, const std::optional<double>*> requested[] = {
        {"width", &width}, {"finger_width", &fingerWidth},
        {"fingers", &fingers}, {"length", &length},
    };
    for (const auto& [semantic, value] : requested) {
        if (!value->has_value()) continue;
        if (!std::isfinite(**value) || **value <= 0.0) {
            diagnostic = {DiagCode::BadParam, std::string("custom ") + semantic + " must be positive"};
            return false;
        }
        const auto* constraint = findParameterConstraint(descriptor, semantic);
        const auto mapping = descriptor.normalized_to_cdf.find(semantic);
        if (constraint == nullptr || mapping == descriptor.normalized_to_cdf.end() ||
            constraint->cdf_name.empty() || constraint->cdf_name != mapping->second ||
            !ValidateParameterConstraint(*constraint)) {
            diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                "target master has no valid CDF constraint for custom " + std::string(semantic)};
            return false;
        }
        const double actual = QuantizeParameter(**value, *constraint);
        const double tolerance = 1e-12 * std::max(1.0, std::fabs(**value));
        if (!std::isfinite(actual) || std::fabs(actual - **value) > tolerance) {
            diagnostic = {DiagCode::DeviceParameterOutOfRange,
                "custom " + std::string(semantic) + " is not a legal quantized CDF value"};
            return false;
        }
        parameters[constraint->cdf_name] = FormatAutoBiasParameter(actual);
    }
    diagnostic = {};
    return true;
}

TransformOutcome applyCascode(Netlist& nl, const CascodeTransformRequest& request,
                              const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(request.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " does not exist"});
        return out;
    }
    auto* original = subckt->find(request.target);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "instance " + request.target + " does not exist"});
        return out;
    }

    const auto* originalDescriptor = catalog.Find(original->model);
    if (!engineeringMos(originalDescriptor)) {
        out.diags.push_back({originalDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "target " + request.target + " is not a registered MOS"});
        return out;
    }

    const std::string newMaster = request.new_master.empty() ? original->model : request.new_master;
    const auto* newDescriptor = catalog.Find(newMaster);
    if (!engineeringMos(newDescriptor)) {
        out.diags.push_back({newDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "new master " + newMaster + " is not a registered MOS"});
        return out;
    }
    if ((!request.experimental_dc && (originalDescriptor->native_parameter_trials ||
         newDescriptor->native_parameter_trials)) ||
        originalDescriptor->kind == DeviceKind::Mos || newDescriptor->kind == DeviceKind::Mos) {
        out.diags.push_back({DiagCode::DeviceIncompatible,
            "Cascode requires a proven polarity; native trials are only allowed with experimental_dc"});
        return out;
    }
    if (request.experimental_dc &&
        (!originalDescriptor->bulk_rule_complete || !newDescriptor->bulk_rule_complete)) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved, "experimental Cascode still requires a proven Bulk rule"});
        return out;
    }
    if (request.experimental_dc &&
        !HaveCompatibleVoltageDomains({originalDescriptor, newDescriptor})) {
        out.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
            "experimental Cascode: original and new devices have incompatible known voltage domains"});
        return out;
    }
    if (newDescriptor->kind != originalDescriptor->kind) {
        out.diags.push_back(checkPolarity(originalDescriptor->kind, newDescriptor->kind));
        return out;
    }
    if (newMaster != original->model) {
        const auto selection = SelectCrossFlavorCandidates(
            *originalDescriptor, catalog, request.voltage_domain, request.experimental_dc);
        const auto accepted = std::find_if(selection.accepted.begin(), selection.accepted.end(),
            [&newMaster](const DeviceDescriptor* descriptor) {
                return descriptor->master == newMaster;
            });
        if (accepted == selection.accepted.end()) {
            out.diags.push_back({DiagCode::DeviceIncompatible,
                "dynamic PDK catalog does not allow the combination of " + original->model + " and " + newMaster});
            return out;
        }
    }
    if (!supportsVoltageDomain(*originalDescriptor, request.voltage_domain, request.experimental_dc) ||
        !supportsVoltageDomain(*newDescriptor, request.voltage_domain, request.experimental_dc)) {
        out.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
                            "original or new device does not support voltage domain " + request.voltage_domain});
        return out;
    }
    if (request.gate_policy != GatePolicy::SharedGate &&
        request.gate_policy != GatePolicy::FixedBias) {
        out.diags.push_back({DiagCode::BadParam, "invalid Cascode gate policy"});
        return out;
    }
    Diagnostic diagnostic;
    MosNets originalNets;
    if (!readMosNets(*original, catalog, originalNets, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    std::string drain = originalNets.drain;
    std::string gate = originalNets.gate;
    std::string source = originalNets.source;
    std::string originalBulk = originalNets.bulk;

    std::string cascodeBulk = originalBulk;
    if (newDescriptor->kind == DeviceKind::MosN) {
        if (request.nmos_bulk_net.empty()) {
            out.diags.push_back({DiagCode::BulkPolicyUnresolved,
                                "NMOS Cascode lacks a valid global Bulk net"});
            return out;
        }
        cascodeBulk = request.nmos_bulk_net;
    } else if (!(request.tie_isolated_pmos_to_source && newDescriptor->isolated_well) &&
               originalBulk.empty()) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved,
                            "PMOS Cascode cannot inherit or establish a valid Bulk connection"});
        return out;
    }

    std::map<std::string, std::string> inheritedParameters;
    const bool hasSolvedCascodeParameters =
        request.gate_policy == GatePolicy::FixedBias &&
        request.solved_bias.has_value() &&
        (request.solved_bias->ok) &&
        !request.solved_bias->sizing.cascode_parameters.empty();
    if (hasSolvedCascodeParameters) {
        // 自动 VBIAS 求解器已经按目标 master 的实际 CDF 约束
        // 生成并量化这些参数。这里直接使用求解结果，避免再用
        // width/length 假设覆盖 FinFET 的 nfin/l 参数域。
        if (const auto quantized = QuantizeAutoBiasParameters(*newDescriptor,
                request.solved_bias->sizing.cascode_parameters, "cascode",
                {true, request.experimental_dc}); !quantized.ok) {
            diagnostic = quantized.diagnostic;
            out.diags.push_back(std::move(diagnostic));
            return out;
        } else {
            inheritedParameters = quantized.out;
        }
    } else if (!mapInheritedParameters(*original, *originalDescriptor,
                                       *newDescriptor, inheritedParameters,
                                       diagnostic)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
    }
    if (!ApplyCustomMosParameters(*newDescriptor, request.custom_width,
            request.custom_finger_width, request.custom_fingers,
            request.custom_length, inheritedParameters, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    NameAllocator names(working, request.subckt);
    const std::string cascodeName = names.Allocate(NameKind::Instance, request.target + "_CAS");
    const std::string middleNet = names.Allocate(NameKind::Net, request.target + "_MID");
    if (newDescriptor->kind == DeviceKind::MosP &&
        request.tie_isolated_pmos_to_source && newDescriptor->isolated_well) {
        cascodeBulk = middleNet; // 新管实际 Source；不改变原管 Bulk。
    }

    std::string biasOutputNet;
    std::string biasSubcktName;
    if (request.gate_policy == GatePolicy::FixedBias) {
        Diagnostic biasDiagnostic;
        if (!validateFixedBiasInputs(request, biasDiagnostic)) {
            out.diags.push_back(std::move(biasDiagnostic));
            return out;
        }
        biasOutputNet = names.Allocate(NameKind::Net,
            request.bias_template->output_net + "_" + request.target);
        if (std::find(subckt->pins.begin(), subckt->pins.end(), biasOutputNet) !=
                subckt->pins.end() ||
            subckt->netRefCount(biasOutputNet) != 0) {
            out.diags.push_back({DiagCode::TargetConflict,
                "Bias output net already exists in the original circuit; the auto-solve result must use an isolated name"});
            return out;
        }
        biasSubcktName = names.Allocate(NameKind::Subckt,
            request.bias_template->template_id + "_" + request.target);
        if (working.find(biasSubcktName) != nullptr) {
            out.diags.push_back({DiagCode::TargetConflict,
                "VBIAS template subckt name conflicts with an existing hierarchy"});
            return out;
        }
    }

    const std::string cascodeGate = request.gate_policy == GatePolicy::SharedGate
        ? gate : biasOutputNet;

    Instance cascode;
    cascode.name = cascodeName;
    cascode.model = newMaster;
    cascode.params = std::move(inheritedParameters);
    cascode.nets.resize(newDescriptor->terminal_count);
    // 两种极性、同型和异型均只断开原 Drain：原D→MID，新S→MID，新D→原D网。
    if (!writeMosNets(cascode, catalog, {drain, cascodeGate, middleNet, cascodeBulk},
                      diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    if (std::any_of(cascode.nets.begin(), cascode.nets.end(),
                    [](const std::string& net) { return net.empty(); })) {
        out.diags.push_back({DiagCode::InvalidTerminalMap,
                            "new MOS has unbound required terminals"});
        return out;
    }
    if (!setTerminalNet(*original, catalog, TerminalRole::Drain, middleNet, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    subckt->insertAfter(request.target, cascode);
    out.modifiedInstances.push_back(request.target);
    out.addedInstances.push_back(cascodeName);
    out.addedNets.push_back(middleNet);
    out.parameter_groups[request.target + "_CASCODE_SIZE"] = {request.target, cascodeName};

    if (request.gate_policy == GatePolicy::FixedBias) {
        // 模板作为独立 subckt 存在（一只复制管＋R_BIAS、固定端口序、求解量化参数）；
        // 父层只放一个层级实例，不散落模板器件。VS_ORIG/VG_CTRL 接变换前
        // 原管的 Source/Gate 网（上面 readMosNets 读出后原管才被改写）。
        Subckt biasSubckt;
        biasSubckt.name = biasSubcktName;
        biasSubckt.pins = request.bias_template->ports;
        for (const auto& element : request.bias_template->elements) {
            Instance elementInstance;
            elementInstance.name = element.name;
            elementInstance.model = element.model;
            elementInstance.nets = element.nets;
            elementInstance.params = element.params;
            biasSubckt.instances.push_back(std::move(elementInstance));
        }
        Instance biasInstance;
        biasInstance.name = names.Allocate(NameKind::Instance, "I_" + biasOutputNet);
        biasInstance.model = biasSubcktName;
        biasInstance.nets = {request.vbias_vhigh_net, request.vbias_vlow_net,
                             source, gate, biasOutputNet};
        // 注意顺序：先改父层实例表，再 push 模板 subckt——push_back 可能让
        // working.subckts 重新分配，之后 subckt 指针就失效了。
        subckt->instances.push_back(biasInstance);
        working.subckts.push_back(std::move(biasSubckt));
        out.bias_instances.push_back(biasInstance.name);
        out.addedNets.push_back(biasOutputNet);
        out.iq_delta += request.solved_bias->sizing.iq_delta;
    } else {
        out.notes.push_back("common-gate mode reuses the original Gate and adds no new Bias");
    }

    transaction.Commit();
    return out;
}

TransformOutcome applyResistor(Netlist& nl, const ResistorTransformRequest& request,
                               const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(request.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " does not exist"});
        return out;
    }
    auto* original = subckt->find(request.target);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "instance " + request.target + " does not exist"});
        return out;
    }
    const auto* originalDescriptor = catalog.Find(original->model);
    if (!engineeringMos(originalDescriptor)) {
        out.diags.push_back({originalDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "target " + request.target + " is not a registered MOS"});
        return out;
    }
    const auto* resistorDescriptor = catalog.Find(request.resistor.master);
    if (resistorDescriptor == nullptr) {
        out.diags.push_back({DiagCode::UnknownModel,
                            "resistor master " + request.resistor.master + " is not registered"});
        return out;
    }
    if (resistorDescriptor->kind != DeviceKind::Resistor) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "specified master is not a PDK resistor"});
        return out;
    }
    if (!request.experimental_dc && (originalDescriptor->native_parameter_trials ||
        resistorDescriptor->native_parameter_trials)) {
        out.diags.push_back({DiagCode::DeviceIncompatible,
            "native parameter trials are only allowed with experimental_dc"});
        return out;
    }
    if (request.experimental_dc &&
        (originalDescriptor->kind == DeviceKind::Mos || !originalDescriptor->bulk_rule_complete)) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved, "experimental resistor transform still requires MOS polarity and Bulk rules"});
        return out;
    }
    if (request.resistor.resistance_parameter.empty()) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "PDK resistor template does not declare a resistance parameter"});
        return out;
    }
    if (request.search_lower_factor <= 0.0 ||
        request.search_upper_factor < request.search_lower_factor) {
        out.diags.push_back({DiagCode::BadParam, "invalid resistor sizing search ratio"});
        return out;
    }

    const double minimum = std::max(resistorDescriptor->limits.min_resistance,
                                    request.resistor.minimum_resistance);
    const double maximum = std::min(resistorDescriptor->limits.max_resistance,
                                    request.resistor.maximum_resistance);
    if (!std::isfinite(minimum) || minimum < 0.0 || maximum < minimum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "the valid resistance ranges of the PDK and the resistor template do not intersect"});
        return out;
    }

    double seed = 0.0;
    std::string seedSource;
    if (request.requested_resistance.has_value()) {
        seed = request.requested_resistance.value();
        seedSource = "user input";
    } else if (request.case_default_resistance.has_value()) {
        seed = request.case_default_resistance.value();
        seedSource = "case preset";
    } else {
        if (minimum <= 0.0 || !std::isfinite(maximum) || maximum <= 0.0) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                                "PDK resistance range lacks finite positive bounds; cannot determine a mid default value"});
            return out;
        }
        seed = std::exp((std::log(minimum) + std::log(maximum)) / 2.0);
        seedSource = "geometric midpoint of PDK valid range";
    }
    if (!std::isfinite(seed) || seed <= 0.0) {
        out.diags.push_back({DiagCode::ResistorEquivalenceUnsupported,
                            "resistance specified by user or case is not a valid positive real number"});
        return out;
    }
    double actual = snapToGrid(seed, request.resistor.grid);
    if (resistorDescriptor->native_parameter_trials) {
        const auto proposal = resistorDescriptor->parameter_constraints.find("resistance");
        if (proposal == resistorDescriptor->parameter_constraints.end() ||
            proposal->second.cdf_name != request.resistor.resistance_parameter ||
            proposal->second.discrete_values.empty() || !ValidateParameterConstraint(proposal->second)) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                "experimental resistor lacks a finite resistance trial set"});
            return out;
        }
        actual = QuantizeParameter(seed, proposal->second);
        if (std::fabs(actual - seed) > 1e-12 * std::max(std::fabs(seed), std::fabs(actual))) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                "requested resistance is not in the declared finite native trials"});
            return out;
        }
        out.notes.push_back("resistance comes from finite native trials; it is only PROPOSED until the actual CDF and netlist readback pass");
    }
    if (!std::isfinite(actual) || actual <= 0.0 || actual < minimum || actual > maximum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "equivalent resistance cannot be quantized into the PDK resistor's valid range"});
        return out;
    }
Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) ||
        !getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) ||
        !getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) ||
        (originalDescriptor->terminal_count != 3 &&
         !getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic))) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    NameAllocator names(working, request.subckt);
    const std::string resistorName = names.Allocate(NameKind::Instance,
                                                     request.target + "_RS");
    const std::string sourceInternal = names.Allocate(NameKind::Net,
                                                       request.target + "_RS_INT");
    Instance resistor;
    resistor.name = resistorName;
    resistor.model = request.resistor.master;
    resistor.nets.resize(resistorDescriptor->terminal_count);
    if (!setTerminalNet(resistor, catalog, TerminalRole::Positive,
                        sourceInternal, diagnostic) ||
        !setTerminalNet(resistor, catalog, TerminalRole::Negative, source, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    for (const auto& binding : resistorDescriptor->terminal_index) {
        const auto role = binding.first;
        if (role == TerminalRole::Positive || role == TerminalRole::Negative) {
            continue;
        }
        const auto extra = request.resistor.extra_terminal_nets.find(role);
        if (extra == request.resistor.extra_terminal_nets.end() || extra->second.empty()) {
            out.diags.push_back({DiagCode::InvalidTerminalMap,
                                "extra terminals of a multi-terminal resistor are not bound in the ResistorTemplate"});
            return out;
        }
        if (!setTerminalNet(resistor, catalog, role, extra->second, diagnostic)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
    }
    if (std::any_of(resistor.nets.begin(), resistor.nets.end(),
                    [](const std::string& net) { return net.empty(); })) {
        out.diags.push_back({DiagCode::InvalidTerminalMap,
                            "resistor has unbound physical terminals"});
        return out;
    }
    resistor.params[request.resistor.resistance_parameter] = resistorDescriptor->native_parameter_trials
        ? FormatAutoBiasParameter(actual) : formatEngineering(actual);
    if (resistorDescriptor->native_parameter_trials) {
        for (const auto& entry : resistorDescriptor->parameter_constraints) {
            const auto& constraint = entry.second;
            if (constraint.discrete_values.empty() || !ValidateParameterConstraint(constraint)) {
                out.diags.push_back({DiagCode::ResistorMappingFailed, "resistor native geometry trials are incomplete"});
                return out;
            }
            if (constraint.cdf_name == request.resistor.resistance_parameter) {
                continue;
            }
            resistor.params[constraint.cdf_name] = FormatAutoBiasParameter(constraint.discrete_values.front());
        }
        const auto resistorQuantized = QuantizeAutoBiasParameters(*resistorDescriptor,
                resistor.params, "source_resistor", {true, true});
        if (!resistorQuantized.ok) {
            diagnostic = resistorQuantized.diagnostic;
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
        resistor.params = resistorQuantized.out;
    }
    if (!setTerminalNet(*original, catalog, TerminalRole::Source,
                        sourceInternal, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    subckt->insertAfter(request.target, resistor);
    out.modifiedInstances.push_back(request.target);
    out.addedInstances.push_back(resistorName);
    out.addedNets.push_back(sourceInternal);
    out.numeric_outputs["R_seed"] = seed;
    out.numeric_outputs["R_actual"] = actual;

    const double sizingMinimum = std::max(minimum, request.search_lower_factor * seed);
    const double sizingMaximum = std::min(maximum, request.search_upper_factor * seed);
    if (sizingMaximum < sizingMinimum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "resistor sizing range does not intersect the PDK valid range"});
        return out;
    }
    out.parameter_ranges[resistorName + "." + request.resistor.resistance_parameter] = {
        actual, sizingMinimum, sizingMaximum, request.resistor.grid
    };

    out.notes.push_back("resistance seed source: " + seedSource);
    out.notes.push_back(originalDescriptor->terminal_count == 3
        ? "preserves Drain/Gate and device parameters of the 3-terminal MOS, only adding a series resistor on the Source path"
        : "preserves the original MOS's Drain/Gate/Bulk and device parameters, only adding a series resistor on the Source path");

    transaction.Commit();
    return out;
}

StackPlan planStack(const Netlist& nl, const StackTransformRequest& request,
                    const DeviceCatalog& catalog)
{
    StackPlan plan;
    const auto* subckt = nl.find(request.subckt);
    if (subckt == nullptr) {
        plan.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " does not exist"});
        return plan;
    }
    const auto* original = subckt->find(request.target);
    if (original == nullptr) {
        plan.diags.push_back({DiagCode::NotFound, "instance " + request.target + " does not exist"});
        return plan;
    }
    const auto* descriptor = catalog.Find(original->model);
    if (!engineeringMos(descriptor)) {
        plan.diags.push_back({descriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                              "target " + request.target + " is not a registered MOS"});
        return plan;
    }
    if ((descriptor->native_parameter_trials && (!request.experimental_dc || request.structure_only)) ||
        (request.experimental_dc && request.structure_only)) {
        plan.diags.push_back({DiagCode::DeviceIncompatible,
            "native parameter trials are only allowed in standalone experimental_dc mode"});
        return plan;
    }
    if (request.experimental_dc && !descriptor->bulk_rule_complete) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved, "experimental Stack still requires a proven Bulk rule"});
        return plan;
    }
    const int maximumStages = std::min(100, descriptor->limits.max_stack_level);
    if (request.stage_count < 2 || request.stage_count > maximumStages) {
        plan.diags.push_back({DiagCode::BadParam,
                              "Stack stage count must be between 2 and the PDK/product upper limit"});
        return plan;
    }
    if (!request.structure_only && !supportsVoltageDomain(*descriptor, request.voltage_domain, request.experimental_dc)) {
        plan.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
                              "Stack device does not support voltage domain " + request.voltage_domain});
        return plan;
    }
    if (request.gate_policy != GatePolicy::SharedGate) {
        plan.diags.push_back({DiagCode::BadParam,
                              "current Stack only supports sharing the original Gate across all stages"});
        return plan;
    }
    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!(getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) &&
          (descriptor->terminal_count == 3 ||
           getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic)))) {
        plan.diags.push_back(std::move(diagnostic));
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::Mos) {
        plan.diags.push_back({DiagCode::MissingInput, "electrical Stack requires a proven MOS polarity"});
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::MosN && request.nmos_bulk_net.empty()) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved,
                              "NMOS Stack lacks a valid global Bulk net"});
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::MosP && bulk.empty() &&
        !(descriptor->isolated_well && request.tie_isolated_pmos_to_source)) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved,
                              "PMOS Stack cannot inherit or establish a valid Bulk connection"});
        return plan;
    }

    auto& logical = plan.stack;
    logical.subckt = request.subckt;
    logical.original_instance = request.target;
    logical.master = original->model;
    logical.stage_count = request.stage_count;
    logical.intent = request.intent;
    logical.gate_policy = request.gate_policy;
    logical.drain_net = drain;
    logical.original_gate_net = gate;
    logical.source_net = source;
    logical.original_bulk_net = bulk;
    logical.original_params = original->params;

    NameAllocator names(nl, request.subckt);
    // The logical order is Drain -> Source.  Preserve the original instance
    // identity on the drain side so existing OP references keep their anchor;
    // only the additional source-side stages receive feature suffixes.
    logical.stage_instance_names.push_back(request.target);
    for (int stage = 1; stage < request.stage_count; ++stage) {
        logical.stage_instance_names.push_back(names.Allocate(
            NameKind::Instance, request.target + "_S" + std::to_string(stage)));
    }
    for (int boundary = 1; boundary < request.stage_count; ++boundary) {
        logical.middle_nets.push_back(names.Allocate(
            NameKind::Net, request.target + "_MID" + std::to_string(boundary)));
    }
    for (int stage = 0; stage < request.stage_count; ++stage) {
        logical.gate_nets.push_back(gate);
    }
    for (int stage = 0; stage < request.stage_count; ++stage) {
        const std::string stageSource = stage == request.stage_count - 1
            ? source : logical.middle_nets[static_cast<std::size_t>(stage)];
        if (request.structure_only || descriptor->terminal_count == 3) {
            logical.bulk_nets.push_back(bulk);
        } else if (descriptor->kind == DeviceKind::MosN) {
            logical.bulk_nets.push_back(request.nmos_bulk_net);
        } else if (descriptor->isolated_well && request.tie_isolated_pmos_to_source) {
            logical.bulk_nets.push_back(stageSource);
        } else {
            logical.bulk_nets.push_back(bulk);
        }
        // 保留原 master 未涉及的参数；自定义值按真实 CDF 约束量化。
        std::map<std::string, std::string> stageParams = original->params;
        if (!ApplyCustomMosParameters(*descriptor, request.custom_width,
                request.custom_finger_width, request.custom_fingers,
                request.custom_length, stageParams, diagnostic)) {
            plan.diags.push_back(std::move(diagnostic));
            return plan;
        }
        logical.stage_params.push_back(std::move(stageParams));
    }
    logical.sizing_groups[request.target + "_STACK_COMMON_SIZE"] =
        logical.stage_instance_names;
    return plan;
}

TransformOutcome materializeStack(Netlist& nl, const LogicalMosStack& stack,
                                  const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(stack.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + stack.subckt + " does not exist"});
        return out;
    }
    auto* original = subckt->find(stack.original_instance);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "the original MOS for this Stack plan no longer exists"});
        return out;
    }
    if (stack.stage_count < 2 ||
        stack.stage_instance_names.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.middle_nets.size() != static_cast<std::size_t>(stack.stage_count - 1) ||
        stack.gate_nets.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.bulk_nets.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.stage_params.size() != static_cast<std::size_t>(stack.stage_count)) {
        out.diags.push_back({DiagCode::BadParam, "LogicalMosStack content is incomplete"});
        return out;
    }
    if (stack.gate_policy != GatePolicy::SharedGate ||
        std::any_of(stack.gate_nets.begin(), stack.gate_nets.end(),
                    [&](const std::string& net) { return net != stack.original_gate_net; })) {
        out.diags.push_back({DiagCode::BadParam,
                            "current Stack materialization only allows sharing the original Gate across all stages"});
        return out;
    }
    if (original->model != stack.master || original->params != stack.original_params) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "the original MOS changed after the plan was generated; please re-plan the Stack"});
        return out;
    }
    const auto* descriptor = catalog.Find(stack.master);
    if (!engineeringMos(descriptor)) {
        out.diags.push_back({descriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "Stack master is not a registered MOS"});
        return out;
    }
    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!(getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) &&
          (descriptor->terminal_count == 3 ||
           getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic)))) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    if (drain != stack.drain_net || gate != stack.original_gate_net ||
        source != stack.source_net || bulk != stack.original_bulk_net) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "the original MOS ports changed after the plan was generated; please re-plan the Stack"});
        return out;
    }
    for (std::size_t index = 1; index < stack.stage_instance_names.size(); ++index) {
        const auto& instanceName = stack.stage_instance_names[index];
        if (subckt->find(instanceName) != nullptr) {
            out.diags.push_back({DiagCode::TargetConflict,
                                "a Stack instance name in the plan is already in use"});
            return out;
        }
    }
    for (const auto& middleNet : stack.middle_nets) {
        if (subckt->netRefCount(middleNet) != 0 ||
            std::find(subckt->pins.begin(), subckt->pins.end(), middleNet) != subckt->pins.end()) {
            out.diags.push_back({DiagCode::TargetConflict,
                                "a Stack internal net name in the plan is already in use"});
            return out;
        }
    }

    for (int stage = 0; stage < stack.stage_count; ++stage) {
        Instance instance;
        instance.name = stack.stage_instance_names[static_cast<std::size_t>(stage)];
        instance.model = stack.master;
        instance.params = stack.stage_params[static_cast<std::size_t>(stage)];
        instance.nets.resize(descriptor->terminal_count);
        const std::string stageDrain = stage == 0
            ? stack.drain_net : stack.middle_nets[static_cast<std::size_t>(stage - 1)];
        const std::string stageSource = stage == stack.stage_count - 1
            ? stack.source_net : stack.middle_nets[static_cast<std::size_t>(stage)];
        const bool bound = descriptor->terminal_count == 3
            ? (setTerminalNet(instance, catalog, TerminalRole::Drain, stageDrain, diagnostic) &&
               setTerminalNet(instance, catalog, TerminalRole::Gate, stack.gate_nets[static_cast<std::size_t>(stage)], diagnostic) &&
               setTerminalNet(instance, catalog, TerminalRole::Source, stageSource, diagnostic))
            : writeMosNets(instance, catalog,
                          {stageDrain, stack.gate_nets[static_cast<std::size_t>(stage)],
                           stageSource, stack.bulk_nets[static_cast<std::size_t>(stage)]},
                          diagnostic);
        if (!bound) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
        if (std::any_of(instance.nets.begin(), instance.nets.end(),
                        [](const std::string& net) { return net.empty(); })) {
            out.diags.push_back({DiagCode::InvalidTerminalMap,
                                "Stack MOS has unbound required terminals"});
            return out;
        }
        if (stage == 0) {
            *original = instance;
            out.modifiedInstances.push_back(instance.name);
        } else {
            subckt->instances.push_back(instance);
            out.addedInstances.push_back(instance.name);
        }
    }
    out.addedNets.insert(out.addedNets.end(), stack.middle_nets.begin(), stack.middle_nets.end());
    out.parameter_groups = stack.sizing_groups;

    out.notes.push_back("Stack logical object has been materialized for simulation/export; the original instance is kept on the Drain side and all stages share the original Gate");
    transaction.Commit();
    return out;
}

// ---------- 内部工具 ----------

// 取目标 MOS 实例并做公共检查（模型登记、是 MOS、4 端子）
static Instance* fetchMos(Subckt* s, const std::string& target,
                          const ModelDb& db, DeviceKind& pol,
                          TransformOutcome& out) {
    Instance* m = s->find(target);
    if (!m) {
        out.diags.push_back({DiagCode::NotFound, "instance " + target + " does not exist"});
        return nullptr;
    }
    auto mi = db.find(m->model);
    if (mi == db.end()) {
        out.diags.push_back({DiagCode::MissingInput,
                             "model " + m->model + " is not registered in ModelDb"});
        return nullptr;
    }
    pol = mi->second.kind;
    if (pol != DeviceKind::MosN && pol != DeviceKind::MosP) {
        out.diags.push_back({DiagCode::NotMos,
                             target + " is not a MOS (model=" + m->model + ")"});
        return nullptr;
    }
    if (static_cast<int>(m->nets.size()) != 4) {
        out.diags.push_back({DiagCode::MissingInput,
                             target + " does not have 4 terminals (D G S B)"});
        return nullptr;
    }
    return m;
}

// ---------- 1) cascode（同型 / 异型）----------

TransformOutcome applyCascode(Netlist& nl, const std::string& subName,
                              const std::string& target,
                              const CascodeOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " does not exist"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) {
        return out;
    }

    // 异型：新 master 必须同极性
    std::string master = o.newMaster.empty() ? m->model : o.newMaster;
    if (!o.newMaster.empty()) {
        auto it = db.find(master);
        if (it == db.end()) {
            out.diags.push_back({DiagCode::MissingInput,
                                 "new master " + master + " is not registered"});
            return out;
        }
        auto pc = checkPolarity(pol, it->second.kind);
        if (isError(pc.code)) {
            out.diags.push_back(pc);
            return out;
        }
    }

    // headroom 校验（提供了工作点才做；估算值由调用方标注）
    if (o.op.valid) {
        double vxMin = std::fabs(o.vdsat1) + std::fabs(o.margin);
        auto hc = checkCascodeHeadroom(std::fabs(o.op.vds),
                                       o.vdsat1, o.vdsat2, o.margin, vxMin);
        if (isError(hc.code)) {
            out.diags.push_back(hc);
            return out;
        }
    }

    // 新管 bulk
    BulkResolution bulk;
    auto bd = resolveBulk(pol, o.sourceTiedBulk, o.nmosBulkNet, m->nets[3],
                          bulk);
    if (isError(bd.code)) {
        out.diags.push_back(bd);
        return out;
    }

    // 结构改写：两种极性都加在原 Drain 侧，原 G/S/B 不变。
    const std::string dnet = m->nets[0];
    const std::string x = target + "_MID";
    const std::string vbias = o.biasNet.empty() ? "VBIAS_1" : o.biasNet;

    Instance m2;
    m2.name = target + "_CAS";
    m2.model = master;
    m2.params = m->params;                       // 初值 1:1 继承原管
    m2.nets = {dnet, vbias, x, bulk.tie_to_source ? x : bulk.net};
    m->nets[0] = x;
    out.modifiedInstances.push_back(m->name);
    s->insertAfter(m->name, m2);
    out.addedInstances.push_back(m2.name);
    out.addedNets.push_back(x);
    out.addedNets.push_back(vbias);

    out.notes.push_back("VBIAS net " + vbias +
                        " is taken over by the registered fixed active Mirror+Replica template");
    return out;
}

// ---------- 2) MOS Source 串联电阻（旧演示入口） ----------

TransformOutcome applyResistor(Netlist& nl, const std::string& subName,
                               const std::string& target,
                               const ResistorOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " does not exist"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) {
        return out;
    }

    auto ri = db.find(o.resModel);
    if (ri == db.end() || ri->second.kind != DeviceKind::Resistor ||
        ri->second.terminalCount != 2) {
        out.diags.push_back({DiagCode::MissingInput,
                             "resistor model " + o.resModel + " is not registered or is not a 2-terminal resistor"});
        return out;
    }
    if (o.rTarget <= 0.0) {
        out.diags.push_back({DiagCode::MissingInput,
                             "R seed value not provided"});
        return out;
    }
    // 搜索带校验：0.5~2 × rSeed
    if (o.rSeed > 0.0 &&
        (o.rTarget < 0.5 * o.rSeed || o.rTarget > 2.0 * o.rSeed)) {
        out.diags.push_back({DiagCode::BadParam,
                             "R is outside the 0.5~2x Rseed search band"});
        return out;
    }

    const std::string snet = m->nets[2];
    const std::string internal = target + "_RS_INT";
    m->nets[2] = internal;
    out.modifiedInstances.push_back(target);

    Instance r;
    r.name = target + "_RS";
    r.nets = {internal, snet};
    r.model = o.resModel;
    r.params["r"] = formatEngineering(snapToGrid(o.rTarget, o.grid));
    s->insertAfter(target, r);
    out.addedInstances.push_back(r.name);
    out.addedNets.push_back(internal);
    out.notes.push_back("preserves the original MOS, only adding a series resistor on the Source path; resistance is not auto-derived from the DC operating point");
    return out;
}

// ---------- 3) stack 串联（分级偏置）----------

TransformOutcome applyStack(Netlist& nl, const std::string& subName,
                            const std::string& target,
                            const StackOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " does not exist"});
        return out;
    }
    if (o.n < 2 || o.n > 100) {
        out.diags.push_back({DiagCode::BadParam, "stage count N must be between 2 and 100"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) {
        return out;
    }
    // bulk 策略
    BulkResolution bulk;
    auto bd = resolveBulk(pol, o.sourceTiedBulk, o.nmosBulkNet, m->nets[3],
                          bulk);
    if (isError(bd.code)) {
        out.diags.push_back(bd);
        return out;
    }

    const std::string dnet = m->nets[0];
    const std::string gnet = m->nets[1];
    const std::string snet = m->nets[2];
    const std::string masterModel = m->model;
    const auto savedParams = m->params;

    // 串联链按 Drain -> Source 记录：Drain侧保留原实例名，
    // 后续依次为 M0_S1...M0_S(N-1)，且全部Gate短接原Gate。
    std::vector<std::string> mid(o.n + 1);
    for (int k = 1; k < o.n; ++k) {
        mid[k] = target + "_MID" + std::to_string(k);
        out.addedNets.push_back(mid[k]);
    }
    for (int k = 0; k < o.n; ++k) {
        Instance stg;
        stg.name = k == 0 ? target : target + "_S" + std::to_string(k);
        stg.model = masterModel;
        stg.params = savedParams;
        std::string d = (k == 0) ? dnet : mid[k];
        std::string ss = (k == o.n - 1) ? snet : mid[k + 1];
        std::string b = bulk.tie_to_source ? ss : bulk.net;
        stg.nets = {d, gnet, ss, b};
        if (k == 0) {
            *m = stg;
            out.modifiedInstances.push_back(target);
        } else {
            s->instances.push_back(stg);
            out.addedInstances.push_back(stg.name);
        }
    }

    std::ostringstream os;
    os << "stack N=" << o.n << ": Drain side keeps " << target
       << ", remaining stages are named toward the Source end as " << target
       << "_S1..., and all Gates share the original net " << gnet;
    out.notes.push_back(os.str());
    return out;
}

} // namespace st
