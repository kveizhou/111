/**
 * 结构变换嵌入 LDO 优化主流程的适配层实现。
 * - 配置从 project_cfg.json 读取（BaseData/jsoncpp）。
 * - 电路获取：优先使用 st_engine 的 ProcessVirtuosoBackend（后端脚本）做
 *   Snapshot 得到基线网表；后端未配置时回退为主流程 NetlistBuilder
 *   （cds 目录 + LCV 出 spectre 网表）。
 * - 变换：ChangeSet.Confirm + Generate 重放全部请求，得到期望网表并落盘。
 */
#include "structure_transform_service.h"

#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <utility>

#include "common/core/netlist/scs.h"
#include "common/core/ops/binder/tech_binder.h"
#include "common/core/ops/lib_parse.h"
#include "common/core/ops/netlist_creator/netlist_creator.h"
#include "common/core/tech/tech.h"
#include "platform/clustorservice/clustor_service.h"
#include "platform/json/basedata_interface.h"
#include "platform/lib/environment.h"
#include "platform/lib/subprocess.h"
#include "st/AutoBias.h"
#include "st/BackendDcEvaluationHost.h"
#include "st/DcSolver.h"
#include "st/JsonWriter.h"
#include "st/Naming.h"
#include "st/PdkCatalog.h"
#include "st/Netlist.h"
#include "st/OaPlan.h"
#include "st/Packaging.h"
#include "st/PythonRuntime.h"
#include "st/Standalone.h"
#include "st/VariantVerifier.h"
#include "st/VirtuosoBackend.h"

namespace maau::stengine {

namespace {

constexpr char kPvt[] = "pvt";
constexpr char kCorner[] = "corner";

// 简易 JSON 字符串读取（jsoncpp BaseData 值转 string，兼容空值）。
std::string StringOf(const maau::platform::BaseData &data, const char *key)
{
    return data.isMember(key) ? data[key].asString() : std::string();
}

// 从 "lib_cell_view" 风格组合字段拆出三段；主流程 project_cfg.json 以
// source_dut_lib/cell/view 等独立字段给出，这里直接读独立字段。
bool ReadDesign(const maau::platform::BaseData &data, const std::string &prefix,
                std::string &lib, std::string &cell, std::string &view)
{
    lib = StringOf(data, (prefix + "_lib").c_str());
    cell = StringOf(data, (prefix + "_cell").c_str());
    view = StringOf(data, (prefix + "_view").c_str());
    return !lib.empty() && !cell.empty();
}

// 期望网表文本落盘。
bool WriteNetlistFile(const std::filesystem::path &path,
                      const st::Netlist &netlist, std::string &message)
{
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    if (error) {
        message = "cannot create directory " + path.parent_path().string() + ": " + error.message();
        return false;
    }
    std::ofstream output(path);
    if (!output) {
        message = "cannot open netlist file for writing: " + path.string();
        return false;
    }
    output << st::emitSpectre(netlist);
    output.close();
    if (!output) {
        message = "failed to write netlist file: " + path.string();
        return false;
    }
    return true;
}

// 把 GUI 传入的层次点路径（如 I2.M0）解析为 st-engine 可定位的扁平目标
// （subckt + instance）。点路径按主流程网表层级语义：I2 是 core subckt 的
// 直接实例（model=子模块名），M0 是子模块内的叶实例。
// 无点路径（顶层 MOS 或调用方已给出扁平 subckt+instance）保持原样。

// 解析 "<高>:<低>" 范围字符串（如 "7:0"），返回 {high, low}；失败返回 false。
bool ParseBusRange(const std::string &text, long long &high, long long &low)
{
    const auto colon = text.find(':');
    if (colon == std::string::npos) { return false; }
    try {
        high = std::stoll(text.substr(0, colon));
        low = std::stoll(text.substr(colon + 1));
        return true;
    } catch (...) {
        return false;
    }
}

// 在 subckt 里找实例：先按精确名（name<index> 格式），找不到时按数组范围
// 格式（name<high:low>）匹配下标 index 是否落在范围内。全展开网表（export_snapshot）
// 保留范围格式（I19<119:0>），ScanMos 网表（NetlistBuilder）展开成单下标
// （I19<60>），两者必须互相兼容才能解析同一路径。
const st::Instance *FindArrayInstance(const st::Subckt &subckt,
                                      const std::string &name)
{
    // 先精确匹配（含 <> 下标的完整名）。
    const auto *exact = subckt.find(name);
    if (exact != nullptr) { return exact; }
    // name 形如 "I19<60>"：拆出 base（I19）+ index（60）。
    const auto lt = name.rfind('<');
    const auto gt = name.rfind('>');
    if (lt == std::string::npos || gt == std::string::npos || gt < lt) {
        return nullptr;
    }
    const std::string base = name.substr(0, lt);
    long long index = 0;
    try {
        index = std::stoll(name.substr(lt + 1, gt - lt - 1));
    } catch (...) {
        return nullptr;
    }
    // 遍历 subckt 实例，匹配 base<high:low> 且 index 在 [low, high] 内。
    for (const auto &inst : subckt.instances) {
        const auto &in = inst.name;
        const auto ilt = in.rfind('<');
        const auto igt = in.rfind('>');
        if (ilt == std::string::npos || igt == std::string::npos || igt < ilt) {
            continue;
        }
        if (in.substr(0, ilt) != base) continue;
        long long high = 0, low = 0;
        if (!ParseBusRange(in.substr(ilt + 1, igt - ilt - 1), high, low)) {
            continue;
        }
        if (index >= std::min(high, low) && index <= std::max(high, low)) {
            return &inst;
        }
    }
    return nullptr;
}

// 在顶层散落实例 (topInstances) 里按名查找, 含数组范围兼容。
// TB 顶层 (如 testbench cell) 不是 subckt 定义, 它的实例被解析到
// Netlist::topInstances ; 层次路径的起点可能在顶层而非 subckt 内。
const st::Instance *FindTopInstance(const st::Netlist &baseline, const std::string &name)
{
    for (const auto &inst : baseline.topInstances) {
        if (inst.name == name) { return &inst; }
    }
    // 数组范围兼容 (I19<60> vs I19<119:0>)
    const auto lt = name.rfind('<');
    const auto gt = name.rfind('>');
    if (lt == std::string::npos || gt == std::string::npos || gt < lt) {
        return nullptr;
    }
    const std::string base = name.substr(0, lt);
    long long index = 0;
    try {
        index = std::stoll(name.substr(lt + 1, gt - lt - 1));
    } catch (...) {
        return nullptr;
    }
    for (const auto &inst : baseline.topInstances) {
        const auto &in = inst.name;
        const auto ilt = in.rfind('<');
        const auto igt = in.rfind('>');
        if (ilt == std::string::npos || igt == std::string::npos || igt < ilt) {
            continue;
        }
        if (in.substr(0, ilt) != base) continue;
        long long high = 0, low = 0;
        if (!ParseBusRange(in.substr(ilt + 1, igt - ilt - 1), high, low)) {
            continue;
        }
        if (index >= std::min(high, low) && index <= std::max(high, low)) {
            return &inst;
        }
    }
    return nullptr;
}

// 在 subckt 或顶层实例中查找实例 (统一入口)。
// subckt 非空时在 subckt 内查找;subckt 为空时在顶层实例中查找。
const st::Instance *FindInstanceInScope(const st::Netlist &baseline, const std::string &subcktName,
                                        const std::string &instName)
{
    if (!subcktName.empty()) {
        const auto *sub = baseline.find(subcktName);
        if (sub != nullptr) {
            const auto *inst = sub->find(instName);
            if (inst != nullptr) { return inst; }
            return FindArrayInstance(*sub, instName);
        }
        // subckt 找不到,可能是 TB 顶层 (不是 subckt 定义), 回退顶层
    }
    return FindTopInstance(baseline, instName);
}

bool ResolveHierarchyTarget(const st::Netlist &baseline,
                            const std::string &core_subckt,
                            std::string hier_path,
                            st::InstancePath &target,
                            std::string &message)
{
    // GUI 显示使用 [29:0]，内部/OA 统一使用 <29:0>。目标解析后始终
    // 回写完整实例名，选中任一 bit 也只能操作其所属完整阵列。
    hier_path = st::NormalizeMosArrayName(std::move(hier_path));
    if (hier_path.find('.') == std::string::npos) {
        // 非层次路径：调用方（如 ldo_sizing）已显式给出 subckt+instance，
        // 或 GUI 传的是叶子 MOS（此时 baseline 顶层 = transform_subckt）。
        // target.instance 可能是完整层次路径（如 ldo_top.I50.M0），此处
        // hier_path 已是裁剪后的叶 MOS（M0），以 hier_path 为准。
        target.instance = hier_path;
        // GUI 传的 target.subckt 可能是顶层 cell 名（在 baseline 里不存在），
        // 找不到时回退到 core_subckt（transform_subckt，Snapshot 导出顶层）。
        auto *owner = baseline.find(target.subckt);
        if (owner == nullptr) {
            target.subckt = core_subckt;
            owner = baseline.find(target.subckt);
        }
        const auto *instance = owner == nullptr ? nullptr
            : FindInstanceInScope(baseline, target.subckt, target.instance);
        if (instance == nullptr) {
            message = "target device not found in baseline netlist: " +
                      target.subckt + "." + target.instance;
            return false;
        }
        target.instance = instance->name;
        message.clear();
        return true;
    }

    const auto segments = [&hier_path]() {
        std::vector<std::string> parts;
        std::size_t begin = 0;
        while (true) {
            const auto end = hier_path.find('.', begin);
            parts.push_back(hier_path.substr(begin, end - begin));
            if (end == std::string::npos) { break; }
            begin = end + 1;
        }
        return parts;
    }();
    if (segments.empty() || segments.front().empty()) {
        message = "transform target is empty";
        return false;
    }

    std::string subckt = core_subckt;
    for (std::size_t index = 0; index + 1 < segments.size(); ++index) {
        const auto *inst = FindInstanceInScope(baseline, subckt, segments[index]);
        if (inst == nullptr) {
            // 报错时列出 subckt 或顶层里与该 base 同名的实例，便于确认。
            const auto lt = segments[index].rfind('<');
            const std::string base = (lt == std::string::npos)
                ? segments[index] : segments[index].substr(0, lt);
            std::string candidates;
            const auto *owner = baseline.find(subckt);
            if (owner != nullptr) {
                for (const auto &cand : owner->instances) {
                    if (cand.name.rfind(base, 0) == 0) {
                        if (!candidates.empty()) candidates += ", ";
                        candidates += cand.name;
                    }
                }
            } else {
                for (const auto &cand : baseline.topInstances) {
                    if (cand.name.rfind(base, 0) == 0) {
                        if (!candidates.empty()) candidates += ", ";
                        candidates += cand.name;
                    }
                }
            }
            message = "instance " + segments[index] + " not found in " +
                      (subckt.empty() ? "top level" : "subckt " + subckt) +
                      " (cannot resolve hierarchy path " + hier_path +
                      "); same-base instances: [" +
                      (candidates.empty() ? "none" : candidates) + "]";
            return false;
        }
        subckt = inst->model;
    }
    const auto *leafInst = FindInstanceInScope(baseline, subckt, segments.back());
    if (leafInst == nullptr) {
        message = "target device not found in baseline netlist: " + hier_path +
                  " (" + (subckt.empty() ? "top level" : "subckt " + subckt) +
                  " has no instance " + segments.back() + ")";
        return false;
    }
    target.subckt = subckt;
    target.instance = leafInst->name;
    message.clear();
    return true;
}

// 修改原因：物化直接使用 STEP2 已解析的 owner；旧的二次解析、祖先 context 和占位布局由局部封装入口替代。
// 把结构变换 Run() 执行过程的关键步骤写入 work_dir/logs/structure_transform_run.log
// （追加模式），方便定位哪一步出错、错在哪。每条日志带 [阶段] 前缀。
void AppendRunLog(const std::filesystem::path &work_dir, const std::string &line)
{
    std::error_code ec;
    const std::filesystem::path logDir = work_dir / "logs";
    std::filesystem::create_directories(logDir, ec);
    if (ec) {
        return;
    }
    std::ofstream logFile(logDir / "structure_transform_run.log", std::ios::app);
    if (!logFile) {
        return;
    }
    logFile << line << std::endl;
}

// 打印 plan 构建结果的概览（delete/create/wires/ports 数量），供日志定位。
std::string PlanSummary(const st::OaMaterializationPlan &plan)
{
    std::ostringstream summary;
    summary << "  clone_on_write=" << plan.clone_map.size()
            << " delete_instances=" << plan.delete_instances.size()
            << " create_instances=" << plan.create_instances.size()
            << " create_ports=" << plan.create_ports.size()
            << " direct_wires=" << plan.direct_wires.size()
            << " wires=" << plan.wires.size();
    for (const auto &mapping : plan.clone_map) {
        summary << "\n    clone: " << mapping.hierarchy_path
                << " -> " << mapping.target.library << "/" << mapping.target.cell
                << " (parent=" << mapping.parent_hierarchy_path
                << " inst=" << mapping.parent_instance_name << ")";
    }
    for (const auto &deletion : plan.delete_instances) {
        summary << "\n    delete: " << deletion.hierarchy_path << ":" << deletion.name;
    }
    for (const auto &creation : plan.create_instances) {
        summary << "\n    create: " << creation.hierarchy_path << ":" << creation.name
                << " master=" << creation.master.library << "/" << creation.master.cell
                << " loc=(" << creation.location.x << "," << creation.location.y << ")";
    }
    return summary.str();
}

// 从 scan-pdk 生成的 DeviceCatalog 写出 snapshot 需要的 device_policy.tsv
// （legacy 19 列 TSV 契约）。逻辑与 Cli.cpp 的 writeScannedDevicePolicy 一致，
// 不依赖任何静态样例 tsv——新 PDK 也能自动生成。
bool WriteDevicePolicyTsv(const st::DeviceCatalog &catalog,
                          const std::filesystem::path &path,
                          std::string &message)
{
    std::ostringstream output;
    output << "oa_library\toa_cell\tkind\tvoltage_domain\tcompatible_masters\t"
              "normalized_to_cdf\tisolated_well\tsource_drain_interchangeable\t"
              "min_width\tmax_width\tmin_length\tmax_length\tmin_resistance\t"
              "max_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\t"
              "terminal_order\n";
    const auto number = [](double value) {
        std::ostringstream stream;
        stream << std::setprecision(17) << value;
        return stream.str();
    };
    const auto join = [](const std::vector<std::string> &values,
                         const char separator) {
        std::string joined;
        for (const auto &value : values) {
            if (!joined.empty()) joined += separator;
            joined += value;
        }
        return joined;
    };
    for (const auto &[master, device] : catalog.Descriptors()) {
        const char *kind = device.kind == st::DeviceKind::MosN ? "mos_n" :
                           device.kind == st::DeviceKind::MosP ? "mos_p" :
                           device.kind == st::DeviceKind::Mos ? "mos" :
                           device.kind == st::DeviceKind::Resistor ? "resistor" : nullptr;
        if (kind == nullptr) continue;
        if (device.oa_library.empty() || device.oa_cell.empty() ||
            device.terminal_names_by_index.empty()) {
            message = "scanned device lacks OA identity or physical terminals: " + master;
            return false;
        }
        std::vector<std::string> mappings;
        for (const auto &[semantic, cdf] : device.normalized_to_cdf) {
            if (!semantic.empty() && !cdf.empty()) {
                mappings.push_back(semantic + ':' + cdf);
            }
        }
        for (const auto &[semantic, constraint] : device.parameter_constraints) {
            if (constraint.cdf_name.empty()) continue;
            const std::string mapping = semantic + ':' + constraint.cdf_name;
            if (std::find(mappings.begin(), mappings.end(), mapping) == mappings.end()) {
                mappings.push_back(mapping);
            }
        }
        const std::vector<std::string> fields = {
            device.oa_library, device.oa_cell, kind,
            device.voltage_domain, "self", join(mappings, ','),
            device.isolated_well ? "true" : "false",
            device.source_drain_interchangeable ? "true" : "false",
            number(device.limits.min_width), number(device.limits.max_width),
            number(device.limits.min_length), number(device.limits.max_length),
            number(device.limits.min_resistance), number(device.limits.max_resistance),
            number(device.limits.max_abs_vgs), number(device.limits.max_abs_vds),
            number(device.limits.max_abs_vgb),
            std::to_string(device.limits.max_stack_level),
            join(device.terminal_names_by_index, ',')};
        for (std::size_t index = 0; index < fields.size(); ++index) {
            const auto &field = fields[index];
            if (field.find_first_of("\t\r\n") != std::string::npos) {
                message = "scanned device field contains illegal separator: " + master;
                return false;
            }
            if (index != 0) output << '\t';
            output << (field.empty() ? "-" : field);
        }
        output << '\n';
    }
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    if (error) {
        message = "cannot create device policy directory: " + path.parent_path().string();
        return false;
    }
    std::ofstream file(path);
    if (!file) {
        message = "cannot open device policy for writing: " + path.string();
        return false;
    }
    file << output.str();
    file.close();
    if (!file) {
        message = "failed to write device policy: " + path.string();
        return false;
    }
    return true;
}

// 修改原因：扫描仍使用原 ProcessVirtuosoBackend 协议，只替换内置 Python 后端的启动方式。
// 显式配置的外部 backend_script 仍交给原 runner，避免改变已有接入接口。
class PythonModuleBackendRunner final : public st::standalone::ProcessRunner {
public:
    PythonModuleBackendRunner(st::standalone::ProcessRunner& runner, std::string root)
        : runner_(runner), root_(std::move(root)) {}
    st::standalone::ProcessResult Run(const std::vector<std::string>& arguments,
                                      const std::filesystem::path& logPath) override
    {
        const std::vector<std::string> options(arguments.begin() + 1, arguments.end());
        return runner_.Run(st::runtime::ModuleCommand(root_,
            "common.structure_transform.st_virtuoso_backend", options), logPath);
    }
private:
    st::standalone::ProcessRunner& runner_;
    std::string root_;
};

// 修改原因：物化/提升/清理统一导入模块，不检查 .py 文件；原本地/集群执行选择保持不变。
bool RunStPythonModule(const StructureTransformConfig &config,
                       const std::string &module,
                       const std::vector<std::string> &moduleArgs,
                       const std::string &logFileName,
                       const std::string &logTag,
                       const std::filesystem::path &workDir,
                       std::string &message)
{
    const auto algoRoot = st::runtime::OptAlgoRoot(config.opt_algo_root);
    const auto args = st::runtime::ModuleCommand(algoRoot, module, moduleArgs);
    const auto logDir = workDir / "logs";
    std::filesystem::create_directories(logDir);
    const auto logFile = (logDir / logFileName).string();
    AppendRunLog(workDir, "[" + logTag + "] module=" + module +
        " python=" + args.front() + " opt_algo_root=" + algoRoot +
        " skill=" + st::runtime::SkillDirectory(algoRoot) + " log=" + logFile);

    if (config.cluster_config.is_valid) {
        const auto clusterKey = platform::ClustorService::RunCmd(
            config.cluster_config, st::runtime::ShellCommand(args), logDir.string());
        if (!clusterKey.Ok()) {
            message = logTag + " job submission failed: " + clusterKey.error().ToString();
            return false;
        }
        const auto jobState = platform::ClustorService::WaitForJobToFinish(*clusterKey);
        if (jobState != platform::JobState::succeeded) {
            message = logTag + " job execution failed (JobState " +
                std::to_string(static_cast<int>(jobState)) + "), logs at " + logDir.string();
            return false;
        }
        return true;
    }

    platform::Subprocess proc;
    platform::Subprocess::Options options;
    options.StdIn("").Stdout(logFile).Stderr(logFile);
    options.Cwd(algoRoot);
    // 修改原因：-c 启动代码负责继承并补充 PYTHONPATH/SKILLPATH/PATH，集群与本地使用相同环境逻辑。
    platform::Environment environment;
    environment.GetEnvp();
    std::vector<std::string> envList;
    for (const auto &[key, value] : environment.GetEnvs()) {
        envList.push_back(platform::Environment::compose({key, value}));
    }
    proc.Run(args, args.front(), options, &envList);
    const auto state = proc.Wait();
    if (state != platform::Subprocess::EXITED || proc.GetStatusCode().GetExitCode() != 0) {
        message = logTag + " execution failed (exit code " +
            std::to_string(proc.GetStatusCode().GetExitCode()) + "), see " + logFile;
        return false;
    }
    return true;
}

// 变换后 OA view 操作（提升/清理）的公共入口：拼参数调
// common/structure_transform/st_finalize_transform.py（SKILL 侧对应
// st_finalize_transform.il）。mode 取 "finalize"（把 <baseView>__maau_struct_transform
// 覆盖回原 view 并删除后缀 view）或 "discard"（只删后缀 view）。
// 放在匿名命名空间内：AppendRunLog 在此命名空间，保持一致可见性。
StructureTransformOpResult RunTransformViewOp(const StructureTransformConfig &config,
                                              const std::vector<std::pair<std::string, std::string>> &cells,
                                              const char *mode,
                                              const std::string &logTag)
{
    StructureTransformOpResult result;
    const std::filesystem::path root(config.work_dir);
    AppendRunLog(root, "[" + logTag + "] 开始 mode=" + mode +
        " work_dir=" + root.string() +
        " cds=" + config.target_cds_path +
        " view=" + config.target_dut_view +
        " cells数=" + std::to_string(cells.size()));

    if (config.target_cds_path.empty() || config.target_dut_view.empty()) {
        result.message = logTag + " config missing cds path or DUT view";
        AppendRunLog(root, "[" + logTag + "] 入参校验失败: " + result.message);
        return result;
    }
    if (cells.empty()) {
        // 没有 history 涉及的 cell：等价于无可操作对象，视为成功（空操作）。
        result.ok = true;
        result.message = logTag + ": no cells to process";
        AppendRunLog(root, "[" + logTag + "] 空 cells，按空操作成功返回");
        return result;
    }

    // 修改原因：打包可仅保留扩展模块，存在性由 Python 导入检查并将实际加载文件写入日志。
    const std::string module = "common.structure_transform.st_finalize_transform";

    // 按 lib 分组：同一 lib 下的 cell 共用一次 python/SKILL 调用。
    // 不同 lib 的 cell 必须分开调（--lib 参数一次只能传一个 lib）。
    std::map<std::string, std::vector<std::string>> cellsByLib;
    for (const auto &[lib, cell] : cells) {
        cellsByLib[lib].push_back(cell);
    }
    AppendRunLog(root, "[" + logTag + "] 涉及 " +
        std::to_string(cellsByLib.size()) + " 个 lib: " +
        [&cellsByLib]() {
            std::string s;
            for (const auto &[lib, cs] : cellsByLib) {
                if (!s.empty()) s += ", ";
                s += lib + "(" + std::to_string(cs.size()) + ")";
            }
            return s;
        }());

    bool allOk = true;
    std::string allMessage;
    for (const auto &[lib, cellList] : cellsByLib) {
        // cells 拼成逗号分隔串传给 python（python 侧再拼成 SKILL list）。
        std::string cellsArg;
        for (std::size_t i = 0; i < cellList.size(); ++i) {
            if (i != 0) cellsArg += ",";
            cellsArg += cellList[i];
        }
        const std::vector<std::string> args = {
            "--mode", mode,
            "--cds-path", config.target_cds_path,
            "--lib", lib,
            "--base-view", config.target_dut_view,
            "--cells", cellsArg,
            "--work-dir", root.string()
        };
        AppendRunLog(root, "[" + logTag + "] module=" + module +
            " lib=" + lib + " cells=[" + cellsArg + "]");

        std::string message;
        if (!RunStPythonModule(config, module, args, logTag + ".log", logTag, root, message)) {
            allOk = false;
            allMessage += "[" + lib + "] " + message + "; ";
            AppendRunLog(root, "[" + logTag + "] " + lib + " 执行失败: " + message);
        }
    }
    if (!allOk) {
        result.message = logTag + " partial failure: " + allMessage;
        AppendRunLog(root, "[" + logTag + "] 部分 lib 执行失败: " + result.message);
        return result;
    }

    // RunStPythonModule 只反映 python 进程的退出码，不反映 SKILL 侧
    // StDiscard/StFinalize 的实际处理结果（删没删 view 由 SKILL 返回值决定，
    // python 侧靠解析 ST_FTZ_DONE <n> stdout 拿到）。这里把对应日志摘出来，
    // 便于排查"撤销后 view 未删"类问题（实际未删 vs 删了但 GUI 没看到）。
    // 日志实际位置是 workDir/logs/<logTag>.log（RunStPythonModule 内部拼的），
    // 不是 root/<logTag>.log。
    const auto logPath = root / "logs" / (logTag + ".log");
    std::error_code readEc;
    if (std::filesystem::exists(logPath, readEc)) {
        std::ifstream ifs(logPath);
        std::string line;
        std::string doneLine;
        std::string skillOutput;
        while (std::getline(ifs, line)) {
            if (line.find("ST_FTZ_DONE") != std::string::npos) {
                doneLine = line;
            }
            // SKILL 侧 stFtzDeleteView/StFinalizeTransformViews 的 printf 输出
            // （"ST_FTZ: deleting ..." / "ST_FTZ: promoted ..." / "ST_FTZ: skip ..."）
            // 也一并收集，便于定位是哪个 cell 没删成功。
            if (line.find("ST_FTZ:") != std::string::npos) {
                skillOutput += "  " + line + "\n";
            }
        }
        if (!doneLine.empty()) {
            AppendRunLog(root, "[" + logTag + "] SKILL 侧处理结果: " + doneLine);
        } else {
            AppendRunLog(root, "[" + logTag + "] 日志中未找到 ST_FTZ_DONE 行，"
                "SKILL 侧可能未执行/未输出处理结果");
        }
        if (!skillOutput.empty()) {
            AppendRunLog(root, "[" + logTag + "] SKILL 明细:\n" + skillOutput);
        }
    } else {
        AppendRunLog(root, "[" + logTag + "] 未找到日志文件: " + logPath.string());
    }
    for (const auto &[lib, cell] : cells) {
        result.touched_views.push_back(lib + "/" + cell + "/" +
                                       config.target_dut_view);
    }
    result.ok = true;
    result.message = logTag + " done: " + std::to_string(cells.size()) +
        " cell(s) processed, mode=" + mode;
    AppendRunLog(root, "[" + logTag + "] 成功: " + result.message);
    return result;
}

// 从 DUT 网表提取电源/地网络名（用于 VBIAS 的 vhigh/vlow 轨）。
// 搜索 DUT subckt 的 pins + topInstances 的端网，找含 VDD/PVDD/POWER 的为 vhigh，
// 含 GND/AGND/VSS/GROUND 的为 vlow。
void ExtractPowerRailNets(const st::Netlist &baseline,
                          const std::string &core_subckt,
                          std::string &vhigh, std::string &vlow)
{
    vhigh.clear();
    vlow.clear();
    const auto *subckt = baseline.find(core_subckt);
    if (subckt != nullptr) {
        for (const auto &pin : subckt->pins) {
            const std::string lower = [&pin]() {
                std::string s;
                for (char c : pin) s += static_cast<char>(std::tolower(c));
                return s;
            }();
            if (vhigh.empty() && (lower.find("vdd") != std::string::npos ||
                                  lower.find("power") != std::string::npos ||
                                  lower.find("pvdd") != std::string::npos)) {
                vhigh = pin;
            }
            if (vlow.empty() && (lower.find("gnd") != std::string::npos ||
                                 lower.find("vss") != std::string::npos ||
                                 lower.find("ground") != std::string::npos ||
                                 lower.find("agnd") != std::string::npos)) {
                vlow = pin;
            }
        }
    }
    // topInstances 的端网里也找
    for (const auto &inst : baseline.topInstances) {
        for (const auto &net : inst.nets) {
            const std::string lower = [&net]() {
                std::string s;
                for (char c : net) s += static_cast<char>(std::tolower(c));
                return s;
            }();
            if (vhigh.empty() && (lower.find("vdd") != std::string::npos ||
                                  lower.find("pvdd") != std::string::npos)) {
                vhigh = net;
            }
            if (vlow.empty() && (lower.find("gnd") != std::string::npos ||
                                 lower.find("vss") != std::string::npos)) {
                vlow = net;
            }
        }
    }
}

// FixedBias Cascode：基线真实 DC + 完整候选逐 R 真实 DC；禁止结构占位成功。
bool SolveVbiasForCascode(const st::Netlist &baseline,
                          const st::DeviceCatalog &catalog,
                          const StructureTransformConfig &config,
                          StructureTransformRequest &resolved,
                          st::standalone::ProcessRunner *injectedRunner,
                          std::string &message)
{
    if (resolved.type != st::TransformType::SameTypeCascode &&
        resolved.type != st::TransformType::CrossFlavorCascode) {
        return true;
    }
    if (resolved.cascode.gate_policy != st::GatePolicy::FixedBias ||
        resolved.cascode.solved_bias.has_value()) {
        return true;
    }
    const auto *subckt = baseline.find(resolved.target.subckt);
    const auto *target = subckt == nullptr ? nullptr : subckt->find(resolved.target.instance);
    if (target == nullptr) {
        message = "VBIAS: target instance not found: " + resolved.target.subckt + "/" + resolved.target.instance;
        return false;
    }
    const auto *descriptor = catalog.Find(target->model);
    if (descriptor == nullptr) {
        message = "VBIAS: target MOS not in device catalog: " + target->model;
        return false;
    }
    // 公共候选宿主封装并替换 DUT 根 CellView。层级叶目标不能冒充根实例。
    if (resolved.target.subckt != config.target_dut_cell) {
        message = "VBIAS real-DC candidate requires a MOS directly in DUT root " +
            config.target_dut_cell + "; hierarchical target is " + resolved.target.subckt +
            "/" + resolved.target.instance;
        return false;
    }
    if (config.source_tb_lib.empty() || config.source_tb_cell.empty() || config.source_tb_view.empty() ||
        config.target_tb_lib.empty() || config.target_tb_cell.empty() || config.target_tb_view.empty()) {
        message = "VBIAS real-DC requires the selected source/target testbench LCV; no bench is configured";
        return false;
    }
    if (config.source_tb_lib != config.target_tb_lib || config.source_tb_cell != config.target_tb_cell ||
        config.source_tb_view != config.target_tb_view) {
        message = "VBIAS real-DC currently requires identical source/target bench LCV";
        return false;
    }
    if (config.corner.empty()) {
        message = "VBIAS real-DC requires an explicitly selected bench corner";
        return false;
    }
    if (config.skill_script.empty()) {
        message = "VBIAS real-DC requires the OA materialization SKILL script";
        return false;
    }

    std::string sourceNet, gateNet, bulkNet;
    std::size_t sourceIndex = 0, gateIndex = 0, bulkIndex = 0;
    st::Diagnostic termDiag;
    if (!catalog.ResolveTerminal(target->model, st::TerminalRole::Source, target->nets.size(), sourceIndex, termDiag) ||
        !catalog.ResolveTerminal(target->model, st::TerminalRole::Gate, target->nets.size(), gateIndex, termDiag) ||
        !catalog.ResolveTerminal(target->model, st::TerminalRole::Bulk, target->nets.size(), bulkIndex, termDiag) ||
        sourceIndex >= target->nets.size() || gateIndex >= target->nets.size() || bulkIndex >= target->nets.size()) {
        message = "VBIAS: cannot resolve original MOS Source/Gate/Bulk terminals: " + termDiag.message;
        return false;
    }
    sourceNet = target->nets[sourceIndex];
    gateNet = target->nets[gateIndex];
    bulkNet = target->nets[bulkIndex];
    std::string vhighNet = config.vbias_vhigh_net;
    std::string vlowNet = config.vbias_vlow_net;
    if (vhighNet.empty() || vlowNet.empty()) {
        std::string detectedHigh, detectedLow;
        ExtractPowerRailNets(baseline, resolved.target.subckt, detectedHigh, detectedLow);
        if (vhighNet.empty()) vhighNet = detectedHigh;
        if (vlowNet.empty()) vlowNet = detectedLow;
    }
    if (vhighNet.empty() || vlowNet.empty()) {
        message = "VBIAS: cannot determine power/ground nets from baseline netlist";
        return false;
    }
    if (descriptor->kind == st::DeviceKind::MosN && resolved.cascode.nmos_bulk_net.empty()) {
        // 只继承原管真实 Bulk；为空时拒绝猜测全局地。
        resolved.cascode.nmos_bulk_net = bulkNet;
    }
    if (descriptor->kind == st::DeviceKind::MosN && resolved.cascode.nmos_bulk_net.empty()) {
        message = "VBIAS: original NMOS Bulk net is empty; refusing to invent a global Bulk";
        return false;
    }

    st::AutoBiasTemplateRequest templateRequest;
    templateRequest.operation_id = resolved.operation_id;
    templateRequest.polarity = descriptor->kind;
    templateRequest.voltage_domain = descriptor->voltage_domain;
    templateRequest.vhigh_net = vhighNet;
    templateRequest.vlow_net = vlowNet;
    templateRequest.original_source_net = sourceNet;
    templateRequest.control_gate_net = gateNet;
    templateRequest.control_master = target->model;
    templateRequest.cascode_master = resolved.cascode.new_master.empty() ? target->model : resolved.cascode.new_master;
    templateRequest.array_range = st::MosArrayRange(target->name);

    std::string safeId = resolved.operation_id.empty() ? "cascode" : resolved.operation_id;
    std::replace_if(safeId.begin(), safeId.end(), [](unsigned char c) {
        return !(std::isalnum(c) || c == '_' || c == '-');
    }, '_');
    const std::filesystem::path root(config.work_dir);
    const std::filesystem::path solveDir = root / "analysis" / safeId;
    const std::filesystem::path scanDir = solveDir / "pdk_scan";
    const st::Subckt *rootSub = baseline.find(config.target_dut_cell);
    if (rootSub == nullptr) {
        message = "VBIAS real-DC DUT root is absent from baseline: " + config.target_dut_cell;
        return false;
    }
    const std::string dutLib = rootSub->library.empty() ? config.target_dut_lib : rootSub->library;
    const st::CellViewRef source{dutLib, config.target_dut_cell, config.target_dut_view,
                                 config.target_cds_path, {}};
    const st::CellViewRef bench{config.source_tb_lib, config.source_tb_cell, config.source_tb_view,
                                config.target_cds_path, {}};
    st::standalone::BackendPaths paths{
        std::filesystem::path(config.target_cds_path) / "cds.lib",
        solveDir / "source_roundtrip.scs", solveDir / "target_roundtrip.scs",
        solveDir / "logs", config.target_dut_cell};
    paths.device_policy = root / "before/device_policy.tsv";
    paths.operating_point_catalog = scanDir / "device_catalog.tsv";
    paths.experimental_dc = resolved.cascode.experimental_dc;
    st::standalone::PosixProcessRunner localRunner;
    st::standalone::ProcessRunner &runner = injectedRunner != nullptr ? *injectedRunner : localRunner;
    st::standalone::PythonModuleBackendRunner moduleRunner(
        runner, st::runtime::OptAlgoRoot(config.opt_algo_root));
    st::standalone::ProcessRunner &backendRunner = config.backend_script.empty()
        ? static_cast<st::standalone::ProcessRunner &>(moduleRunner) : runner;
    st::standalone::ProcessVirtuosoBackend backend(config.backend_script, paths, backendRunner);

    const st::standalone::PdkScanOutputs scanOutputs{
        scanDir / "device_catalog.tsv", scanDir / "pdk_identity.tsv"};
    auto status = backend.ScanPdk(source, scanOutputs);
    if (!status.ok) {
        message = "VBIAS real PDK scan failed: " + status.message;
        return false;
    }
    std::string pdkVersion;
    if (!st::standalone::LoadPdkVersionFromScanIdentity(
            scanOutputs.pdk_identity_tsv, pdkVersion, message)) {
        message = "VBIAS real PDK identity unavailable: " + message;
        return false;
    }
    st::DeviceCatalog scannedCatalog;
    std::vector<st::Diagnostic> catalogDiagnostics;
    if (!st::standalone::LoadDeviceCatalogTsv(
            scanOutputs.raw_catalog_tsv, scannedCatalog, catalogDiagnostics)) {
        message = "VBIAS real PDK catalog unavailable: " +
            (catalogDiagnostics.empty() ? std::string("unknown parse error") : catalogDiagnostics.front().message);
        return false;
    }
    st::DeviceCatalog solveCatalog;
    for (const auto &[name, base] : catalog.Descriptors()) {
        auto desc = base;
        desc.reliability_complete = false;
        desc.bulk_rule_complete = false;
        desc.pdk_version = pdkVersion;
        if (const auto *scanned = scannedCatalog.Find(name)) {
            desc.reliability_complete = scanned->reliability_complete;
            desc.bulk_rule_complete = scanned->bulk_rule_complete;
            desc.limits = scanned->limits;
            desc.isolated_well = scanned->isolated_well;
        }
        st::Diagnostic addDiagnostic;
        if (!solveCatalog.Add(desc, addDiagnostic)) {
            message = "VBIAS merged PDK catalog rejected " + name + ": " + addDiagnostic.message;
            return false;
        }
    }
    backend.UseOperatingPointCatalog(scanOutputs.raw_catalog_tsv);

    st::AnalysisIdentity identity;
    identity.dut_hash = st::standalone::CellViewIdentityHash(
        source.library, source.cell, source.view, source.storage_path);
    identity.bench_hash = st::standalone::CellViewIdentityHash(
        bench.library, bench.cell, bench.view, bench.storage_path);
    identity.pdk_version = pdkVersion;
    identity.corner = config.corner;
    identity.topology_hash = st::ComputeNetlistTopologyHash(baseline);
    identity.parameter_hash = st::ComputeNetlistParameterHash(baseline);
    identity.solver_version = "cascode-resistance-dc-v1";

    const std::filesystem::path baselineDir = solveDir / "baseline_op";
    const st::standalone::OperatingPointOutputs baselineOutputs{
        baselineDir / "identity.tsv", baselineDir / "mos.tsv"};
    status = backend.RunOperatingPoint(source, bench, identity, baselineOutputs);
    if (!status.ok) {
        message = "VBIAS baseline real DC failed (run-op backend is required): " + status.message;
        return false;
    }
    st::OperatingPointSnapshot baselineOp;
    std::vector<st::Diagnostic> opDiagnostics;
    if (!st::LoadOperatingPointTsv(baselineOutputs.identity_tsv, baselineOutputs.mos_tsv,
                                   baselineOp, opDiagnostics) ||
        !st::IsReusable(baselineOp, identity)) {
        message = "VBIAS baseline OP is unreadable or has mismatched identity: " +
            (opDiagnostics.empty() ? std::string("identity mismatch") : opDiagnostics.front().message);
        return false;
    }

    st::standalone::RootGeometry geometry;
    std::vector<st::Diagnostic> geometryDiagnostics;
    if (!st::standalone::LoadRootGeometryTsv(root / "before/geometry.tsv", geometry, geometryDiagnostics)) {
        message = "VBIAS candidate geometry unavailable: " +
            (geometryDiagnostics.empty() ? std::string("unknown") : geometryDiagnostics.front().message);
        return false;
    }
    std::ostringstream progress;
    st::standalone::CandidateHostConfig hostConfig{
        baseline, solveCatalog, geometry, config.target_dut_cell, dutLib,
        config.target_dut_cell + "__dc_" + safeId, config.skill_script,
        solveDir / "candidates", true};
    st::standalone::BackendDcEvaluationHost host(
        backend, {source, bench}, std::move(hostConfig), progress);

    st::AutoBiasSolveRequest request;
    request.baseline = baseline;
    request.root_subckt = config.target_dut_cell;
    request.target_instance = resolved.target.instance;
    request.template_request = templateRequest;
    request.baseline_op = baselineOp;
    request.nominal_identity = identity;
    request.nmos_bulk_net = resolved.cascode.nmos_bulk_net;
    request.tie_isolated_pmos_to_source = resolved.cascode.tie_isolated_pmos_to_source;
    request.custom_width = resolved.cascode.custom_width;
    request.custom_finger_width = resolved.cascode.custom_finger_width;
    request.custom_fingers = resolved.cascode.custom_fingers;
    request.custom_length = resolved.cascode.custom_length;
    std::stringstream corners(config.pvt_corners);
    std::string corner;
    while (std::getline(corners, corner, ',')) {
        if (!corner.empty() && corner != config.corner) request.pvt_corners.push_back(corner);
    }

    auto solved = st::SolveAutoBias(request, solveCatalog, host);
    const std::filesystem::path tracePath = solveDir / "resistance_dc_trace.jsonl";
    std::error_code traceError;
    std::filesystem::create_directories(tracePath.parent_path(), traceError);
    std::ofstream trace(tracePath);
    for (const auto &line : solved.trace_lines) trace << line << '\n';
    AppendRunLog(root, "[VBIAS_DC] " + progress.str());
    AppendRunLog(root, "[VBIAS_DC] trace=" + tracePath.string());
    if (!solved.ok) {
        message = "VBIAS resistance DC search failed; generation stopped: " +
            (solved.diagnostics.empty() ? std::string("no feasible real-DC candidate") : solved.diagnostics.front().message) +
            "; trace=" + tracePath.string();
        return false;
    }
    const auto built = st::BuildAutoBiasTemplate(templateRequest, solved.sizing, solveCatalog);
    if (!built.ok) {
        message = "VBIAS selected template rebuild failed: " +
            (built.diagnostics.empty() ? std::string("unknown") : built.diagnostics.front().message);
        return false;
    }
    resolved.cascode.solved_bias = std::move(solved);
    resolved.cascode.bias_template = built;
    resolved.cascode.vbias_vhigh_net = vhighNet;
    resolved.cascode.vbias_vlow_net = vlowNet;
    return true;
}

// 用主流程 tech framework 构建 st::DeviceCatalog，替代 scan-pdk（SKILL 扫描）。
// CreateTech 从 $TECH_ROOT_PATH/{tech}/tech_cfg_v2.0.json 读取 PDK 器件清单
// （主流程 GUI 已用它做 MOS 极性判定，服务器上可用性已验证）。
// 端子顺序用默认契约（MOS: D/G/S/B，电阻: PLUS/MINUS），
// normalized_to_cdf 从 tech 的 InstCDFsMap 读。
bool BuildCatalogFromTech(const std::string &tech_name,
                          st::DeviceCatalog &catalog,
                          std::string &message)
{
    if (tech_name.empty()) {
        message = "target tech is empty; cannot build device catalog";
        return false;
    }
    std::shared_ptr<maau::platform::Tech> tech;
    try {
        tech = maau::platform::CreateTech(tech_name);
        tech->LoadTech(tech_name);
    } catch (const std::exception &error) {
        message = std::string("cannot load tech '") + tech_name + "': " + error.what();
        return false;
    }
    if (!tech->IsValid()) {
        message = "tech is not valid: " + tech_name;
        return false;
    }
    const std::string pdkName = tech->GetPDKName();
    // HiEPDK 工艺的电阻/电容器件实际位于 base PDK 库 (如 smicnp1pp),
    // 而非 HiEPDK 库 (如 HMJ730R_HiEPDK)。获取 base PDK 名供非 MOS 器件使用。
    std::string basePdkName = pdkName;
    if (tech->IsHiEpdk()) {
        const auto baseTech = tech->GetBase();
        if (baseTech.has_value() && *baseTech != nullptr) {
            basePdkName = (*baseTech)->GetPDKName();
        }
    }
    std::size_t added = 0;
    const auto addDevice = [&catalog, &added, &pdkName, &basePdkName, &tech](const std::string &master,
                                                                             st::DeviceKind kind) {
        st::DeviceDescriptor desc;
        desc.master = master;
        desc.kind = kind;
        // MOS 器件使用 HiEPDK 库;电阻/电容等非 MOS 器件使用 base PDK 库。
        const std::string &oaLib = (kind == st::DeviceKind::Resistor || kind == st::DeviceKind::Capacitor)
                                    ? basePdkName : pdkName;
        desc.oa_library = oaLib;
        // OA cell 名：model → cell 映射（如 p18_ckt → p18_ckt_tp）。
        // 网表里 master 是 oa_{lib}__{cell} 格式（如 oa_np2_HiEPDK__p18_ckt_tp），
        // 必须用真实 OA cell 名登记，否则 catalog.Find 匹配不上。
        std::string oaCell = master;
        try {
            const std::string cellFromTech = tech->GetTypeName(master);
            if (!cellFromTech.empty()) { oaCell = cellFromTech; }
        } catch (...) { // ignore: tech mapping not available
        }
        desc.oa_cell = oaCell;
        desc.oa_view = "symbol";
        desc.pdk_name = oaLib;
        desc.model_name = master;
        // 结构变换场景不跑 DC 电气证明，标记为已证明（可靠性/Bulk 由用户后续确认）。
        // 否则 SelectCrossFlavorCandidates 会因 reliability/bulk 不全拒绝所有候选。
        desc.reliability_complete = true;
        desc.bulk_rule_complete = true;
        desc.voltage_domain = "core";
        desc.allowed_voltage_domains.insert("core");
        if (kind == st::DeviceKind::MosN || kind == st::DeviceKind::MosP) {
            desc.terminal_count = 4;
            desc.terminal_names_by_index = {"D", "G", "S", "B"};
            desc.terminal_roles_by_index = {st::TerminalRole::Drain,
                                            st::TerminalRole::Gate,
                                            st::TerminalRole::Source,
                                            st::TerminalRole::Bulk};
            desc.terminal_index = {{st::TerminalRole::Drain, 0},
                                   {st::TerminalRole::Gate, 1},
                                   {st::TerminalRole::Source, 2},
                                   {st::TerminalRole::Bulk, 3}};
        } else {
            desc.terminal_count = 2;
            desc.terminal_names_by_index = {"PLUS", "MINUS"};
            desc.terminal_roles_by_index = {st::TerminalRole::Positive,
                                            st::TerminalRole::Negative};
            desc.terminal_index = {{st::TerminalRole::Positive, 0},
                                   {st::TerminalRole::Negative, 1}};
        }
        try {
            const auto &cdfMap = tech->GetInstCDFsMap(master);
            for (const auto &[key, value] : cdfMap) {
                desc.normalized_to_cdf[key] = value;
            }
        } catch (...) {
            // 无 CDF 映射时保持空，变换用默认参数名。
        }
        // 工艺 CDF 是唯一依据：小写匹配 tech 映射 key，CDF 名保留原大小写。
        // WF/NF/L 工艺绝不能被补成 W/L，未声明的尺寸域留给 UI 明确禁用。
        const auto normalizeSemantic = [](const std::string &key) -> std::string {
            std::string lower;
            std::transform(key.begin(), key.end(), std::back_inserter(lower),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            if (lower == "width" || lower == "w") return "width";
            if (lower == "length" || lower == "l") return "length";
            if (lower == "finger_width" || lower == "fingerwidth" ||
                lower == "wf" || lower == "fw") return "finger_width";
            if (lower == "fingers" || lower == "nf" || lower == "fin" || lower == "fins") return "fingers";
            if (lower == "multi" || lower == "multiplier" || lower == "m") return "multi";
            if (lower == "resistance" || lower == "r") return "resistance";
            return {};
        };
        std::map<std::string, std::string> normalized;
        for (const auto &[key, cdfName] : desc.normalized_to_cdf) {
            const std::string semantic = normalizeSemantic(key);
            if (semantic.empty() || cdfName.empty()) continue;
            normalized[semantic] = cdfName;
            st::ParameterConstraint constraint;
            constraint.semantic_name = semantic;
            constraint.cdf_name = cdfName;
            constraint.integer_only = semantic == "fingers" || semantic == "multi";
            try {
                const auto range = tech->GetConstraintVec(cdfName, master, "");
                if (range.size() >= 2) {
                    constraint.minimum = range[0];
                    constraint.maximum = range[1];
                    if (range.size() >= 3) constraint.grid = range[2];
                }
            } catch (...) { // 没有约束时不生成虚构默认值。
            }
            desc.parameter_constraints[semantic] = std::move(constraint);
        }
        desc.normalized_to_cdf = std::move(normalized);
        // 从 tech 约束填尺寸范围（Length/Fw/Fingers/Multi 的 min/max）。
        const auto minMaxOf = [](const std::vector<double> &values) {
            return std::make_pair(values.empty() ? 0.0 : values.front(),
                                  values.empty() ? 0.0 : values.back());
        };
        try {
            const auto [minL, maxL] = minMaxOf(tech->GetLengthConstrains(master));
            desc.limits.min_length = minL;
            desc.limits.max_length = maxL;
        } catch (...) { // ignore: length constraint not available
        }
        try {
            const auto [minW, maxW] = minMaxOf(tech->GetFwConstrains(master));
            desc.limits.min_width = minW;
            desc.limits.max_width = maxW;
        } catch (...) { // ignore: width constraint not available
        }
        st::Diagnostic diag;
        // 主名（裸 model 名，如 p18_ckt）。
        if (catalog.Add(desc, diag)) {
            ++added;
        }
        // 别名1：oa_{pdkName}__{model}（如 oa_np2_HiEPDK__p18_ckt）。
        // 电阻等非 MOS 器件用 base PDK 名 (与 oa_library 一致)。
        {
            st::DeviceDescriptor alias = desc;
            alias.master = "oa_" + oaLib + "__" + master;
            catalog.Add(alias, diag);
        }
        // 别名2：oa_{pdkName}__{OA cell 名}（如 oa_np2_HiEPDK__p18_ckt_tp，
        // 单层模式 export_snapshot 用的 OA master key 格式）。
        if (oaCell != master) {
            st::DeviceDescriptor alias = desc;
            alias.master = "oa_" + oaLib + "__" + oaCell;
            catalog.Add(alias, diag);
        }
        // 别名3：裸 OA cell 名（如 p18_ckt_tp）。全展开模式 export_snapshot
        // 引用行用 inst~>master~>cellName（= OA cell 名，非裸 model 名），
        // 必须登记它，否则 Find 匹配不到报 "not a registered MOS"。
        if (oaCell != master) {
            st::DeviceDescriptor alias = desc;
            alias.master = oaCell;
            catalog.Add(alias, diag);
        }
    };
    for (const auto &master : tech->GetMosNList()) {
        addDevice(master, st::DeviceKind::MosN);
    }
    for (const auto &master : tech->GetMosPList()) {
        addDevice(master, st::DeviceKind::MosP);
    }
    // 补充注册 cell_name 别名 (如 p18_ckt_stack)。
    // 网表实例 master 用 cell_name 而非 model_name, catalog 必须两者都有。
    // GetCellNamePMosList/GetCellNameNMosList 在 TechBase 中实现交叉,
    // 所以合并两个列表后用 IsPMosByCellName/IsNMosByCellName 判断极性。
    {
        std::set<std::string> mosCellNames;
        for (const auto &cn : tech->GetCellNamePMosList()) { mosCellNames.insert(cn); }
        for (const auto &cn : tech->GetCellNameNMosList()) { mosCellNames.insert(cn); }
        for (const auto &cellName : mosCellNames) {
            // 修改原因：model 和多个真实 OA Cell 可共用模型；已登记的别名也可能仍指向 *_ana。
            // 必须让 *_stack 等实际 Cell 各自出现在 policy 中，导出时才能按 D/G/S/B 取网。
            const auto *existing = catalog.Find(cellName);
            if (existing != nullptr && existing->oa_cell == cellName) { continue; }
            st::DeviceKind kind = st::DeviceKind::Mos;
            if (tech->IsPMosByCellName(cellName)) { kind = st::DeviceKind::MosP; }
            else if (tech->IsNMosByCellName(cellName)) { kind = st::DeviceKind::MosN; }
            else { continue; } // 非 MOS cell, 跳过
            // 尝试取 model_name, 复用已注册的描述符 (含端子/CDF/约束等)。
            // tech->GetModelName 在某些 tech accessor 未注册时抛异常,
            // 此处兜底为空字符串即可走未注册分支, 无需传播。
            const std::string modelName = [&tech, &cellName]() {
                try {
                    return tech->GetModelName(cellName);
                } catch (...) {
                    // 忽略: 取不到 model_name 时保持空, 后续走默认描述符分支.
                    return std::string{};
                }
            }();
            const st::DeviceDescriptor *modelDesc = nullptr;
            if (!modelName.empty()) { modelDesc = catalog.Find(modelName); }
            // 修改原因：修正已有别名的 OA 身份时保留其参数和约束。
            if (modelDesc == nullptr) { modelDesc = existing; }
            st::DeviceDescriptor desc;
            if (modelDesc != nullptr) {
                desc = *modelDesc; // 继承端子序、CDF 映射、尺寸约束等
            } else {
                desc.kind = kind;
                desc.oa_library = pdkName;
                desc.oa_view = "symbol";
                desc.pdk_name = pdkName;
                desc.reliability_complete = true;
                desc.bulk_rule_complete = true;
                desc.voltage_domain = "core";
                desc.allowed_voltage_domains.insert("core");
                desc.terminal_count = 4;
                desc.terminal_names_by_index = {"D", "G", "S", "B"};
                desc.terminal_roles_by_index = {st::TerminalRole::Drain,
                                                st::TerminalRole::Gate,
                                                st::TerminalRole::Source,
                                                st::TerminalRole::Bulk};
                desc.terminal_index = {{st::TerminalRole::Drain, 0},
                                       {st::TerminalRole::Gate, 1},
                                       {st::TerminalRole::Source, 2},
                                       {st::TerminalRole::Bulk, 3}};
            }
            desc.master = cellName;
            // 修改原因：继承模型参数不等于继承模型的默认 Cell；匹配原图必须用真实 cellName。
            desc.oa_cell = cellName;
            desc.model_name = modelName.empty() ? cellName : modelName;
            st::Diagnostic diag;
            if (catalog.Add(desc, diag)) { ++added; }
            // 同步 oa_{pdkName}__{cellName} 别名。
            {
                st::DeviceDescriptor alias = desc;
                alias.master = "oa_" + pdkName + "__" + cellName;
                catalog.Add(alias, diag);
            }
        }
    }
    for (const auto &master : tech->GetResistantList()) {
        addDevice(master, st::DeviceKind::Resistor);
    }
    if (added == 0) {
        message = "no devices found in tech '" + tech_name + "'";
        return false;
    }
    return true;
}
} // namespace

bool StructureTransformConfig::FromProjectCfg(const std::string &project_cfg_json,
                                              const std::string &workDir)
{
    maau::platform::BaseData base_data;
    if (!maau::platform::BaseDataAccessor(project_cfg_json).ReadBaseData(base_data)) {
        return false;
    }
    source_cds_path = StringOf(base_data, "source_cds_path");
    target_cds_path = StringOf(base_data, "target_cds_path");
    ReadDesign(base_data, "source_dut", source_dut_lib, source_dut_cell, source_dut_view);
    ReadDesign(base_data, "target_dut", target_dut_lib, target_dut_cell, target_dut_view);
    ReadDesign(base_data, "source_tb", source_tb_lib, source_tb_cell, source_tb_view);
    ReadDesign(base_data, "target_tb", target_tb_lib, target_tb_cell, target_tb_view);
    source_tech = StringOf(base_data, "source_tech");
    target_tech = StringOf(base_data, "target_tech");
    if (base_data.isMember(kPvt) && base_data[kPvt].isMember(kCorner)) {
        corner = base_data[kPvt][kCorner].asString();
    }
    if (corner.empty()) { corner = "tt"; }
    pvt_corners = corner;
    this->work_dir = workDir;
    // 修改原因：沿用发布脚本已有 MAAU_ROOT/SKILLPATH；开发环境仍可用 OPT_ALGO_ROOT 覆盖。
    opt_algo_root = st::runtime::OptAlgoRoot(StringOf(base_data, "opt_algo_root"));
    skill_script = (std::filesystem::path(st::runtime::SkillDirectory(opt_algo_root)) /
                    "st_multi_level_materializer.il").string();
    // 修改原因：空值表示导入内置后端模块；不再用 .py 是否存在决定后端可用性。
    backend_script = StringOf(base_data, "st_backend_script");
    if (backend_script.empty()) backend_script = st::runtime::BackendOverride();
    // 集群配置：project_cfg.json 的 cluster_config 字段（主流程序列化写入），
    // is_valid=true 时物化通过 ClustorService::RunCmd 提交集群。
    if (base_data.isMember("cluster_config")) {
        cluster_config.FromBaseData(base_data["cluster_config"]);
    }
    return !target_cds_path.empty() && !target_dut_lib.empty();
}

st::TransformRequest StructureTransformRequest::ToTransformRequest() const
{
    st::TransformRequest request;
    request.operation_id = operation_id;
    request.target = target;
    request.type = type;
    switch (type) {
    case st::TransformType::SameTypeCascode:
    case st::TransformType::CrossFlavorCascode:
        request.payload = cascode;
        break;
    case st::TransformType::AddSourceResistor:
        request.payload = resistor;
        break;
    case st::TransformType::MosStack:
        // 结构变换只做拓扑占位（期望网表），不跑 DC/不校验电气域。
        // structure_only=true 跳过 voltage_domain/bulk 等电气校验，否则
        // Stack 会因 catalog 无电压域信息报 "does not support voltage domain"。
        {
            auto stackCopy = stack;
            stackCopy.structure_only = true;
            request.payload = stackCopy;
        }
        break;
    default:
        request.payload = std::monostate{};
        break;
    }
    return request;
}

StructureTransformService::StructureTransformService(st::standalone::ProcessRunner *runner)
    : runner_(runner) {}

bool StructureTransformService::PrepareBaseline(
    const StructureTransformConfig &config,
    st::Netlist &baseline,
    st::DeviceCatalog &catalog,
    std::string &message,
    std::string *netlist_path,
    std::string *log_path)
{
    if (config.target_cds_path.empty()) {
        message = "structure transform config missing target_cds_path (project_cfg.json has no circuit dir)";
        return false;
    }
    const std::filesystem::path root(config.work_dir);
    const std::filesystem::path beforeDir = root / "before";
    // 用主流程 tech framework 构建 DeviceCatalog（替代 scan-pdk SKILL 扫描）。
    if (!BuildCatalogFromTech(config.target_tech, catalog, message)) {
        return false;
    }
    // 从 catalog 生成 device_policy.tsv（供 Snapshot 的 export_snapshot.il 识别器件）。
    const std::filesystem::path devicePolicyPath = root / "before/device_policy.tsv";
    if (!WriteDevicePolicyTsv(catalog, devicePolicyPath, message)) {
        return false;
    }

    // 用 st-engine 的 Snapshot（export_snapshot.il）从 DUT cell 导出**全展开网表**：
    // export_snapshot.il 会递归展开所有子模块 subckt 定义写入网表，
    // 这样 baseline 里每个子模块都有定义，ResolveHierarchyTarget 能逐层找到。
    // 之前用主流程 NetlistBuilder 只展开顶层（不含子模块定义），导致找不到 subckt。
    {
        std::error_code ec;
        std::filesystem::create_directories(beforeDir, ec);
    }
    const std::filesystem::path cdsLib =
        std::filesystem::path(config.target_cds_path) / "cds.lib";
    // Snapshot 打开"变换所在子模块"（config.transform_subckt，如 l50）——它是
    // 包含目标 MOS 的那一层 cell（OA 库真实存在，ScanMos DFS 能展开它）。
    // 在该层导出网表，变换算法直接在层内的 MOS 上操作（跟随 st-engine 原型
    // 的 core_subckt 语义）。transform_subckt 为空时用 source_dut_cell（顶层）。
    const std::string snapshotCell = config.transform_subckt.empty()
        ? (config.source_dut_cell.empty() ? config.target_dut_cell
                                          : config.source_dut_cell)
        : config.transform_subckt;
    const std::string snapshotLib = config.transform_lib.empty()
        ? (config.source_dut_lib.empty() ? config.target_dut_lib
                                         : config.source_dut_lib)
        : config.transform_lib;
    const std::string snapshotView = config.source_dut_view.empty()
        ? config.target_dut_view : config.source_dut_view;
    const st::CellViewRef source{snapshotLib, snapshotCell, snapshotView,
                                 config.target_cds_path, {}};
    AppendRunLog(root, "[STEP1] Snapshot 打开: lib=" + snapshotLib +
        " cell=" + snapshotCell + " view=" + snapshotView);
    st::standalone::BackendPaths paths{cdsLib, root / "after/source_roundtrip.scs",
                                       root / "after/core_roundtrip.scs",
                                       root / "logs", source.cell};
    paths.device_policy = devicePolicyPath;
    st::standalone::PosixProcessRunner localRunner;
    st::standalone::ProcessRunner &runner = runner_ != nullptr ? *runner_ : localRunner;
    // 修改原因：默认扫描后端支持 .py/.so 两种发布形式，不改变扫描参数和返回校验。
    PythonModuleBackendRunner moduleRunner(runner, st::runtime::OptAlgoRoot(config.opt_algo_root));
    st::standalone::ProcessRunner& backendRunner = config.backend_script.empty()
        ? static_cast<st::standalone::ProcessRunner&>(moduleRunner) : runner;
    st::standalone::ProcessVirtuosoBackend backend(config.backend_script, paths, backendRunner);
    const st::standalone::SnapshotOutputs artifacts{
        beforeDir / "core_before.scs", beforeDir / "device_catalog.tsv",
        beforeDir / "geometry.tsv"};
    const auto status = backend.Snapshot(source, source.cell, artifacts);
    if (!status.ok) {
        message = "baseline netlist generation failed: " + status.message;
        if (log_path != nullptr) { *log_path = status.log_path; }
        return false;
    }
    std::ifstream input(artifacts.netlist, std::ios::binary);
    const std::string text((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());
    std::vector<st::Diagnostic> diagnostics;
    baseline = st::parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) {
        message = "baseline netlist parse failed: " + diagnostics.front().message;
        return false;
    }
    if (baseline.subckts.empty()) {
        message = "baseline netlist contains no subckt (DUT cell '" +
                  config.target_dut_cell + "' not expanded)";
        return false;
    }
    if (netlist_path != nullptr) { *netlist_path = artifacts.netlist.string(); }
    return true;
}

StructureTransformResult StructureTransformService::Run(
    const StructureTransformConfig &config,
    const std::vector<StructureTransformRequest> &requests)
{
    StructureTransformResult result;
    std::string message;

    if (config.target_cds_path.empty()) {
        result.message = "structure transform config missing target_cds_path (project_cfg.json has no circuit dir)";
        return result;
    }
    if (requests.empty()) {
        result.message = "structure transform request list is empty";
        return result;
    }

    const std::filesystem::path root(config.work_dir);
    const std::filesystem::path expectedDir = root / "expected";

    AppendRunLog(root, "[RUN] 结构变换开始 work_dir=" + root.string() +
        " cds=" + config.target_cds_path +
        " dut=" + config.target_dut_lib + "/" + config.target_dut_cell +
        "/" + config.target_dut_view + " tech=" + config.target_tech +
        " 请求数=" + std::to_string(requests.size()));
    for (std::size_t index = 0; index < requests.size(); ++index) {
        const auto &item = requests[index];
        AppendRunLog(root, "[RUN]   请求[" + std::to_string(index) + "] type=" +
            std::to_string(static_cast<int>(item.type)) +
            " op_id=" + item.operation_id +
            " hierarchy_path=" + item.hierarchy_path);
    }

    // ---- 1) 基线网表 + PDK 器件目录 ----
    st::Netlist baseline;
    st::DeviceCatalog catalog;
    if (!PrepareBaseline(config, baseline, catalog, message, nullptr, &result.log_path)) {
        AppendRunLog(root, "[STEP1] 基线网表失败: " + message);
        result.message = message;
        return result;
    }
    AppendRunLog(root, "[STEP1] 基线网表成功 subckt数=" +
        std::to_string(baseline.subckts.size()) +
        " 顶层实例数=" + std::to_string(baseline.topInstances.size()) +
        " 日志=" + result.log_path);

    // ---- 2) 重放全部变换请求 ----
    // 先把每个请求的层次点路径（GUI 传入，如 I2.M0）解析成 st-engine 可定位
    // 的扁平 (subckt, instance)，并同步 payload，保持 ChangeSet::Confirm 的
    // payload.target == request.target.instance 一致性校验通过。
    st::ChangeSet changes;
    // 变换所在子模块（GUI 从选中 MOS 的 parent_subckt 取）。Snapshot 以它为
    // source 导出这一层网表（顶层 = 该子模块）。所以层级解析的起点是
    // transform_subckt，路径裁剪为"transform_subckt 之后的部分"（叶 MOS）。
    // 为空时退回从 target_dut_cell（顶层）解析完整路径。
    const std::string resolveRoot = config.transform_subckt.empty()
        ? config.target_dut_cell : config.transform_subckt;
    for (const auto &item : requests) {
        StructureTransformRequest resolved = item;
        // 裁剪路径：transform_subckt 是"最终子模块的 cell 名"（如 l50 的 master），
        // 路径是实例名链（如 ldo_top.l50.M0）。两者不同维度，不能按段匹配。
        // 当 transform_subckt 非空时，Snapshop 已从该子模块导出网表（顶层=子模块），
        // 所以层级解析只需叶 MOS（路径最后一段），起点 = transform_subckt。
        std::string leafPath = item.target.instance;
        if (!config.transform_subckt.empty()) {
            const auto lastDot = leafPath.rfind('.');
            if (lastDot != std::string::npos) {
                leafPath = leafPath.substr(lastDot + 1);  // 只保留叶 MOS
            }
        }
        AppendRunLog(root, "[STEP2] 解析准备: transform_subckt='" +
            config.transform_subckt + "' transform_lib='" + config.transform_lib +
            "' resolveRoot='" + resolveRoot + "' 原路径='" +
            item.target.instance + "' 裁剪后='" + leafPath + "'");
        std::string resolveMessage;
        if (!ResolveHierarchyTarget(baseline, resolveRoot,
                                    leafPath, resolved.target,
                                    resolveMessage)) {
            AppendRunLog(root, "[STEP2] 层级解析失败: " + resolveMessage);
            result.message = resolveMessage;
            return result;
        }
        // 填充 hierarchy = 原始完整路径的"父实例部分"（去掉最后的叶 MOS 名）。
        // Canonical() 在 hierarchy 非空时会拼接它，使同一 master 被多次实例化时
        // 的不同 occurrence（如 ldo_top.I19.M3 vs ldo_top.ldo_main.ldo_400ma_core.
        // I15<104>.M3）不再撞成同一个目标（Bug 1 根源：hierarchy 一直为空）。
        resolved.target.hierarchy = item.hierarchy_path;
        {
            const auto lastDot = resolved.target.hierarchy.rfind('.');
            if (lastDot != std::string::npos) {
                resolved.target.hierarchy = resolved.target.hierarchy.substr(0, lastDot);
            }
        }
        AppendRunLog(root, "[STEP2] 请求 " + item.operation_id +
            " 解析: 路径=" + item.hierarchy_path +
            " -> subckt=" + resolved.target.subckt +
            " instance=" + resolved.target.instance +
            " hierarchy=" + resolved.target.hierarchy);
        // payload 里的 subckt/target 必须与 target 一致（Confirm 校验）。
        const auto syncPayload = [&resolved, &catalog]() {
            switch (resolved.type) {
            case st::TransformType::SameTypeCascode:
            case st::TransformType::CrossFlavorCascode:
                resolved.cascode.subckt = resolved.target.subckt;
                resolved.cascode.target = resolved.target.instance;
                break;
            case st::TransformType::AddSourceResistor:
                resolved.resistor.subckt = resolved.target.subckt;
                resolved.resistor.target = resolved.target.instance;
                // 电阻 master 为空时自动选 catalog 里第一个电阻（新增器件，
                // 需要指定电阻类型；GUI 只填了阻值 R）。
                if (resolved.resistor.resistor.master.empty()) {
                    for (const auto &[master, desc] : catalog.Descriptors()) {
                        if (desc.kind == st::DeviceKind::Resistor) {
                            resolved.resistor.resistor.master = master;
                            break;
                        }
                    }
                }
                break;
            case st::TransformType::MosStack:
                resolved.stack.subckt = resolved.target.subckt;
                resolved.stack.target = resolved.target.instance;
                break;
            default:
                break;
            }
        };
        syncPayload();
        // FixedBias Cascode 必须先完成基线与逐 R 的真实 DC 闭环。
        std::string vbiasMessage;
        if (!SolveVbiasForCascode(baseline, catalog, config, resolved, runner_, vbiasMessage)) {
            AppendRunLog(root, "[STEP2] VBIAS 求解失败: " + vbiasMessage);
            result.message = vbiasMessage;
            return result;
        }
        if (resolved.cascode.solved_bias.has_value()) {
            AppendRunLog(root, "[STEP2] VBIAS 模板已生成: " + resolved.operation_id +
                " vhigh=" + resolved.cascode.vbias_vhigh_net +
                " vlow=" + resolved.cascode.vbias_vlow_net);
        }
        st::Diagnostic diagnostic;
        if (!changes.Confirm(resolved.ToTransformRequest(), diagnostic)) {
            AppendRunLog(root, "[STEP2] Confirm 失败: " + diagnostic.message);
            result.message = diagnostic.message;
            return result;
        }
    }
    result.replay = changes.Generate(baseline, result.expected_netlist, catalog);
    if (!result.replay.ok) {
        result.message = result.replay.diagnostics.empty()
            ? "结构变换重放失败" : result.replay.diagnostics.front().message;
        AppendRunLog(root, "[STEP2] Generate 失败: " + result.message);
        return result;
    }
    AppendRunLog(root, "[STEP2] 重放成功: 应用操作=" +
        std::to_string(result.replay.applied_operation_ids.size()) +
        " 期望网表 subckt数=" + std::to_string(result.expected_netlist.subckts.size()));

    // ---- 3) 期望网表落盘 ----
    result.expected_netlist_path = (expectedDir / "core_expected.scs").string();
    if (!WriteNetlistFile(result.expected_netlist_path, result.expected_netlist, message)) {
        AppendRunLog(root, "[STEP3] 期望网表落盘失败: " + message);
        result.message = message;
        return result;
    }
    AppendRunLog(root, "[STEP3] 期望网表已落盘: " + result.expected_netlist_path);

    // ---- 4) 封装 + OA 物化计划 + 调 maau-cli sch 执行物化 ----
    // config.target_dut_lib 可能是 IP 暂存库 (如 HiAplat730RV200_ip), 但 DUT cell
    // 实际可能位于基础库 (如 HiAplat730RV200)。物化需要打开源 schematic,
    // 库必须正确。从基线网表的 // Library name 注释提取实际 OA 库。
    std::string variantLib = config.target_dut_lib;
    {
        const auto *rootSub = baseline.find(config.target_dut_cell);
        if (rootSub != nullptr && !rootSub->library.empty()) {
            variantLib = rootSub->library;
        }
    }
    const std::string variantCell = config.target_dut_cell;
    // 固定后缀：同一 cell 下始终覆盖同一个变换 view，避免 __maau_st_N 累积
    // 出孤儿 view。物化脚本需保证同名 view 已存在时先删除再重建。
    const std::string variantView = config.target_dut_view + "__maau_struct_transform";

    // 修改原因：历史请求可以分属不相关模块，不能把后续模块伪装成首个模块的子实例。
    // 只按 STEP2 已解析的 MOS 所在模块分别封装；扫描、Python 调用和 UI 引用策略不变。
    const st::CellViewRef fallbackSource{
        config.transform_lib.empty() ? variantLib : config.transform_lib,
        config.target_dut_cell, config.target_dut_view, config.target_cds_path, {}};
    const auto builtPlans = st::BuildModuleTransformPlans(
        {&baseline, &result.expected_netlist, {}, &changes, &result.replay, {}},
        catalog, fallbackSource, variantView, &result.packaged);
    if (!builtPlans.ok()) {
        result.message = "OA materialization plan build failed: " + builtPlans.diagnostics.front().message;
        for (const auto& diagnostic : builtPlans.diagnostics)
            AppendRunLog(root, "[STEP4] " + diagnostic.message);
        return result;
    }
    AppendRunLog(root, "ST_MODULE_PLAN_COUNT=" + std::to_string(builtPlans.plans.size()));
    for (const auto& plan : builtPlans.plans) {
        AppendRunLog(root, "ST_MODULE_PLAN source=" + plan.source.library + "/" +
            plan.source.cell + "/" + plan.source.view + " target=" + plan.target.library + "/" +
            plan.target.cell + "/" + plan.target.view + " root=/" + PlanSummary(plan));
        for (const auto& cell : plan.generated_cells) {
            AppendRunLog(root, "ST_PACKAGE_CELL=" + cell.schematic.library + "/" +
                cell.schematic.cell + "/" + cell.schematic.view);
        }
    }

    // plan JSON 落盘
    const std::filesystem::path planDir = root / "plan";
    const std::filesystem::path planPath = planDir / "materialize_plan.json";
    {
        std::error_code ec;
        std::filesystem::create_directories(planDir, ec);
        if (ec) {
            result.message = "cannot create plan directory: " + ec.message();
            return result;
        }
        std::ofstream planFile(planPath);
        if (!planFile) {
            result.message = "cannot open plan JSON for writing: " + planPath.string();
            return result;
        }
        // 修改原因：多个局部计划交给同一次 SKILL 调用，沿用原 Python 递归转换。
        planFile << builtPlans.Json();
        planFile.close();
        if (!planFile) {
            result.message = "failed to write plan JSON: " + planPath.string();
            return result;
        }
    }
    result.plan_path = planPath.string();
    AppendRunLog(root, "[STEP4] plan JSON 已落盘: " + result.plan_path +
        " 大小=" + std::to_string(std::filesystem::file_size(planPath)) + " 字节");

    // 修改原因：Python 进程退出成功不等于 SKILL 完成；复用已有状态文件确认本次封装成功。
    const auto materializeStatus = root / "materialize_status.txt";
    std::error_code statusError;
    std::filesystem::remove(materializeStatus, statusError);
    if (statusError) {
        result.message = "cannot clear materialization status: " + statusError.message();
        return result;
    }

    // ---- 5) 导入 Python 物化模块；源码和打包 .so 使用同一 main(argv) ----
    // 修改原因：不再执行/检查 st_materialize_main.py，发布包保留扩展模块即可。
    const auto skillScript = config.skill_script.empty()
        ? (std::filesystem::path(st::runtime::SkillDirectory(
               st::runtime::OptAlgoRoot(config.opt_algo_root))) / "st_multi_level_materializer.il").string()
        : config.skill_script;
    const auto logFile = (root / "logs/materialize.log").string();
    const std::vector<std::string> args = {
        "--cds-path", config.target_cds_path,
        "--plan", planPath.string(),
        "--skill", skillScript,
        "--work-dir", root.string()
    };
    AppendRunLog(root, "[STEP5] 物化参数: cds=" + config.target_cds_path +
        " plan=" + planPath.string() + " skill=" + skillScript + " work_dir=" + root.string());
    AppendRunLog(root, std::string("[STEP5] 物化方式: ") +
        (config.cluster_config.is_valid ? "集群提交" : "本地 Subprocess"));
    if (!RunStPythonModule(config, "common.structure_transform.st_materialize_main",
                           args, "materialize.log", "materialization", root, result.message)) {
        AppendRunLog(root, "[STEP5] " + result.message);
        return result;
    }
    AppendRunLog(root, "[STEP5] 物化执行成功（exit=0）日志=" + logFile);

    // 修改原因：materialize.il 仅在封装/连接检查完成后写 OK，避免界面把 SKILL 失败显示为成功。
    std::ifstream statusFile(materializeStatus);
    std::string status;
    statusFile >> status;
    if (status != "OK") {
        result.message = "materialization did not report OK; see " + logFile;
        AppendRunLog(root, "[STEP5] " + result.message);
        return result;
    }

    result.ok = true;
    result.variant_lib = variantLib;
    result.variant_cell = variantCell;
    result.variant_view = variantView;
    result.message = "structure transform done: replayed " + std::to_string(requests.size()) +
        " operation(s), expected netlist at " + result.expected_netlist_path +
        ", materialization plan at " + planPath.string();
    AppendRunLog(root, "[RUN] 结构变换完成: " + result.message);
    return result;
}

StructureScanResult StructureTransformService::ScanMos(
    const StructureTransformConfig &config)
{
    StructureScanResult result;
    std::string message;

    const std::filesystem::path root(config.work_dir);
    AppendRunLog(root, "[SCAN] ===== MOS 扫描开始 =====");
    AppendRunLog(root, "[SCAN] 入参: work_dir=" + config.work_dir +
        " target_cds_path=" + config.target_cds_path +
        " source_dut=" + config.source_dut_lib + "/" + config.source_dut_cell +
        "/" + config.source_dut_view +
        " target_dut=" + config.target_dut_lib + "/" + config.target_dut_cell +
        "/" + config.target_dut_view +
        " tech=" + config.target_tech +
        " backend_script=" + config.backend_script +
        " skill_script=" + config.skill_script);

    // 与 Run 同源：用 export_snapshot（PrepareBaseline）全展开网表，而不是
    // NetlistBuilder（两者层级展开不同，会导致扫描路径与生成解析不一致）。
    // 全展开网表含全部子模块定义，Scs 解析后 DFS 扫到的路径与 Run 的 baseline 一致。
    if (config.target_cds_path.empty()) {
        result.message = "MOS scan config missing target_cds_path (project_cfg.json has no circuit dir)";
        AppendRunLog(root, "[SCAN] 入参校验失败: " + result.message);
        return result;
    }
    if (config.target_dut_lib.empty() || config.target_dut_cell.empty()) {
        result.message = "MOS scan config missing DUT L/C (project_cfg.json has no circuit LCV)";
        AppendRunLog(root, "[SCAN] 入参校验失败: " + result.message);
        return result;
    }

    st::Netlist scanBaseline;
    st::DeviceCatalog scanCatalog;
    std::string scanMessage;
    std::string scanNetlistPath;
    AppendRunLog(root, "[SCAN] STEP1 PrepareBaseline 开始");
    if (!PrepareBaseline(config, scanBaseline, scanCatalog, scanMessage,
                         &scanNetlistPath, nullptr)) {
        result.message = "baseline netlist generation failed: " + scanMessage;
        AppendRunLog(root, "[SCAN] STEP1 PrepareBaseline 失败: " + result.message);
        return result;
    }
    AppendRunLog(root, "[SCAN] STEP1 PrepareBaseline 成功: subckt数=" +
        std::to_string(scanBaseline.subckts.size()) +
        " 顶层实例数=" + std::to_string(scanBaseline.topInstances.size()) +
        " netlist=" + scanNetlistPath);
    const std::filesystem::path netlistPath = scanNetlistPath;

    // 2) 解析 scs 网表到内存模型。
    AppendRunLog(root, "[SCAN] STEP2 Scs.Load 开始 netlist=" + netlistPath.string());
    maau::circuit::schematic::Scs scs;
    try {
        scs.Load(netlistPath.string());
    } catch (const std::exception &error) {
        result.message = std::string("netlist parse failed: ") + error.what();
        AppendRunLog(root, "[SCAN] STEP2 Scs.Load 异常: " + result.message);
        return result;
    }
    auto *netlist = scs.GetView(maau::circuit::schematic::Scs::View::netlist);
    if (netlist == nullptr) {
        result.message = "netlist parse failed: no netlist view";
        AppendRunLog(root, "[SCAN] STEP2 失败: " + result.message);
        return result;
    }
    AppendRunLog(root, "[SCAN] STEP2 Scs.Load 成功");

    // 3) TechBinder 按工艺判定每个实例类型（NMOS/PMOS/电阻/电容...）。
    // 工艺缺失时（case_item.tech 为空）跳过打标，遍历阶段用 cell 名启发式兜底，
    // 确保仍能扫到 MOS。
    const bool techAvailable = !config.target_tech.empty();
    AppendRunLog(root, std::string("[SCAN] STEP3 TechBinder: techAvailable=") +
        (techAvailable ? "true" : "false") +
        (techAvailable ? " tech=" + config.target_tech : " (走启发式兜底)"));
    if (techAvailable) {
        try {
            maau::circuit::schematic::TechBinder binder(config.target_tech);
            // 结构变换 MOS 扫描专用：开启 cell_name 兜底，正确识别
            // HiEPDK stacked MOS（cell_name ≠ model_name）的极性。
            binder.Bind(netlist, true, true);
            AppendRunLog(root, "[SCAN] STEP3 TechBinder.Bind 成功");
        } catch (const std::exception &error) {
            result.message = std::string("device type annotation failed: ") + error.what();
            AppendRunLog(root, "[SCAN] STEP3 TechBinder.Bind 异常: " + result.message);
            return result;
        }
    }

    // 无工艺时的启发式判断：常见 MOS cell/model 名以 nch/pch/nmos/pmos 开头，
    // 或以 n_/p_ 前缀区分极性。仅作兜底，有工艺时以 TechBinder 打标为准。
    const auto guessMos = [](const std::string &cell) -> int {
        if (cell.rfind("nch", 0) == 0 || cell.rfind("nmos", 0) == 0 ||
            cell.rfind("n_", 0) == 0 || cell.rfind("nmis", 0) == 0) return 1;
        if (cell.rfind("pch", 0) == 0 || cell.rfind("pmos", 0) == 0 ||
            cell.rfind("p_", 0) == 0 || cell.rfind("pmis", 0) == 0) return -1;
        return 0;
    };

    // 4) 递归遍历 DUT 所有层级的叶实例，过滤 MOS，提取 D/G/S/B 端网。
    // 顶层可能是 TB（含散件 + 一个 DUT 子模块实例），也可能就是 DUT 本身。
    // 用"顶层是否唯一存在可下钻的子模块实例"来区分两种情形；叶 MOS 用完整
    // 层次路径（点分隔）作为 instance。
    result.netlist_path = netlistPath.string();
    const auto *topDesign = netlist->TopDesign();
    if (topDesign == nullptr) {
        result.message = "netlist parse failed: no top-level design";
        AppendRunLog(root, "[SCAN] STEP4 顶层识别失败: " + result.message);
        return result;
    }
    AppendRunLog(root, "[SCAN] STEP4 顶层识别: topDesign=" +
        topDesign->GetCellName() + " lib=" + topDesign->GetLibName() +
        " 顶层实例数=" + std::to_string(topDesign->GetInsts().size()));

    // 项目本地 lib 白名单：只有白名单内 lib 的 cell 才允许进入 MOS 列表/
    // 下钻递归，公共 PDK/理想器件 lib（functional/basic/analogLib/smicnp1pp
    // 等绝对路径 DEFINE 项）下的 cell 不可做结构变换，直接排除。
    // 判定规则：解析 target_cds_path/cds.lib 的 DEFINE 行，lib 路径落在
    // target_cds_path 目录内（项目本地，通常为相对路径 DEFINE）的才入
    // 白名单；绝对路径且不在项目目录下的是外部公共库。cds.lib 解析失败或
    // 无本地 lib 时白名单为空 → 不过滤（兼容无 cds.lib 的独立网表场景）。
    std::set<std::string> localLibs;
    if (!config.target_cds_path.empty()) {
        const std::filesystem::path cdsLibPath =
            std::filesystem::path(config.target_cds_path) / "cds.lib";
        maau::circuit::LibParse libParser;
        const auto libs = libParser.GetOnlyLibs(cdsLibPath.string());
        const auto canonicalBase = std::filesystem::weakly_canonical(
            std::filesystem::path(config.target_cds_path));
        for (const auto &lib : libs) {
            if (lib.lib_path.empty()) {
                continue;
            }
            const auto canonicalLib = std::filesystem::weakly_canonical(
                std::filesystem::path(lib.lib_path));
            const auto baseStr = canonicalBase.generic_string();
            const auto libStr = canonicalLib.generic_string();
            const bool underProject = !baseStr.empty() &&
                libStr.size() >= baseStr.size() &&
                libStr.compare(0, baseStr.size(), baseStr) == 0 &&
                (libStr.size() == baseStr.size() || libStr[baseStr.size()] == '/');
            if (underProject) {
                localLibs.insert(lib.lib_name);
            }
        }
        std::string libNames;
        for (const auto &name : localLibs) {
            if (!libNames.empty()) libNames += ", ";
            libNames += name;
        }
        AppendRunLog(root, "[SCAN] STEP4 本地 lib 白名单(" +
            std::to_string(localLibs.size()) + "): [" + libNames + "]" +
            " (cds.lib=" + cdsLibPath.string() + ")");
    }
    // 空白的 master lib（解析不出 lib 信息）不挡：宁多勿漏，避免误过滤。
    const auto isLocalLib = [&localLibs](const std::string &lib) {
        return localLibs.empty() || lib.empty() || localLibs.count(lib) != 0;
    };

    // DUT 识别：仅当顶层存在唯一"master 非空且其内部还有子实例"的实例时，
    // 才把该实例作为 DUT（典型 testbench 顶层场景：TB 下只有一个 DUT 子模块）。
    // 否则（0 个 = 用户打开的就是 DUT 本身；多个 = 并列子模块无法判断），
    // 直接把顶层当作 DUT，避免随机选择造成扫描范围偏差。
    const auto *dutDesign = topDesign;
    const maau::circuit::schematic::Inst *uniqueDutInst = nullptr;
    for (const auto *inst : topDesign->GetInsts()) {
        if (inst == nullptr) continue;
        const auto *master = inst->GetMaster();
        if (master == nullptr || master == topDesign ||
            master->GetInsts().empty()) {
            continue;
        }
        // 非项目本地 lib 的子模块不参与 DUT 识别（外部 PDK 子模块不可变换）。
        if (!isLocalLib(master->GetLibName())) {
            continue;
        }
        if (uniqueDutInst != nullptr) {
            // 已有候选——不唯一，放弃下钻。
            uniqueDutInst = nullptr;
            break;
        }
        uniqueDutInst = inst;
    }
    if (uniqueDutInst != nullptr) {
        const auto *master = uniqueDutInst->GetMaster();
        result.core_subckt = master->GetCellName();
        dutDesign = master;
    } else {
        // 顶层即 DUT：core_subckt 用顶层 cell 名。
        result.core_subckt = topDesign->GetCellName();
    }
    AppendRunLog(root, "[SCAN] STEP4 DUT 识别: core_subckt=" + result.core_subckt +
        " dutDesign=" + dutDesign->GetCellName() +
        (dutDesign == topDesign ? " (顶层即DUT)" : " (从TB顶层下钻)"));
    AppendRunLog(root, "[SCAN] STEP4 DFS 开始");
    const auto addDevice = [&techAvailable, &guessMos, &scanCatalog, &result, &root](const maau::circuit::schematic::Inst *inst,
                               const std::string &path,
                               const std::string &parentCell,
                               const std::string &parentLib) {
        if (inst == nullptr) {
            return;
        }
        bool isMos = techAvailable ? inst->IsMos() : true;
        const int guessed = techAvailable ? 0 : guessMos(inst->GetCellName());
        if (techAvailable && !isMos) {
            return;
        }
        if (!techAvailable && guessed == 0) {
            return;
        }
        StructureMosDevice device;
        device.instance = path;
        device.master = inst->GetCellName();
        device.parent_subckt = parentCell;
        device.parent_lib = parentLib;
        device.kind = techAvailable
            ? (inst->IsPMos() ? st::DeviceKind::MosP : st::DeviceKind::MosN)
            : (guessed > 0 ? st::DeviceKind::MosN : st::DeviceKind::MosP);
        for (const auto *pin : inst->GetPins()) {
            if (pin == nullptr) {
                continue;
            }
            const std::string netName = pin->GetNet() == nullptr
                ? std::string() : pin->GetNet()->GetName();
            switch (pin->GetTermType()) {
            case maau::circuit::schematic::D:
                device.drain_net = netName;
                break;
            case maau::circuit::schematic::G:
                device.gate_net = netName;
                break;
            case maau::circuit::schematic::S:
                device.source_net = netName;
                break;
            case maau::circuit::schematic::B:
                device.bulk_net = netName;
                break;
            default:
                break;
            }
        }
        // 实例 CDF 参数（W/L/m 等）保留原文。
        for (const auto &[key, value] : inst->GetParams()) {
            device.parameters[key] = value;
        }
        // 异型 Cascode 候选：从 DeviceCatalog 里选同 kind 不同 master 的 MOS。
        if (techAvailable) {
            const auto *originalDesc = scanCatalog.Find(device.master);
            if (originalDesc != nullptr) {
                device.parameter_mode = st::MosParameterMode(*originalDesc);
                const auto selection = st::SelectCrossFlavorCandidates(
                    *originalDesc, scanCatalog, "core", false);
                for (const auto *candidate : selection.accepted) {
                    device.cross_flavor_candidates.push_back(candidate->master);
                    device.candidate_parameter_modes[candidate->master] =
                        st::MosParameterMode(*candidate);
                }
                for (const auto &[master, reasons] : selection.rejected_reasons) {
                    device.candidate_rejections[master] = reasons;
                }
            }
        }
        AppendRunLog(root, "[SCAN]   MOS: " + device.instance +
            " master=" + device.master +
            " kind=" + (device.kind == st::DeviceKind::MosN ? "NMOS" :
                        device.kind == st::DeviceKind::MosP ? "PMOS" : "?") +
            " parent=" + device.parent_subckt +
            " candidates=" + std::to_string(device.cross_flavor_candidates.size()));
        result.devices.push_back(std::move(device));
    };
    // 递归遍历：master 含子实例 → 子模块，下钻递归；否则视为叶器件候选。
    // 用"当前递归栈上的 design 集合"防环路（A↔B 互引），而不是全局 visited：
    // 同一子模块被多个实例引用（如 X_IO1/IO_bank、X_IO2/IO_bank）时两条路径
    // 都要扫到，各自路径下的 MOS 是不同物理器件。
    // DFS 递归时记录"上一层设计子模块"的 cell 名 + lib 名。
    // 当递归进入叶子标准单元（如 ts_nand2_18）时，叶子单元里的 MOS 的
    // parent_subckt 应该是包含该叶子单元实例的"设计子模块"（如 l50），
    // 而不是叶子标准单元本身。
    // 注意：叶器件判定不能只看 master==nullptr。中间层 design 既可能含子模块
    // 实例（master 内有子 inst，应下钻），也可能直接引用 PDK 叶器件（master
    // 内无子 inst，如 nch/pch 的 schematic view 只有 pin）。后者在原
    // "master==nullptr 才算叶" 的判定下会被错误下钻，导致该层直接放的 PDK
    // 器件从扫描结果中丢失。
    // 本地 lib 白名单：master lib 不在白名单的叶器件直接跳过（理想器件/
    // 公共 PDK 元件不可做结构变换）；子模块实例仅当 master lib 在白名单内
    // 才下钻，否则整个外部引用子树全部排除。isLocalLib 由外层捕获。
    struct ParentInfo {
        std::string cell;
        std::string lib;
    };
    std::set<const maau::circuit::schematic::Design *> onStack;
    std::function<void(const maau::circuit::schematic::Design *,
                       const std::string &, const ParentInfo &)> dfs =
        [&](const maau::circuit::schematic::Design *design,
            const std::string &prefix, const ParentInfo &parent) {
        if (design == nullptr || onStack.count(design) != 0) {
            return;
        }
        onStack.insert(design);
        for (const auto *inst : design->GetInsts()) {
            if (inst == nullptr) {
                continue;
            }
            const auto *master = inst->GetMaster();
            const std::string instName = st::NormalizeMosArrayName(inst->GetName());
            const std::string path =
                prefix.empty() ? instName : prefix + "." + instName;
            // 阵列 pcell 在 Virtuoso 中是一个 MOS；即使其 master 能展开出
            // 内部实例，也必须先保留完整阵列，禁止下钻拆成 bit。
            // 其他叶器件仍按 master 缺失或无子实例识别。
            const bool isLeafDevice = st::MosArrayBitCount(instName) > 1 ||
                (master == nullptr) || master->GetInsts().empty();
            if (isLeafDevice) {
                // 只收项目本地 lib 的叶器件：master lib 不在白名单（理想器件
                // /公共 PDK 元件，如 analogLib 的 vdc、functional 的 iprobe）
                // 直接跳过——这些 cell 不可做结构变换，出现在列表只会误导。
                if (!isLocalLib(inst->GetLibName())) {
                    continue;
                }
                // 叶子 MOS：parent_subckt 用上一层设计子模块（parent.cell），
                // 不是当前 design（可能是叶子标准单元）。
                // 但如果当前 design 就是 DUT 顶层（parent.cell 空），
                // 说明 MOS 直接在顶层，用当前 design 的 cell 名。
                if (parent.cell.empty()) {
                    addDevice(inst, path, design->GetCellName(), design->GetLibName());
                } else {
                    addDevice(inst, path, parent.cell, parent.lib);
                }
            } else {
                // 子模块实例：仅当 master lib 在项目本地白名单内才下钻；
                // 外部 PDK/公共库子模块整体跳过（其内部叶器件不可变换）。
                if (!isLocalLib(master->GetLibName())) {
                    continue;
                }
                // parent 应是"子模块 master"的 cell/lib，因为叶子 MOS 在
                // master 内部。不是当前 design（父级）。
                ParentInfo nextParent;
                nextParent.cell = master->GetCellName();
                nextParent.lib = master->GetLibName();
                dfs(master, path, nextParent);
            }
        }
        onStack.erase(design);
    };
    dfs(dutDesign, "", ParentInfo{});

    // 按 polarity 分组统计，便于在日志中快速比对 MOS 分布。
    std::size_t nmosCount = 0;
    std::size_t pmosCount = 0;
    std::size_t unknownCount = 0;
    for (const auto &device : result.devices) {
        if (device.kind == st::DeviceKind::MosN) {
            ++nmosCount;
        } else if (device.kind == st::DeviceKind::MosP) {
            ++pmosCount;
        } else {
            ++unknownCount;
        }
    }
    AppendRunLog(root, "[SCAN] STEP4 DFS 完成: core_subckt=" + result.core_subckt +
        " netlist_path=" + result.netlist_path +
        " devices=" + std::to_string(result.devices.size()) +
        " (nmos=" + std::to_string(nmosCount) +
        " pmos=" + std::to_string(pmosCount) +
        " unknown=" + std::to_string(unknownCount) + ")");

    result.ok = true;
    result.message = "scan done: " + std::to_string(result.devices.size()) + " MOS found";
    AppendRunLog(root, "[SCAN] ===== MOS 扫描结束: " + result.message + " =====");
    return result;
}

StructureTransformOpResult StructureTransformService::FinalizeTransform(
    const StructureTransformConfig &config,
    const std::vector<std::pair<std::string, std::string>> &cells)
{
    return RunTransformViewOp(config, cells, "finalize", "FTZ");
}

StructureTransformOpResult StructureTransformService::DiscardTransformViews(
    const StructureTransformConfig &config,
    const std::vector<std::pair<std::string, std::string>> &cells)
{
    return RunTransformViewOp(config, cells, "discard", "DISCARD");
}

} // namespace maau::stengine
