/**
 *
 * 结构变换嵌入 LDO 优化主流程的适配层。
 *
 * 设计说明：
 * - st_engine（结构变换引擎）原本以独立 CLI（st_circuit_tool）运行，电路获取
 *   靠终端输入 inspect 参数并写入会话目录 session.conf。
 * - 嵌入主流程后，本适配层作为 st_engine 与 LDO 主流程之间的桥梁：
 *   * 输入配置全部从 LDO 主流程生成的 project_cfg.json 读取（用户要求），
 *     字段映射见 StructureTransformConfig::FromProjectCfg。
 *   * 不再要求会话目录/CLI；变换直接作用于主流程给定的电路目录（cds 目录）。
 * - 变换类型（Cascode / Source电阻 / Stack）与目标器件通过
 *   StructureTransformRequest 指定；主流程把用户的变换意图填进来。
 */
#ifndef MAAU_MODULES_ST_ENGINE_STRUCTURE_TRANSFORM_SERVICE_H
#define MAAU_MODULES_ST_ENGINE_STRUCTURE_TRANSFORM_SERVICE_H

#include <string>
#include <vector>

#include "platform/clustorservice/cluster_type.h"
#include "st/ChangeSet.h"
#include "st/OaPlan.h"
#include "st/Packaging.h"
#include "st/Standalone.h"
#include "st/Transform.h"
#include "st/VirtuosoBackend.h"

namespace maau::stengine {

/**
 * @brief 结构变换在 LDO 优化主流程中的配置。
 * 所有路径字段的取值来源都是 project_cfg.json（FromProjectCfg）。
 */
struct StructureTransformConfig {
    // ---- 电路位置（来自 project_cfg.json）----
    std::string source_cds_path;   // project_cfg.source_cds_path（sizing/sim 时为 copy_cds_path）
    std::string target_cds_path;   // project_cfg.target_cds_path（clone 产物电路目录）
    // ---- DUT / Bench LCV（来自 project_cfg.json source_*/target_* 字段）----
    std::string source_dut_lib;
    std::string source_dut_cell;
    std::string source_dut_view;
    std::string target_dut_lib;
    std::string target_dut_cell;
    std::string target_dut_view;
    std::string source_tb_lib;
    std::string source_tb_cell;
    std::string source_tb_view;
    std::string target_tb_lib;
    std::string target_tb_cell;
    std::string target_tb_view;
    // ---- 工艺 / 仿真（来自 project_cfg.json）----
    std::string source_tech;       // project_cfg.source_tech
    std::string target_tech;       // project_cfg.target_tech
    std::string corner;            // project_cfg.pvt.corner（默认 tt）
    std::string pvt_corners;       // 逗号分隔，从 pvt 配置推导
    // 变换所在子模块 cell 名 + lib 名（GUI 从选中 MOS 的 parent_subckt/lib 取）。
    // Snapshot 以它为 source + core_subckt 导出这一层网表，直接在层内操作 MOS。
    // 空 = 用 source_dut_cell（顶层）。
    std::string transform_subckt;
    std::string transform_lib;
    // ---- VBIAS 求解（Cascode FixedBias 需要）----
    std::string vbias_vhigh_net;   // VBIAS 高电源轨网络（如 PVDD）
    std::string vbias_vlow_net;     // VBIAS 低电源轨网络（如 GND/AGND）
    std::string validation_scope = "dc_operating_point"; // dc_operating_point / structure_only
    // ---- st-engine 运行时（主流程环境注入，project_cfg.json 无默认值）----
    // 修改原因：空值使用可导入的 Python 后端（兼容 .so）；非空仍是显式外部后端路径。
    std::string backend_script;
    std::string skill_script;      // SKILL 物化脚本路径（原 CLI --skill）
    // 物化执行方式：主流程规范为 maau -cli sch + ClustorService::RunCmd（集群
    // 提交，见 rpc_flow_agent.cc / cluster_device.cc）。opt_algo_root 为 opt_algo
    // 仓库根（脚本 common/structure_transform/st_materialize_main.py 的基准），
    // 由主流程环境变量注入；cluster_config 决定是否提交集群（is_valid=true）。
    // 修改原因：发布包默认从 MAAU_ROOT/package/circuit/algorithm/opt_algo 定位，可由 OPT_ALGO_ROOT 覆盖。
    std::string opt_algo_root;
    maau::ClusterConfig cluster_config;   // 集群配置（is_valid=false 时本地执行）
    // ---- 会话工作目录（变换中间产物落点）----
    std::string work_dir;          // 建议取 project_cfg.project_base_path 下派生目录

    /** 从 LDO 主流程生成的 project_cfg.json 读取配置。
     * @param project_cfg_json project_cfg.json 文件路径
     * @param workDir 结构变换会话工作目录（由主流程指定）
     * @return true 读取成功 */
    bool FromProjectCfg(const std::string &project_cfg_json,
                        const std::string &workDir);
};

/**
 * @brief 一次结构变换请求（对应 st_engine 的一个 TransformRequest）。
 */
struct StructureTransformRequest {
    std::string operation_id;
    st::TransformType type = st::TransformType::SameTypeCascode;
    st::InstancePath target;           // subckt + instance 指定目标器件
    // GUI 传入的原始点分隔层次路径（如 ldo.ldo_top.I52.I35<4>.M2<1>），
    // 用于推导 OA 物化的层级 clone 路径（/ldo/ldo_top/I52/I35<4>）。
    // 非空时 Run() 用它构建多层级物化计划；为空时退化为根层封装。
    std::string hierarchy_path;
    st::CascodeTransformRequest cascode;
    st::ResistorTransformRequest resistor;
    st::StackTransformRequest stack;
    st::TransformRequest ToTransformRequest() const;
};

/**
 * @brief 结构变换结果。
 */
struct StructureTransformResult {
    bool ok = false;
    std::string message;
    st::ReplayResult replay;               // 变换重放结果（含新增/删除/修改清单）
    st::Netlist expected_netlist;          // 变换后的期望网表
    std::string expected_netlist_path;     // 期望网表落盘路径
    std::string log_path;
    st::PackageTopologyResult packaged;    // 封装结果（阶段4产出）
    std::string plan_path;                 // OA物化计划JSON路径（阶段4产出）
    // 物化产物定位：与原 DUT 同 lib 同 cell 下的新 view
    //（schematic__maau_struct_transform，固定后缀，每次 Run 覆盖）。
    std::string variant_lib;
    std::string variant_cell;
    std::string variant_view;
};

/**
 * @brief 通用结构变换 OA 操作（提升/清理）结果。
 */
struct StructureTransformOpResult {
    bool ok = false;
    std::string message;
    // 操作的 (lib, cell, view) 三元组，便于 GUI 提示与日志。
    std::vector<std::string> touched_views;
};

/**
 * @brief 扫描 DUT 得到的 MOS 清单（GUI 结构变换页填充器件列表用）。
 * 与 st_engine 的 DirectMosDevice 一一对应，Qt-free 标量便于 GUI 直接消费。
 */
struct StructureMosDevice {
    std::string instance;
    std::string master;
    st::DeviceKind kind = st::DeviceKind::Other;
    // 该 MOS 所在的最终子模块 cell 名 + lib 名（Snapshot 以它为 source + core_subckt，
    // 导出这一层网表后在层内直接操作 MOS）。空 = MOS 在顶层。
    std::string parent_subckt;
    std::string parent_lib;
    std::string drain_net;
    std::string gate_net;
    std::string source_net;
    std::string bulk_net;
    // 异型 Cascode 候选 master 列表（空 = 不可做异型 Cascode）。
    std::vector<std::string> cross_flavor_candidates;
    std::map<std::string, std::vector<std::string>> candidate_rejections;
    std::map<std::string, std::string> parameters;
    // w_l / wf_nf_l / unsupported；由原管和新增管各自的真实 CDF 得出。
    std::string parameter_mode = "unsupported";
    std::map<std::string, std::string> candidate_parameter_modes;
};

/**
 * @brief 扫描 DUT 的结果。
 */
struct StructureScanResult {
    bool ok = false;
    std::string message;
    std::string core_subckt;
    std::vector<StructureMosDevice> devices;   // 扫描到的全部 MOS
    std::string netlist_path;                  // 基线网表落盘路径（诊断用）
    std::string log_path;
};

/**
 * @brief 结构变换服务：把结构变换嵌入 LDO 优化主流程。
 *
 * 使用方式（在 LdoSizingCommandHandler::Execute 的 SizingAnalysis 之前调用）：
 *   1. StructureTransformConfig config; config.FromProjectCfg(project_cfg_path, work_dir);
 *   2. StructureTransformService service;
 *   3. 组装 StructureTransformRequest 列表（来自主流程的变换意图）；
 *   4. service.Run(config, requests, &result);
 *
 * 内部流程：
 *   - 从 config.target_cds_path 指定的 cds 目录 + DUT LCV 生成基线网表
 *     （主流程 NetlistBuilder / st_engine 后端二选一，见实现）；
 *   - ChangeSet 重放全部变换请求得到期望网表；
 *   - 期望网表落盘到 work_dir/expected/ 供后续物化/验证。
 */
class StructureTransformService {
public:
    /** @param runner 外部进程执行器；为空时使用内置 PosixProcessRunner */
    explicit StructureTransformService(st::standalone::ProcessRunner *runner = nullptr);
    ~StructureTransformService() = default;

    StructureTransformResult Run(const StructureTransformConfig &config,
                                 const std::vector<StructureTransformRequest> &requests);

    /** 扫描 DUT 电路，返回全部 MOS 及其异型 Cascode 候选。
     * GUI 结构变换页调用此接口填充器件列表。 */
    StructureScanResult ScanMos(const StructureTransformConfig &config);

    /** "生成最终电路"：把 cell 下所有 <view>__maau_struct_transform 后缀 view
     * 通过 dbCopyCellView 提升（覆盖）回原始 <view>。history 涉及的每个叶子层
     * cell + DUT 顶层 cell 都会被覆盖。
     * @param config  定位 lib/cell 用（target_dut_lib/cell/view）
     * @param cells   需要被提升的 (lib, cell) 对集合（各 cell 可能属于不同 lib）
     */
    StructureTransformOpResult FinalizeTransform(
        const StructureTransformConfig &config,
        const std::vector<std::pair<std::string, std::string>> &cells);

    /** "恢复初始"：清空 history 对应的物化产物——删除 cell 下所有
     * <view>__maau_struct_transform 后缀 view。
     * @param config  定位 lib/cell 用
     * @param cells   需要被清理的 (lib, cell) 对集合（各 cell 可能属于不同 lib）
     */
    StructureTransformOpResult DiscardTransformViews(
        const StructureTransformConfig &config,
        const std::vector<std::pair<std::string, std::string>> &cells);

private:
    // 共享的基线网表 + PDK 器件目录获取（Snapshot + catalog）。
    bool PrepareBaseline(const StructureTransformConfig &config,
                         st::Netlist &baseline,
                         st::DeviceCatalog &catalog,
                         std::string &message,
                         std::string *netlist_path = nullptr,
                         std::string *log_path = nullptr);
    st::standalone::ProcessRunner *runner_ = nullptr;
};

} // namespace maau::stengine

#endif // MAAU_MODULES_ST_ENGINE_STRUCTURE_TRANSFORM_SERVICE_H
