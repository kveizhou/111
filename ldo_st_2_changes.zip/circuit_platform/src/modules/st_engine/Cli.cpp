#include "st/Cli.h"

#include "st/AutoBias.h"
#include "st/BackendDcEvaluationHost.h"
#include "st/DcSolver.h"
#include "st/JsonWriter.h"
#include "st/OperatingPoint.h"
#include "st/Packaging.h"
#include "st/PdkCatalog.h"
#include "st/Standalone.h"

#include "securec.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>

namespace st::standalone {
namespace {

using Options = std::map<std::string, std::string>;

// 会话 Manifest schema=3：记录完整扫描目录的内容身份。
// 这些字段是 generate 自动求解闭环的全部会话级输入，禁止在生成时猜测。
struct SessionManifest {
    std::filesystem::path backend;
    std::filesystem::path cds_lib;
    std::string source_library;
    std::string source_cell;
    std::string source_view;
    std::string source_storage;
    std::string core_subckt;
    std::string variant_library;
    std::string variant_cell;
    std::string variant_id;
    std::filesystem::path skill_script;
    std::string bench_library;
    std::string bench_cell;
    std::string bench_view;
    std::string simulator;
    std::string nominal_corner;
    std::string pvt_corners;
    std::string pdk_version;
    std::string catalog_hash;
    std::string max_branch_current_error;
    std::string max_vbias_current;
    std::string dut_hash;
    std::string bench_hash;
    std::string vbias_vhigh_net;
    std::string vbias_vlow_net;
    std::string validation_scope = "dc_operating_point";
};

std::string trim(const std::string& input)
{
    const auto first = input.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return {};
    }
    const auto last = input.find_last_not_of(" \t\r\n");
    return input.substr(first, last - first + 1);
}

// 对成功解析后的扫描 TSV 计算稳定身份。排序记录行消除 PDK 枚举顺序差异；
// 保留整行字段，避免遗漏可靠性来源、CDF 来源等 JSON 摘要之外的证明数据。
bool catalogHash(const std::filesystem::path& path, std::string& hash,
                 std::string& message)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        message = "无法读取PDK扫描目录：" + path.string();
        return false;
    }
    std::string header;
    if (!std::getline(input, header)) {
        message = "PDK扫描目录为空：" + path.string();
        return false;
    }
    if (!header.empty() && header.back() == '\r') {
        header.pop_back();
    }
    std::vector<std::string> rows;
    std::string row;
    while (std::getline(input, row)) {
        if (!row.empty() && row.back() == '\r') {
            row.pop_back();
        }
        if (!row.empty()) {
            rows.push_back(row);
        }
    }
    if (!input.eof() || rows.empty()) {
        message = "PDK扫描目录读取失败或没有器件：" + path.string();
        return false;
    }
    std::sort(rows.begin(), rows.end());
    std::uint64_t value = UINT64_C(14695981039346656037);
    const auto feed = [&value](const std::string& line) {
        for (const unsigned char character : line) {
            value ^= character;
            value *= UINT64_C(1099511628211);
        }
        value ^= '\n';
        value *= UINT64_C(1099511628211);
    };
    feed(header);
    for (const auto& record : rows) {
        feed(record);
    }
    std::ostringstream output;
    output << std::hex << std::setw(16) << std::setfill('0') << value;
    hash = output.str();
    return true;
}

bool archiveScanLog(const HostStatus& status,
                    const std::filesystem::path& scanDirectory,
                    std::string& message)
{
    if (status.log_path.empty()) {
        message = "PDK扫描缺少后端日志路径";
        return false;
    }
    std::error_code error;
    if (!std::filesystem::copy_file(status.log_path,
            scanDirectory / "scan_pdk.log", std::filesystem::copy_options::none,
            error)) {
        message = "无法留存PDK扫描日志：" + error.message();
        return false;
    }
    return true;
}

bool parseOptions(const std::vector<std::string>& arguments,
                  std::string& command, Options& options, std::string& message)
{
    if (arguments.empty()) {
        message = "缺少命令";
        return false;
    }
    command = arguments.front();
    if (command == "help" || command == "--help" || command == "-h") {
        return true;
    }
    if ((arguments.size() - 1) % 2 != 0) {
        message = "参数必须使用--name value成对提供";
        return false;
    }
    for (std::size_t index = 1; index < arguments.size(); index += 2) {
        const auto& key = arguments[index];
        if (key.size() < 3 || key[0] != '-' || key[1] != '-' ||
            !options.emplace(key.substr(2), arguments[index + 1]).second) {
            message = "无效或重复参数：" + key;
            return false;
        }
    }
    return true;
}

bool required(const Options& options, const std::string& name,
              std::string& value, std::string& message)
{
    const auto found = options.find(name);
    if (found == options.end() || found->second.empty()) {
        message = "缺少参数--" + name;
        return false;
    }
    value = found->second;
    return true;
}

std::string optional(const Options& options, const std::string& name,
                     const std::string& fallback = {})
{
    const auto found = options.find(name);
    return found == options.end() ? fallback : found->second;
}

bool applyResistorTrials(const std::string& path, DeviceCatalog& catalog,
                        std::ostream& output, std::string& message, bool automatic = false)
{
    std::ifstream input(path);
    std::string master;
    std::string cdf;
    std::string text;
    if (!(input >> master >> cdf >> text)) {
        message = "参考电阻试点文件需要 master CDF values";
        return false;
    }
    const auto* source = catalog.Find(master);
    if (!source || source->kind != DeviceKind::Resistor || !source->native_parameter_trials) {
        message = "参考电阻试点必须对应当前原生实验电阻";
        return false;
    }
    auto selected = *source;
    selected.native_resistor_auto_search = automatic;
    auto resistance = selected.parameter_constraints.find("resistance");
    if (resistance == selected.parameter_constraints.end() || resistance->second.cdf_name != cdf) {
        message = "参考电阻试点CDF映射与当前目录不一致";
        return false;
    }
    std::map<std::string, std::vector<double>> columns;
    const std::string resistanceCdf = cdf;
    const std::string resistanceText = text;
    for (;;) {
        auto found = std::find_if(selected.parameter_constraints.begin(), selected.parameter_constraints.end(),
            [&cdf](const auto& item) { return item.second.cdf_name == cdf; });
        if (found == selected.parameter_constraints.end() || columns.count(cdf)) {
            message = "参考电阻联动参数缺少CDF约束或重复: " + cdf;
            return false;
        }
        std::vector<double> values;
        std::istringstream parts(text);
        std::string part;
        while (std::getline(parts, part, ',')) {
            bool parsed = false;
            const double value = parseSuffixValue(part, parsed);
            if (!parsed || !std::isfinite(value) || values.size() >= (automatic ? 4096U : 5U) ||
                (cdf == resistanceCdf && (value <= 0 || std::find(values.begin(),values.end(),value)!=values.end()))) {
                message = "参考电阻试点数值无效: " + cdf;
                return false;
            }
            values.push_back(value);
        }
        if (values.empty() || (!columns.empty() && values.size() != columns.at(resistanceCdf).size())) {
            message = "参考电阻联动参数非空且列数必须相同";
            return false;
        }
        auto& domain = found->second;
        // Python checked the known CDF limits. These are finite experimental
        // tuples; keep old bounds for unchanged instances of the same master.
        domain.minimum = std::min(domain.minimum, *std::min_element(values.begin(),values.end()));
        domain.maximum = std::max(domain.maximum, *std::max_element(values.begin(),values.end()));
        domain.grid = 0;
        domain.discrete_values = values;
        if (cdf != resistanceCdf) {
            std::sort(domain.discrete_values.begin(),domain.discrete_values.end());
            domain.discrete_values.erase(std::unique(domain.discrete_values.begin(),domain.discrete_values.end()),
                                         domain.discrete_values.end());
        }
        columns[cdf] = values;
        std::string nextMaster;
        if (!(input >> nextMaster)) {
            break;
        }
        if (nextMaster != master || !(input >> cdf >> text)) {
            message = "参考电阻联动参数行不完整或master不同";
            return false;
        }
    }
    const auto& values = columns.at(resistanceCdf);
    for (std::size_t index = 0; index < values.size(); ++index) {
        for (const auto& column : columns) {
            selected.native_resistor_trial_parameters[values[index]][column.first] = FormatAutoBiasParameter(column.second[index]);
        }
    }
    selected.limits.min_resistance = std::min(selected.limits.min_resistance, resistance->second.minimum);
    selected.limits.max_resistance = std::max(selected.limits.max_resistance, resistance->second.maximum);
    DeviceCatalog active;
    Diagnostic diagnostic;
    for (const auto& [name, descriptor] : catalog.Descriptors()) {
        if (!active.Add(name == master ? selected : descriptor, diagnostic)) {
            message = diagnostic.message;
            return false;
        }
    }
    catalog = std::move(active);
    output << "EXPERIMENT_RESISTOR_TRIALS master=" << master << " cdf=" << resistanceCdf
           << (automatic ? " automatic_candidates=" : " values=")
           << (automatic ? std::to_string(values.size()) : resistanceText) << " coupled_parameters=" << columns.size() << '\n';
    return true;
}

bool positiveLimit(const std::string& text, bool currentWithSuffix, double& value)
{
    if (text.empty()) {
        return false;
    }
    if (currentWithSuffix) {
        bool parsed = false;
        value = parseSuffixValue(text, parsed);
        return parsed && std::isfinite(value) && value > 0.0;
    }
    try {
        std::size_t used = 0;
        value = std::stod(text, &used);
        return used == text.size() && std::isfinite(value) && value > 0.0;
    } catch (const std::exception&) {
        return false;
    }
}

bool writeAtomic(const std::filesystem::path& path, const std::string& text,
                 std::string& message)
{
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    if (error) {
        message = "无法创建目录" + path.parent_path().string() + "：" + error.message();
        return false;
    }
    const auto temporary = path.string() + ".tmp";
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        output << text;
        if (!output) {
            message = "无法写文件：" + temporary;
            return false;
        }
    }
    std::filesystem::remove(path, error);
    error.clear();
    std::filesystem::rename(temporary, path, error);
    if (error) {
        std::filesystem::remove(temporary);
        message = "无法发布文件" + path.string() + "：" + error.message();
        return false;
    }
    return true;
}

std::string manifestText(const SessionManifest& manifest)
{
    std::ostringstream output;
    output << "schema=3\n"
           << "validation_scope=" << manifest.validation_scope << '\n'
           << "backend=" << manifest.backend.string() << '\n'
           << "cds_lib=" << manifest.cds_lib.string() << '\n'
           << "source_library=" << manifest.source_library << '\n'
           << "source_cell=" << manifest.source_cell << '\n'
           << "source_view=" << manifest.source_view << '\n'
           << "source_storage=" << manifest.source_storage << '\n'
           << "core_subckt=" << manifest.core_subckt << '\n'
           << "variant_library=" << manifest.variant_library << '\n'
           << "variant_cell=" << manifest.variant_cell << '\n'
           << "variant_id=" << manifest.variant_id << '\n'
           << "skill_script=" << manifest.skill_script.string() << '\n'
           << "bench_library=" << manifest.bench_library << '\n'
           << "bench_cell=" << manifest.bench_cell << '\n'
           << "bench_view=" << manifest.bench_view << '\n'
           << "simulator=" << manifest.simulator << '\n'
           << "nominal_corner=" << manifest.nominal_corner << '\n'
           << "pvt_corners=" << manifest.pvt_corners << '\n'
           << "pdk_version=" << manifest.pdk_version << '\n'
           << "catalog_hash=" << manifest.catalog_hash << '\n'
           << "max_branch_current_error=" << manifest.max_branch_current_error << '\n'
           << "max_vbias_current=" << manifest.max_vbias_current << '\n'
           << "dut_hash=" << manifest.dut_hash << '\n'
           << "bench_hash=" << manifest.bench_hash << '\n'
           << "vbias_vhigh_net=" << manifest.vbias_vhigh_net << '\n'
           << "vbias_vlow_net=" << manifest.vbias_vlow_net << '\n';
    return output.str();
}

bool readPairs(const std::filesystem::path& path,
               std::map<std::string, std::string>& values, std::string& message)
{
    std::ifstream input(path);
    if (!input) {
        message = "无法读取会话文件：" + path.string();
        return false;
    }
    std::string line;
    while (std::getline(input, line)) {
        line = trim(line);
        if (line.empty() || line.front() == '#') {
            continue;
        }
        const auto separator = line.find('=');
        if (separator == std::string::npos) {
            message = "会话文件格式错误：" + line;
            return false;
        }
        values[trim(line.substr(0, separator))] = trim(line.substr(separator + 1));
    }
    return true;
}

bool loadManifest(const std::filesystem::path& root,
                  SessionManifest& manifest, std::string& message)
{
    std::map<std::string, std::string> values;
    if (!readPairs(root / "session.conf", values, message)) {
        return false;
    }
    if (values["schema"] != "3") {
        message = "会话文件schema不是3，请用当前版本inspect重建会话";
        return false;
    }
    // 发现会话允许 Bench/轨网/Case 限值留空；generate 再检查仿真入口。
    const char* requiredKeys[] = {"backend", "cds_lib", "source_library",
        "source_cell", "source_view", "source_storage", "core_subckt",
        "variant_library", "variant_cell", "variant_id", "skill_script",
        "simulator", "nominal_corner", "pdk_version", "catalog_hash", "dut_hash"};
    for (const auto* key : requiredKeys) {
        if (values[key].empty()) {
            message = "会话文件缺少字段：" + std::string(key);
            return false;
        }
    }
    manifest.backend = values["backend"];
    manifest.cds_lib = values["cds_lib"];
    manifest.source_library = values["source_library"];
    manifest.source_cell = values["source_cell"];
    manifest.source_view = values["source_view"];
    manifest.source_storage = values["source_storage"];
    manifest.core_subckt = values["core_subckt"];
    manifest.variant_library = values["variant_library"];
    manifest.variant_cell = values["variant_cell"];
    manifest.variant_id = values["variant_id"];
    manifest.skill_script = values["skill_script"];
    manifest.bench_library = values["bench_library"];
    manifest.bench_cell = values["bench_cell"];
    manifest.bench_view = values["bench_view"];
    if (!values["validation_scope"].empty()) {
        manifest.validation_scope = values["validation_scope"];
    }
    if (manifest.validation_scope != "dc_operating_point" && manifest.validation_scope != "structure_only" &&
        manifest.validation_scope != "experimental_dc") {
        message = "未知validation_scope";
        return false;
    }
    const auto scopePath = root / "before/validation_scope.txt";
    std::ifstream scopeInput(scopePath);
    std::string pinnedScope;
    if ((scopeInput && (!std::getline(scopeInput, pinnedScope) ||
                        trim(pinnedScope) != manifest.validation_scope)) ||
        (!scopeInput && manifest.validation_scope == "experimental_dc")) {
        message = "validation_scope与inspect固定范围不一致，请新建隔离会话";
        return false;
    }
    const bool anyBench = !manifest.bench_library.empty() ||
        !manifest.bench_cell.empty() || !manifest.bench_view.empty();
    if (anyBench && (manifest.bench_library.empty() ||
                     manifest.bench_cell.empty() ||
                     manifest.bench_view.empty())) {
        message = "Bench L/C/V 必须成组提供";
        return false;
    }
    manifest.simulator = values["simulator"];
    manifest.nominal_corner = values["nominal_corner"];
    manifest.pvt_corners = values["pvt_corners"];
    manifest.pdk_version = values["pdk_version"];
    manifest.catalog_hash = values["catalog_hash"];
    manifest.max_branch_current_error = values["max_branch_current_error"];
    manifest.max_vbias_current = values["max_vbias_current"];
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            message = "Case支路电流偏差与VBIAS电流上限必须成对提供且为正数";
            return false;
        }
    }
    manifest.dut_hash = values["dut_hash"];
    manifest.bench_hash = values["bench_hash"];
    manifest.vbias_vhigh_net = values["vbias_vhigh_net"];
    manifest.vbias_vlow_net = values["vbias_vlow_net"];
    if (manifest.vbias_vhigh_net.empty() != manifest.vbias_vlow_net.empty()) {
        message = "VBIAS 高低轨网必须成组提供";
        return false;
    }
    return true;
}

bool loadNetlist(const std::filesystem::path& path, Netlist& netlist,
                 std::string& message)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        message = "无法读取网表：" + path.string();
        return false;
    }
    const std::string text((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());
    std::vector<Diagnostic> diagnostics;
    netlist = parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) {
        message = "网表解析失败：" + diagnostics.front().message;
        return false;
    }
    return true;
}

bool loadCatalog(const std::filesystem::path& root, DeviceCatalog& catalog,
                 std::string& message, bool experimentalDc = false)
{
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(root / "before/device_catalog.tsv", catalog, diagnostics)) {
        message = diagnostics.empty() ? "PDK器件目录读取失败" : diagnostics.front().message;
        return false;
    }
    for (const auto& entry : catalog.Descriptors()) {
        if (entry.second.native_parameter_trials && !experimentalDc) {
            message = "原生参数试点目录只允许experimental_dc：" + entry.first;
            return false;
        }
    }
    return true;
}
std::vector<std::filesystem::path> changeFiles(const std::filesystem::path& root)
{
    std::vector<std::filesystem::path> files;
    std::error_code error;
    const auto directory = root / "changes";
    if (!std::filesystem::exists(directory, error)) {
        return files;
    }
    for (const auto& entry : std::filesystem::directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == ".conf") {
            files.push_back(entry.path());
        }
    }
    std::sort(files.begin(), files.end());
    return files;
}

// FixedBias Cascode 在操作文件里只是"意图声明"：求解结果由 generate
// 自动闭环产生。求解前它不参与网表重放（重放必然因缺少求解结果而失败）。
bool needsBiasSolve(const TransformRequest& request)
{
    if (request.type != TransformType::SameTypeCascode &&
        request.type != TransformType::CrossFlavorCascode) {
        return false;
    }
    const auto* payload = std::get_if<CascodeTransformRequest>(&request.payload);
    return payload != nullptr && payload->gate_policy == GatePolicy::FixedBias &&
        !payload->solved_bias.has_value();
}

bool prepareScopeRequest(TransformRequest& request, const SessionManifest& manifest,
                         std::string& message)
{
    const bool experimentalDc = manifest.validation_scope == "experimental_dc";
    if (auto* cascode = std::get_if<CascodeTransformRequest>(&request.payload)) {
        cascode->experimental_dc = experimentalDc;
    }
    if (auto* resistor = std::get_if<ResistorTransformRequest>(&request.payload)) {
        resistor->experimental_dc = experimentalDc;
    }
    if (auto* stack = std::get_if<StackTransformRequest>(&request.payload)) {
        stack->experimental_dc = experimentalDc;
    }
    if (manifest.validation_scope != "structure_only") {
        return true;
    }
    if (request.type != TransformType::AddSourceResistor && request.type != TransformType::MosStack) {
        message = "structure_only仅支持Source电阻和共栅Stack；Cascode/VBIAS需要DC会话";
        return false;
    }
    if (auto* stack = std::get_if<StackTransformRequest>(&request.payload)) {
        stack->structure_only = true;
    }
    return true;
}

bool invalidateValidation(const std::filesystem::path& root, std::string& message)
{
    std::error_code error;
    std::filesystem::remove(root / "reports/validation.txt", error);
    if (!error) {
        return true;
    }
    message = "无法撤销旧生成验证：" + error.message();
    return false;
}

// 解析并校验全部已确认操作；validated 用于幂等冲突检查，顺序保持文件序。
bool loadChangeRequests(const std::filesystem::path& root,
                        const SessionManifest& manifest,
                        std::vector<TransformRequest>& requests,
                        ChangeSet& validated, std::string& message)
{
    for (const auto& path : changeFiles(root)) {
        auto parsed = ParseTransformRequest(path, manifest.core_subckt);
        if (!parsed.ok) {
            message = parsed.diagnostics.empty() ? "操作文件解析失败" :
                parsed.diagnostics.front().message;
            return false;
        }
        if (!prepareScopeRequest(parsed.request, manifest, message)) {
            return false;
        }
        Diagnostic diagnostic;
        if (!validated.Confirm(parsed.request, diagnostic)) {
            message = diagnostic.message;
            return false;
        }
        requests.push_back(parsed.request);
    }
    return true;
}

bool confirmReplayable(const std::vector<TransformRequest>& requests,
                       ChangeSet& replayable, std::string& message)
{
    for (const auto& request : requests) {
        if (needsBiasSolve(request)) {
            continue;
        }
        Diagnostic diagnostic;
        if (!replayable.Confirm(request, diagnostic)) {
            message = diagnostic.message;
            return false;
        }
    }
    return true;
}

struct BuildCurrentOutputs {
    Netlist& baseline;
    DeviceCatalog& catalog;
    std::vector<TransformRequest>& requests;
    Netlist& current;
    ReplayResult& replay;
};

bool buildCurrent(const std::filesystem::path& root, const SessionManifest& manifest,
                  BuildCurrentOutputs outputs, std::string& message)
{
    ChangeSet validated;
    if (!loadNetlist(root / "before/core_before.scs", outputs.baseline, message) ||
        !loadCatalog(root, outputs.catalog, message, manifest.validation_scope == "experimental_dc") ||
        !loadChangeRequests(root, manifest, outputs.requests, validated, message)) {
        return false;
    }
    ChangeSet replayable;
    if (!confirmReplayable(outputs.requests, replayable, message)) {
        return false;
    }
    outputs.replay = replayable.Generate(outputs.baseline, outputs.current, outputs.catalog);
    if (!outputs.replay.ok) {
        message = outputs.replay.diagnostics.empty() ? "Change Set重放失败" :
            outputs.replay.diagnostics.front().message;
        return false;
    }
    return true;
}

void printInventory(std::ostream& output, const MosInventoryResult& inventory)
{
    output << "可修改MOS（所选核心cell当前层）: " << inventory.devices.size() << '\n';
    for (const auto& device : inventory.devices) {
        output << "  " << device.instance << "  "
               << (device.kind == DeviceKind::MosN ? "NMOS" : device.kind == DeviceKind::MosP ? "PMOS" : "MOS")
               << "  master=" << device.master
               << "  D=" << device.drain_net << " G=" << device.gate_net
               << " S=" << device.source_net << " B=" << device.bulk_net;
        if (!device.cross_flavor_candidates.empty()) {
            output << "  异型候选=";
            for (std::size_t index = 0; index < device.cross_flavor_candidates.size(); ++index) {
                if (index != 0) {
                    output << ',';
                }
                output << device.cross_flavor_candidates[index];
            }
        }
        output << '\n';
    }
}

std::string stageName(MaterializationStage stage)
{
    switch (stage) {
    case MaterializationStage::ValidatePlan: return "validate_plan";
    case MaterializationStage::CopyCircuit: return "copy_circuit";
    case MaterializationStage::WritePlan: return "write_plan";
    case MaterializationStage::ExecuteSkill: return "execute_skill";
    case MaterializationStage::NominalDcCheck: return "nominal_dc_check";
    case MaterializationStage::PvtCheck: return "pvt_check";
    case MaterializationStage::VerifySource: return "verify_source";
    case MaterializationStage::RegenerateNetlist: return "regenerate_netlist";
    case MaterializationStage::VerifyRoundTrip: return "verify_roundtrip";
    case MaterializationStage::PublishTarget: return "publish_target";
    case MaterializationStage::Complete: return "complete";
    }
    return "unknown";
}

std::vector<std::string> splitCommaList(const std::string& input)
{
    std::vector<std::string> values;
    std::string value;
    std::istringstream stream(input);
    while (std::getline(stream, value, ',')) {
        value = trim(value);
        if (!value.empty()) {
            values.push_back(value);
        }
    }
    return values;
}

std::string jsonEscape(const std::string& text)
{
    std::string escaped;
    for (const char ch : text) {
        switch (ch) {
        case '"': escaped += "\\\""; break;
        case '\\': escaped += "\\\\"; break;
        default:
            if (static_cast<unsigned char>(ch) < 0x20) {
                escaped += '?';
            } else {
                escaped += ch;
            }
        }
    }
    return escaped;
}

std::string formatNumber(double value)
{
    if (!std::isfinite(value)) {
        return "null";
    }
    char buffer[64];
    snprintf_s(buffer, sizeof(buffer), sizeof(buffer), "%.6g", value);
    return buffer;
}

void appendJsonList(std::string& target, const std::vector<std::string>& items)
{
    for (std::size_t i = 0; i < items.size(); ++i) {
        if (i != 0) {
            target += ',';
        }
        target += '"' + jsonEscape(items[i]) + '"';
    }
}

void appendPvtJson(std::string& target,
                   const std::vector<PvtCornerResult>& results)
{
    bool firstCorner = true;
    for (const auto& corner : results) {
        if (!firstCorner) {
            target += ',';
        }
        firstCorner = false;
        target += std::string("{\"corner\":\"") +
            jsonEscape(corner.corner) + "\",\"ok\":" +
            (corner.ok ? "true" : "false") +
            ",\"constraint\":\"" +
            jsonEscape(corner.failed_constraint) + "\"}";
    }
}

void pinBiasRoles(const ReplayResult& cumulativeReplay, const ChangeSet& cumulativeChanges,
                  std::vector<ElectricalConstraintRequest>& checks)
{
    for (std::size_t i = 0; i < cumulativeReplay.outcomes.size(); ++i) {
        const auto& outcome = cumulativeReplay.outcomes[i];
        if (outcome.bias_instances.empty()) {
            continue;
        }
        for (auto& check : checks) {
            if (check.operation_id != cumulativeChanges.Changes()[i].request.operation_id) {
                continue;
            }
            check.control_replica.container_instance = outcome.bias_instances.front();
            check.bias_resistor.container_instance = outcome.bias_instances.front();
        }
    }
}

struct VbiasTemplateState {
    bool* any_failed = nullptr;
    std::string* status_text = nullptr;
    std::string* diagnostics_json = nullptr;
    std::string* pvt_json = nullptr;
    std::string* pvt_ready_json = nullptr;
    std::string* experimental_pvt_ready_json = nullptr;
    std::vector<ElectricalConstraintRequest>* electrical_checks = nullptr;
    CascodeTransformRequest* payload = nullptr;
    std::ostream* output = nullptr;
    std::string* failure_message = nullptr;
    const SessionManifest* manifest = nullptr;
    const TransformRequest* request = nullptr;
    bool experimental_dc = false;
};

void applyBuiltTemplate(const AutoBiasSolveResult& solved,
                        const AutoBiasTemplateRequest& templateRequest,
                        const DeviceCatalog& catalog,
                        const VbiasTemplateState& state)
{
    const auto built = BuildAutoBiasTemplate(templateRequest, solved.sizing, catalog);
    if (!built.ok) {
        *state.any_failed = true;
        *state.status_text = "no_solution";
        *state.diagnostics_json = "[\"" +
            jsonEscape(built.diagnostics.empty() ? std::string("模板构建失败")
                                                 : built.diagnostics.front().message) +
            "\"]";
        if (state.failure_message->empty()) {
            *state.failure_message = "操作 " + state.request->operation_id + " VBIAS模板构建失败";
        }
        return;
    }
    state.payload->solved_bias = solved;
    state.payload->bias_template = built;
    state.payload->vbias_vhigh_net = state.manifest->vbias_vhigh_net;
    state.payload->vbias_vlow_net = state.manifest->vbias_vlow_net;
    *state.status_text = solved.best_effort ? "best_effort" : "solved";
    *state.output << "VBIAS_SELECTION operation=" << state.request->operation_id
                  << " result=" << *state.status_text << " point=" << solved.selected_candidate
                  << " evaluations=" << solved.nominal_evaluations
                  << " vbias=" << solved.sizing.nominal_voltage << std::endl;
    *state.output << "VBIAS_CUMULATIVE_CHECK operation=" << state.request->operation_id
                  << " previous_groups=" << state.electrical_checks->size()
                  << " result=" << (state.experimental_dc
                      ? state.electrical_checks->empty() ? "NOT_APPLICABLE" : "DEFERRED_TO_FINAL"
                      : "PASS") << std::endl;
    *state.pvt_ready_json = solved.pvt_ready && !state.experimental_dc ? "true" : "false";
    *state.experimental_pvt_ready_json = solved.pvt_ready && state.experimental_dc ? "true" : "false";
    state.electrical_checks->push_back(solved.electrical_check);
    *state.pvt_json = "[";
    appendPvtJson(*state.pvt_json, solved.pvt_results);
    *state.pvt_json += ']';
}

// The OA structural exporter needs a terminal order and the instance CDF
// parameter names before it can emit a faithful baseline/round-trip netlist.
// Derive its legacy TSV contract from this session's authoritative scan, not
// from server/config/device_policy.tsv for one demonstration process.
bool writeScannedDevicePolicy(const DeviceCatalog& catalog,
                              const std::filesystem::path& path,
                              std::string& message)
{
    std::ostringstream output;
    output << "oa_library\toa_cell\tkind\tvoltage_domain\tcompatible_masters\t"
              "normalized_to_cdf\tisolated_well\tsource_drain_interchangeable\t"
              "min_width\tmax_width\tmin_length\tmax_length\tmin_resistance\t"
              "max_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\t"
              "terminal_order\n";
    const auto number = [](double value) {
        std::ostringstream stream;
        stream << std::setprecision(17) << value;
        return stream.str();
    };
    const auto join = [](const std::vector<std::string>& values,
                         const char separator) {
        std::string joined;
        for (const auto& value : values) {
            if (!joined.empty()) {
                joined += separator;
            }
            joined += value;
        }
        return joined;
    };
    for (const auto& [master, device] : catalog.Descriptors()) {
        const char* kind = device.kind == DeviceKind::MosN ? "mos_n" :
                           device.kind == DeviceKind::MosP ? "mos_p" :
                           device.kind == DeviceKind::Mos ? "mos" :
                           device.kind == DeviceKind::Resistor ? "resistor" : nullptr;
        if (kind == nullptr) {
            continue;
        }
        if (device.oa_library.empty() || device.oa_cell.empty() ||
            device.terminal_names_by_index.empty()) {
            message = "扫描目录中的器件缺少OA身份或物理端子：" + master;
            return false;
        }
        std::vector<std::string> mappings;
        for (const auto& [semantic, cdf] : device.normalized_to_cdf) {
            if (!semantic.empty() && !cdf.empty()) {
                mappings.push_back(semantic + ':' + cdf);
            }
        }
        for (const auto& [semantic, constraint] : device.parameter_constraints) {
            if (constraint.cdf_name.empty()) {
                continue;
            }
            const std::string mapping = semantic + ':' + constraint.cdf_name;
            if (std::find(mappings.begin(), mappings.end(), mapping) == mappings.end()) {
                mappings.push_back(mapping);
            }
        }
        const std::vector<std::string> fields = {
            device.oa_library, device.oa_cell, kind,
            device.voltage_domain, "self", join(mappings, ','),
            device.isolated_well ? "true" : "false",
            device.source_drain_interchangeable ? "true" : "false",
            number(device.limits.min_width), number(device.limits.max_width),
            number(device.limits.min_length), number(device.limits.max_length),
            number(device.limits.min_resistance), number(device.limits.max_resistance),
            number(device.limits.max_abs_vgs), number(device.limits.max_abs_vds),
            number(device.limits.max_abs_vgb),
            std::to_string(device.limits.max_stack_level),
            join(device.terminal_names_by_index, ',')};
        for (std::size_t index = 0; index < fields.size(); ++index) {
            const auto& field = fields[index];
            if (field.find_first_of("\t\r\n") != std::string::npos) {
                message = "扫描目录字段含非法分隔符：" + master;
                return false;
            }
            if (index != 0) {
                output << '\t';
            }
            output << (field.empty() ? "-" : field);
        }
        output << '\n';
    }
    return writeAtomic(path, output.str(), message);
}

std::string paramsJson(const std::map<std::string, std::string>& params)
{
    std::string output = "{";
    bool first = true;
    for (const auto& [name, value] : params) {
        if (!first) {
            output += ',';
        }
        first = false;
        output += '"' + jsonEscape(name) + "\":\"" + jsonEscape(value) + "\"";
    }
    output += '}';
    return output;
}

std::string sizingJson(const BiasSizing& sizing)
{
    // 保留空 mirror_master 字段以兼容既有结果读取方；当前模板不含镜像器件。
    std::string output = "{\"mirror_master\":\"\",\"resistor_master\":\"" +
        jsonEscape(sizing.resistor_master) +
        "\",\"nominal_voltage\":" + formatNumber(sizing.nominal_voltage) +
        ",\"iq_delta\":" + formatNumber(sizing.iq_delta) +
        ",\"cascode\":" + paramsJson(sizing.cascode_parameters) + ",\"elements\":{";
    bool first = true;
    for (const auto& [role, params] : sizing.element_parameters) {
        if (!first) {
            output += ',';
        }
        first = false;
        output += '"' + jsonEscape(role) + "\":" + paramsJson(params);
    }
    output += "}}";
    return output;
}

std::string metricsJson(const DcCandidateMetrics& metrics)
{
    return std::string("{\"branch_current_error\":") +
        formatNumber(metrics.branch_current_error) + ",\"control_op_error\":" +
        formatNumber(metrics.control_op_error) + ",\"iq_delta\":" +
        formatNumber(metrics.iq_delta) + ",\"reliability_margin\":" +
        formatNumber(metrics.reliability_margin) + ",\"saturation_margin\":" +
        formatNumber(metrics.saturation_margin) + ",\"area_estimate\":" +
        formatNumber(metrics.area_estimate) + '}';
}

std::string operationTypeName(TransformType type)
{
    switch (type) {
    case TransformType::SameTypeCascode: return "same_type_cascode";
    case TransformType::CrossFlavorCascode: return "cross_flavor_cascode";
    case TransformType::AddSourceResistor: return "add_source_resistor";
    case TransformType::MosStack: return "mos_stack";
    }
    return "unknown";
}

// 按角色语义从实例读取端网（Source/Gate），端子顺序由 PDK 目录提供。
bool terminalNet(const DeviceCatalog& catalog, const Instance& instance,
                 TerminalRole role, std::string& net, std::string& message)
{
    std::size_t index = 0;
    Diagnostic diagnostic;
    if (!catalog.ResolveTerminal(instance.model, role, instance.nets.size(), index,
                                 diagnostic)) {
        message = diagnostic.message;
        return false;
    }
    if (index >= instance.nets.size()) {
        message = "实例 " + instance.name + " 端子数与目录不一致";
        return false;
    }
    net = instance.nets[index];
    return true;
}

// 真实候选 DC 由公共 BackendDcEvaluationHost 完成。

int inspectCommand(const Options& options, std::ostream& output,
                   std::ostream& error, ProcessRunner& runner)
{
    std::string message;
    SessionManifest manifest;
    std::string workDir;
    if (!required(options, "backend", workDir, message)) {
        error << message << '\n';
        return 2;
    }
    manifest.backend = workDir;
    if (!required(options, "cds-lib", workDir, message)) {
        error << message << '\n';
        return 2;
    }
    manifest.cds_lib = workDir;
    if (!required(options, "lib", manifest.source_library, message) ||
        !required(options, "cell", manifest.source_cell, message) ||
        !required(options, "view", manifest.source_view, message) ||
        !required(options, "work-dir", workDir, message) ||
        !required(options, "variant-lib", manifest.variant_library, message) ||
        !required(options, "variant-cell", manifest.variant_cell, message) ||
        !required(options, "variant-id", manifest.variant_id, message)) {
        error << message << '\n';
        return 2;
    }
    manifest.bench_library = optional(options, "bench-lib");
    manifest.validation_scope = optional(options, "validation-scope", "dc_operating_point");
    if (manifest.validation_scope != "dc_operating_point" && manifest.validation_scope != "structure_only" &&
        manifest.validation_scope != "experimental_dc") {
        error << "validation-scope只支持dc_operating_point、structure_only或experimental_dc\n";
        return 2;
    }
    manifest.bench_cell = optional(options, "bench-cell");
    manifest.bench_view = optional(options, "bench-view");
    manifest.vbias_vhigh_net = optional(options, "vbias-vhigh-net");
    manifest.vbias_vlow_net = optional(options, "vbias-vlow-net");
    const bool anyBench = !manifest.bench_library.empty() ||
        !manifest.bench_cell.empty() || !manifest.bench_view.empty();
    if (anyBench && (manifest.bench_library.empty() ||
                     manifest.bench_cell.empty() ||
                     manifest.bench_view.empty())) {
        error << "Bench L/C/V 必须成组提供\n";
        return 2;
    }
    if (manifest.vbias_vhigh_net.empty() != manifest.vbias_vlow_net.empty()) {
        error << "VBIAS 高低轨网必须成组提供\n";
        return 2;
    }
    std::string skill;
    if (!required(options, "skill", skill, message)) {
        error << message << '\n';
        return 2;
    }
    manifest.skill_script = skill;
    manifest.core_subckt = optional(options, "core-subckt", manifest.source_cell);
    manifest.simulator = optional(options, "simulator", "spectre");
    manifest.nominal_corner = optional(options, "nominal-corner", "tt");
    manifest.pvt_corners = optional(options, "pvt-corners", "");
    manifest.max_branch_current_error =
        optional(options, "max-branch-current-error");
    manifest.max_vbias_current = optional(options, "max-vbias-current");
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            error << "Case支路电流偏差与VBIAS电流上限必须成对提供且为正数\n";
            return 2;
        }
    }
    if (manifest.simulator != "spectre") {
        error << "仅支持spectre仿真器声明，收到：" << manifest.simulator << '\n';
        return 2;
    }
    if (manifest.variant_library == manifest.source_library) {
        error << "派生library必须与源library不同，拒绝写入源设计库\n";
        return 2;
    }
    constexpr const char* stagingSuffix = "__STAGING";
    if (manifest.variant_library.size() >= std::char_traits<char>::length(stagingSuffix) &&
        manifest.variant_library.compare(
            manifest.variant_library.size() - std::char_traits<char>::length(stagingSuffix),
            std::char_traits<char>::length(stagingSuffix), stagingSuffix) == 0) {
        error << "派生library名称不能以__STAGING结尾\n";
        return 2;
    }
    manifest.source_storage = manifest.cds_lib.parent_path().string();
    const std::filesystem::path root(workDir);
    if (std::filesystem::exists(root / "session.conf")) {
        error << "工作目录已包含结构变换会话，请使用新的work-dir\n";
        return 2;
    }
    if (!std::filesystem::exists(manifest.cds_lib) ||
        !std::filesystem::exists(manifest.skill_script)) {
        error << "cds.lib或SKILL脚本不存在\n";
        return 2;
    }
    std::error_code directoryError;
    for (const auto* name : {"before", "changes", "expected", "materialization",
                              "after", "reports", "logs", "history", "analysis"}) {
        std::filesystem::create_directories(root / name, directoryError);
        if (directoryError) {
            error << "无法创建会话目录：" << directoryError.message() << '\n';
            return 2;
        }
    }

    BackendPaths paths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.device_policy = root / "analysis/device_policy.tsv";
    paths.structure_only = manifest.validation_scope == "structure_only";
    paths.experimental_dc = manifest.validation_scope == "experimental_dc";
    ProcessVirtuosoBackend backend(manifest.backend, paths, runner);
    const CellViewRef source{manifest.source_library, manifest.source_cell,
                             manifest.source_view, manifest.source_storage, {}};
    const auto scanDirectory = root / "analysis/pdk_scan/inspect";
    const PdkScanOutputs scanOutputs{scanDirectory / "raw_catalog.tsv",
                                     scanDirectory / "pdk_identity.tsv"};
    const auto scanStatus = backend.ScanPdk(source, scanOutputs);
    if (!scanStatus.ok) {
        std::error_code logError;
        if (!scanStatus.log_path.empty() &&
            std::filesystem::exists(scanStatus.log_path, logError) && !logError) {
            std::string archiveMessage;
            archiveScanLog(scanStatus, scanDirectory, archiveMessage);
        }
        error << "PDK扫描失败：" << scanStatus.message
              << "\n日志：" << scanStatus.log_path << '\n';
        return 3;
    }
    if (!archiveScanLog(scanStatus, scanDirectory, message)) {
        error << message << '\n';
        return 3;
    }
    DeviceCatalog catalog;
    std::vector<Diagnostic> scanDiagnostics;
    if (!LoadDeviceCatalogTsv(scanOutputs.raw_catalog_tsv, catalog, scanDiagnostics)) {
        if (message.empty()) {
            message = scanDiagnostics.empty()
            ? "PDK扫描目录读取失败" : scanDiagnostics.front().message;
        }
        error << message << '\n';
        return 4;
    }
    if (!writeScannedDevicePolicy(catalog, paths.device_policy, message)) {
        error << message << '\n';
        return 4;
    }
    const SnapshotOutputs artifacts{root / "before/core_before.scs",
        root / "before/device_catalog.tsv", root / "before/geometry.tsv"};
    const auto status = backend.Snapshot(source, manifest.core_subckt, artifacts);
    if (!status.ok) {
        error << "Virtuoso snapshot失败：" << status.message
              << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    Netlist baseline;
    if (!loadNetlist(artifacts.netlist, baseline, message)) {
        error << message << '\n';
        return 4;
    }
    if (!catalogHash(scanOutputs.raw_catalog_tsv, manifest.catalog_hash, message)) {
        error << message << '\n';
        return 4;
    }
    std::ifstream scanInput(scanOutputs.raw_catalog_tsv, std::ios::binary);
    const std::string scanText((std::istreambuf_iterator<char>(scanInput)),
                               std::istreambuf_iterator<char>());
    if (scanInput.bad() ||
        !writeAtomic(artifacts.catalog, scanText, message) ||
        !writeAtomic(root / "before/validation_scope.txt", manifest.validation_scope + "\n", message)) {
        error << (message.empty() ? "PDK扫描目录保存失败" : message) << '\n';
        return 4;
    }
    if (catalog.Descriptors().empty() ||
        catalog.Descriptors().begin()->second.pdk_version.empty()) {
        error << "PDK器件目录缺少pdk_version，无法建立会话身份\n";
        return 4;
    }
    manifest.pdk_version = catalog.Descriptors().begin()->second.pdk_version;
    manifest.dut_hash = CellViewIdentityHash(manifest.source_library,
        manifest.source_cell, manifest.source_view, manifest.source_storage);
    if (anyBench) {
        manifest.bench_hash = CellViewIdentityHash(manifest.bench_library,
            manifest.bench_cell, manifest.bench_view, manifest.source_storage);
    }
    const auto inventory = ListDirectMos(baseline, manifest.core_subckt, catalog, manifest.validation_scope == "experimental_dc");
    if (!inventory.ok) {
        error << inventory.diagnostics.front().message << '\n';
        return 4;
    }
    if (!WriteMosInventoryTsv(root / "before/mos_inventory.tsv", inventory, message) ||
        !WriteCrossFlavorCandidatesJson(root / "analysis/cross_flavor_candidates.json", inventory, message) ||
        !writeAtomic(root / "analysis/pdk_catalog.json", WritePdkCatalogJson(catalog), message) ||
        !writeAtomic(root / "session.conf", manifestText(manifest), message)) {
        error << message << '\n';
        return 2;
    }
    output << "会话已创建：" << root.string() << '\n';
    printInventory(output, inventory);
    output << "原始网表：" << artifacts.netlist.string() << '\n';
    return 0;
}

int listCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error)
{
    std::string message;
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) {
        error << message << '\n';
        return 2;
    }
    Netlist baseline;
    Netlist current;
    DeviceCatalog catalog;
    std::vector<TransformRequest> requests;
    ReplayResult replay;
    if (!buildCurrent(root, manifest, {baseline, catalog, requests, current, replay},
                      message)) {
        error << message << '\n';
        return 4;
    }
    const auto inventory = ListDirectMos(current, manifest.core_subckt, catalog, manifest.validation_scope == "experimental_dc");
    if (!inventory.ok) {
        error << inventory.diagnostics.front().message << '\n';
        return 4;
    }
    output << "已确认操作: " << requests.size() << '\n';
    for (const auto& request : requests) {
        output << "  " << request.operation_id << " -> " << request.target.instance;
        if (needsBiasSolve(request)) {
            output << "（待generate自动求解VBIAS）";
        }
        output << '\n';
    }
    printInventory(output, inventory);
    return 0;
}

int confirmCommand(const std::filesystem::path& root, const Options& options,
                   std::ostream& output, std::ostream& error)
{
    std::string message;
    std::string operationPath;
    if (!required(options, "operation", operationPath, message)) {
        error << message << '\n';
        return 2;
    }
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) {
        error << message << '\n';
        return 2;
    }
    Netlist baseline;
    DeviceCatalog catalog;
    if (!loadNetlist(root / "before/core_before.scs", baseline, message) ||
        !loadCatalog(root, catalog, message, manifest.validation_scope == "experimental_dc")) {
        error << message << '\n';
        return 4;
    }
    std::vector<TransformRequest> requests;
    ChangeSet validated;
    if (!loadChangeRequests(root, manifest, requests, validated, message)) {
        error << message << '\n';
        return 4;
    }
    auto parsed = ParseTransformRequest(operationPath, manifest.core_subckt);
    if (!parsed.ok) {
        error << parsed.diagnostics.front().message << '\n';
        return 2;
    }
    if (!prepareScopeRequest(parsed.request, manifest, message)) {
        error << message << '\n';
        return 4;
    }
    Diagnostic diagnostic;
    if (!validated.Confirm(parsed.request, diagnostic)) {
        error << diagnostic.message << '\n';
        return 4;
    }
    // 重放校验只覆盖可重放操作；未求解的FixedBias Cascode推迟到generate求解后校验。
    ChangeSet replayable;
    if (!confirmReplayable(requests, replayable, message)) {
        error << message << '\n';
        return 4;
    }
    if (!needsBiasSolve(parsed.request)) {
        if (!replayable.Confirm(parsed.request, diagnostic)) {
            error << diagnostic.message << '\n';
            return 4;
        }
    }
    Netlist current;
    const auto replay = replayable.Generate(baseline, current, catalog);
    if (!replay.ok) {
        error << (replay.diagnostics.empty() ? "变换校验失败" :
                  replay.diagnostics.front().message) << '\n';
        return 4;
    }
    std::ostringstream changeNumber;
    changeNumber << std::setw(4) << std::setfill('0') << validated.Size();
    const auto destination = root / "changes" / (changeNumber.str() + ".conf");
    std::ifstream source(operationPath, std::ios::binary);
    const std::string contents((std::istreambuf_iterator<char>(source)),
                               std::istreambuf_iterator<char>());
    if (!source.good() && !source.eof()) {
        error << "无法读取操作文件\n";
        return 2;
    }
    if (!invalidateValidation(root, message) || !writeAtomic(destination, contents, message)) {
        error << message << '\n';
        return 2;
    }
    output << "已确认操作: " << parsed.request.operation_id
           << "，当前操作数=" << validated.Size() << '\n';
    return 0;
}

bool moveToHistory(const std::filesystem::path& root,
                   const std::filesystem::path& source,
                   const std::string& reason, std::string& message)
{
    std::error_code error;
    std::filesystem::create_directories(root / "history", error);
    if (error) {
        message = error.message();
        return false;
    }
    std::size_t suffix = 1;
    std::filesystem::path target;
    do {
        target = root / "history" /
            (reason + "_" + std::to_string(suffix++) + "_" + source.filename().string());
    } while (std::filesystem::exists(target));
    std::filesystem::rename(source, target, error);
    if (error) {
        message = "无法移动操作到history：" + error.message();
        return false;
    }
    return true;
}

int undoCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error)
{
    auto files = changeFiles(root);
    if (files.empty()) {
        error << "没有可撤销的操作\n";
        return 4;
    }
    std::string message;
    if (!invalidateValidation(root, message) || !moveToHistory(root, files.back(), "undo", message)) {
        error << message << '\n';
        return 2;
    }
    output << "已撤销最后一次修改，剩余操作数=" << (files.size() - 1) << '\n';
    return 0;
}

int freshCommand(const std::filesystem::path& root, std::ostream& output,
                 std::ostream& error)
{
    const auto files = changeFiles(root);
    std::string message;
    if (!invalidateValidation(root, message)) {
        error << message << '\n';
        return 2;
    }
    for (const auto& file : files) {
        if (!moveToHistory(root, file, "fresh", message)) {
            error << message << '\n';
            return 2;
        }
    }
    output << "已恢复到初始逻辑结构，活动操作数=0\n";
    return 0;
}

bool writeValidationReport(const std::filesystem::path& root,
                           const std::string& body, std::string& message)
{
    return writeAtomic(root / "reports/validation.txt", body, message);
}

int generateCommand(const std::filesystem::path& root, const Options& options, std::ostream& output,
                    std::ostream& error, ProcessRunner& runner)
{
    std::string message;
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) {
        error << message << '\n';
        return 2;
    }
    Netlist baseline;
    DeviceCatalog catalog;
    if (!loadNetlist(root / "before/core_before.scs", baseline, message) ||
        !loadCatalog(root, catalog, message, manifest.validation_scope == "experimental_dc")) {
        error << message << '\n';
        return 4;
    }
    std::vector<TransformRequest> requests;
    ChangeSet validated;
    if (!loadChangeRequests(root, manifest, requests, validated, message)) {
        error << message << '\n';
        return 4;
    }
    if (requests.empty()) {
        error << "Change Set为空，不能生成派生电路\n";
        return 4;
    }
    const bool structureOnly = manifest.validation_scope == "structure_only";
    const bool experimentalDc = manifest.validation_scope == "experimental_dc";
    if (!structureOnly && (manifest.bench_library.empty() || manifest.bench_cell.empty() ||
        manifest.bench_view.empty() || manifest.bench_hash.empty())) {
        error << "generate缺少真实Bench L/C/V：发现会话只能查看MOS清单，"
                 "请取得Case映射后重新inspect\n";
        return 4;
    }
    if (std::any_of(requests.begin(), requests.end(), needsBiasSolve) &&
        (manifest.vbias_vhigh_net.empty() || manifest.vbias_vlow_net.empty())) {
        error << "Cascode求解缺少VBIAS高低轨网：请取得Case轨网后重新inspect\n";
        return 4;
    }
    std::optional<double> maxBranchCurrentError;
    std::optional<double> maxVbiasCurrent;
    const bool hasBiasOperation =
        std::any_of(requests.begin(), requests.end(), needsBiasSolve);
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            error << "电流上限选填；填写时 --max-branch-current-error 与"
                     " --max-vbias-current 必须成对提供且为正数\n";
            return 4;
        }
        maxBranchCurrentError = branch;
        maxVbiasCurrent = bias;
    }
    const bool currentLimitsApplied = !experimentalDc && hasBiasOperation &&
        maxBranchCurrentError.has_value() && maxVbiasCurrent.has_value();

    BackendPaths paths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.device_policy = root / "analysis/device_policy.tsv";
    paths.structure_only = structureOnly;
    paths.experimental_dc = experimentalDc;
    ProcessVirtuosoBackend backend(manifest.backend, paths, runner);
    const CellViewRef source{manifest.source_library, manifest.source_cell,
                             manifest.source_view, manifest.source_storage, {}};
    const CellViewRef bench{manifest.bench_library, manifest.bench_cell,
                            manifest.bench_view, manifest.source_storage, {}};

    // ---- 1) PDK重扫：版本和内容身份均一致后才允许求解 ----
    std::filesystem::path scanDirectory;
    for (unsigned number = 1; number <= 9999; ++number) {
        std::ostringstream name;
        name << "run_" << std::setw(4) << std::setfill('0') << number;
        const auto candidate = root / "analysis/pdk_scan" / name.str();
        std::error_code directoryError;
        if (std::filesystem::create_directory(candidate, directoryError)) {
            scanDirectory = candidate;
            break;
        }
        if (directoryError &&
            directoryError != std::errc::file_exists) {
            error << "无法创建PDK扫描归档目录：" << directoryError.message() << '\n';
            return 2;
        }
    }
    if (scanDirectory.empty()) {
        error << "PDK扫描归档目录编号已用尽\n";
        return 2;
    }
    const PdkScanOutputs scanOutputs{scanDirectory / "raw_catalog.tsv",
                                     scanDirectory / "pdk_identity.tsv"};
    auto status = backend.ScanPdk(source, scanOutputs);
    if (!status.ok) {
        std::error_code logError;
        if (!status.log_path.empty() &&
            std::filesystem::exists(status.log_path, logError) && !logError) {
            std::string archiveMessage;
            archiveScanLog(status, scanDirectory, archiveMessage);
        }
        error << "PDK重扫失败：" << status.message << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    if (!archiveScanLog(status, scanDirectory, message)) {
        error << message << '\n';
        return 3;
    }
    DeviceCatalog scanned;
    {
        std::vector<Diagnostic> diagnostics;
        if (!LoadDeviceCatalogTsv(scanOutputs.raw_catalog_tsv, scanned, diagnostics)) {
            error << "PDK重扫目录读取失败：" <<
                (diagnostics.empty() ? std::string("unknown") : diagnostics.front().message)
                  << '\n';
            return 4;
        }
    }
if (scanned.Descriptors().empty() ||
        scanned.Descriptors().begin()->second.pdk_version != manifest.pdk_version) {
        error << "PDK版本与建会话时不一致（期望 " << manifest.pdk_version
              << "），拒绝继续生成\n";
        return 4;
    }
    std::string beforeHash;
    std::string scannedHash;
    if (!catalogHash(root / "before/device_catalog.tsv", beforeHash, message) ||
        !catalogHash(scanOutputs.raw_catalog_tsv, scannedHash, message)) {
        error << message << '\n';
        return 4;
    }
    if (beforeHash != manifest.catalog_hash || scannedHash != manifest.catalog_hash) {
        error << "PDK目录内容与建会话时不一致，请重新inspect和confirm\n";
        return 4;
    }
    catalog = std::move(scanned);
    const auto resistorTrials = optional(options, "experimental-resistor-trials");
    if (!resistorTrials.empty() && (!experimentalDc || !hasBiasOperation ||
        !applyResistorTrials(resistorTrials, catalog, output, message,
            optional(options,"experimental-resistor-auto") == "true"))) {
        error << "参考电阻试点仅适用于experimental_dc Cascode：" << message << '\n';
        return 4;
    }
    const bool nativeParameterTrials = std::any_of(catalog.Descriptors().begin(),
        catalog.Descriptors().end(), [](const auto& entry) { return entry.second.native_parameter_trials; });
    backend.UseOperatingPointCatalog(scanOutputs.raw_catalog_tsv);
    if (!writeScannedDevicePolicy(catalog, paths.device_policy, message)) {
        error << message << '\n';
        return 4;
    }

    // ---- 2) 基线直流工作点：身份一致才复用，否则重跑 ----
    OperatingPointSnapshot baselineOp;
    const AnalysisIdentity nominalIdentity{manifest.dut_hash, manifest.bench_hash,
        manifest.pdk_version, manifest.nominal_corner,
        ComputeNetlistTopologyHash(baseline), ComputeNetlistParameterHash(baseline),
        experimentalDc ? "st-dc-solver-v3-experimental_dc" : "st-dc-solver-v2-intrinsic"};
    if (!structureOnly) {
    const auto baselineDir = root / "analysis/baseline_op";
    bool baselineReused = false;
    {
        std::vector<Diagnostic> diagnostics;
        if (LoadOperatingPointTsv(baselineDir, baselineOp, diagnostics) &&
            IsReusable(baselineOp, nominalIdentity) &&
            std::all_of(requests.begin(), requests.end(), [&](const auto& request) {
                return !needsBiasSolve(request) ||
                    baselineOp.mos.count(request.target.instance) != 0;
            })) {
            baselineReused = true;
        }
    }
    if (!baselineReused) {
        const OperatingPointOutputs outputs{baselineDir / "identity.tsv",
                                            baselineDir / "mos.tsv"};
        status = backend.RunOperatingPoint(source, bench, nominalIdentity, outputs);
        if (!status.ok) {
            error << "基线直流工作点失败：" << status.message
                  << "\n日志：" << status.log_path << '\n';
            return 3;
        }
        std::vector<Diagnostic> diagnostics;
        if (!LoadOperatingPointTsv(baselineDir, baselineOp, diagnostics) ||
            !IsReusable(baselineOp, nominalIdentity)) {
            error << "基线直流工作点身份与声明不一致\n";
            return 4;
        }
    }
    {
        std::string json = std::string("{\"validation_scope\":\"") + manifest.validation_scope +
            "\",\"dut_hash\":\"" + manifest.dut_hash +
            "\",\"bench_hash\":\"" + manifest.bench_hash + "\",\"pdk_version\":\"" +
            jsonEscape(manifest.pdk_version) + "\",\"corner\":\"" +
            jsonEscape(manifest.nominal_corner) + "\",\"total_supply_current\":" +
            (baselineOp.total_supply_current ? formatNumber(*baselineOp.total_supply_current) : "null") + ",\"reused\":" +
            (baselineReused ? "true" : "false") + "}\n";
        if (!writeAtomic(root / "analysis/baseline_op.json", json, message)) {
            error << message << '\n';
            return 2;
        }
    }

    }
    // ---- 3) 逐操作自动求解VBIAS：求解轨迹与已解析参数先落盘，再决定继续与否 ----
    RootGeometry geometry;
    std::vector<Diagnostic> geometryDiagnostics;
    if (!LoadRootGeometryTsv(root / "before/geometry.tsv", geometry,
                             geometryDiagnostics)) {
        error << geometryDiagnostics.front().message << '\n';
        return 4;
    }
    BackendDcEvaluationHost evaluationHost(
        backend, {source, bench},
        {baseline, catalog, geometry, manifest.core_subckt,
         manifest.variant_library + "__STAGING",
         manifest.variant_cell + "__DC", manifest.skill_script,
         root / "analysis/candidates", experimentalDc},
        output);
    std::vector<TransformRequest> solvedRequests;
    std::vector<ElectricalConstraintRequest> electricalChecks;
    std::vector<std::string> traceLines;
    std::string resolvedEntries;
    bool anyFailed = false;
    std::string failureMessage;
    std::string backendAbortedBy;
    std::string cumulativeAbortedBy;
    Netlist cumulative = baseline;
    ChangeSet cumulativeChanges;
    ReplayResult cumulativeReplay;
    evaluationHost.SetPreceding(cumulative, cumulativeChanges, cumulativeReplay);
    if (hasBiasOperation) {
        output << "VBIAS_CUMULATIVE=true" << std::endl;
    }
    // PVT 总结论：配置了 Corner 列表、且所有 FixedBias 求解操作复验全过才为 true。
    const bool pvtConfigured = !structureOnly && !(experimentalDc && hasBiasOperation) && !splitCommaList(manifest.pvt_corners).empty();
    for (auto request : requests) {
        std::string statusText = "not_required";
        std::string selection = "null";
        std::string sizing = "null";
        std::string metrics = "null";
        std::string diagnosticsJson = "[]";
        std::string pvtReadyJson = "false";
        std::string experimentalPvtReadyJson = "false";
        std::string pvtJson = "[]";
        if (!backendAbortedBy.empty() || !cumulativeAbortedBy.empty()) {
            const auto& abortedBy = backendAbortedBy.empty() ? cumulativeAbortedBy : backendAbortedBy;
            statusText = backendAbortedBy.empty() ? "skipped_cumulative_failure" : "skipped_backend_failure";
            diagnosticsJson = "[\"未评估：前序操作 " + jsonEscape(abortedBy) +
                " 未能完成累积选择\"]";
            output << "VBIAS_OPERATION_SKIPPED operation=" << request.operation_id
                   << " cause=" << abortedBy << std::endl;
        } else if (needsBiasSolve(request)) {
            output << "VBIAS_OPERATION=START operation=" << request.operation_id
                   << " target=" << request.target.instance
                   << " retained_groups=" << electricalChecks.size() << std::endl;
            auto* payload = std::get_if<CascodeTransformRequest>(&request.payload);
            const Subckt* baselineRoot = cumulative.find(manifest.core_subckt);
            const Instance* target = baselineRoot == nullptr
                ? nullptr : baselineRoot->find(request.target.instance);
            const DeviceDescriptor* descriptor = target == nullptr
                ? nullptr : catalog.Find(target->model);
            AutoBiasTemplateRequest templateRequest;
            templateRequest.experimental_dc = experimentalDc;
            bool inputsReady = target != nullptr && descriptor != nullptr &&
                (descriptor->kind == DeviceKind::MosN ||
                 descriptor->kind == DeviceKind::MosP);
            if (inputsReady) {
                templateRequest.operation_id = request.operation_id;
                templateRequest.polarity = descriptor->kind;
                templateRequest.voltage_domain = payload->voltage_domain;
                templateRequest.vhigh_net = manifest.vbias_vhigh_net;
                templateRequest.vlow_net = manifest.vbias_vlow_net;
                templateRequest.control_master = target->model;
                templateRequest.cascode_master = payload->new_master.empty()
                    ? target->model : payload->new_master;
                inputsReady =
                    terminalNet(catalog, *target, TerminalRole::Source,
                                templateRequest.original_source_net, message) &&
                    terminalNet(catalog, *target, TerminalRole::Gate,
                                templateRequest.control_gate_net, message);
                // The experimental runner does not specify a separate Bulk.
                // Preserve the proven original body connection for this exact
                // same-master, non-isolated NMOS; also retain it for final replay.
                const bool preserveBulk =
                    experimentalDc &&
                    request.type == TransformType::SameTypeCascode &&
                    descriptor->kind == DeviceKind::MosN &&
                    descriptor->bulk_rule_complete && !descriptor->isolated_well &&
                    templateRequest.cascode_master == target->model &&
                    payload->nmos_bulk_net.empty();
                const auto logBulkInherited = [&inputsReady, &output, &request,
                                               &payload] {
                    if (inputsReady) {
                        output << "EXPERIMENT_BULK_INHERITED operation=" << request.operation_id
                               << " target=" << request.target.instance
                               << " bulk=" << payload->nmos_bulk_net << '\n';
                    }
                };
                if (preserveBulk) {
                    inputsReady = terminalNet(catalog, *target, TerminalRole::Bulk,
                                               payload->nmos_bulk_net, message) &&
                                  !payload->nmos_bulk_net.empty();
                    logBulkInherited();
                }
            }
            if (!inputsReady) {
                anyFailed = true;
                statusText = "no_solution";
                diagnosticsJson = "[\"目标实例不存在、不是MOS或端网无法解析\"]";
                const auto recordInputFailure = [&failureMessage, &request] {
                    if (failureMessage.empty()) {
                        failureMessage = "操作 " + request.operation_id +
                            " 的目标实例无法建立求解输入";
                    }
                };
                recordInputFailure();
            } else {
                AutoBiasSolveRequest solveRequest;
                solveRequest.baseline = cumulative;
                solveRequest.preceding_checks = electricalChecks;
                solveRequest.root_subckt = manifest.core_subckt;
                solveRequest.target_instance = request.target.instance;
                solveRequest.template_request = templateRequest;
                solveRequest.baseline_op = baselineOp;
                solveRequest.nominal_identity = nominalIdentity;
                solveRequest.nmos_bulk_net = payload->nmos_bulk_net;
                solveRequest.tie_isolated_pmos_to_source =
                    payload->tie_isolated_pmos_to_source;
                if (!experimentalDc) {
                    solveRequest.pvt_corners = splitCommaList(manifest.pvt_corners);
                }
                solveRequest.max_branch_current_error = maxBranchCurrentError;
                solveRequest.max_vbias_current = maxVbiasCurrent;
                auto solved = SolveAutoBias(solveRequest, catalog, evaluationHost);
                if (solved.evaluation_failed) {
                    backendAbortedBy = request.operation_id;
                    output << "VBIAS_BATCH_STOPPED=true operation=" << request.operation_id
                           << " reason=evaluation_failed" << std::endl;
                }
                traceLines.insert(traceLines.end(), solved.trace_lines.begin(),
                                  solved.trace_lines.end());
                sizing = sizingJson(solved.sizing);
                metrics = metricsJson(solved.metrics);
                selection = "{\"candidate\":" + std::to_string(solved.selected_candidate) +
                    ",\"evaluations\":" + std::to_string(solved.nominal_evaluations) +
                    ",\"dc_feasible\":" + (solved.ok ? "true" : "false") +
                    ",\"best_effort\":" + (solved.best_effort ? "true" : "false") +
                    ",\"failed_constraints\":[";
                const auto setFailureIfEmpty = [&failureMessage, &request](const std::string& verb) {
                    if (failureMessage.empty()) {
                        failureMessage = "操作 " + request.operation_id + verb;
                    }
                };
                appendJsonList(selection, solved.failed_constraints);
                selection += "]}";
                if (!solved.ok && !(experimentalDc && solved.best_effort)) {
                    anyFailed = true;
                    statusText = solved.evaluation_failed ? "evaluation_failed" :
                        solved.nominal_evaluations == 0 && solved.searched_device_combinations > 0
                        ? "construction_failed" : experimentalDc ? "no_valid_dc_candidate" : "no_solution";
                    std::vector<std::string> messages;
                    messages.reserve(solved.diagnostics.size());
                    for (const auto& diagnostic : solved.diagnostics) {
                        messages.push_back(diagnostic.message);
                    }
                    diagnosticsJson = "[";
                    appendJsonList(diagnosticsJson, messages);
                    diagnosticsJson += ']';
                    setFailureIfEmpty(" 自动VBIAS处理失败：" +
                        (solved.diagnostics.empty() ? std::string("unknown")
                                                    : solved.diagnostics.front().message));
                } else {
                    VbiasTemplateState vbiasState;
                    vbiasState.any_failed = &anyFailed;
                    vbiasState.status_text = &statusText;
                    vbiasState.diagnostics_json = &diagnosticsJson;
                    vbiasState.pvt_json = &pvtJson;
                    vbiasState.pvt_ready_json = &pvtReadyJson;
                    vbiasState.experimental_pvt_ready_json = &experimentalPvtReadyJson;
                    vbiasState.electrical_checks = &electricalChecks;
                    vbiasState.payload = payload;
                    vbiasState.output = &output;
                    vbiasState.failure_message = &failureMessage;
                    vbiasState.manifest = &manifest;
                    vbiasState.request = &request;
                    vbiasState.experimental_dc = experimentalDc;
                    applyBuiltTemplate(solved, templateRequest, catalog, vbiasState);
                }
                output << "VBIAS_OPERATION=END operation=" << request.operation_id
                       << " result=" << statusText << " evaluations="
                       << solved.nominal_evaluations << std::endl;
            }
        }
        // Replay only selected parameters, never the last attempted point. The
        // next host clones the original OA and materializes this entire prefix.
        if (!anyFailed && backendAbortedBy.empty() && cumulativeAbortedBy.empty()) {
            Diagnostic diagnostic;
            if (!cumulativeChanges.Confirm(request, diagnostic)) {
                anyFailed = true;
                failureMessage = diagnostic.message;
            } else {
                Netlist next;
                cumulativeReplay = cumulativeChanges.Generate(baseline, next, catalog);
                if (!cumulativeReplay.ok) {
                    anyFailed = true;
                    failureMessage = cumulativeReplay.diagnostics.empty()
                        ? "累积电路组装失败" : cumulativeReplay.diagnostics.front().message;
                } else {
                    cumulative = std::move(next);
                    // Bias instance names survive packaging. Pin roles to their
                    // owning group before another same-polarity group is added.
                    pinBiasRoles(cumulativeReplay, cumulativeChanges, electricalChecks);
                    evaluationHost.SetPreceding(cumulative, cumulativeChanges, cumulativeReplay);
                }
            }
            if (anyFailed) {
                statusText = "construction_failed";
                diagnosticsJson = "[\"" + jsonEscape(failureMessage) + "\"]";
            }
        }
        if (anyFailed && backendAbortedBy.empty() && cumulativeAbortedBy.empty()) {
            cumulativeAbortedBy = request.operation_id;
            output << "VBIAS_BATCH_STOPPED=true operation=" << request.operation_id
                   << " reason=" << statusText << std::endl;
        }
        if (!resolvedEntries.empty()) {
            resolvedEntries += ',';
        }
        resolvedEntries += std::string("{\"operation\":\"") +
            jsonEscape(request.operation_id) + "\",\"type\":\"" +
            operationTypeName(request.type) + "\",\"status\":\"" + statusText +
            "\",\"pvt_ready\":" + pvtReadyJson + ",\"experimental_pvt_ready\":" + experimentalPvtReadyJson + ",\"pvt\":" + pvtJson +
            ",\"selection\":" + selection + ",\"sizing\":" + sizing + ",\"metrics\":" + metrics +
            ",\"diagnostics\":" + diagnosticsJson + '}';
        solvedRequests.push_back(std::move(request));
    }
    {
        std::string trace;
        for (const auto& line : traceLines) {
            trace += line;
            trace += '\n';
        }
        if (!writeAtomic(root / "analysis/solver_trace.jsonl", trace, message) ||
            !writeAtomic(root / "analysis/resolved_parameters.json",
                         std::string("{\"validation_scope\":\"") + manifest.validation_scope +
                         "\",\"native_parameter_trials\":" + (nativeParameterTrials ? "true" : "false") +
                         ",\"reliability_verified\":false,\"operations\":[" + resolvedEntries + "]}\n",
                         message)) {
            error << message << '\n';
            return 2;
        }
    }
    if (anyFailed) {
        std::ostringstream report;
        report << "ok=false\n"
               << "validation_scope=" << manifest.validation_scope << '\n'
               << "experimental_dc_ready=false\n"
               << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
               << "reliability_verified=false\n"
               << "published=false\n"
               << "structural_ready=false\n"
               << "nominal_dc_ready=false\n"
               << "pvt_ready=false\n"
               << "parameters_quantized=false\n"
               << "ready_for_sizing=false\n"
               << "stage=solve\n"
               << "message=" << failureMessage << '\n'
               << "solver_trace=" << (root / "analysis/solver_trace.jsonl").string() << '\n'
               << "resolved_parameters="
               << (root / "analysis/resolved_parameters.json").string() << '\n';
        if (!writeValidationReport(root, report.str(), message)) {
            error << message << '\n';
            return 2;
        }
        error << "自动VBIAS求解失败：" << failureMessage
              << "\n已保留求解轨迹与逐项原因，未写OA计划、未clone、未发布\n";
        return 4;
    }

    // ---- 4) 全部求解成功后重放、封装、出OA计划 ----
    ChangeSet solvedChanges;
    for (const auto& request : solvedRequests) {
        Diagnostic diagnostic;
        if (!solvedChanges.Confirm(request, diagnostic)) {
            error << diagnostic.message << '\n';
            return 4;
        }
    }
    Netlist expected;
    ReplayResult replay = solvedChanges.Generate(baseline, expected, catalog);
    if (!replay.ok) {
        error << (replay.diagnostics.empty() ? "求解后重放失败" :
                  replay.diagnostics.front().message) << '\n';
        return 4;
    }
    // The existing per-generate scan directory already supplies a unique run
    // number. Use it for the final experimental parent AND generated children,
    // so a previous failed materialization cannot occupy this attempt's names.
    const std::string generationRun = experimentalDc ? scanDirectory.filename().string() : "";
    const std::string generationCell = manifest.variant_cell +
        (experimentalDc ? "__GEN_" + generationRun : "");
    PackageTopologyInput packagedInput;
    packagedInput.baseline = &baseline;
    packagedInput.flatVariant = &expected;
    packagedInput.coreSubckt = manifest.core_subckt;
    packagedInput.changes = &solvedChanges;
    packagedInput.replay = &replay;
    packagedInput.generated = {generationCell, manifest.variant_library + "__STAGING"};
    const auto packaged = PackageTopologyVariant(packagedInput);
    if (!packaged.ok()) {
        error << packaged.diagnostics.front().message << '\n';
        return 4;
    }
    // 最终电路已封装成父层 wrapper + 功能/VBIAS 子 Cell。把求解阶段的
    // 叶实例角色绑定到对应 wrapper，供最终 Spectre OP 层级名精确解析。
    for (auto& check : electricalChecks) {
        bool actualContainerFound = false;
        bool biasContainerFound = false;
        for (const auto& package : packaged.packages) {
            if (std::find(package.operation_ids.begin(), package.operation_ids.end(),
                          check.operation_id) == package.operation_ids.end()) {
                continue;
            }
            const auto hasMember = [&package](const std::string& name) {
                return std::find(package.member_instances.begin(),
                                 package.member_instances.end(), name) !=
                    package.member_instances.end();
            };
            if (hasMember(check.actual_control.leaf_name) &&
                hasMember(check.actual_cascode.leaf_name)) {
                check.actual_control.container_instance =
                    package.parent_instance_name;
                check.actual_cascode.container_instance =
                    package.parent_instance_name;
                actualContainerFound = true;
            }
            if (hasMember(check.control_replica.leaf_name) &&
                hasMember(check.bias_resistor.leaf_name)) {
                check.control_replica.container_instance = package.parent_instance_name;
                check.bias_resistor.container_instance = package.parent_instance_name;
                biasContainerFound = true;
            }
        }
        if (!actualContainerFound || !biasContainerFound) {
            error << "操作 " << check.operation_id
                  << " 无法把最终电气校验角色绑定到功能/VBIAS封装实例\n";
            return 4;
        }
    }
    std::vector<ExpectedResistor> sourceResistorChecks;
    const Subckt* flatRoot = expected.find(manifest.core_subckt);
    for (std::size_t index = 0; index < solvedRequests.size(); ++index) {
        if (structureOnly || solvedRequests[index].type != TransformType::AddSourceResistor) {
            continue;
        }
        bool found = false;
        for (const auto& name : replay.outcomes[index].addedInstances) {
            const Instance* instance = flatRoot == nullptr ? nullptr : flatRoot->find(name);
            const DeviceDescriptor* descriptor = instance == nullptr
                ? nullptr : catalog.Find(instance->model);
            if (descriptor == nullptr || descriptor->kind != DeviceKind::Resistor) {
                continue;
            }
            for (const auto& package : packaged.packages) {
                if (std::find(package.operation_ids.begin(), package.operation_ids.end(),
                              solvedRequests[index].operation_id) ==
                        package.operation_ids.end() ||
                    std::find(package.member_instances.begin(),
                              package.member_instances.end(), name) ==
                        package.member_instances.end()) {
                    continue;
                }
                sourceResistorChecks.push_back({solvedRequests[index].operation_id,
                    package.parent_instance_name, name, instance->model, experimentalDc});
                found = true;
                break;
            }
        }
        if (!found) {
            error << "操作 " << solvedRequests[index].operation_id
                  << " 无法绑定最终Source电阻实例的应力门禁\n";
            return 4;
        }
    }
    expected = packaged.netlist;
    if (!writeAtomic(root / "expected/core_expected.scs", emitSpectre(expected), message)) {
        error << message << '\n';
        return 2;
    }

    const CellViewRef staging{manifest.variant_library + "__STAGING",
        generationCell + "__STAGING", "schematic", manifest.source_storage, {}};
    const CellViewRef target{manifest.variant_library, manifest.variant_cell,
                             "schematic", manifest.source_storage, {}};
    const PreviewIdentity preview{manifest.variant_id, "initial", "standalone-v2-packaged"};
    auto context = BuildRootOaContext(
        baseline, expected, manifest.core_subckt, geometry, {source, staging, preview});
    if (!context.ok) {
        error << context.diagnostics.front().message << '\n';
        return 4;
    }
    context.context.structure_only = structureOnly;
    const auto builtPlan = BuildPackagedOaMaterializationPlan(
        baseline, packaged, catalog, context.context, staging.library);
    if (!builtPlan.ok()) {
        error << builtPlan.diagnostics.front().message << '\n';
        return 4;
    }

    GenerationRequest request;
    request.plan = builtPlan.plan;
    request.baseline = baseline;
    request.expected_variant = expected;
    request.root_subckt = manifest.core_subckt;
    request.work_dir = root.string();
    request.plan_path = (root / "materialization/plan.json").string();
    request.skill_script_path = manifest.skill_script.string();
    request.publish_clone_map.push_back({staging, target, "/"});
    for (const auto& cell : request.plan.generated_cells) {
        auto finalSchematic = cell.schematic;
        auto finalSymbol = cell.symbol;
        finalSchematic.library = target.library;
        finalSymbol.library = target.library;
        request.publish_clone_map.push_back({cell.schematic, finalSchematic,
                                            "@" + cell.package_id + "/schematic"});
        request.publish_clone_map.push_back({cell.symbol, finalSymbol,
                                            "@" + cell.package_id + "/symbol"});
    }
    request.parameter_groups = replay.parameter_groups;
    request.iq_delta = replay.iq_delta;
    // 名义DC检查：对staging变体验明工作点身份，dut_hash必须是staging的哈希。
    request.run_nominal_dc = !structureOnly;
    request.structure_only = structureOnly;
    request.experimental_dc = experimentalDc;
    request.bench = bench;
    request.nominal_corner = manifest.nominal_corner;
    request.nominal_identity = AnalysisIdentity{
        CellViewIdentityHash(staging.library, staging.cell, staging.view,
                             staging.storage_path),
        manifest.bench_hash, manifest.pdk_version, manifest.nominal_corner,
        ComputeNetlistTopologyHash(expected), ComputeNetlistParameterHash(expected),
        experimentalDc ? "st-dc-solver-v3-experimental_dc" : "st-dc-solver-v2-intrinsic"};
    request.nominal_op_dir = (root / "analysis/variant_op").string();
    request.electrical_checks = electricalChecks;
    request.retain_electrical_candidate = experimentalDc && !electricalChecks.empty();
    request.resistor_checks = sourceResistorChecks;
    if (experimentalDc) {
        for (const auto& package : packaged.packages) {
            for (const auto& instance : package.circuit.instances) {
                const auto* descriptor = catalog.Find(instance.model);
                if (descriptor == nullptr) {
                    continue;
                }
                const auto prefix = package.parent_instance_name + "/" + instance.name + "/";
                if (descriptor->native_parameter_trials) {
                    request.unverified_constraints.push_back(prefix + "parameter_domain");
                }
                if (descriptor->voltage_domain.empty() && descriptor->allowed_voltage_domains.empty()) {
                    request.unverified_constraints.push_back(prefix + "voltage_domain");
                }
                if (!isMosKind(descriptor->kind)) {
                    continue;
                }
                request.experimental_mos_checks.push_back({package.parent_instance_name,
                    instance.name, descriptor->limits, descriptor->reliability_complete});
            }
        }
    }
    request.parameters_quantized = !structureOnly && !experimentalDc;
    // 候选阶段的PVT用于提前淘汰/诊断，但最终门禁必须重新仿真同一个
    // staging CellView；不能把候选结论直接当作最终电路结论。
    request.pvt_configured = pvtConfigured;
    for (const auto& corner : (pvtConfigured ? splitCommaList(manifest.pvt_corners) : std::vector<std::string>{})) {
        if (corner == manifest.nominal_corner) {
            continue;
        }
        auto identity = request.nominal_identity;
        identity.corner = corner;
        request.pvt_checks.push_back({
            corner, identity,
            (root / "analysis/variant_pvt" / corner).string()});
    }

    TopologyVariantMaterializer materializer;
    if (experimentalDc) {
        output << "FINAL_OA_GENERATION=" << generationRun << '\n'
               << "FINAL_OA_CELL=" << staging.library << '/' << staging.cell << '/' << staging.view << '\n';
    }
    const auto generated = materializer.Generate(request, backend);

    std::ostringstream report;
    report << "ok=" << (generated.ok ? "true" : "false") << '\n'
           << "structural_ready=" << (generated.structural_ready ? "true" : "false") << '\n'
           << "nominal_dc_ready=" << (generated.nominal_dc_ready ? "true" : "false") << '\n'
           << "pvt_ready=" << (generated.pvt_ready ? "true" : "false") << '\n'
           << "parameters_quantized=" << (generated.parameters_quantized ? "true" : "false")
           << '\n'
           << "ready_for_sizing=" << (generated.ready_for_sizing ? "true" : "false") << '\n'
           << "stage=" << stageName(generated.stage) << '\n'
           << "generation_run=" << generationRun << '\n'
           << "message=" << generated.message << '\n'
           << "source=" << manifest.source_library << '/' << manifest.source_cell << '/'
           << manifest.source_view << '\n'
           << "target=" << generated.target.library << '/' << generated.target.cell << '/' << generated.target.view << '\n'
           << "baseline_netlist=" << (root / "before/core_before.scs").string() << '\n'
           << "expected_netlist=" << (root / "expected/core_expected.scs").string() << '\n'
           << "roundtrip_netlist=" << (root / "after/core_roundtrip.scs").string() << '\n'
           << "source_roundtrip_netlist=" << (root / "after/source_roundtrip.scs").string() << '\n'
           << "plan=" << request.plan_path << '\n'
           << "generated_cells=" << packaged.packages.size() << '\n'
           << "topology_hash=" << generated.topology_hash << '\n'
           << "vbias_branch_current=" << generated.iq_delta << '\n'
           << "validation_scope=" << manifest.validation_scope << '\n'
           << "experimental_dc_ready=" << (generated.experimental_dc_ready ? "true" : "false") << '\n'
           << "optimization_candidate_ready=" << (generated.optimization_candidate_ready ? "true" : "false") << '\n'
           << "experimental_pvt_ready=" << (generated.experimental_pvt_ready ? "true" : "false") << '\n'
           << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
           << "reliability_verified=false\n"
           << "published=" << (generated.ok && !experimentalDc ? "true" : "false") << '\n'
           << "performance_verified=false\n"
           << "current_limits_applied=" << (currentLimitsApplied ? "true" : "false") << '\n'
           << "max_branch_current_error=" << manifest.max_branch_current_error << '\n'
           << "max_vbias_current=" << manifest.max_vbias_current << '\n'
           << "solver_trace=" << (root / "analysis/solver_trace.jsonl").string() << '\n'
           << "resolved_parameters="
           << (root / "analysis/resolved_parameters.json").string() << '\n';
    std::string failedConstraints;
    for (const auto& failed : generated.failed_constraints) {
        if (!failedConstraints.empty()) {
            failedConstraints += ',';
        }
        failedConstraints += failed;
    }
    report << "failed_constraints=" << failedConstraints << '\n';
    for (const auto& unknown : generated.unverified_constraints) {
        report << "unverified_constraint=" << unknown << '\n';
    }
    for (const auto& measurement : generated.stress_measurements) {
        report << "stress." << measurement.first << '=' << std::setprecision(17) << measurement.second << '\n';
    }
    for (std::size_t index = 0; index < generated.generated_netlist_paths.size(); ++index) {
        report << "generated_roundtrip_netlist_" << (index + 1) << '='
               << generated.generated_netlist_paths[index] << '\n';
    }
    if (!writeValidationReport(root, report.str(), message)) {
        error << message << '\n';
        return 2;
    }
    if (!generated.ok) {
        error << "生成失败，阶段=" << stageName(generated.stage)
              << "：" << generated.message << "\n日志：" << generated.log_path << '\n';
        return 4;
    }
    output << "validation_scope=" << manifest.validation_scope << '\n'
           << "experimental_dc_ready=" << (generated.experimental_dc_ready ? "true" : "false") << '\n'
           << "optimization_candidate_ready=" << (generated.optimization_candidate_ready ? "true" : "false") << '\n'
           << "experimental_pvt_ready=" << (generated.experimental_pvt_ready ? "true" : "false") << '\n'
           << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
           << "reliability_verified=false\n"
           << "published=" << (generated.ok && !experimentalDc ? "true" : "false") << '\n'
           << "performance_verified=false\n"
           << "current_limits_applied=" << (currentLimitsApplied ? "true" : "false") << '\n'
           << "structural_ready=" << (generated.structural_ready ? "true" : "false") << '\n'
           << "nominal_dc_ready=" << (generated.nominal_dc_ready ? "true" : "false") << '\n'
           << "pvt_ready=" << (generated.pvt_ready ? "true" : "false") << '\n'
           << "parameters_quantized="
           << (generated.parameters_quantized ? "true" : "false") << '\n'
           << "ready_for_sizing=" << (generated.ready_for_sizing ? "true" : "false") << '\n'
           << "派生电路=" << generated.target.library << '/' << generated.target.cell << '/' << generated.target.view << '\n'
           << "原始网表=" << (root / "before/core_before.scs").string() << '\n'
           << "期望网表=" << (root / "expected/core_expected.scs").string() << '\n'
           << "回读网表=" << (root / "after/core_roundtrip.scs").string() << '\n'
           << "封装子Cell数=" << packaged.packages.size() << '\n'
           << "验证报告=" << (root / "reports/validation.txt").string() << '\n';
    return 0;
}

int openCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error, ProcessRunner& runner)
{
    std::string message;
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) {
        error << message << '\n';
        return 2;
    }
    const bool experimentalDc = manifest.validation_scope == "experimental_dc";
    std::map<std::string, std::string> validation;
    if (!readPairs(root / "reports/validation.txt", validation, message)) {
        error << "派生电路尚未通过本会话范围的generate与回读校验，拒绝打开\n";
        return 4;
    }
    const auto generationRun = validation["generation_run"];
    if (experimentalDc && !generationRun.empty() &&
        (generationRun.size() != 8 || generationRun.substr(0, 4) != "run_" ||
         generationRun == "run_0000" ||
         !std::all_of(generationRun.begin() + 4, generationRun.end(),
                      [](char c) { return c >= '0' && c <= '9'; }))) {
        error << "实验生成报告的运行编号无效\n";
        return 4;
    }
    // Older successful reports have no run number and keep their legacy name.
    const CellViewRef target{manifest.variant_library + (experimentalDc ? "__STAGING" : ""),
        manifest.variant_cell + (experimentalDc && !generationRun.empty() ? "__GEN_" + generationRun : "") +
            (experimentalDc ? "__STAGING" : ""),
        "schematic", manifest.source_storage, {}};
    if (validation["ok"] != "true" || validation["stage"] != "complete" ||
        validation["validation_scope"] != manifest.validation_scope ||
        validation["target"] != target.library + "/" + target.cell + "/schematic" ||
        (experimentalDc
         ? ((validation["experimental_dc_ready"] != "true" &&
             validation["optimization_candidate_ready"] != "true") ||
            validation["ready_for_sizing"] != "false" || validation["published"] != "false")
         : (manifest.validation_scope == "structure_only"
            ? validation["structural_ready"] != "true"
            : validation["ready_for_sizing"] != "true"))) {
        error << "派生电路尚未通过本会话范围的generate与回读校验，拒绝打开\n";
        return 4;
    }
    BackendPaths paths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.experimental_dc = experimentalDc;
    ProcessVirtuosoBackend backend(manifest.backend, paths, runner);
    const auto status = backend.Open(target);
    if (!status.ok) {
        error << "打开Virtuoso失败：" << status.message << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    output << "已请求打开：" << target.library << '/' << target.cell << '/'
           << target.view << '\n';
    return 0;
}

} // namespace

void PrintCliHelp(std::ostream& output)
{
    output <<
        "st_circuit_tool - 独立MOS结构变换与Virtuoso往返工具\n\n"
        "命令:\n"
        "  inspect  --backend PATH --cds-lib PATH --lib LIB --cell CELL --view schematic\n"
        "           --work-dir DIR --variant-lib LIB --variant-cell CELL --variant-id ID\n"
        "           --skill topology_variant.il\n"
        "           [--validation-scope dc_operating_point|structure_only|experimental_dc]\n"
        "           [--bench-lib LIB --bench-cell CELL --bench-view schematic]\n"
        "           [--vbias-vhigh-net NET --vbias-vlow-net NET]\n"
        "           [--core-subckt NAME] [--simulator spectre] [--nominal-corner tt]\n"
        "           [--pvt-corners tt,ss,ff]\n"
        "           [--max-branch-current-error FRACTION --max-vbias-current AMPERE]\n"
        "  list     --session DIR\n"
        "  confirm  --session DIR --operation FILE.conf\n"
        "  undo     --session DIR\n"
        "  fresh    --session DIR\n"
        "  generate --session DIR [--experimental-resistor-trials FILE.tsv] [--experimental-resistor-auto true]\n"
        "  open     --session DIR\n\n"
        "输入是Virtuoso工程cds.lib和核心L/C/V；baseline网表由后端自动生成。\n"
        "generate自动完成PDK重扫、基线工作点、VBIAS求解、封装、物化、\n"
        "名义DC检查与回读验证，全部通过后输出四状态与ready_for_sizing。\n"
        "电流上限选填且须成对提供；无Spec时求解名义DC可行参数，未验完整性能。\n";
}

int RunCli(const std::vector<std::string>& arguments,
           std::ostream& output,
           std::ostream& error,
           ProcessRunner& runner)
{
    std::string command;
    Options options;
    std::string message;
    if (!parseOptions(arguments, command, options, message)) {
        error << message << '\n';
        PrintCliHelp(error);
        return 2;
    }
    if (command == "help" || command == "--help" || command == "-h") {
        PrintCliHelp(output);
        return 0;
    }
    if (command == "inspect") {
        return inspectCommand(options, output, error, runner);
    }

    std::string session;
    if (!required(options, "session", session, message)) {
        error << message << '\n';
        return 2;
    }
    const std::filesystem::path root(session);
    if (command == "list") {
        return listCommand(root, output, error);
    }
    if (command == "confirm") {
        return confirmCommand(root, options, output, error);
    }
    if (command == "undo") {
        return undoCommand(root, output, error);
    }
    if (command == "fresh") {
        return freshCommand(root, output, error);
    }
    if (command == "generate") {
        return generateCommand(root, options, output, error, runner);
    }
    if (command == "open") {
        return openCommand(root, output, error, runner);
    }
    error << "未知命令：" << command << '\n';
    PrintCliHelp(error);
    return 2;
}

} // namespace st::standalone
