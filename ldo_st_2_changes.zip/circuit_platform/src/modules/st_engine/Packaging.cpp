#include "st/Packaging.h"
// 修改原因：多个独立模块复用原计划 JSON 格式，以列表传给现有 Python 转换器。
#include "st/JsonWriter.h"
#include "st/Naming.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

namespace st {
namespace {

std::string sanitizeName(const std::string& value)
{
    std::string result;
    result.reserve(value.size());
    for (const unsigned char character : value) {
        result.push_back(std::isalnum(character) || character == '_'
            ? static_cast<char>(character) : '_');
    }
    if (result.empty()) {
        result = "TOPOLOGY";
    }
    return result;
}

// 修改原因：用户需要从 Cell 名直接认出原模块、目标 MOS 和变换；不暴露 ST_EDIT/PKG 编号。
std::string descriptiveCellName(const std::string& owner, const ChangeSet& changes,
                                const std::vector<std::size_t>& indices)
{
    std::string name = owner;
    for (auto index : indices) {
        const auto& request = changes.Changes()[index].request;
        auto mos = sanitizeName(request.target.instance);
        while (!mos.empty() && mos.back() == '_') mos.pop_back();
        const char* type = request.type == TransformType::AddSourceResistor ? "resistor" :
            request.type == TransformType::MosStack ? "stack" :
            request.type == TransformType::SameTypeCascode ? "same_cascode" : "cross_cascode";
        name += "_" + mos + "_" + type;
    }
    return sanitizeName(name);
}

bool intersects(const std::set<std::string>& left, const std::set<std::string>& right)
{
    for (const auto& value : left) {
        if (right.count(value) != 0) {
            return true;
        }
    }
    return false;
}

bool sameInstance(const Instance& left, const Instance& right)
{
    return left.name == right.name && left.model == right.model &&
        left.nets == right.nets && left.params == right.params;
}

void appendUnique(std::vector<std::string>& values, std::set<std::string>& seen,
                  const std::string& value)
{
    if (!value.empty() && seen.insert(value).second) {
        values.push_back(value);
    }
}

struct Group {
    std::set<std::string> touched;
    std::vector<std::size_t> operation_indices;
};

std::string roleName(TerminalRole role)
{
    switch (role) {
    case TerminalRole::Drain: return "Drain";
    case TerminalRole::Gate: return "Gate";
    case TerminalRole::Source: return "Source";
    case TerminalRole::Bulk: return "Bulk";
    case TerminalRole::Positive: return "Positive";
    case TerminalRole::Negative: return "Negative";
    case TerminalRole::Substrate: return "Substrate";
    case TerminalRole::Well: return "Well";
    case TerminalRole::Other: return "Other";
    }
    return "Other";
}

std::vector<TerminalRole> terminalRoles(const DeviceDescriptor& descriptor)
{
    if (descriptor.terminal_roles_by_index.size() == descriptor.terminal_count) {
        return descriptor.terminal_roles_by_index;
    }
    std::vector<TerminalRole> roles(descriptor.terminal_count, TerminalRole::Other);
    for (const auto& [role, index] : descriptor.terminal_index) {
        if (index < roles.size()) {
            roles[index] = role;
        }
    }
    return roles;
}

bool validateMappedRange(const Instance& instance, const DeviceDescriptor& descriptor,
                         const std::string& normalized,
                         const std::pair<double, double>& bounds,
                         std::vector<Diagnostic>& diagnostics)
{
    const double minimum = bounds.first;
    const double maximum = bounds.second;
    const auto mapped = descriptor.normalized_to_cdf.find(normalized);
    if (mapped == descriptor.normalized_to_cdf.end()) {
        return true;
    }
    const auto value = instance.params.find(mapped->second);
    if (value == instance.params.end()) {
        return true;
    }
    bool parsed = false;
    const double number = parseSuffixValue(value->second, parsed);
    // CDF numeric bounds and engineering suffixes can round to adjacent doubles.
    // Match AutoBias's relative roundoff tolerance, without an absolute floor
    // (an absolute tolerance in metres could admit a real geometry change).
    const auto sameValue = [](double left, double right) {
        return std::isfinite(left) && std::isfinite(right) &&
            std::fabs(left - right) <= 1e-12 * std::max(std::fabs(left), std::fabs(right));
    };
    if (!parsed || !std::isfinite(number) ||
        (number < minimum && !sameValue(number, minimum)) ||
        (number > maximum && !sameValue(number, maximum))) {
        std::ostringstream detail;
        detail << std::setprecision(17) << " raw=" << value->second
               << " parsed=" << (parsed ? std::string{} : "INVALID:") << number
               << " min=" << minimum << " max=" << maximum;
        diagnostics.push_back({DiagCode::DeviceParameterOutOfRange,
            "device " + instance.name + " PDK parameter " + mapped->second +
            " out of allowed range or invalid;" + detail.str()});
        return false;
    }
    return true;
}

bool validateInstanceForOa(const Instance& instance, const DeviceDescriptor*& descriptor,
                           const DeviceCatalog& catalog,
                           std::vector<Diagnostic>& diagnostics)
{
    descriptor = catalog.Find(instance.model);
    if (descriptor == nullptr || descriptor->oa_library.empty() ||
        descriptor->oa_cell.empty() || descriptor->oa_view.empty() ||
        descriptor->terminal_count == 0 ||
        descriptor->terminal_names_by_index.size() != descriptor->terminal_count ||
        instance.nets.size() != descriptor->terminal_count) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
            "device " + instance.name + " lacks PDK OA master or complete terminal order"});
        return false;
    }
    bool ok = true;
    ok = validateMappedRange(instance, *descriptor, "width",
        {descriptor->limits.min_width, descriptor->limits.max_width}, diagnostics) && ok;
    ok = validateMappedRange(instance, *descriptor, "length",
        {descriptor->limits.min_length, descriptor->limits.max_length}, diagnostics) && ok;
    ok = validateMappedRange(instance, *descriptor, "resistance",
        {descriptor->limits.min_resistance, descriptor->limits.max_resistance}, diagnostics) && ok;
    return ok;
}

bool validatePackagingInputs(const PackageTopologyInput& input,
                             PackageTopologyResult& failed)
{
    const Netlist& baseline = *input.baseline;
    const Netlist& flatVariant = *input.flatVariant;
    const std::string& coreSubckt = input.coreSubckt;
    const ChangeSet& changes = *input.changes;
    const ReplayResult& replay = *input.replay;
    const auto* baseCore = baseline.find(coreSubckt);
    const auto* flatCore = flatVariant.find(coreSubckt);
    auto* packagedCore = failed.netlist.find(coreSubckt);
    if (baseCore == nullptr || flatCore == nullptr || packagedCore == nullptr) {
        failed.diagnostics.push_back({DiagCode::NotFound,
            "packaging cannot find core subckt " + coreSubckt});
        return false;
    }
    if (!replay.ok || changes.Changes().size() != replay.outcomes.size()) {
        failed.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "packaging Change Set count does not match transform result count"});
        return false;
    }
    if (input.generated.prefix.empty() || input.generated.library.empty()) {
        failed.diagnostics.push_back({DiagCode::MissingInput,
            "generated cell library and prefix must not be empty"});
        return false;
    }
    return true;
}

std::map<std::string, std::string> collectMemberMapping(const Netlist& baseline,
                                                        const std::string& coreSubckt,
                                                        const ChangeSet& changes,
                                                        const ReplayResult& replay)
{
    const auto* baseCore = baseline.find(coreSubckt);
    std::map<std::string, std::string> originalByMember;
    if (baseCore == nullptr) {
        return originalByMember;
    }
    for (const auto& instance : baseCore->instances) {
        originalByMember[instance.name] = instance.name;
    }
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        const auto& request = changes.Changes()[index].request;
        const auto origin = originalByMember.find(request.target.instance);
        // 修改原因：同型 Cascode 和 Stack 的新增 MOS 仍用原 master，复用原图属性可避免重写 PDK 派生字段。
        if ((request.type == TransformType::MosStack || request.type == TransformType::SameTypeCascode) &&
            origin != originalByMember.end()) {
            const auto originalName = origin->second;
            for (const auto& added : replay.outcomes[index].addedInstances) {
                originalByMember[added] = originalName;
            }
        }
    }
    return originalByMember;
}

std::vector<Group> buildOperationGroups(const ChangeSet& changes,
                                        const ReplayResult& replay)
{
    std::vector<Group> groups;
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        Group incoming;
        incoming.operation_indices.push_back(index);
        incoming.touched.insert(changes.Changes()[index].request.target.instance);
        const auto& outcome = replay.outcomes[index];
        incoming.touched.insert(outcome.addedInstances.begin(), outcome.addedInstances.end());
        incoming.touched.insert(outcome.removedInstances.begin(), outcome.removedInstances.end());
        incoming.touched.insert(outcome.modifiedInstances.begin(), outcome.modifiedInstances.end());

        for (auto iterator = groups.begin(); iterator != groups.end();) {
            if (!intersects(iterator->touched, incoming.touched)) {
                ++iterator;
                continue;
            }
            incoming.touched.insert(iterator->touched.begin(), iterator->touched.end());
            incoming.operation_indices.insert(incoming.operation_indices.end(),
                iterator->operation_indices.begin(), iterator->operation_indices.end());
            iterator = groups.erase(iterator);
        }
        std::sort(incoming.operation_indices.begin(), incoming.operation_indices.end());
        groups.push_back(std::move(incoming));
    }
    std::sort(groups.begin(), groups.end(), [](const Group& left, const Group& right) {
        return left.operation_indices.front() < right.operation_indices.front();
    });
    return groups;
}

TransformOutcome buildCandidateOutcome(const Netlist& precedingVariant,
                                       const Netlist& flatCandidate,
                                       const std::string& coreSubckt)
{
    const auto* baseCore = precedingVariant.find(coreSubckt);
    const auto* candidateCore = flatCandidate.find(coreSubckt);
    TransformOutcome outcome;
    if (baseCore == nullptr || candidateCore == nullptr) {
        return outcome;
    }
    for (const auto& original : baseCore->instances) {
        const auto* candidate = candidateCore->find(original.name);
        if (candidate == nullptr) {
            outcome.removedInstances.push_back(original.name);
        } else if (!sameInstance(original, *candidate)) {
            outcome.modifiedInstances.push_back(original.name);
        }
    }
    for (const auto& candidate : candidateCore->instances) {
        if (baseCore->find(candidate.name) != nullptr) {
            continue;
        }
        // 新增实例的 model 若是候选网表内部 subckt，它是 VBIAS
        // 层级载具；其余才是功能封装内的物理器件。
        if (flatCandidate.find(candidate.model) != nullptr) {
            outcome.bias_instances.push_back(candidate.name);
        } else {
            outcome.addedInstances.push_back(candidate.name);
        }
    }
    return outcome;
}

bool layoutsSeparated(const OaCreateInstance& current, const OaGeneratedCell& symbol,
                      const OaCreateInstance& prior, const OaGeneratedCell& priorSymbol,
                      double pinAndStubMargin)
{
    const bool separateX =
        current.location.x + symbol.symbol_upper_right.x + pinAndStubMargin <
            prior.location.x + priorSymbol.symbol_lower_left.x - pinAndStubMargin ||
        prior.location.x + priorSymbol.symbol_upper_right.x + pinAndStubMargin <
            current.location.x + symbol.symbol_lower_left.x - pinAndStubMargin;
    const bool separateY =
        current.location.y + symbol.symbol_upper_right.y + pinAndStubMargin <
            prior.location.y + priorSymbol.symbol_lower_left.y - pinAndStubMargin ||
        prior.location.y + priorSymbol.symbol_upper_right.y + pinAndStubMargin <
            current.location.y + symbol.symbol_lower_left.y - pinAndStubMargin;
    return separateX || separateY;
}

bool separateLayoutPass(OaMaterializationPlan& plan, std::size_t i,
                        double pinAndStubMargin, double clearGap)
{
    auto& current = plan.create_instances[i];
    const auto& symbol = plan.generated_cells[i];
    bool moved = false;
    for (std::size_t j = 0; j < i; ++j) {
        const auto& prior = plan.create_instances[j];
        const auto& priorSymbol = plan.generated_cells[j];
        if (layoutsSeparated(current, symbol, prior, priorSymbol, pinAndStubMargin)) {
            continue;
        }
        current.location.y = prior.location.y + priorSymbol.symbol_lower_left.y -
            symbol.symbol_upper_right.y - 2.0 * pinAndStubMargin - clearGap;
        moved = true;
    }
    return moved;
}

void separateGeneratedLayouts(OaMaterializationPlan& plan,
                              double pinAndStubMargin, double clearGap)
{
    for (std::size_t i = 0; i < plan.create_instances.size(); ++i) {
        for (std::size_t pass = 0; pass < i; ++pass) {
            if (!separateLayoutPass(plan, i, pinAndStubMargin, clearGap)) {
                break;
            }
        }
    }
}

} // namespace

PackageTopologyResult PackageTopologyVariant(
    const PackageTopologyInput& input)
{
    const Netlist& baseline = *input.baseline;
    const Netlist& flatVariant = *input.flatVariant;
    const std::string& coreSubckt = input.coreSubckt;
    const ChangeSet& changes = *input.changes;
    const ReplayResult& replay = *input.replay;
    const GeneratedCellId& generated = input.generated;
    PackageTopologyResult result;
    result.netlist = flatVariant;
    const std::string& generatedCellPrefix = generated.prefix;
    const std::string& generatedLibrary = generated.library;
    const auto* baseCore = baseline.find(coreSubckt);
    const auto* flatCore = flatVariant.find(coreSubckt);
    auto* packagedCore = result.netlist.find(coreSubckt);
    if (!validatePackagingInputs(input, result)) {
        return result;
    }

    const std::map<std::string, std::string> originalByMember =
        collectMemberMapping(baseline, coreSubckt, changes, replay);
    const std::vector<Group> groups = buildOperationGroups(changes, replay);

    std::set<std::string> packageCellNames;
    for (const auto& subckt : flatVariant.subckts) {
        packageCellNames.insert(subckt.name);
    }
    std::set<std::string> membersAcrossPackages;
    std::vector<Instance> wrappers;
    std::set<std::string> namesToRemove;

    for (std::size_t groupIndex = 0; groupIndex < groups.size(); ++groupIndex) {
        const auto& group = groups[groupIndex];
        GeneratedTopologyPackage package;
        // 修改原因：保留实际变换类型，PMOS 反序摆放不应用于串电阻/Cascode 或混合封装。
        package.stack_layout = group.operation_indices.size() == 1 &&
            changes.Changes()[group.operation_indices.front()].request.type == TransformType::MosStack;
        std::ostringstream number;
        number << std::setw(4) << std::setfill('0') << (groupIndex + 1);
        package.package_id = "PKG" + number.str();
        // 修改原因：功能封装按选中器件命名，多次生成同一历史时名称保持稳定。
        package.cell_name = generated.descriptive_names
            ? descriptiveCellName(generatedCellPrefix, changes, group.operation_indices)
            : sanitizeName(generatedCellPrefix) + "__" + package.package_id;
        while (!packageCellNames.insert(package.cell_name).second) {
            package.cell_name += "_2";
        }
        package.circuit.name = "oa_" + generatedLibrary + "__" + package.cell_name;

        for (const auto operationIndex : group.operation_indices) {
            package.operation_ids.push_back(
                changes.Changes()[operationIndex].request.operation_id);
        }

        for (const auto& instance : flatCore->instances) {
            if (group.touched.count(instance.name) == 0) {
                continue;
            }
            if (!membersAcrossPackages.insert(instance.name).second) {
                result.diagnostics.push_back({DiagCode::TargetConflict,
                    "instance " + instance.name + " is claimed by multiple packages"});
                return result;
            }
            package.member_instances.push_back(instance.name);
            package.circuit.instances.push_back(instance);
            const auto origin = originalByMember.find(instance.name);
            if (origin != originalByMember.end()) {
                package.original_instance_by_member[instance.name] = origin->second;
            }
            namesToRemove.insert(instance.name);
        }
        if (package.circuit.instances.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "package " + package.package_id + " has no materializable instances"});
            return result;
        }

        for (const auto operationIndex : group.operation_indices) {
            const auto& target = changes.Changes()[operationIndex].request.target.instance;
            if (baseCore->find(target) != nullptr) {
                if (std::find(package.replaced_parent_instances.begin(),
                              package.replaced_parent_instances.end(), target) ==
                    package.replaced_parent_instances.end()) {
                    package.replaced_parent_instances.push_back(target);
                }
                package.parent_instance_name = target;
            }
        }
        if (package.parent_instance_name.empty()) {
            for (const auto& instance : baseCore->instances) {
                if (group.touched.count(instance.name) != 0) {
                    package.parent_instance_name = instance.name;
                    package.replaced_parent_instances.push_back(instance.name);
                    break;
                }
            }
        }
        if (package.parent_instance_name.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "package has no replaceable baseline parent instance"});
            return result;
        }

        std::set<std::string> boundary;
        boundary.insert(flatCore->pins.begin(), flatCore->pins.end());
        for (const auto& instance : baseCore->instances) {
            if (group.touched.count(instance.name) == 0) {
                continue;
            }
            boundary.insert(instance.nets.begin(), instance.nets.end());
        }
        for (const auto& instance : flatCore->instances) {
            if (group.touched.count(instance.name) != 0) {
                continue;
            }
            boundary.insert(instance.nets.begin(), instance.nets.end());
        }
        for (const auto operationIndex : group.operation_indices) {
            const auto& ports = replay.outcomes[operationIndex].external_ports;
            boundary.insert(ports.begin(), ports.end());
        }

        std::set<std::string> seenPins;
        for (const auto& original : baseCore->instances) {
            if (group.touched.count(original.name) == 0) {
                continue;
            }
            for (const auto& net : original.nets) {
                bool usedInside = false;
                for (const auto& instance : package.circuit.instances) {
                    usedInside = usedInside ||
                        std::find(instance.nets.begin(), instance.nets.end(), net) !=
                            instance.nets.end();
                }
                if (usedInside && boundary.count(net) != 0) {
                    appendUnique(package.circuit.pins, seenPins, net);
                }
            }
        }
        for (const auto& instance : package.circuit.instances) {
            for (const auto& net : instance.nets) {
                if (boundary.count(net) != 0) {
                    appendUnique(package.circuit.pins, seenPins, net);
                }
            }
        }
        if (package.circuit.pins.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "package " + package.package_id + " has no external ports"});
            return result;
        }

        wrappers.push_back({package.parent_instance_name, package.circuit.pins,
                            package.circuit.name, {}});
        result.packages.push_back(std::move(package));
    }

    // 每个 FixedBias Cascode 操作的 bias 层级实例单独封装成 VBIAS 子Cell：
    // 独立 VBIAS%04d 计数器，不并入功能分组，也不替换任何基线实例。
    std::set<std::string> templateSubcktNames;
    std::size_t vbiasCounter = 0;
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        for (const auto& biasName : replay.outcomes[index].bias_instances) {
            const auto* flatInstance = flatCore->find(biasName);
            if (flatInstance == nullptr) {
                result.diagnostics.push_back({DiagCode::NotFound,
                    "packaging cannot find bias instance " + biasName});
                return result;
            }
            const auto* templateSubckt = flatVariant.find(flatInstance->model);
            if (templateSubckt == nullptr || templateSubckt->instances.empty()) {
                result.diagnostics.push_back({DiagCode::NotFound,
                    "packaging cannot find VBIAS template subckt " + flatInstance->model});
                return result;
            }
            GeneratedTopologyPackage package;
            ++vbiasCounter;
            std::ostringstream number;
            number << std::setw(4) << std::setfill('0') << vbiasCounter;
            package.package_id = "VBIAS" + number.str();
            // 修改原因：偏置封装与对应 MOS 同名加 _VBIAS，便于区分功能管和偏置模块。
            package.cell_name = generated.descriptive_names
                ? descriptiveCellName(generatedCellPrefix, changes, {index}) + "_VBIAS"
                : sanitizeName(generatedCellPrefix) + "__" + package.package_id;
            while (!packageCellNames.insert(package.cell_name).second) {
                package.cell_name += "_2";
            }
            package.circuit.name = "oa_" + generatedLibrary + "__" + package.cell_name;
            package.circuit.pins = templateSubckt->pins;
            package.circuit.instances = templateSubckt->instances;
            for (const auto& instance : templateSubckt->instances) {
                package.member_instances.push_back(instance.name);
            }
            package.parent_instance_name = biasName;
            package.operation_ids.push_back(changes.Changes()[index].request.operation_id);
            // wrapper 保持真实父层网（VHIGH/VLOW/VS_ORIG/VG_CTRL/输出网），
            // 与模板端口按位置对应，不假设 pin 名等于 net 名。
            wrappers.push_back({biasName, flatInstance->nets, package.circuit.name, {}});
            namesToRemove.insert(biasName);
            templateSubcktNames.insert(flatInstance->model);
            result.packages.push_back(std::move(package));
        }
    }

    // 模板定义载具已变成封装 circuit，从扁平结果里删掉，避免重复定义。
    auto& resultSubckts = result.netlist.subckts;
    resultSubckts.erase(
        std::remove_if(resultSubckts.begin(), resultSubckts.end(),
            [&](const Subckt& subckt) {
                return templateSubcktNames.count(subckt.name) != 0;
            }),
        resultSubckts.end());

    packagedCore->instances.erase(
        std::remove_if(packagedCore->instances.begin(), packagedCore->instances.end(),
            [&](const Instance& instance) { return namesToRemove.count(instance.name) != 0; }),
        packagedCore->instances.end());
    packagedCore->instances.insert(packagedCore->instances.end(), wrappers.begin(), wrappers.end());
    for (const auto& package : result.packages) {
        result.netlist.subckts.push_back(package.circuit);
    }
    return result;
}
PackageTopologyResult PackageSingleCandidateVariant(
    const Netlist& baseline,
    const Netlist& flatCandidate,
    const std::string& coreSubckt,
    const std::string& targetInstance,
    const GeneratedCellId& generated)
{
    ChangeSet emptyChanges;
    ReplayResult emptyReplay;
    CandidatePackagingInput input;
    input.baseline = &baseline;
    input.precedingVariant = &baseline;
    input.precedingChanges = &emptyChanges;
    input.precedingReplay = &emptyReplay;
    input.flatCandidate = &flatCandidate;
    input.coreSubckt = coreSubckt;
    input.targetInstance = targetInstance;
    input.operationId = "dc_candidate";
    input.generated = generated;
    return PackageCumulativeCandidateVariant(input);
}

PackageTopologyResult PackageCumulativeCandidateVariant(
    const CandidatePackagingInput& input)
{
    const Netlist& baseline = *input.baseline;
    const Netlist& precedingVariant = *input.precedingVariant;
    const ChangeSet& precedingChanges = *input.precedingChanges;
    const ReplayResult& precedingReplay = *input.precedingReplay;
    const Netlist& flatCandidate = *input.flatCandidate;
    const std::string& coreSubckt = input.coreSubckt;
    const std::string& targetInstance = input.targetInstance;
    const std::string& operationId = input.operationId;
    const GeneratedCellId& generated = input.generated;
    PackageTopologyResult failed;
    failed.netlist = flatCandidate;
    const auto* baseCore = precedingVariant.find(coreSubckt);
    const auto* candidateCore = flatCandidate.find(coreSubckt);
    if (baseCore == nullptr || candidateCore == nullptr ||
        baseCore->find(targetInstance) == nullptr) {
        failed.diagnostics.push_back({DiagCode::NotFound,
            "DC candidate packaging cannot find core subckt or target instance"});
        return failed;
    }

    TransformRequest request;
    request.operation_id = operationId;
    request.target = {"/", coreSubckt, targetInstance};
    request.type = TransformType::SameTypeCascode;
    CascodeTransformRequest payload;
    payload.subckt = coreSubckt;
    payload.target = targetInstance;
    request.payload = payload;
    ChangeSet changes = precedingChanges;
    Diagnostic diagnostic;
    if (!changes.Confirm(request, diagnostic)) {
        failed.diagnostics.push_back(std::move(diagnostic));
        return failed;
    }

    TransformOutcome outcome = buildCandidateOutcome(precedingVariant,
        flatCandidate, coreSubckt);
    if (outcome.modifiedInstances.empty() && outcome.addedInstances.empty()) {
        failed.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "DC candidate has no packagable functional change versus baseline"});
        return failed;
    }

    ReplayResult replay = precedingReplay;
    replay.ok = true;
    replay.applied_operation_ids.push_back(request.operation_id);
    replay.outcomes.push_back(std::move(outcome));
    PackageTopologyInput packagedInput;
    packagedInput.baseline = &baseline;
    packagedInput.flatVariant = &flatCandidate;
    packagedInput.coreSubckt = coreSubckt;
    packagedInput.changes = &changes;
    packagedInput.replay = &replay;
    packagedInput.generated = generated;
    return PackageTopologyVariant(packagedInput);
}

OaPlanBuildResult BuildPackagedOaMaterializationPlan(
    const Netlist& baseline,
    const PackageTopologyResult& packaged,
    const DeviceCatalog& catalog,
    const OaPlanBuildContext& context,
    const std::string& generatedLibrary)
{
    OaPlanBuildResult result;
    auto& plan = result.plan;
    plan.schema_version = 3;
    plan.source = context.source;
    plan.target = context.target;
    plan.clone_map = context.clone_map;
    plan.preview = context.preview;
    // Each wrapper terminal is connected by a labeled stub at its actual
    // symbol pin. The context's guessed, free-standing label wires can cross
    // those pins and short unrelated nets; they do not belong in this plan.
    if (!packaged.ok()) {
        result.diagnostics = packaged.diagnostics;
        return result;
    }
    if (generatedLibrary.empty()) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "generated package child cell library must not be empty"});
        return result;
    }

    std::string coreName;
    for (const auto& [subckt, hierarchy] : context.hierarchy_by_subckt) {
        if (hierarchy == "/" && baseline.find(subckt) != nullptr &&
            packaged.netlist.find(subckt) != nullptr) {
            coreName = subckt;
            break;
        }
    }
    if (coreName.empty()) {
        result.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "packaging OA plan cannot find root-level core subckt"});
        return result;
    }

    std::set<std::string> deleted;
    for (const auto& package : packaged.packages) {
        for (const auto& original : package.replaced_parent_instances) {
            if (deleted.insert(original).second) {
                plan.delete_instances.push_back({"/", original});
            }
        }
        const auto location = context.locations.find("/:" + package.parent_instance_name);
        if (location == context.locations.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "wrapper " + package.parent_instance_name + " lacks root-level placement coordinates"});
            continue;
        }

        OaGeneratedCell generated;
        generated.package_id = package.package_id;
        generated.schematic = {generatedLibrary, package.cell_name, "schematic",
                               context.target.storage_path, {}};
        generated.symbol = {generatedLibrary, package.cell_name, "symbol",
                            context.target.storage_path, {}};
        const double halfHeight = std::max(1.0,
            0.5 * static_cast<double>(package.circuit.pins.size()));
        generated.symbol_lower_left = {-1.5, -halfHeight};
        generated.symbol_upper_right = {1.5, halfHeight};
        const std::string scope = "/@generated/" + package.package_id;

        OaCreateInstance wrapper;
        wrapper.hierarchy_path = "/";
        wrapper.name = package.parent_instance_name;
        wrapper.master = generated.symbol;
        wrapper.location = location->second;
        wrapper.expected_terminal_count = package.circuit.pins.size();
        wrapper.bit_count = MosArrayBitCount(wrapper.name);
        // wrapper 连接按封装网表里的真实父层网映射：功能封装 nets==pins，
        // VBIAS 封装则是 VHIGH/VLOW/VS_ORIG/VG_CTRL 对应的真实轨网。
        const auto* packagedCore = packaged.netlist.find(coreName);
        const Instance* wrapperInstance = packagedCore == nullptr
            ? nullptr : packagedCore->find(package.parent_instance_name);
        if (wrapperInstance == nullptr ||
            wrapperInstance->model != package.circuit.name ||
            wrapperInstance->nets.size() != package.circuit.pins.size()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "wrapper " + package.parent_instance_name +
                " missing in packaged netlist or net count does not match package ports"});
            continue;
        }
        for (std::size_t pinIndex = 0; pinIndex < package.circuit.pins.size(); ++pinIndex) {
            wrapper.connections.push_back({"Other", package.circuit.pins[pinIndex],
                                           wrapperInstance->nets[pinIndex]});
        }
        plan.create_instances.push_back(std::move(wrapper));

        constexpr std::size_t kRowsPerColumn = 20;
        constexpr double kColumnPitch = 6.0;
        constexpr double kRowPitch = 3.0;
        for (std::size_t index = 0; index < package.circuit.instances.size(); ++index) {
            const auto& instance = package.circuit.instances[index];
            const DeviceDescriptor* descriptor = nullptr;
            if (!validateInstanceForOa(instance, descriptor, catalog, result.diagnostics)) {
                continue;
            }
            OaCreateInstance create;
            create.hierarchy_path = scope;
            create.name = instance.name;
            create.master = {descriptor->oa_library, descriptor->oa_cell,
                             descriptor->oa_view};
            // 修改原因：PMOS symbol 的 S 在上、D 在下，Stack 按 Source 到 Drain 从上往下摆。
            // 只反转显示位置，保留实例顺序及原有 D/G/S/B 网络、参数和方向。
            const std::size_t layoutIndex = package.stack_layout && descriptor->kind == DeviceKind::MosP
                ? package.circuit.instances.size() - 1 - index : index;
            create.location = {
                kColumnPitch * static_cast<double>(layoutIndex / kRowsPerColumn),
                -kRowPitch * static_cast<double>(layoutIndex % kRowsPerColumn)};
            create.expected_terminal_count = descriptor->terminal_count;
            create.bit_count = MosArrayBitCount(instance.name);
            create.cdf_parameters = instance.params;
            const auto origin = package.original_instance_by_member.find(instance.name);
            const auto* original = origin == package.original_instance_by_member.end()
                ? nullptr : baseline.find(coreName)->find(origin->second);
            if (original && isMosKind(descriptor->kind) && original->model == instance.model) {
                // 修改原因：复制原 MOS 全部属性，只对明确改变的尺寸调用 CDF；自定义 Stack 不重算无关参数。
                create.property_source = context.target;
                create.property_source_instance = original->name;
                create.cdf_parameters.clear();
                for (const auto& parameter : instance.params) {
                    const auto old = original->params.find(parameter.first);
                    if (old == original->params.end() || old->second != parameter.second)
                        create.cdf_parameters.insert(parameter);
                }
            }
            const auto resistance = descriptor->parameter_constraints.find("resistance");
            const bool nativeResistanceTrials = descriptor->native_parameter_trials &&
                resistance != descriptor->parameter_constraints.end() &&
                resistance->second.discrete_values.size() > 1;
            if ((context.structure_only || nativeResistanceTrials) && descriptor->kind == DeviceKind::Resistor && !original) {
                for (const auto& mapping : descriptor->normalized_to_cdf) {
                    if (instance.params.count(mapping.second) == 0) {
                        create.allowed_extra_cdf_parameters.insert(mapping.second);
                    }
                }
            }
            const auto roles = terminalRoles(*descriptor);
            for (std::size_t terminal = 0; terminal < instance.nets.size(); ++terminal) {
                const auto& terminalName = descriptor->terminal_names_by_index[terminal];
                const auto& net = instance.nets[terminal];
                create.connections.push_back({roleName(roles[terminal]), terminalName, net});
            }
            generated.create_instances.push_back(std::move(create));
        }

        // 修改原因：每个真实 pin 已用带网名的物理短线相连；再次跨器件直连会让 Stack
        // 的多个中间节点共用路由轨道而短路，因此不再重复添加 direct_wires。

        for (std::size_t index = 0; index < package.circuit.pins.size(); ++index) {
            const bool left = index % 2 == 0;
            const double y = halfHeight - 0.5 -
                static_cast<double>(index / 2);
            generated.create_ports.push_back({scope, package.circuit.pins[index],
                "inputOutput", package.circuit.pins[index],
                {left ? -8.0 : 8.0, y}});
        }
        plan.generated_cells.push_back(std::move(generated));
    }

    // Context locations use a primitive-sized grid. Generated symbols grow
    // with their port count; include the pin and stub reach when separating
    // wrappers. Keep X in the isolated area beyond the source schematic.
    constexpr double kPinAndStubMargin = 1.0;
    constexpr double kClearGap = 0.25;
    separateGeneratedLayouts(plan, kPinAndStubMargin, kClearGap);
    const auto validation = ValidateOaPlan(plan);
    result.diagnostics.insert(result.diagnostics.end(), validation.begin(), validation.end());
    return result;
}

// 修改原因：旧服务的子模块分支直接增删 MOS，绕过封装。这里只把操作转成 wrapper + 子 Cell，
// 沿用调用者既定的 clone_map/source/target/preview，不决定祖先复制、最终提升或撤销策略。
OaPlanBuildResult BuildPackagedTransformPlan(const PackageTopologyInput& input,
        const DeviceCatalog& catalog, const OaPlanBuildContext& context,
        PackageTopologyResult* combined)
{
    OaPlanBuildResult result;
    auto& plan = result.plan;
    plan.schema_version = 3;
    plan.source = context.source;
    plan.target = context.target;
    plan.clone_map = context.clone_map;
    plan.preview = context.preview;
    if (combined) { *combined = {}; combined->netlist = *input.flatVariant; }
    std::map<std::string, std::vector<std::size_t>> owners;
    for (std::size_t i = 0; i < input.changes->Size(); ++i)
        owners[input.changes->Changes()[i].request.target.subckt].push_back(i);
    for (const auto& owner : owners) {
        const auto path = context.hierarchy_by_subckt.find(owner.first);
        const auto clone = std::find_if(context.clone_map.begin(), context.clone_map.end(),
            [&](const OaCloneMapping& item) {
                return path != context.hierarchy_by_subckt.end() && item.hierarchy_path == path->second;
            });
        if (clone == context.clone_map.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "package owner has no caller-provided clone mapping: " + owner.first});
            return result;
        }
        ChangeSet local;
        ReplayResult replay;
        replay.ok = true;
        for (auto index : owner.second) {
            Diagnostic diagnostic;
            if (!local.Confirm(input.changes->Changes()[index].request, diagnostic)) {
                result.diagnostics.push_back(diagnostic); return result;
            }
            replay.outcomes.push_back(input.replay->outcomes.at(index));
        }
        const auto packaged = PackageTopologyVariant({input.baseline, input.flatVariant,
            owner.first, &local, &replay, {clone->source.cell, clone->source.library, true}});
        if (!packaged.ok()) { result.diagnostics = packaged.diagnostics; return result; }
        OaPlanBuildContext localContext;
        localContext.source = clone->source;
        localContext.target = clone->target;
        localContext.clone_map = {{clone->source, clone->target, "/"}};
        localContext.hierarchy_by_subckt[owner.first] = "/";
        localContext.preview = context.preview;
        localContext.structure_only = context.structure_only;
        for (std::size_t i = 0; i < packaged.packages.size(); ++i)
            localContext.locations["/:" + packaged.packages[i].parent_instance_name] = {12.0, -12.0 * i};
        auto localPlan = BuildPackagedOaMaterializationPlan(*input.baseline, packaged, catalog,
                                                          localContext, clone->source.library);
        if (!localPlan.ok()) { result.diagnostics = localPlan.diagnostics; return result; }
        for (auto item : localPlan.plan.delete_instances) {
            item.hierarchy_path = path->second;
            plan.delete_instances.push_back(std::move(item));
        }
        for (auto item : localPlan.plan.create_instances) {
            item.hierarchy_path = path->second;
            plan.create_instances.push_back(std::move(item));
        }
        for (auto cell : localPlan.plan.generated_cells) {
            // 修改原因：不同 owner 的局部 PKG 编号会重复；合并时用真实包名区分，Cell 名不加编号。
            cell.package_id = cell.schematic.library + "/" + cell.schematic.cell;
            const std::string generatedPath = "/@generated/" + cell.package_id;
            for (auto& item : cell.create_instances) item.hierarchy_path = generatedPath;
            for (auto& item : cell.create_ports) item.hierarchy_path = generatedPath;
            for (auto& item : cell.direct_wires) item.hierarchy_path = generatedPath;
            for (auto& item : cell.wires) item.hierarchy_path = generatedPath;
            plan.generated_cells.push_back(std::move(cell));
        }
        if (combined) {
            *combined->netlist.find(owner.first) = *packaged.netlist.find(owner.first);
            combined->netlist.subckts.erase(std::remove_if(combined->netlist.subckts.begin(),
                combined->netlist.subckts.end(), [&](const Subckt& sub) {
                    return input.flatVariant->find(sub.name) && !packaged.netlist.find(sub.name);
                }), combined->netlist.subckts.end());
            for (auto package : packaged.packages) {
                package.package_id = package.circuit.name;
                combined->netlist.subckts.push_back(package.circuit);
                combined->packages.push_back(std::move(package));
            }
        }
    }
    result.diagnostics = ValidateOaPlan(plan);
    return result;
}

// 修改原因：旧服务把第二个 owner 拼成第一个 owner 的子实例，导致 missing direct child。
// 使用已经解析的目标 subckt 分组，每个模块只有根克隆；不改变上层引用或扫描方式。
ModuleTransformPlans BuildModuleTransformPlans(const PackageTopologyInput& input,
        const DeviceCatalog& catalog, const CellViewRef& fallbackSource,
        const std::string& targetView, PackageTopologyResult* combined)
{
    ModuleTransformPlans result;
    std::vector<std::string> owners;
    std::map<std::string, std::vector<std::size_t>> indices;
    for (std::size_t i = 0; i < input.changes->Size(); ++i) {
        const auto& owner = input.changes->Changes()[i].request.target.subckt;
        if (indices.count(owner) == 0) owners.push_back(owner);
        indices[owner].push_back(i);
    }
    if (combined) { *combined = {}; combined->netlist = *input.flatVariant; }
    for (const auto& owner : owners) {
        const auto* source = input.baseline->find(owner);
        if (!source) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid, "module owner missing: " + owner});
            return result;
        }
        ChangeSet changes;
        ReplayResult replay;
        replay.ok = true;
        for (auto index : indices.at(owner)) {
            Diagnostic diagnostic;
            if (!changes.Confirm(input.changes->Changes()[index].request, diagnostic)) {
                result.diagnostics.push_back(diagnostic); return result;
            }
            replay.outcomes.push_back(input.replay->outcomes.at(index));
        }
        OaPlanBuildContext context;
        context.source = fallbackSource;
        context.source.cell = owner;
        if (!source->library.empty()) context.source.library = source->library;
        context.target = context.source;
        context.target.view = targetView;
        context.clone_map = {{context.source, context.target, "/"}};
        context.hierarchy_by_subckt[owner] = "/";
        context.preview = {targetView, "initial", "standalone-v2-packaged"};
        context.structure_only = true;
        PackageTopologyResult packaged;
        auto built = BuildPackagedTransformPlan({input.baseline, input.flatVariant, owner,
            &changes, &replay, input.generated}, catalog, context, &packaged);
        if (!built.ok()) { result.diagnostics = built.diagnostics; return result; }
        result.plans.push_back(std::move(built.plan));
        if (combined) {
            *combined->netlist.find(owner) = *packaged.netlist.find(owner);
            combined->netlist.subckts.erase(std::remove_if(combined->netlist.subckts.begin(),
                combined->netlist.subckts.end(), [&](const Subckt& sub) {
                    return input.flatVariant->find(sub.name) && !packaged.netlist.find(sub.name);
                }), combined->netlist.subckts.end());
            for (auto& package : packaged.packages) {
                combined->netlist.subckts.push_back(package.circuit);
                combined->packages.push_back(std::move(package));
            }
        }
    }
    return result;
}

// 修改原因：单模块保留原协议；多模块由 SKILL 批量预检查后逐个处理，Python 无需改动。
std::string ModuleTransformPlans::Json() const
{
    if (plans.size() == 1) return WritePlanJson(plans.front());
    std::ostringstream out;
    out << "{\"module_plans\":[";
    for (std::size_t i = 0; i < plans.size(); ++i) {
        if (i != 0) out << ',';
        out << WritePlanJson(plans[i]);
    }
    out << "]}";
    return out.str();
}

} // namespace st
