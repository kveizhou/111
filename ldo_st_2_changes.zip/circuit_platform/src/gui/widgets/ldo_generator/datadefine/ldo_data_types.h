#ifndef MAAU_GUI_WIDGETS_LDO_GENERATOR_DATADEFINE_LDO_DATA_TYPES_H
#define MAAU_GUI_WIDGETS_LDO_GENERATOR_DATADEFINE_LDO_DATA_TYPES_H

#include <QMetaType>
#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "common/basic/ldo_common_data_define.h"

namespace maau {
namespace gui {
namespace ldo {

// Types shared with the service layer live in maau::ldo (ldo_common_data_define.h).
// Alias them into this namespace so existing GUI code keeps using the bare Ldo* names.
using LdoArchitecture = maau::ldo::LdoArchitecture;
using LdoConstraintLevel = maau::ldo::LdoConstraintLevel;
using LdoSpecItem = maau::ldo::LdoSpecItem;
using LdoVariableItem = maau::ldo::LdoVariableItem;
using LdoAnalysisConfig = maau::ldo::LdoAnalysisConfig;
using LdoTestConfig = maau::ldo::LdoTestConfig;
using LdoCornerDetail = maau::ldo::LdoCornerDetail;
using LdoCornerItem = maau::ldo::LdoCornerItem;
using LdoTbNode = maau::ldo::LdoTbNode;
using LdoBenchStatus = maau::ldo::LdoBenchStatus;
using LdoCaseItem = maau::ldo::LdoCaseItem;
using LdoBenchVersion = maau::ldo::LdoBenchVersion;
using LdoBenchWorkspace = maau::ldo::LdoBenchWorkspace;
using LdoCandidateResult = maau::ldo::LdoCandidateResult;
using LdoRecommendationResult = maau::ldo::LdoRecommendationResult;
using LdoCaseQueryRequest = maau::ldo::LdoCaseQueryRequest;
using LdoSpecQueryResult = maau::ldo::LdoSpecQueryResult;
using LdoSpecProfile = maau::ldo::LdoSpecProfile;

enum class LdoSpecCompareType : uint8_t {
    None = 0,
    Min = 1,
    Max = 2,
    Range = 3,
    Target = 4,
    Info = 5
};

struct LdoSpecSelectionData {
    LdoSpecProfile profile;
    // User-confirmed spec rows from the Step 1 spec form (the profile carries
    // only name/arch/pdk/version metadata).
    std::vector<LdoSpecItem> spec_items;
    // Full-field spec definitions from GetCommonSpecMetrics (type/output/evaltype/
    // spec/weight). The bench page edits the per-item .spec target; the service
    // adapter passes spec_config_info straight to the simulation engine.
    SpecConfigInfo spec_config_info;
    LdoCandidateResult selected_candidate;

    bool isValid() const
    {
        return !selected_candidate.case_item.case_id.empty();
    }

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoBenchData {
    std::string source_case_id;
    LdoBenchWorkspace workspace;
    bool saved = false;

    bool isValid() const
    {
        return !source_case_id.empty() &&
               !workspace.selected_version_id.empty();
    }

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};


enum class LdoSimulationRunStatus : uint8_t {
    Queued = 0,
    Running,
    Completed,
    Failed
};

enum class LdoMetricCellStatus : uint8_t {
    Neutral = 0,
    Better,
    Worse,
    WithinTolerance
};

enum class LdoSimulationTaskStatus : uint8_t {
    Running = 0,
    Queued = 1,
    Completed = 2,
    Failed = 3
};

struct LdoSimulationTaskItem {
    std::string name;
    LdoSimulationTaskStatus status = LdoSimulationTaskStatus::Queued;
    std::string log_path;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationProgress {
    int total_runs = 0;
    int running_runs = 0;
    int queued_runs = 0;
    int completed_runs = 0;
    int failed_runs = 0;
    int progress_percent = 0;
    std::string elapsed;
    std::string remaining;
    std::string average_run_time;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationTableColumn {
    std::string id;
    std::string display_name;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationTableCell {
    std::string column_id;
    std::string value;
    LdoMetricCellStatus status = LdoMetricCellStatus::Neutral;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationTableRow {
    std::vector<LdoSimulationTableCell> cells;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationTableData {
    std::vector<LdoSimulationTableColumn> columns;
    std::vector<LdoSimulationTableRow> rows;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

// One completed simulation run under one TB. Layer-2 node of the history tree,
// labelled by start_time. The result/parameter tables back the right-side table;
// config_snapshot backs the read-only Tests/GV/Params/Corners layer-3 nodes.
struct LdoSimulationHistoryRun {
    std::string run_id;
    std::string start_time;
    LdoSimulationTableData parameter_table;
    LdoSimulationTableData result_table;
    LdoTbNode config_snapshot;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

// Layer-1 node of the history tree: all runs for one testbench.
struct LdoTbSimulationHistory {
    std::string tb_id;
    std::vector<LdoSimulationHistoryRun> runs;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationSnapshot {
    LdoSimulationProgress progress;
    std::string campaign_id;
    std::vector<LdoSimulationTaskItem> tasks;

    // Per-TB result tables (key = tb_id). One entry per selected TB.
    std::map<std::string, LdoSimulationTableData> result_tables_by_tb;
    std::map<std::string, LdoSimulationTableData> parameter_tables_by_tb;

    // Read-only history tree: one entry per TB that has any past run.
    std::vector<LdoTbSimulationHistory> history_by_tb;

    // Per-TB spec_sim_result_before.json paths (key = tb_id); checkpoint
    // re-reads each TB's results from disk on restore.
    std::map<std::string, std::string> report_json_paths_by_tb;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSimulationData {
    std::string source_bench_id;
    LdoSimulationSnapshot snapshot;

    bool isValid() const
    {
        return !source_bench_id.empty();
    }

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};


struct LdoSizingGroup {
    std::string name;
    std::vector<std::string> instances;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingDeviceTypeConstraints {
    std::string device_type;
    bool can_add_group = false;
    std::vector<LdoSizingGroup> groups;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoRatioItem {
    std::string instance_name;
    std::string ratio_parameter;
    std::string ratio_value;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoRatioConstraint {
    std::string device_type;
    std::string base_instance_name;
    std::vector<LdoRatioItem> items;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingConstraints {
    std::vector<LdoSizingDeviceTypeConstraints> device_types;
    std::vector<LdoRatioConstraint> ratio_constraints;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingAlgorithmConfig {
    // Spec-optimization algorithm (single-select): "beems"/"simo"/"de"/"vts".
    // Feeds AlgoConfig.spec_enabled_list.
    std::string spec_algo;
    std::vector<std::string> available_spec_algos;
    // Space-pruning algorithms (multi-select): "uno"/"maze"/"allin".
    // Feeds AlgoConfig.small_enabled_list.
    std::vector<std::string> available_space_pruning;
    std::vector<std::string> selected_space_pruning;
    // MOS tunable parameter dimensions (Design Variables). Backend values
    // (e.g. {"L","FIN","FINGERS"}). Restored into the DeviceParameterPanel
    // via optParamToGuiView; persisted so checkpoint reopens with the same
    // selection. Mirrors optimization's device_opt_params.mos_parameter.
    std::vector<std::string> mos_parameter;
    // RES/CAP Design Variables. No tech mapping (transDeviceParams with empty
    // tech). Persisted for checkpoint round-trip; restored into the panel.
    std::vector<std::string> res_parameter;
    std::vector<std::string> cap_parameter;
    int time_limit_min = 0;
    int point_limit = 0;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoParasiticAwareConfig {
    bool enabled = false;
    std::string baseline_dspf;
    std::string key_net;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

// One parameter row of a sizing result device. `reference` is the baseline
// (origin) value used for change-ratio coloring; empty when no baseline exists.
// `result_values` aligns 1:1 with LdoSizingSnapshot::result_columns.
struct LdoSizingParamResult {
    std::string reference;
    std::vector<std::string> result_values;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingResultDevice {
    std::string device_name;
    std::vector<std::pair<std::string, LdoSizingParamResult>> parameters;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingSnapshot {
    LdoSizingConstraints constraints;
    LdoSizingAlgorithmConfig algorithm;
    std::string mode_name;
    int iterations = 0;
    std::string elapsed_time;
    LdoParasiticAwareConfig parasitic;
    std::vector<std::string> result_columns;
    std::vector<LdoSizingResultDevice> result_devices;

    // On-disk references returned by the sizing handler payload
    // {output_path, db_files[], summary_optimizer_input_path}. Stored so the
    // checkpoint can re-read sizing results from disk on restore. Empty until
    // a sizing completes. summary_optimizer_input_path locates the Spec flow's
    // instance2Variable map, which the result table needs for Cell-tab aggregation.
    std::string output_path;
    std::vector<std::string> db_files;
    std::string summary_optimizer_input_path;

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoSizingData {
    LdoSizingSnapshot snapshot;

    bool isValid() const
    {
        return !snapshot.output_path.empty();
    }

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

struct LdoHandoffInfo {
    bool is_pr_ready = false;
    bool is_sized = false;
    bool is_topo_transformed = false;
};

// One confirmed structure transform on a device (结构变换页 m_history 的元素)。
// 定义在 datadefine 而非页面头文件：LdoCaseState（ldo_workflow_context.h）要
// 持久化它，放页面头文件会造成 context → page → context 的循环包含。
// 序列化进 LdoCaseState（checkpoint），重开项目后结构变换页可恢复历史与
// "已修改"标记。
struct LdoTransformChange {
    std::string deviceId;
    std::string type;
    std::string w;
    std::string wf;
    std::string nf;
    std::string l;
    std::string r;  // 电阻值（仅"替换成电阻"类型用）
    int stages = 2;
    std::string newMaster;  // 异型 Cascode 新增管 master（用户从下拉选）

    void ToBaseData(maau::platform::BaseData &base_data) const;
    void FromBaseData(maau::platform::BaseData &base_data);
};

enum class LdoSizingMode : uint8_t {
    NormalSizing = 0,
    PASSizing = 1,
};

enum class LdoTopologyTransformType : uint8_t {
    None = 0,
    Cascode = 1,
    Stack = 2,
    Parallel = 3,
    BiasTemplate = 4
};

struct LdoTopologyTransformConfig {
    LdoTopologyTransformType transform_type = LdoTopologyTransformType::None;
    std::map<std::string, std::string> params;
    bool is_configured = false;
};

enum class LdoWorkflowStep : uint8_t {
    SpecAndCase = 0,
    Bench = 1,
    Simulation = 2,
    Sizing = 3,
    Summary = 4,
    Handoff = 5,
    Unknown = 255
};

}  // namespace ldo
}  // namespace gui
}  // namespace maau

Q_DECLARE_METATYPE(maau::ldo::LdoArchitecture)
Q_DECLARE_METATYPE(maau::ldo::LdoCaseItem)
Q_DECLARE_METATYPE(maau::ldo::LdoTbNode)
Q_DECLARE_METATYPE(maau::ldo::LdoCandidateResult)
Q_DECLARE_METATYPE(maau::ldo::LdoVariableItem)
Q_DECLARE_METATYPE(maau::ldo::LdoAnalysisConfig)
Q_DECLARE_METATYPE(maau::ldo::LdoTestConfig)
Q_DECLARE_METATYPE(maau::ldo::LdoCornerItem)
Q_DECLARE_METATYPE(maau::ldo::LdoBenchVersion)
Q_DECLARE_METATYPE(maau::ldo::LdoBenchWorkspace)
Q_DECLARE_METATYPE(maau::gui::ldo::LdoWorkflowStep)
Q_DECLARE_METATYPE(maau::gui::ldo::LdoSpecSelectionData)
Q_DECLARE_METATYPE(maau::gui::ldo::LdoBenchData)
Q_DECLARE_METATYPE(maau::gui::ldo::LdoSimulationData)
Q_DECLARE_METATYPE(maau::gui::ldo::LdoSizingData)

#endif
