#include <type_traits>

#include "ldo_data_types.h"
#include "platform/json/basedata_helper.h"
#include "platform/json/basedata_interface.h"
#include "widgets/ldo_generator/ldo_workflow_context.h"

namespace maau {
namespace gui {
namespace ldo {
namespace {
template <typename E, typename = std::enable_if_t<std::is_enum_v<E>>>
void EnumToBaseData(maau::platform::BaseData &base_data, E value)
{
    base_data = static_cast<int>(static_cast<std::underlying_type_t<E>>(value));
}

template <typename E, typename = std::enable_if_t<std::is_enum_v<E>>>
void EnumFromBaseData(const maau::platform::BaseData &base_data, E &out)
{
    if (base_data.isInt()) {
        out = static_cast<E>(base_data.asInt());
    }
}
}  // namespace

void LdoSpecSelectionData::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    profile.ToBaseData(base_data["profile"]);
    maau::platform::FiledToBaseData(base_data["spec_items"], spec_items);
    maau::platform::FiledToBaseData(base_data["spec_config_info"], spec_config_info);
    selected_candidate.ToBaseData(base_data["selected_candidate"]);
}

void LdoSpecSelectionData::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("profile")) {
        profile.FromBaseData(base_data["profile"]);
    }
    maau::platform::FiledFromBaseData(base_data, spec_items, "spec_items");
    maau::platform::FiledFromBaseData(base_data, spec_config_info, "spec_config_info");
    if (base_data.isMember("selected_candidate")) {
        selected_candidate.FromBaseData(base_data["selected_candidate"]);
    }
}

void LdoBenchData::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["source_case_id"], source_case_id);
    workspace.ToBaseData(base_data["workspace"]);
    maau::platform::FiledToBaseData(base_data["saved"], saved);
}

void LdoBenchData::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, source_case_id, "source_case_id");
    if (base_data.isMember("workspace")) {
        workspace.FromBaseData(base_data["workspace"]);
    }
    maau::platform::FiledFromBaseData(base_data, saved, "saved");
}

void LdoSimulationTaskItem::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["name"], name);
    EnumToBaseData(base_data["status"], status);
    maau::platform::FiledToBaseData(base_data["log_path"], log_path);
}

void LdoSimulationTaskItem::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, name, "name");
    EnumFromBaseData(base_data["status"], status);
    maau::platform::FiledFromBaseData(base_data, log_path, "log_path");
}

void LdoSimulationProgress::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["total_runs"], total_runs);
    maau::platform::FiledToBaseData(base_data["running_runs"], running_runs);
    maau::platform::FiledToBaseData(base_data["queued_runs"], queued_runs);
    maau::platform::FiledToBaseData(base_data["completed_runs"], completed_runs);
    maau::platform::FiledToBaseData(base_data["failed_runs"], failed_runs);
    maau::platform::FiledToBaseData(base_data["progress_percent"], progress_percent);
    maau::platform::FiledToBaseData(base_data["elapsed"], elapsed);
    maau::platform::FiledToBaseData(base_data["remaining"], remaining);
    maau::platform::FiledToBaseData(base_data["average_run_time"], average_run_time);
}

void LdoSimulationProgress::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, total_runs, "total_runs");
    maau::platform::FiledFromBaseData(base_data, running_runs, "running_runs");
    maau::platform::FiledFromBaseData(base_data, queued_runs, "queued_runs");
    maau::platform::FiledFromBaseData(base_data, completed_runs, "completed_runs");
    maau::platform::FiledFromBaseData(base_data, failed_runs, "failed_runs");
    maau::platform::FiledFromBaseData(base_data, progress_percent, "progress_percent");
    maau::platform::FiledFromBaseData(base_data, elapsed, "elapsed");
    maau::platform::FiledFromBaseData(base_data, remaining, "remaining");
    maau::platform::FiledFromBaseData(base_data, average_run_time, "average_run_time");
}

void LdoSimulationTableColumn::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["id"], id);
    maau::platform::FiledToBaseData(base_data["display_name"], display_name);
}

void LdoSimulationTableColumn::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, id, "id");
    maau::platform::FiledFromBaseData(base_data, display_name, "display_name");
}

void LdoSimulationTableCell::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["column_id"], column_id);
    maau::platform::FiledToBaseData(base_data["value"], value);
    EnumToBaseData(base_data["status"], status);
}

void LdoSimulationTableCell::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, column_id, "column_id");
    maau::platform::FiledFromBaseData(base_data, value, "value");
    EnumFromBaseData(base_data["status"], status);
}

void LdoSimulationTableRow::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::arrayValue;
    for (const auto &cell : cells) {
        maau::platform::BaseData item;
        cell.ToBaseData(item);
        base_data.append(item);
    }
}

void LdoSimulationTableRow::FromBaseData(maau::platform::BaseData &base_data)
{
    cells.clear();
    if (base_data.isArray()) {
        for (auto &v : base_data) {
            LdoSimulationTableCell cell;
            cell.FromBaseData(v);
            cells.push_back(std::move(cell));
        }
    }
}

void LdoSimulationTableData::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["columns"], columns);
    maau::platform::FiledToBaseData(base_data["rows"], rows);
}

void LdoSimulationTableData::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, columns, "columns");
    maau::platform::FiledFromBaseData(base_data, rows, "rows");
}

void LdoSimulationHistoryRun::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["run_id"], run_id);
    maau::platform::FiledToBaseData(base_data["start_time"], start_time);
    parameter_table.ToBaseData(base_data["parameter_table"]);
    result_table.ToBaseData(base_data["result_table"]);
    config_snapshot.ToBaseData(base_data["config_snapshot"]);
}

void LdoSimulationHistoryRun::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, run_id, "run_id");
    maau::platform::FiledFromBaseData(base_data, start_time, "start_time");
    if (base_data.isMember("parameter_table")) {
        parameter_table.FromBaseData(base_data["parameter_table"]);
    }
    if (base_data.isMember("result_table")) {
        result_table.FromBaseData(base_data["result_table"]);
    }
    if (base_data.isMember("config_snapshot")) {
        config_snapshot.FromBaseData(base_data["config_snapshot"]);
    }
}

void LdoTbSimulationHistory::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["tb_id"], tb_id);
    maau::platform::FiledToBaseData(base_data["runs"], runs);
}

void LdoTbSimulationHistory::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, tb_id, "tb_id");
    maau::platform::FiledFromBaseData(base_data, runs, "runs");
}

void LdoSimulationSnapshot::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    progress.ToBaseData(base_data["progress"]);
    maau::platform::FiledToBaseData(base_data["campaign_id"], campaign_id);
    maau::platform::FiledToBaseData(base_data["tasks"], tasks);
    // Result tables NOT serialized — re-derived from report_json_paths_by_tb on
    // restore (reloadSimulationTablesFromDisk). Only the on-disk paths persist.
    maau::platform::FiledToBaseData(base_data["history_by_tb"], history_by_tb);
    maau::platform::FiledToBaseData(base_data["report_json_paths_by_tb"], report_json_paths_by_tb);
}

void LdoSimulationSnapshot::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("progress")) {
        progress.FromBaseData(base_data["progress"]);
    }
    maau::platform::FiledFromBaseData(base_data, campaign_id, "campaign_id");
    maau::platform::FiledFromBaseData(base_data, tasks, "tasks");
    // result_tables_by_tb / parameter_tables_by_tb are intentionally not restored
    // here; they are reloaded from disk via report_json_paths_by_tb on the restore
    // path. history_by_tb (history tree) IS restored; old checkpoints that predate
    // it restore the vector empty (FiledFromBaseData tolerates a missing key).
    maau::platform::FiledFromBaseData(base_data, history_by_tb, "history_by_tb");
    maau::platform::FiledFromBaseData(base_data, report_json_paths_by_tb, "report_json_paths_by_tb");
}

void LdoSimulationData::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["source_bench_id"], source_bench_id);
    snapshot.ToBaseData(base_data["snapshot"]);
}

void LdoSimulationData::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, source_bench_id, "source_bench_id");
    if (base_data.isMember("snapshot")) {
        snapshot.FromBaseData(base_data["snapshot"]);
    }
}

void LdoSizingGroup::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["name"], name);
    maau::platform::FiledToBaseData(base_data["instances"], instances);
}

void LdoSizingGroup::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, name, "name");
    maau::platform::FiledFromBaseData(base_data, instances, "instances");
}

void LdoSizingDeviceTypeConstraints::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["device_type"], device_type);
    maau::platform::FiledToBaseData(base_data["can_add_group"], can_add_group);
    maau::platform::FiledToBaseData(base_data["groups"], groups);
}

void LdoSizingDeviceTypeConstraints::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, device_type, "device_type");
    maau::platform::FiledFromBaseData(base_data, can_add_group, "can_add_group");
    maau::platform::FiledFromBaseData(base_data, groups, "groups");
}

void LdoRatioItem::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["instance_name"], instance_name);
    maau::platform::FiledToBaseData(base_data["ratio_parameter"], ratio_parameter);
    maau::platform::FiledToBaseData(base_data["ratio_value"], ratio_value);
}

void LdoRatioItem::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, instance_name, "instance_name");
    maau::platform::FiledFromBaseData(base_data, ratio_parameter, "ratio_parameter");
    maau::platform::FiledFromBaseData(base_data, ratio_value, "ratio_value");
}

void LdoRatioConstraint::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["device_type"], device_type);
    maau::platform::FiledToBaseData(base_data["base_instance_name"], base_instance_name);
    maau::platform::FiledToBaseData(base_data["items"], items);
}

void LdoRatioConstraint::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, device_type, "device_type");
    maau::platform::FiledFromBaseData(base_data, base_instance_name, "base_instance_name");
    maau::platform::FiledFromBaseData(base_data, items, "items");
}

void LdoSizingConstraints::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["device_types"], device_types);
    maau::platform::FiledToBaseData(base_data["ratio_constraints"], ratio_constraints);
}

void LdoSizingConstraints::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, device_types, "device_types");
    maau::platform::FiledFromBaseData(base_data, ratio_constraints, "ratio_constraints");
}

void LdoSizingAlgorithmConfig::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["spec_algo"], spec_algo);
    maau::platform::FiledToBaseData(base_data["available_spec_algos"], available_spec_algos);
    maau::platform::FiledToBaseData(base_data["available_space_pruning"], available_space_pruning);
    maau::platform::FiledToBaseData(base_data["selected_space_pruning"], selected_space_pruning);
    maau::platform::FiledToBaseData(base_data["mos_parameter"], mos_parameter);
    maau::platform::FiledToBaseData(base_data["res_parameter"], res_parameter);
    maau::platform::FiledToBaseData(base_data["cap_parameter"], cap_parameter);
    maau::platform::FiledToBaseData(base_data["time_limit_seconds"], time_limit_min);
    maau::platform::FiledToBaseData(base_data["point_limit"], point_limit);
}

void LdoSizingAlgorithmConfig::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, spec_algo, "spec_algo");
    maau::platform::FiledFromBaseData(base_data, available_spec_algos, "available_spec_algos");
    maau::platform::FiledFromBaseData(base_data, available_space_pruning, "available_space_pruning");
    maau::platform::FiledFromBaseData(base_data, selected_space_pruning, "selected_space_pruning");
    maau::platform::FiledFromBaseData(base_data, mos_parameter, "mos_parameter");
    maau::platform::FiledFromBaseData(base_data, res_parameter, "res_parameter");
    maau::platform::FiledFromBaseData(base_data, cap_parameter, "cap_parameter");
    maau::platform::FiledFromBaseData(base_data, time_limit_min, "time_limit_seconds");
    maau::platform::FiledFromBaseData(base_data, point_limit, "point_limit");
}

void LdoParasiticAwareConfig::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["enabled"], enabled);
    maau::platform::FiledToBaseData(base_data["baseline_dspf"], baseline_dspf);
    maau::platform::FiledToBaseData(base_data["key_net"], key_net);
}

void LdoParasiticAwareConfig::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, enabled, "enabled");
    maau::platform::FiledFromBaseData(base_data, baseline_dspf, "baseline_dspf");
    maau::platform::FiledFromBaseData(base_data, key_net, "key_net");
}

void LdoSizingParamResult::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["reference"], reference);
    maau::platform::FiledToBaseData(base_data["result_values"], result_values);
}

void LdoSizingParamResult::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, reference, "reference");
    maau::platform::FiledFromBaseData(base_data, result_values, "result_values");
}

void LdoSizingResultDevice::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["device_name"], device_name);
    // parameters: vector<pair<string, LdoSizingParamResult>>
    // Serialized as an array of {param_name, reference, result_values[]} objects.
    base_data["parameters"] = Json::arrayValue;
    for (const auto &p : parameters) {
        maau::platform::BaseData item = Json::objectValue;
        std::string name = p.first;
        maau::platform::FiledToBaseData(item["name"], name);
        p.second.ToBaseData(item["param_result"]);
        base_data["parameters"].append(item);
    }
}

void LdoSizingResultDevice::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, device_name, "device_name");
    parameters.clear();
    if (base_data.isMember("parameters") && base_data["parameters"].isArray()) {
        for (auto &v : base_data["parameters"]) {
            std::string name;
            maau::platform::FiledFromBaseData(v, name, "name");
            LdoSizingParamResult paramResult;
            paramResult.FromBaseData(v["param_result"]);
            parameters.emplace_back(std::move(name), std::move(paramResult));
        }
    }
}

void LdoSizingSnapshot::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    constraints.ToBaseData(base_data["constraints"]);
    algorithm.ToBaseData(base_data["algorithm"]);
    maau::platform::FiledToBaseData(base_data["mode_name"], mode_name);
    maau::platform::FiledToBaseData(base_data["iterations"], iterations);
    maau::platform::FiledToBaseData(base_data["elapsed_time"], elapsed_time);
    parasitic.ToBaseData(base_data["parasitic"]);
    // result_columns / result_devices are NOT serialized — they are re-derived
    // from db_files on restore (loadSizingResultFromDb). Only the on-disk
    // references (output_path / db_files) are persisted, per the checkpoint
    // design. constraints/algorithm/parasitic stay so restore can rebuild the
    // sizing input config without re-running the backend.
    maau::platform::FiledToBaseData(base_data["output_path"], output_path);
    maau::platform::FiledToBaseData(base_data["db_files"], db_files);
    maau::platform::FiledToBaseData(base_data["summary_optimizer_input_path"], summary_optimizer_input_path);
}

void LdoSizingSnapshot::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("constraints")) {
        constraints.FromBaseData(base_data["constraints"]);
    }
    if (base_data.isMember("algorithm")) {
        algorithm.FromBaseData(base_data["algorithm"]);
    }
    maau::platform::FiledFromBaseData(base_data, mode_name, "mode_name");
    maau::platform::FiledFromBaseData(base_data, iterations, "iterations");
    maau::platform::FiledFromBaseData(base_data, elapsed_time, "elapsed_time");
    if (base_data.isMember("parasitic")) {
        parasitic.FromBaseData(base_data["parasitic"]);
    }
    maau::platform::FiledFromBaseData(base_data, output_path, "output_path");
    maau::platform::FiledFromBaseData(base_data, db_files, "db_files");
    maau::platform::FiledFromBaseData(base_data, summary_optimizer_input_path, "summary_optimizer_input_path");
}

void LdoSizingData::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    snapshot.ToBaseData(base_data["snapshot"]);
}

void LdoSizingData::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("snapshot")) {
        snapshot.FromBaseData(base_data["snapshot"]);
    }
}

void LdoTransformChange::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    maau::platform::FiledToBaseData(base_data["device_id"], deviceId);
    maau::platform::FiledToBaseData(base_data["type"], type);
    maau::platform::FiledToBaseData(base_data["w"], w);
    maau::platform::FiledToBaseData(base_data["wf"], wf);
    maau::platform::FiledToBaseData(base_data["nf"], nf);
    maau::platform::FiledToBaseData(base_data["l"], l);
    maau::platform::FiledToBaseData(base_data["r"], r);
    maau::platform::FiledToBaseData(base_data["stages"], stages);
    maau::platform::FiledToBaseData(base_data["new_master"], newMaster);
}

void LdoTransformChange::FromBaseData(maau::platform::BaseData &base_data)
{
    maau::platform::FiledFromBaseData(base_data, deviceId, "device_id");
    maau::platform::FiledFromBaseData(base_data, type, "type");
    maau::platform::FiledFromBaseData(base_data, w, "w");
    maau::platform::FiledFromBaseData(base_data, wf, "wf");
    maau::platform::FiledFromBaseData(base_data, nf, "nf");
    maau::platform::FiledFromBaseData(base_data, l, "l");
    maau::platform::FiledFromBaseData(base_data, r, "r");
    maau::platform::FiledFromBaseData(base_data, stages, "stages");
    maau::platform::FiledFromBaseData(base_data, newMaster, "new_master");
}

void LdoSpecConfig::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    profile.ToBaseData(base_data["profile"]);
    maau::platform::FiledToBaseData(base_data["spec_items"], spec_items);
    maau::platform::FiledToBaseData(base_data["spec_config_info"], spec_config_info);
}

void LdoSpecConfig::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("profile")) {
        profile.FromBaseData(base_data["profile"]);
    }
    maau::platform::FiledFromBaseData(base_data, spec_items, "spec_items");
    maau::platform::FiledFromBaseData(base_data, spec_config_info, "spec_config_info");
}

void LdoCaseState::ToBaseData(maau::platform::BaseData &base_data) const
{
    base_data = Json::objectValue;
    candidate.ToBaseData(base_data["candidate"]);
    bench.ToBaseData(base_data["bench"]);
    // simulation/sizing persist only on-disk references (report_json_paths_by_tb /
    // db_files); result tables are re-derived on restore via the page's enterPage.
    if (simulation.has_value()) {
        simulation->ToBaseData(base_data["simulation"]);
    }
    if (sizing.has_value()) {
        sizing->ToBaseData(base_data["sizing"]);
    }
    base_data["completed_steps"] = Json::arrayValue;
    for (auto step : completedSteps) {
        base_data["completed_steps"].append(static_cast<int>(step));
    }
    base_data["back_annotated"] = back_annotated;
    base_data["parasitic_enabled"] = parasitic_enabled;
    maau::platform::FiledToBaseData(base_data["pulled_dspf_path"], pulledDspfPath);
    // 结构变换页状态：history + 物化产物 LCV/cds + finalized + DUT cell。
    // 重开项目后结构变换页据此恢复"已修改"标记与"变换后"预览定位。
    maau::platform::FiledToBaseData(base_data["transform_history"], transform_history);
    maau::platform::FiledToBaseData(base_data["transform_generated"], transform_generated);
    maau::platform::FiledToBaseData(base_data["transform_finalized"], transform_finalized);
    maau::platform::FiledToBaseData(base_data["transformed_lcv_lib"], transformed_lcv_lib);
    maau::platform::FiledToBaseData(base_data["transformed_lcv_cell"], transformed_lcv_cell);
    maau::platform::FiledToBaseData(base_data["transformed_lcv_view"], transformed_lcv_view);
    maau::platform::FiledToBaseData(base_data["transformed_cds_path"], transformed_cds_path);
    maau::platform::FiledToBaseData(base_data["transform_dut_cell"], transform_dut_cell);
}

void LdoCaseState::FromBaseData(maau::platform::BaseData &base_data)
{
    if (base_data.isMember("candidate")) {
        candidate.FromBaseData(base_data["candidate"]);
    }
    if (base_data.isMember("bench")) {
        bench.FromBaseData(base_data["bench"]);
    }
    if (base_data.isMember("simulation")) {
        LdoSimulationData sim;
        sim.FromBaseData(base_data["simulation"]);
        simulation = std::move(sim);
    }
    if (base_data.isMember("sizing")) {
        LdoSizingData sz;
        sz.FromBaseData(base_data["sizing"]);
        sizing = std::move(sz);
    }
    completedSteps.clear();
    if (base_data.isMember("completed_steps") && base_data["completed_steps"].isArray()) {
        for (const auto &v : base_data["completed_steps"]) {
            if (v.isInt()) {
                completedSteps.insert(static_cast<LdoWorkflowStep>(v.asInt()));
            }
        }
    }
    if (base_data.isMember("back_annotated") && base_data["back_annotated"].isBool()) {
        back_annotated = base_data["back_annotated"].asBool();
    }
    if (base_data.isMember("parasitic_enabled") && base_data["parasitic_enabled"].isBool()) {
        parasitic_enabled = base_data["parasitic_enabled"].asBool();
    }
    maau::platform::FiledFromBaseData(base_data, pulledDspfPath, "pulled_dspf_path");
    // 结构变换页状态恢复（字段缺失时保持默认值，兼容旧 checkpoint）。
    maau::platform::FiledFromBaseData(base_data, transform_history, "transform_history");
    maau::platform::FiledFromBaseData(base_data, transform_generated, "transform_generated");
    maau::platform::FiledFromBaseData(base_data, transform_finalized, "transform_finalized");
    maau::platform::FiledFromBaseData(base_data, transformed_lcv_lib, "transformed_lcv_lib");
    maau::platform::FiledFromBaseData(base_data, transformed_lcv_cell, "transformed_lcv_cell");
    maau::platform::FiledFromBaseData(base_data, transformed_lcv_view, "transformed_lcv_view");
    maau::platform::FiledFromBaseData(base_data, transformed_cds_path, "transformed_cds_path");
    maau::platform::FiledFromBaseData(base_data, transform_dut_cell, "transform_dut_cell");
}

}  // namespace ldo
}  // namespace gui
}  // namespace maau
