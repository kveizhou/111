#ifndef MAAU_GUI_WIDGETS_LDO_GENERATOR_PAGES_LDO_STRUCTURE_TRANSFORM_PAGE_H
#define MAAU_GUI_WIDGETS_LDO_GENERATOR_PAGES_LDO_STRUCTURE_TRANSFORM_PAGE_H

#include <QButtonGroup>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPushButton>
#include <QRadioButton>
#include <QSpinBox>
#include <QString>
#include <QToolButton>
#include <QWidget>
#include <map>
#include <set>
#include <string>
#include <vector>

#include <QtConcurrent/QtConcurrent>
#include <QFutureWatcher>
#include <QMessageBox>

#include "widgets/common/waitingwidget.h"

#include "modules/st_engine/structure_transform_service.h"
#include "widgets/ldo_generator/datadefine/ldo_data_types.h"
#include "widgets/ldo_generator/ldo_workflow_context.h"

namespace maau {
namespace gui {
namespace ldo {

// LdoTransformChange 已移至 datadefine/ldo_data_types.h（LdoCaseState 持久化
// 需要引用它，放页面头文件会造成 context → page → context 循环包含）。
// 本头通过 ldo_data_types.h 拿到定义。

// The in-progress (unconfirmed) transform being edited before "确认变换".
struct LdoTransformDraft {
    std::string type;
    bool customSize = false;  // false = 使用原管尺寸, true = 自定义 W/L
    std::string w;
    std::string wf;
    std::string nf;
    std::string l;
    std::string r;  // 电阻值（仅"替换成电阻"类型用）
    int stages = 2;
    std::string newMaster;  // 异型 Cascode 候选 master（用户从下拉选）
};

class LdoStructureTransformPage : public QWidget {
    Q_OBJECT
public:
    explicit LdoStructureTransformPage(LdoWorkflowContext *context,
                                       QWidget *parent = nullptr);
    // Called when the 结构变换 tab becomes active; loads the original schematic.
    void loadOnTabEnter();

private:
    void setupUi();
    QWidget *createLeftColumn(QWidget *parent);
    QWidget *createTransformConfigCard(QWidget *parent);
    QWidget *createPreviewCard(QWidget *parent);
    QWidget *createActionButtons(QWidget *parent);

    void applyDraft();
    // 生成电路预览：lockAsFinal=false（确认变换后立即预览），
    // lockAsFinal=true（生成最终电路，锁定为调优输入）。
    void generateCircuit(bool lockAsFinal);
    void undoLast();
    void resetToFresh();
    // 收集 history 涉及的 OA cell 集合（DUT 顶层 cell + 各变换目标叶子层 cell），
    // 供 FinalizeTransform / DiscardTransformViews 按 cell 维度提升/清理后缀 view。
    // 返回 (lib, cell) 对：各叶子层 cell 可能属于不同 lib，不能用统一 target_dut_lib。
    std::vector<std::pair<std::string, std::string>> collectTransformCells(
        const maau::stengine::StructureTransformConfig &config) const;
    // "生成最终电路"成功后台阶段：物化 view 已生成，调用 FinalizeTransform 把
    // history 涉及 cell 的 __maau_struct_transform 后缀 view 提升覆盖回原 view。
    void finalizeTransformViews(
        const maau::stengine::StructureTransformConfig &config);
    // "恢复初始"后台阶段：调用 DiscardTransformViews 删除所有后缀 view。
    void discardTransformViews(
        const maau::stengine::StructureTransformConfig &config);
    void refreshStatusMessage(const QString &message);
    // No device data wired yet: all type buttons stay disabled so the user
    // cannot stage a transform with nothing to apply it to.
    void refreshTypeButtons();
    void refreshDraftControls();
    // 根据原管及当前异型候选 master 的真实 CDF 切换尺寸输入。
    std::string currentParameterMode() const;
    // 扫描当前 DUT 电路的 MOS 清单并填充器件列表（主流程 NetlistBuilder 实现）。
    void scanMosDevices();
    // 把当前页面结构变换状态（history/产物 LCV/finalized/dutCell）写回
    // active case 的 LdoCaseState（checkpoint 据此持久化）。history 变更点
    // （applyDraft/撤销/恢复初始/生成成功）调用。
    void syncTransformStateToContext();
    // 从 active case 的 LdoCaseState 恢复结构变换状态（loadOnTabEnter 时调用，
    // 在 scanMosDevices 之后执行——器件列表填充后 refreshDeviceListLabels 才能
    // 把恢复的 history 反映为"已修改"标记）。
    void restoreTransformStateFromContext();
    // 构造 StructureTransformConfig（scanMosDevices 与 generateCircuit 共用，
    // 保证扫描与生成的网表源一致）。
    void makeStructureConfig(const LdoCaseItem &caseItem,
                             maau::stengine::StructureTransformConfig &config);
    // 根据 m_history 刷新器件列表标签：已修改的 MOS 标记"（已修改）"并禁用选中。
    void refreshDeviceListLabels();
    // 重新填充器件列表（排序切换时调用）。descending=true 降序（深→浅）。
    void refillDeviceList(bool descending);
    // 打开变换后的 staging 电路到预览容器。
    void openTransformedSchematic();
    // 把 Virtuoso 窗口（wId）嵌入预览容器。
    void embedWindow(uint64_t wId);

    // Opens the original-structure schematic into the preview container via
    // the same protocol path as multi_tb_circuit_widget.cpp:openSchematic.
    void openOriginalSchematic();
    void clearSchematicContainer();
    // 统一嵌入 Virtuoso 窗口（wId）到预览容器：清容器 → fromWinId →
    // createWindowContainer。wId==0 时跳过（防"正确显示后瞬间消失"的未定义
    // 行为）。openSchematicLcv / openTransformedSchematic 共用。
    void embedSchematicWindow(uint64_t wId);

    // 程序路径强制切换视图（撤销/重置/生成成功回调用）。
    // 规避 QToolButton::setChecked 同值 no-op 不发 toggled 的静默路径：
    // 按钮已 checked 时直接调 openXxxSchematic 显式刷新，否则 setChecked
    // 触发 toggled 走正常路径。
    void showTransformedView();
    void showOriginalView();
    // 打开指定 LCV 到"变换后"预览容器（选中已修改 MOS 时展示其所在 cell 的
    // 物化 view 用）。view 命名规则：同 lib/cell 下的 <base_view>__maau_struct_transform。
    void openSchematicLcv(const std::string &lib, const std::string &cell,
                          const std::string &view);
    // 更新预览卡标题为"<前缀>：lib|cell|view"；original=true 前缀"原结构电路预览"
    // （LCV 为顶层 DUT），false 前缀"变换后电路预览"（LCV 为叶子层物化）。
    // 空 LCV 时仅显示前缀。
    void updatePreviewTitle(const std::string &lib, const std::string &cell,
                            const std::string &view, bool original = false);
    // 根据当前选中 MOS 是否在 history 中，更新"确认变换"按钮与配置区可用性。
    // 同一 device 不可重复变换：已修改项可选中浏览，但确认按钮与配置区禁用。
    void refreshApplyEnabled();
    // 排序按钮左侧"已修改"过滤勾选状态变化：勾选时列表只显示已修改项。
    void refillDeviceListFiltered();
    // 右键菜单"撤销修改"：从 history 移除指定 device 的变换并重新生成预览
    // （叠加式重放剩余 history，内部带 loading）。
    void removeHistoryAndRegenerate(const std::string &deviceId);
    // 撤销某 device 后，若其所在 cell 已无剩余变换，后台删除该 cell 的
    // __maau_struct_transform 后缀 view（孤立物化产物）。parent_subckt 查不到
    // 时回退 m_transformedLcvCell（叶子层物化 cell），保证残留可被清理。
    void discardOrphanTransformView(const std::string &deviceId);

    LdoWorkflowContext *m_context = nullptr;

    QListWidget *m_deviceList = nullptr;
    QButtonGroup *m_typeGroup = nullptr;
    QWidget *m_typeButtons = nullptr;
    QRadioButton *m_useOriginalSize = nullptr;
    QRadioButton *m_customSize = nullptr;
    QWidget *m_sizeModeRow = nullptr; // 使用原管尺寸/自定义W-L radio 行容器（电阻类型隐藏）
    QLineEdit *m_wEdit = nullptr;
    QLineEdit *m_wfEdit = nullptr;
    QLineEdit *m_nfEdit = nullptr;
    QLineEdit *m_lEdit = nullptr;
    QLineEdit *m_rEdit = nullptr;
    QWidget *m_wlRow = nullptr;    // W/L 行容器
    QWidget *m_wfnflRow = nullptr; // WF/NF/L 行容器
    QLabel *m_parameterModeLabel = nullptr;
    QWidget *m_resistorRow = nullptr; // R 行容器（替换成电阻类型显示）
    QSpinBox *m_stagesSpin = nullptr;
    // 级数 N 行：仅 Stack 串联类型显示，其余类型隐藏。
    QWidget *m_stagesRow = nullptr;
    QComboBox *m_candidateCombo = nullptr;  // 异型 Cascode 候选 MOS 下拉
    QWidget *m_candidateRow = nullptr;      // 候选 MOS 下拉行容器（仅异型 Cascode 显示）
    // 变换配置区根容器（变换类型 + 新器件属性），选中已修改 MOS 时整体禁用。
    QWidget *m_configCard = nullptr;
    QStringList m_candidateMasters;          // 当前选中 MOS 的候选 master 列表
    QToolButton *m_showOriginalBtn = nullptr;
    QToolButton *m_showTransformedBtn = nullptr;
    QWidget *m_schematicContainer = nullptr;
    // 预览卡标题标签（"变换后电路预览"），打开视图后追加当前 LCV。
    QLabel *m_previewTitleLabel = nullptr;
    QLabel *m_statusLabel = nullptr;
    QPushButton *m_applyButton = nullptr;
    QPushButton *m_generateButton = nullptr;
    QPushButton *m_undoButton = nullptr;
    QPushButton *m_resetButton = nullptr;

    std::string m_selectedDeviceId;
    LdoTransformDraft m_draft;
    std::vector<LdoTransformChange> m_history;
    // DUT cell 名（ScanMos 从 TB 顶层提取，生成电路时作为网表顶层）。
    std::string m_dutCell;
    // 当前选中 MOS 的最终子模块 cell 名 + lib 名（Snapshot 以它为 source）。
    std::string m_parentSubckt;
    std::string m_parentLib;
    bool m_draftDirty = false;
    // 生成电路失败时是否回滚 m_history 尾部：applyDraft（确认变换）失败时回滚
    // 新加的那条；撤销后重新生成失败时不回滚（尾部是合法历史，不是新增）。
    bool m_rollbackTailOnFail = false;
    // 本次 generateCircuit 是否由撤销修改触发：true 时生成完成的提示文案
    // 应为"撤销完成"而非"生成电路成功"，且不弹成功信息框。
    bool m_undoRegenerate = false;
    bool m_showOriginal = true;
    // 扫描得到的 DUT MOS 清单（instance -> 器件信息），供按钮可用性判断。
    std::map<std::string, maau::stengine::StructureMosDevice> m_scanDevices;
    // 首次扫描后置位，避免每次进入重复扫描。
    bool m_scanLoaded = false;
    // 变换后电路的 LCV + cds 路径（generateCircuit 成功后填，"变换后"按钮用）。
    bool m_transformGenerated = false;
    // 变换结果已锁定为最终版（"生成最终电路"后置位）。
    bool m_finalized = false;
    std::string m_transformedLcvLib;
    std::string m_transformedLcvCell;
    std::string m_transformedLcvView;
    std::string m_transformedCdsPath;
    // OpenVirtuosoWindow spawns a standalone window; call it once and reuse the
    // running server on later view switches via GetSchematicWindowId.
    bool m_virtuosoOpened = false;
    // True while the original-structure schematic is embedded; loadOnTabEnter
    // skips re-embedding (and the embed flash) when it is already showing.
    bool m_originalLoaded = false;
    // 排序后的器件列表（供排序切换时重新填充）。
    struct MosListItem {
        std::string displayPath;
        std::string fullPath;
        std::string polarity;
        std::string master;
    };
    std::vector<MosListItem> m_sortedItems;
    QPushButton *m_sortButton = nullptr;
    // "已修改"过滤勾选按钮：勾选后列表只显示已修改项。无已修改项时置灰。
    QPushButton *m_modifiedFilterButton = nullptr;
    // MOS 列表搜索框：按显示路径/极性/master 名做不区分大小写的子串过滤，
    // 空串表示不过滤。refillDeviceList 在填充时统一应用。
    QLineEdit *m_deviceSearchEdit = nullptr;
    // 当前选中的 MOS 是否已在 history（已修改）中。已修改项可浏览但不可再变换。
    bool m_selectedIsModified = false;
};

}  // namespace ldo
}  // namespace gui
}  // namespace maau

#endif  // MAAU_GUI_WIDGETS_LDO_GENERATOR_PAGES_LDO_STRUCTURE_TRANSFORM_PAGE_H
