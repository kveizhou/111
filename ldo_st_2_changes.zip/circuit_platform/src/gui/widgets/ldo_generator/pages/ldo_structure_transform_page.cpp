#include "widgets/ldo_generator/pages/ldo_structure_transform_page.h"

#include <QDir>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QMenu>
#include <QSizePolicy>
#include <QTimer>
#include <QVBoxLayout>
#include <QWindow>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <filesystem>

#include "modules/st_engine/st/Netlist.h"
#include "service/access/virtuoso_process.h"
#include "widgets/ldo_generator/datadefine/ldo_data_types.h"
#include "widgets/ldo_generator/ldo_generator_log.h"
#include "widgets/project/design_compiler_path_manager.h"

namespace maau {
namespace gui {
namespace ldo {
namespace {

// 修改原因：stod 会把 10k/10n 都读成 10；R 和 W/L 复用引擎的工程单位解析。
// 沿用引擎约定：k/K、n/N、u/U 等价，m=1e-3，M=1e6。
bool ParseTransformValue(const std::string &text, double &value)
{
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) { return false; }
    const auto last = text.find_last_not_of(" \t\r\n");
    bool parsed = false;
    value = st::parseSuffixValue(text.substr(first, last - first + 1), parsed);
    return parsed && std::isfinite(value) && value > 0.0;
}

struct TransformTypeInfo {
    std::string id;
    QString label;    // 按钮文本（英文）
    QString tooltip;  // 鼠标停留提示（中文描述）
};

// Fixed transform-type enum, front-end only (from the .octo prototype).
// 按钮文本用英文，tooltip 保留原中文描述。
const std::vector<TransformTypeInfo> kTransformTypes = {
    {"same_cascode", QStringLiteral("Same-type Cascode"),
     QStringLiteral("同型 Cascode：在原管上串联同型 MOS")},
    {"cross_cascode", QStringLiteral("Cross-type Cascode"),
     QStringLiteral("异型 Cascode：在原管上串联异型 MOS（需选候选管）")},
    {"resistor", QStringLiteral("Source Resistor"),
     QStringLiteral("Source 串电阻：在原管源极串联电阻")},
    {"stack", QStringLiteral("Stack Series"),
     QStringLiteral("Stack 串联：把原管替换为 N 级串联 MOS")},
};

// 变换类型 id → 简短中文名（撤销确认弹窗用）。
QString TransformTypeDisplayName(const std::string &id)
{
    if (id == "same_cascode") {
        return QStringLiteral("同型 Cascode");
    }
    if (id == "cross_cascode") {
        return QStringLiteral("异型 Cascode");
    }
    if (id == "resistor") {
        return QStringLiteral("Source 串电阻");
    }
    if (id == "stack") {
        return QStringLiteral("Stack 串联");
    }
    return QString::fromStdString(id);
}

QFrame *card(QWidget *parent)
{
    auto *frame = new QFrame(parent);
    frame->setStyleSheet(
        "QFrame { background:#252526; border:1px solid #3d3d3d;"
        " border-radius:6px; }");
    return frame;
}

QLabel *cardTitle(const QString &text, QWidget *parent)
{
    auto *label = new QLabel(text, parent);
    label->setStyleSheet(
        "font-size:13px; font-weight:600; color:#ffffff;"
        " font-family:\"Microsoft Yahei\"; background:transparent;");
    return label;
}

// 补全结构变换的 launcher 与 SKILL 目录。python 入口是 .so，只能由
// main_opt.py import，因此统一经 maau_opt 分发；解析逻辑集中在
// StructureTransformService，GUI 不再自行推导路径。
void fillConfigFromSkillPath(maau::stengine::StructureTransformConfig &config)
{
    maau::stengine::ResolveStructureTransformScripts(config);
}

}  // namespace

LdoStructureTransformPage::LdoStructureTransformPage(
    LdoWorkflowContext *context, QWidget *parent)
    : QWidget(parent), m_context(context)
{
    setupUi();
}

void LdoStructureTransformPage::loadOnTabEnter()
{
    if (m_originalLoaded && m_showOriginal) {
        // 电路已加载但尚未扫描 MOS（首次进入）时补齐扫描。
        if (!m_scanLoaded) {
            scanMosDevices();
        }
        return;
    }
    m_showOriginal = true;
    {
        const QSignalBlocker blocker(m_showOriginalBtn);
        m_showOriginalBtn->setChecked(true);
    }
    openOriginalSchematic();
    if (!m_scanLoaded) {
        scanMosDevices();
    }
}

void LdoStructureTransformPage::makeStructureConfig(
    const LdoCaseItem &caseItem, maau::stengine::StructureTransformConfig &config)
{
    config.target_cds_path = caseItem.copy_cds_path;
    // source_dut_*：Snapshot 打开用的 cell（caseItem.schematic_cell 在 OA 库
    // 真实存在、能打开，如 ldo1_0_cbb_top）。不能用它当解析起点（它是 TB 顶层，
    // 不含 DUT 子模块定义）。
    config.source_dut_lib = caseItem.schematic_lib;
    config.source_dut_cell = caseItem.schematic_cell;
    config.source_dut_view = caseItem.schematic_view.empty()
        ? std::string("schematic") : caseItem.schematic_view;
    // target_dut_cell：层级解析起点（ScanMos 从 source 顶层提取的 DUT core_subckt，
    // 如 oa_..._rv100）。Snapshot 导出的全展开网表里有它的 subckt 定义。
    config.target_dut_lib = caseItem.schematic_lib;
    config.target_dut_cell = m_dutCell.empty()
        ? caseItem.schematic_cell : m_dutCell;
    config.target_dut_view = caseItem.schematic_view.empty()
        ? std::string("schematic") : caseItem.schematic_view;
    // 变换所在子模块：支持跨子模块叠加变换，Snapshot 从 DUT 顶层（source_dut_cell）
    // 递归导出全展开网表，baseline 含全部子模块定义，任意 MOS 都可由完整层次
    // 路径逐层定位。transform_subckt 保持为空走多层级物化分支。
    config.transform_subckt.clear();
    config.transform_lib.clear();
    config.target_tech = caseItem.tech;
    // Cascode 真实 DC 必须使用当前编辑 TB；没有编辑焦点时只接受唯一勾选 TB。
    std::string selectedTbId = caseItem.selected_tb_id;
    if (selectedTbId.empty() && caseItem.selected_tb_ids.size() == 1) {
        selectedTbId = caseItem.selected_tb_ids.front();
    }
    const LdoTbNode *selectedTb = nullptr;
    for (const auto &tb : caseItem.tb_list) {
        if (!selectedTbId.empty() && tb.tb_id == selectedTbId) {
            selectedTb = &tb;
            break;
        }
    }
    if (selectedTb != nullptr) {
        config.source_tb_lib = config.target_tb_lib = selectedTb->lib;
        config.source_tb_cell = config.target_tb_cell = selectedTb->cell;
        config.source_tb_view = config.target_tb_view = selectedTb->view;
        config.pvt_corners.clear();
        for (const auto &corner : selectedTb->corners) {
            if (!corner.selected || corner.name.empty()) continue;
            if (config.corner.empty()) config.corner = corner.name;
            if (!config.pvt_corners.empty()) config.pvt_corners += ',';
            config.pvt_corners += corner.name;
        }
    }
    // 中间产物写入 LDO 项目目录（ldo_generator 文件夹）下的 st_engine 子目录，
    // 不写入只读的原电路目录（copy_cds_path 仅作网表生成输入）。
    project::DesignCompilerPathManager pathManager;
    config.work_dir = (pathManager.GetLdoProjectPath() + "/st_engine").toStdString();
    // launcher 与 SKILL 目录统一由 ResolveStructureTransformScripts 解析，
    // GUI 不再自行推导路径。
    const char *optAlgoRoot = std::getenv("OPT_ALGO_ROOT");
    if (optAlgoRoot != nullptr) {
        config.opt_algo_root = optAlgoRoot;
    }
    fillConfigFromSkillPath(config);
}

void LdoStructureTransformPage::scanMosDevices()
{
    if (m_context == nullptr) {
        return;
    }
    LdoSpecSelectionData selection;
    if (!m_context->specSelection(selection)) {
        refreshStatusMessage(QStringLiteral("缺少 Case 选择，无法扫描 MOS。"));
        return;
    }
    const auto &caseItem = selection.selected_candidate.case_item;
    if (caseItem.copy_cds_path.empty() ||
        caseItem.schematic_lib.empty() || caseItem.schematic_cell.empty()) {
        refreshStatusMessage(QStringLiteral("缺少电路信息（copy_cds_path 或 DUT LCV），无法扫描 MOS。"));
        return;
    }

    maau::stengine::StructureTransformConfig config;
    makeStructureConfig(caseItem, config);

    maau::stengine::StructureTransformService service;
    auto scan = service.ScanMos(config);
    m_scanDevices.clear();
    m_deviceList->clear();
    if (!scan.ok) {
        GUI_LDO_LOG(ERROR) << "structure-transform scan MOS failed: "
                           << scan.message;
        // 状态栏显示精简失败原因，便于定位；完整信息在日志中。
        refreshStatusMessage(QStringLiteral("扫描 MOS 失败：%1")
                                 .arg(QString::fromStdString(scan.message)));
        return;
    }
    // 记录 DUT cell 名（ScanMos 从 TB 顶层提取），生成电路时作为网表顶层。
    m_dutCell = scan.core_subckt;
    // 把扫描到的器件父层信息摘出来打日志：deviceId → parent_lib/parent_subckt
    // 的映射是 discardOrphanTransformView 定位孤立 view 的输入，扫描缺失/路径
    // 不匹配时该映射查不到（撤销后 view 删不掉的常见根因），需要可见。
    {
        std::size_t withParent = 0;
        std::string sample;
        for (const auto &device : scan.devices) {
            if (!device.parent_subckt.empty()) {
                ++withParent;
                if (sample.size() < 400) {
                    if (!sample.empty()) sample += "; ";
                    sample += device.instance + "->" + device.parent_lib + "/" +
                              device.parent_subckt;
                }
            }
        }
        GUI_LDO_LOG(INFO)
            << "structure-transform scan: total=" << scan.devices.size()
            << ", with_parent_subckt=" << withParent
            << ", sample: " << sample;
    }
    // 只显示 LDO 主功能核心 ldo_top 分支下的 MOS（结构变换优化的目标范围），
    // 其余辅助/测试电路（ldo_ls / ldo_dft / 顶层散落阵列等）不出现在选择列表中，
    // 避免误选无关器件。device.instance 是点分隔层次路径（DUT 顶层起步，
    // 如 ldo_top.I52.I35<4>.M2<1>），叶子 MOS 一定带 ldo_top 前缀。
    const std::string kTopBranchPrefix = "ldo_top";
    const std::size_t kPrefixLen = kTopBranchPrefix.size() + 1; // "ldo_top."
    // 先收集到临时列表，排序后再加到 m_deviceList。
    std::vector<MosListItem> items;
    for (const auto &device : scan.devices) {
        const std::string &inst = device.instance;
        const bool inTopBranch =
            inst == kTopBranchPrefix ||
            (inst.size() > kTopBranchPrefix.size() &&
             inst.compare(0, kTopBranchPrefix.size(), kTopBranchPrefix) == 0 &&
             inst[kTopBranchPrefix.size()] == '.');
        if (!inTopBranch) {
            continue;
        }
        m_scanDevices.emplace(device.instance, device);
        const std::string polarity = (device.kind == st::DeviceKind::MosN)
            ? "NMOS"
            : (device.kind == st::DeviceKind::MosP) ? "PMOS" : "MOS";
        // 去掉 ldo_top. 前缀（保留点分隔，去掉第一段）。
        std::string display = inst;
        if (display.size() > kPrefixLen &&
            display.compare(0, kPrefixLen, kTopBranchPrefix + ".") == 0) {
            display = display.substr(kPrefixLen);
        }
        // 显示用 "/" 分隔层次路径（如 I50/M2），把 bus 下标 <n> 美化为 [n]。
        std::string compressed;
        compressed.reserve(display.size());
        for (char c : display) {
            if (c == '.') compressed.push_back('/');
            else if (c == '<') compressed.push_back('[');
            else if (c == '>') compressed.push_back(']');
            else compressed.push_back(c);
        }
        items.push_back({compressed, inst, polarity, device.master});
    }
    // 兜底: 若 ldo_top 前端未命中任何器件 (不同 netlist 的 DUT 内部层次命名
    // 不一定包含 ldo_top 实例, 如 test_ldo_4 的 DUT 内部为 IO/I2/I4/I1),
    // 则展示全部扫描到的 MOS, 避免列表为空让用户误以为扫描未执行。
    const bool prefixMissed = items.empty() && !scan.devices.empty();
    if (prefixMissed) {
        for (const auto &device : scan.devices) {
            const std::string &inst = device.instance;
            m_scanDevices.emplace(device.instance, device);
            const std::string polarity = (device.kind == st::DeviceKind::MosN)
                ? "NMOS"
                : (device.kind == st::DeviceKind::MosP) ? "PMOS" : "MOS";
            std::string display = inst;
            std::string compressed;
            compressed.reserve(display.size());
            for (char c : display) {
                if (c == '.') compressed.push_back('/');
                else if (c == '<') compressed.push_back('[');
                else if (c == '>') compressed.push_back(']');
                else compressed.push_back(c);
            }
            items.push_back({compressed, inst, polarity, device.master});
        }
    }
    // 默认按路径由短到长排序（浅层 MOS 在前，深层在后），便于快速浏览。
    std::sort(items.begin(), items.end(),
              [](const MosListItem &a, const MosListItem &b) {
                  return a.displayPath < b.displayPath;
              });
    // 保存排序后的 items 供排序切换用（m_sortedItems）。
    m_sortedItems = items;
    // 填充列表（默认升序）。走 refillDeviceList 以复用搜索过滤逻辑——
    // 避免扫描完成时搜索框里已有词但列表未过滤的不一致状态。
    refillDeviceList(false);
    m_scanLoaded = true;
    // 扫描完成后从 checkpoint 恢复 history/产物 LCV/finalized 等（必须在器件
    // 列表填充之后：refreshDeviceListLabels 才能把恢复的 history 反映为
    // "已修改"标记；重复调用幂等——m_history 相同则标签不变）。
    restoreTransformStateFromContext();
    if (prefixMissed) {
        refreshStatusMessage(QString::fromStdString(
            "已扫描到 " + std::to_string(items.size()) +
            " 个 MOS (Ldo_top 前缀未命中, 已展示全部), 请选择器件并配置变换。"));
    } else {
        refreshStatusMessage(QString::fromStdString(
            "已扫描到 " + std::to_string(items.size()) +
            " 个 MOS (仅 ldo_top 分支), 请选择器件并配置变换。"));
    }
}

void LdoStructureTransformPage::syncTransformStateToContext()
{
    if (m_context == nullptr) {
        return;
    }
    const std::string &caseKey = m_context->activeCaseId();
    if (caseKey.empty()) {
        return;
    }
    m_context->setTransformState(
        caseKey, m_history, m_transformGenerated, m_finalized,
        m_transformedLcvLib, m_transformedLcvCell, m_transformedLcvView,
        m_transformedCdsPath, m_dutCell, m_packagedCells);
}

void LdoStructureTransformPage::restoreTransformStateFromContext()
{
    if (m_context == nullptr) {
        return;
    }
    const std::string &caseKey = m_context->activeCaseId();
    if (caseKey.empty()) {
        return;
    }
    std::vector<LdoTransformChange> history;
    bool generated = false;
    bool finalized = false;
    std::string lib;
    std::string cell;
    std::string view;
    std::string cdsPath;
    std::string dutCell;
    std::vector<LdoPackagedCell> packagedCells;
    if (!m_context->transformStateFor(caseKey, history, generated, finalized,
                                      lib, cell, view, cdsPath, dutCell,
                                      packagedCells)) {
        return;
    }
    m_history = std::move(history);
    m_transformGenerated = generated;
    m_finalized = finalized;
    m_transformedLcvLib = std::move(lib);
    m_transformedLcvCell = std::move(cell);
    m_transformedLcvView = std::move(view);
    m_transformedCdsPath = std::move(cdsPath);
    m_packagedCells = std::move(packagedCells);
    if (!dutCell.empty()) {
        m_dutCell = std::move(dutCell);
    }
    // 器件列表已由 scanMosDevices 填充（restore 在其后调用），这里把恢复的
    // history 反映为"已修改"标记，并刷新确认/恢复按钮可用性。
    refreshDeviceListLabels();
    refreshApplyEnabled();
    // 已有生成结果时切到"变换后"预览，让重进页面直接看到最近一次变换产物。
    // showTransformedView 内部处理 setChecked 同值 no-op 与叶子层 cell 定位；
    // 视图不存在时由 openSchematicLcv 的 CellViewExists 校验兜底提示。
    if (m_transformGenerated && !m_transformedLcvView.empty()) {
        showTransformedView();
    }
}

void LdoStructureTransformPage::refillDeviceList(bool descending)
{
    // 保留当前选中的 deviceId，重新排序后恢复选中。
    QString selectedId;
    if (auto *cur = m_deviceList->currentItem()) {
        selectedId = cur->data(Qt::UserRole).toString();
    }
    m_deviceList->clear();
    auto items = m_sortedItems; // 拷贝排序
    if (descending) {
        std::sort(items.begin(), items.end(),
                  [](const auto &a, const auto &b) {
                      return a.displayPath > b.displayPath;
                  });
    } else {
        std::sort(items.begin(), items.end(),
                  [](const auto &a, const auto &b) {
                      return a.displayPath < b.displayPath;
                  });
    }
    // 搜索过滤：显示路径/极性/master 任一字段命中（不区分大小写子串）即保留。
    const QString searchText = m_deviceSearchEdit == nullptr
        ? QString() : m_deviceSearchEdit->text().trimmed();
    const auto matchesSearch = [&searchText](const MosListItem &item) {
        if (searchText.isEmpty()) {
            return true;
        }
        const QString needle = searchText.toLower();
        return QString::fromStdString(item.displayPath).toLower().contains(needle) ||
               QString::fromStdString(item.polarity).toLower().contains(needle) ||
               QString::fromStdString(item.master).toLower().contains(needle);
    };
    // "已修改"过滤：勾选后只保留 history 中出现的 deviceId。
    const bool onlyModified = m_modifiedFilterButton != nullptr &&
        m_modifiedFilterButton->isChecked();
    std::set<std::string> modifiedIds;
    if (onlyModified) {
        for (const auto &change : m_history) {
            modifiedIds.insert(change.deviceId);
        }
    }
    int selectRow = -1;
    for (const auto &item : items) {
        if (!matchesSearch(item)) {
            continue;
        }
        if (onlyModified && modifiedIds.count(item.fullPath) == 0) {
            continue;
        }
        auto *listItem = new QListWidgetItem(
            QString::fromStdString(item.displayPath) + "  [" +
            QString::fromStdString(item.polarity) + "] " +
            QString::fromStdString(item.master));
        listItem->setData(Qt::UserRole, QString::fromStdString(item.fullPath));
        m_deviceList->addItem(listItem);
        if (!selectedId.isEmpty() &&
            listItem->data(Qt::UserRole).toString() == selectedId) {
            selectRow = m_deviceList->count() - 1;
        }
    }
    if (selectRow >= 0) {
        m_deviceList->setCurrentRow(selectRow);
    }
    refreshDeviceListLabels();
}

void LdoStructureTransformPage::setupUi()
{
    setStyleSheet(
        "QWidget { color:#ffffff; font-family:\"Microsoft Yahei\"; }"
        "QLabel { font-family:\"Microsoft Yahei\"; }"
        "QLineEdit { background:#3c3c3c; border:1px solid #555;"
        " border-radius:4px; padding:5px; font-family:\"Microsoft Yahei\"; }"
        "QPushButton { background:#3c3c3c; border:1px solid #555;"
        " border-radius:4px; padding:6px 12px; font-family:\"Microsoft Yahei\"; }"
        "QPushButton:checked { background:#007acc; color:white; }"
        "QPushButton:disabled { background:#2a2a2a; color:#707070;"
        " border:1px solid #3b3b3b; }"
        "QRadioButton { font-family:\"Microsoft Yahei\"; }"
        "QRadioButton:disabled { color:#707070; }"
        "QSpinBox { background:#3c3c3c; border:1px solid #555;"
        " border-radius:4px; padding:3px; font-family:\"Microsoft Yahei\"; }"
        "QToolButton { font-family:\"Microsoft Yahei\"; padding:4px 10px;"
        " border:1px solid #555; border-radius:4px; background:#3c3c3c; }"
        "QToolButton:checked { background:#007acc; color:white; }"
        "QListWidget { background:#1e1e1e; border:1px solid #3d3d3d;"
        " border-radius:4px; font-family:\"Microsoft Yahei\"; }"
        "QListWidget::item { padding:4px 6px; }"
        "QListWidget::item:selected { background:#007acc; }");

    auto *outer = new QVBoxLayout(this);
    outer->setContentsMargins(0, 0, 0, 0);
    outer->setSpacing(12);

    // Left column: device list (top) + transform type (middle) + new device
    // attrs (bottom), stacked vertically per the .octo prototype. Right column:
    // circuit preview with original/transformed toggle.
    auto *columns = new QHBoxLayout();
    columns->setSpacing(12);
    columns->addWidget(createLeftColumn(this), 3);
    columns->addWidget(createPreviewCard(this), 7);
    outer->addLayout(columns, 1);

    outer->addWidget(createActionButtons(this));

    refreshTypeButtons();
    refreshDraftControls();
    refreshApplyEnabled();
    refreshStatusMessage(QStringLiteral("请选择 MOS 管并配置结构变换。"));
}

QWidget *LdoStructureTransformPage::createLeftColumn(QWidget *parent)
{
    auto *column = new QVBoxLayout();
    column->setSpacing(12);

    auto *deviceCard = card(parent);
    auto *deviceLayout = new QVBoxLayout(deviceCard);
    deviceLayout->setContentsMargins(10, 8, 10, 10);
    deviceLayout->setSpacing(8);
    // 标题行 + 排序按钮。
    auto *titleRow = new QHBoxLayout();
    titleRow->setSpacing(8);
    titleRow->addWidget(cardTitle(QStringLiteral("选择 MOS 管"), deviceCard));
    titleRow->addStretch();
    // "已修改"过滤勾选：勾选后列表只显示已修改项，再点取消恢复全部。
    m_modifiedFilterButton = new QPushButton(QStringLiteral("已修改"), deviceCard);
    m_modifiedFilterButton->setCheckable(true);
    m_modifiedFilterButton->setStyleSheet(
        "QPushButton { background:#3c3c3c; border:1px solid #555;"
        " border-radius:4px; padding:4px 10px; }"
        "QPushButton:checked { background:#007acc; color:white; }"
        "QPushButton:disabled { background:#2a2a2a; color:#707070;"
        " border:1px solid #3b3b3b; }");
    m_modifiedFilterButton->setToolTip(
        QStringLiteral("勾选后仅显示已修改的 MOS"));
    m_modifiedFilterButton->setEnabled(false);  // 初始无已修改项，置灰
    titleRow->addWidget(m_modifiedFilterButton);
    m_sortButton = new QPushButton(QStringLiteral("升序"), deviceCard);
    m_sortButton->setCheckable(true);
    m_sortButton->setStyleSheet(
        "QPushButton { background:#3c3c3c; border:1px solid #555;"
        " border-radius:4px; padding:4px 10px; }"
        "QPushButton:checked { background:#007acc; color:white; }");
    m_sortButton->setToolTip(QStringLiteral("点击切换升序/降序排列"));
    titleRow->addWidget(m_sortButton);
    deviceLayout->addLayout(titleRow);
    // 搜索框：按显示路径/极性/master 名做不区分大小写的子串过滤。
    m_deviceSearchEdit = new QLineEdit(deviceCard);
    m_deviceSearchEdit->setPlaceholderText(
        QStringLiteral("搜索 MOS（路径 / NMOS / PMOS / master 名）..."));
    m_deviceSearchEdit->setClearButtonEnabled(true);
    deviceLayout->addWidget(m_deviceSearchEdit);
    m_deviceList = new QListWidget(deviceCard);
    m_deviceList->setMinimumHeight(140);
    // 搜索词变化时按当前排序状态重新填充（refillDeviceList 同时应用过滤）。
    connect(m_deviceSearchEdit, &QLineEdit::textChanged, this, [this](const QString &) {
        refillDeviceList(m_sortButton != nullptr && m_sortButton->isChecked());
    });
    // 排序按钮：切换升序（浅→深）/降序（深→浅）。
    connect(m_sortButton, &QPushButton::toggled, this, [this](bool checked) {
        m_sortButton->setText(checked ? QStringLiteral("降序")
                                      : QStringLiteral("升序"));
        refillDeviceList(checked);
    });
    // "已修改"过滤：勾选后列表只显示已修改项（refillDeviceList 统一应用）。
    connect(m_modifiedFilterButton, &QPushButton::toggled, this,
            [this](bool) { refillDeviceListFiltered(); });
    connect(m_deviceList, &QListWidget::currentTextChanged, this,
            [this](const QString &text) {
                GUI_LDO_LOG(INFO)
                    << "structure-transform device selection changed: text="
                    << text.toStdString();
                if (text.isEmpty()) {
                    m_selectedDeviceId.clear();
                    m_selectedIsModified = false;
                } else {
                    // 显示文本仅供阅读（去掉了 ldo_top 前缀 + <> → []），
                    // 真实 deviceId（完整点分隔路径，含 ldo_top 前缀 + <> 下标）
                    // 存于 UserRole，变换必须用它精确定位子模块内 MOS。
                    auto *item = m_deviceList->currentItem();
                    const QVariant role =
                        item == nullptr ? QVariant() : item->data(Qt::UserRole);
                    if (!role.isValid()) {
                        m_selectedDeviceId.clear();
                        m_selectedIsModified = false;
                        refreshTypeButtons();
                        refreshApplyEnabled();
                        return;
                    }
                    m_selectedDeviceId = role.toString().toStdString();
                    // 判断选中项是否已修改（在 history 中）：已修改项可浏览，
                    // 但同一 device 不可重复变换（确认按钮/配置区禁用）。
                    m_selectedIsModified = std::any_of(
                        m_history.begin(), m_history.end(),
                        [this](const LdoTransformChange &c) {
                            return c.deviceId == m_selectedDeviceId;
                        });
                    // 填充异型 Cascode 候选 MOS 下拉 + 记录最终子模块。
                    m_candidateMasters.clear();
                    const auto deviceIt = m_scanDevices.find(m_selectedDeviceId);
                    if (deviceIt != m_scanDevices.end()) {
                        m_parentSubckt = deviceIt->second.parent_subckt;
                        m_parentLib = deviceIt->second.parent_lib;
                        for (const auto &candidate : deviceIt->second.cross_flavor_candidates) {
                            m_candidateMasters.append(QString::fromStdString(candidate));
                        }
                    } else {
                        m_parentSubckt.clear();
                        m_parentLib.clear();
                    }
                    if (m_candidateCombo != nullptr) {
                        m_candidateCombo->clear();
                        m_candidateCombo->addItems(m_candidateMasters);
                    }
                    m_draft.newMaster.clear();
                    // 已修改项的预览改为右键菜单"预览"触发，选中时不再自动切换视图。
                }
                m_draftDirty = false;
                refreshTypeButtons();
                refreshApplyEnabled();
                refreshDraftControls();
            });
    // 右键菜单：仅对已修改项提供"预览"/"撤销修改"。
    m_deviceList->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(m_deviceList, &QListWidget::customContextMenuRequested, this,
            [this](const QPoint &pos) {
                auto *item = m_deviceList->itemAt(pos);
                if (item == nullptr) {
                    return;
                }
                const QVariant role = item->data(Qt::UserRole);
                if (!role.isValid()) {
                    return;
                }
                const std::string deviceId = role.toString().toStdString();
                const auto histIt = std::find_if(
                    m_history.begin(), m_history.end(),
                    [&deviceId](const LdoTransformChange &c) {
                        return c.deviceId == deviceId;
                    });
                if (histIt == m_history.end()) {
                    return;  // 未修改项不提供右键菜单
                }
                QMenu menu(this);
                menu.setStyleSheet(
                    "QMenu { background:#2d2d2d; color:#ffffff; border:1px solid #555;"
                    " font-family:\"Microsoft Yahei\"; }"
                    "QMenu::item:selected { background:#007acc; }");
                QAction *previewAction = menu.addAction(QStringLiteral("预览"));
                QAction *undoAction = menu.addAction(QStringLiteral("撤销修改"));
                QAction *chosen = menu.exec(m_deviceList->viewport()->mapToGlobal(pos));
                if (chosen == previewAction) {
                    // 预览：切到"变换后"并打开该器件所在 cell 的物化 view + 高亮器件。
                    const auto devIt = m_scanDevices.find(deviceId);
                    if (devIt == m_scanDevices.end() ||
                        devIt->second.parent_subckt.empty()) {
                        refreshStatusMessage(
                            QStringLiteral("无法定位已修改器件所在模块。"));
                        return;
                    }
                    if (!m_transformGenerated) {
                        refreshStatusMessage(
                            QStringLiteral("尚未生成变换后电路，请先点击[生成电路]。"));
                        return;
                    }
                    // 已修改 cell 的 lib 优先取扫描结果（parent_lib），空时回退
                    // 到变换后电路所在 lib（物化在同 lib/cell 下生成后缀 view）。
                    const std::string cellLib = devIt->second.parent_lib.empty()
                        ? m_transformedLcvLib : devIt->second.parent_lib;
                    // 打开前校验 view 存在（物化只克隆叶子层，部分 cell 无后缀
                    // view），不存在则提示并跳过，避免污染窗口服务器致黑窗。
                    if (!maau::protocol::CellViewExists(
                            cellLib, devIt->second.parent_subckt,
                            m_transformedLcvView)) {
                        GUI_LDO_LOG(WARNING)
                            << "structure-transform preview: modified cellview "
                               "not exists: "
                            << cellLib << "/" << devIt->second.parent_subckt
                            << "/" << m_transformedLcvView;
                        refreshStatusMessage(QStringLiteral(
                            "已修改模块的变换后视图不存在（%1/%2/%3），"
                            "可能该 cell 未被物化。")
                                .arg(QString::fromStdString(cellLib),
                                     QString::fromStdString(
                                         devIt->second.parent_subckt),
                                     QString::fromStdString(
                                         m_transformedLcvView)));
                        return;
                    }
                    // 不切"变换后"按钮（showTransformedView 内部 setChecked 会
                    // 触发 toggled → openTransformedSchematic，与下面的
                    // openSchematicLcv 重复打开同一 view，导致多窗口）。只同步
                    // 按钮视觉态 + 状态标志，实际打开由 openSchematicLcv 完成。
                    m_showOriginal = false;
                    m_originalLoaded = false;
                    if (m_showTransformedBtn != nullptr &&
                        !m_showTransformedBtn->isChecked()) {
                        // 阻断信号再 setChecked，避免触发 toggled 回调重复打开。
                        const QSignalBlocker blocker(m_showTransformedBtn);
                        m_showTransformedBtn->setChecked(true);
                    }
                    openSchematicLcv(cellLib, devIt->second.parent_subckt,
                                     m_transformedLcvView);
                    // 高亮：parent_subckt 是叶 MOS 的直接父 cell，相对于它的
                    // 路径就是 deviceId 的最后一段（叶 MOS 名，如 M2<1>）。
                    // highlight_inst_in_view 在 parent_subckt 的变换后 view 里
                    // 按叶名直接定位高亮。
                    const auto dotPos = deviceId.rfind('.');
                    const std::string leafName = dotPos == std::string::npos
                        ? deviceId : deviceId.substr(dotPos + 1);
                    maau::protocol::HighlightDeviceInView(
                        cellLib, devIt->second.parent_subckt,
                        m_transformedLcvView, leafName);
                    refreshStatusMessage(QString::fromStdString(
                        "已切换到已修改器件所在模块：" +
                        devIt->second.parent_subckt));
                } else if (chosen == undoAction) {
                    // 撤销修改：确认后从 history 移除并重新生成。
                    const QString deviceLabel = QString::fromStdString(deviceId);
                    const auto ret = QMessageBox::question(
                        this, tr("Structure Transform"),
                        tr("确认取消 %1 器件 %2 变换吗？")
                            .arg(deviceLabel,
                                 TransformTypeDisplayName(histIt->type)));
                    if (ret != QMessageBox::Yes) {
                        return;
                    }
                    removeHistoryAndRegenerate(deviceId);
                }
            });
    deviceLayout->addWidget(m_deviceList, 1);
    column->addWidget(deviceCard);

    column->addWidget(createTransformConfigCard(parent));

    column->addStretch();
    auto *wrapper = new QWidget(parent);
    wrapper->setLayout(column);
    return wrapper;
}

QWidget *LdoStructureTransformPage::createTransformConfigCard(QWidget *parent)
{
    auto *frame = card(parent);
    auto *layout = new QVBoxLayout(frame);
    layout->setContentsMargins(10, 8, 10, 10);
    layout->setSpacing(12);

    layout->addWidget(cardTitle(QStringLiteral("变换类型"), frame));
    m_typeGroup = new QButtonGroup(frame);
    m_typeGroup->setExclusive(true);
    m_typeButtons = new QWidget(frame);
    auto *typeLayout = new QVBoxLayout(m_typeButtons);
    typeLayout->setContentsMargins(0, 0, 0, 0);
    typeLayout->setSpacing(6);
    auto *typeRow1 = new QHBoxLayout();
    typeRow1->setSpacing(6);
    auto *typeRow2 = new QHBoxLayout();
    typeRow2->setSpacing(6);
    for (size_t i = 0; i < kTransformTypes.size(); ++i) {
        const auto &info = kTransformTypes[i];
        auto *btn = new QPushButton(info.label, m_typeButtons);
        btn->setCheckable(true);
        // id 存于 UserRole（不再占用 toolTip）；toolTip 留给中文描述。
        btn->setProperty("transformTypeId", QString::fromStdString(info.id));
        btn->setToolTip(info.tooltip);
        m_typeGroup->addButton(btn);
        (i < 3 ? typeRow1 : typeRow2)->addWidget(btn);
        // 替换成电阻不用 W/L：切到该类型时强制回"使用原管尺寸"并清空 W/L，
        // 避免残留的自定义尺寸/阻值干扰后续校验与请求构造。
        // 提取为 lambda 降低 lambda 内嵌套深度（codecheck: max-nesting-depth）。
        const auto applyResistorReset = [this]() {
            m_draft.customSize = false;
            m_draft.w.clear();
            m_draft.wf.clear();
            m_draft.nf.clear();
            m_draft.l.clear();
            if (m_useOriginalSize != nullptr) {
                m_useOriginalSize->setChecked(true);
            }
        };
        connect(btn, &QPushButton::toggled, this, [this, id = info.id, applyResistorReset](bool on) {
            if (on) {
                m_draft.type = id;
                m_draftDirty = true;
                if (id == "resistor") {
                    applyResistorReset();
                }
                refreshDraftControls();
                refreshStatusMessage(
                    QStringLiteral("已选择变换类型，请配置新器件属性。"));
            }
        });
    }
    typeRow1->addStretch();
    typeRow2->addStretch();
    typeLayout->addLayout(typeRow1);
    typeLayout->addLayout(typeRow2);
    layout->addWidget(m_typeButtons);

    layout->addWidget(cardTitle(QStringLiteral("新器件属性"), frame));
    auto *attrLayout = new QVBoxLayout();
    attrLayout->setSpacing(6);
    m_sizeModeRow = new QWidget(frame);
    auto *modeRow = new QHBoxLayout(m_sizeModeRow);
    modeRow->setContentsMargins(0, 0, 0, 0);
    m_useOriginalSize = new QRadioButton(
        QStringLiteral("使用原管尺寸"), frame);
    m_customSize = new QRadioButton(
        QStringLiteral("自定义 W / L"), frame);
    m_useOriginalSize->setChecked(true);
    modeRow->addWidget(m_useOriginalSize);
    modeRow->addWidget(m_customSize);
    modeRow->addStretch();
    attrLayout->addWidget(m_sizeModeRow);

    m_parameterModeLabel = new QLabel(frame);
    m_parameterModeLabel->setWordWrap(true);
    attrLayout->addWidget(m_parameterModeLabel);

    // 两种工艺显示各自的真实 CDF 参数，绝不同时提交 W 和 WF。
    m_wlRow = new QWidget(frame);
    auto *wlLayout = new QHBoxLayout(m_wlRow);
    wlLayout->setContentsMargins(0, 0, 0, 0);
    wlLayout->addWidget(new QLabel(QStringLiteral("W:"), m_wlRow));
    m_wEdit = new QLineEdit(m_wlRow);
    m_wEdit->setPlaceholderText(QStringLiteral("如 1200u"));
    wlLayout->addWidget(m_wEdit);
    wlLayout->addSpacing(8);
    wlLayout->addWidget(new QLabel(QStringLiteral("L:"), m_wlRow));
    m_lEdit = new QLineEdit(m_wlRow);
    m_lEdit->setPlaceholderText(QStringLiteral("如 0.5u"));
    wlLayout->addWidget(m_lEdit);
    wlLayout->addStretch();
    m_wlRow->setVisible(false);
    attrLayout->addWidget(m_wlRow);

    m_wfnflRow = new QWidget(frame);
    auto *wfnflLayout = new QHBoxLayout(m_wfnflRow);
    wfnflLayout->setContentsMargins(0, 0, 0, 0);
    wfnflLayout->addWidget(new QLabel(QStringLiteral("WF:"), m_wfnflRow));
    m_wfEdit = new QLineEdit(m_wfnflRow);
    m_wfEdit->setPlaceholderText(QStringLiteral("如 0.5u"));
    wfnflLayout->addWidget(m_wfEdit);
    wfnflLayout->addWidget(new QLabel(QStringLiteral("NF:"), m_wfnflRow));
    m_nfEdit = new QLineEdit(m_wfnflRow);
    m_nfEdit->setPlaceholderText(QStringLiteral("正整数，如 4"));
    wfnflLayout->addWidget(m_nfEdit);
    wfnflLayout->addWidget(new QLabel(QStringLiteral("L:"), m_wfnflRow));
    m_lEdit = new QLineEdit(m_wfnflRow);
    m_lEdit->setPlaceholderText(QStringLiteral("如 0.03u"));
    wfnflLayout->addWidget(m_lEdit);
    wfnflLayout->addStretch();
    m_wfnflRow->setVisible(false);
    attrLayout->addWidget(m_wfnflRow);

    // R 行（替换成电阻类型显示）
    m_resistorRow = new QWidget(frame);
    auto *rLayout = new QHBoxLayout(m_resistorRow);
    rLayout->setContentsMargins(0, 0, 0, 0);
    rLayout->addWidget(new QLabel(QStringLiteral("R:"), m_resistorRow));
    m_rEdit = new QLineEdit(m_resistorRow);
    m_rEdit->setPlaceholderText(QStringLiteral("如 10k"));
    // 修改原因：明确区分 m（毫）和 M（兆），避免大小写造成阻值误解。
    m_rEdit->setToolTip(QStringLiteral("单位为 Ω；支持 k/K、n/N、u/U，m=毫，M=兆，以及科学计数法。"));
    rLayout->addWidget(m_rEdit);
    rLayout->addStretch();
    m_resistorRow->setVisible(false);
    attrLayout->addWidget(m_resistorRow);

    m_stagesRow = new QWidget(frame);
    auto *stagesLayout = new QHBoxLayout(m_stagesRow);
    stagesLayout->setContentsMargins(0, 0, 0, 0);
    stagesLayout->addWidget(new QLabel(QStringLiteral("级数 N:"), m_stagesRow));
    m_stagesSpin = new QSpinBox(m_stagesRow);
    m_stagesSpin->setRange(2, 100);
    m_stagesSpin->setValue(2);
    stagesLayout->addWidget(m_stagesSpin);
    stagesLayout->addStretch();
    // 仅 Stack 串联类型显示级数 N；其余类型默认隐藏。
    m_stagesRow->setVisible(false);
    attrLayout->addWidget(m_stagesRow);

    // 候选 MOS 下拉（异型 Cascode 新增管选择）
    m_candidateRow = new QWidget(frame);
    auto *candidateLayout = new QHBoxLayout(m_candidateRow);
    candidateLayout->setContentsMargins(0, 0, 0, 0);
    candidateLayout->addWidget(new QLabel(QStringLiteral("新增管:"), m_candidateRow));
    m_candidateCombo = new QComboBox(m_candidateRow);
    candidateLayout->addWidget(m_candidateCombo, 1);
    m_candidateRow->setVisible(false);
    attrLayout->addWidget(m_candidateRow);
    connect(m_candidateCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this](int index) {
                if (index >= 0 && index < m_candidateMasters.size()) {
                    m_draft.newMaster = m_candidateMasters[index].toStdString();
                    m_draftDirty = true;
                    refreshDraftControls();
                }
            });
    layout->addLayout(attrLayout);

    connect(m_useOriginalSize, &QRadioButton::toggled, this, [this](bool on) {
        if (on) {
            m_draft.customSize = false;
            m_draftDirty = true;
            refreshDraftControls();
        }
    });
    connect(m_customSize, &QRadioButton::toggled, this, [this](bool on) {
        if (on) {
            m_draft.customSize = true;
            m_draftDirty = true;
            refreshDraftControls();
        }
    });
    connect(m_wEdit, &QLineEdit::textChanged, this, [this](const QString &t) {
        m_draft.w = t.toStdString();
        m_draftDirty = true;
    });
    connect(m_wfEdit, &QLineEdit::textChanged, this, [this](const QString &t) {
        m_draft.wf = t.toStdString();
        m_draftDirty = true;
    });
    connect(m_nfEdit, &QLineEdit::textChanged, this, [this](const QString &t) {
        m_draft.nf = t.toStdString();
        m_draftDirty = true;
    });
    connect(m_lEdit, &QLineEdit::textChanged, this, [this](const QString &t) {
        m_draft.l = t.toStdString();
        m_draftDirty = true;
    });
    connect(m_rEdit, &QLineEdit::textChanged, this, [this](const QString &t) {
        m_draft.r = t.toStdString();
        m_draftDirty = true;
    });
    connect(m_stagesSpin,
            QOverload<int>::of(&QSpinBox::valueChanged), this,
            [this](int v) {
                m_draft.stages = v;
                m_draftDirty = true;
            });
    // 变换配置区根容器：选中已修改 MOS 时整体禁用（不可重复变换）。
    m_configCard = frame;
    return frame;
}

void LdoStructureTransformPage::refreshApplyEnabled()
{
    // 同一 device 不可重复变换：选中已修改项时确认按钮与配置区整体禁用，
    // 已修改项仍可被选中浏览（查看其变换后视图）。
    const bool canApply = !m_selectedDeviceId.empty() && !m_selectedIsModified;
    GUI_LDO_LOG(INFO)
        << "structure-transform refreshApplyEnabled: selectedDeviceId="
        << (m_selectedDeviceId.empty() ? "<empty>" : m_selectedDeviceId)
        << ", selectedIsModified=" << (m_selectedIsModified ? "true" : "false")
        << ", canApply=" << (canApply ? "true" : "false")
        << ", history_size=" << m_history.size();
    if (m_applyButton != nullptr) {
        m_applyButton->setEnabled(canApply);
    }
    if (m_configCard != nullptr) {
        m_configCard->setEnabled(canApply);
    }
    // 恢复初始按钮：history 为空时无内容可恢复，置灰避免误触。
    if (m_resetButton != nullptr) {
        m_resetButton->setEnabled(!m_history.empty());
    }
    // "已修改"过滤按钮：无已修改项时置灰（勾选态只允许在有已修改项时保持）。
    if (m_modifiedFilterButton != nullptr) {
        m_modifiedFilterButton->setEnabled(!m_history.empty());
        if (m_history.empty() && m_modifiedFilterButton->isChecked()) {
            m_modifiedFilterButton->setChecked(false);
        }
    }
    // 生成最终电路按钮：history 为空（无任何已确认变换）时置灰，避免空操作
    // 弹出"确认变换"提示却无实质内容。与恢复初始按钮同一判定基准。
    if (m_generateButton != nullptr) {
        m_generateButton->setEnabled(!m_history.empty());
    }
}

void LdoStructureTransformPage::refillDeviceListFiltered()
{
    // "已修改"过滤勾选状态变化：按当前排序状态重新填充（refillDeviceList
    // 内部统一应用搜索词与已修改过滤）。
    refillDeviceList(m_sortButton != nullptr && m_sortButton->isChecked());
}

void LdoStructureTransformPage::embedSchematicWindow(uint64_t wId)
{
    // 嵌入时防呆：无效的 wId（0）做 fromWinId 行为未定义，会表现为
    // "正确显示后瞬间消失"。调用方已判空串，这里兜底拦一层。
    if (m_schematicContainer == nullptr || wId == 0) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: embedSchematicWindow skip, wId=" << wId;
        return;
    }
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: embedSchematicWindow enter, wId=" << wId;
    clearSchematicContainer();
    auto *win = QWindow::fromWinId(static_cast<WId>(wId));
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: fromWinId(" << wId << ") -> QWindow="
        << (win == nullptr ? "NULL" : "valid");
    if (win == nullptr) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: fromWinId returned null for wId="
            << wId << " (X window may be destroyed/not ready), abort embed";
        return;
    }
    auto *diagram = QWidget::createWindowContainer(win, m_schematicContainer);
    auto *layout = m_schematicContainer->layout();
    if (layout == nullptr) {
        auto *box = new QVBoxLayout(m_schematicContainer);
        box->setContentsMargins(0, 0, 0, 0);
        box->addWidget(diagram);
    } else {
        layout->addWidget(diagram);
    }
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: embed done, wId=" << wId
        << ", container children=" << m_schematicContainer->children().size();
}

void LdoStructureTransformPage::openSchematicLcv(const std::string &lib,
                                                 const std::string &cell,
                                                 const std::string &view)
{
    // 打开指定 LCV 到"变换后"预览容器（选中已修改 MOS 时展示其所在 cell 的
    // 物化 view）。与 openTransformedSchematic 的区别：不带 m_transformGenerated
    // 守卫（由调用方保证），LCV 由调用方指定（用于定位叶子层 cell 的 view）。
    if (lib.empty() || cell.empty() || view.empty()) {
        return;
    }
    // 打开前校验 view 存在：物化只克隆叶子层 cell，部分 cell（如顶层 DUT）
    // 可能没有后缀 view。dbOpenCellViewByType 'r' 模式打开不存在 view 会
    // 报错并污染窗口服务器状态（后续 SwitchViewWindow 连锁失败、嵌入黑窗），
    // 必须先探测再打开。失败时保留当前窗口，不动容器。
    if (!maau::protocol::CellViewExists(lib, cell, view)) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: cellview not exists, skip open: "
            << lib << "/" << cell << "/" << view;
        refreshStatusMessage(QStringLiteral(
            "已修改模块的变换后视图不存在（%1/%2/%3），可能该 cell 未被物化。")
                .arg(QString::fromStdString(lib), QString::fromStdString(cell),
                     QString::fromStdString(view)));
        return;
    }
    // cell 是叶子子模块（非 TB 顶层），直接用输入 LCV，不走 GetTopLibCellView
    // （后者是"由 TB 求顶层 schematic"，对非 TB cell 会 fallback 返回输入，
    // 多一次无意义的 SKILL 往返）。
    // 与 openOriginalSchematic 相同的重试兜底：Virtuoso 异步启动中窗口未就绪
    // （重开工程后首次切"变换后"的典型场景）时延迟重试一次，不阻塞 GUI 线程。
    // 重试 lambda 捕获 lib/cell/view（值拷贝），不捕获裸 this 以外的悬垂引用。
    auto tryOpen = [this, lib, cell, view]() {
        uint64_t wId = 0;
        if (!maau::protocol::GetSchematicWindowIdEx(lib, cell, view, wId)) {
            GUI_LDO_LOG(WARNING)
                << "structure-transform preview: GetSchematicWindowId failed for "
                << lib << "/" << cell << "/" << view;
            return false;
        }
        embedSchematicWindow(wId);
        updatePreviewTitle(lib, cell, view);
        return true;
    };
    if (tryOpen()) {
        return;
    }
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: window not ready for "
        << lib << "/" << cell << "/" << view << ", retrying in 1s...";
    QTimer::singleShot(1000, this, [this, tryOpen]() {
        if (!tryOpen()) {
            // 重试仍失败：保留当前窗口（不清容器），仅提示，避免黑窗。
            refreshStatusMessage(QStringLiteral("无法打开已修改模块视图，详情见日志。"));
        }
    });
}

void LdoStructureTransformPage::updatePreviewTitle(const std::string &lib,
                                                   const std::string &cell,
                                                   const std::string &view,
                                                   bool original)
{
    if (m_previewTitleLabel == nullptr) {
        return;
    }
    const QString prefix = QStringLiteral("电路预览");
    if (lib.empty() && cell.empty() && view.empty()) {
        m_previewTitleLabel->setText(prefix);
        return;
    }
    m_previewTitleLabel->setText(prefix + QStringLiteral("：%1|%2|%3")
        .arg(QString::fromStdString(lib), QString::fromStdString(cell),
             QString::fromStdString(view)));
}

QWidget *LdoStructureTransformPage::createPreviewCard(QWidget *parent)
{
    auto *frame = card(parent);
    auto *layout = new QVBoxLayout(frame);
    layout->setContentsMargins(10, 8, 10, 10);
    layout->setSpacing(8);

    auto *header = new QHBoxLayout();
    header->setSpacing(8);
    m_previewTitleLabel = cardTitle(QStringLiteral("变换后电路预览"), frame);
    header->addWidget(m_previewTitleLabel);
    header->addStretch();
    m_showOriginalBtn = new QToolButton(frame);
    m_showOriginalBtn->setText(QStringLiteral("原结构"));
    m_showOriginalBtn->setCheckable(true);
    m_showOriginalBtn->setChecked(true);
    m_showTransformedBtn = new QToolButton(frame);
    m_showTransformedBtn->setText(QStringLiteral("变换后"));
    m_showTransformedBtn->setCheckable(true);
    header->addWidget(m_showOriginalBtn);
    header->addWidget(m_showTransformedBtn);
    layout->addLayout(header);

    m_schematicContainer = new QWidget(frame);
    m_schematicContainer->setStyleSheet(
        "background:#1e1e1e; border:1px solid #3d3d3d; border-radius:4px;");
    m_schematicContainer->setMinimumHeight(340);
    layout->addWidget(m_schematicContainer, 1);

    auto *viewGroup = new QButtonGroup(frame);
    viewGroup->setExclusive(true);
    viewGroup->addButton(m_showOriginalBtn);
    viewGroup->addButton(m_showTransformedBtn);
    connect(m_showOriginalBtn, &QToolButton::toggled, this, [this](bool on) {
        if (on) {
            m_showOriginal = true;
            updatePreviewTitle("", "", "");
            openOriginalSchematic();
        }
    });
    connect(m_showTransformedBtn, &QToolButton::toggled, this, [this](bool on) {
        if (on) {
            m_showOriginal = false;
            // 该窗口仅供浏览打开的 view，不支持上下层跳转（edit-in-place）。
            m_showTransformedBtn->setToolTip(
                QStringLiteral("仅供浏览当前打开的视图，不支持上下层跳转"));
            openTransformedSchematic();
        }
    });
    return frame;
}

// 程序路径强制切到"变换后"预览：QToolButton::setChecked(true) 在按钮已 checked
// 时是 no-op（不发 toggled），用户提前手动切到该按钮时副作用被静默吞掉。
// 这里显式重置 m_originalLoaded 强制后续 embed 时清容器（否则旧窗口残留
// 挡住新内容）；按钮只负责视觉态，实际打开统一走 openSchematicLcv（定位到
// 最近一次变换所在子模块 cell 的物化 view，而非顶层 DUT——物化只克隆叶子层，
// 顶层 DUT 的同名后缀 view 不一定存在）。
void LdoStructureTransformPage::showTransformedView()
{
    if (!m_transformGenerated || m_transformedLcvView.empty()) {
        return;
    }
    m_originalLoaded = false;
    m_showOriginal = false;
    // 保证按钮视觉态切到"变换后"。阻断信号再 setChecked：toggled 回调会调
    // openTransformedSchematic 重复打开同一 view（与下面的 openSchematicLcv
    // 撞车），导致 Virtuoso 侧开两个窗口。
    if (m_showTransformedBtn != nullptr && !m_showTransformedBtn->isChecked()) {
        const QSignalBlocker blocker(m_showTransformedBtn);
        m_showTransformedBtn->setChecked(true);
    }
    // 从最近一次变换的器件推出其所在子模块 cell，直接打开该 cell 的物化
    // view——物化只克隆叶子层 cell，顶层 DUT 的同名后缀 view 不一定存在，
    // 固定开顶层会误报"变换后视图不存在"。找不到（理论上不会发生）时回退
    // 顶层 DUT cell。
    std::string cell;
    std::string lib = m_transformedLcvLib;
    if (!m_history.empty()) {
        const auto devIt = m_scanDevices.find(m_history.back().deviceId);
        if (devIt != m_scanDevices.end() && !devIt->second.parent_subckt.empty()) {
            cell = devIt->second.parent_subckt;
            if (!devIt->second.parent_lib.empty()) {
                lib = devIt->second.parent_lib;
            }
        }
    }
    if (cell.empty()) {
        cell = m_transformedLcvCell;
    }
    openSchematicLcv(lib, cell, m_transformedLcvView);
}

// 程序路径强制切到"原结构"预览：阻断信号再 setChecked（toggled 回调会调
// openOriginalSchematic，与显式调用撞车导致 Virtuoso 侧开两个窗口）。
void LdoStructureTransformPage::showOriginalView()
{
    if (m_showOriginalBtn != nullptr && !m_showOriginalBtn->isChecked()) {
        const QSignalBlocker blocker(m_showOriginalBtn);
        m_showOriginalBtn->setChecked(true);
    }
    m_showOriginal = true;
    openOriginalSchematic();
}

QWidget *LdoStructureTransformPage::createActionButtons(QWidget *parent)
{
    auto *row = new QHBoxLayout();
    row->setSpacing(10);
    m_applyButton = new QPushButton(QStringLiteral("确认变换"), parent);
    m_generateButton = new QPushButton(QStringLiteral("生成最终电路"), parent);
    m_undoButton = new QPushButton(QStringLiteral("撤销修改"), parent);
    // 撤销当前是"全量重放剩余 history"实现，固定 view 后缀后存在覆盖语义
    // 歧义（撤销失败路径会误删剩余历史），且对用户暴露的语义不清晰。
    // 暂时屏蔽，待语义梳理清楚后再开放。仍保留 undoLast 函数体供后续恢复。
    m_undoButton->setVisible(false);
    m_resetButton = new QPushButton(
        QStringLiteral("恢复初始"), parent);
    m_generateButton->setStyleSheet(
        "QPushButton { background:#007acc; color:white; font-weight:600;"
        " font-family:\"Microsoft Yahei\";"
        " border:1px solid #168bd2; border-radius:4px; padding:6px 14px; }"
        "QPushButton:hover:enabled { background:#168bd2; }"
        "QPushButton:disabled { background:#2a2a2a; color:#707070;"
        " border:1px solid #3b3b3b; }");
    row->addWidget(m_applyButton);
    row->addStretch();
    // 右侧按钮组：undo/reset/generate 依次右对齐，statusLabel 在 generate 之后。
    // 不用 addSpacing 分隔 reset/generate，保持统一 spacing。
    row->addWidget(m_undoButton);
    row->addWidget(m_resetButton);
    row->addWidget(m_generateButton);
    m_statusLabel = new QLabel(parent);
    m_statusLabel->setStyleSheet("color:#b0b0b0;");
    row->addWidget(m_statusLabel);

    connect(m_applyButton, &QPushButton::clicked,
            this, &LdoStructureTransformPage::applyDraft);
    // "生成最终电路"：锁定变换结果为最终版（不触发调优，用户后续去 sizing 页）。
    connect(m_generateButton, &QPushButton::clicked,
            this, [this]() { generateCircuit(true); });
    connect(m_undoButton, &QPushButton::clicked,
            this, &LdoStructureTransformPage::undoLast);
    connect(m_resetButton, &QPushButton::clicked,
            this, &LdoStructureTransformPage::resetToFresh);

    auto *wrapper = new QWidget(parent);
    wrapper->setLayout(row);
    return wrapper;
}

void LdoStructureTransformPage::applyDraft()
{
    // 入口全状态日志：按钮"没反应"时先看这条——是前置校验拦了，还是根本没进来。
    GUI_LDO_LOG(INFO)
        << "structure-transform applyDraft enter: selectedDeviceId="
        << (m_selectedDeviceId.empty() ? "<empty>" : m_selectedDeviceId)
        << ", selectedIsModified=" << (m_selectedIsModified ? "true" : "false")
        << ", draft.type=" << (m_draft.type.empty() ? "<empty>" : m_draft.type)
        << ", draft.customSize=" << (m_draft.customSize ? "true" : "false")
        << ", draft.w=" << m_draft.w << ", draft.l=" << m_draft.l
        << ", draft.r=" << m_draft.r << ", draft.stages=" << m_draft.stages
        << ", draft.newMaster=" << m_draft.newMaster
        << ", history_size=" << m_history.size()
        << ", applyButton enabled="
        << (m_applyButton != nullptr && m_applyButton->isEnabled() ? "true" : "false");
    if (m_selectedDeviceId.empty()) {
        GUI_LDO_LOG(INFO) << "structure-transform applyDraft blocked: no device selected";
        refreshStatusMessage(QStringLiteral("请先选择 MOS 管。"));
        return;
    }
    if (m_draft.type.empty()) {
        GUI_LDO_LOG(INFO) << "structure-transform applyDraft blocked: no transform type selected";
        refreshStatusMessage(QStringLiteral("请先选择变换类型。"));
        return;
    }
    // 防呆：m_draft 的 r/w/l 只在对应 QLineEdit 的 textChanged 里写入。若用户
    // 填了值后触发恢复初始/撤销等清空了 draft，但输入框界面残留旧文本（后续
    // 未再编辑），draft 为空但界面显示有值——此时以界面文本为准回填，避免
    // "界面有值却提示请填写"。
    if (m_draft.type == "resistor" &&
        m_draft.r.empty() && m_rEdit != nullptr && !m_rEdit->text().isEmpty()) {
        m_draft.r = m_rEdit->text().toStdString();
        GUI_LDO_LOG(INFO)
            << "structure-transform applyDraft: draft.r empty but UI has text, "
               "backfill from m_rEdit: r=" << m_draft.r;
    }
    if (m_draft.customSize) {
        if (m_draft.w.empty() && m_wEdit != nullptr) m_draft.w = m_wEdit->text().toStdString();
        if (m_draft.wf.empty() && m_wfEdit != nullptr) m_draft.wf = m_wfEdit->text().toStdString();
        if (m_draft.nf.empty() && m_nfEdit != nullptr) m_draft.nf = m_nfEdit->text().toStdString();
        if (m_draft.l.empty() && m_lEdit != nullptr) m_draft.l = m_lEdit->text().toStdString();
    }
    const std::string mode = currentParameterMode();
    if (m_draft.type == "resistor") {
        if (m_draft.r.empty()) {
            refreshStatusMessage(QStringLiteral("请填写电阻值 R。"));
            return;
        }
    } else if (m_draft.customSize && mode == "unsupported") {
        refreshStatusMessage(QStringLiteral("工艺 CDF 尺寸参数不完整，不能自定义尺寸。"));
        return;
    } else if (m_draft.customSize && mode == "w_l" &&
               (m_draft.w.empty() || m_draft.l.empty())) {
        refreshStatusMessage(QStringLiteral("请填写完整的 W / L 初值。"));
        return;
    } else if (m_draft.customSize && mode == "wf_nf_l" &&
               (m_draft.wf.empty() || m_draft.nf.empty() || m_draft.l.empty())) {
        refreshStatusMessage(QStringLiteral("请填写完整的 WF / NF / L 初值。"));
        return;
    }
    // 异型 Cascode 必须选候选 MOS。
    if (m_draft.type == "cross_cascode" && m_draft.newMaster.empty()) {
        GUI_LDO_LOG(INFO) << "structure-transform applyDraft blocked: cross_cascode but no candidate master";
        refreshStatusMessage(QStringLiteral("请选择异型 Cascode 的新增管（候选 MOS）。"));
        return;
    }
    GUI_LDO_LOG(INFO) << "structure-transform applyDraft passed all pre-checks, proceeding";
    LdoTransformChange change;
    change.deviceId = m_selectedDeviceId;
    change.type = m_draft.type;
    change.w = m_draft.customSize && mode == "w_l" ? m_draft.w : "";
    change.wf = m_draft.customSize && mode == "wf_nf_l" ? m_draft.wf : "";
    change.nf = m_draft.customSize && mode == "wf_nf_l" ? m_draft.nf : "";
    change.l = m_draft.customSize ? m_draft.l : "";
    change.r = m_draft.type == "resistor" ? m_draft.r : "";
    change.stages = m_draft.type == "stack"
        ? std::max(2, std::min(100, m_draft.stages))
        : 2;
    change.newMaster = m_draft.type == "cross_cascode" ? m_draft.newMaster : "";
    m_history.push_back(std::move(change));
    // 记录变换点日志：器件 + 类型 + 关键参数。
    {
        const auto &added = m_history.back();
        std::string params;
        if (added.type == "resistor") {
            params = "R=" + added.r;
        } else if (added.type == "stack") {
            params = "stages=" + std::to_string(added.stages);
            if (!added.w.empty()) params += " W=" + added.w;
            if (!added.l.empty()) params += " L=" + added.l;
        } else if (added.type == "cross_cascode") {
            params = "new_master=" + added.newMaster;
        } else if (!added.w.empty() || !added.l.empty()) {
            params = "W=" + added.w + " L=" + added.l;
        }
        GUI_LDO_LOG(INFO)
            << "structure-transform history add: device=" << added.deviceId
            << ", type=" << added.type
            << (params.empty() ? "" : ", params=" + params)
            << ", history_size=" << m_history.size();
    }
    m_draftDirty = false;
    m_finalized = false;  // 有新变换后，之前的"最终"锁定失效
    refreshDeviceListLabels();
    refreshApplyEnabled();  // history 非空，恢复初始按钮可用
    syncTransformStateToContext();  // 持久化：新增变换写入 checkpoint
    // 确认变换即立即生成预览（叠加式：重放全部历史变换）。
    // 失败时回滚尾部新加的那条（m_rollbackTailOnFail=true）。
    m_rollbackTailOnFail = true;
    refreshStatusMessage(QStringLiteral("正在生成变换电路..."));
    generateCircuit(false);
}

void LdoStructureTransformPage::generateCircuit(bool lockAsFinal)
{
    if (m_draftDirty) {
        refreshStatusMessage(
            QStringLiteral("还有未确认的修改，请先点击[确认变换]，再生成电路。"));
        return;
    }
    if (m_history.empty()) {
        refreshStatusMessage(QStringLiteral("请先确认至少一次结构变换。"));
        return;
    }

    // "生成最终电路"会把变换物化并覆盖回原电路，覆盖后变换不可再撤销，
    // 必须先弹窗向用户确认，避免误操作丢失可撤销的历史。
    if (lockAsFinal) {
        const auto ret = QMessageBox::question(
            this, tr("Structure Transform"),
            tr("应用当前所有变换到电路后，将不可撤销，后续需要手动修改，是否继续？"));
        if (ret != QMessageBox::Yes) {
            return;
        }
        // lockAsFinal=true 时，确认变换（applyDraft）已经执行过 Run() 物化，
        // 产物 LCV 已保存在 m_transformedLcv*。此处不再重复 Run()，
        // 直接走 finalizeTransformViews 把已有后缀 view 覆盖回原 view。
        if (!m_transformGenerated || m_transformedLcvView.empty()) {
            refreshStatusMessage(QStringLiteral("尚未生成变换后电路，请先点击[确认变换]。"));
            return;
        }
        LdoSpecSelectionData selection;
        if (!m_context->specSelection(selection)) {
            refreshStatusMessage(QStringLiteral("缺少 Case 选择，无法生成电路。"));
            return;
        }
        maau::stengine::StructureTransformConfig config;
        makeStructureConfig(selection.selected_candidate.case_item, config);
        finalizeTransformViews(config);
        refreshStatusMessage(QStringLiteral("正在将变换结果覆盖回原电路..."));
        return;
    }

    // 构造 StructureTransformConfig（scanMosDevices 与 generateCircuit 共用）。
    LdoSpecSelectionData selection;
    if (!m_context->specSelection(selection)) {
        refreshStatusMessage(QStringLiteral("缺少 Case 选择，无法生成电路。"));
        return;
    }
    const auto &caseItem = selection.selected_candidate.case_item;
    maau::stengine::StructureTransformConfig config;
    makeStructureConfig(caseItem, config);

    // 把 m_history 转为 StructureTransformRequest 列表
    std::vector<maau::stengine::StructureTransformRequest> stRequests;
    stRequests.reserve(m_history.size());
    for (const auto &change : m_history) {
        maau::stengine::StructureTransformRequest req;
        req.operation_id = change.deviceId + "_" + change.type;
        if (change.type == "same_cascode") {
            req.type = st::TransformType::SameTypeCascode;
            // FixedBias：service 先执行基线与逐 R 的真实 DC；失败时禁止物化。
            // 页面不自行计算工作区，也不把结构连接成功当作 DC 通过。
        } else if (change.type == "cross_cascode") {
            req.type = st::TransformType::CrossFlavorCascode;
            // 异型 Cascode：新增管用用户从下拉选的候选 MOS master。
            req.cascode.new_master = change.newMaster;
        } else if (change.type == "resistor") {
            req.type = st::TransformType::AddSourceResistor;
            // 修改原因：完整解析工程后缀，格式错误时不能静默变成默认阻值。
            if (!change.r.empty()) {
                double resistance = 0.0;
                if (!ParseTransformValue(change.r, resistance)) {
                    refreshStatusMessage(QStringLiteral("%1 的电阻值 R 无效：%2。请输入正数，如 10k、10m、10M。")
                        .arg(QString::fromStdString(change.deviceId), QString::fromStdString(change.r)));
                    return;
                }
                req.resistor.requested_resistance = resistance;
            }
        } else if (change.type == "stack") {
            req.type = st::TransformType::MosStack;
            req.stack.stage_count = change.stages;
        }
        req.target.subckt = caseItem.schematic_cell;
        req.target.instance = change.deviceId;
        // 历史记录携带唯一一种尺寸模式；后端再次按真实 CDF 校验和量化。
        double width = 0.0, fingerWidth = 0.0, fingers = 0.0, length = 0.0;
        if (!change.w.empty() && !ParseTransformValue(change.w, width)) {
            refreshStatusMessage(QStringLiteral("%1 的 W 无效。").arg(QString::fromStdString(change.deviceId)));
            return;
        }
        if (!change.wf.empty() && !ParseTransformValue(change.wf, fingerWidth)) {
            refreshStatusMessage(QStringLiteral("%1 的 WF 无效。").arg(QString::fromStdString(change.deviceId)));
            return;
        }
        if (!change.nf.empty() && (!ParseTransformValue(change.nf, fingers) ||
                                   std::floor(fingers) != fingers)) {
            refreshStatusMessage(QStringLiteral("%1 的 NF 必须是正整数。").arg(QString::fromStdString(change.deviceId)));
            return;
        }
        if (!change.l.empty() && !ParseTransformValue(change.l, length)) {
            refreshStatusMessage(QStringLiteral("%1 的 L 无效。").arg(QString::fromStdString(change.deviceId)));
            return;
        }
        if (req.type == st::TransformType::MosStack) {
            if (!change.w.empty()) req.stack.custom_width = width;
            if (!change.wf.empty()) req.stack.custom_finger_width = fingerWidth;
            if (!change.nf.empty()) req.stack.custom_fingers = fingers;
            if (!change.l.empty()) req.stack.custom_length = length;
        } else {
            if (!change.w.empty()) req.cascode.custom_width = width;
            if (!change.wf.empty()) req.cascode.custom_finger_width = fingerWidth;
            if (!change.nf.empty()) req.cascode.custom_fingers = fingers;
            if (!change.l.empty()) req.cascode.custom_length = length;
        }
        // 原始点分隔层次路径（如 ldo.ldo_top.I52.I35<4>.M2<1>），
        // 供 service 侧推导 OA 物化的多层级 clone 路径。
        req.hierarchy_path = change.deviceId;
        stRequests.push_back(std::move(req));
    }

    // 判断本次是否含 Cascode 变换（生成后弹 VBIAS 确认提示框）。
    const bool hasCascode = std::any_of(
        m_history.begin(), m_history.end(), [](const LdoTransformChange &change) {
            return change.type == "same_cascode" || change.type == "cross_cascode";
        });
    // 物化产物定位由 service 返回（同 lib/cell 下的新 view
    // schematic__maau_struct_transform，固定后缀，每次 Run 覆盖）。
    const std::string cdsPath = caseItem.copy_cds_path;

    // 后台线程执行 Run()（含后端 Snapshot / 物化，可能耗时），主线程显示转圈加载框。
    auto *waiting = new WaitingWidget(tr("Generating circuit..."), this);
    waiting->setStopBtnVisable(false);
    waiting->setWindowModality(Qt::ApplicationModal);
    waiting->show();

    auto *watcher = new QFutureWatcher<maau::stengine::StructureTransformResult>(this);
    connect(watcher, &QFutureWatcher<maau::stengine::StructureTransformResult>::finished,
            this, [this, waiting, watcher, lockAsFinal, hasCascode, cdsPath, config]() {
                auto result = watcher->result();
                waiting->Stop();
                waiting->deleteLater();
                watcher->deleteLater();
                if (!result.ok) {
                    GUI_LDO_LOG(ERROR) << "structure-transform finalize failed: "
                                       << result.message;
                    QMessageBox::warning(
                        this, tr("Structure Transform"),
                        tr("Circuit generation failed: %1\nSee logs for details.")
                            .arg(QString::fromStdString(result.message)));
                    // 叠加语义：applyDraft（确认变换）失败时回滚尾部新加的那条；
                    // 撤销后重新生成（m_rollbackTailOnFail=false）失败时不回滚
                    // （尾部是合法历史，不是新增）。
                    if (m_rollbackTailOnFail && !m_history.empty()) {
                        m_history.pop_back();
                        m_finalized = false;
                        refreshDeviceListLabels();
                        syncTransformStateToContext();  // 持久化：回滚尾部
                    }
                    m_rollbackTailOnFail = false;
                    m_undoRegenerate = false;
                    refreshStatusMessage(
                        QStringLiteral("生成电路失败，已回滚本次变换，可重新选择 MOS 继续。"));
                    return;
                }
                m_transformedLcvLib = result.variant_lib;
                m_transformedLcvCell = result.variant_cell;
                m_transformedLcvView = result.variant_view;
                m_transformedCdsPath = cdsPath;
                m_transformGenerated = true;
                // 记录本次 Run 生成的封装 cell（如 CELL1_I52_resistor）：
                // 撤销修改 / 恢复初始时整 cell 删除。
                // 每次 Run 都是全量重放，新计划不再产出的旧封装 cell 需要
                // 整 cell 删除——尤其是"撤销某器件后重新生成"：被撤销变换
                // 对应的封装不会出现在新计划里，不删就会残留在 OA 中。
                std::vector<LdoPackagedCell> previousPackaged;
                previousPackaged.swap(m_packagedCells);
                m_packagedCells.reserve(result.packaged_cells.size());
                std::set<std::pair<std::string, std::string>> currentKeys;
                for (const auto &packaged : result.packaged_cells) {
                    LdoPackagedCell cell;
                    cell.library = packaged.library;
                    cell.cell = packaged.cell;
                    cell.operationIds = packaged.operation_ids;
                    currentKeys.insert({cell.library, cell.cell});
                    m_packagedCells.push_back(std::move(cell));
                }
                // 旧封装中本次未再产出的（且当前已无 history 引用）删除。
                std::vector<std::pair<std::string, std::string>> stalePackaged;
                for (const auto &cell : previousPackaged) {
                    if (currentKeys.count({cell.library, cell.cell}) == 0) {
                        stalePackaged.emplace_back(cell.library, cell.cell);
                    }
                }
                GUI_LDO_LOG(INFO)
                    << "structure-transform packaged cells: current="
                    << m_packagedCells.size()
                    << ", stale=" << stalePackaged.size();
                discardPackagedCellsAsync(std::move(stalePackaged),
                                          "stale packaged cell cleanup");
                m_rollbackTailOnFail = false;  // 成功后重置，避免残留影响后续撤销重生成
                syncTransformStateToContext();  // 持久化：物化产物 LCV + 最新 history
                if (lockAsFinal) {
                    // 生成最终电路：把 history 涉及 cell 的后缀 view 提升覆盖回
                    // 原 view（后台线程执行 OA 拷贝，可能耗时）。m_finalized 在
                    // finalize 成功回调内置位，避免提升失败仍误锁。
                    finalizeTransformViews(config);
                }
                const QString circuitPath = QString::fromStdString(
                    result.variant_lib + "/" + result.variant_cell + "/" +
                    result.variant_view);
                GUI_LDO_LOG(INFO)
                    << "structure-transform finalize ok: " << result.message
                    << "; generated circuit at " << circuitPath.toStdString();
                // 记录变换结果：物化产物 LCV + 当前 history 摘要（器件:类型）。
                {
                    std::string summary;
                    for (const auto &change : m_history) {
                        if (!summary.empty()) summary += ", ";
                        summary += change.deviceId + ":" + change.type;
                    }
                    GUI_LDO_LOG(INFO)
                        << "structure-transform result: variant="
                        << result.variant_lib << "/" << result.variant_cell
                        << "/" << result.variant_view
                        << ", history=[" << summary << "]"
                        << ", lockAsFinal=" << (lockAsFinal ? "true" : "false");
                }
                // lockAsFinal 分支的结果提示由 finalizeTransformViews 回调统一
                // 给出（含"已覆盖回原电路"语义），此处不再重复弹框。
                // 撤销触发的生成（m_undoRegenerate）完成后弹窗提示"撤销完成"。
                if (!lockAsFinal) {
                    if (m_undoRegenerate) {
                        QMessageBox::information(
                            this, tr("Structure Transform"),
                            tr("撤销完成。"));
                    } else if (hasCascode) {
                        QMessageBox::information(
                            this, tr("VBIAS"),
                            tr("VBIAS circuit requires your confirmation of "
                               "reasonableness.\nGenerated circuit: %1")
                                .arg(circuitPath));
                    } else {
                        QMessageBox::information(
                            this, tr("Structure Transform"),
                            tr("Circuit generated successfully.\nGenerated circuit: %1")
                                .arg(circuitPath));
                    }
                }
                // 确认变换成功后自动切到"变换后"预览，展示本次变换后的物化
                // view（叶子层 cell）。showTransformedView 内部处理按钮视觉
                // 态同步与叶子层 cell 定位。
                if (!lockAsFinal) {
                    showTransformedView();
                }
                refreshStatusMessage(
                    lockAsFinal
                        ? QStringLiteral("正在将变换结果覆盖回原电路...")
                        : m_undoRegenerate
                            ? QStringLiteral("撤销完成。")
                            : QStringLiteral("变换已生成，可继续对其它 MOS 确认变换。"));
                m_undoRegenerate = false;
            });

    watcher->setFuture(QtConcurrent::run(
        [config, stRequests]() {
            maau::stengine::StructureTransformService service;
            return service.Run(config, stRequests);
        }));
}

void LdoStructureTransformPage::resetToFresh()
{
    GUI_LDO_LOG(INFO)
        << "structure-transform resetToFresh enter: history_size="
        << m_history.size() << ", selectedDeviceId="
        << (m_selectedDeviceId.empty() ? "<empty>" : m_selectedDeviceId)
        << ", selectedIsModified=" << (m_selectedIsModified ? "true" : "false")
        << ", draft.type=" << (m_draft.type.empty() ? "<empty>" : m_draft.type);
    // 恢复初始会作废所有已确认的变换并删除物化产物，先弹窗让用户确认，
    // 避免误触导致已做的工作丢失。
    if (!m_history.empty()) {
        const auto ret = QMessageBox::question(
            this, tr("Structure Transform"),
            tr("恢复初始将作废全部 %1 项已确认的变换并删除已生成的变换电路，确认继续吗？")
                .arg(m_history.size()));
        if (ret != QMessageBox::Yes) {
            GUI_LDO_LOG(INFO) << "structure-transform resetToFresh: user cancelled";
            return;
        }
    }
    // 恢复初始 = 清空 plan/history + 删除 OA 中所有 __maau_struct_transform
    // 后缀 view。先收集 config 与 history 涉及的 cell（必须在 m_history.clear()
    // 之前），后台线程删除后缀 view，再清内存态。
LdoSpecSelectionData selection;
    if (m_context != nullptr && m_context->specSelection(selection)) {
        maau::stengine::StructureTransformConfig config;
        makeStructureConfig(selection.selected_candidate.case_item, config);
        discardTransformViews(config);
    }
    m_history.clear();
    m_draftDirty = false;
    m_draft = {};
    m_virtuosoOpened = false;
    m_originalLoaded = false;
    if (m_typeGroup->checkedButton() != nullptr) {
        m_typeGroup->setExclusive(false);
        m_typeGroup->checkedButton()->setChecked(false);
        m_typeGroup->setExclusive(true);
    }
    m_useOriginalSize->setChecked(true);
    m_wEdit->clear();
    m_lEdit->clear();
    // 电阻值输入框同步清空：draft = {} 已清 draft.r，但输入框残留旧文本会
    // 误导用户以为值还在（点确认变换时 draft.r 为空报"请填写 R"，界面却显示
    // 有值）。与 w/l 输入框同一处理。
    if (m_rEdit != nullptr) {
        m_rEdit->clear();
    }
    m_stagesSpin->setValue(2);
    m_transformGenerated = false;
    m_finalized = false;
    m_transformedLcvLib.clear();
    m_transformedLcvCell.clear();
    m_transformedLcvView.clear();
    m_transformedCdsPath.clear();
    // 封装 cell 已在 discardTransformViews 中（后台）删除，这里只清内存记录。
    m_packagedCells.clear();
    // 复位选中态：不清除的话，若当前选中项曾在 history 中，refreshApplyEnabled
    // 会因"选中项已修改"把确认变换按钮/配置区置灰，表现为"恢复初始后点确认
    // 变换没反应"。
    m_selectedDeviceId.clear();
    m_selectedIsModified = false;
    if (m_deviceList != nullptr) {
        m_deviceList->clearSelection();
        m_deviceList->setCurrentItem(nullptr);
    }
    if (m_showOriginalBtn != nullptr) {
        m_showOriginalBtn->setChecked(true);
    }
    // 显式刷新原结构视图（resetToFresh 通常在用户已切到"原结构"时被点击，
    // 此时 setChecked 同值 no-op，需要直接调用确保右侧容器被清掉）。
    m_showOriginal = true;
    openOriginalSchematic();
    updatePreviewTitle("", "", "");
    GUI_LDO_LOG(INFO)
        << "structure-transform resetToFresh done: history cleared, selection reset,"
        << " selectedDeviceId empty=" << (m_selectedDeviceId.empty() ? "true" : "false")
        << ", selectedIsModified=" << (m_selectedIsModified ? "true" : "false")
        << ", draft.type empty=" << (m_draft.type.empty() ? "true" : "false")
        << ", about to refreshApplyEnabled";
    refreshApplyEnabled();
    refreshDraftControls();
    refreshDeviceListLabels();
    syncTransformStateToContext();  // 持久化：history/产物 LCV 已清空
    refreshStatusMessage(
        QStringLiteral("所有修改已作废，电路结构恢复至初始状态，可从原电路重新开始。"));
}

std::vector<std::pair<std::string, std::string>>
LdoStructureTransformPage::toCellPairs(
    const std::vector<LdoPackagedCell> &packagedCells)
{
    std::vector<std::pair<std::string, std::string>> pairs;
    pairs.reserve(packagedCells.size());
    for (const auto &cell : packagedCells) {
        if (!cell.library.empty() && !cell.cell.empty()) {
            pairs.emplace_back(cell.library, cell.cell);
        }
    }
    return pairs;
}

void LdoStructureTransformPage::pruneFinalizedPackagedCells(
    const std::vector<std::string> &finalizedLibs)
{
    if (finalizedLibs.empty() || m_packagedCells.empty()) {
        return;
    }
    // finalize 已把这些 lib 的封装 cell 固化进原 view（被实例引用），
    // 不能再当作可清理产物。只移除这些 lib 的记录，失败 lib 的保留。
    const std::set<std::string> libs(finalizedLibs.begin(), finalizedLibs.end());
    std::vector<LdoPackagedCell> kept;
    kept.reserve(m_packagedCells.size());
    std::size_t removed = 0;
    for (auto &cell : m_packagedCells) {
        if (libs.count(cell.library) != 0) {
            ++removed;
            continue;
        }
        kept.push_back(std::move(cell));
    }
    if (removed == 0) {
        return;
    }
    m_packagedCells = std::move(kept);
    std::string finalizedList;
    for (const auto &lib : finalizedLibs) {
        if (!finalizedList.empty()) {
            finalizedList += ", ";
        }
        finalizedList += lib;
    }
    GUI_LDO_LOG(INFO)
        << "structure-transform finalize partial: pruned " << removed
        << " packaged cell record(s) for finalized libs [" << finalizedList
        << "], remaining=" << m_packagedCells.size();
    syncTransformStateToContext();  // 持久化：剔除已固化的封装 cell 记录
}

void LdoStructureTransformPage::discardPackagedCellsAsync(
    std::vector<std::pair<std::string, std::string>> packagedCells,
    const std::string &reason)
{
    if (packagedCells.empty()) {
        return;
    }
    LdoSpecSelectionData selection;
    if (m_context == nullptr || !m_context->specSelection(selection)) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform " << reason
            << ": specSelection failed, skip packaged cell cleanup ("
            << packagedCells.size() << " cell(s))";
        return;
    }
    maau::stengine::StructureTransformConfig config;
    makeStructureConfig(selection.selected_candidate.case_item, config);
    for (const auto &[lib, cell] : packagedCells) {
        GUI_LDO_LOG(INFO)
            << "structure-transform " << reason
            << ": discard packaged cell " << lib << "/" << cell;
    }
    QtConcurrent::run([config, packagedCells, reason]() {
        maau::stengine::StructureTransformService service;
        auto result = service.DiscardPackagedCells(config, packagedCells);
        if (!result.ok) {
            GUI_LDO_LOG(WARNING)
                << "structure-transform " << reason
                << ": discard packaged cells failed: " << result.message;
        } else {
            GUI_LDO_LOG(INFO)
                << "structure-transform " << reason
                << ": discard packaged cells ok: " << result.message;
        }
    });
}

std::vector<std::pair<std::string, std::string>> LdoStructureTransformPage::collectTransformCells(
    const maau::stengine::StructureTransformConfig &config) const
{
    // DUT 顶层 cell + history 各变换目标的叶子层 cell（parent_subckt）。
    // std::set 去重（同一 cell 多次变换只提升/清理一次）。
    // 用 (lib, cell) pair 作为 key：叶子层 cell 可能属于不同 lib。
    std::set<std::pair<std::string, std::string>> cellSet;
    if (!config.target_dut_cell.empty()) {
        cellSet.emplace(config.target_dut_lib, config.target_dut_cell);
    }
    for (const auto &change : m_history) {
        const auto it = m_scanDevices.find(change.deviceId);
        if (it != m_scanDevices.end() && !it->second.parent_subckt.empty()) {
            const std::string &lib = it->second.parent_lib.empty()
                ? config.target_dut_lib : it->second.parent_lib;
            cellSet.emplace(lib, it->second.parent_subckt);
        }
    }
    // 兜底：parent_subckt 查找全部失败（扫描缺失/路径不匹配）时，物化叶子层
    // cell（m_transformedLcvCell，生成成功时记录）仍可能有后缀 view 残留，
    // 一并纳入清理集合，保证"恢复初始"路径能清掉叶子层孤立产物。
    if (!m_transformedLcvCell.empty()) {
        cellSet.emplace(m_transformedLcvLib.empty()
            ? config.target_dut_lib : m_transformedLcvLib,
            m_transformedLcvCell);
    }
    return std::vector<std::pair<std::string, std::string>>(
        cellSet.begin(), cellSet.end());
}

void LdoStructureTransformPage::finalizeTransformViews(
    const maau::stengine::StructureTransformConfig &config)
{
    const auto cells = collectTransformCells(config);
    if (cells.empty()) {
        refreshStatusMessage(QStringLiteral("没有需要提升的变换 cell。"));
        return;
    }
    // finalize 只提升后缀 view，封装 cell 仍被提升后的原 view 实例化，
    // 不能删除（只有撤销修改 / 恢复初始才删）。
    auto *waiting = new WaitingWidget(tr("Finalizing circuit..."), this);
    waiting->setStopBtnVisable(false);
    waiting->setWindowModality(Qt::ApplicationModal);
    waiting->show();
    auto *watcher =
        new QFutureWatcher<maau::stengine::StructureTransformOpResult>(this);
    connect(watcher,
            &QFutureWatcher<maau::stengine::StructureTransformOpResult>::finished,
            this, [this, waiting, watcher]() {
                auto result = watcher->result();
                waiting->Stop();
                waiting->deleteLater();
                watcher->deleteLater();
                if (!result.ok) {
                    GUI_LDO_LOG(ERROR)
                        << "structure-transform finalize views failed: "
                        << result.message;
                    // 多 lib 分批调用时可能部分 lib 已提升成功：这些 lib 的
                    // 封装 cell 已固化进原电路，必须从待清理记录中剔除，
                    // 否则后续"恢复初始"会删掉它们导致原电路断链。
                    pruneFinalizedPackagedCells(result.succeeded_libs);
                    QMessageBox::warning(
                        this, tr("Structure Transform"),
                        tr("Finalize failed: %1\nThe suffixed views are kept; "
                           "see logs for details.")
                            .arg(QString::fromStdString(result.message)));
                    refreshStatusMessage(
                        QStringLiteral("覆盖回原电路失败，后缀 view 已保留，详情见日志。"));
                    return;
                }
                // 提升成功：后缀 view 已覆盖回原 view 并删除，锁定为最终版。
                m_finalized = true;
                syncTransformStateToContext();  // 持久化：finalized 标志
                GUI_LDO_LOG(INFO)
                    << "structure-transform finalize views ok: " << result.message;
                // 用 SKILL 返回的真实提升数，而不是请求处理的 cell 数：
                // collectTransformCells 总会带上 DUT 顶层 cell，但它通常
                // 没有 __maau_struct_transform 后缀 view，实际不会被提升，
                // 用它计数会虚报（如只改 1 个 cell 却显示 Promoted 2）。
                QMessageBox::information(
                    this, tr("Structure Transform"),
                    tr("Final circuit generated and promoted over the original "
                       "views.\nPromoted %1 cell(s).")
                        .arg(static_cast<int>(result.processed_count)));
                refreshStatusMessage(
                    QStringLiteral("最终电路已生成并覆盖回原电路，可到调优页继续优化。"));
                // 弹窗确认后刷新界面到初始状态：变换已固化进原电路，history 与
                // 产物 LCV 已失效。只清内存态 + 切回原结构视图，不调
                // discardTransformViews（后缀 view 已被 finalize 提升/删除，
                // 再删会误伤已提升的原 view）。
                m_history.clear();
                m_draftDirty = false;
                m_draft = {};
                if (m_typeGroup->checkedButton() != nullptr) {
                    m_typeGroup->setExclusive(false);
                    m_typeGroup->checkedButton()->setChecked(false);
                    m_typeGroup->setExclusive(true);
                }
                m_useOriginalSize->setChecked(true);
                m_wEdit->clear();
                m_lEdit->clear();
                if (m_rEdit != nullptr) {
                    m_rEdit->clear();
                }
                m_stagesSpin->setValue(2);
                m_transformGenerated = false;
                m_finalized = false;
                m_transformedLcvLib.clear();
                m_transformedLcvCell.clear();
                m_transformedLcvView.clear();
                m_transformedCdsPath.clear();
                // 封装 cell 已被提升后的原 view 引用，不能删除；只清内存记录，
                // 避免后续"恢复初始"误删已固化的封装 cell。
                m_packagedCells.clear();
                m_selectedDeviceId.clear();
                m_selectedIsModified = false;
                if (m_deviceList != nullptr) {
                    m_deviceList->clearSelection();
                    m_deviceList->setCurrentItem(nullptr);
                }
                m_showOriginal = true;
                openOriginalSchematic();
                updatePreviewTitle("", "", "");
                refreshApplyEnabled();
                refreshDraftControls();
                refreshDeviceListLabels();
                syncTransformStateToContext();  // 持久化：history/产物 LCV 已清空
            });
    watcher->setFuture(QtConcurrent::run(
        [config, cells]() {
            maau::stengine::StructureTransformService service;
            return service.FinalizeTransform(config, cells);
        }));
}

void LdoStructureTransformPage::discardTransformViews(
    const maau::stengine::StructureTransformConfig &config)
{
    const auto cells = collectTransformCells(config);
    // 恢复初始要清掉全部变换产物：后缀 view + 生成的封装 cell。
    const auto packagedCells = toCellPairs(m_packagedCells);
    if (cells.empty() && packagedCells.empty()) {
        // 无 history（或扫描不到 parent_subckt）且无封装 cell：OA 侧本就没有
        // 产物，空操作，无需起后台线程。
        return;
    }
    // cells 已是 (lib, cell) pair（collectTransformCells 从 scanDevices/history
    // 提取），直接透传给服务层——服务层内部按 lib 分组调 python 脚本。
    for (const auto &[lib, cell] : cells) {
        GUI_LDO_LOG(INFO)
            << "discardTransformViews: lib=" << lib << " cell=" << cell;
    }
    for (const auto &[lib, cell] : packagedCells) {
        GUI_LDO_LOG(INFO)
            << "discardTransformViews: packaged cell lib=" << lib
            << " cell=" << cell;
    }
    auto *watcher =
        new QFutureWatcher<maau::stengine::StructureTransformOpResult>(this);
    connect(watcher,
            &QFutureWatcher<maau::stengine::StructureTransformOpResult>::finished,
            this, [this, watcher]() {
                auto result = watcher->result();
                watcher->deleteLater();
                // 恢复初始只记录日志，不打扰用户（内存态已被 resetToFresh 清空）。
                if (!result.ok) {
                    GUI_LDO_LOG(WARNING)
                        << "structure-transform discard views failed: "
                        << result.message;
                } else {
                    GUI_LDO_LOG(INFO)
                        << "structure-transform discard views ok: "
                        << result.message;
                }
            });
    watcher->setFuture(QtConcurrent::run(
        [config, cells, packagedCells]() {
            maau::stengine::StructureTransformService service;
            return service.DiscardTransformViews(config, cells, packagedCells);
        }));
}

void LdoStructureTransformPage::discardOrphanTransformView(
    const std::string &deviceId,
    const std::vector<std::pair<std::string, std::string>> &packagedCells)
{
    // 判断被撤销器件所在 cell 是否还有其他变换：没有了则删除该 cell 的
    // 后缀 view（孤立 view），避免 OA 中残留无用的物化产物。
    // packagedCells 非空时（全部撤销，无后续重生成）在同一次调用里一并删除
    // 封装 cell——合并成单次 Virtuoso 调用，避免两个后台进程并发写同一 OA 库。
    // 部分撤销时传空：封装 cell 等重新生成成功后按"旧封装 - 新封装"差集清理。
    GUI_LDO_LOG(INFO)
        << "structure-transform undo: discardOrphanTransformView enter, deviceId="
        << deviceId << ", history_size=" << m_history.size()
        << ", scanDevices_size=" << m_scanDevices.size()
        << ", transformedLcvCell=" << m_transformedLcvCell;
    std::string orphanCell;
    std::string orphanLib;
    const auto devIt = m_scanDevices.find(deviceId);
    if (devIt != m_scanDevices.end() && !devIt->second.parent_subckt.empty()) {
        const std::string &cell = devIt->second.parent_subckt;
        const std::string &cellLib = devIt->second.parent_lib;
        const bool stillUsed = std::any_of(
            m_history.begin(), m_history.end(),
            [this, &cell](const LdoTransformChange &c) {
                const auto it2 = m_scanDevices.find(c.deviceId);
                return it2 != m_scanDevices.end() &&
                       it2->second.parent_subckt == cell;
            });
        GUI_LDO_LOG(INFO)
            << "structure-transform undo: deviceId=" << deviceId
            << " maps to cell " << cellLib << "/" << cell
            << ", stillUsed=" << (stillUsed ? "true" : "false");
        if (!stillUsed) {
            orphanCell = cell;
            orphanLib = cellLib;
        }
    } else {
        GUI_LDO_LOG(INFO)
            << "structure-transform undo: parent_subckt lookup missed for "
            << deviceId << " (devIt found=" << (devIt != m_scanDevices.end())
            << ", parent_subckt empty="
            << (devIt != m_scanDevices.end() && devIt->second.parent_subckt.empty())
            << ")";
    }
    if (orphanCell.empty() && packagedCells.empty()) {
        GUI_LDO_LOG(INFO)
            << "structure-transform undo: no orphan cell / packaged cell for "
            << deviceId << ", skip discard";
        return;
    }
    LdoSpecSelectionData selection;
    if (m_context == nullptr || !m_context->specSelection(selection)) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform undo: specSelection failed, skip discard for "
            << deviceId;
        return;
    }
    maau::stengine::StructureTransformConfig config;
    makeStructureConfig(selection.selected_candidate.case_item, config);
    // orphanLib 可能为空（ScanMos 未解析到 parent_lib），此时用 DUT lib 兜底。
    const std::string actualLib = orphanLib.empty()
        ? config.target_dut_lib : orphanLib;
    const std::vector<std::pair<std::string, std::string>> viewCells =
        orphanCell.empty()
            ? std::vector<std::pair<std::string, std::string>>{}
            : std::vector<std::pair<std::string, std::string>>{
                  {actualLib, orphanCell}};
    GUI_LDO_LOG(INFO)
        << "structure-transform undo: discard orphan view for cell "
        << orphanCell << ", lib=" << actualLib
        << ", base view=" << config.target_dut_view
        << ", packaged cells=" << packagedCells.size();
    QtConcurrent::run([config, viewCells, packagedCells, actualLib,
                       orphanCell]() {
        maau::stengine::StructureTransformService service;
        auto result = service.DiscardTransformViews(config, viewCells,
                                                   packagedCells);
        if (!result.ok) {
            GUI_LDO_LOG(WARNING)
                << "structure-transform undo: discard failed for cell "
                << actualLib << "/" << orphanCell << ": " << result.message;
        } else {
            GUI_LDO_LOG(INFO)
                << "structure-transform undo: discard ok for cell "
                << actualLib << "/" << orphanCell << ": " << result.message;
        }
    });
}

void LdoStructureTransformPage::removeHistoryAndRegenerate(
    const std::string &deviceId)
{
    const auto it = std::find_if(
        m_history.begin(), m_history.end(),
        [&deviceId](const LdoTransformChange &c) {
            return c.deviceId == deviceId;
        });
    if (it == m_history.end()) {
        return;
    }
    // 记录撤销日志：器件 + 类型 + 撤销后剩余条数。
    GUI_LDO_LOG(INFO)
        << "structure-transform history undo: device=" << it->deviceId
        << ", type=" << it->type
        << ", remaining_history=" << (m_history.size() - 1);
    m_history.erase(it);
    m_finalized = false;  // 有修改后，之前的"最终"锁定失效
    m_draftDirty = false;
    // 若当前选中项正是被撤销的器件，复位其已修改标志并刷新确认区可用性。
    if (m_selectedDeviceId == deviceId) {
        m_selectedIsModified = false;
    }
    // 全部撤销时不再重新生成，封装 cell 一并清理；部分撤销只删孤立后缀
    // view（封装 cell 等重生成成功后按差集清理）。两者合成单次 Virtuoso 调用。
    std::vector<std::pair<std::string, std::string>> stalePackaged;
    if (m_history.empty()) {
        stalePackaged = toCellPairs(m_packagedCells);
        m_packagedCells.clear();
    }
    discardOrphanTransformView(deviceId, stalePackaged);
    refreshDeviceListLabels();
    refreshApplyEnabled();
    if (m_history.empty()) {
        syncTransformStateToContext();  // 持久化：移除 history + 封装 cell
        // 回到原电路预览。showOriginalView 处理 setChecked 同值 no-op 的情形
        // （用户已手动切回原结构时仍能强制刷新右侧容器）。
        m_transformGenerated = false;
        showOriginalView();
        updatePreviewTitle("", "", "");
        refreshStatusMessage(
            QStringLiteral("已撤销全部修改，回到原电路。"));
        QMessageBox::information(this, tr("Structure Transform"),
                                 tr("撤销完成。"));
        return;
    }
    syncTransformStateToContext();  // 持久化：移除一条 history
    // 仍有剩余变换：重新生成预览（叠加式重放剩余 history，内部带 loading）。
    // 失败时不回滚尾部（尾部是合法历史，不是新增）。
    m_rollbackTailOnFail = false;
    m_undoRegenerate = true;
    refreshStatusMessage(
        QStringLiteral("已撤销该器件修改，剩余 %1 处，正在重新生成...")
            .arg(m_history.size()));
    generateCircuit(false);
}

void LdoStructureTransformPage::undoLast()
{
    if (m_history.empty()) {
        refreshStatusMessage(QStringLiteral("没有可撤销的修改。"));
        return;
    }
    // 记录撤销日志：器件 + 类型 + 撤销后剩余条数。
    GUI_LDO_LOG(INFO)
        << "structure-transform history undoLast: device="
        << m_history.back().deviceId << ", type=" << m_history.back().type
        << ", remaining_history=" << (m_history.size() - 1);
    const std::string removedId = m_history.back().deviceId;
    m_history.pop_back();
    m_finalized = false;  // 有修改后，之前的"最终"锁定失效
    refreshDeviceListLabels();
    // 全部撤销时不再重新生成，封装 cell 一并清理；部分撤销只删孤立后缀
    // view（封装 cell 等重生成成功后按差集清理）。两者合成单次 Virtuoso 调用。
    std::vector<std::pair<std::string, std::string>> stalePackaged;
    if (m_history.empty()) {
        stalePackaged = toCellPairs(m_packagedCells);
        m_packagedCells.clear();
    }
    discardOrphanTransformView(removedId, stalePackaged);
    if (m_history.empty()) {
        syncTransformStateToContext();  // 持久化：弹出 history + 封装 cell
        // 回到原电路预览。showOriginalView 处理 setChecked 同值 no-op 的情形
        // （用户已手动切回原结构时仍能强制刷新右侧容器）。
        m_transformGenerated = false;
        showOriginalView();
        refreshStatusMessage(QStringLiteral("已撤销全部修改，回到原电路。"));
        QMessageBox::information(this, tr("Structure Transform"),
                                 tr("撤销完成。"));
    } else {
        syncTransformStateToContext();  // 持久化：弹出尾部 history
        // 仍有剩余变换：重新生成预览（叠加式）。
        m_rollbackTailOnFail = false;
        m_undoRegenerate = true;
        refreshStatusMessage(QStringLiteral("已撤销最近一次修改，剩余 %1 处，正在重新生成...")
                                 .arg(m_history.size()));
        generateCircuit(false);
    }
}

void LdoStructureTransformPage::refreshStatusMessage(
    const QString &message)
{
    if (m_statusLabel == nullptr) {
        return;
    }
    // 状态栏文本限宽换行，避免超长错误信息把窗口撑宽且无法调整。
    // 超过约 120 字符的文本截短，完整内容只保留在日志中。
    const QString elided = message.length() > 120
        ? message.left(117) + QStringLiteral("...")
        : message;
    m_statusLabel->setText(elided);
    m_statusLabel->setWordWrap(true);
    m_statusLabel->setMaximumWidth(480);
    m_statusLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Preferred);
}

void LdoStructureTransformPage::refreshTypeButtons()
{
    // 已实现的四种变换：同型 Cascode、异型 Cascode、替换成电阻、Stack 串联。
    // 选中 MOS 后可用；未选中时全禁用。并联扩展（parallel）、分支复制（branch）
    // 尚未实现，始终禁用。
    const bool enabled = !m_selectedDeviceId.empty();
    const std::vector<QString> enabledIds = {
        "same_cascode", "cross_cascode", "resistor", "stack"};
    for (auto *btn : m_typeGroup->buttons()) {
        const QString id = btn->property("transformTypeId").toString();
        const bool allowed = std::find(enabledIds.begin(), enabledIds.end(), id)
            != enabledIds.end();
        btn->setEnabled(enabled && allowed);
    }
}

std::string LdoStructureTransformPage::currentParameterMode() const
{
    const auto device = m_scanDevices.find(m_selectedDeviceId);
    if (device == m_scanDevices.end()) return "unsupported";
    if (m_draft.type != "cross_cascode" || m_draft.newMaster.empty()) {
        return device->second.parameter_mode;
    }
    const auto candidate = device->second.candidate_parameter_modes.find(m_draft.newMaster);
    return candidate == device->second.candidate_parameter_modes.end()
        ? "unsupported" : candidate->second;
}

void LdoStructureTransformPage::refreshDraftControls()
{
    const bool isResistor = m_draft.type == "resistor";
    const bool isStack = m_draft.type == "stack";
    const bool isCascode = m_draft.type == "same_cascode" ||
                           m_draft.type == "cross_cascode";

    // 使用原管尺寸/自定义W-L 的 radio 行：仅 MOS 尺寸类变换（Cascode/Stack）显示，
    // 替换成电阻类型隐藏（电阻用阻值 R，不用 W/L）。
    const bool isSizeBased = isCascode || isStack;
    if (m_sizeModeRow != nullptr) {
        m_sizeModeRow->setVisible(isSizeBased);
    }

    const std::string mode = currentParameterMode();
    const bool custom = m_draft.customSize && mode != "unsupported";
    if (m_wlRow != nullptr) m_wlRow->setVisible(isSizeBased && mode == "w_l");
    if (m_wfnflRow != nullptr) m_wfnflRow->setVisible(isSizeBased && mode == "wf_nf_l");
    m_wEdit->setEnabled(isSizeBased && custom && mode == "w_l");
    m_wfEdit->setEnabled(isSizeBased && custom && mode == "wf_nf_l");
    m_nfEdit->setEnabled(isSizeBased && custom && mode == "wf_nf_l");
    m_lEdit->setEnabled(isSizeBased && custom);
    if (m_customSize != nullptr) m_customSize->setEnabled(isSizeBased && mode != "unsupported");
    if (m_customSize != nullptr) {
        m_customSize->setText(mode == "wf_nf_l" ? QStringLiteral("自定义 WF / NF / L")
                                                : QStringLiteral("自定义 W / L"));
    }
    if (m_parameterModeLabel != nullptr) {
        m_parameterModeLabel->setVisible(isSizeBased && mode == "unsupported");
        m_parameterModeLabel->setText(QStringLiteral("该器件 CDF 未完整声明 W/L 或 WF/NF/L，不能自定义尺寸。"));
    }

    // R 行：仅"替换成电阻"类型显示。
    if (m_resistorRow != nullptr) {
        m_resistorRow->setVisible(isResistor);
    }
    if (m_rEdit != nullptr) {
        m_rEdit->setEnabled(isResistor);
    }

    // 级数 N 行：仅 Stack 串联类型显示。
    if (m_stagesRow != nullptr) {
        m_stagesRow->setVisible(isStack);
    }
    m_stagesSpin->setEnabled(isStack);

    // 候选 MOS 下拉：异型 Cascode 始终显示（无候选时显示空下拉+提示）。
    const bool isCrossCascode = m_draft.type == "cross_cascode";
    const bool hasCandidates = !m_candidateMasters.isEmpty();
    if (m_candidateRow != nullptr) {
        m_candidateRow->setVisible(isCrossCascode);
    }
    if (m_candidateCombo != nullptr) {
        if (isCrossCascode && !hasCandidates) {
            m_candidateCombo->clear();
            m_candidateCombo->addItem(QStringLiteral("（无可用候选 MOS）"));
            m_candidateCombo->setEnabled(false);
        } else {
            m_candidateCombo->setEnabled(isCrossCascode && hasCandidates);
        }
    }
}

void LdoStructureTransformPage::refreshDeviceListLabels()
{
    // 收集已修改的 deviceId 集合
    std::set<std::string> modifiedIds;
    for (const auto &change : m_history) {
        modifiedIds.insert(change.deviceId);
    }
    // 无已修改项时"已修改"过滤按钮置灰；若当前正勾选着又清空（如恢复初始），
    // 主动取消勾选恢复全部列表。
    if (m_modifiedFilterButton != nullptr) {
        m_modifiedFilterButton->setEnabled(!modifiedIds.empty());
        if (modifiedIds.empty() && m_modifiedFilterButton->isChecked()) {
            m_modifiedFilterButton->setChecked(false);  // 触发 refillDeviceList
        }
    }
    // 遍历器件列表项，给已修改的 MOS 加"（已修改）"后缀。
    // 已修改项可选中（用于"变换后"视图定位），但不可重复变换——
    // 确认按钮与配置区可用性由 refreshApplyEnabled 按选中项单独控制。
    for (int i = 0; i < m_deviceList->count(); ++i) {
        QListWidgetItem *item = m_deviceList->item(i);
        if (item == nullptr) continue;
        // 用 UserRole 里的真实 deviceId（完整点分隔路径）匹配。
        // 显示文本仅供阅读（去掉了 ldo_top 前缀 + <> → []），不能用于匹配。
        const QVariant role = item->data(Qt::UserRole);
        if (!role.isValid()) continue;
        const std::string instId = role.toString().toStdString();
        const bool modified = modifiedIds.count(instId) != 0;
        // 去掉旧的"（已修改）"标记再重新加
        QString baseText = item->text();
        const int tagIdx = baseText.indexOf(QStringLiteral("（已修改）"));
        if (tagIdx >= 0) {
            baseText = baseText.left(tagIdx).trimmed();
        }
        if (modified) {
            item->setText(baseText + QStringLiteral("  （已修改）"));
        } else {
            item->setText(baseText);
        }
        // 所有项保持可选中（已修改项选中后由 refreshApplyEnabled 禁用确认）。
        item->setFlags(item->flags() | Qt::ItemIsEnabled);
    }
}

void LdoStructureTransformPage::openTransformedSchematic()
{
    if (!m_transformGenerated) {
        // 无可展示内容：弹框提示后自动切回原结构，避免用户误以为点击无响应。
        QMessageBox::information(
            this, tr("Structure Transform"),
            tr("没有可展示的变换结果，请先点击[确认变换]生成电路。"));
        refreshStatusMessage(QStringLiteral("尚未生成变换后电路，请先点击[生成电路]。"));
        // 切回原结构按钮
        m_showOriginalBtn->setChecked(true);
        updatePreviewTitle("", "", "");
        return;
    }
    if (m_transformedCdsPath.empty()) {
        QMessageBox::information(
            this, tr("Structure Transform"),
            tr("没有可展示的变换结果（电路路径为空）。"));
        refreshStatusMessage(QStringLiteral("变换后电路路径为空。"));
        m_showOriginalBtn->setChecked(true);
        updatePreviewTitle("", "", "");
        return;
    }

    // Virtuoso 应已打开（openOriginalSchematic 时已启动）。
    // 物化只克隆叶子层 cell，顶层 DUT 的同名后缀 view 不一定存在。
    // 从最近一次变换的器件推出其所在子模块 cell，直接打开该 cell 的物化 view。
    // 找不到（理论上不会发生）时回退顶层 DUT cell。
    std::string cell;
    std::string lib = m_transformedLcvLib;
    if (!m_history.empty()) {
        const auto devIt = m_scanDevices.find(m_history.back().deviceId);
        if (devIt != m_scanDevices.end() && !devIt->second.parent_subckt.empty()) {
            cell = devIt->second.parent_subckt;
            if (!devIt->second.parent_lib.empty()) {
                lib = devIt->second.parent_lib;
            }
        }
    }
    if (cell.empty()) {
        cell = m_transformedLcvCell;
    }
    // 打开前校验 view 存在（物化只克隆叶子层，部分 cell 无后缀 view），
    // 不存在则提示并跳过，避免污染窗口服务器致黑窗。
    if (!maau::protocol::CellViewExists(lib, cell, m_transformedLcvView)) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: transformed cellview not exists: "
            << lib << "/" << cell << "/" << m_transformedLcvView;
        QMessageBox::information(
            this, tr("Structure Transform"),
            tr("变换后视图不存在（%1/%2/%3），可能该 cell 未被物化，请检查日志。")
                .arg(QString::fromStdString(lib),
                     QString::fromStdString(cell),
                     QString::fromStdString(m_transformedLcvView)));
        refreshStatusMessage(QStringLiteral("变换后视图不存在，无法预览。"));
        m_showOriginalBtn->setChecked(true);
        return;
    }
    // 与 openOriginalSchematic 相同的重试兜底：Virtuoso 异步启动中窗口未就绪
    // （重开工程后首次切"变换后"的典型场景）时延迟重试一次，不阻塞 GUI 线程。
    // 重试 lambda 捕获 lib/cell/view（值拷贝），不捕获裸 this 以外的悬垂引用。
    auto tryOpen = [this, lib, cell, view = m_transformedLcvView]() {
        uint64_t wId = 0;
        if (!maau::protocol::GetSchematicWindowIdEx(lib, cell, view, wId)) {
            GUI_LDO_LOG(WARNING)
                << "structure-transform preview: GetSchematicWindowId failed for "
                << lib << "/" << cell << "/" << view;
            return false;
        }
        embedSchematicWindow(wId);
        updatePreviewTitle(lib, cell, view);
        refreshStatusMessage(QStringLiteral("已切换到变换后电路。"));
        return true;
    };
    if (tryOpen()) {
        return;
    }
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: transformed window not ready for "
        << lib << "/" << cell << "/" << m_transformedLcvView
        << ", retrying in 1s...";
    QTimer::singleShot(1000, this, [this, tryOpen]() {
        if (!tryOpen()) {
            // 重试仍失败：保留当前容器，提示并切回"原结构"按钮态。
            refreshStatusMessage(QStringLiteral("无法获取变换后电路窗口，详情见日志。"));
            m_showOriginalBtn->setChecked(true);
        }
    });
}

void LdoStructureTransformPage::clearSchematicContainer()
{
    if (m_schematicContainer == nullptr) {
        return;
    }
    auto *layout = m_schematicContainer->layout();
    if (layout == nullptr) {
        return;
    }
    QLayoutItem *item = nullptr;
    while ((item = layout->takeAt(0)) != nullptr) {
        delete item->widget();
        delete item;
    }
    m_originalLoaded = false;
}

void LdoStructureTransformPage::embedWindow(uint64_t wId)
{
    if (m_schematicContainer == nullptr) {
        return;
    }
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: embedWindow enter, wId=" << wId;
    auto *win = QWindow::fromWinId(static_cast<WId>(wId));
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: fromWinId(" << wId << ") -> QWindow="
        << (win == nullptr ? "NULL" : "valid");
    if (win == nullptr) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: fromWinId returned null for wId="
            << wId << ", abort embed";
        return;
    }
    auto *diagram = QWidget::createWindowContainer(win, m_schematicContainer);
    auto *layout = m_schematicContainer->layout();
    if (layout == nullptr) {
        auto *box = new QVBoxLayout(m_schematicContainer);
        box->setContentsMargins(0, 0, 0, 0);
        box->addWidget(diagram);
    } else {
        QLayoutItem *item = nullptr;
        while ((item = layout->takeAt(0)) != nullptr) {
            delete item->widget();
            delete item;
        }
        layout->addWidget(diagram);
    }
    m_originalLoaded = true;
}

void LdoStructureTransformPage::openOriginalSchematic()
{
    if (m_context == nullptr) {
        return;
    }
    LdoSpecSelectionData selection;
    if (!m_context->specSelection(selection)) {
        return;
    }
    const auto &caseItem = selection.selected_candidate.case_item;
    GUI_LDO_LOG(DEBUG) << "structure-transform preview: openOriginalSchematic, copy_cds_path="
                      << caseItem.copy_cds_path << ", schematic_lcv="
                      << caseItem.schematic_lib << "/" << caseItem.schematic_cell
                      << "/" << caseItem.schematic_view;
    if (caseItem.copy_cds_path.empty() ||
        !QDir(QString::fromStdString(caseItem.copy_cds_path)).exists()) {
        GUI_LDO_LOG(WARNING) << "structure-transform preview: copy_cds_path empty or not exists: "
                             << caseItem.copy_cds_path;
        clearSchematicContainer();
        return;
    }
    if (caseItem.schematic_lib.empty() || caseItem.schematic_cell.empty() ||
        caseItem.schematic_view.empty()) {
        GUI_LDO_LOG(WARNING) << "structure-transform preview: schematic LCV incomplete, lib="
                             << caseItem.schematic_lib << ", cell=" << caseItem.schematic_cell
                             << ", view=" << caseItem.schematic_view;
        clearSchematicContainer();
        return;
    }
    project::DesignCompilerPathManager pathManager;
    const QString workPath = pathManager.GetLdoProjectPath();
    GUI_LDO_LOG(DEBUG) << "structure-transform preview: workPath=" << workPath;
    if (!m_virtuosoOpened) {
        GUI_LDO_LOG(DEBUG) << "structure-transform preview: launching Virtuoso with cds_path="
                          << caseItem.copy_cds_path << ", workPath=" << workPath;
        if (!maau::protocol::OpenVirtuosoWindow(
                caseItem.copy_cds_path, workPath.toStdString())) {
            GUI_LDO_LOG(WARNING)
                << "structure-transform preview: OpenVirtuosoWindow failed for "
                << caseItem.copy_cds_path;
            m_virtuosoOpened = false;
            return;
        }
        m_virtuosoOpened = true;
    }
    auto lcv = maau::protocol::GetTopLibCellView(
        {caseItem.schematic_lib, caseItem.schematic_cell,
         caseItem.schematic_view});
    GUI_LDO_LOG(DEBUG) << "structure-transform preview: GetTopLibCellView input="
                      << caseItem.schematic_lib << "/" << caseItem.schematic_cell
                      << "/" << caseItem.schematic_view << ", output="
                      << lcv.lib << "/" << lcv.cell << "/" << lcv.view;
    // 打开前校验 view 存在：避免 dbOpenCellViewByType 'r' 模式打开不存在 view
    // 报错并污染窗口服务器（连锁导致后续任何视图都打不开、嵌入黑窗）。
    if (!maau::protocol::CellViewExists(lcv.lib, lcv.cell, lcv.view)) {
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: original cellview not exists: "
            << lcv.lib << "/" << lcv.cell << "/" << lcv.view;
        refreshStatusMessage(QStringLiteral("原电路视图不存在（%1/%2/%3）。")
                .arg(QString::fromStdString(lcv.lib),
                     QString::fromStdString(lcv.cell),
                     QString::fromStdString(lcv.view)));
        return;
    }
    uint64_t wId = 0;
    if (maau::protocol::GetSchematicWindowIdEx(
            lcv.lib, lcv.cell, lcv.view, wId)) {
        GUI_LDO_LOG(DEBUG) << "structure-transform preview: GetSchematicWindowId success, wId=" << wId;
        embedWindow(wId);
        updatePreviewTitle(lcv.lib, lcv.cell, lcv.view, true);
        return;
    }
    // Virtuoso 异步启动中，窗口未就绪。用 QTimer 延迟重试，不阻塞 GUI 线程，
    // 避免主线程 sleep 导致界面卡死、后续扫描 MOS 无法执行。
    GUI_LDO_LOG(DEBUG)
        << "structure-transform preview: Virtuoso window not ready for "
        << lcv.lib << "/" << lcv.cell << "/" << lcv.view << ", retrying...";
    QTimer::singleShot(1000, this, [this, lcv = std::move(lcv)]() {
        uint64_t retryWId = 0;
        if (maau::protocol::GetSchematicWindowIdEx(
                lcv.lib, lcv.cell, lcv.view, retryWId)) {
            GUI_LDO_LOG(DEBUG) << "structure-transform preview: retry GetSchematicWindowId success, wId="
                              << retryWId;
            embedWindow(retryWId);
            updatePreviewTitle(lcv.lib, lcv.cell, lcv.view, true);
            return;
        }
        // 重试仍失败：保留当前容器（不清空），仅记录日志，避免黑窗残留。
        GUI_LDO_LOG(WARNING)
            << "structure-transform preview: GetSchematicWindowId failed for "
            << lcv.lib << "/" << lcv.cell << "/" << lcv.view
            << " (cellview may not exist in copy_cds_path)";
        m_originalLoaded = false;
    });
}

}  // namespace ldo
}  // namespace gui
}  // namespace maau
