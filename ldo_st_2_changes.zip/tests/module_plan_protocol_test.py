"""修改原因：只检查本次模块计划协议；不导入或修改服务器 skillbridge/Python 调度。"""
import ast
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
build = Path(sys.argv[1])
source = root / "opt_algo/common/structure_transform/st_materialize_main.py"
tree = ast.parse(source.read_text())
convert = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
               and node.name == "prepare_skill_plan")
scope = {"json": json}
exec(compile(ast.Module(body=[convert], type_ignores=[]), str(source), "exec"), scope)


def balanced(text):
    depth = 0
    string = escape = comment = False
    for char in text:
        if comment:
            if char == "\n":
                comment = False
        elif string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                string = False
        elif char == ';':
            comment = True
        elif char == '"':
            string = True
        elif char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
            assert depth >= 0
    assert depth == 0 and not string


for name in ("single", "modules"):
    src, dst = build / (name + ".json"), build / (name + ".il")
    scope["prepare_skill_plan"](str(src), str(dst))
    balanced(dst.read_text())
batch = json.loads((build / "modules.json").read_text())["module_plans"]
assert len(batch) == 2
assert [p["source"]["cell"] for p in batch] == ["bgr_lv8_core", "bgr_lv8_sleep"]
for plan in batch:
    assert len(plan["clone_on_write"]) == 1
    assert plan["clone_on_write"][0]["hierarchy_path"] == "/"
assert '(list "module_plans" (list ' in (build / "modules.il").read_text()

# 修改原因：预检查失败时不能先删第一次成功的 view；静态顺序检查不冒充 Cadence 执行。
skill = (root / "opt_algo/common/skill/script/st_multi_level_materializer.il").read_text()
balanced(skill)
create_instance = skill.split("procedure(stMlApplyCreateInstance(", 1)[1].split("procedure(", 1)[0]
assert 'stMlGet(item "bit_count")' in create_instance
assert 'stMlGet(item "orientation") 1)' not in create_instance
# 阵列 pcell 必须在扫描时就当作一个叶 MOS，不能下钻展开 PCell 内部实例。
service = (root / "circuit_platform/src/modules/st_engine/structure_transform_service.cc").read_text()
scan_body = service.split('const std::string instName = st::NormalizeMosArrayName(inst->GetName());', 1)[1]
leaf = scan_body.split('const bool isLeafDevice =', 1)[1].split(';', 1)[0]
assert 'st::MosArrayBitCount(instName) > 1' in leaf
assert 'st::NormalizeMosArrayName' in service
preflight = skill.split("procedure(stMlPreflight(plan)", 1)[1].split("procedure(", 1)[0]
assert "ddDeleteObj(" not in preflight
entry = skill.split("procedure(StTopologyVariantMaterialize(planPath)", 1)[1]
assert entry.index("foreach(plan plans stMlPreflight(plan))") < entry.index("stMlMaterializePlan(plan)")
worker = skill.split("procedure(stMlMaterializePlan(plan)", 1)[1].split("procedure(", 1)[0]
assert "let((plan " not in worker  # 参数不能被同名局部变量遮蔽。
assert worker.index("ddDeleteObj(existingObj)") < worker.index("stMlCopySourceToClone(entry)")
assert 'unless(plans plans = list(document))' in entry
print("PASS unchanged Python converter, module JSON, SKILL delimiters and preflight-before-delete order")
