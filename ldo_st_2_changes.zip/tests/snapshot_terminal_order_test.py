"""修改原因：本地无 Virtuoso，检查快照端子规范化契约；真实 OA 连接由服务器回归覆盖。"""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
script = (root / "opt_algo/common/skill/script/export_snapshot.il").read_text()

helper_start = script.index("procedure(stBackendCanonicalMosTerminalNames")
helper_end = script.index("\nprocedure(stBackendPolicyTerminalNames", helper_start)
helper = script[helper_start:helper_end]

# np1pp fallback 可以乱序，但仅标准四端 MOS 被规范为 C++ 的 D/G/S/B 契约。
for terminal in ("D", "G", "S", "B"):
    assert f'member("{terminal}" names)' in helper
assert 'equal(length(names) 4)' in helper
assert 'list("D" "G" "S" "B")' in helper
# HiEPDK 已有 policy 与其它非 MOS 器件仍走原顺序，不被无条件重排。
assert 'member(kind list("mos_n" "mos_p" "mos"))' in helper
assert 'else\n      names' in helper

policy_start = helper_end
policy_end = script.index("\nprocedure(stBackendWriteCatalogPolicyRow", policy_start)
policy = script[policy_start:policy_end]
# policy 和 OA instTerms fallback 最终必须经过同一个规范化出口。
assert 'names = if(equal(raw "")' in policy
assert 'foreach(instTerm inst~>instTerms' in policy
canonical_call = 'stBackendCanonicalMosTerminalNames(row names)'
assert canonical_call in policy
assert policy.index(canonical_call) > policy.index('names = if(equal(raw "")')

# 写网表仍按实际端子名查询 OA 连接，而不是按 instTerms 的位置取网。
assert script.count("instTerm = stBackendFindInstTermByName(inst terminalName)") == 2
assert script.count("stBackendNormalizeNetName(instTerm)") >= 4
print("PASS np1pp shuffled MOS order canonicalization; HiEPDK/non-MOS order guard")
