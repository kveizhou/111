#include "st/ResistanceBiasSolver.h"

#include <cassert>
#include <cmath>
#include <iostream>

using namespace st;

namespace {

ResistanceBiasSearchConfig Config(DeviceKind polarity)
{
    ResistanceBiasSearchConfig config;
    config.polarity = polarity;
    config.original_was_saturated = true;
    config.initial_vds = 0.4;
    config.initial_current = 1e-4;
    config.resistance = {"resistance", "r", 1.0, 1e9, 1.0, {}, false};
    return config;
}

void OriginalLimitedThenCascodeLimited(DeviceKind polarity, double second)
{
    auto config = Config(polarity);
    ResistanceBiasSearch search(config);
    assert(search.valid());
    assert(std::fabs(search.next() - 4000.0) < 1e-12);
    search.Update({true, false, true});
    assert(!search.finished() && std::fabs(search.next() - second) < 1e-12);
    search.Update({true, true, false});
    assert(!search.finished());
    assert(std::fabs(search.next() - std::sqrt(4000.0 * second)) < 0.51);
    const double midpoint = search.next();
    search.Update({true, true, true});
    assert(search.finished() && search.solved());
    assert(search.evaluations() == 3);
    assert(std::fabs(midpoint - search.next()) < 1e-12);
}

} // namespace

int main()
{
    OriginalLimitedThenCascodeLimited(DeviceKind::MosN, 8000.0);
    OriginalLimitedThenCascodeLimited(DeviceKind::MosP, 2000.0);
    assert(Config(DeviceKind::MosN).max_evaluations == 20);
    {
        auto config = Config(DeviceKind::MosN);
        ResistanceBiasSearch search(config);
        search.Update({true, true, false});
        assert(std::fabs(search.next() - 2000.0) < 1e-12);
    }
    {
        auto config = Config(DeviceKind::MosP);
        ResistanceBiasSearch search(config);
        search.Update({true, true, false});
        assert(std::fabs(search.next() - 8000.0) < 1e-12);
    }
    {
        auto config = Config(DeviceKind::MosN);
        config.original_was_saturated = false;
        ResistanceBiasSearch search(config);
        search.Update({true, false, true});
        // 线性区原管的 |VDS| 过大，NMOS 需要减小 R。
        assert(std::fabs(search.next() - 2000.0) < 1e-12);
    }
    {
        auto config = Config(DeviceKind::MosN);
        config.resistance.minimum = config.resistance.maximum = 1.0;
        config.initial_vds = 1e-4;
        config.initial_current = 1e-4;
        ResistanceBiasSearch search(config);
        assert(std::fabs(search.next() - 1.0) < 1e-12);
        search.Update({true, false, true});
        assert(search.finished() && !search.solved());
        assert(search.reason().find("quantized") != std::string::npos);
    }
    {
        auto config = Config(DeviceKind::MosN);
        ResistanceBiasSearch search(config);
        search.Update({false, false, false});
        assert(!search.finished() && std::fabs(search.next() - 8000.0) < 1e-12);
    }
    {
        auto config = Config(DeviceKind::MosN);
        config.max_evaluations = 1;
        ResistanceBiasSearch search(config);
        search.Update({true, false, true});
        assert(search.finished() && !search.solved());
        assert(search.reason().find("evaluation_limit") != std::string::npos);
    }
    {
        auto config = Config(DeviceKind::MosN);
        config.initial_current = 0.0;
        ResistanceBiasSearch search(config);
        assert(!search.valid());
    }
    std::cout << "PASS resistance-bias R0, polarity, bracket, quantization and stopping\n";
}
