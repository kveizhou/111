#include "st/ResistanceBiasSolver.h"

#include "st/PdkCatalog.h"

#include <cassert>
#include <cmath>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

using namespace st;

namespace {

DeviceCatalog Catalog()
{
    DeviceCatalog catalog;
    Diagnostic diagnostic;
    for (const char* name : {"nmos", "pmos"}) {
        DeviceDescriptor mos;
        mos.master = name;
        mos.kind = name[0] == 'n' ? DeviceKind::MosN : DeviceKind::MosP;
        mos.terminal_count = 4;
        mos.terminal_names_by_index = {"D", "G", "S", "B"};
        mos.terminal_roles_by_index = {TerminalRole::Drain, TerminalRole::Gate,
                                       TerminalRole::Source, TerminalRole::Bulk};
        mos.terminal_index = {{TerminalRole::Drain, 0}, {TerminalRole::Gate, 1},
                              {TerminalRole::Source, 2}, {TerminalRole::Bulk, 3}};
        mos.normalized_to_cdf = {{"width", "w"}, {"length", "l"}};
        mos.voltage_domain = "core";
        mos.allowed_voltage_domains = {"core"};
        mos.reliability_complete = true;
        mos.bulk_rule_complete = true;
        mos.oa_library = "PDK";
        mos.oa_cell = name;
        mos.limits.max_abs_vgs = 5.0;
        mos.limits.max_abs_vds = 5.0;
        mos.limits.max_abs_vgb = 5.0;
        mos.parameter_constraints["width"] = {"width", "w", 1e-9, 100e-6, 0.0, {}, false};
        mos.parameter_constraints["length"] = {"length", "l", 1e-9, 100e-6, 0.0, {}, false};
        assert(catalog.Add(mos, diagnostic));
    }
    DeviceDescriptor resistor;
    resistor.master = "res";
    resistor.kind = DeviceKind::Resistor;
    resistor.terminal_count = 2;
    resistor.terminal_names_by_index = {"PLUS", "MINUS"};
    resistor.terminal_roles_by_index = {TerminalRole::Positive, TerminalRole::Negative};
    resistor.terminal_index = {{TerminalRole::Positive, 0}, {TerminalRole::Negative, 1}};
    resistor.normalized_to_cdf = {{"resistance", "r"}};
    resistor.parameter_constraints["resistance"] =
        {"resistance", "r", 1.0, 1e30, 1.0, {}, false};
    resistor.voltage_domain = "core";
    resistor.allowed_voltage_domains = {"core"};
    resistor.oa_library = "PDK";
    resistor.oa_cell = "res";
    assert(catalog.Add(resistor, diagnostic));
    return catalog;
}

MosOperatingPoint Point(double vds, double vdsat, double id, double source)
{
    MosOperatingPoint point;
    point.vd = source + vds;
    point.vg = source + 0.4;
    point.vs = source;
    point.vb = 0.0;
    point.id = id;
    point.vgs = 0.4;
    point.vds = vds;
    point.vbs = -source;
    point.vth = 0.3;
    point.vdsat = vdsat;
    point.cgg = 1e-15;
    point.intrinsic_vgs = point.vgs;
    point.intrinsic_vds = vds;
    return point;
}

AutoBiasSolveRequest Request(DeviceKind polarity, bool linear = false)
{
    AutoBiasSolveRequest request;
    request.root_subckt = "TOP";
    request.target_instance = "M0";
    request.nmos_bulk_net = "GND";
    std::vector<Diagnostic> diagnostics;
    const std::string text = polarity == DeviceKind::MosN
        ? "subckt TOP OUT IN GND VDD\nM0 (OUT IN GND GND) nmos w=1u l=240n\nends TOP\n"
        : "subckt TOP OUT IN GND VDD\nM0 (OUT IN VDD VDD) pmos w=1u l=240n\nends TOP\n";
    request.baseline = parseSpectre(text, diagnostics);
    assert(diagnostics.empty());
    request.template_request.operation_id = "op";
    request.template_request.polarity = polarity;
    request.template_request.voltage_domain = "core";
    request.template_request.vhigh_net = "VDD";
    request.template_request.vlow_net = "GND";
    request.template_request.original_source_net = polarity == DeviceKind::MosN ? "GND" : "VDD";
    request.template_request.control_gate_net = "IN";
    request.template_request.control_master = polarity == DeviceKind::MosN ? "nmos" : "pmos";
    request.template_request.cascode_master = request.template_request.control_master;
    const double sign = polarity == DeviceKind::MosN ? 1.0 : -1.0;
    const double source = polarity == DeviceKind::MosN ? 0.0 : 1.2;
    const double vds = sign * (linear ? 0.05 : 0.6);
    const double vdsat = sign * 0.2;
    request.baseline_op.mos["M0"] = Point(vds, vdsat, sign * 1e-4, source);
    request.nominal_identity = {"dut", "bench", "pdk", "tt", "topology", "parameter", "solver"};
    return request;
}

struct Step {
    Step(bool converged_value = true, bool original_region_value = true,
         bool cascode_saturated_value = true, std::string diagnostic_value = {})
        : converged(converged_value), original_region(original_region_value),
          cascode_saturated(cascode_saturated_value),
          diagnostic(std::move(diagnostic_value)) {}

    bool converged;
    bool original_region;
    bool cascode_saturated;
    std::string diagnostic;
};

class FakeHost final : public DcEvaluationHost {
public:
    FakeHost(DeviceKind polarity, MosOperatingPoint baseline, std::vector<Step> steps)
        : polarity_(polarity), baseline_(baseline), steps_(std::move(steps)) {}

    bool Evaluate(const DcEvaluationRequest& request,
                  OperatingPointSnapshot& snapshot, Diagnostic& diagnostic) override
    {
        ++calls;
        const auto* root = request.candidate.find("TOP");
        assert(root != nullptr && root->find("M0") != nullptr &&
               root->find("M0_CAS") != nullptr);
        cascode_parameters = root->find("M0_CAS")->params;
        const Subckt* bias = nullptr;
        for (const auto& subckt : request.candidate.subckts) {
            if (subckt.name.find("VBIAS_") == 0) {
                assert(bias == nullptr);
                bias = &subckt;
            }
        }
        assert(bias != nullptr && bias->instances.size() == 2);
        std::size_t mosCount = 0;
        std::size_t resistorCount = 0;
        for (const auto& instance : bias->instances) {
            if (instance.name.find("R_") == 0) {
                ++resistorCount;
            } else {
                ++mosCount;
            }
            if (instance.name.find("R_BIAS_") == 0) {
                bool parsed = false;
                resistances.push_back(parseSuffixValue(instance.params.at("r"), parsed));
                assert(parsed);
            }
        }
        assert(mosCount == 1 && resistorCount == 1);
        assert(bias->find("N_CAS_REP_N") == nullptr && bias->find("P_CAS_REP_P") == nullptr);
        complete_candidates = complete_candidates && request.candidate.subckts.size() == 2;

        const std::size_t stepIndex = steps_.empty() ? 0U :
            std::min(static_cast<std::size_t>(calls - 1), steps_.size() - 1);
        const Step step = steps_.empty() ? Step{} : steps_.at(stepIndex);
        if (!step.diagnostic.empty()) {
            diagnostic = {DiagCode::BadParam, step.diagnostic};
            return false;
        }
        if (!step.converged) return false;
        snapshot.identity = request.identity;
        const double sign = polarity_ == DeviceKind::MosN ? 1.0 : -1.0;
        const double source = polarity_ == DeviceKind::MosN ? 0.0 : 1.2;
        MosOperatingPoint original = baseline_;
        if (!step.original_region) {
            const bool wasSaturated = std::fabs(baseline_.vds) >= std::fabs(baseline_.vdsat);
            original = Point(sign * (wasSaturated ? 0.05 : 0.6), baseline_.vdsat,
                             baseline_.id, source);
        }
        snapshot.mos["M0"] = original;
        const auto cascode = Point(sign * (step.cascode_saturated ? 0.5 : 0.05),
                                   sign * 0.2, baseline_.id, source + original.vds);
        snapshot.mos["M0_CAS"] = cascode;
        std::string container;
        for (const auto& instance : root->instances) {
            if (instance.model == bias->name) container = instance.name;
        }
        assert(!container.empty());
        const auto scoped = [&container](const std::string& leaf) { return container + "." + leaf; };
        const std::string ctrl = polarity_ == DeviceKind::MosN ? "N_CTRL_REP_N" : "P_CTRL_REP_P";
        auto replica = original;
        // 新拓扑 D 接电源、S 输出 VBIAS；保持各端电压与指定 VDS/VGS 一致。
        replica.vd = polarity_ == DeviceKind::MosN ? 1.2 : 0.0;
        replica.vs = replica.vd - original.vds;
        replica.vg = replica.vs + original.vgs;
        replica.vds = original.vds;
        replica.vbs = replica.vb - replica.vs;
        replica.intrinsic_vds = replica.vds;
        snapshot.mos[scoped(ctrl)] = replica;
        const std::string biasR = polarity_ == DeviceKind::MosN ? "R_BIAS_N" : "R_BIAS_P";
        snapshot.resistors[scoped(biasR)] = {"res", "r=1k", 0.4, 0.2, 1e-4,
                                             5.0, 1.0, 1e-2, "test"};
        return true;
    }

    int calls = 0;
    bool complete_candidates = true;
    std::vector<double> resistances;
    std::map<std::string, std::string> cascode_parameters;

private:
    DeviceKind polarity_;
    MosOperatingPoint baseline_;
    std::vector<Step> steps_;
};

void MissingBaselineNeverCallsHost()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    request.baseline_op.mos.clear();
    FakeHost host(DeviceKind::MosN, Point(0.6, 0.2, 1e-4, 0.0), {});
    const auto result = SolveCascodeResistanceBias(request, catalog, host);
    assert(!result.ok && host.calls == 0);
    request = Request(DeviceKind::MosN);
    request.baseline_op.mos["M0"].id = 0.0;
    const auto zeroCurrent = SolveCascodeResistanceBias(request, catalog, host);
    assert(!zeroCurrent.ok && host.calls == 0);
}

void SeedAndSuccessfulCandidateAreComplete()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    FakeHost host(DeviceKind::MosN, request.baseline_op.mos["M0"], {{}});
    const auto result = SolveCascodeResistanceBias(request, catalog, host);
    if (!result.ok) {
        for (const auto& item : result.diagnostics) std::cerr << item.message << '\n';
        for (const auto& line : result.trace_lines) std::cerr << line << '\n';
    }
    assert(result.ok && host.calls == 1 && host.complete_candidates);
    assert(host.resistances.size() == 1 && std::fabs(host.resistances[0] - 6000.0) < 0.51);
    assert(result.nominal_evaluations == 1 && result.selected_candidate == 1);
    assert(!result.best_effort && !result.evaluation_failed);
    assert(result.trace_lines.size() == 1);
    assert(result.trace_lines[0].find("original_intrinsic_vds") != std::string::npos);
    assert(result.trace_lines[0].find("cascode_vdsat") != std::string::npos);
}

void OriginalFailureThenSuccessAdjustsResistance()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    FakeHost host(DeviceKind::MosN, request.baseline_op.mos["M0"],
                  {{true, false, true}, {true, true, true}});
    const auto result = SolveCascodeResistanceBias(request, catalog, host);
    assert(result.ok && host.calls == 2);
    assert(host.resistances.size() == 2 && std::fabs(host.resistances[1] - 12000.0) < 0.51);
}

void LinearOriginalMustStayLinear()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN, true);
    FakeHost host(DeviceKind::MosN, request.baseline_op.mos["M0"],
                  {{true, false, true}, {true, true, true}});
    const auto result = SolveAutoBias(request, catalog, host);
    if (!result.ok || host.calls != 2) {
        std::cerr << "linear-original calls=" << host.calls << '\n';
        for (const auto& item : result.diagnostics) std::cerr << item.message << '\n';
        for (const auto& line : result.trace_lines) std::cerr << line << '\n';
    }
    assert(result.ok && host.calls == 2);
    assert(std::fabs(host.resistances[0] - 500.0) < 0.51);
    assert(std::fabs(host.resistances[1] - 250.0) < 0.51);
}

void NonconvergenceContinuesButHostFailureStops()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    FakeHost retry(DeviceKind::MosN, request.baseline_op.mos["M0"],
                   {{false, false, false}, {true, true, true}});
    const auto retried = SolveCascodeResistanceBias(request, catalog, retry);
    assert(retried.ok && retry.calls == 2);
    FakeHost failure(DeviceKind::MosN, request.baseline_op.mos["M0"],
                     {{true, true, true, "backend unavailable"}, {}});
    const auto failed = SolveCascodeResistanceBias(request, catalog, failure);
    assert(!failed.ok && failed.evaluation_failed && failure.calls == 1);
}

void EvaluationLimitIsNotSuccess()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    FakeHost host(DeviceKind::MosN, request.baseline_op.mos["M0"],
                  {{true, false, true}});
    const auto result = SolveCascodeResistanceBias(request, catalog, host);
    if (host.calls != 20) {
        std::cerr << "evaluation-limit calls=" << host.calls << " lastR=" << host.resistances.back() << '\n';
        for (const auto& item : result.diagnostics) std::cerr << item.message << '\n';
    }
    assert(!result.ok && !result.best_effort && host.calls == 20);
    assert(result.nominal_evaluations == 20);
}

void CustomSizingIsEvaluatedBeforeAcceptance()
{
    const auto catalog = Catalog();
    auto request = Request(DeviceKind::MosN);
    request.custom_width = 2e-6;
    request.custom_length = 480e-9;
    FakeHost host(DeviceKind::MosN, request.baseline_op.mos["M0"], {{}});
    const auto result = SolveCascodeResistanceBias(request, catalog, host);
    assert(result.ok && host.calls == 1);
    bool widthParsed = false;
    bool lengthParsed = false;
    assert(std::fabs(parseSuffixValue(host.cascode_parameters.at("w"), widthParsed) - 2e-6) < 1e-15);
    assert(std::fabs(parseSuffixValue(host.cascode_parameters.at("l"), lengthParsed) - 480e-9) < 1e-18);
    assert(widthParsed && lengthParsed);
    assert(host.cascode_parameters == result.sizing.cascode_parameters);
}

} // namespace

int main()
{
    MissingBaselineNeverCallsHost();
    SeedAndSuccessfulCandidateAreComplete();
    OriginalFailureThenSuccessAdjustsResistance();
    LinearOriginalMustStayLinear();
    NonconvergenceContinuesButHostFailureStops();
    EvaluationLimitIsNotSuccess();
    CustomSizingIsEvaluatedBeforeAcceptance();
    std::cout << "PASS complete-candidate resistance-bias DC solver and failure handling\n";
}
