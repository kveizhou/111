"""修改原因：执行实际目录构建/TSV代码，复现多个 OA Cell 共用模型时的端子错配。"""
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
build = Path(sys.argv[1])
service = (root / "circuit_platform/src/modules/st_engine/structure_transform_service.cc").read_text()


def definition(name):
    # 修改原因：主流程私有依赖不全；只提取真实函数，替换 Tech 数据输入，不另写算法。
    start = service.index("bool " + name + "(")
    return service[start:service.index("\n}\n", start) + 3]


fixture = r'''
#include "st/Packaging.h"
#include "st/Netlist.h"
#include <algorithm>
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <optional>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

// 修改原因：模拟 *_ana 与 *_stack 共用模型、同名模型别名以及无模型映射三种真实目录边界。
namespace maau::platform {
class Tech {
public:
    void LoadTech(const std::string&) {}
    bool IsValid() const { return true; }
    const std::string& GetPDKName() const { static const std::string n="MOCK_PDK"; return n; }
    bool IsHiEpdk() const { return false; }
    std::optional<const Tech*> GetBase() const { return {}; }
    const std::unordered_set<std::string>& GetMosNList() const {
        static const std::unordered_set<std::string> v={"n18", "n_legacy_stack"}; return v;
    }
    const std::unordered_set<std::string>& GetMosPList() const {
        static const std::unordered_set<std::string> v={"p18"}; return v;
    }
    const std::unordered_set<std::string>& GetResistantList() const {
        static const std::unordered_set<std::string> v={"res"}; return v;
    }
    std::string GetTypeName(const std::string& model) const {
        if(model=="n_legacy_stack") return "n_legacy_ana";
        return model=="res" ? model : model+"_ana";
    }
    const std::unordered_set<std::string>& GetCellNameNMosList() const {
        static const std::unordered_set<std::string> v={"n18_ana","n18_stack","n_legacy_stack","n_unknown"}; return v;
    }
    const std::unordered_set<std::string>& GetCellNamePMosList() const {
        static const std::unordered_set<std::string> v={"p18_ana","p18_stack"}; return v;
    }
    bool IsPMosByCellName(const std::string& cell) const { return cell.front()=='p'; }
    bool IsNMosByCellName(const std::string& cell) const { return cell.front()=='n'; }
    std::string GetModelName(const std::string& cell) const {
        if(cell=="n_unknown") return {};
        if(cell=="n_legacy_stack") return cell;
        return cell.substr(0,3);
    }
    const std::unordered_map<std::string,std::string>& GetInstCDFsMap(const std::string&) const {
        static const std::unordered_map<std::string,std::string> v={{"width","w"},{"length","l"}}; return v;
    }
    std::vector<double> GetConstraintVec(const std::string&,const std::string&,const std::string&) const {return {};}
    std::vector<double> GetLengthConstrains(const std::string&) const {return {};}
    std::vector<double> GetFwConstrains(const std::string&) const {return {};}
};
std::shared_ptr<Tech> CreateTech(const std::string&) { return std::make_shared<Tech>(); }
}
'''

checks = r'''
int main(int argc, char** argv) {
    assert(argc==2);
    st::DeviceCatalog catalog; std::string message;
    assert(BuildCatalogFromTech("mock",catalog,message));
    for(const auto& cell:{"n18_stack","p18_stack","n_legacy_stack","n_unknown"}) {
        const auto* d=catalog.Find(cell);
        assert(d && d->oa_cell==cell && d->oa_library=="MOCK_PDK");
        const auto* alias=catalog.Find(std::string("oa_MOCK_PDK__")+cell);
        assert(alias && alias->oa_cell==cell);
    }
    assert(catalog.Find("n18")->oa_cell=="n18_ana"); // 模型的默认 Cell 仍保持不变。
    assert(catalog.Find("n18_stack")->normalized_to_cdf==catalog.Find("n18")->normalized_to_cdf);
    assert(WriteDevicePolicyTsv(catalog,argv[1],message));
    std::ifstream policy(argv[1]); std::string line;
    std::map<std::string,std::vector<std::string>> orders;
    while(std::getline(policy,line)) {
        std::istringstream row(line); std::vector<std::string> fields; std::string field;
        while(std::getline(row,field,'\t')) fields.push_back(field);
        if(fields.size()!=19 || fields[0]!="MOCK_PDK") continue;
        std::istringstream terminals(fields[18]);
        std::vector<std::string> names;
        while(std::getline(terminals,field,',')) names.push_back(field);
        orders[fields[1]]=names;
    }
    // 修改原因：以原图端子名建立独立连接事实，再通过输出 policy 串到实际变换和封装代码。
    for(const auto& cell:{"n18_stack","p18_stack","n_legacy_stack","n_unknown"}) {
        assert(orders.at(cell)==std::vector<std::string>({"D","G","S","B"}));
        const bool pmos=cell[0]=='p';
        const std::string rail=pmos?"AVDD":"AGND";
        const std::map<std::string,std::string> original={{"D","net0173"},{"G","VBN1"},{"S",rail},{"B",rail}};
        std::ostringstream text;
        text<<"subckt CORE net0173 VBN1 "<<rail<<"\nI128 (";
        for(const auto& terminal:orders.at(cell)) text<<original.at(terminal)<<' ';
        text<<") "<<cell<<"\nends CORE\n";
        std::vector<st::Diagnostic> diagnostics;
        auto before=st::parseSpectre(text.str(),diagnostics); assert(diagnostics.empty());
        st::TransformRequest request; request.operation_id="source_r";
        request.target={"/","CORE","I128"}; request.type=st::TransformType::AddSourceResistor;
        st::ResistorTransformRequest r; r.subckt="CORE"; r.target="I128";
        r.resistor.master="res"; r.requested_resistance=1000; request.payload=r;
        st::ChangeSet changes; st::Diagnostic diagnostic;
        assert(changes.Confirm(request,diagnostic));
        st::Netlist after; auto replay=changes.Generate(before,after,catalog); assert(replay.ok);
        st::OaPlanBuildContext context;
        context.source={"DESIGN","CORE","schematic","cds"};
        context.target={"DESIGN","CORE","schematic_maau_struct_transform","cds"};
        context.clone_map={{context.source,context.target,"/"}};
        context.hierarchy_by_subckt["CORE"]="/"; context.structure_only=true;
        context.preview={"fixture-view","fixture-parameters","fixture-materializer"};
        auto plan=st::BuildPackagedTransformPlan({&before,&after,{},&changes,&replay,{}},catalog,context);
        if(!plan.ok()) for(const auto& error:plan.diagnostics) std::cerr<<cell<<": "<<error.message<<'\n';
        assert(plan.ok() && plan.plan.generated_cells.size()==1);
        std::map<std::string,std::map<std::string,std::string>> connections;
        for(const auto& inst:plan.plan.generated_cells[0].create_instances) {
            for(const auto& connection:inst.connections) connections[inst.name][connection.pdk_terminal]=connection.net;
            if(inst.name=="I128") assert(inst.master.cell==cell);
        }
        const auto& mos=connections.at("I128"); const auto& resistor=connections.at("I128_RS");
        assert(mos.at("D")=="net0173" && mos.at("G")=="VBN1" && mos.at("B")==rail);
        assert(mos.at("S")!=rail && resistor.at("PLUS")==mos.at("S") && resistor.at("MINUS")==rail);
        for(const auto& wrapper:plan.plan.create_instances)
            for(const auto& connection:wrapper.connections) assert(connection.pdk_terminal==connection.net);
    }
    std::cout<<"PASS actual Cell policy entries, model aliases, NMOS/PMOS source-R and package terminal maps\n";
}
'''

build.mkdir(parents=True, exist_ok=True)
source = build / "catalog_terminal_mapping_test.cpp"
source.write_text(fixture + definition("WriteDevicePolicyTsv") + definition("BuildCatalogFromTech") + checks)
binary = build / "catalog_terminal_mapping_test"
subprocess.run([os.environ.get("CXX", "c++"), "-std=c++17", "-O0", "-g", "-Wall", "-Wextra",
                "-I" + str(root / "circuit_platform/src/modules/st_engine"),
                "-I" + str(root / "tests/support"), str(source), *sys.argv[2:], "-o", str(binary)], check=True)
subprocess.run([str(binary), str(build / "device_policy.tsv")], check=True)
