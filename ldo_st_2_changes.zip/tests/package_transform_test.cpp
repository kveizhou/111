#include "st/Packaging.h"
#include "st/AutoBias.h"
#include "st/JsonWriter.h"
#include "st/Naming.h"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <fstream>
using namespace st;

// 修改原因：回归局部封装算法，不调整调用者提供的层级、view 或扫描结果。
DeviceCatalog Catalog()
{
    DeviceCatalog result;
    Diagnostic d;
    for (const auto& name : {"nmos", "nmos_alt", "pmos", "pmos_alt"}) {
        DeviceDescriptor mos;
        mos.master=name; mos.kind=name[0]=='n' ? DeviceKind::MosN : DeviceKind::MosP;
        mos.terminal_count=4; mos.oa_library="PDK"; mos.oa_cell=name;
        mos.terminal_names_by_index={"D","G","S","B"};
        mos.terminal_roles_by_index={TerminalRole::Drain,TerminalRole::Gate,TerminalRole::Source,TerminalRole::Bulk};
        mos.terminal_index={{TerminalRole::Drain,0},{TerminalRole::Gate,1},{TerminalRole::Source,2},{TerminalRole::Bulk,3}};
        mos.normalized_to_cdf={{"width","w"},{"length","l"}};
        mos.voltage_domain="core"; mos.allowed_voltage_domains={"core"};
        mos.reliability_complete=true; mos.bulk_rule_complete=true;
        mos.parameter_constraints["width"].cdf_name="w";
        mos.parameter_constraints["length"].cdf_name="l";
        for (auto& pair:mos.parameter_constraints) { pair.second.minimum=1e-9; pair.second.maximum=100e-6; }
        assert(result.Add(mos,d));
    }
    DeviceDescriptor r; r.master="res"; r.kind=DeviceKind::Resistor;
    r.terminal_count=2; r.oa_library="BASE_PDK"; r.oa_cell="real_res";
    r.terminal_names_by_index={"PLUS","MINUS"};
    r.terminal_roles_by_index={TerminalRole::Positive,TerminalRole::Negative};
    r.terminal_index={{TerminalRole::Positive,0},{TerminalRole::Negative,1}};
    r.normalized_to_cdf={{"resistance","r"}};
    r.parameter_constraints["resistance"].cdf_name="r";
    r.parameter_constraints["resistance"].minimum=1; r.parameter_constraints["resistance"].maximum=1e9;
    r.voltage_domain="core"; r.allowed_voltage_domains={"core"};
    assert(result.Add(r,d)); return result;
}
Netlist Baseline()
{
    std::vector<Diagnostic> d;
    auto n=parseSpectre(R"(
subckt TOP OUT IN GND VDD
B (OUT IN GND VDD) MID
C (OUT IN GND VDD) MID
MROOT (OUT IN GND GND) nmos w=1u l=240n
ends TOP
subckt MID OUT IN GND VDD
D0 (OUT IN GND VDD) LEAF
D1 (OUT IN GND VDD) LEAF
ends MID
subckt LEAF OUT IN GND VDD
M0 (OUT IN GND GND) nmos w=1u l=240n
M1 (OUT IN VDD VDD) pmos w=1u l=240n
ends LEAF
)",d);
    assert(d.empty());
    for (auto& sub:n.subckts) sub.library="DESIGN";
    return n;
}
TransformRequest Request(const InstancePath& path, TransformType type, const DeviceCatalog& cat,
                         const Netlist& n, const std::string& id)
{
    TransformRequest r; r.operation_id=id; r.target=path; r.type=type;
    if (type==TransformType::AddSourceResistor) {
        ResistorTransformRequest p; p.subckt=path.subckt; p.target=path.instance;
        p.requested_resistance=1000; p.resistor.master="res"; r.payload=p;
    } else if (type==TransformType::MosStack) {
        StackTransformRequest p; p.subckt=path.subckt; p.target=path.instance;
        p.stage_count=3; p.structure_only=true; r.payload=p;
    } else {
        CascodeTransformRequest p; p.subckt=path.subckt; p.target=path.instance;
        const auto& orig=*n.find(path.subckt)->find(path.instance);
        p.new_master=type==TransformType::CrossFlavorCascode ? orig.model+"_alt" : "";
        p.voltage_domain="core"; p.nmos_bulk_net="GND";
        AutoBiasTemplateRequest tr; tr.operation_id=id; tr.polarity=cat.Find(orig.model)->kind;
        tr.voltage_domain="core"; tr.control_master=orig.model; tr.cascode_master=p.new_master.empty() ? orig.model : p.new_master;
        tr.vhigh_net="VDD"; tr.vlow_net="GND";
        tr.array_range=MosArrayRange(orig.name);
        tr.original_source_net=orig.nets[2]; tr.control_gate_net=orig.nets[1];
        BiasSizing sizing; Diagnostic init;
        assert(InitialStructuralBias(tr,cat,orig,sizing,init));
        auto built=BuildAutoBiasTemplate(tr,sizing,cat);
        if(!built.ok) for(auto& e:built.diagnostics) std::cerr<<e.message<<'\n';
        assert(built.ok);
        assert(built.elements.size()==2);
        const std::string range=MosArrayRange(orig.name);
        const std::string ctrl=tr.polarity==DeviceKind::MosN?"N_CTRL_REP_N":"P_CTRL_REP_P";
        const std::string biasR=tr.polarity==DeviceKind::MosN?"R_BIAS_N":"R_BIAS_P";
        std::size_t mosCount=0,resistorCount=0;
        for(const auto& element:built.elements) {
            assert(element.name.size()>=range.size() &&
                   element.name.compare(element.name.size()-range.size(),range.size(),range)==0);
            assert(element.name.find("N_CAS_REP_N")==std::string::npos &&
                   element.name.find("P_CAS_REP_P")==std::string::npos);
            assert(element.name.find("P_REF")==std::string::npos &&
                   element.name.find("N_REF")==std::string::npos &&
                   element.name.find("P_OUT")==std::string::npos &&
                   element.name.find("N_OUT")==std::string::npos &&
                   element.name.find("R_REF")==std::string::npos);
            const auto* descriptor=cat.Find(element.model);
            assert(descriptor!=nullptr);
            if(descriptor->kind==DeviceKind::Resistor) ++resistorCount; else ++mosCount;
            if(element.name==ctrl+range) {
                assert(element.nets[0]==(tr.polarity==DeviceKind::MosN?"VHIGH":"VLOW"));
                assert(element.nets[1]=="VG_CTRL"+range);
                assert(element.nets[2]==built.output_net+range);
            }
            if(element.name==biasR+range) {
                assert(element.nets[0]==built.output_net+range);
                assert(element.nets[1]=="VS_ORIG"+range);
            }
        }
        assert(mosCount==1 && resistorCount==1);
        AutoBiasSolveResult solved; solved.ok=true; solved.sizing=sizing;
        p.solved_bias=solved; p.bias_template=built; p.vbias_vhigh_net="VDD"; p.vbias_vlow_net="GND";
        // 即使伪造 solved.ok，旧五器件模板也不能绕过两器件结构门禁。
        auto legacy=p;
        legacy.bias_template->elements.resize(5,legacy.bias_template->elements.front());
        Netlist rejectedNetlist=n;
        const auto rejected=applyCascode(rejectedNetlist,legacy,cat);
        assert(!rejected.ok());
        r.payload=p;
    }
    return r;
}


OaPlanBuildContext Context(const std::string& owner, const std::string& library="DESIGN")
{
    OaPlanBuildContext c;
    c.source={library,owner,"schematic_stb","cds"};
    c.target={library,owner,"schematic_stb__maau_struct_transform","cds"};
    c.clone_map={{c.source,c.target,"/"}};
    c.hierarchy_by_subckt[owner]="/";
    c.preview={"caller-view","caller-parameters","caller-materializer"};
    c.structure_only=true;
    return c;
}
void SameContext(const OaMaterializationPlan& p,const OaPlanBuildContext& c)
{
    assert(p.source==c.source && p.target==c.target && p.clone_map.size()==c.clone_map.size());
    assert(p.preview.variant_id==c.preview.variant_id);
    assert(p.preview.parameter_set_id==c.preview.parameter_set_id);
    assert(p.preview.materializer_version==c.preview.materializer_version);
    for(size_t i=0;i<c.clone_map.size();++i) {
        const auto& a=p.clone_map[i];const auto& b=c.clone_map[i];
        assert(a.source==b.source && a.target==b.target && a.hierarchy_path==b.hierarchy_path);
        assert(a.parent_hierarchy_path==b.parent_hierarchy_path && a.parent_instance_name==b.parent_instance_name);
    }
}
void CheckType(const DeviceCatalog& cat, TransformType type, const std::string& mos, int nameMode)
{
    auto n=Baseline();
    const bool indexed=nameMode==1;
    const bool ranged=nameMode==2;
    auto name=indexed?std::string("I7<0>"):ranged?std::string("I82<29:0>"):mos;
    n.find("LEAF")->find(mos)->name=name;
    const auto before=emitSpectre(n);
    ChangeSet changes;Diagnostic d;
    auto request=Request({"/","LEAF",name},type,cat,n,"op");
    assert(changes.Confirm(request,d));
    Netlist out;auto replay=changes.Generate(n,out,cat);
    if(!replay.ok) for(auto& e:replay.diagnostics) std::cerr<<e.message<<'\n';
    assert(replay.ok && emitSpectre(n)==before);
    const auto& original=*n.find("LEAF")->find(name);
    const auto& transformed=*out.find("LEAF")->find(name);
    assert(original.nets[1]==transformed.nets[1] && original.nets[3]==transformed.nets[3]);
    if(type==TransformType::AddSourceResistor) {
        assert(original.nets[0]==transformed.nets[0] && original.nets[2]!=transformed.nets[2]);
        const auto* r=out.find("LEAF")->find(replay.outcomes[0].addedInstances[0]);
        assert(r && r->nets[0]==transformed.nets[2] && r->nets[1]==original.nets[2]);
    } else if(type==TransformType::MosStack) {
        assert(original.nets[0]==transformed.nets[0]);
        auto source=transformed.nets[2];
        for(auto& added:replay.outcomes[0].addedInstances) {
            const auto& inst=*out.find("LEAF")->find(added);
            assert(inst.nets[0]==source && inst.nets[1]==original.nets[1] && inst.nets[3]==original.nets[3]);
            source=inst.nets[2];
        }
        assert(source==original.nets[2]);
    } else {
        assert(original.nets[0]!=transformed.nets[0] && original.nets[2]==transformed.nets[2]);
        const auto& added=*out.find("LEAF")->find(replay.outcomes[0].addedInstances[0]);
        assert(added.nets[0]==original.nets[0] && added.nets[2]==transformed.nets[0]);
    }
    for(const auto& added:replay.outcomes[0].addedInstances) {
        assert(MosArrayBitCount(added)==(ranged?30U:1U));
        if(ranged) assert(MosArrayRange(added)=="<29:0>");
    }
    auto c=Context("LEAF");PackageTopologyResult packaged;
    auto built=BuildPackagedTransformPlan({&n,&out,{},&changes,&replay,{}},cat,c,&packaged);
    if(!built.ok()) for(auto& e:built.diagnostics) std::cerr<<e.message<<'\n';
    assert(built.ok());SameContext(built.plan,c);
    const char* suffix=type==TransformType::AddSourceResistor?"resistor":type==TransformType::MosStack?"stack":
        type==TransformType::SameTypeCascode?"same_cascode":"cross_cascode";
    const std::string targetCell=indexed?"I7_0":ranged?"I82_29_0":name;
    const std::string cell="LEAF_"+targetCell+"_"+suffix;
    assert(built.plan.generated_cells[0].schematic.cell==cell);
    assert(built.plan.delete_instances.size()==1 && built.plan.delete_instances[0].name==name);
    bool copied=false;
    for(auto& generated:built.plan.generated_cells) {
        assert(generated.schematic.library=="DESIGN" && generated.schematic.view=="schematic");
        assert(generated.symbol.view=="symbol" && generated.symbol.cell==generated.schematic.cell);
        assert(generated.direct_wires.empty());
        std::size_t placed=0;
        for(auto& inst:generated.create_instances) {
            // 修改原因：PMOS Stack 以外的 NMOS、串电阻、Cascode 保持原摆放顺序。
            if(type!=TransformType::MosStack || mos=="M0") {
                assert(inst.location.x==6.0*(placed/20));
                assert(inst.location.y==-3.0*(placed%20));
            }
            ++placed;
            assert(inst.bit_count==(ranged?30U:1U));
            if(ranged) assert(MosArrayRange(inst.name)=="<29:0>");
            if(inst.name==name) {
                copied=true;
                assert(inst.property_source_instance==name && inst.property_source==c.target);
                assert(inst.cdf_parameters.empty());
            } else if(!ranged) assert(inst.name.find_first_of("<>:\\")==std::string::npos);
        }
    }
    for(const auto& wrapper:built.plan.create_instances)
        assert(wrapper.bit_count==(ranged?30U:1U));
    assert(copied);
    assert(packaged.netlist.find("TOP")->find("B")->model=="MID");
    assert(packaged.netlist.find("MID")->find("D0")->model=="LEAF");
    assert(packaged.netlist.find("LEAF")->find(name)->model=="oa_DESIGN__"+cell);
    assert(packaged.netlist.find("LEAF")->find(mos=="M0"?"M1":"M0"));
    const auto json=WritePlanJson(built.plan);
    assert(json.find("module_plans")==std::string::npos && json.find("ST_EDIT")==std::string::npos);
    if(ranged) assert(json.find("\"bit_count\":30")!=std::string::npos);
    std::cout<<"PASS "<<cell<<" S-resistor/D-cascode/shared-gate-stack, original properties, caller context\n";
}
// 修改原因：复现先 core 串电阻、再独立 sleep 做 Stack；不能虚构 core/ref_sleep 父子关系。
void CheckIndependentModules(const DeviceCatalog& cat, const std::string& jsonPath)
{
    auto n=Baseline();
    Subckt first=*n.find("LEAF"), second=first;
    first.name="bgr_lv8_core"; second.name="bgr_lv8_sleep"; second.library="OTHER_DESIGN";
    first.find("M0")->name="M2";
    n.subckts.push_back(first); n.subckts.push_back(second);
    const auto original=emitSpectre(n);
    ChangeSet changes; Diagnostic d; Netlist out;
    const CellViewRef source{"FALLBACK","TOP","schematic","cds"};
    const std::string view="schematic__maau_struct_transform";
    assert(changes.Confirm(Request({"/B",first.name,"M1"},TransformType::AddSourceResistor,cat,n,"first"),d));
    auto replay=changes.Generate(n,out,cat); assert(replay.ok);
    auto single=BuildModuleTransformPlans({&n,&out,{},&changes,&replay,{}},cat,source,view);
    assert(single.ok() && single.plans.size()==1);
    assert(single.Json()==WritePlanJson(single.plans[0]));
    assert(changes.Confirm(Request({"/C",second.name,"M0"},TransformType::MosStack,cat,n,"second"),d));
    replay=changes.Generate(n,out,cat); assert(replay.ok);
    PackageTopologyResult combined;
    auto batch=BuildModuleTransformPlans({&n,&out,{},&changes,&replay,{}},cat,source,view,&combined);
    if(!batch.ok()) for(auto& e:batch.diagnostics) std::cerr<<e.message<<'\n';
    assert(batch.ok() && batch.plans.size()==2 && combined.packages.size()==2);
    const auto& a=batch.plans[0]; const auto& b=batch.plans[1];
    assert(WritePlanJson(a)==single.Json()); // 第二次必须保留第一次电阻操作。
    assert(a.source.cell==first.name && a.source.library=="DESIGN");
    assert(b.source.cell==second.name && b.source.library=="OTHER_DESIGN");
    for(const auto& plan:batch.plans) {
        assert(plan.clone_map.size()==1 && plan.clone_map[0].hierarchy_path=="/");
        assert(plan.clone_map[0].parent_hierarchy_path.empty() && plan.clone_map[0].parent_instance_name.empty());
        assert(plan.source.view=="schematic" && plan.target.view==view);
        assert(plan.source.cell==plan.target.cell && plan.source.library==plan.target.library);
        assert(ValidateOaPlan(plan).empty());
    }
    assert(a.generated_cells[0].schematic.cell=="bgr_lv8_core_M1_resistor");
    assert(b.generated_cells[0].schematic.cell=="bgr_lv8_sleep_M0_stack");
    assert(b.generated_cells[0].create_instances.size()==3);
    assert(combined.netlist.find("TOP")->find("B")->model=="MID");
    assert(combined.netlist.find(first.name)->find("M1")->model=="oa_DESIGN__bgr_lv8_core_M1_resistor");
    assert(combined.netlist.find(second.name)->find("M0")->model=="oa_OTHER_DESIGN__bgr_lv8_sleep_M0_stack");
    if(!jsonPath.empty()) {std::ofstream f(jsonPath); f<<batch.Json(); assert(f.good());}
    // 修改原因：再次回到首个模块时合并其操作；交错历史的 replay/outcome 必须保持对应。
    assert(changes.Confirm(Request({"/B",first.name,"M2"},TransformType::MosStack,cat,n,"third"),d));
    replay=changes.Generate(n,out,cat); assert(replay.ok);
    batch=BuildModuleTransformPlans({&n,&out,{},&changes,&replay,{}},cat,source,view,&combined);
    assert(batch.ok() && batch.plans.size()==2 && combined.packages.size()==3);
    assert(batch.plans[0].generated_cells.size()==2 && batch.plans[1].generated_cells.size()==1);
    assert(emitSpectre(n)==original);
    std::cout<<"PASS independent module roots, resistor then stack, interleaved history, original views and names\n";
}

// 修改原因：验证 PMOS 只反转坐标，且相邻 S/D 同网；覆盖超过 20 级时换列的情况。
void CheckStackPlacement(const DeviceCatalog& cat)
{
    for(const std::string mos:{"M0","M1"}) for(int stages:{2,3,20,21,30,100}) {
        auto baseline=Baseline(); const auto originalText=emitSpectre(baseline);
        auto request=Request({"/","LEAF",mos},TransformType::MosStack,cat,baseline,"layout");
        std::get<StackTransformRequest>(request.payload).stage_count=stages;
        ChangeSet changes; Diagnostic d; assert(changes.Confirm(request,d));
        Netlist out; auto replay=changes.Generate(baseline,out,cat); assert(replay.ok);
        const auto expectedText=emitSpectre(out);
        auto built=BuildPackagedTransformPlan({&baseline,&out,{},&changes,&replay,{}},cat,Context("LEAF"));
        assert(built.ok() && built.plan.generated_cells.size()==1);
        assert(emitSpectre(baseline)==originalText && emitSpectre(out)==expectedText);
        const auto& instances=built.plan.generated_cells.front().create_instances;
        assert(instances.size()==static_cast<std::size_t>(stages));
        std::vector<std::string> chain={mos};
        chain.insert(chain.end(),replay.outcomes.front().addedInstances.begin(),
                     replay.outcomes.front().addedInstances.end());
        std::vector<const OaCreateInstance*> display;
        for(std::size_t i=0;i<instances.size();++i) {
            const auto& inst=instances[i];
            assert(inst.name==chain[i] && inst.orientation=="R0");
            assert(inst.property_source_instance==mos && inst.cdf_parameters.empty());
            const auto* expected=out.find("LEAF")->find(inst.name); assert(expected);
            const auto* descriptor=cat.Find(expected->model); assert(descriptor);
            assert(inst.connections.size()==expected->nets.size());
            for(std::size_t pin=0;pin<expected->nets.size();++pin) {
                assert(inst.connections[pin].pdk_terminal==descriptor->terminal_names_by_index[pin]);
                assert(inst.connections[pin].net==expected->nets[pin]);
            }
            display.push_back(&inst);
        }
        std::sort(display.begin(),display.end(),[](const auto* a,const auto* b) {
            return a->location.x==b->location.x ? a->location.y>b->location.y : a->location.x<b->location.x;
        });
        if(mos=="M1") std::reverse(chain.begin(),chain.end());
        const auto net=[](const OaCreateInstance& inst,const std::string& terminal) {
            for(const auto& c:inst.connections) if(c.pdk_terminal==terminal) return c.net;
            assert(false); return std::string();
        };
        for(std::size_t i=0;i<display.size();++i) {
            assert(display[i]->name==chain[i]);
            assert(display[i]->location.x==6.0*(i/20) && display[i]->location.y==-3.0*(i%20));
            if(i>0) {
                // PMOS 上管 D 接下管 S；NMOS 上管 S 接下管 D，换列处也保持串联网络。
                assert(net(*display[i-1],mos=="M1"?"D":"S")==net(*display[i],mos=="M1"?"S":"D"));
            }
        }
    }
    std::cout<<"PASS NMOS/PMOS Stack placement: 2/3/20/21/30/100 stages, unchanged D/G/S/B and properties\n";
}

int main(int argc,char** argv)
{
    const auto cat=Catalog();
    // best_effort 只是诊断状态，不能作为 FixedBias 的结构成功凭据。
    auto unprovenNetlist=Baseline();
    auto unproven=Request({"/","LEAF","M0"},TransformType::SameTypeCascode,
                          cat,unprovenNetlist,"unproven");
    auto& unprovenCascode=std::get<CascodeTransformRequest>(unproven.payload);
    unprovenCascode.experimental_dc=true;
    unprovenCascode.solved_bias->ok=false;
    unprovenCascode.solved_bias->best_effort=true;
    if(applyCascode(unprovenNetlist,unprovenCascode,cat).ok()) {
        std::cerr<<"best_effort must not bypass real-DC acceptance\n";
        return 2;
    }
    CheckStackPlacement(cat);
    CheckIndependentModules(cat,argc>2?argv[2]:"");
    for(auto type:{TransformType::AddSourceResistor,TransformType::SameTypeCascode,
                   TransformType::CrossFlavorCascode,TransformType::MosStack})
        for(auto mos:{"M0","M1"}) for(int nameMode=0;nameMode<3;++nameMode)
            CheckType(cat,type,mos,nameMode);
    auto n=Baseline();
    n.find("LEAF")->find("M1")->name="I7_0__RS";
    NameAllocator names(n,"LEAF");
    const std::string ranged=NormalizeMosArrayName("I0/I36/I82[29:0]");
    assert(ranged=="I0/I36/I82<29:0>");
    assert(MosArrayRange(ranged)=="<29:0>" && MosArrayBitCount(ranged)==30);
    assert(NormalizeMosArrayName("M0")=="M0" && MosArrayBitCount("M0")==1);
    assert(names.Allocate(NameKind::Instance,"I7<0>_RS")=="I7_0__RS_2");
    assert(names.Allocate(NameKind::Instance,"I7<0>_RS")=="I7_0__RS_3");
    n=Baseline();
    ChangeSet changes; Diagnostic d;
    assert(changes.Confirm(Request({"/","TOP","MROOT"},TransformType::AddSourceResistor,cat,n,"root"),d));
    assert(changes.Confirm(Request({"/","LEAF","M0"},TransformType::AddSourceResistor,cat,n,"leaf_n"),d));
    assert(changes.Confirm(Request({"/","LEAF","M1"},TransformType::MosStack,cat,n,"leaf_p"),d));
    Netlist out;auto replay=changes.Generate(n,out,cat);assert(replay.ok);
    auto c=Context("TOP");
    CellViewRef midSource{"DESIGN","MID","schematic","cds"},midTarget{"DESIGN","MID","variant","cds"};
    CellViewRef leafSource{"SUBLIB","LEAF","schematic","cds"},leafTarget{"SUBLIB","LEAF","variant","cds"};
    c.clone_map.push_back({midSource,midTarget,"/B","/","B"});
    c.clone_map.push_back({leafSource,leafTarget,"/B/D0","/B","D0"});
    c.hierarchy_by_subckt["MID"]="/B";c.hierarchy_by_subckt["LEAF"]="/B/D0";
    PackageTopologyResult combined;
    auto built=BuildPackagedTransformPlan({&n,&out,{},&changes,&replay,{}},cat,c,&combined);
    if(!built.ok()) for(auto& e:built.diagnostics) std::cerr<<e.message<<'\n';
    assert(built.ok());SameContext(built.plan,c);
    assert(built.plan.generated_cells.size()==3 && combined.packages.size()==3);
    for(auto& generated:built.plan.generated_cells)
        assert(generated.schematic.library==(generated.schematic.cell.find("LEAF_")==0?"SUBLIB":"DESIGN"));
    assert(combined.netlist.find("MID")->find("D1")->model=="LEAF");
    if(argc>1) {std::ofstream f(argv[1]);f<<WritePlanJson(built.plan);assert(f.good());}
    // 修改原因：没有调用者提供的层级映射就说明集成不完整；算法不得自行增加祖先复制策略。
    c.hierarchy_by_subckt.erase("LEAF");
    assert(!BuildPackagedTransformPlan({&n,&out,{},&changes,&replay,{}},cat,c).ok());
    // Existing callers that did not request descriptive naming keep their names.
    ChangeSet single;assert(single.Confirm(Request({"/","LEAF","M0"},TransformType::AddSourceResistor,cat,n,"legacy"),d));
    replay=single.Generate(n,out,cat);
    auto legacy=PackageTopologyVariant({&n,&out,"LEAF",&single,&replay,{"OLD","DESIGN"}});
    assert(legacy.ok() && legacy.packages[0].cell_name=="OLD__PKG0001");
    std::cout<<"PASS multiple owners, owner libraries, no context changes, legacy naming\n";
}
