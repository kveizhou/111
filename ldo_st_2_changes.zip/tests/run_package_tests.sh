#!/usr/bin/env bash
set -euo pipefail
# 修改原因：提供不依赖私有主流程的算法回归；不替代服务器完整编译和 Cadence 验证。
cd "$(dirname "$0")/.."
st_source=circuit_platform/src/modules/st_engine
st_build="${TMPDIR:-/tmp}/ldo_st2_package_transform_tests"
mkdir -p "$st_build"
st_sources=()
for name in AutoBias Bias ChangeSet DcSolver JsonWriter Materialization Naming Netlist OaPlan OperatingPoint Packaging PdkCatalog ResistorStress Solver Transaction Transform Validate VariantVerifier; do
    st_sources+=("$st_source/$name.cpp")
done
st_sources+=("$st_source/ResistanceBiasSolver.cc")
"${CXX:-c++}" -std=c++17 -O0 -g -Wall -Wextra -I"$st_source" -Itests/support tests/package_transform_test.cpp "${st_sources[@]}" -o "$st_build/package_transform_test"
# 修改原因：测试真实计划 JSON 经原 Python 转换器进入 SKILL 的单模块/多模块协议。
"$st_build/package_transform_test" "$st_build/single.json" "$st_build/modules.json"
python3 tests/module_plan_protocol_test.py "$st_build"
# 修改原因：覆盖真实 Cell 别名登记到 policy、再到封装端子连接的回归。
python3 tests/catalog_terminal_mapping_test.py "$st_build" "${st_sources[@]}"
# 修改原因：覆盖 np1pp 乱序 fallback 的规范化出口及 HiEPDK/非 MOS 顺序保护。
python3 tests/snapshot_terminal_order_test.py
# 修改原因：覆盖 R、Stack W/L 的工程单位输入到 CDF 参数计划，避免后缀被再次丢弃。
python3 tests/engineering_input_test.py "$st_build" "${st_sources[@]}"
# 修改原因：独立覆盖 VBIAS 单电阻初值、极性方向、量化和停止条件。
"${CXX:-c++}" -std=c++17 -O0 -g -Wall -Wextra -I"$st_source" -Itests/support \
    tests/resistance_bias_solver_test.cpp "${st_sources[@]}" \
    -o "$st_build/resistance_bias_solver_test"
"$st_build/resistance_bias_solver_test"
# 修改原因：完整候选 DC、原管工作区及宿主失败语义必须独立于假结构成功验证。
"${CXX:-c++}" -std=c++17 -O0 -g -Wall -Wextra -I"$st_source" -Itests/support \
    tests/cascode_resistance_dc_solver_test.cpp "${st_sources[@]}" \
    -o "$st_build/cascode_resistance_dc_solver_test"
"$st_build/cascode_resistance_dc_solver_test"
