"""修改原因：回归真实 UI 解析函数到变换、封装、CDF 参数 JSON 的单位传递。"""
import ast
import json
import math
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
build = Path(sys.argv[1])
ui = (root / "circuit_platform/src/gui/widgets/ldo_generator/pages/ldo_structure_transform_page.cpp").read_text()
start = ui.index("bool ParseTransformValue(")
helper = ui[start:ui.index("\n}\n", start) + 3]
assert "std::stod(change." not in ui
for field in ("r", "w", "wf", "nf", "l"):
    assert "ParseTransformValue(change." + field + "," in ui

# 修改原因：复用现有器件/封装测试数据，直接编译 UI 中的实际函数，避免另写解析实现。
fixtures = (root / "tests/package_transform_test.cpp").read_text().split("int main(", 1)[0]
fixture = r'''
#include <cmath>
#include <iomanip>
PACKAGE_FIXTURES
UI_HELPER

int main()
{
    const std::vector<std::pair<std::string, double>> cases = {
        {"10k",1e4}, {"10K",1e4}, {"10n",1e-8}, {"10N",1e-8},
        {"10u",1e-5}, {"10U",1e-5}, {"10m",1e-2}, {"10M",1e7},
        {"10meg",1e7}, {"10MEG",1e7}, {"10Meg",1e7},
        {"10p",1e-11}, {"10P",1e-11}, {"10f",1e-14}, {"10F",1e-14},
        {"10g",1e10}, {"10G",1e10}, {"10000",1e4},
        {"1e4",1e4}, {"1E-8",1e-8}, {"  10K\t",1e4}
    };
    for (const auto& text : {"", " ", "10abc", "10kk", "nan", "inf", "1e999",
                             "0", "-10k", "1e-999", "10k!"}) {
        double value=0; assert(!ParseTransformValue(text,value));
    }
    for (const auto& item : cases) {
        double value=0; assert(ParseTransformValue(item.first,value));
        assert(std::fabs(value-item.second)<=std::fabs(item.second)*1e-12);
        for (const std::string mos : {"M0","M1"}) {
            auto cat=Catalog(); auto baseline=Baseline();
            auto request=Request({"/","LEAF",mos},TransformType::AddSourceResistor,
                                 cat,baseline,"units");
            std::get<ResistorTransformRequest>(request.payload).requested_resistance=value;
            ChangeSet changes; Diagnostic d; assert(changes.Confirm(request,d));
            Netlist out; auto replay=changes.Generate(baseline,out,cat); assert(replay.ok);
            auto built=BuildPackagedTransformPlan(
                {&baseline,&out,{},&changes,&replay,{}},cat,Context("LEAF"));
            assert(built.ok());
            std::cout<<std::setprecision(17)<<"{\"expected_r\":"<<item.second
                     <<",\"plan\":"<<WritePlanJson(built.plan)<<"}\n";
        }
    }
    for (const std::string mos : {"M0","M1"}) {
        auto cat=Catalog(); auto baseline=Baseline();
        // 修改原因：这里只验证 1200u 的倍率；真实 PDK 尺寸上限仍由其自身决定。
        auto desc=*cat.Find(mos=="M0"?"nmos":"pmos"); Diagnostic d;
        desc.parameter_constraints["width"].maximum=0.01; assert(cat.Add(desc,d));
        auto request=Request({"/","LEAF",mos},TransformType::MosStack,cat,baseline,"size");
        auto& stack=std::get<StackTransformRequest>(request.payload);
        double width=0,length=0;
        assert(ParseTransformValue("1200U",width));
        assert(ParseTransformValue("0.5u",length));
        stack.custom_width=width; stack.custom_length=length;
        ChangeSet changes; assert(changes.Confirm(request,d));
        Netlist out; auto replay=changes.Generate(baseline,out,cat); assert(replay.ok);
        auto built=BuildPackagedTransformPlan(
            {&baseline,&out,{},&changes,&replay,{}},cat,Context("LEAF"));
        assert(built.ok());
        std::cout<<"{\"stack\":true,\"plan\":"<<WritePlanJson(built.plan)<<"}\n";
    }
    // WF/NF/L CDF 不允许在任意环节凭空改成 W/L。
    for (const std::string mos : {"M0","M1"}) {
        auto cat=Catalog(); auto baseline=Baseline(); Diagnostic d;
        for (const std::string& model : {std::string(mos=="M0"?"nmos":"pmos"),
                                       std::string(mos=="M0"?"nmos_alt":"pmos_alt")}) {
            auto desc=*cat.Find(model);
            desc.normalized_to_cdf={{"finger_width","wf"},{"fingers","nf"},{"length","l"}};
            desc.parameter_constraints.clear();
            for (const auto& item : desc.normalized_to_cdf) {
                auto& constraint=desc.parameter_constraints[item.first];
                constraint.semantic_name=item.first; constraint.cdf_name=item.second;
                constraint.minimum=1; constraint.maximum=8;
            }
            desc.parameter_constraints["finger_width"].minimum=1e-9;
            desc.parameter_constraints["finger_width"].maximum=1e-3;
            desc.parameter_constraints["length"].minimum=1e-9;
            desc.parameter_constraints["length"].maximum=1e-3;
            assert(cat.Add(desc,d));
        }
        baseline.find("LEAF")->find(mos)->params={{"wf","0.5u"},{"nf","2"},{"l","240n"}};
        auto makeRequest=[&](TransformType type) {
            return Request({"/","LEAF",mos},type,cat,baseline,"wf_nf");
        };
        auto stackRequest=makeRequest(TransformType::MosStack);
        auto& stack=std::get<StackTransformRequest>(stackRequest.payload);
        stack.custom_finger_width=0.75e-6; stack.custom_fingers=4;
        stack.custom_length=0.3e-6;
        ChangeSet changes; assert(changes.Confirm(stackRequest,d));
        Netlist out; auto replay=changes.Generate(baseline,out,cat); assert(replay.ok);
        auto built=BuildPackagedTransformPlan(
            {&baseline,&out,{},&changes,&replay,{}},cat,Context("LEAF"));
        assert(built.ok());
        std::cout<<"{\"wf_nf_stack\":true,\"plan\":"<<WritePlanJson(built.plan)<<"}\n";
        for (auto type : {TransformType::SameTypeCascode,TransformType::CrossFlavorCascode}) {
            auto request=makeRequest(type);
            auto& cascode=std::get<CascodeTransformRequest>(request.payload);
            cascode.custom_finger_width=0.75e-6; cascode.custom_fingers=4;
            cascode.custom_length=0.3e-6;
            ChangeSet change; assert(change.Confirm(request,d));
            Netlist transformed; auto applied=change.Generate(baseline,transformed,cat);
            assert(applied.ok);
            auto plan=BuildPackagedTransformPlan(
                {&baseline,&transformed,{},&change,&applied,{}},cat,Context("LEAF"));
            assert(plan.ok());
            std::cout<<"{\"wf_nf_cascode\":true,\"plan\":"<<WritePlanJson(plan.plan)<<"}\n";
        }
    }
}
'''.replace("PACKAGE_FIXTURES", fixtures).replace("UI_HELPER", helper)
cpp = build / "engineering_input_test.cpp"
exe = build / "engineering_input_test"
cpp.write_text(fixture)
subprocess.run([os.environ.get("CXX", "c++"), "-std=c++17", "-O0", "-g", "-Wall", "-Wextra",
                "-I" + str(root / "circuit_platform/src/modules/st_engine"),
                "-I" + str(root / "tests"), "-I" + str(root / "tests/support"),
                str(cpp), *sys.argv[2:], "-o", str(exe)], check=True, cwd=root)
result = subprocess.run([str(exe)], check=True, text=True, capture_output=True)


def numeric(text):
    # 修改原因：独立读取最终 JSON 的工程字符串，与测试期望的欧姆/米数值比较。
    scales = {"meg": 1e6, "k": 1e3, "m": 1e-3, "u": 1e-6,
              "n": 1e-9, "p": 1e-12, "g": 1e9}
    for suffix, scale in scales.items():
        if text.endswith(suffix):
            return float(text[:-len(suffix)]) * scale
    return float(text)


records = [json.loads(line) for line in result.stdout.splitlines()]
assert len(records) == 50
for record in records:
    instances = [inst for cell in record["plan"]["generated_cells"]
                 for inst in cell["create_instances"]]
    params = [{p["name"]: p["value"] for p in inst["cdf_parameter_list"]}
              for inst in instances]
    if record.get("wf_nf_stack"):
        assert len(params) == 3
        for p in params:
            assert "w" not in p
            assert math.isclose(numeric(p["wf"]), 0.75e-6, rel_tol=1e-12)
            assert math.isclose(numeric(p["nf"]), 4, rel_tol=1e-12)
            assert math.isclose(numeric(p["l"]), 0.3e-6, rel_tol=1e-12)
    elif record.get("wf_nf_cascode"):
        added = [p for inst, p in zip(instances, params)
                 if inst["name"].endswith("_CAS")]
        assert len(added) == 1
        assert "w" not in added[0]
        assert math.isclose(numeric(added[0]["wf"]), 0.75e-6, rel_tol=1e-12)
        assert math.isclose(numeric(added[0]["nf"]), 4, rel_tol=1e-12)
        assert math.isclose(numeric(added[0]["l"]), 0.3e-6, rel_tol=1e-12)
    elif record.get("stack"):
        assert len(params) == 3
        for p in params:
            assert math.isclose(numeric(p["w"]), 0.0012, rel_tol=1e-12)
            assert math.isclose(numeric(p["l"]), 0.0000005, rel_tol=1e-12)
    else:
        resistors = [p for p in params if "r" in p]
        assert len(resistors) == 1
        assert math.isclose(numeric(resistors[0]["r"]), record["expected_r"], rel_tol=1e-12)

# 修改原因：本机无 Cadence；只检查 SKILL 语法结构和转换入口，不冒充 CDF 执行测试。
skill = (root / "opt_algo/common/skill/script/st_pdk_adapter.il").read_text()
coerce = skill.split("procedure(stAdapterCoerceValue(", 1)[1].split("procedure(", 1)[0]
assert "cdfParseFloatString(value)" in coerce
assert "atof(value)" not in coerce and "atoi(value)" not in coerce
assert "(t value)" in coerce  # 字符串型 CDF 继续保留工程值或表达式原文。
tree = ast.parse((root / "tests/module_plan_protocol_test.py").read_text())
balanced = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "balanced")
scope = {}
exec(compile(ast.Module(body=[balanced], type_ignores=[]), "balanced", "exec"), scope)
scope["balanced"](skill)
print("PASS engineering input: 21 numeric forms, 11 invalid inputs, 42 resistor plans, 2 W/L Stack plans, 2 WF/NF/L Stack plans, 4 WF/NF/L Cascode plans; SKILL static checks only")
