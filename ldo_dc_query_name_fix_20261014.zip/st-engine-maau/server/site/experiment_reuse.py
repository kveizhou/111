"""Explicit same-session experimental evidence reuse; never candidate DC reuse."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from site_data import read_json, write_json, verify_site_inputs
from dc_results import canonical_device


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_files(files):
    if not files:
        raise ValueError('reuse evidence fingerprints missing')
    for path, expected in files.items():
        if digest(path) != expected:
            raise ValueError('reuse evidence changed: '+path)


def active_receipt():
    path=Path(os.environ['ST_EXPERIMENT_REUSE_MANIFEST']).resolve()
    inputs=read_json(os.environ['ST_SITE_INPUTS_MANIFEST'])
    if inputs.get('file_sha256',{}).get(str(path)) != digest(path):
        raise ValueError('reuse receipt is not pinned by active inputs')
    verify_site_inputs(inputs, os.environ)
    receipt=read_json(path)
    if receipt.get('schema')!='cascode-experiment-reuse-v1' or read_json(inputs['rules']).get('validation_scope')!='experimental_dc':
        raise ValueError('reuse requires experimental_dc and supported receipt')
    check_files(receipt['file_sha256'])
    return receipt


def source_request(args, receipt):
    if [args.dut_lib,args.dut_cell,args.dut_view] != receipt['source']:
        return False
    for name in ('corner','dut_hash','bench_hash','pdk_version'):
        if getattr(args,name) != receipt[name]:
            raise ValueError('baseline reuse request changed: '+name)
    if [args.bench_lib,args.bench_cell,args.bench_view] != receipt['bench']:
        raise ValueError('baseline reuse Bench changed')
    if args.solver_version!='st-dc-solver-v3-experimental_dc':
        raise ValueError('baseline reuse solver semantics changed')
    return True


def write_baseline(args, receipt):
    if not source_request(args,receipt) or not receipt.get('mos_rows'):
        return False
    from op_provider import write_tsv, write_mos_tsv
    names=['dut_hash','bench_hash','pdk_version','corner','topology_hash','parameter_hash','solver_version']
    write_tsv(args.identity_output,names+['total_supply_current'],
              [[getattr(args,k) for k in names]+[receipt['total_supply_current']]])
    write_mos_tsv(args.mos_output,receipt['mos_rows'])
    if args.resistor_output:
        write_tsv(args.resistor_output,['instance','master','geometry','vpos','vneg','current','max_voltage','max_power','max_current','rating_source'],[])
    print('BASELINE_DC_REUSED=true\nBASELINE_TARGETS='+','.join(row[0] for row in receipt['mos_rows'])+
          '\nBASELINE_NATIVE_EXECUTIONS=0',flush=True)
    return True


def copy_source_export(args,receipt,directory):
    if not source_request(args,receipt):
        return None
    retained=Path(receipt['simulation_directory'])
    for name in ('dut.scs','bench.scs','oa_bindings.tsv'):
        shutil.copyfile(retained/name,Path(directory)/name)
    print('BASELINE_EXPORT_REUSED=true\nPORT_EVIDENCE_REUSED=true\nDEVICE_BINDINGS_REUSED=true',flush=True)
    return (retained/'simulation.scs').read_text(),receipt['root_path']


def prepare_receipt(candidate, inputs):
    """Read retained successful export and scan once; no native executions."""
    from inspect_cascode_pdk_evidence import latest
    from run_cascode_experiment import pairs
    from baseline_bundle import load_bundle
    from standalone import validate_bundle_profile
    from op_provider import (flatten_dut,physical_signature,bind_physical_devices,
        load_scanned_catalog,read_oa_bindings,read_raw,mos_row,
        require_supported_voltage_semantics,total_supply_measurement)
    from runtime_bridge import accepted_reader_cache
    candidate=Path(candidate).resolve();work=candidate/'work';files={}
    def record(path):
        path=Path(path).resolve();files[str(path)]=digest(path);return path
    cfg=pairs(record(work/'session.conf'))
    profile=read_json(record(inputs['rules']));record(inputs['context'])
    if cfg['validation_scope']!='experimental_dc' or profile['validation_scope']!='experimental_dc':
        raise ValueError('only experimental sessions can reuse this evidence')
    source=[cfg['source_'+k] for k in ('library','cell','view')]
    bundle=load_bundle(profile['validated_baseline_bundle'],dict(zip(('lib','cell','view'),source)),
                       dict(lib=cfg['bench_library'],cell=cfg['bench_cell'],view=cfg['bench_view']),cfg['nominal_corner'],
                       runtime_inputs=inputs)
    validate_bundle_profile(bundle,profile)
    record(bundle['_bundle_path']);record(bundle['bench_netlist'])
    # Use the same full simulation.scs/root_path that found the missing leaves.
    directory=latest((work/'analysis/baseline_op/raw_op').glob('st-op-simulation.*/binding.json')).parent
    binding=read_json(record(directory/'binding.json'))
    if binding['dut']!=source or binding['corner']!=cfg['nominal_corner']:
        raise ValueError('retained export does not belong to this source and Corner')
    for name,field in [('dut.scs','physical_dut_sha256'),('bench.scs','physical_bench_sha256'),('simulation.scs','simulation_sha256')]:
        if digest(record(directory/name))!=binding[field]:raise ValueError('retained export changed: '+name)
    if (directory/'bench.scs').read_text()!=Path(bundle['bench_netlist']).read_text():
        raise ValueError('retained Bench differs from accepted baseline')
    if record(directory/'dut_oa/runtime.done').read_text().strip()!='OK':
        raise ValueError('retained native export did not complete')
    record(directory/'oa_bindings.tsv')
    catalogs=[p for p in (work/'analysis/pdk_scan').glob('run_*/raw_catalog.tsv') if digest(p)==binding['scanned_catalog_sha256']]
    catalog=record(latest(catalogs));identity=record(catalog.parent/'pdk_identity.tsv')
    for p in (work/'before').iterdir():
        if p.is_file():record(p)
    targets=[]
    for p in sorted((work/'changes').glob('*.conf')):
        operation=pairs(record(p));target=operation.get('instance')
        if not target:raise ValueError('confirmed operation target missing')
        targets.append(target)
    if not targets:raise ValueError('no confirmed experimental targets')
    configs=read_json(record(inputs['tech']));tech=[t for t in configs if t['version']==cfg['pdk_version']]
    if len(tech)!=1:raise ValueError('cached PDK version ambiguous')
    catalog_data=load_scanned_catalog(catalog,tech[0],cfg['pdk_version'],'experimental_dc')
    text=(directory/'simulation.scs').read_text();baseline=Path(bundle['bench_netlist']).read_text();root=binding['root_path']
    if root!=bundle['root_path']:raise ValueError('retained hierarchy differs from accepted baseline')
    kept=[]
    physical=bind_physical_devices(text,root,source[1],catalog_data,read_oa_bindings(directory/'oa_bindings.tsv'),
                 baseline_text=baseline,baseline_master=bundle['source_subckt'],preserved_report=kept)
    receipt=dict(schema='cascode-experiment-reuse-v1',source=source,
        bench=[cfg['bench_'+k] for k in ('library','cell','view')],corner=cfg['nominal_corner'],
        dut_hash=cfg['dut_hash'],bench_hash=cfg['bench_hash'],pdk_version=cfg['pdk_version'],
        cds_lib=str(Path(cfg['cds_lib']).resolve()),catalog=str(catalog),pdk_identity=str(identity),
        simulation_directory=str(directory),root_path=root,preserved_resistors=kept,mos_rows=[],
        total_supply_current='NA',baseline_reuse_reason='native circuit differs from saved baseline')
    # A full, effective native leaf comparison is required before reusing DC.
    def signatures(deck,master):
        leaves=flatten_dut(deck,root,master)
        return {d['path']:physical_signature(d) for d in leaves}
    def controls(deck):
        from op_provider import parse_deck
        parsed=parse_deck(deck)
        instances=list(parsed['top'])
        for definition in parsed['definitions'].values():
            instances.extend(definition['instances'])
        instance_lines={i['line'] for i in instances}
        result=[]
        for index,line in enumerate(parsed['lines']):
            clean=line.strip()
            if (index not in instance_lines and clean and not clean.startswith(('//','subckt ','ends'))):
                result.append(clean)
        return result
    if (signatures(text,source[1])==signatures(baseline,bundle['source_subckt'])
            and controls(text)==controls(baseline)):
        bridge=Path(bundle['_bundle_path']).parent.parent
        query=read_json(record(bridge/'query.json'));expected=read_json(record(bridge/'expected_values.json'))
        state=read_json(record(bridge/'bridge_status.json'))
        reader=Path(state.get('reader_cache_dir') or bridge)
        origins=read_json(record(reader/'raw_signed.tsv.sources.json'))
        reader,hashes=accepted_reader_cache(Path(bundle['baseline']),query,expected,origins['psf_sha256'])
        if reader is None:raise ValueError('accepted formal reader cache missing')
        for name in hashes:record(reader/name)
        raw=read_raw(reader/'raw_signed.tsv')
        selected=[entry for entry in physical if entry[0]['output_name'] in targets]
        if len(selected)!=len(set(targets)) or any(c['kind'] not in ('mos_n','mos_p') for _,c,_ in selected):
            raise ValueError('baseline target binding incomplete')
        require_supported_voltage_semantics(selected,origins)
        for device,catalog_row,dev in selected:
            device=dict(device,signal_path=canonical_device(device['path']+dev['signal_postfix']))
            signals=dict(dev['dc_signals']);signals.update(dev['electrical_rules'].get('dc_signals',{}))
            receipt['mos_rows'].append(mos_row(device,raw,catalog_row,signals))
        receipt['total_supply_current']=total_supply_measurement(raw,profile.get('supply_current_signals',[]))
        receipt['baseline_reuse_reason']='accepted DC and native circuit match'
    receipt['file_sha256']=files
    check_files(files)
    return receipt


def copy_scan(receipt,source,cds_lib,catalog,identity):
    if source!=receipt['source'] or str(Path(cds_lib).resolve())!=receipt['cds_lib']:
        raise ValueError('cached PDK scan source differs from request')
    for src,dst in ((receipt['catalog'],catalog),(receipt['pdk_identity'],identity)):
        if Path(src).resolve()==Path(dst).resolve():raise ValueError('cannot overwrite reused evidence')
        shutil.copyfile(src,dst)
    print('PDK_SCAN_REUSED=true',flush=True)


if __name__=='__main__':
    try:
        if len(sys.argv)!=8 or sys.argv[1]!='scan':raise ValueError('invalid scan reuse arguments')
        copy_scan(active_receipt(),sys.argv[2:5],*sys.argv[5:8])
    except (OSError,ValueError,KeyError) as error:
        print('EXPERIMENT_REUSE_ERROR='+str(error),file=sys.stderr);sys.exit(2)
