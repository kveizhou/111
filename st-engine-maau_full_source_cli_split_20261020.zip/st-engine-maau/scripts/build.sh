#!/usr/bin/env bash
set -euo pipefail

tool_only=false
if [[ $# == 1 && "$1" == --tool-only ]]; then
    tool_only=true
elif [[ $# != 0 ]]; then
    echo "usage: $0 [--tool-only]" >&2
    exit 2
fi

project_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
build_dir=${ST_BUILD_DIR:-"$project_dir/build"}

# File modes are sometimes lost while copying the project to the Linux server.
# Normalize only this project's documented command entrypoints.
chmod +x "$project_dir"/scripts/*.sh "$project_dir"/server/*.sh \
    "$project_dir"/server/bin/*.sh "$project_dir"/tests/ServerBackendContractTest.sh \
    "$project_dir"/server/site/*.py

if [[ -n "${CXX:-}" ]]; then
    compiler=$CXX
elif command -v clang++ >/dev/null 2>&1; then
    compiler=clang++
elif command -v g++ >/dev/null 2>&1; then
    compiler=g++
else
    echo "error: clang++ or g++ is required" >&2
    exit 2
fi

mkdir -p "$build_dir/bin" "$build_dir/tests"
common_flags=(-std=c++17 -Wall -Wextra -Wpedantic -Werror -I"$project_dir/include")
core_sources=("$project_dir"/src/*.cpp)

site_library=${ST_MAAU_SITE_HOST_LIBRARY:-}
if [[ "${ST_BUILD_MAAU_SITE_PROVIDER:-OFF}" == "ON" && \
      ( "$site_library" != /* || ! -f "$site_library" ) ]]; then
    echo "error: ST_MAAU_SITE_HOST_LIBRARY must be an existing absolute library path" >&2
    exit 2
fi

"$compiler" "${common_flags[@]}" "${core_sources[@]}" \
    "$project_dir/app/st_circuit_tool.cpp" -o "$build_dir/bin/st_circuit_tool"

if [[ "$tool_only" == true ]]; then
    echo "built tool only: $build_dir/bin/st_circuit_tool"
    exit 0
fi

tests=(
    TestMain
    MainFlowTest
    DeviceCatalogTest
    PdkCatalogTest
    OperatingPointTest
    ResistorStressTest
    TransactionTest
    ChangeSetTest
    BiasTest
    AutoBiasTest
    DcSolverTest
    CascodeTransformTest
    ResistorTransformTest
    StackTransformTest
    OaPlanTest
    PackagingTest
    VariantVerifierTest
    StandaloneTest
    VirtuosoBackendTest
    CliWorkflowTest
)

for test_name in "${tests[@]}"; do
    output_name=$(printf '%s' "$test_name" | tr '[:upper:]' '[:lower:]')
    "$compiler" "${common_flags[@]}" "${core_sources[@]}" \
        "$project_dir/tests/$test_name.cpp" -o "$build_dir/tests/$output_name"
done

maau_sources=(
    "$project_dir/integration/maau/tech_catalog_provider.cc"
    "$project_dir/integration/maau/op_simulation_provider.cc"
    "$project_dir/integration/maau/topology_variant_adapter.cc"
    "$project_dir/integration/maau/topology_variant_materializer.cc"
)

if [[ "${ST_BUILD_MAAU_COMPAT:-OFF}" == "ON" ]]; then
    "$compiler" "${common_flags[@]}" -I"$project_dir/integration/maau" \
        "${core_sources[@]}" "${maau_sources[@]}" \
        "$project_dir/tests/MaauContractTest.cpp" -o "$build_dir/tests/maaucontracttest"
fi

site_marker="$build_dir/bin/st_maau_op_provider.site-linked"
if [[ "${ST_BUILD_MAAU_SITE_PROVIDER:-OFF}" == "ON" ]]; then
    "$compiler" "${common_flags[@]}" -I"$project_dir/integration/maau" \
        "${core_sources[@]}" "${maau_sources[@]}" \
        "$project_dir/integration/maau/site_op_simulation_host.cc" \
        "$project_dir/app/st_maau_op_provider.cpp" \
        "$site_library" \
        -o "$build_dir/bin/st_maau_op_provider"
    printf 'site_op_simulation_host_v1\n' > "$site_marker"
else
    rm -f "$build_dir/bin/st_maau_op_provider" "$site_marker"
fi

for demo_name in DemoCascode DemoChangeSet; do
    output_name=$(printf '%s' "$demo_name" | tr '[:upper:]' '[:lower:]')
    "$compiler" "${common_flags[@]}" "${core_sources[@]}" \
        "$project_dir/examples/$demo_name.cpp" -o "$build_dir/bin/$output_name"
done

echo "built: $build_dir/bin/st_circuit_tool"
echo "tests: $build_dir/tests"
