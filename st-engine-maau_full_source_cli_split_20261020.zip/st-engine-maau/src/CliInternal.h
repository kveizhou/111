#pragma once

#include "st/Standalone.h"
#include "st/VirtuosoBackend.h"

#include <filesystem>
#include <iosfwd>
#include <map>
#include <string>
#include <vector>

namespace st::standalone::detail {

using Options = std::map<std::string, std::string>;

// 会话 Manifest schema=3：记录完整扫描目录的内容身份。
// 这些字段是 generate 自动求解闭环的全部会话级输入，禁止在生成时猜测。
struct SessionManifest {
    std::filesystem::path backend;
    std::filesystem::path cds_lib;
    std::string source_library;
    std::string source_cell;
    std::string source_view;
    std::string source_storage;
    std::string core_subckt;
    std::string variant_library;
    std::string variant_cell;
    std::string variant_id;
    std::filesystem::path skill_script;
    std::string bench_library;
    std::string bench_cell;
    std::string bench_view;
    std::string simulator;
    std::string nominal_corner;
    std::string pvt_corners;
    std::string pdk_version;
    std::string catalog_hash;
    std::string max_branch_current_error;
    std::string max_vbias_current;
    std::string dut_hash;
    std::string bench_hash;
    std::string vbias_vhigh_net;
    std::string vbias_vlow_net;
    std::string validation_scope = "dc_operating_point";
};

bool required(const Options& options, const std::string& name,
              std::string& value, std::string& message);
std::string optional(const Options& options, const std::string& name,
                     const std::string& fallback = {});
bool positiveLimit(const std::string& text, bool currentWithSuffix, double& value);
bool writeAtomic(const std::filesystem::path& path, const std::string& text,
                 std::string& message);
std::string manifestText(const SessionManifest& manifest);
bool readPairs(const std::filesystem::path& path,
               std::map<std::string, std::string>& values, std::string& message);
bool loadManifest(const std::filesystem::path& root,
                  SessionManifest& manifest, std::string& message);
bool loadNetlist(const std::filesystem::path& path, Netlist& netlist,
                 std::string& message);
bool loadCatalog(const std::filesystem::path& root, DeviceCatalog& catalog,
                 std::string& message, bool experimentalDc = false);
std::vector<std::filesystem::path> changeFiles(const std::filesystem::path& root);
bool needsBiasSolve(const TransformRequest& request);
bool prepareScopeRequest(TransformRequest& request, const SessionManifest& manifest,
                         std::string& message);
bool invalidateValidation(const std::filesystem::path& root, std::string& message);
bool loadChangeRequests(const std::filesystem::path& root,
                        const SessionManifest& manifest,
                        std::vector<TransformRequest>& requests,
                        ChangeSet& validated, std::string& message);
bool confirmReplayable(const std::vector<TransformRequest>& requests,
                       ChangeSet& replayable, std::string& message);
std::vector<std::string> splitCommaList(const std::string& input);
std::string jsonEscape(const std::string& text);
std::string formatNumber(double value);
bool writeValidationReport(const std::filesystem::path& root,
                           const std::string& body, std::string& message);

bool catalogHash(const std::filesystem::path& path, std::string& hash,
                 std::string& message);
bool archiveScanLog(const HostStatus& status,
                    const std::filesystem::path& scanDirectory,
                    std::string& message);
bool applyResistorTrials(const std::string& path, DeviceCatalog& catalog,
                        std::ostream& output, std::string& message, bool automatic = false);
bool writeScannedDevicePolicy(const DeviceCatalog& catalog,
                              const std::filesystem::path& path,
                              std::string& message);

int inspectCommand(const Options& options, std::ostream& output,
                   std::ostream& error, ProcessRunner& runner);
int listCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error);
int confirmCommand(const std::filesystem::path& root, const Options& options,
                   std::ostream& output, std::ostream& error);
int undoCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error);
int freshCommand(const std::filesystem::path& root, std::ostream& output,
                 std::ostream& error);
int openCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error, ProcessRunner& runner);

int generateCommand(const std::filesystem::path& root, const Options& options, std::ostream& output,
                    std::ostream& error, ProcessRunner& runner);

} // namespace st::standalone::detail
