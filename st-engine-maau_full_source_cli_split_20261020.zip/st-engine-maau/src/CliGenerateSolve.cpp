#include "CliGenerate.h"
#include "CliDcEvaluation.h"
#include "st/AutoBias.h"
#include <sstream>

namespace st::standalone::detail {

namespace {

std::string paramsJson(const std::map<std::string, std::string>& params)
{
    std::string output = "{";
    bool first = true;
    for (const auto& [name, value] : params) {
        if (!first) output += ',';
        first = false;
        output += '"' + jsonEscape(name) + "\":\"" + jsonEscape(value) + "\"";
    }
    output += '}';
    return output;
}

std::string sizingJson(const BiasSizing& sizing)
{
    std::string output = "{\"mirror_master\":\"" + jsonEscape(sizing.mirror_master) +
        "\",\"resistor_master\":\"" + jsonEscape(sizing.resistor_master) +
        "\",\"nominal_voltage\":" + formatNumber(sizing.nominal_voltage) +
        ",\"iq_delta\":" + formatNumber(sizing.iq_delta) +
        ",\"cascode\":" + paramsJson(sizing.cascode_parameters) + ",\"elements\":{";
    bool first = true;
    for (const auto& [role, params] : sizing.element_parameters) {
        if (!first) output += ',';
        first = false;
        output += '"' + jsonEscape(role) + "\":" + paramsJson(params);
    }
    output += "}}";
    return output;
}

std::string metricsJson(const DcCandidateMetrics& metrics)
{
    return std::string("{\"branch_current_error\":") +
        formatNumber(metrics.branch_current_error) + ",\"control_op_error\":" +
        formatNumber(metrics.control_op_error) + ",\"iq_delta\":" +
        formatNumber(metrics.iq_delta) + ",\"reliability_margin\":" +
        formatNumber(metrics.reliability_margin) + ",\"saturation_margin\":" +
        formatNumber(metrics.saturation_margin) + ",\"area_estimate\":" +
        formatNumber(metrics.area_estimate) + '}';
}

std::string operationTypeName(TransformType type)
{
    switch (type) {
    case TransformType::SameTypeCascode: return "same_type_cascode";
    case TransformType::CrossFlavorCascode: return "cross_flavor_cascode";
    case TransformType::AddSourceResistor: return "add_source_resistor";
    case TransformType::MosStack: return "mos_stack";
    }
    return "unknown";
}

// 按角色语义从实例读取端网（Source/Gate），端子顺序由 PDK 目录提供。
bool terminalNet(const DeviceCatalog& catalog, const Instance& instance,
                 TerminalRole role, std::string& net, std::string& message)
{
    std::size_t index = 0;
    Diagnostic diagnostic;
    if (!catalog.ResolveTerminal(instance.model, role, instance.nets.size(), index,
                                 diagnostic)) {
        message = diagnostic.message;
        return false;
    }
    if (index >= instance.nets.size()) {
        message = "实例 " + instance.name + " 端子数与目录不一致";
        return false;
    }
    net = instance.nets[index];
    return true;
}

} // namespace

struct SolveOperationsState {
    BackendDcEvaluationHost& evaluationHost;
    std::vector<std::string> traceLines;
    std::string resolvedEntries;
    bool anyFailed = false;
    std::string failureMessage;
    std::string backendAbortedBy;
    std::string cumulativeAbortedBy;
    Netlist cumulative;
    ChangeSet cumulativeChanges;
    ReplayResult cumulativeReplay;

    explicit SolveOperationsState(BackendDcEvaluationHost& host) : evaluationHost(host) {}
};

struct OperationReport {
    std::string statusText = "not_required";
    std::string selection = "null";
    std::string sizing = "null";
    std::string metrics = "null";
    std::string diagnosticsJson = "[]";
    std::string pvtReadyJson = "false";
    std::string experimentalPvtReadyJson = "false";
    std::string pvtJson = "[]";
};

void GenerateContext::GenerateSolveBiasOperation(SolveOperationsState& state,
        TransformRequest& request, OperationReport& report)
{
    auto& evaluationHost = state.evaluationHost;
    auto& traceLines = state.traceLines;
    auto& anyFailed = state.anyFailed;
    auto& failureMessage = state.failureMessage;
    auto& backendAbortedBy = state.backendAbortedBy;
    auto& cumulative = state.cumulative;
    auto& statusText = report.statusText;
    auto& selection = report.selection;
    auto& sizing = report.sizing;
    auto& metrics = report.metrics;
    auto& diagnosticsJson = report.diagnosticsJson;
    auto& pvtReadyJson = report.pvtReadyJson;
    auto& experimentalPvtReadyJson = report.experimentalPvtReadyJson;
    auto& pvtJson = report.pvtJson;
    output << "VBIAS_OPERATION=START operation=" << request.operation_id
           << " target=" << request.target.instance
           << " retained_groups=" << electricalChecks.size() << std::endl;
    auto* payload = std::get_if<CascodeTransformRequest>(&request.payload);
    const Subckt* baselineRoot = cumulative.find(manifest.core_subckt);
    const Instance* target = baselineRoot == nullptr
        ? nullptr : baselineRoot->find(request.target.instance);
    const DeviceDescriptor* descriptor = target == nullptr
        ? nullptr : catalog.Find(target->model);
    AutoBiasTemplateRequest templateRequest;
    templateRequest.experimental_dc = experimentalDc;
    bool inputsReady = target != nullptr && descriptor != nullptr &&
        (descriptor->kind == DeviceKind::MosN ||
         descriptor->kind == DeviceKind::MosP);
    if (inputsReady) {
        templateRequest.operation_id = request.operation_id;
        templateRequest.polarity = descriptor->kind;
        templateRequest.voltage_domain = payload->voltage_domain;
        templateRequest.vhigh_net = manifest.vbias_vhigh_net;
        templateRequest.vlow_net = manifest.vbias_vlow_net;
        templateRequest.control_master = target->model;
        templateRequest.cascode_master = payload->new_master.empty()
            ? target->model : payload->new_master;
        inputsReady =
            terminalNet(catalog, *target, TerminalRole::Source,
                        templateRequest.original_source_net, message) &&
            terminalNet(catalog, *target, TerminalRole::Gate,
                        templateRequest.control_gate_net, message);
        // The experimental runner does not specify a separate Bulk.
        // Preserve the proven original body connection for this exact
        // same-master, non-isolated NMOS; also retain it for final replay.
        if (inputsReady && experimentalDc &&
            request.type == TransformType::SameTypeCascode &&
            descriptor->kind == DeviceKind::MosN &&
            descriptor->bulk_rule_complete && !descriptor->isolated_well &&
            templateRequest.cascode_master == target->model &&
            payload->nmos_bulk_net.empty()) {
            inputsReady = terminalNet(catalog, *target, TerminalRole::Bulk,
                                       payload->nmos_bulk_net, message) &&
                          !payload->nmos_bulk_net.empty();
            if (inputsReady) {
                output << "EXPERIMENT_BULK_INHERITED operation=" << request.operation_id
                       << " target=" << request.target.instance
                       << " bulk=" << payload->nmos_bulk_net << '\n';
            }
        }
    }
    if (!inputsReady) {
        anyFailed = true;
        statusText = "no_solution";
        diagnosticsJson = "[\"目标实例不存在、不是MOS或端网无法解析\"]";
        if (failureMessage.empty()) {
            failureMessage = "操作 " + request.operation_id +
                " 的目标实例无法建立求解输入";
        }
    } else {
        AutoBiasSolveRequest solveRequest;
        solveRequest.baseline = cumulative;
        solveRequest.preceding_checks = electricalChecks;
        solveRequest.root_subckt = manifest.core_subckt;
        solveRequest.target_instance = request.target.instance;
        solveRequest.template_request = templateRequest;
        solveRequest.baseline_op = baselineOp;
        solveRequest.nominal_identity = nominalIdentity;
        solveRequest.nmos_bulk_net = payload->nmos_bulk_net;
        solveRequest.tie_isolated_pmos_to_source =
            payload->tie_isolated_pmos_to_source;
        if (!experimentalDc) solveRequest.pvt_corners = splitCommaList(manifest.pvt_corners);
        solveRequest.max_branch_current_error = maxBranchCurrentError;
        solveRequest.max_vbias_current = maxVbiasCurrent;
        auto solved = SolveAutoBias(solveRequest, catalog, evaluationHost);
        if (solved.evaluation_failed) {
            backendAbortedBy = request.operation_id;
            output << "VBIAS_BATCH_STOPPED=true operation=" << request.operation_id
                   << " reason=evaluation_failed" << std::endl;
        }
        traceLines.insert(traceLines.end(), solved.trace_lines.begin(),
                          solved.trace_lines.end());
        sizing = sizingJson(solved.sizing);
        metrics = metricsJson(solved.metrics);
        selection = "{\"candidate\":" + std::to_string(solved.selected_candidate) +
            ",\"evaluations\":" + std::to_string(solved.nominal_evaluations) +
            ",\"dc_feasible\":" + (solved.ok ? "true" : "false") +
            ",\"best_effort\":" + (solved.best_effort ? "true" : "false") +
            ",\"failed_constraints\":[";
        for (std::size_t i = 0; i < solved.failed_constraints.size(); ++i) {
            if (i) selection += ',';
            selection += '"' + jsonEscape(solved.failed_constraints[i]) + '"';
        }
        selection += "]}";
        if (!solved.ok && !(experimentalDc && solved.best_effort)) {
            anyFailed = true;
            statusText = solved.evaluation_failed ? "evaluation_failed" :
                solved.nominal_evaluations == 0 && solved.searched_device_combinations > 0
                ? "construction_failed" : experimentalDc ? "no_valid_dc_candidate" : "no_solution";
            diagnosticsJson = "[";
            bool first = true;
            for (const auto& diagnostic : solved.diagnostics) {
                if (!first) diagnosticsJson += ',';
                first = false;
                diagnosticsJson += '"' + jsonEscape(diagnostic.message) + '"';
            }
            diagnosticsJson += ']';
            if (failureMessage.empty()) {
                failureMessage = "操作 " + request.operation_id +
                    " 自动VBIAS处理失败：" +
                    (solved.diagnostics.empty() ? std::string("unknown")
                                                : solved.diagnostics.front().message);
            }
        } else {
            auto built = BuildAutoBiasTemplate(templateRequest, solved.sizing,
                                               catalog);
            if (!built.ok) {
                anyFailed = true;
                statusText = "no_solution";
                diagnosticsJson = "[\"" +
                    jsonEscape(built.diagnostics.empty()
                                   ? std::string("模板构建失败")
                                   : built.diagnostics.front().message) +
                    "\"]";
                if (failureMessage.empty()) {
                    failureMessage = "操作 " + request.operation_id +
                        " VBIAS模板构建失败";
                }
            } else {
                payload->solved_bias = solved;
                payload->bias_template = built;
                payload->vbias_vhigh_net = manifest.vbias_vhigh_net;
                payload->vbias_vlow_net = manifest.vbias_vlow_net;
                statusText = solved.best_effort ? "best_effort" : "solved";
                output << "VBIAS_SELECTION operation=" << request.operation_id
                       << " result=" << statusText << " point=" << solved.selected_candidate
                       << " evaluations=" << solved.nominal_evaluations
                       << " vbias=" << solved.sizing.nominal_voltage << std::endl;
                output << "VBIAS_CUMULATIVE_CHECK operation=" << request.operation_id
                       << " previous_groups=" << electricalChecks.size()
                       << " result=" << (experimentalDc
                           ? electricalChecks.empty() ? "NOT_APPLICABLE" : "DEFERRED_TO_FINAL"
                           : "PASS") << std::endl;
                pvtReadyJson = solved.pvt_ready && !experimentalDc ? "true" : "false";
                experimentalPvtReadyJson = solved.pvt_ready && experimentalDc ? "true" : "false";
                electricalChecks.push_back(solved.electrical_check);
                pvtJson = "[";
                bool firstCorner = true;
                for (const auto& corner : solved.pvt_results) {
                    if (!firstCorner) pvtJson += ',';
                    firstCorner = false;
                    pvtJson += std::string("{\"corner\":\"") +
                        jsonEscape(corner.corner) + "\",\"ok\":" +
                        (corner.ok ? "true" : "false") +
                        ",\"constraint\":\"" +
                        jsonEscape(corner.failed_constraint) + "\"}";
                }
                pvtJson += ']';
            }
        }
        output << "VBIAS_OPERATION=END operation=" << request.operation_id
               << " result=" << statusText << " evaluations="
               << solved.nominal_evaluations << std::endl;
    }
}

void GenerateContext::GenerateSolveOperation(SolveOperationsState& state, const TransformRequest& input)
{
    auto request = input;
    auto& evaluationHost = state.evaluationHost;
    auto& resolvedEntries = state.resolvedEntries;
    auto& anyFailed = state.anyFailed;
    auto& failureMessage = state.failureMessage;
    auto& backendAbortedBy = state.backendAbortedBy;
    auto& cumulativeAbortedBy = state.cumulativeAbortedBy;
    auto& cumulative = state.cumulative;
    auto& cumulativeChanges = state.cumulativeChanges;
    auto& cumulativeReplay = state.cumulativeReplay;
    OperationReport report;
    auto& statusText = report.statusText;
    auto& selection = report.selection;
    auto& sizing = report.sizing;
    auto& metrics = report.metrics;
    auto& diagnosticsJson = report.diagnosticsJson;
    auto& pvtReadyJson = report.pvtReadyJson;
    auto& experimentalPvtReadyJson = report.experimentalPvtReadyJson;
    auto& pvtJson = report.pvtJson;
    if (!backendAbortedBy.empty() || !cumulativeAbortedBy.empty()) {
        const auto& abortedBy = backendAbortedBy.empty() ? cumulativeAbortedBy : backendAbortedBy;
        statusText = backendAbortedBy.empty() ? "skipped_cumulative_failure" : "skipped_backend_failure";
        diagnosticsJson = "[\"未评估：前序操作 " + jsonEscape(abortedBy) +
            " 未能完成累积选择\"]";
        output << "VBIAS_OPERATION_SKIPPED operation=" << request.operation_id
               << " cause=" << abortedBy << std::endl;
    } else if (needsBiasSolve(request)) {
        GenerateSolveBiasOperation(state, request, report);
    }
    // Replay only selected parameters, never the last attempted point. The
    // next host clones the original OA and materializes this entire prefix.
    if (!anyFailed && backendAbortedBy.empty() && cumulativeAbortedBy.empty()) {
        Diagnostic diagnostic;
        if (!cumulativeChanges.Confirm(request, diagnostic)) {
            anyFailed = true;
            failureMessage = diagnostic.message;
        } else {
            Netlist next;
            cumulativeReplay = cumulativeChanges.Generate(baseline, next, catalog);
            if (!cumulativeReplay.ok) {
                anyFailed = true;
                failureMessage = cumulativeReplay.diagnostics.empty()
                    ? "累积电路组装失败" : cumulativeReplay.diagnostics.front().message;
            } else {
                cumulative = std::move(next);
                // Bias instance names survive packaging. Pin roles to their
                // owning group before another same-polarity group is added.
                for (std::size_t i = 0; i < cumulativeReplay.outcomes.size(); ++i) {
                    const auto& outcome = cumulativeReplay.outcomes[i];
                    if (outcome.bias_instances.empty()) continue;
                    for (auto& check : electricalChecks) {
                        if (check.operation_id != cumulativeChanges.Changes()[i].request.operation_id) continue;
                        for (auto* role : {&check.mirror_ref, &check.mirror_out,
                                &check.cascode_replica, &check.control_replica})
                            role->container_instance = outcome.bias_instances.front();
                        check.resistor.container_instance = outcome.bias_instances.front();
                    }
                }
                evaluationHost.SetPreceding(cumulative, cumulativeChanges, cumulativeReplay);
            }
        }
        if (anyFailed) {
            statusText = "construction_failed";
            diagnosticsJson = "[\"" + jsonEscape(failureMessage) + "\"]";
        }
    }
    if (anyFailed && backendAbortedBy.empty() && cumulativeAbortedBy.empty()) {
        cumulativeAbortedBy = request.operation_id;
        output << "VBIAS_BATCH_STOPPED=true operation=" << request.operation_id
               << " reason=" << statusText << std::endl;
    }
    if (!resolvedEntries.empty()) resolvedEntries += ',';
    resolvedEntries += std::string("{\"operation\":\"") +
        jsonEscape(request.operation_id) + "\",\"type\":\"" +
        operationTypeName(request.type) + "\",\"status\":\"" + statusText +
        "\",\"pvt_ready\":" + pvtReadyJson + ",\"experimental_pvt_ready\":" + experimentalPvtReadyJson + ",\"pvt\":" + pvtJson +
        ",\"selection\":" + selection + ",\"sizing\":" + sizing + ",\"metrics\":" + metrics +
        ",\"diagnostics\":" + diagnosticsJson + '}';
    solvedRequests.push_back(std::move(request));
}

std::unique_ptr<BackendDcEvaluationHost> GenerateContext::CreateEvaluationHost()
{
    return std::make_unique<BackendDcEvaluationHost>(*backend, DcEvaluationHostConfig
        {source, bench, baseline, geometry, manifest.core_subckt,
         manifest.variant_library + "__STAGING", manifest.variant_cell + "__DC",
         manifest.skill_script, root / "analysis/candidates", experimentalDc},
        catalog, output);
}

int GenerateContext::GenerateSolveOperations()
{
    // ---- 3) 逐操作自动求解VBIAS：求解轨迹与已解析参数先落盘，再决定继续与否 ----
    std::vector<Diagnostic> geometryDiagnostics;
    if (!LoadRootGeometryTsv(root / "before/geometry.tsv", geometry,
                             geometryDiagnostics)) {
        error << geometryDiagnostics.front().message << '\n';
        return 4;
    }
    auto evaluationHost = CreateEvaluationHost();
    SolveOperationsState state(*evaluationHost);
    auto& traceLines = state.traceLines;
    auto& resolvedEntries = state.resolvedEntries;
    auto& anyFailed = state.anyFailed;
    auto& failureMessage = state.failureMessage;
    auto& cumulative = state.cumulative;
    auto& cumulativeChanges = state.cumulativeChanges;
    auto& cumulativeReplay = state.cumulativeReplay;
    state.cumulative = baseline;
    evaluationHost->SetPreceding(cumulative, cumulativeChanges, cumulativeReplay);
    if (hasBiasOperation) output << "VBIAS_CUMULATIVE=true" << std::endl;
    // PVT 总结论：配置了 Corner 列表、且所有 FixedBias 求解操作复验全过才为 true。
    pvtConfigured = !structureOnly && !(experimentalDc && hasBiasOperation) && !splitCommaList(manifest.pvt_corners).empty();
    for (const auto& request : requests) {
        GenerateSolveOperation(state, request);
    }
    {
        std::string trace;
        for (const auto& line : traceLines) {
            trace += line;
            trace += '\n';
        }
        if (!writeAtomic(root / "analysis/solver_trace.jsonl", trace, message) ||
            !writeAtomic(root / "analysis/resolved_parameters.json",
                         std::string("{\"validation_scope\":\"") + manifest.validation_scope +
                         "\",\"native_parameter_trials\":" + (nativeParameterTrials ? "true" : "false") +
                         ",\"reliability_verified\":false,\"operations\":[" + resolvedEntries + "]}\n",
                         message)) {
            error << message << '\n'; return 2;
        }
    }
    if (anyFailed) {
        std::ostringstream report;
        report << "ok=false\n"
               << "validation_scope=" << manifest.validation_scope << '\n'
               << "experimental_dc_ready=false\n"
               << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
               << "reliability_verified=false\n"
               << "published=false\n"
               << "structural_ready=false\n"
               << "nominal_dc_ready=false\n"
               << "pvt_ready=false\n"
               << "parameters_quantized=false\n"
               << "ready_for_sizing=false\n"
               << "stage=solve\n"
               << "message=" << failureMessage << '\n'
               << "solver_trace=" << (root / "analysis/solver_trace.jsonl").string() << '\n'
               << "resolved_parameters="
               << (root / "analysis/resolved_parameters.json").string() << '\n';
        if (!writeValidationReport(root, report.str(), message)) {
            error << message << '\n'; return 2;
        }
        error << "自动VBIAS求解失败：" << failureMessage
              << "\n已保留求解轨迹与逐项原因，未写OA计划、未clone、未发布\n";
        return 4;
    }
    return 0;
}

} // namespace st::standalone::detail
