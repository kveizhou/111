#include "CliInternal.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace st::standalone::detail {

namespace {

std::string trim(const std::string& input)
{
    const auto first = input.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = input.find_last_not_of(" \t\r\n");
    return input.substr(first, last - first + 1);
}

} // namespace

bool required(const Options& options, const std::string& name,
              std::string& value, std::string& message)
{
    const auto found = options.find(name);
    if (found == options.end() || found->second.empty()) {
        message = "缺少参数--" + name;
        return false;
    }
    value = found->second;
    return true;
}

std::string optional(const Options& options, const std::string& name,
                     const std::string& fallback)
{
    const auto found = options.find(name);
    return found == options.end() ? fallback : found->second;
}

bool positiveLimit(const std::string& text, bool currentWithSuffix, double& value)
{
    if (text.empty()) return false;
    if (currentWithSuffix) {
        bool parsed = false;
        value = parseSuffixValue(text, parsed);
        return parsed && std::isfinite(value) && value > 0.0;
    }
    try {
        std::size_t used = 0;
        value = std::stod(text, &used);
        return used == text.size() && std::isfinite(value) && value > 0.0;
    } catch (const std::exception&) {
        return false;
    }
}

bool writeAtomic(const std::filesystem::path& path, const std::string& text,
                 std::string& message)
{
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    if (error) {
        message = "无法创建目录" + path.parent_path().string() + "：" + error.message();
        return false;
    }
    const auto temporary = path.string() + ".tmp";
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        output << text;
        if (!output) {
            message = "无法写文件：" + temporary;
            return false;
        }
    }
    std::filesystem::remove(path, error);
    error.clear();
    std::filesystem::rename(temporary, path, error);
    if (error) {
        std::filesystem::remove(temporary);
        message = "无法发布文件" + path.string() + "：" + error.message();
        return false;
    }
    return true;
}

std::string manifestText(const SessionManifest& manifest)
{
    std::ostringstream output;
    output << "schema=3\n"
           << "validation_scope=" << manifest.validation_scope << '\n'
           << "backend=" << manifest.backend.string() << '\n'
           << "cds_lib=" << manifest.cds_lib.string() << '\n'
           << "source_library=" << manifest.source_library << '\n'
           << "source_cell=" << manifest.source_cell << '\n'
           << "source_view=" << manifest.source_view << '\n'
           << "source_storage=" << manifest.source_storage << '\n'
           << "core_subckt=" << manifest.core_subckt << '\n'
           << "variant_library=" << manifest.variant_library << '\n'
           << "variant_cell=" << manifest.variant_cell << '\n'
           << "variant_id=" << manifest.variant_id << '\n'
           << "skill_script=" << manifest.skill_script.string() << '\n'
           << "bench_library=" << manifest.bench_library << '\n'
           << "bench_cell=" << manifest.bench_cell << '\n'
           << "bench_view=" << manifest.bench_view << '\n'
           << "simulator=" << manifest.simulator << '\n'
           << "nominal_corner=" << manifest.nominal_corner << '\n'
           << "pvt_corners=" << manifest.pvt_corners << '\n'
           << "pdk_version=" << manifest.pdk_version << '\n'
           << "catalog_hash=" << manifest.catalog_hash << '\n'
           << "max_branch_current_error=" << manifest.max_branch_current_error << '\n'
           << "max_vbias_current=" << manifest.max_vbias_current << '\n'
           << "dut_hash=" << manifest.dut_hash << '\n'
           << "bench_hash=" << manifest.bench_hash << '\n'
           << "vbias_vhigh_net=" << manifest.vbias_vhigh_net << '\n'
           << "vbias_vlow_net=" << manifest.vbias_vlow_net << '\n';
    return output.str();
}

bool readPairs(const std::filesystem::path& path,
               std::map<std::string, std::string>& values, std::string& message)
{
    std::ifstream input(path);
    if (!input) {
        message = "无法读取会话文件：" + path.string();
        return false;
    }
    std::string line;
    while (std::getline(input, line)) {
        line = trim(line);
        if (line.empty() || line.front() == '#') continue;
        const auto separator = line.find('=');
        if (separator == std::string::npos) {
            message = "会话文件格式错误：" + line;
            return false;
        }
        values[trim(line.substr(0, separator))] = trim(line.substr(separator + 1));
    }
    return true;
}

bool loadManifest(const std::filesystem::path& root,
                  SessionManifest& manifest, std::string& message)
{
    std::map<std::string, std::string> values;
    if (!readPairs(root / "session.conf", values, message)) return false;
    if (values["schema"] != "3") {
        message = "会话文件schema不是3，请用当前版本inspect重建会话";
        return false;
    }
    // 发现会话允许 Bench/轨网/Case 限值留空；generate 再检查仿真入口。
    const char* requiredKeys[] = {"backend", "cds_lib", "source_library",
        "source_cell", "source_view", "source_storage", "core_subckt",
        "variant_library", "variant_cell", "variant_id", "skill_script",
        "simulator", "nominal_corner", "pdk_version", "catalog_hash", "dut_hash"};
    for (const auto* key : requiredKeys) {
        if (values[key].empty()) {
            message = "会话文件缺少字段：" + std::string(key);
            return false;
        }
    }
    manifest.backend = values["backend"];
    manifest.cds_lib = values["cds_lib"];
    manifest.source_library = values["source_library"];
    manifest.source_cell = values["source_cell"];
    manifest.source_view = values["source_view"];
    manifest.source_storage = values["source_storage"];
    manifest.core_subckt = values["core_subckt"];
    manifest.variant_library = values["variant_library"];
    manifest.variant_cell = values["variant_cell"];
    manifest.variant_id = values["variant_id"];
    manifest.skill_script = values["skill_script"];
    manifest.bench_library = values["bench_library"];
    manifest.bench_cell = values["bench_cell"];
    manifest.bench_view = values["bench_view"];
    if (!values["validation_scope"].empty()) manifest.validation_scope = values["validation_scope"];
    if (manifest.validation_scope != "dc_operating_point" && manifest.validation_scope != "structure_only" &&
        manifest.validation_scope != "experimental_dc") {
        message = "未知validation_scope";
        return false;
    }
    const auto scopePath = root / "before/validation_scope.txt";
    std::ifstream scopeInput(scopePath);
    std::string pinnedScope;
    if ((scopeInput && (!std::getline(scopeInput, pinnedScope) ||
                        trim(pinnedScope) != manifest.validation_scope)) ||
        (!scopeInput && manifest.validation_scope == "experimental_dc")) {
        message = "validation_scope与inspect固定范围不一致，请新建隔离会话";
        return false;
    }
    const bool anyBench = !manifest.bench_library.empty() ||
        !manifest.bench_cell.empty() || !manifest.bench_view.empty();
    if (anyBench && (manifest.bench_library.empty() ||
                     manifest.bench_cell.empty() ||
                     manifest.bench_view.empty())) {
        message = "Bench L/C/V 必须成组提供";
        return false;
    }
    manifest.simulator = values["simulator"];
    manifest.nominal_corner = values["nominal_corner"];
    manifest.pvt_corners = values["pvt_corners"];
    manifest.pdk_version = values["pdk_version"];
    manifest.catalog_hash = values["catalog_hash"];
    manifest.max_branch_current_error = values["max_branch_current_error"];
    manifest.max_vbias_current = values["max_vbias_current"];
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            message = "Case支路电流偏差与VBIAS电流上限必须成对提供且为正数";
            return false;
        }
    }
    manifest.dut_hash = values["dut_hash"];
    manifest.bench_hash = values["bench_hash"];
    manifest.vbias_vhigh_net = values["vbias_vhigh_net"];
    manifest.vbias_vlow_net = values["vbias_vlow_net"];
    if (manifest.vbias_vhigh_net.empty() != manifest.vbias_vlow_net.empty()) {
        message = "VBIAS 高低轨网必须成组提供";
        return false;
    }
    return true;
}

bool loadNetlist(const std::filesystem::path& path, Netlist& netlist,
                 std::string& message)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        message = "无法读取网表：" + path.string();
        return false;
    }
    const std::string text((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());
    std::vector<Diagnostic> diagnostics;
    netlist = parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) {
        message = "网表解析失败：" + diagnostics.front().message;
        return false;
    }
    return true;
}

bool loadCatalog(const std::filesystem::path& root, DeviceCatalog& catalog,
                 std::string& message, bool experimentalDc)
{
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(root / "before/device_catalog.tsv", catalog, diagnostics)) {
        message = diagnostics.empty() ? "PDK器件目录读取失败" : diagnostics.front().message;
        return false;
    }
    for (const auto& entry : catalog.Descriptors()) {
        if (entry.second.native_parameter_trials && !experimentalDc) {
            message = "原生参数试点目录只允许experimental_dc：" + entry.first;
            return false;
        }
    }
    return true;
}

std::vector<std::filesystem::path> changeFiles(const std::filesystem::path& root)
{
    std::vector<std::filesystem::path> files;
    std::error_code error;
    const auto directory = root / "changes";
    if (!std::filesystem::exists(directory, error)) return files;
    for (const auto& entry : std::filesystem::directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == ".conf") {
            files.push_back(entry.path());
        }
    }
    std::sort(files.begin(), files.end());
    return files;
}

// FixedBias Cascode 在操作文件里只是"意图声明"：求解结果由 generate
// 自动闭环产生。求解前它不参与网表重放（重放必然因缺少求解结果而失败）。
bool needsBiasSolve(const TransformRequest& request)
{
    if (request.type != TransformType::SameTypeCascode &&
        request.type != TransformType::CrossFlavorCascode) {
        return false;
    }
    const auto* payload = std::get_if<CascodeTransformRequest>(&request.payload);
    return payload != nullptr && payload->gate_policy == GatePolicy::FixedBias &&
        !payload->solved_bias.has_value();
}

bool prepareScopeRequest(TransformRequest& request, const SessionManifest& manifest,
                         std::string& message)
{
    const bool experimentalDc = manifest.validation_scope == "experimental_dc";
    if (auto* cascode = std::get_if<CascodeTransformRequest>(&request.payload))
        cascode->experimental_dc = experimentalDc;
    if (auto* resistor = std::get_if<ResistorTransformRequest>(&request.payload))
        resistor->experimental_dc = experimentalDc;
    if (auto* stack = std::get_if<StackTransformRequest>(&request.payload))
        stack->experimental_dc = experimentalDc;
    if (manifest.validation_scope != "structure_only") return true;
    if (request.type != TransformType::AddSourceResistor && request.type != TransformType::MosStack) {
        message = "structure_only仅支持Source电阻和共栅Stack；Cascode/VBIAS需要DC会话";
        return false;
    }
    if (auto* stack = std::get_if<StackTransformRequest>(&request.payload)) {
        stack->structure_only = true;
    }
    return true;
}

bool invalidateValidation(const std::filesystem::path& root, std::string& message)
{
    std::error_code error;
    std::filesystem::remove(root / "reports/validation.txt", error);
    if (!error) return true;
    message = "无法撤销旧生成验证：" + error.message();
    return false;
}

// 解析并校验全部已确认操作；validated 用于幂等冲突检查，顺序保持文件序。
bool loadChangeRequests(const std::filesystem::path& root,
                        const SessionManifest& manifest,
                        std::vector<TransformRequest>& requests,
                        ChangeSet& validated, std::string& message)
{
    for (const auto& path : changeFiles(root)) {
        auto parsed = ParseTransformRequest(path, manifest.core_subckt);
        if (!parsed.ok) {
            message = parsed.diagnostics.empty() ? "操作文件解析失败" :
                parsed.diagnostics.front().message;
            return false;
        }
        if (!prepareScopeRequest(parsed.request, manifest, message)) return false;
        Diagnostic diagnostic;
        if (!validated.Confirm(parsed.request, diagnostic)) {
            message = diagnostic.message;
            return false;
        }
        requests.push_back(parsed.request);
    }
    return true;
}

bool confirmReplayable(const std::vector<TransformRequest>& requests,
                       ChangeSet& replayable, std::string& message)
{
    for (const auto& request : requests) {
        if (needsBiasSolve(request)) continue;
        Diagnostic diagnostic;
        if (!replayable.Confirm(request, diagnostic)) {
            message = diagnostic.message;
            return false;
        }
    }
    return true;
}

std::vector<std::string> splitCommaList(const std::string& input)
{
    std::vector<std::string> values;
    std::string value;
    std::istringstream stream(input);
    while (std::getline(stream, value, ',')) {
        value = trim(value);
        if (!value.empty()) values.push_back(value);
    }
    return values;
}

std::string jsonEscape(const std::string& text)
{
    std::string escaped;
    for (const char ch : text) {
        switch (ch) {
        case '"': escaped += "\\\""; break;
        case '\\': escaped += "\\\\"; break;
        default:
            if (static_cast<unsigned char>(ch) < 0x20) {
                escaped += '?';
            } else {
                escaped += ch;
            }
        }
    }
    return escaped;
}

std::string formatNumber(double value)
{
    if (!std::isfinite(value)) return "null";
    char buffer[64];
    std::snprintf(buffer, sizeof buffer, "%.6g", value);
    return buffer;
}

bool writeValidationReport(const std::filesystem::path& root,
                           const std::string& body, std::string& message)
{
    return writeAtomic(root / "reports/validation.txt", body, message);
}

} // namespace st::standalone::detail
