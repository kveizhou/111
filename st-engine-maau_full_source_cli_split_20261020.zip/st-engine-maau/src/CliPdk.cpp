#include "CliInternal.h"
#include "st/PdkCatalog.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace st::standalone::detail {

// 对成功解析后的扫描 TSV 计算稳定身份。排序记录行消除 PDK 枚举顺序差异；
// 保留整行字段，避免遗漏可靠性来源、CDF 来源等 JSON 摘要之外的证明数据。
bool catalogHash(const std::filesystem::path& path, std::string& hash,
                 std::string& message)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        message = "无法读取PDK扫描目录：" + path.string();
        return false;
    }
    std::string header;
    if (!std::getline(input, header)) {
        message = "PDK扫描目录为空：" + path.string();
        return false;
    }
    if (!header.empty() && header.back() == '\r') header.pop_back();
    std::vector<std::string> rows;
    std::string row;
    while (std::getline(input, row)) {
        if (!row.empty() && row.back() == '\r') row.pop_back();
        if (!row.empty()) rows.push_back(row);
    }
    if (!input.eof() || rows.empty()) {
        message = "PDK扫描目录读取失败或没有器件：" + path.string();
        return false;
    }
    std::sort(rows.begin(), rows.end());
    std::uint64_t value = UINT64_C(14695981039346656037);
    const auto feed = [&value](const std::string& line) {
        for (const unsigned char character : line) {
            value ^= character;
            value *= UINT64_C(1099511628211);
        }
        value ^= '\n';
        value *= UINT64_C(1099511628211);
    };
    feed(header);
    for (const auto& record : rows) feed(record);
    std::ostringstream output;
    output << std::hex << std::setw(16) << std::setfill('0') << value;
    hash = output.str();
    return true;
}

bool archiveScanLog(const HostStatus& status,
                    const std::filesystem::path& scanDirectory,
                    std::string& message)
{
    if (status.log_path.empty()) {
        message = "PDK扫描缺少后端日志路径";
        return false;
    }
    std::error_code error;
    if (!std::filesystem::copy_file(status.log_path,
            scanDirectory / "scan_pdk.log", std::filesystem::copy_options::none,
            error)) {
        message = "无法留存PDK扫描日志：" + error.message();
        return false;
    }
    return true;
}

bool applyResistorTrials(const std::string& path, DeviceCatalog& catalog,
                        std::ostream& output, std::string& message, bool automatic)
{
    std::ifstream input(path);
    std::string master, cdf, text;
    if (!(input >> master >> cdf >> text)) {
        message = "参考电阻试点文件需要 master CDF values"; return false;
    }
    const auto* source = catalog.Find(master);
    if (!source || source->kind != DeviceKind::Resistor || !source->native_parameter_trials) {
        message = "参考电阻试点必须对应当前原生实验电阻"; return false;
    }
    auto selected = *source;
    selected.native_resistor_auto_search = automatic;
    auto resistance = selected.parameter_constraints.find("resistance");
    if (resistance == selected.parameter_constraints.end() || resistance->second.cdf_name != cdf) {
        message = "参考电阻试点CDF映射与当前目录不一致"; return false;
    }
    std::map<std::string, std::vector<double>> columns;
    const std::string resistanceCdf = cdf, resistanceText = text;
    for (;;) {
        auto found = std::find_if(selected.parameter_constraints.begin(), selected.parameter_constraints.end(),
            [&](const auto& item) { return item.second.cdf_name == cdf; });
        if (found == selected.parameter_constraints.end() || columns.count(cdf)) {
            message = "参考电阻联动参数缺少CDF约束或重复: " + cdf; return false;
        }
        std::vector<double> values;
        std::istringstream parts(text);
        std::string part;
        while (std::getline(parts, part, ',')) {
            bool parsed = false;
            const double value = parseSuffixValue(part, parsed);
            if (!parsed || !std::isfinite(value) || values.size() >= (automatic ? 4096U : 5U) ||
                (cdf == resistanceCdf && (value <= 0 || std::find(values.begin(),values.end(),value)!=values.end()))) {
                message = "参考电阻试点数值无效: " + cdf; return false;
            }
            values.push_back(value);
        }
        if (values.empty() || (!columns.empty() && values.size() != columns.at(resistanceCdf).size())) {
            message = "参考电阻联动参数非空且列数必须相同"; return false;
        }
        auto& domain = found->second;
        // Python checked the known CDF limits. These are finite experimental
        // tuples; keep old bounds for unchanged instances of the same master.
        domain.minimum = std::min(domain.minimum, *std::min_element(values.begin(),values.end()));
        domain.maximum = std::max(domain.maximum, *std::max_element(values.begin(),values.end()));
        domain.grid = 0;
        domain.discrete_values = values;
        if (cdf != resistanceCdf) {
            std::sort(domain.discrete_values.begin(),domain.discrete_values.end());
            domain.discrete_values.erase(std::unique(domain.discrete_values.begin(),domain.discrete_values.end()),
                                         domain.discrete_values.end());
        }
        columns[cdf] = values;
        std::string nextMaster;
        if (!(input >> nextMaster)) break;
        if (nextMaster != master || !(input >> cdf >> text)) {
            message = "参考电阻联动参数行不完整或master不同"; return false;
        }
    }
    const auto& values = columns.at(resistanceCdf);
    for (std::size_t index = 0; index < values.size(); ++index)
        for (const auto& column : columns)
            selected.native_resistor_trial_parameters[values[index]][column.first] = FormatAutoBiasParameter(column.second[index]);
    selected.limits.min_resistance = std::min(selected.limits.min_resistance, resistance->second.minimum);
    selected.limits.max_resistance = std::max(selected.limits.max_resistance, resistance->second.maximum);
    DeviceCatalog active;
    Diagnostic diagnostic;
    for (const auto& [name, descriptor] : catalog.Descriptors()) {
        if (!active.Add(name == master ? selected : descriptor, diagnostic)) {
            message = diagnostic.message; return false;
        }
    }
    catalog = std::move(active);
    output << "EXPERIMENT_RESISTOR_TRIALS master=" << master << " cdf=" << resistanceCdf
           << (automatic ? " automatic_candidates=" : " values=")
           << (automatic ? std::to_string(values.size()) : resistanceText) << " coupled_parameters=" << columns.size() << '\n';
    return true;
}

// The OA structural exporter needs a terminal order and the instance CDF
// parameter names before it can emit a faithful baseline/round-trip netlist.
// Derive its legacy TSV contract from this session's authoritative scan, not
// from server/config/device_policy.tsv for one demonstration process.
bool writeScannedDevicePolicy(const DeviceCatalog& catalog,
                              const std::filesystem::path& path,
                              std::string& message)
{
    std::ostringstream output;
    output << "oa_library\toa_cell\tkind\tvoltage_domain\tcompatible_masters\t"
              "normalized_to_cdf\tisolated_well\tsource_drain_interchangeable\t"
              "min_width\tmax_width\tmin_length\tmax_length\tmin_resistance\t"
              "max_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\t"
              "terminal_order\n";
    const auto number = [](double value) {
        std::ostringstream stream;
        stream << std::setprecision(17) << value;
        return stream.str();
    };
    const auto join = [](const std::vector<std::string>& values,
                         const char separator) {
        std::string joined;
        for (const auto& value : values) {
            if (!joined.empty()) joined += separator;
            joined += value;
        }
        return joined;
    };
    for (const auto& [master, device] : catalog.Descriptors()) {
        const char* kind = device.kind == DeviceKind::MosN ? "mos_n" :
                           device.kind == DeviceKind::MosP ? "mos_p" :
                           device.kind == DeviceKind::Mos ? "mos" :
                           device.kind == DeviceKind::Resistor ? "resistor" : nullptr;
        if (kind == nullptr) continue;
        if (device.oa_library.empty() || device.oa_cell.empty() ||
            device.terminal_names_by_index.empty()) {
            message = "扫描目录中的器件缺少OA身份或物理端子：" + master;
            return false;
        }
        std::vector<std::string> mappings;
        for (const auto& [semantic, cdf] : device.normalized_to_cdf) {
            if (!semantic.empty() && !cdf.empty()) {
                mappings.push_back(semantic + ':' + cdf);
            }
        }
        for (const auto& [semantic, constraint] : device.parameter_constraints) {
            if (constraint.cdf_name.empty()) continue;
            const std::string mapping = semantic + ':' + constraint.cdf_name;
            if (std::find(mappings.begin(), mappings.end(), mapping) == mappings.end()) {
                mappings.push_back(mapping);
            }
        }
        const std::vector<std::string> fields = {
            device.oa_library, device.oa_cell, kind,
            device.voltage_domain, "self", join(mappings, ','),
            device.isolated_well ? "true" : "false",
            device.source_drain_interchangeable ? "true" : "false",
            number(device.limits.min_width), number(device.limits.max_width),
            number(device.limits.min_length), number(device.limits.max_length),
            number(device.limits.min_resistance), number(device.limits.max_resistance),
            number(device.limits.max_abs_vgs), number(device.limits.max_abs_vds),
            number(device.limits.max_abs_vgb),
            std::to_string(device.limits.max_stack_level),
            join(device.terminal_names_by_index, ',')};
        for (std::size_t index = 0; index < fields.size(); ++index) {
            const auto& field = fields[index];
            if (field.find_first_of("\t\r\n") != std::string::npos) {
                message = "扫描目录字段含非法分隔符：" + master;
                return false;
            }
            if (index != 0) output << '\t';
            output << (field.empty() ? "-" : field);
        }
        output << '\n';
    }
    return writeAtomic(path, output.str(), message);
}

} // namespace st::standalone::detail
