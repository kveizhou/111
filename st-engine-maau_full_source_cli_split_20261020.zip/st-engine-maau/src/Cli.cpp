#include "st/Cli.h"

#include "CliInternal.h"
#include "st/MainFlow.h"

#include <cstdlib>
#include <ostream>

namespace st::standalone {
namespace {

bool parseOptions(const std::vector<std::string>& arguments,
                  std::string& command, detail::Options& options, std::string& message)
{
    if (arguments.empty()) {
        message = "缺少命令";
        return false;
    }
    command = arguments.front();
    if (command == "help" || command == "--help" || command == "-h") return true;
    if ((arguments.size() - 1) % 2 != 0) {
        message = "参数必须使用--name value成对提供";
        return false;
    }
    for (std::size_t index = 1; index < arguments.size(); index += 2) {
        const auto& key = arguments[index];
        if (key.size() < 3 || key[0] != '-' || key[1] != '-' ||
            !options.emplace(key.substr(2), arguments[index + 1]).second) {
            message = "无效或重复参数：" + key;
            return false;
        }
    }
    return true;
}

} // namespace

void PrintCliHelp(std::ostream& output)
{
    output <<
        "st_circuit_tool - 独立MOS结构变换与Virtuoso往返工具\n\n"
        "命令:\n"
        "  inspect  --backend PATH --cds-lib PATH --lib LIB --cell CELL --view schematic\n"
        "           --work-dir DIR --variant-lib LIB --variant-cell CELL --variant-id ID\n"
        "           --skill topology_variant.il\n"
        "           [--validation-scope dc_operating_point|structure_only|experimental_dc]\n"
        "           [--bench-lib LIB --bench-cell CELL --bench-view schematic]\n"
        "           [--vbias-vhigh-net NET --vbias-vlow-net NET]\n"
        "           [--auto-vbias-rails true]\n"
        "           [--core-subckt NAME] [--simulator spectre] [--nominal-corner tt]\n"
        "           [--pvt-corners tt,ss,ff]\n"
        "           [--max-branch-current-error FRACTION --max-vbias-current AMPERE]\n"
        "  inspect  --case MAIN_FLOW.json [--case-side target|source] [上述显式输出选项]\n"
        "  scan-rails --case MAIN_FLOW.json [--case-side target|source]\n"
        "  所有后端命令可选 --provider-inputs 已有EDA输入JSON；否则沿用宿主环境。\n"
        "  list     --session DIR\n"
        "  confirm  --session DIR --operation FILE.conf\n"
        "  undo     --session DIR\n"
        "  fresh    --session DIR\n"
        "  generate --session DIR [--experimental-resistor-trials FILE.tsv] [--experimental-resistor-auto true]\n"
        "           [--native-resistor-search true]（--case入口默认开启）\n"
        "  confirm/undo/list/generate/open可用--case代替默认--session。\n"
        "  experimental_dc每组候选DC最多5次；基线、最终DC、PVT另计。\n"
        "  open     --session DIR\n\n"
        "输入是Virtuoso工程cds.lib和核心L/C/V；baseline网表由后端自动生成。\n"
        "generate自动完成PDK重扫、基线工作点、VBIAS求解、封装、物化、\n"
        "名义DC检查与回读验证，全部通过后输出四状态与ready_for_sizing。\n"
        "电流上限选填且须成对提供；无Spec时求解名义DC可行参数，未验完整性能。\n";
}

int RunCli(const std::vector<std::string>& arguments,
           std::ostream& output,
           std::ostream& error,
           ProcessRunner& runner)
{
    using namespace detail;
    std::string command;
    Options options;
    std::string message;
    if (!parseOptions(arguments, command, options, message)) {
        error << message << '\n';
        PrintCliHelp(error);
        return 2;
    }
    if (command == "help" || command == "--help" || command == "-h") {
        PrintCliHelp(output);
        return 0;
    }
    std::map<std::string, std::string> environment;
    if (options.count("provider-inputs") &&
        !LoadProviderEnvironment(options.at("provider-inputs"), environment, message)) {
        error << message << '\n'; return 2;
    }
    Options caseOptions;
    if (options.count("case")) {
        const auto side = optional(options, "case-side", "target");
        if (!LoadMainFlowOptions(options.at("case"), side, caseOptions, message)) {
            error << message << '\n'; return 2;
        }
        const auto profileEnv = std::getenv("ST_SIMULATION_PROFILE");
        const auto profile = environment.count("ST_SIMULATION_PROFILE")
            ? environment.at("ST_SIMULATION_PROFILE") : profileEnv ? profileEnv : "";
        if (!profile.empty() &&
            !InheritSimulationOptions(profile, caseOptions, caseOptions, message)) {
            error << message << '\n'; return 2;
        }
        if (options.count("pvt-corners") && caseOptions.count("pvt-corners") &&
            options.at("pvt-corners") != caseOptions.at("pvt-corners")) {
            error << "CLI与已有EDA配置的PVT列表不一致\n"; return 2;
        }
        if (command == "inspect" || command == "scan-rails") {
            for (const auto& entry : caseOptions) {
                // Output naming/location can be overridden; source identity cannot.
                if ((entry.first == "cds-lib" || entry.first == "lib" || entry.first == "cell" ||
                     entry.first == "view" || entry.first.rfind("bench-", 0) == 0 ||
                     entry.first == "nominal-corner") &&
                    options.count(entry.first) && options.at(entry.first) != entry.second) {
                    error << "Case与CLI字段不一致：" << entry.first << '\n'; return 2;
                }
                options.emplace(entry);
            }
        } else options.emplace("session", caseOptions.at("work-dir"));
        if (command == "generate") options.emplace("native-resistor-search", "true");
        environment["ST_MAINFLOW_CASE"] = std::filesystem::absolute(options.at("case")).string();
        environment["ST_MAINFLOW_SIDE"] = side;
        environment["ST_MAINFLOW_NOMINAL_CORNER"] = caseOptions.at("nominal-corner");
        environment["ST_MAINFLOW_TEMPERATURE"] = caseOptions.at("mainflow-temperature");
        output << "MAIN_FLOW_SIDE=" << side << '\n'
               << "MAIN_FLOW_DUT=" << caseOptions.at("lib") << '/' << caseOptions.at("cell")
               << '/' << caseOptions.at("view") << '\n'
               << "ORCHESTRATOR=CPP\n";
    }
    if (options.count("provider-inputs")) {
        auto backendPath = options.count("backend") ? options.at("backend")
            : caseOptions.count("backend") ? caseOptions.at("backend") : std::string{};
        if (backendPath.empty() && options.count("session")) {
            SessionManifest manifest;
            if (!loadManifest(options.at("session"), manifest, message)) { error << message << '\n'; return 2; }
            backendPath = manifest.backend.string();
        }
        if (!backendPath.empty()) {
            const auto engine = std::filesystem::path(backendPath).parent_path().parent_path();
            environment["ST_ENGINE_ROOT"] = engine.string();
            environment["ST_OP_PROVIDER_BIN"] = (engine / "server/site/op_provider.py").string();
        }
    }
    EnvironmentProcessRunner backendRunner(runner, std::move(environment));
    if (command == "scan-rails") {
        std::string backend, cds, lib, cell, view, work;
        if (!required(options, "backend", backend, message) ||
            !required(options, "cds-lib", cds, message) ||
            !required(options, "lib", lib, message) ||
            !required(options, "cell", cell, message) ||
            !required(options, "view", view, message) ||
            !required(options, "work-dir", work, message)) {
            error << message << '\n'; return 2;
        }
        BackendPaths paths{cds, {}, {}, std::filesystem::path(work) / "logs", cell};
        paths.experimental_dc = optional(options, "validation-scope") == "experimental_dc";
        paths.structure_only = optional(options, "validation-scope") == "structure_only";
        ProcessVirtuosoBackend host(backend, paths, backendRunner);
        std::string high, low;
        const auto status = host.ScanSupplyNets({lib, cell, view, {}, {}}, high, low);
        if (!status.ok) { error << status.message << "\n日志：" << status.log_path << '\n'; return 3; }
        output << "VBIAS_RAILS_SOURCE=OA_SIG_TYPE\nVBIAS_VHIGH_NET=" << high
               << "\nVBIAS_VLOW_NET=" << low << '\n';
        return 0;
    }
    if (command == "inspect") return inspectCommand(options, output, error, backendRunner);

    std::string session;
    if (!required(options, "session", session, message)) {
        error << message << '\n';
        return 2;
    }
    const std::filesystem::path root(session);
    if (!caseOptions.empty()) {
        SessionManifest manifest;
        if (!loadManifest(root, manifest, message)) { error << message << '\n'; return 2; }
        if (manifest.source_library != caseOptions.at("lib") ||
            manifest.source_cell != caseOptions.at("cell") ||
            manifest.source_view != caseOptions.at("view") ||
            manifest.cds_lib.lexically_normal() != std::filesystem::path(caseOptions.at("cds-lib")).lexically_normal() ||
            manifest.bench_library != caseOptions.at("bench-lib") ||
            manifest.bench_cell != caseOptions.at("bench-cell") ||
            manifest.bench_view != caseOptions.at("bench-view") ||
            manifest.nominal_corner != caseOptions.at("nominal-corner") ||
            (caseOptions.count("pvt-corners") && manifest.pvt_corners != caseOptions.at("pvt-corners"))) {
            error << "Case电路、Bench或Corner与当前会话不一致\n"; return 2;
        }
    }
    if (command == "list") return listCommand(root, output, error);
    if (command == "confirm") return confirmCommand(root, options, output, error);
    if (command == "undo") return undoCommand(root, output, error);
    if (command == "fresh") return freshCommand(root, output, error);
    if (command == "generate") return generateCommand(root, options, output, error, backendRunner);
    if (command == "open") return openCommand(root, output, error, backendRunner);
    error << "未知命令：" << command << '\n';
    PrintCliHelp(error);
    return 2;
}

} // namespace st::standalone
