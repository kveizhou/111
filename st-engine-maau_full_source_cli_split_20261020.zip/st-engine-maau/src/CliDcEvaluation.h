#pragma once

#include "CliInternal.h"
#include "st/DcSolver.h"

namespace st::standalone::detail {

// 用真实后端对求解候选跑直流工作点。每个候选先封装并物化为
// 唯一 OA CellView，然后把该 CellView 绑到临时 Case 中跑 Maau/Spectre。
// Corner 取自每次评估请求的身份（名义候选=名义Corner，PVT复验=各自Corner）。
struct DcEvaluationHostConfig {
    CellViewRef source;
    CellViewRef bench;
    Netlist baseline;
    RootGeometry geometry;
    std::string rootSubckt;
    std::string candidateLibrary;
    std::string candidatePrefix;
    std::filesystem::path skillScript;
    std::filesystem::path candidateDir;
    bool reuseTemplate;
};

class BackendDcEvaluationHost : public DcEvaluationHost {
public:
    BackendDcEvaluationHost(ProcessVirtuosoBackend& backend, DcEvaluationHostConfig config,
                            const DeviceCatalog& catalog, std::ostream& progress);
    void SetPreceding(const Netlist& variant, const ChangeSet& changes,
                      const ReplayResult& replay);
    bool Evaluate(const DcEvaluationRequest& request,
                  OperatingPointSnapshot& snapshot, Diagnostic& diagnostic) override;

private:
    struct EvaluationContext;
    bool PrepareCandidatePlan(EvaluationContext& context);
    bool ExecuteCandidatePlan(EvaluationContext& context);
    bool ReadCandidateBack(EvaluationContext& context);
    bool EvaluateCandidateDc(EvaluationContext& context);
    static std::string PlanStructure(OaMaterializationPlan plan);

    std::string templateCell_;
    OaMaterializationPlan templatePlan_;
    Netlist parentReadback_;
    std::map<std::string, Netlist> childReadbacks_;
    ProcessVirtuosoBackend& backend_;
    CellViewRef source_;
    CellViewRef bench_;
    Netlist baseline_;
    Netlist precedingVariant_;
    ChangeSet precedingChanges_;
    ReplayResult precedingReplay_;
    const DeviceCatalog& catalog_;
    RootGeometry geometry_;
    std::string rootSubckt_;
    std::string candidateLibrary_;
    std::string candidatePrefix_;
    std::filesystem::path skillScript_;
    std::filesystem::path candidateDir_;
    bool reuseTemplate_;
    std::ostream& progress_;
    std::size_t counter_ = 0;
};

} // namespace st::standalone::detail
