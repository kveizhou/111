#include "CliInternal.h"
#include "st/JsonWriter.h"
#include "st/PdkCatalog.h"
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace st::standalone::detail {

namespace {

struct CurrentCircuitRefs {
    Netlist& baseline;
    DeviceCatalog& catalog;
    std::vector<TransformRequest>& requests;
    Netlist& current;
    ReplayResult& replay;
};

bool buildCurrent(const std::filesystem::path& root, const SessionManifest& manifest,
                  CurrentCircuitRefs state, std::string& message)
{
    auto& baseline = state.baseline;
    auto& catalog = state.catalog;
    auto& requests = state.requests;
    auto& current = state.current;
    auto& replay = state.replay;
    ChangeSet validated;
    if (!loadNetlist(root / "before/core_before.scs", baseline, message) ||
        !loadCatalog(root, catalog, message, manifest.validation_scope == "experimental_dc") ||
        !loadChangeRequests(root, manifest, requests, validated, message)) return false;
    ChangeSet replayable;
    if (!confirmReplayable(requests, replayable, message)) return false;
    replay = replayable.Generate(baseline, current, catalog);
    if (!replay.ok) {
        message = replay.diagnostics.empty() ? "Change Set重放失败" :
            replay.diagnostics.front().message;
        return false;
    }
    return true;
}

void printInventory(std::ostream& output, const MosInventoryResult& inventory)
{
    output << "可修改MOS（所选核心cell当前层）: " << inventory.devices.size() << '\n';
    for (const auto& device : inventory.devices) {
        output << "  " << device.instance << "  "
               << (device.kind == DeviceKind::MosN ? "NMOS" : device.kind == DeviceKind::MosP ? "PMOS" : "MOS")
               << "  master=" << device.master
               << "  D=" << device.drain_net << " G=" << device.gate_net
               << " S=" << device.source_net << " B=" << device.bulk_net;
        if (!device.cross_flavor_candidates.empty()) {
            output << "  异型候选=";
            for (std::size_t index = 0; index < device.cross_flavor_candidates.size(); ++index) {
                if (index != 0) output << ',';
                output << device.cross_flavor_candidates[index];
            }
        }
        output << '\n';
    }
}

bool moveToHistory(const std::filesystem::path& root,
                   const std::filesystem::path& source,
                   const std::string& reason, std::string& message)
{
    std::error_code error;
    std::filesystem::create_directories(root / "history", error);
    if (error) { message = error.message(); return false; }
    std::size_t suffix = 1;
    std::filesystem::path target;
    do {
        target = root / "history" /
            (reason + "_" + std::to_string(suffix++) + "_" + source.filename().string());
    } while (std::filesystem::exists(target));
    std::filesystem::rename(source, target, error);
    if (error) { message = "无法移动操作到history：" + error.message(); return false; }
    return true;
}

} // namespace

int inspectCommand(const Options& options, std::ostream& output,
                   std::ostream& error, ProcessRunner& runner)
{
    std::string message;
    SessionManifest manifest;
    std::string workDir;
    if (!required(options, "backend", workDir, message)) { error << message << '\n'; return 2; }
    manifest.backend = workDir;
    if (!required(options, "cds-lib", workDir, message)) { error << message << '\n'; return 2; }
    manifest.cds_lib = workDir;
    if (!required(options, "lib", manifest.source_library, message) ||
        !required(options, "cell", manifest.source_cell, message) ||
        !required(options, "view", manifest.source_view, message) ||
        !required(options, "work-dir", workDir, message) ||
        !required(options, "variant-lib", manifest.variant_library, message) ||
        !required(options, "variant-cell", manifest.variant_cell, message) ||
        !required(options, "variant-id", manifest.variant_id, message)) {
        error << message << '\n'; return 2;
    }
    manifest.bench_library = optional(options, "bench-lib");
    manifest.validation_scope = optional(options, "validation-scope", "dc_operating_point");
    if (manifest.validation_scope != "dc_operating_point" && manifest.validation_scope != "structure_only" &&
        manifest.validation_scope != "experimental_dc") {
        error << "validation-scope只支持dc_operating_point、structure_only或experimental_dc\n";
        return 2;
    }
    manifest.bench_cell = optional(options, "bench-cell");
    manifest.bench_view = optional(options, "bench-view");
    manifest.vbias_vhigh_net = optional(options, "vbias-vhigh-net");
    manifest.vbias_vlow_net = optional(options, "vbias-vlow-net");
    const bool anyBench = !manifest.bench_library.empty() ||
        !manifest.bench_cell.empty() || !manifest.bench_view.empty();
    if (anyBench && (manifest.bench_library.empty() ||
                     manifest.bench_cell.empty() ||
                     manifest.bench_view.empty())) {
        error << "Bench L/C/V 必须成组提供\n";
        return 2;
    }
    if (manifest.vbias_vhigh_net.empty() != manifest.vbias_vlow_net.empty()) {
        error << "VBIAS 高低轨网必须成组提供\n";
        return 2;
    }
    std::string skill;
    if (!required(options, "skill", skill, message)) { error << message << '\n'; return 2; }
    manifest.skill_script = skill;
    manifest.core_subckt = optional(options, "core-subckt", manifest.source_cell);
    manifest.simulator = optional(options, "simulator", "spectre");
    manifest.nominal_corner = optional(options, "nominal-corner", "tt");
    manifest.pvt_corners = optional(options, "pvt-corners", "");
    manifest.max_branch_current_error =
        optional(options, "max-branch-current-error");
    manifest.max_vbias_current = optional(options, "max-vbias-current");
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            error << "Case支路电流偏差与VBIAS电流上限必须成对提供且为正数\n";
            return 2;
        }
    }
    if (manifest.simulator != "spectre") {
        error << "仅支持spectre仿真器声明，收到：" << manifest.simulator << '\n';
        return 2;
    }
    if (manifest.variant_library == manifest.source_library) {
        error << "派生library必须与源library不同，拒绝写入源设计库\n";
        return 2;
    }
    constexpr const char* stagingSuffix = "__STAGING";
    if (manifest.variant_library.size() >= std::char_traits<char>::length(stagingSuffix) &&
        manifest.variant_library.compare(
            manifest.variant_library.size() - std::char_traits<char>::length(stagingSuffix),
            std::char_traits<char>::length(stagingSuffix), stagingSuffix) == 0) {
        error << "派生library名称不能以__STAGING结尾\n";
        return 2;
    }
    manifest.source_storage = manifest.cds_lib.parent_path().string();
    const std::filesystem::path root(workDir);
    if (std::filesystem::exists(root / "session.conf")) {
        error << "工作目录已包含结构变换会话，请使用新的work-dir\n";
        return 2;
    }
    if (!std::filesystem::exists(manifest.cds_lib) ||
        !std::filesystem::exists(manifest.skill_script)) {
        error << "cds.lib或SKILL脚本不存在\n";
        return 2;
    }
    std::error_code directoryError;
    for (const auto* name : {"before", "changes", "expected", "materialization",
                              "after", "reports", "logs", "history", "analysis"}) {
        std::filesystem::create_directories(root / name, directoryError);
        if (directoryError) {
            error << "无法创建会话目录：" << directoryError.message() << '\n';
            return 2;
        }
    }

    BackendPaths paths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.device_policy = root / "analysis/device_policy.tsv";
    paths.structure_only = manifest.validation_scope == "structure_only";
    paths.experimental_dc = manifest.validation_scope == "experimental_dc";
    ProcessVirtuosoBackend backend(manifest.backend, paths, runner);
    const CellViewRef source{manifest.source_library, manifest.source_cell,
                             manifest.source_view, manifest.source_storage, {}};
    if (manifest.vbias_vhigh_net.empty() && optional(options, "auto-vbias-rails") == "true") {
        const auto rails = backend.ScanSupplyNets(source, manifest.vbias_vhigh_net, manifest.vbias_vlow_net);
        if (!rails.ok) {
            error << rails.message << "\n日志：" << rails.log_path << '\n';
            return 3;
        }
        output << "VBIAS_RAILS_SOURCE=OA_SIG_TYPE\n"
               << "VBIAS_VHIGH_NET=" << manifest.vbias_vhigh_net << '\n'
               << "VBIAS_VLOW_NET=" << manifest.vbias_vlow_net << '\n';
    }
    const auto scanDirectory = root / "analysis/pdk_scan/inspect";
    const PdkScanOutputs scanOutputs{scanDirectory / "raw_catalog.tsv",
                                     scanDirectory / "pdk_identity.tsv"};
    const auto scanStatus = backend.ScanPdk(source, scanOutputs);
    if (!scanStatus.ok) {
        std::error_code logError;
        if (!scanStatus.log_path.empty() &&
            std::filesystem::exists(scanStatus.log_path, logError) && !logError) {
            std::string archiveMessage;
            archiveScanLog(scanStatus, scanDirectory, archiveMessage);
        }
        error << "PDK扫描失败：" << scanStatus.message
              << "\n日志：" << scanStatus.log_path << '\n';
        return 3;
    }
    if (!archiveScanLog(scanStatus, scanDirectory, message)) {
        error << message << '\n'; return 3;
    }
    DeviceCatalog catalog;
    std::vector<Diagnostic> scanDiagnostics;
    if (!LoadDeviceCatalogTsv(scanOutputs.raw_catalog_tsv, catalog, scanDiagnostics)) {
        if (message.empty()) message = scanDiagnostics.empty()
            ? "PDK扫描目录读取失败" : scanDiagnostics.front().message;
        error << message << '\n'; return 4;
    }
    if (!writeScannedDevicePolicy(catalog, paths.device_policy, message)) {
        error << message << '\n'; return 4;
    }
    const SnapshotOutputs artifacts{root / "before/core_before.scs",
        root / "before/device_catalog.tsv", root / "before/geometry.tsv"};
    const auto status = backend.Snapshot(source, manifest.core_subckt, artifacts);
    if (!status.ok) {
        error << "Virtuoso snapshot失败：" << status.message
              << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    Netlist baseline;
    if (!loadNetlist(artifacts.netlist, baseline, message)) {
        error << message << '\n'; return 4;
    }
    if (!catalogHash(scanOutputs.raw_catalog_tsv, manifest.catalog_hash, message)) {
        error << message << '\n'; return 4;
    }
    std::ifstream scanInput(scanOutputs.raw_catalog_tsv, std::ios::binary);
    const std::string scanText((std::istreambuf_iterator<char>(scanInput)),
                               std::istreambuf_iterator<char>());
    if (scanInput.bad() ||
        !writeAtomic(artifacts.catalog, scanText, message) ||
        !writeAtomic(root / "before/validation_scope.txt", manifest.validation_scope + "\n", message)) {
        error << (message.empty() ? "PDK扫描目录保存失败" : message) << '\n';
        return 4;
    }
    if (catalog.Descriptors().empty() ||
        catalog.Descriptors().begin()->second.pdk_version.empty()) {
        error << "PDK器件目录缺少pdk_version，无法建立会话身份\n";
        return 4;
    }
    manifest.pdk_version = catalog.Descriptors().begin()->second.pdk_version;
    manifest.dut_hash = CellViewIdentityHash(manifest.source_library,
        manifest.source_cell, manifest.source_view, manifest.source_storage);
    if (anyBench) {
        manifest.bench_hash = CellViewIdentityHash(manifest.bench_library,
            manifest.bench_cell, manifest.bench_view, manifest.source_storage);
    }
    const auto inventory = ListDirectMos(baseline, manifest.core_subckt, catalog, manifest.validation_scope == "experimental_dc");
    if (!inventory.ok) {
        error << inventory.diagnostics.front().message << '\n'; return 4;
    }
    if (!WriteMosInventoryTsv(root / "before/mos_inventory.tsv", inventory, message) ||
        !WriteCrossFlavorCandidatesJson(root / "analysis/cross_flavor_candidates.json", inventory, message) ||
        !writeAtomic(root / "analysis/pdk_catalog.json", WritePdkCatalogJson(catalog), message) ||
        !writeAtomic(root / "session.conf", manifestText(manifest), message)) {
        error << message << '\n'; return 2;
    }
    output << "会话已创建：" << root.string() << '\n';
    printInventory(output, inventory);
    output << "原始网表：" << artifacts.netlist.string() << '\n';
    return 0;
}

int listCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error)
{
    std::string message;
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) { error << message << '\n'; return 2; }
    Netlist baseline;
    Netlist current;
    DeviceCatalog catalog;
    std::vector<TransformRequest> requests;
    ReplayResult replay;
    if (!buildCurrent(root, manifest, {baseline, catalog, requests, current, replay},
                      message)) {
        error << message << '\n'; return 4;
    }
    const auto inventory = ListDirectMos(current, manifest.core_subckt, catalog, manifest.validation_scope == "experimental_dc");
    if (!inventory.ok) { error << inventory.diagnostics.front().message << '\n'; return 4; }
    output << "已确认操作: " << requests.size() << '\n';
    for (const auto& request : requests) {
        output << "  " << request.operation_id << " -> " << request.target.instance;
        if (needsBiasSolve(request)) output << "（待generate自动求解VBIAS）";
        output << '\n';
    }
    printInventory(output, inventory);
    return 0;
}

int confirmCommand(const std::filesystem::path& root, const Options& options,
                   std::ostream& output, std::ostream& error)
{
    std::string message;
    std::string operationPath;
    if (!required(options, "operation", operationPath, message)) {
        error << message << '\n'; return 2;
    }
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) { error << message << '\n'; return 2; }
    Netlist baseline;
    DeviceCatalog catalog;
    if (!loadNetlist(root / "before/core_before.scs", baseline, message) ||
        !loadCatalog(root, catalog, message, manifest.validation_scope == "experimental_dc")) {
        error << message << '\n'; return 4;
    }
    std::vector<TransformRequest> requests;
    ChangeSet validated;
    if (!loadChangeRequests(root, manifest, requests, validated, message)) {
        error << message << '\n'; return 4;
    }
    auto parsed = ParseTransformRequest(operationPath, manifest.core_subckt);
    if (!parsed.ok) {
        error << parsed.diagnostics.front().message << '\n'; return 2;
    }
    if (!prepareScopeRequest(parsed.request, manifest, message)) {
        error << message << '\n'; return 4;
    }
    Diagnostic diagnostic;
    if (!validated.Confirm(parsed.request, diagnostic)) {
        error << diagnostic.message << '\n'; return 4;
    }
    // 重放校验只覆盖可重放操作；未求解的FixedBias Cascode推迟到generate求解后校验。
    ChangeSet replayable;
    if (!confirmReplayable(requests, replayable, message)) {
        error << message << '\n'; return 4;
    }
    if (!needsBiasSolve(parsed.request)) {
        if (!replayable.Confirm(parsed.request, diagnostic)) {
            error << diagnostic.message << '\n'; return 4;
        }
    }
    Netlist current;
    const auto replay = replayable.Generate(baseline, current, catalog);
    if (!replay.ok) {
        error << (replay.diagnostics.empty() ? "变换校验失败" :
                  replay.diagnostics.front().message) << '\n';
        return 4;
    }
    std::ostringstream changeNumber;
    changeNumber << std::setw(4) << std::setfill('0') << validated.Size();
    const auto destination = root / "changes" / (changeNumber.str() + ".conf");
    std::ifstream source(operationPath, std::ios::binary);
    const std::string contents((std::istreambuf_iterator<char>(source)),
                               std::istreambuf_iterator<char>());
    if (!source.good() && !source.eof()) {
        error << "无法读取操作文件\n"; return 2;
    }
    if (!invalidateValidation(root, message) || !writeAtomic(destination, contents, message)) { error << message << '\n'; return 2; }
    output << "已确认操作: " << parsed.request.operation_id
           << "，当前操作数=" << validated.Size() << '\n';
    return 0;
}

int undoCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error)
{
    auto files = changeFiles(root);
    if (files.empty()) { error << "没有可撤销的操作\n"; return 4; }
    std::string message;
    if (!invalidateValidation(root, message) || !moveToHistory(root, files.back(), "undo", message)) {
        error << message << '\n'; return 2;
    }
    output << "已撤销最后一次修改，剩余操作数=" << files.size() - 1 << '\n';
    return 0;
}

int freshCommand(const std::filesystem::path& root, std::ostream& output,
                 std::ostream& error)
{
    const auto files = changeFiles(root);
    std::string message;
    if (!invalidateValidation(root, message)) { error << message << '\n'; return 2; }
    for (const auto& file : files) {
        if (!moveToHistory(root, file, "fresh", message)) {
            error << message << '\n'; return 2;
        }
    }
    output << "已恢复到初始逻辑结构，活动操作数=0\n";
    return 0;
}

int openCommand(const std::filesystem::path& root, std::ostream& output,
                std::ostream& error, ProcessRunner& runner)
{
    std::string message;
    SessionManifest manifest;
    if (!loadManifest(root, manifest, message)) { error << message << '\n'; return 2; }
    const bool experimentalDc = manifest.validation_scope == "experimental_dc";
    std::map<std::string, std::string> validation;
    if (!readPairs(root / "reports/validation.txt", validation, message)) {
        error << "派生电路尚未通过本会话范围的generate与回读校验，拒绝打开\n";
        return 4;
    }
    const auto generationRun = validation["generation_run"];
    if (experimentalDc && !generationRun.empty() &&
        (generationRun.size() != 8 || generationRun.substr(0, 4) != "run_" ||
         generationRun == "run_0000" ||
         !std::all_of(generationRun.begin() + 4, generationRun.end(),
                      [](char c) { return c >= '0' && c <= '9'; }))) {
        error << "实验生成报告的运行编号无效\n";
        return 4;
    }
    // Older successful reports have no run number and keep their legacy name.
    const CellViewRef target{manifest.variant_library + (experimentalDc ? "__STAGING" : ""),
        manifest.variant_cell + (experimentalDc && !generationRun.empty() ? "__GEN_" + generationRun : "") +
            (experimentalDc ? "__STAGING" : ""),
        "schematic", manifest.source_storage, {}};
    if (validation["ok"] != "true" || validation["stage"] != "complete" ||
        validation["validation_scope"] != manifest.validation_scope ||
        validation["target"] != target.library + "/" + target.cell + "/schematic" ||
        (experimentalDc
         ? ((validation["experimental_dc_ready"] != "true" &&
             validation["optimization_candidate_ready"] != "true") ||
            validation["ready_for_sizing"] != "false" || validation["published"] != "false")
         : (manifest.validation_scope == "structure_only"
            ? validation["structural_ready"] != "true"
            : validation["ready_for_sizing"] != "true"))) {
        error << "派生电路尚未通过本会话范围的generate与回读校验，拒绝打开\n";
        return 4;
    }
    BackendPaths paths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.experimental_dc = experimentalDc;
    ProcessVirtuosoBackend backend(manifest.backend, paths, runner);
    const auto status = backend.Open(target);
    if (!status.ok) {
        error << "打开Virtuoso失败：" << status.message << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    output << "已请求打开：" << target.library << '/' << target.cell << '/'
           << target.view << '\n';
    return 0;
}

} // namespace st::standalone::detail
