#include "CliDcEvaluation.h"
#include "st/JsonWriter.h"
#include "st/Packaging.h"
#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>

namespace st::standalone::detail {

struct BackendDcEvaluationHost::EvaluationContext {
    const DcEvaluationRequest& request;
    OperatingPointSnapshot& snapshot;
    Diagnostic& diagnostic;
    std::filesystem::path evaluationDir;
    std::string candidateCell;
    CellViewRef candidateTarget;
    PackageTopologyResult packaged;
    OaPlanBuildResult builtPlan;
    bool reuse = false;
    std::set<std::string> changedCells;
    OaMaterializationPlan executionPlan;
    HostStatus status;

    EvaluationContext(const DcEvaluationRequest& evaluationRequest,
                      OperatingPointSnapshot& operatingPoint, Diagnostic& failure)
        : request(evaluationRequest), snapshot(operatingPoint), diagnostic(failure) {}
};

BackendDcEvaluationHost::BackendDcEvaluationHost(ProcessVirtuosoBackend& backend, DcEvaluationHostConfig config,
                        const DeviceCatalog& catalog, std::ostream& progress)
    : backend_(backend), source_(std::move(config.source)), bench_(std::move(config.bench)),
      baseline_(std::move(config.baseline)), catalog_(catalog),
      geometry_(std::move(config.geometry)), rootSubckt_(std::move(config.rootSubckt)),
      candidateLibrary_(std::move(config.candidateLibrary)),
      candidatePrefix_(std::move(config.candidatePrefix)),
      skillScript_(std::move(config.skillScript)),
      candidateDir_(std::move(config.candidateDir)), reuseTemplate_(config.reuseTemplate),
      progress_(progress) {}

void BackendDcEvaluationHost::SetPreceding(const Netlist& variant, const ChangeSet& changes,
                  const ReplayResult& replay)
{
    precedingVariant_ = variant;
    precedingChanges_ = changes;
    precedingReplay_ = replay;
}

bool BackendDcEvaluationHost::Evaluate(const DcEvaluationRequest& request,
              OperatingPointSnapshot& snapshot, Diagnostic& diagnostic)
{
    EvaluationContext context(request, snapshot, diagnostic);
    if (!PrepareCandidatePlan(context)) return false;
    if (!ExecuteCandidatePlan(context)) return false;
    if (!ReadCandidateBack(context)) return false;
    if (!EvaluateCandidateDc(context)) return false;
    return true;
}

bool BackendDcEvaluationHost::PrepareCandidatePlan(EvaluationContext& context)
{
    auto& request = context.request;
    auto& diagnostic = context.diagnostic;
    auto& evaluationDir = context.evaluationDir;
    auto& candidateCell = context.candidateCell;
    auto& candidateTarget = context.candidateTarget;
    auto& packaged = context.packaged;
    auto& builtPlan = context.builtPlan;
    auto& reuse = context.reuse;
    auto& changedCells = context.changedCells;
    auto& executionPlan = context.executionPlan;
    std::ostringstream stem;
    std::error_code error;
    std::filesystem::create_directories(candidateDir_, error);
    while (!error) {
        stem.str({});
        stem << "candidate_" << std::setw(3) << std::setfill('0') << ++counter_;
        evaluationDir = candidateDir_ / stem.str();
        // Atomically reserve a new directory. Existing candidates and their
        // corresponding OA names remain available across generate retries.
        if (std::filesystem::create_directory(evaluationDir, error)) break;
    }
    if (error) {
        diagnostic = {DiagCode::MissingInput,
                      "无法创建候选目录：" + error.message()};
        return false;
    }
    const auto netlistPath = evaluationDir / "flat_candidate.scs";
    {
        std::ofstream output(netlistPath, std::ios::binary | std::ios::trunc);
        output << emitSpectre(request.candidate);
        if (!output) {
            diagnostic = {DiagCode::MissingInput, "候选网表写入失败"};
            return false;
        }
    }

    const std::string freshCell = candidatePrefix_ + "__" + stem.str();
    candidateCell = templateCell_.empty() ? freshCell : templateCell_;
    reuse = false;
    // A different topology/master/parameter-key set needs a new template.
    // Only values in generated child instances can be updated in place.
    for (;;) {
        candidateTarget = {candidateLibrary_, candidateCell,
            "schematic", source_.storage_path, {}};
        packaged = PackageCumulativeCandidateVariant(
            baseline_, precedingVariant_, precedingChanges_, precedingReplay_,
            request.candidate, rootSubckt_, request.target_instance,
            request.operation_id, candidateCell, candidateLibrary_);
        if (!packaged.ok()) {
            diagnostic = packaged.diagnostics.empty()
                ? Diagnostic{DiagCode::OaPlanInvalid, "DC候选封装失败"}
                : packaged.diagnostics.front();
            return false;
        }
        const PreviewIdentity preview{candidateCell, "dc_candidate",
                                      "standalone-v2-dc-candidate"};
        const auto context = BuildRootOaContext(
            baseline_, packaged.netlist, rootSubckt_, source_, candidateTarget,
            geometry_, preview);
        if (!context.ok) {
            diagnostic = context.diagnostics.empty()
                ? Diagnostic{DiagCode::OaPlanInvalid, "DC候选根层OA上下文构建失败"}
                : context.diagnostics.front();
            return false;
        }
        builtPlan = BuildPackagedOaMaterializationPlan(
            baseline_, packaged, catalog_, context.context, candidateLibrary_);
        if (!builtPlan.ok()) {
            diagnostic = builtPlan.diagnostics.empty()
                ? Diagnostic{DiagCode::OaPlanInvalid, "DC候选OA计划构建失败"}
                : builtPlan.diagnostics.front();
            return false;
        }
        reuse = !templateCell_.empty() &&
            PlanStructure(builtPlan.plan) == PlanStructure(templatePlan_);
        if (reuse || candidateCell == freshCell) break;
        candidateCell = freshCell;
    }
    executionPlan = builtPlan.plan;
    if (reuse) {
        executionPlan.parameters_only = true;
        executionPlan.clone_map.clear();
        executionPlan.generated_cells.clear();
        executionPlan.delete_instances.clear();
        executionPlan.create_instances.clear();
        executionPlan.create_ports.clear();
        executionPlan.direct_wires.clear();
        executionPlan.wires.clear();
        for (std::size_t i = 0; i < builtPlan.plan.generated_cells.size(); ++i) {
            auto cell = builtPlan.plan.generated_cells[i];
            cell.create_instances.clear();
            cell.create_ports.clear();
            cell.direct_wires.clear();
            cell.wires.clear();
            const auto& next = builtPlan.plan.generated_cells[i].create_instances;
            const auto& previous = templatePlan_.generated_cells[i].create_instances;
            for (std::size_t j = 0; j < next.size(); ++j) {
                if (next[j].cdf_parameters != previous[j].cdf_parameters)
                    cell.create_instances.push_back(next[j]);
            }
            if (!cell.create_instances.empty()) {
                changedCells.insert(cell.schematic.cell);
                executionPlan.generated_cells.push_back(std::move(cell));
            }
        }
    }
    if (reuseTemplate_) {
        progress_ << "CANDIDATE_OA_MODE=" << (reuse
            ? (changedCells.empty() ? "REUSE" : "UPDATE") : "BUILD")
            << " point=" << counter_ << " cell=" << candidateCell << '\n'
            << "CANDIDATE_READBACK_CELLS=" << (reuse ? changedCells.size()
                : 1 + builtPlan.plan.generated_cells.size()) << std::endl;
    }
    return true;
}

bool BackendDcEvaluationHost::ExecuteCandidatePlan(EvaluationContext& context)
{
    auto& diagnostic = context.diagnostic;
    auto& evaluationDir = context.evaluationDir;
    auto& packaged = context.packaged;
    auto& builtPlan = context.builtPlan;
    auto& reuse = context.reuse;
    auto& changedCells = context.changedCells;
    auto& executionPlan = context.executionPlan;
    auto& status = context.status;
    std::string artifactMessage;
    if (!writeAtomic(evaluationDir / "expected/core_expected.scs",
                     emitSpectre(packaged.netlist), artifactMessage)) {
        diagnostic = {DiagCode::MissingInput,
                      "DC候选期望网表写入失败：" + artifactMessage};
        return false;
    }
    if (!reuse) {
        status = backend_.CopyCircuits(builtPlan.plan.clone_map);
        if (!status.ok) {
            diagnostic = {DiagCode::OaPlanInvalid,
                "DC候选clone失败：" + status.message +
                (status.log_path.empty() ? std::string{} : "；日志=" + status.log_path)};
            return false;
        }
    }
    const auto planPath = evaluationDir / "plan.json";
    status = backend_.WritePlanFile(planPath.string(), WritePlanJson(executionPlan));
    if (!status.ok) {
        diagnostic = {DiagCode::OaPlanInvalid,
            "DC候选计划写入失败：" + status.message};
        return false;
    }
    if (!reuse || !changedCells.empty()) {
        status = backend_.ExecuteSkill(evaluationDir.string(), skillScript_.string(),
                                       planPath.string());
        if (!status.ok) {
            diagnostic = {DiagCode::OaPlanInvalid,
                "DC候选OA物化失败：" + status.message +
                (status.log_path.empty() ? std::string{} : "；日志=" + status.log_path)};
            return false;
        }
    }
    return true;
}

bool BackendDcEvaluationHost::ReadCandidateBack(EvaluationContext& context)
{
    auto& diagnostic = context.diagnostic;
    auto& evaluationDir = context.evaluationDir;
    auto& candidateCell = context.candidateCell;
    auto& candidateTarget = context.candidateTarget;
    auto& packaged = context.packaged;
    auto& builtPlan = context.builtPlan;
    auto& reuse = context.reuse;
    auto& changedCells = context.changedCells;
    auto& status = context.status;
    std::string artifactMessage;
    const auto rejectRoundtrip = [&](const std::string& message) {
        std::string reportMessage;
        diagnostic = {DiagCode::VariantStructureMismatch, message};
        if (!writeAtomic(evaluationDir / "validation.txt",
                "ok=false\nmessage=" + message + "\n", reportMessage)) {
            diagnostic.message += "；校验报告写入失败：" + reportMessage;
        }
        return false;
    };
    Netlist roundtrip = reuse ? parentReadback_ : Netlist{};
    if (!reuse) {
        status = backend_.RegenerateNetlistTo(
            candidateTarget, rootSubckt_, evaluationDir / "roundtrip/core.scs",
            evaluationDir / "logs/netlist_core.log", roundtrip);
        if (!status.ok) {
            return rejectRoundtrip("DC候选父图回读失败：" + status.message +
                "；日志=" + status.log_path);
        }
    }
    const Netlist parentReadback = roundtrip;
    auto childReadbacks = reuse ? childReadbacks_ : std::map<std::string, Netlist>{};
    VariantVerificationPolicy candidateParameterPolicy;
    for (const auto& generated : builtPlan.plan.generated_cells) {
        const auto scope = "oa_" + generated.schematic.library + "__" + generated.schematic.cell;
        for (const auto& instance : generated.create_instances) {
            candidateParameterPolicy.allowed_extra_parameters_by_instance[{scope, instance.name}] =
                instance.allowed_extra_cdf_parameters;
        }
    }
    std::size_t packageIndex = 0;
    for (const auto& generated : builtPlan.plan.generated_cells) {
        const auto logicalSubckt = "oa_" + generated.schematic.library +
            "__" + generated.schematic.cell;
        const auto packageStem = "package_" + std::to_string(++packageIndex);
        Netlist child;
        if (reuse && changedCells.count(generated.schematic.cell) == 0) {
            child = childReadbacks.at(logicalSubckt);
        } else {
            status = backend_.RegenerateNetlistTo(
                generated.schematic, logicalSubckt,
                evaluationDir / "roundtrip" / (packageStem + ".scs"),
                evaluationDir / "logs" / ("netlist_" + packageStem + ".log"),
                child);
            if (!status.ok) {
                return rejectRoundtrip("DC候选子Cell回读失败[" +
                    generated.package_id + "]：" + status.message +
                    "；日志=" + status.log_path);
            }
        }
        childReadbacks[logicalSubckt] = child;
        const auto* subckt = child.find(logicalSubckt);
        const auto* expectedSubckt = packaged.netlist.find(logicalSubckt);
        if (subckt == nullptr || expectedSubckt == nullptr ||
            roundtrip.find(logicalSubckt) != nullptr) {
            return rejectRoundtrip("DC候选子Cell回读缺失或重名：" +
                                   logicalSubckt);
        }
        Netlist expectedChild;
        expectedChild.subckts.push_back(*expectedSubckt);
        const auto childVerification = VerifyVariantRoundTrip(
            baseline_, expectedChild, child, candidateParameterPolicy);
        if (!childVerification.ok) {
            std::string message = "DC候选子Cell回读校验失败[" +
                generated.package_id + "]";
            for (const auto& mismatch : childVerification.mismatches) {
                message += "\n" + mismatch;
            }
            return rejectRoundtrip(message);
        }
        roundtrip.subckts.push_back(*subckt);
    }
    const auto verification = VerifyVariantRoundTrip(
        baseline_, packaged.netlist, roundtrip, candidateParameterPolicy);
    if (!verification.ok) {
        std::string message = "DC候选OA回读校验失败";
        for (const auto& mismatch : verification.mismatches) {
            message += "\n" + mismatch;
        }
        return rejectRoundtrip(message);
    }
    if (!writeAtomic(evaluationDir / "roundtrip/complete.scs",
                     emitSpectre(roundtrip), artifactMessage) ||
        !writeAtomic(evaluationDir / "validation.txt",
            "ok=true\nexpected_topology_hash=" +
            verification.expected_topology_hash +
            "\nactual_topology_hash=" + verification.actual_topology_hash +
            "\n", artifactMessage)) {
        diagnostic = {DiagCode::MissingInput,
            "DC候选回读证据写入失败：" + artifactMessage};
        return false;
    }

    if (reuseTemplate_) {
        templateCell_ = candidateCell;
        templatePlan_ = builtPlan.plan;
        parentReadback_ = parentReadback;
        childReadbacks_ = std::move(childReadbacks);
    }
    return true;
}

bool BackendDcEvaluationHost::EvaluateCandidateDc(EvaluationContext& context)
{
    auto& request = context.request;
    auto& snapshot = context.snapshot;
    auto& diagnostic = context.diagnostic;
    auto& evaluationDir = context.evaluationDir;
    auto& candidateTarget = context.candidateTarget;
    auto& status = context.status;
    AnalysisIdentity physicalIdentity = request.identity;
    physicalIdentity.dut_hash = CellViewIdentityHash(
        candidateTarget.library, candidateTarget.cell, candidateTarget.view,
        candidateTarget.storage_path);
    const OperatingPointOutputs outputs{
        evaluationDir / "identity.tsv", evaluationDir / "mos.tsv",
        evaluationDir / "resistor.tsv"};
    status = backend_.RunOperatingPoint(
        candidateTarget, bench_, physicalIdentity, outputs);
    if (!status.ok) {
        diagnostic = {DiagCode::BadParam,
                      "候选直流评估失败：" + status.message +
                      (status.log_path.empty() ? std::string{}
                                               : "；日志=" + status.log_path)};
        return false;
    }
    std::vector<Diagnostic> diagnostics;
    if (!LoadOperatingPointTsv(outputs.identity_tsv, outputs.mos_tsv,
                               outputs.resistor_tsv, snapshot, diagnostics)) {
        diagnostic = diagnostics.empty()
            ? Diagnostic{DiagCode::BadParam, "候选工作点解析失败"}
            : diagnostics.front();
        return false;
    }
    if (!IsReusable(snapshot, physicalIdentity)) {
        diagnostic = {DiagCode::BadParam, "候选工作点身份与请求不一致"};
        return false;
    }
    return true;
}

std::string BackendDcEvaluationHost::PlanStructure(OaMaterializationPlan plan)
{
    for (auto& cell : plan.generated_cells)
        for (auto& instance : cell.create_instances)
            for (auto& parameter : instance.cdf_parameters) parameter.second.clear();
    return WritePlanJson(plan);
}

} // namespace st::standalone::detail
