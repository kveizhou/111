#include "st/VirtuosoBackend.h"
#include "st/Standalone.h"
#include "st/JsonWriter.h"
#include "st/PdkCatalog.h"

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <iomanip>
#include <set>
#include <spawn.h>
#include <sstream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

extern char** environ;

namespace st::standalone {
namespace {

void addCellView(std::vector<std::string>& arguments, const std::string& prefix,
                 const CellViewRef& cellView)
{
    arguments.push_back("--" + prefix + "-lib");
    arguments.push_back(cellView.library);
    arguments.push_back("--" + prefix + "-cell");
    arguments.push_back(cellView.cell);
    arguments.push_back("--" + prefix + "-view");
    arguments.push_back(cellView.view);
    if (!cellView.storage_path.empty()) {
        arguments.push_back("--" + prefix + "-storage");
        arguments.push_back(cellView.storage_path);
    }
}

HostStatus missingArtifact(const std::filesystem::path& path,
                           const std::filesystem::path& logPath)
{
    return {false, "后端未生成预期文件或文件为空：" + path.string(),
            logPath.string(), path.string()};
}

std::string safeArtifactName(const std::string& value)
{
    std::string result;
    result.reserve(value.size());
    for (const unsigned char character : value) {
        result.push_back(std::isalnum(character) || character == '_'
            ? static_cast<char>(character) : '_');
    }
    return result.empty() ? "subckt" : result;
}

bool canonicalOutputPath(const std::filesystem::path& requested,
                         std::filesystem::path& resolved,
                         std::string& message)
{
    std::error_code error;
    auto absolute = std::filesystem::absolute(requested, error);
    if (error) {
        message = error.message();
        return false;
    }
    resolved = std::filesystem::weakly_canonical(absolute, error);
    if (error) {
        message = error.message();
        return false;
    }
    resolved = resolved.lexically_normal();
    return true;
}

bool outputPathsConflict(const std::vector<std::filesystem::path>& paths)
{
    for (std::size_t left = 0; left < paths.size(); ++left) {
        for (std::size_t right = left + 1; right < paths.size(); ++right) {
            if (paths[left] == paths[right]) return true;
            std::error_code error;
            const bool leftExists = std::filesystem::exists(paths[left], error);
            if (error || !leftExists) continue;
            error.clear();
            const bool rightExists = std::filesystem::exists(paths[right], error);
            if (error || !rightExists) continue;
            error.clear();
            if (std::filesystem::equivalent(paths[left], paths[right], error) && !error) {
                return true;
            }
        }
    }
    return false;
}

bool pathObjectExists(const std::filesystem::path& path, std::error_code& error)
{
    const auto status = std::filesystem::symlink_status(path, error);
    if (error == std::errc::no_such_file_or_directory) {
        error.clear();
        return false;
    }
    return !error && status.type() != std::filesystem::file_type::not_found;
}

bool protectedArtifactType(const std::filesystem::path& path,
                           std::string& message)
{
    std::error_code error;
    const auto status = std::filesystem::symlink_status(path, error);
    if (error == std::errc::no_such_file_or_directory) {
        error.clear();
        return true;
    }
    if (error) {
        message = "无法检查旧工作点输出" + path.string() + "：" +
            error.message();
        return false;
    }
    if (status.type() == std::filesystem::file_type::not_found ||
        status.type() == std::filesystem::file_type::regular ||
        status.type() == std::filesystem::file_type::symlink) {
        return true;
    }
    message = "工作点输出路径只允许普通文件或需保护的符号链接：" +
        path.string();
    return false;
}

bool generatedRegularFile(const std::filesystem::path& path,
                          std::error_code& error)
{
    const auto status = std::filesystem::symlink_status(path, error);
    return !error && status.type() == std::filesystem::file_type::regular;
}

bool completeCellView(const CellViewRef& cellView)
{
    return !cellView.library.empty() && !cellView.cell.empty() &&
        !cellView.view.empty();
}

struct MovedArtifact {
    std::filesystem::path path;
    std::filesystem::path backup;
    bool moved = false;
};

class ArtifactTransaction {
public:
    explicit ArtifactTransaction(std::vector<std::filesystem::path> paths)
    {
        artifacts_.reserve(paths.size());
        for (auto& path : paths) artifacts_.push_back({std::move(path), {}, false});
    }

    bool Begin(std::string& message)
    {
        for (const auto& artifact : artifacts_) {
            if (!protectedArtifactType(artifact.path, message)) return false;
        }
        for (std::size_t index = 0; index < artifacts_.size(); ++index) {
            auto& artifact = artifacts_[index];
            std::error_code error;
            const bool exists = pathObjectExists(artifact.path, error);
            if (error) {
                message = "无法检查旧工作点输出：" + error.message();
                Rollback();
                return false;
            }
            if (!exists) continue;
            artifact.backup = uniqueBackupPath(artifact.path, index);
            std::filesystem::rename(artifact.path, artifact.backup, error);
            if (error) {
                message = "无法保护旧工作点输出：" + error.message();
                Rollback();
                return false;
            }
            artifact.moved = true;
        }
        active_ = true;
        return true;
    }

    void Rollback()
    {
        for (auto iterator = artifacts_.rbegin(); iterator != artifacts_.rend(); ++iterator) {
            std::error_code error;
            std::filesystem::remove(iterator->path, error);
            if (error) {
                // A provider may have produced a non-empty directory or other
                // unexpected object.  Preserve it under a quarantine name so
                // the caller's protected artifact can still be restored.
                error.clear();
                std::filesystem::rename(
                    iterator->path, uniqueRejectedPath(iterator->path), error);
            }
            if (!iterator->moved) continue;
            error.clear();
            std::filesystem::rename(iterator->backup, iterator->path, error);
        }
        active_ = false;
    }

    bool Commit(std::string& message)
    {
        // Publishing is irreversible at this point.  Disable destructor
        // rollback before best-effort backup cleanup so a cleanup failure can
        // never delete the newly committed artifacts.
        active_ = false;
        std::vector<std::filesystem::path> retainedBackups;
        for (auto& artifact : artifacts_) {
            if (!artifact.moved) continue;
            std::error_code error;
            std::filesystem::remove(artifact.backup, error);
            if (error) {
                retainedBackups.push_back(artifact.backup);
                continue;
            }
            artifact.moved = false;
        }
        if (retainedBackups.empty()) return true;
        std::ostringstream details;
        details << "新工作点输出已提交，但无法删除备份；请人工检查保留路径：";
        for (std::size_t index = 0; index < retainedBackups.size(); ++index) {
            if (index != 0) details << ", ";
            details << retainedBackups[index].string();
        }
        message = details.str();
        return false;
    }

    ~ArtifactTransaction()
    {
        if (active_) Rollback();
    }

private:
    static std::filesystem::path uniqueBackupPath(
        const std::filesystem::path& path, std::size_t index)
    {
        const auto stem = path.string() + ".st-op-backup-" +
            std::to_string(static_cast<long long>(getpid())) + "-" +
            std::to_string(index);
        std::filesystem::path candidate(stem);
        std::size_t attempt = 0;
        std::error_code error;
        while (pathObjectExists(candidate, error) && !error) {
            candidate = stem + "-" + std::to_string(++attempt);
        }
        return candidate;
    }

    static std::filesystem::path uniqueRejectedPath(
        const std::filesystem::path& path)
    {
        const auto stem = path.string() + ".st-op-rejected-" +
            std::to_string(static_cast<long long>(getpid()));
        std::filesystem::path candidate(stem);
        std::size_t attempt = 0;
        std::error_code error;
        while (pathObjectExists(candidate, error) && !error) {
            candidate = stem + "-" + std::to_string(++attempt);
        }
        return candidate;
    }

    std::vector<MovedArtifact> artifacts_;
    bool active_ = false;
};

std::vector<std::string> splitTsv(const std::string& line)
{
    std::vector<std::string> fields;
    std::size_t begin = 0;
    while (true) {
        const auto end = line.find('\t', begin);
        fields.push_back(line.substr(begin, end - begin));
        if (end == std::string::npos) break;
        begin = end + 1;
    }
    return fields;
}

std::set<std::string> splitCommaSet(const std::string& value)
{
    std::set<std::string> result;
    std::size_t begin = 0;
    while (begin <= value.size()) {
        const auto end = value.find(',', begin);
        const auto item = value.substr(begin, end - begin);
        if (!item.empty()) result.insert(item);
        if (end == std::string::npos) break;
        begin = end + 1;
    }
    return result;
}

struct ScanIdentityEvidence {
    std::string process_identity;
    std::string pdk_name;
    std::string pdk_version;
    std::set<std::string> candidate_libraries;
};

bool loadCompleteScanIdentity(const std::filesystem::path& path,
                              ScanIdentityEvidence& evidence,
                              std::string& message)
{
    std::ifstream input(path);
    std::string headerLine;
    std::string rowLine;
    if (!std::getline(input, headerLine) || !std::getline(input, rowLine)) {
        message = "PDK identity缺少header或数据记录";
        return false;
    }
    const auto header = splitTsv(headerLine);
    const auto row = splitTsv(rowLine);
    const auto field = [&](const std::string& name) -> std::string {
        const auto found = std::find(header.begin(), header.end(), name);
        if (found == header.end()) return {};
        const auto index = static_cast<std::size_t>(found - header.begin());
        return index < row.size() ? row[index] : std::string{};
    };
    evidence.process_identity = field("process_identity");
    evidence.pdk_name = field("pdk_name");
    evidence.pdk_version = field("pdk_version");
    if (evidence.process_identity.empty() ||
        field("context_complete") != "true") {
        message = "PDK identity的source tech context不完整";
        return false;
    }
    if (evidence.pdk_name.empty() || evidence.pdk_version.empty()) {
        message = "PDK identity缺少pdk_name或pdk_version";
        return false;
    }
    if (field("scan_complete") != "true") {
        message = "PDK identity未声明scan_complete=true";
        const auto diagnostic = field("diagnostic");
        if (!diagnostic.empty()) message += "：" + diagnostic;
        return false;
    }
    evidence.candidate_libraries =
        splitCommaSet(field("candidate_libraries"));
    if (evidence.candidate_libraries.empty()) {
        message = "PDK identity没有已证明的candidate_libraries";
        return false;
    }
    return true;
}

bool provenSource(const std::string& value)
{
    if (value.empty()) return false;
    std::string lower;
    lower.reserve(value.size());
    std::transform(value.begin(), value.end(), std::back_inserter(lower),
                   [](unsigned char character) {
                       return static_cast<char>(std::tolower(character));
                   });
    return lower != "missing" && lower != "unknown" &&
        lower.find("inference") == std::string::npos &&
        lower.find("guess") == std::string::npos;
}

bool validateCatalogEvidence(const std::filesystem::path& path,
                             const ScanIdentityEvidence& identity,
                             std::string& message, bool structureOnly, bool experimentalDc)
{
    if (structureOnly && experimentalDc) {
        message = "structure_only与experimental_dc不得混用";
        return false;
    }
    std::ifstream input(path);
    std::string headerLine;
    if (!std::getline(input, headerLine)) {
        message = "PDK catalog缺少header";
        return false;
    }
    const auto header = splitTsv(headerLine);
    const auto indexOf = [&](const std::string& name) {
        const auto found = std::find(header.begin(), header.end(), name);
        return found == header.end()
            ? header.size()
            : static_cast<std::size_t>(found - header.begin());
    };
    const std::vector<std::string> required = {
        "master", "kind", "oa_library", "pdk_name", "pdk_version",
        "parameter_constraints", "reliability_complete", "bulk_rule_complete",
        "process_identity", "kind_source", "terminal_source", "cdf_source",
        "reliability_source", "bulk_source", "domain_source", "corner_source",
        "device_proof_source"};
    for (const auto& name : required) {
        if (indexOf(name) == header.size()) {
            message = "PDK catalog缺少证据列：" + name;
            return false;
        }
    }
    bool hasDevice = false;
    std::string line;
    std::size_t rowNumber = 1;
    while (std::getline(input, line)) {
        ++rowNumber;
        if (line.empty()) continue;
        const auto row = splitTsv(line);
        const auto field = [&](const std::string& name) -> std::string {
            const auto index = indexOf(name);
            return index < row.size() ? row[index] : std::string{};
        };
        const std::string master = field("master");
        if (master.empty()) {
            message = "PDK catalog第" + std::to_string(rowNumber) +
                "行master为空";
            return false;
        }
        if (!identity.candidate_libraries.count(field("oa_library"))) {
            message = "PDK catalog包含未证明的器件library：" +
                field("oa_library");
            return false;
        }
        if (field("process_identity") != identity.process_identity ||
            field("pdk_name") != identity.pdk_name ||
            field("pdk_version") != identity.pdk_version) {
            message = "PDK catalog器件不属于当前DUT工艺：" + master;
            return false;
        }
        const auto kind = field("kind");
        std::vector<std::string> requiredSources{
            "kind_source", "terminal_source", "device_proof_source"};
        if (kind == "resistor") {
            requiredSources.push_back("cdf_source");
            if (!structureOnly && !experimentalDc) requiredSources.insert(requiredSources.end(), {"domain_source", "corner_source"});
        } else if (kind == "mos_n" || kind == "mos_p" || (structureOnly && kind == "mos")) {
            // Inventory may include devices unsuitable for automatic biasing.
            // Do not manufacture MOS rules for resistors or three-pin MOS.
            if (field("reliability_complete") == "true")
                requiredSources.push_back("reliability_source");
            if (field("bulk_rule_complete") == "true")
                requiredSources.push_back("bulk_source");
        } else {
            message = "PDK catalog包含不支持的器件类型：" + master;
            return false;
        }
        for (const auto& source : requiredSources) {
            if (!provenSource(field(source))) {
                message = "PDK catalog器件的" + std::string(source) +
                    "没有可验证来源：" + master;
                return false;
            }
        }
        if (kind == "resistor" && !structureOnly) {
            if (field("parameter_constraints").find("resistance:") ==
                std::string::npos) {
                message = "PDK电阻缺少resistance参数约束：" + master;
                return false;
            }
        }
        hasDevice = true;
    }
    if (!hasDevice) {
        message = "PDK catalog必须包含已证明的器件";
        return false;
    }
    DeviceCatalog catalog;
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(path, catalog, diagnostics)) {
        message = diagnostics.empty() ? "PDK catalog不可解析" : diagnostics.front().message;
        return false;
    }
    for (const auto& entry : catalog.Descriptors()) {
        const auto& device = entry.second;
        if (device.native_parameter_trials && !experimentalDc) {
            message = "原生参数试点目录只允许experimental_dc：" + device.master;
            return false;
        }
        const auto count = [&](TerminalRole role) {
            return std::count(device.terminal_roles_by_index.begin(),
                              device.terminal_roles_by_index.end(), role);
        };
        const auto& names = device.terminal_names_by_index;
        if (std::set<std::string>(names.begin(), names.end()).size() != names.size() ||
            std::find(names.begin(), names.end(), "") != names.end() ||
            (isMosKind(device.kind) && (count(TerminalRole::Drain) != 1 ||
                count(TerminalRole::Gate) != 1 || count(TerminalRole::Source) != 1 ||
                (names.size() == 3 ? count(TerminalRole::Bulk) != 0 :
                                    count(TerminalRole::Bulk) != 1))) ||
            (device.kind == DeviceKind::Resistor &&
                (count(TerminalRole::Positive) != 1 || count(TerminalRole::Negative) != 1))) {
            message = "PDK catalog端子角色证据不完整：" + device.master;
            return false;
        }
        if (device.kind == DeviceKind::Resistor) {
            const auto constraint = device.parameter_constraints.find("resistance");
            const auto mapping = device.normalized_to_cdf.find("resistance");
            if (mapping == device.normalized_to_cdf.end() || mapping->second.empty() ||
                (constraint == device.parameter_constraints.end() ? !structureOnly :
                 (mapping->second != constraint->second.cdf_name || !ValidateParameterConstraint(constraint->second)))) {
                message = "PDK电阻缺少有效resistance映射与约束：" + device.master;
                return false;
            }
        } else if (device.reliability_complete &&
                   (!std::isfinite(device.limits.max_abs_vgs) ||
                    !std::isfinite(device.limits.max_abs_vds) ||
                    !std::isfinite(device.limits.max_abs_vgb) ||
                    device.limits.max_abs_vgs <= 0 ||
                    device.limits.max_abs_vds <= 0 ||
                    device.limits.max_abs_vgb <= 0)) {
            message = "PDK MOS声明完整可靠性但缺少有效电压上限：" + device.master;
            return false;
        }
    }
    return true;
}

} // namespace

ProcessResult PosixProcessRunner::Run(const std::vector<std::string>& arguments,
                                     const std::filesystem::path& logPath)
{
    if (arguments.empty() || arguments.front().empty()) return {-1, "后端程序路径为空"};
    std::error_code error;
    std::filesystem::create_directories(logPath.parent_path(), error);
    if (error) return {-1, "无法创建日志目录：" + error.message()};

    // Construct arguments in the caller, not in a forked multi-threaded host.
    std::vector<char*> argv;
    for (const auto& argument : arguments) argv.push_back(const_cast<char*>(argument.c_str()));
    argv.push_back(nullptr);
    posix_spawn_file_actions_t actions;
    int result = posix_spawn_file_actions_init(&actions);
    if (result) return {-1, "spawn初始化失败：" + std::string(std::strerror(result))};
    result = posix_spawn_file_actions_addopen(&actions, STDOUT_FILENO, logPath.c_str(),
                                             O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (!result) result = posix_spawn_file_actions_adddup2(&actions, STDOUT_FILENO, STDERR_FILENO);
    pid_t child = 0;
    if (!result) result = posix_spawn(&child, argv.front(), &actions, nullptr, argv.data(), environ);
    posix_spawn_file_actions_destroy(&actions);
    if (result) return {result == ENOENT ? 127 : 126,
                        "后端启动失败：" + std::string(std::strerror(result))};
    int status = 0;
    pid_t waited;
    do { waited = waitpid(child, &status, 0); } while (waited < 0 && errno == EINTR);
    if (waited < 0) {
        return {-1, "waitpid失败：" + std::string(std::strerror(errno))};
    }
    if (WIFEXITED(status)) {
        const int exitCode = WEXITSTATUS(status);
        return {exitCode, exitCode == 0 ? std::string{} :
            "后端退出码=" + std::to_string(exitCode)};
    }
    if (WIFSIGNALED(status)) {
        return {128 + WTERMSIG(status),
                "后端被信号终止：" + std::to_string(WTERMSIG(status))};
    }
    return {-1, "后端进程状态未知"};
}

ProcessVirtuosoBackend::ProcessVirtuosoBackend(std::filesystem::path executable,
                                               BackendPaths paths,
                                               ProcessRunner& runner)
    : executable_(std::move(executable)), paths_(std::move(paths)), runner_(runner)
{
}

HostStatus ProcessVirtuosoBackend::ScanSupplyNets(const CellViewRef& source,
                                                 std::string& high, std::string& low)
{
    const auto table = paths_.log_dir / "supply_nets.tsv";
    const auto log = paths_.log_dir / "scan_supplies.log";
    auto status = Run("scan-supplies", {
        "--cds-lib", paths_.cds_lib.string(), "--lib", source.library,
        "--cell", source.cell, "--view", source.view, "--output", table.string()}, log);
    if (!status.ok) return status;
    std::ifstream stream(table);
    std::string line;
    if (!std::getline(stream, line) || line != "net\tsig_type")
        return missingArtifact(table, log);
    std::set<std::string> highs, lows;
    while (std::getline(stream, line)) {
        const auto tab = line.find('\t');
        if (tab == std::string::npos || tab == 0 || line.find('\t', tab + 1) != std::string::npos)
            return {false, "DUT电源网扫描表格式错误", log.string(), table.string()};
        const auto name = line.substr(0, tab);
        const auto type = line.substr(tab + 1);
        if (type == "supply") highs.insert(name);
        else if (type == "ground") lows.insert(name);
        else return {false, "DUT电源网扫描返回未知sigType", log.string(), table.string()};
    }
    if (stream.bad() || highs.size() != 1 || lows.size() != 1 || *highs.begin() == *lows.begin()) {
        std::string details = "DUT未标明唯一电源/地，不能自动选择VBIAS轨；supply=";
        for (const auto& name : highs) details += name + ",";
        details += " ground=";
        for (const auto& name : lows) details += name + ",";
        return {false, details, log.string(), table.string()};
    }
    high = *highs.begin();
    low = *lows.begin();
    return status;
}

HostStatus ProcessVirtuosoBackend::PrepareResistorTrials(const std::filesystem::path& work,
                                                        const std::filesystem::path& output)
{
    return Run("resistor-trials", {"--work-dir", std::filesystem::absolute(work).string(),
        "--output-dir", std::filesystem::absolute(output).string()}, paths_.log_dir / "resistor_trials.log");
}

HostStatus ProcessVirtuosoBackend::Snapshot(const CellViewRef& source,
                                            const std::string& coreSubckt,
                                            const SnapshotOutputs& outputs)
{
    std::error_code error;
    std::filesystem::create_directories(outputs.netlist.parent_path(), error);
    if (error) return {false, "无法创建snapshot目录：" + error.message(), {}, {}};
    std::filesystem::remove(outputs.netlist, error);
    error.clear();
    std::filesystem::remove(outputs.catalog, error);
    error.clear();
    std::filesystem::remove(outputs.geometry, error);
    std::vector<std::string> arguments = {
        "--cds-lib", paths_.cds_lib.string(),
        "--lib", source.library,
        "--cell", source.cell,
        "--view", source.view,
        "--core-subckt", coreSubckt,
        "--netlist-output", outputs.netlist.string(),
        "--catalog-output", outputs.catalog.string(),
        "--geometry-output", outputs.geometry.string(),
    };
    if (!paths_.device_policy.empty()) {
        arguments.insert(arguments.end(),
                         {"--device-policy", paths_.device_policy.string()});
    }
    auto status = Run("snapshot", std::move(arguments), paths_.log_dir / "snapshot.log");
    if (!status.ok) return status;
    const std::filesystem::path artifacts[] = {
        outputs.netlist, outputs.catalog, outputs.geometry,
    };
    for (const auto& artifact : artifacts) {
        error.clear();
        if (!std::filesystem::exists(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            return missingArtifact(artifact, paths_.log_dir / "snapshot.log");
        }
    }
    return {true, {}, (paths_.log_dir / "snapshot.log").string(),
            outputs.netlist.string()};
}

HostStatus ProcessVirtuosoBackend::ScanPdk(const CellViewRef& source,
                                           const PdkScanOutputs& outputs)
{
    const auto logPath = paths_.log_dir / "scan_pdk.log";
    std::error_code error;
    if (outputs.raw_catalog_tsv.empty() || outputs.pdk_identity_tsv.empty()) {
        return {false, "PDK扫描输出路径不能为空", logPath.string(), {}};
    }
    std::filesystem::path catalogPath;
    std::string pathMessage;
    if (!canonicalOutputPath(outputs.raw_catalog_tsv, catalogPath, pathMessage)) {
        return {false, "无法规范化PDK目录路径：" + pathMessage,
                logPath.string(), {}};
    }
    std::filesystem::path identityPath;
    if (!canonicalOutputPath(outputs.pdk_identity_tsv, identityPath, pathMessage)) {
        return {false, "无法规范化PDK身份路径：" + pathMessage,
                logPath.string(), {}};
    }
    const auto artifactRoot = catalogPath.parent_path();
    std::filesystem::path catalogTempPath;
    if (!canonicalOutputPath(catalogPath.string() + ".tmp",
                             catalogTempPath, pathMessage)) {
        return {false, "无法规范化PDK catalog临时路径：" + pathMessage,
                logPath.string(), artifactRoot.string()};
    }
    std::filesystem::path identityTempPath;
    if (!canonicalOutputPath(identityPath.string() + ".tmp",
                             identityTempPath, pathMessage)) {
        return {false, "无法规范化PDK identity临时路径：" + pathMessage,
                logPath.string(), artifactRoot.string()};
    }
    if (outputPathsConflict({catalogPath, identityPath,
                             catalogTempPath, identityTempPath})) {
        return {false, "PDK catalog、identity及其临时输出路径必须互不冲突",
                logPath.string(), artifactRoot.string()};
    }

    const std::filesystem::path parents[] = {
        catalogPath.parent_path(), identityPath.parent_path(),
    };
    for (const auto& parent : parents) {
        if (parent.empty()) continue;
        error.clear();
        std::filesystem::create_directories(parent, error);
        if (error) {
            return {false, "无法创建PDK扫描输出目录：" + error.message(),
                    logPath.string(), artifactRoot.string()};
        }
    }
    error.clear();
    std::filesystem::remove(catalogPath, error);
    error.clear();
    std::filesystem::remove(identityPath, error);

    std::vector<std::string> arguments = {
        "--cds-lib", paths_.cds_lib.string(),
        "--lib", source.library,
        "--cell", source.cell,
        "--view", source.view,
        "--catalog-output", catalogPath.string(),
        "--identity-output", identityPath.string(),
    };
    auto status = Run("scan-pdk", std::move(arguments), logPath);
    status.artifact_path = artifactRoot.string();
    if (!status.ok) return status;

    const std::filesystem::path artifacts[] = {
        catalogPath, identityPath,
    };
    for (const auto& artifact : artifacts) {
        error.clear();
        if (!std::filesystem::exists(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            return {false, "后端未生成预期文件或文件为空：" + artifact.string(),
                    logPath.string(), artifactRoot.string()};
        }
    }

    DeviceCatalog catalog;
    std::vector<Diagnostic> diagnostics;
    if (!LoadDeviceCatalogTsv(catalogPath, catalog, diagnostics) ||
        catalog.Descriptors().empty()) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, "PDK catalog没有可解析的器件数据记录",
                logPath.string(), artifactRoot.string()};
    }
    ScanIdentityEvidence identityEvidence;
    std::string identityMessage;
    if (!loadCompleteScanIdentity(identityPath, identityEvidence, identityMessage)) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, identityMessage, logPath.string(), artifactRoot.string()};
    }
    if (!validateCatalogEvidence(catalogPath, identityEvidence, identityMessage, paths_.structure_only, paths_.experimental_dc)) {
        std::filesystem::remove(catalogPath, error);
        error.clear();
        std::filesystem::remove(identityPath, error);
        return {false, identityMessage, logPath.string(), artifactRoot.string()};
    }
    return {true, {}, logPath.string(), artifactRoot.string()};
}

void ProcessVirtuosoBackend::UseOperatingPointCatalog(const std::filesystem::path& catalog)
{
    paths_.operating_point_catalog = catalog;
}

HostStatus ProcessVirtuosoBackend::RunOperatingPoint(
    const CellViewRef& dut,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const OperatingPointOutputs& outputs)
{
    const auto logPath = paths_.log_dir /
        ("run_op_" + safeArtifactName(identity.corner) + "_" +
         safeArtifactName(identity.topology_hash) + "_" +
         safeArtifactName(identity.parameter_hash) + ".log");
    if (!completeCellView(dut)) {
        return {false, "DUT L/C/V不完整", logPath.string(), {}};
    }
    if (!completeCellView(bench)) {
        return {false, "Bench L/C/V不完整", logPath.string(), {}};
    }
    if (identity.dut_hash.empty() || identity.bench_hash.empty() ||
        identity.pdk_version.empty() || identity.corner.empty() ||
        identity.topology_hash.empty() || identity.parameter_hash.empty() ||
        identity.solver_version.empty()) {
        return {false, "工作点七项身份不完整", logPath.string(), {}};
    }
    if (outputs.identity_tsv.empty() || outputs.mos_tsv.empty()) {
        return {false, "工作点输出路径不能为空", logPath.string(), {}};
    }

    std::filesystem::path identityPath;
    std::filesystem::path mosPath;
    std::filesystem::path resistorPath;
    std::filesystem::path identityTempPath;
    std::filesystem::path mosTempPath;
    std::filesystem::path resistorTempPath;
    std::string pathMessage;
    if (!canonicalOutputPath(outputs.identity_tsv, identityPath, pathMessage) ||
        !canonicalOutputPath(outputs.mos_tsv, mosPath, pathMessage) ||
        !canonicalOutputPath(identityPath.string() + ".tmp",
                             identityTempPath, pathMessage) ||
        !canonicalOutputPath(mosPath.string() + ".tmp", mosTempPath, pathMessage)) {
        return {false, "无法规范化工作点输出路径：" + pathMessage,
                logPath.string(), {}};
    }
    if (!outputs.resistor_tsv.empty() &&
        (!canonicalOutputPath(outputs.resistor_tsv, resistorPath, pathMessage) ||
         !canonicalOutputPath(resistorPath.string() + ".tmp",
                              resistorTempPath, pathMessage))) {
        return {false, "无法规范化电阻工作点输出路径：" + pathMessage,
                logPath.string(), {}};
    }
    const auto artifactRoot = identityPath.parent_path();
    std::vector<std::filesystem::path> artifacts = {
        identityPath, mosPath, identityTempPath, mosTempPath};
    if (!resistorPath.empty()) {
        artifacts.push_back(resistorPath);
        artifacts.push_back(resistorTempPath);
    }
    if (outputPathsConflict(artifacts)) {
        return {false, "工作点identity、MOS及其临时输出路径必须互不冲突",
                logPath.string(), artifactRoot.string()};
    }

    std::error_code error;
    for (const auto& parent : {identityPath.parent_path(), mosPath.parent_path(),
                               resistorPath.parent_path()}) {
        if (parent.empty()) continue;
        error.clear();
        std::filesystem::create_directories(parent, error);
        if (error) {
            return {false, "无法创建工作点输出目录：" + error.message(),
                    logPath.string(), artifactRoot.string()};
        }
    }

    ArtifactTransaction transaction(artifacts);
    std::string transactionMessage;
    if (!transaction.Begin(transactionMessage)) {
        return {false, transactionMessage, logPath.string(), artifactRoot.string()};
    }

    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string()};
    addCellView(arguments, "dut", dut);
    addCellView(arguments, "bench", bench);
    arguments.insert(arguments.end(), {
        "--corner", identity.corner,
        "--dut-hash", identity.dut_hash,
        "--bench-hash", identity.bench_hash,
        "--pdk-version", identity.pdk_version,
        "--topology-hash", identity.topology_hash,
        "--parameter-hash", identity.parameter_hash,
        "--solver-version", identity.solver_version,
        "--identity-output", identityPath.string(),
        "--mos-output", mosPath.string(),
    });
    if (!resistorPath.empty()) {
        arguments.insert(arguments.end(),
                         {"--resistor-output", resistorPath.string()});
    }
    if (!paths_.operating_point_catalog.empty()) {
        arguments.insert(arguments.end(),
            {"--device-catalog", paths_.operating_point_catalog.string()});
    }
    auto status = Run("run-op", std::move(arguments), logPath);
    status.artifact_path = artifactRoot.string();
    if (!status.ok) {
        transaction.Rollback();
        return status;
    }

    std::vector<std::filesystem::path> finalArtifacts = {identityPath, mosPath};
    if (!resistorPath.empty()) finalArtifacts.push_back(resistorPath);
    for (const auto& artifact : finalArtifacts) {
        error.clear();
        if (!generatedRegularFile(artifact, error) || error ||
            std::filesystem::file_size(artifact, error) == 0 || error) {
            transaction.Rollback();
            return {false, "后端未生成本轮预期的非空普通工作点文件：" +
                    artifact.string(), logPath.string(), artifactRoot.string()};
        }
    }
    std::vector<std::filesystem::path> temporaryArtifacts = {
        identityTempPath, mosTempPath};
    if (!resistorTempPath.empty()) temporaryArtifacts.push_back(resistorTempPath);
    for (const auto& temporary : temporaryArtifacts) {
        error.clear();
        if (pathObjectExists(temporary, error) || error) {
            transaction.Rollback();
            return {false, "工作点后端成功后仍遗留临时输出：" +
                    temporary.string(), logPath.string(), artifactRoot.string()};
        }
    }

    OperatingPointSnapshot snapshot;
    std::vector<Diagnostic> diagnostics;
    if (!LoadOperatingPointTsv(identityPath, mosPath, resistorPath,
                               snapshot, diagnostics)) {
        const auto message = diagnostics.empty() ? std::string("unknown parse failure")
                                                 : diagnostics.front().message;
        transaction.Rollback();
        return {false, "工作点输出校验失败：" + message,
                logPath.string(), artifactRoot.string()};
    }
    if (!IsReusable(snapshot, identity)) {
        transaction.Rollback();
        return {false, "工作点输出的DUT/Bench/PDK/Corner/Topology/Parameter/Solver身份与请求不一致",
                logPath.string(), artifactRoot.string()};
    }
    if (!transaction.Commit(transactionMessage)) {
        return {false, transactionMessage, logPath.string(), artifactRoot.string()};
    }
    return {true, {}, logPath.string(), artifactRoot.string()};
}

HostStatus ProcessVirtuosoBackend::RunVariantOperatingPoint(
    const CellViewRef& target,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const std::string& identityTsvPath,
    const std::string& mosTsvPath)
{
    const OperatingPointOutputs outputs{
        std::filesystem::path(identityTsvPath), std::filesystem::path(mosTsvPath)};
    return RunOperatingPoint(target, bench, identity, outputs);
}

HostStatus ProcessVirtuosoBackend::RunVariantOperatingPoint(
    const CellViewRef& target,
    const CellViewRef& bench,
    const AnalysisIdentity& identity,
    const std::string& identityTsvPath,
    const std::string& mosTsvPath,
    const std::string& resistorTsvPath)
{
    const OperatingPointOutputs outputs{identityTsvPath, mosTsvPath,
                                         resistorTsvPath};
    return RunOperatingPoint(target, bench, identity, outputs);
}

HostStatus ProcessVirtuosoBackend::Run(const std::string& verb,
                                       std::vector<std::string> arguments,
                                       const std::filesystem::path& logPath)
{
    std::vector<std::string> command;
    command.push_back(executable_.string());
    command.push_back(verb);
    command.insert(command.end(), arguments.begin(), arguments.end());
    if (paths_.experimental_dc)
        command.insert(command.end(), {"--validation-scope", "experimental_dc"});
    const auto result = runner_.Run(command, logPath);
    return {result.exit_code == 0,
            result.exit_code == 0 ? std::string{} : result.message,
            logPath.string(), {}};
}

HostStatus ProcessVirtuosoBackend::CopyCircuits(
    const std::vector<OaCloneMapping>& cloneMap)
{
    if (cloneMap.empty()) return {false, "clone map为空", {}, {}};
    for (std::size_t index = 0; index < cloneMap.size(); ++index) {
        const auto& mapping = cloneMap[index];
        std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                              "--hierarchy", mapping.hierarchy_path};
        addCellView(arguments, "source", mapping.source);
        addCellView(arguments, "target", mapping.target);
        auto status = Run("clone", std::move(arguments),
                          paths_.log_dir / ("clone_" + std::to_string(index) + ".log"));
        if (!status.ok) return status;
    }
    return {true, {}, {}, {}};
}

HostStatus ProcessVirtuosoBackend::WritePlanFile(const std::string& path,
                                                 const std::string& json)
{
    const std::filesystem::path target(path);
    std::error_code error;
    std::filesystem::create_directories(target.parent_path(), error);
    if (error) return {false, "无法创建物化计划目录：" + error.message(), {}, path};
    const auto temporary = target.string() + ".tmp";
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        output << json;
        if (!output) return {false, "物化计划写入失败", {}, path};
    }
    std::filesystem::rename(temporary, target, error);
    if (error) {
        std::filesystem::remove(temporary);
        return {false, "物化计划发布失败：" + error.message(), {}, path};
    }
    return {true, {}, {}, path};
}

HostStatus ProcessVirtuosoBackend::ExecuteSkill(const std::string& workDir,
                                                const std::string& skillScriptPath,
                                                const std::string& planPath)
{
    return Run("materialize", {"--cds-lib", paths_.cds_lib.string(),
            "--work-dir", workDir, "--skill", skillScriptPath, "--plan", planPath},
        paths_.log_dir / "materialize.log");
}

HostStatus ProcessVirtuosoBackend::RegenerateNetlist(const CellViewRef& target,
                                                     const std::string& logicalSubckt,
                                                     Netlist& netlist)
{
    const auto callIndex = netlist_call_count_++;
    std::filesystem::path output;
    std::filesystem::path log;
    if (callIndex == 0) {
        output = paths_.source_roundtrip;
        log = paths_.log_dir / "netlist_source.log";
    } else if (callIndex == 1) {
        output = paths_.target_roundtrip;
        log = paths_.log_dir / "netlist_target.log";
    } else {
        std::ostringstream number;
        number << std::setw(4) << std::setfill('0') << callIndex - 1;
        const auto stem = "package_" + number.str() + "_" +
            safeArtifactName(logicalSubckt.empty() ? target.cell : logicalSubckt);
        output = paths_.target_roundtrip.parent_path() / (stem + ".scs");
        log = paths_.log_dir / ("netlist_" + stem + ".log");
    }
    return RegenerateNetlistTo(target, logicalSubckt, output, log, netlist);
}

HostStatus ProcessVirtuosoBackend::RegenerateNetlistTo(
    const CellViewRef& target, const std::string& logicalSubckt,
    const std::filesystem::path& output, const std::filesystem::path& log,
    Netlist& netlist)
{
    if (output.empty() || log.empty()) {
        return {false, "回读网表或日志路径为空", log.string(), output.string()};
    }
    std::error_code error;
    std::filesystem::create_directories(output.parent_path(), error);
    if (!error) std::filesystem::create_directories(log.parent_path(), error);
    if (!error) std::filesystem::remove(output, error);
    if (error) {
        return {false, "回读产物准备失败：" + error.message(),
                log.string(), output.string()};
    }
    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                          "--lib", target.library,
                                          "--cell", target.cell,
                                          "--view", target.view,
                                          "--core-subckt", logicalSubckt.empty()
                                              ? paths_.core_subckt : logicalSubckt,
                                          "--output", output.string()};
    if (!paths_.device_policy.empty()) {
        arguments.insert(arguments.end(),
                         {"--device-policy", paths_.device_policy.string()});
    }
    auto status = Run("netlist", std::move(arguments), log);
    status.artifact_path = output.string();
    if (!status.ok) return status;
    if (!std::filesystem::exists(output, error) || error ||
        std::filesystem::file_size(output, error) == 0 || error) {
        return missingArtifact(output, log);
    }
    std::ifstream input(output, std::ios::binary);
    const std::string text((std::istreambuf_iterator<char>(input)),
                           std::istreambuf_iterator<char>());
    std::vector<Diagnostic> diagnostics;
    netlist = parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) {
        return {false, "回读网表解析失败：" + diagnostics.front().message,
                log.string(), output.string()};
    }
    return {true, {}, log.string(), output.string()};
}

HostStatus ProcessVirtuosoBackend::PublishCircuits(
    const std::vector<OaCloneMapping>& publishMap)
{
    if (paths_.experimental_dc) return {false, "experimental_dc禁止发布staging", {}, {}};
    if (!paths_.operating_point_catalog.empty()) {
        DeviceCatalog catalog;
        std::vector<Diagnostic> diagnostics;
        if (!LoadDeviceCatalogTsv(paths_.operating_point_catalog, catalog, diagnostics))
            return {false, "发布前无法核对固定PDK目录", {}, {}};
        for (const auto& entry : catalog.Descriptors()) {
            if (entry.second.native_parameter_trials)
                return {false, "原生参数试点目录不得发布", {}, {}};
        }
    }
    if (publishMap.empty()) return {false, "publish map为空", {}, {}};
    OaMaterializationPlan plan;
    plan.source = publishMap.front().source;
    plan.target = publishMap.front().target;
    plan.clone_map = publishMap;
    const auto planPath = paths_.log_dir / "publish_plan.json";
    auto status = WritePlanFile(planPath.string(), WritePlanJson(plan));
    if (!status.ok) return status;
    return Run("publish", {"--cds-lib", paths_.cds_lib.string(),
                           "--publish-plan", planPath.string()},
               paths_.log_dir / "publish.log");
}

HostStatus ProcessVirtuosoBackend::Open(const CellViewRef& target)
{
    std::vector<std::string> arguments = {"--cds-lib", paths_.cds_lib.string(),
                                          "--lib", target.library,
                                          "--cell", target.cell,
                                          "--view", target.view};
    return Run("open", std::move(arguments), paths_.log_dir / "open.log");
}

} // namespace st::standalone
