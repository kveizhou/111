#include "st/MainFlow.h"

#include <cctype>
#include <cmath>
#include <fstream>
#include <set>
#include <stdexcept>
#include <utility>

namespace st::standalone {
namespace {

// Small JSON reader for integration fields, without a new library dependency.
// Retains scalar types and object paths; accepts // and /* */ example comments.
// Unknown nested settings are parsed, not mistaken for top-level DUT fields.
struct Value { char type; std::string text; };
using Fields = std::map<std::string, Value>;
class Reader {
public:
    explicit Reader(std::string text) : text_(std::move(text)) {}
    Fields Read() {
        Space();
        if (Peek() != '{') Fail();
        Parse("", 0);
        Space();
        if (pos_ != text_.size()) Fail();
        return fields_;
    }
private:
    [[noreturn]] void Fail() const {
        throw std::runtime_error("无效JSON，字节位置=" + std::to_string(pos_));
    }
    char Peek() const { return pos_ < text_.size() ? text_[pos_] : '\0'; }
    void Space() {
        for (;;) {
            while (std::isspace(static_cast<unsigned char>(Peek()))) ++pos_;
            if (text_.compare(pos_, 2, "//") == 0) {
                while (Peek() && Peek() != '\n') ++pos_;
            } else if (text_.compare(pos_, 2, "/*") == 0) {
                const auto end = text_.find("*/", pos_ + 2);
                if (end == std::string::npos) Fail();
                pos_ = end + 2;
            } else return;
        }
    }
    bool Take(char c) {
        Space();
        if (Peek() != c) return false;
        ++pos_;
        return true;
    }
    unsigned Hex() {
        unsigned code = 0;
        for (int i = 0; i < 4; ++i) {
            const unsigned char c = Peek();
            if (!std::isxdigit(c)) Fail();
            ++pos_;
            code = code * 16 + (std::isdigit(c) ? c - '0' : std::tolower(c) - 'a' + 10);
        }
        return code;
    }
    std::string String() {
        if (!Take('"')) Fail();
        std::string out;
        while (Peek() != '"') {
            unsigned char c = Peek();
            if (c < 32) Fail();
            ++pos_;
            if (c != '\\') { out += static_cast<char>(c); continue; }
            c = Peek();
            if (!c) Fail();
            ++pos_;
            const std::string escapes = "\"\\/bfnrt";
            const auto index = escapes.find(c);
            if (index != std::string::npos) {
                out += std::string("\"\\/\b\f\n\r\t")[index];
            } else if (c == 'u') {
                unsigned code = Hex();
                if (code >= 0xd800 && code <= 0xdbff) {
                    if (text_.compare(pos_, 2, "\\u") != 0) Fail();
                    pos_ += 2;
                    const unsigned low = Hex();
                    if (low < 0xdc00 || low > 0xdfff) Fail();
                    code = 0x10000 + ((code - 0xd800) << 10) + low - 0xdc00;
                } else if (code >= 0xdc00 && code <= 0xdfff) Fail();
                if (code < 0x80) out += static_cast<char>(code);
                else {
                    if (code < 0x800) out += static_cast<char>(0xc0 | (code >> 6));
                    else {
                        if (code < 0x10000) out += static_cast<char>(0xe0 | (code >> 12));
                        else {
                            out += static_cast<char>(0xf0 | (code >> 18));
                            out += static_cast<char>(0x80 | ((code >> 12) & 63));
                        }
                        out += static_cast<char>(0x80 | ((code >> 6) & 63));
                    }
                    out += static_cast<char>(0x80 | (code & 63));
                }
            } else Fail();
        }
        ++pos_;
        return out;
    }
    void Parse(const std::string& path, unsigned depth) {
        if (depth > 64) Fail();
        Space();
        const char type = Peek();
        Value value{type, {}};
        if (type == '{' || type == '[') {
            ++pos_;
            const char end = type == '{' ? '}' : ']';
            std::set<std::string> keys;
            unsigned index = 0;
            if (!Take(end)) {
                do {
                    std::string key = type == '{' ? String() : std::to_string(index++);
                    // JSON-pointer escaping prevents collisions with nested keys.
                    std::string component;
                    for (char c : key) component += c == '~' ? "~0" : c == '/' ? "~1" : std::string(1, c);
                    if (!keys.insert(key).second) Fail();
                    if (type == '{' && !Take(':')) Fail();
                    Parse(path + "/" + component, depth + 1);
                } while (Take(','));
                if (!Take(end)) Fail();
            }
        } else if (type == '"') value.text = String();
        else if (type == 't' || type == 'f' || type == 'n') {
            value.text = type == 't' ? "true" : type == 'f' ? "false" : "null";
            if (text_.compare(pos_, value.text.size(), value.text) != 0) Fail();
            pos_ += value.text.size();
        } else {
            const auto start = pos_;
            if (Peek() == '-') ++pos_;
            if (Peek() == '0') ++pos_;
            else {
                if (Peek() < '1' || Peek() > '9') Fail();
                while (std::isdigit(static_cast<unsigned char>(Peek()))) ++pos_;
            }
            if (Peek() == '.') {
                ++pos_;
                if (!std::isdigit(static_cast<unsigned char>(Peek()))) Fail();
                while (std::isdigit(static_cast<unsigned char>(Peek()))) ++pos_;
            }
            if (Peek() == 'e' || Peek() == 'E') {
                ++pos_;
                if (Peek() == '+' || Peek() == '-') ++pos_;
                if (!std::isdigit(static_cast<unsigned char>(Peek()))) Fail();
                while (std::isdigit(static_cast<unsigned char>(Peek()))) ++pos_;
            }
            value.type = '#';
            value.text = text_.substr(start, pos_ - start);
        }
        fields_.emplace(path, std::move(value));
    }
    std::string text_;
    std::size_t pos_ = 0;
    Fields fields_;
};

Fields ReadFile(const std::filesystem::path& path) {
    std::ifstream stream(path);
    if (!stream) throw std::runtime_error("无法读取JSON：" + path.string());
    return Reader({std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()}).Read();
}
std::string Text(const Fields& fields, const std::string& key, bool required = true) {
    const auto item = fields.find("/" + key);
    if (item == fields.end() && !required) return {};
    if (item == fields.end() || item->second.type != '"' || item->second.text.empty() ||
        item->second.text.find_first_of(std::string("\0\r\n", 3)) != std::string::npos)
        throw std::runtime_error("JSON字段缺失或不是非空字符串：" + key);
    return item->second.text;
}
std::string Identifier(std::string value) {
    for (char& c : value)
        if (!std::isalnum(static_cast<unsigned char>(c)) && c != '_') c = '_';
    return value;
}
std::string NumericText(const Fields& fields, const std::string& key) {
    const auto item = fields.find("/" + key);
    if (item == fields.end() || (item->second.type != '"' && item->second.type != '#'))
        throw std::runtime_error("JSON数值字段缺失或类型错误：" + key);
    std::size_t end = 0;
    const double value = std::stod(item->second.text, &end);
    if (!std::isfinite(value) || end != item->second.text.size())
        throw std::runtime_error("JSON数值字段无效：" + key);
    return item->second.text;
}
} // namespace

bool LoadMainFlowOptions(const std::filesystem::path& caseFile, const std::string& side,
                         std::map<std::string, std::string>& options, std::string& message)
{
    try {
        if (side != "source" && side != "target")
            throw std::runtime_error("case-side必须为source或target");
        const auto fields = ReadFile(caseFile);
        const std::filesystem::path cds = Text(fields, side + "_cds_path");
        const std::filesystem::path backend = Text(fields, "st_backend_script");
        const std::filesystem::path project = Text(fields, "project_path");
        if (!cds.is_absolute() || !backend.is_absolute() || !project.is_absolute())
            throw std::runtime_error("Case电路路径、project_path和st_backend_script必须为绝对路径");
        std::map<std::string, std::string> mapped{
            {"backend", backend.string()}, {"cds-lib", (cds / "cds.lib").string()},
            {"lib", Text(fields, side + "_dut_lib")},
            {"cell", Text(fields, side + "_dut_cell")},
            {"view", Text(fields, side + "_dut_view")},
            {"bench-lib", Text(fields, side + "_tb_lib")},
            {"bench-cell", Text(fields, side + "_tb_cell")},
            {"bench-view", Text(fields, side + "_tb_view")},
            {"nominal-corner", Text(fields, "pvt/corner")},
            {"mainflow-temperature", NumericText(fields, "pvt/temp")},
            {"work-dir", (project / "structure_transform").string()},
            {"skill", (backend.parent_path().parent_path() / "skill/topology_variant.il").string()},
            {"validation-scope", "experimental_dc"}, {"auto-vbias-rails", "true"},
            {"simulator", "spectre"}
        };
        mapped["variant-lib"] = "ST_" + Identifier(mapped["lib"]);
        mapped["variant-cell"] = Identifier(mapped["cell"]) + "_variant";
        mapped["variant-id"] = Identifier(mapped["cell"]) + "_mainflow";
        for (const auto* name : {"vbias_vhigh_net", "vbias_vlow_net"}) {
            const auto value = Text(fields, name, false);
            if (!value.empty()) {
                std::string key = name;
                for (char& c : key) if (c == '_') c = '-';
                mapped[key] = value;
            }
        }
        // The host owns complete model/launch settings, not this mapper.
        options = std::move(mapped);
        return true;
    } catch (const std::exception& exception) { message = exception.what(); return false; }
}

bool LoadProviderEnvironment(const std::filesystem::path& manifest,
                             std::map<std::string, std::string>& environment,
                             std::string& message)
{
    try {
        const auto fields = ReadFile(manifest);
        std::map<std::string, std::string> result{
            {"ST_CIRCUIT_CONTEXT", Text(fields, "context")},
            {"ST_SIMULATION_PROFILE", Text(fields, "rules")},
            {"ST_PDK_METADATA", Text(fields, "tech")},
            {"ST_PDK_TECH_ADAPTER", Text(fields, "adapter")},
            {"ST_CADENCE_RUNTIME_BIN", Text(fields, "runtime")},
            {"ST_SITE_INPUTS_MANIFEST", std::filesystem::absolute(manifest).string()}
        };
        const auto init = Text(fields, "init", false);
        if (!init.empty()) result["ST_SKILL_INIT"] = init;
        environment = std::move(result);
        return true;
    } catch (const std::exception& exception) { message = exception.what(); return false; }
}

bool InheritSimulationOptions(const std::filesystem::path& profile,
                              const std::map<std::string, std::string>& caseOptions,
                              std::map<std::string, std::string>& options,
                              std::string& message)
{
    try {
        const auto fields = ReadFile(profile);
        const auto corner = Text(fields, "nominal_corner");
        if (corner != caseOptions.at("nominal-corner") ||
            std::stod(NumericText(fields, "op_corners/" + corner + "/temperature")) !=
            std::stod(caseOptions.at("mainflow-temperature")))
            throw std::runtime_error("主流程JSON与已有EDA配置的名义Corner/温度不一致");
        const auto pvt = fields.find("/pvt_corners");
        if (pvt != fields.end()) {
            if (pvt->second.type != '[') throw std::runtime_error("pvt_corners必须为数组");
            std::string corners;
            for (unsigned i = 0; fields.count("/pvt_corners/" + std::to_string(i)); ++i) {
                const auto name = Text(fields, "pvt_corners/" + std::to_string(i));
                if (!fields.count("/op_corners/" + name))
                    throw std::runtime_error("PVT Corner未配置模型和温度：" + name);
                if (!corners.empty()) corners += ',';
                corners += name;
            }
            if (options.count("pvt-corners") && options.at("pvt-corners") != corners)
                throw std::runtime_error("CLI与已有EDA配置的PVT列表不一致");
            options["pvt-corners"] = corners;
        }
        return true;
    } catch (const std::exception& exception) { message = exception.what(); return false; }
}

EnvironmentProcessRunner::EnvironmentProcessRunner(ProcessRunner& runner,
    std::map<std::string, std::string> environment)
    : runner_(runner), environment_(std::move(environment)) {}

ProcessResult EnvironmentProcessRunner::Run(const std::vector<std::string>& arguments,
                                             const std::filesystem::path& logPath)
{
    if (environment_.empty()) return runner_.Run(arguments, logPath);
    std::vector<std::string> child{"/usr/bin/env"};
    for (const auto& item : environment_) child.push_back(item.first + "=" + item.second);
    child.insert(child.end(), arguments.begin(), arguments.end());
    return runner_.Run(child, logPath);
}
} // namespace st::standalone
