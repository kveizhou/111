#pragma once

#include "CliInternal.h"
#include "st/Packaging.h"

#include <memory>
#include <optional>

namespace st::standalone::detail {

class BackendDcEvaluationHost;

// Shared state has one owner; each phase retains its original return codes and diagnostics.
struct SolveOperationsState;
struct OperationReport;

struct GenerateContext {
    const std::filesystem::path& root;
    const Options& options;
    std::ostream& output;
    std::ostream& error;
    ProcessRunner& runner;
    std::string message;
    SessionManifest manifest;
    Netlist baseline;
    DeviceCatalog catalog;
    std::vector<TransformRequest> requests;
    std::optional<double> maxBranchCurrentError;
    std::optional<double> maxVbiasCurrent;
    bool structureOnly = false;
    bool experimentalDc = false;
    bool hasBiasOperation = false;
    bool currentLimitsApplied = false;
    bool nativeParameterTrials = false;
    bool pvtConfigured = false;
    BackendPaths paths;
    std::unique_ptr<ProcessVirtuosoBackend> backend;
    CellViewRef source;
    CellViewRef bench;
    std::filesystem::path scanDirectory;
    OperatingPointSnapshot baselineOp;
    AnalysisIdentity nominalIdentity;
    RootGeometry geometry;
    std::vector<TransformRequest> solvedRequests;
    std::vector<ElectricalConstraintRequest> electricalChecks;
    std::string generationRun;
    PackageTopologyResult packaged;
    CellViewRef staging;
    GenerationRequest generationRequest;

    GenerateContext(const std::filesystem::path& rootPath, const Options& commandOptions,
                    std::ostream& out, std::ostream& err, ProcessRunner& processRunner)
        : root(rootPath), options(commandOptions), output(out), error(err), runner(processRunner) {}
    int GenerateLoadAndValidate();
    int GenerateRescanPdk();
    int GenerateBaselineOp();
    std::unique_ptr<BackendDcEvaluationHost> CreateEvaluationHost();
    int GenerateSolveOperations();
    void GenerateSolveOperation(SolveOperationsState& state, const TransformRequest& input);
    void GenerateSolveBiasOperation(SolveOperationsState& state, TransformRequest& request,
                                    OperationReport& report);
    int GeneratePlan();
    void ConfigureGenerationRequest(const OaMaterializationPlan& plan, const ReplayResult& replay,
                                    const Netlist& expected, const std::vector<ExpectedResistor>& sourceResistorChecks,
                                    const CellViewRef& target);
    int GenerateMaterializeAndReport();
};

} // namespace st::standalone::detail
