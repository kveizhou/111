#pragma once

#include "VirtuosoBackend.h"

#include <map>

namespace st::standalone {

// Map the existing main-flow JSON to the same options consumed by RunCli.
// Does not start Python, an EDA process, or another C++ tool process.
bool LoadMainFlowOptions(const std::filesystem::path& caseFile,
                         const std::string& side,
                         std::map<std::string, std::string>& options,
                         std::string& message);

// Optional existing EDA input bundle. Main-flow hosts can instead supply their
// own ProcessRunner/environment; simulation settings remain the host's inputs.
bool LoadProviderEnvironment(const std::filesystem::path& manifest,
                             std::map<std::string, std::string>& environment,
                             std::string& message);

// Reuse the host's actual model-corner list, checking nominal corner/temperature.
bool InheritSimulationOptions(const std::filesystem::path& profile,
                              const std::map<std::string, std::string>& caseOptions,
                              std::map<std::string, std::string>& options,
                              std::string& message);

// Per-call child environment: never changes the calling process's cwd or env.
class EnvironmentProcessRunner : public ProcessRunner {
public:
    EnvironmentProcessRunner(ProcessRunner& runner,
                             std::map<std::string, std::string> environment);
    ProcessResult Run(const std::vector<std::string>& arguments,
                      const std::filesystem::path& logPath) override;
private:
    ProcessRunner& runner_;
    std::map<std::string, std::string> environment_;
};

} // namespace st::standalone
