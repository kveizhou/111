#include "st/MainFlow.h"

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>

int main()
{
    int failures = 0;
    const auto check = [&](bool result, const char* message) {
        std::cout << (result ? "ok: " : "FAIL: ") << message << '\n';
        if (!result) ++failures;
    };
    const auto root = std::filesystem::temp_directory_path() / "st_mainflow_reader";
    std::filesystem::create_directories(root);
    const auto file = root / "case.json";
    const auto write = [&](const std::string& text) { std::ofstream(file) << text; };
    const std::string json = R"({
        // main-flow sample, paths and DUT supplied by host
        "project_path":"/workspace/\u7535\u8def",
        "target_cds_path":"/workspace/target","source_cds_path":"/workspace/source",
        "target_dut_lib":"DST","target_dut_cell":"core","target_dut_view":"schematic",
        "source_dut_lib":"SRC","source_dut_cell":"original","source_dut_view":"schematic",
        "target_tb_lib":"TB","target_tb_cell":"bench","target_tb_view":"maestro",
        "source_tb_lib":"TB0","source_tb_cell":"bench0","source_tb_view":"maestro",
        "pvt":{"corner":"tt","temp":"27"}, "st_backend_script":"/engine/server/st_virtuoso_backend.sh",
        "other":[true,false,null,-1.25e-3,{"target_dut_lib":"wrong"}]
    })";
    std::map<std::string, std::string> fields;
    std::string error;
    write(json);
    check(st::standalone::LoadMainFlowOptions(file, "target", fields, error) &&
          fields.at("lib") == "DST" && fields.at("cds-lib") == "/workspace/target/cds.lib" &&
          fields.at("work-dir") == "/workspace/电路/structure_transform",
          "JSON嵌套、数组、注释和Unicode不影响真实target字段");
    check(st::standalone::LoadMainFlowOptions(file, "source", fields, error) &&
          fields.at("lib") == "SRC" && fields.at("cell") == "original",
          "显式source侧使用整套source路径、DUT和Bench");
    const auto caseFields = fields;
    write(R"({"nominal_corner":"tt","pvt_corners":["tt","ss"],
              "op_corners":{"tt":{"temperature":27},"ss":{"temperature":125}}})");
    std::map<std::string, std::string> simulation;
    check(st::standalone::InheritSimulationOptions(file, caseFields, simulation, error) &&
          simulation.at("pvt-corners") == "tt,ss",
          "沿用已有仿真配置的真实PVT列表，不从tt猜其它角点");
    auto mismatch = caseFields;
    mismatch["mainflow-temperature"] = "125";
    check(!st::standalone::InheritSimulationOptions(file, mismatch, simulation, error),
          "主流程温度与已有EDA配置不一致时拒绝仿真错Case");
    write(R"({"nominal_corner":"tt","op_corners":{"tt":{"temperature":27}}})");
    simulation.clear();
    check(st::standalone::InheritSimulationOptions(file, caseFields, simulation, error) &&
          !simulation.count("pvt-corners"), "没有PVT列表时不自动增加角点");
    check(!st::standalone::LoadMainFlowOptions(file, "bad", fields, error), "拒绝未知电路侧");
    for (const auto& text : {
            json + " garbage", std::string("{\"project_path\":\"/one\",\"project_path\":\"/two\"}"),
            std::string("{\"project_path\":false}"), std::string("{\"project_path\":\"\\uD800\"}"),
            std::string("{\"a\":01}"), std::string("{\"a\":NaN}"),
            std::string("{\"a\":[1,]}")}) {
        write(text);
        check(!st::standalone::LoadMainFlowOptions(file, "target", fields, error),
              "格式错误或重复/错类型字段在执行后端前返回错误");
    }
    write(R"({"context":"/context","rules":"/profile","tech":"/tech",
               "adapter":"/adapter","runtime":"/runtime","init":"/init"})");
    check(st::standalone::LoadProviderEnvironment(file, fields, error) &&
          fields.at("ST_SIMULATION_PROFILE") == "/profile" &&
          fields.at("ST_PDK_TECH_ADAPTER") == "/adapter",
          "已有EDA输入直接读取为子进程环境，无Python启动器");
    st::standalone::PosixProcessRunner process;
    st::standalone::EnvironmentProcessRunner child(process, {{"ST_MAINFLOW_TEST_VALUE", "a b;$()"}});
    const auto log = root / "child.log";
    const auto previous = std::getenv("ST_MAINFLOW_TEST_VALUE");
    const std::string before = previous ? previous : "";
    const auto status = child.Run({"/bin/sh", "-c", "printf '%s' \"$ST_MAINFLOW_TEST_VALUE\"; printf error >&2; exit 7"}, log);
    std::ifstream stream(log);
    const std::string output{std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()};
    const auto after = std::getenv("ST_MAINFLOW_TEST_VALUE");
    check(status.exit_code == 7 && output == "a b;$()error" &&
          (after ? after : "") == before, "原生进程保留退出码和双流日志，参数不经shell拼接且不改主进程环境");
    check(process.Run({"/nonexistent/st_backend"}, log).exit_code == 127,
          "后端程序不存在时返回执行失败");
    std::cout << "Main-flow failures=" << failures << '\n';
    return failures ? 1 : 0;
}
