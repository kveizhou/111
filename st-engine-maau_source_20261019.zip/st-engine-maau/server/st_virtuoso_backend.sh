#!/usr/bin/env bash
set -euo pipefail

server_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

if [[ $# -lt 1 ]]; then
    echo "usage: $0 discover-pdk|probe-pdk|scan-pdk|run-op|device-bindings|snapshot|clone|materialize|netlist|publish|open [arguments...]" >&2
    exit 2
fi

verb=$1
shift

case "$verb" in
    discover-pdk)
        runner="$server_dir/bin/discover_pdk_runner.sh"
        ;;
    probe-pdk)
        runner="$server_dir/bin/probe_pdk_runner.sh"
        ;;
    scan-pdk)
        runner="$server_dir/bin/scan_pdk_runner.sh"
        ;;
    run-op)
        runner="$server_dir/bin/run_op_runner.sh"
        ;;
    device-bindings)
        runner="$server_dir/bin/device_bindings_runner.sh"
        ;;
    snapshot|clone|materialize|netlist|publish|open)
        runner="$server_dir/bin/${verb}_runner.sh"
        ;;
    *)
        echo "unsupported backend verb: $verb" >&2
        exit 2
        ;;
esac

if [[ ! -x "$runner" ]]; then
    echo "backend runner is not executable: $runner" >&2
    exit 64
fi

exec "$runner" "$@"
