"""Shared signed scalar PSF readers, reused by diagnostics and the formal runtime."""
import json
import math
from pathlib import Path
import re


def canonical_device(value):
    # Spectre escapes array brackets; the backslash is not a hierarchy level.
    value = re.sub(r'\\([<>])', r'\1', value)
    return '.'.join(part for part in re.split(r'[./]+', value) if part)


def validate_query(query):
    if not isinstance(query, dict) or set(query) != {'schema','nodes','device_parameters','currents'} or query['schema'] != 'st-dc-query-v1':
        raise ValueError('invalid formal DC query schema')
    def names(values, label, colon=False):
        if not isinstance(values,list) or any(not isinstance(v,str) or not v or any(c in v for c in '\t\n\r') for v in values):
            raise ValueError('invalid '+label+' names')
        if len(values)!=len(set(values)) or any((':' in v)!=colon for v in values):
            raise ValueError('duplicate or ambiguous '+label+' names')
    names(query['nodes'],'node');names(query['currents'],'current',True)
    devices=query['device_parameters']
    if not isinstance(devices,dict):raise ValueError('device_parameters must be an object')
    names(list(devices),'device')
    for name,params in devices.items():
        if canonical_device(name)!=name or not params:
            raise ValueError('device query must use exact canonical path and parameters: '+repr(name))
        names(params,'parameter')
    if not query['nodes'] and not devices and not query['currents']:raise ValueError('empty DC query')
    return query


def query_script(psf, query, init, directory):
    validate_query(query)
    directory=Path(directory)
    code=node_context_script(psf,query,init,directory/'nodes.tsv',finish=False)
    code+=focused_op_script(psf,list(query['device_parameters']),init,directory/'ops.tsv',finish=False,exact=True)
    code+='result=errset(and(stNodeRead() stFocusRead()) t)\n'
    code+='when(and(result car(result)) port=outfile('+json.dumps(str(directory/'runtime.done'))+') fprintf(port "OK\\n") close(port))\nexit()\n'
    return code


def consume_query(query, node_rows, op_rows):
    """Consume only exact requested signals; keep raw signs and source names."""
    validate_query(query);raw={};sources={};seen=set();devices={}
    def numeric(row):
        if row['status']!='OK':raise ValueError('required DC signal unavailable: '+row['signal']+' '+row['status'])
        try:value=float(row['value'])
        except (TypeError,ValueError):raise ValueError('invalid numeric DC value: '+row['signal'])
        if not math.isfinite(value):raise ValueError('nonfinite DC value: '+row['signal'])
        return value
    for row in node_rows:
        if set(row)!={'kind','signal','value','status'}:raise ValueError('invalid node table')
        kind,name=row['kind'],row['signal']
        wanted=query['nodes'] if kind=='node' else query['currents'] if kind=='current' else []
        if name not in wanted or name=='0':raise ValueError('unrequested exact node/current: '+name)
        if name in seen:raise ValueError('duplicate node/current: '+name)
        seen.add(name);raw[name]=numeric(row);sources[name]=dict(kind=kind,signal=name,result='dcOp')
    if '0' in query['nodes']:raw['0']=0.;sources['0']=dict(kind='reference_zero',signal='0')
    for row in op_rows:
        if set(row)!={'kind','signal','parameter','value','status'}:raise ValueError('invalid OP table')
        signal=canonical_device(row['signal'])
        if signal not in query['device_parameters']:raise ValueError('unrequested exact device: '+row['signal'])
        record=devices.setdefault(signal,dict(signal=row['signal'],params={},type=None))
        if record['signal']!=row['signal']:raise ValueError('ambiguous canonical device: '+signal)
        if row['kind']=='device':
            if row['status']!='META' or row['parameter'] or not row['value'] or record['type'] is not None:raise ValueError('invalid/duplicate device metadata')
            record['type']=row['value']
        elif row['kind']=='op':
            param=row['parameter']
            if not param or param in record['params'] or row['status'] not in ('OK','NON_NUMERIC','READ_ERROR'):raise ValueError('invalid/duplicate OP parameter')
            record['params'][param]=row
        else:raise ValueError('unknown OP row kind')
    for device,params in query['device_parameters'].items():
        record=devices.get(device)
        if not record or not record['type']:raise ValueError('required device metadata missing: '+device)
        rows=record['params']
        if all(k in rows and rows[k]['status']=='OK' for k in ('vdsat','vdssat')) and numeric(rows['vdsat'])!=numeric(rows['vdssat']):
            raise ValueError('conflicting vdsat/vdssat: '+device)
        for param in params:
            if param not in rows:raise ValueError('required OP missing: '+device+':'+param)
            key=device+':'+param;raw[key]=numeric(rows[param])
            sources[key]=dict(kind='op',signal=record['signal'],parameter=param,device_type=record['type'],result='dcOpInfo')
    missing=(set(query['nodes'])|set(query['currents']))-raw.keys()
    if missing:raise ValueError('required nodes/currents missing: '+','.join(sorted(missing)))
    return raw,sources

def focused_op_script(psf, paths, init, table, finish=True, exact=False):
    """Read only target device OP; node/waveform inventory is not needed here."""
    paths = [canonical_device(p) for p in paths]
    script = 'load('+json.dumps(str(init))+')\nstFocusTargets=list('+ ' '.join(json.dumps(p) for p in paths)+')\nstFocusExact='+('t' if exact else 'nil')+'\n'+r'''
procedure(stFocusName(value)
  let((result clean index char)
    clean="" index=1
    while(index<=strlen(value)
      char=substring(value index 1)
      when(and(equal(char "\\") index<strlen(value)
        member(substring(value index+1 1) list("<" ">")))
        index=index+1
        char=substring(value index 1))
      clean=strcat(clean char)
      index=index+1)
    result=""
    foreach(part parseString(clean "./")
      result=strcat(result if(equal(result "") then "" else ".") part))
    result
  )
)
procedure(stFocusTargetP(value)
  let((name found)
    name=stFocusName(value)
    foreach(prefix stFocusTargets
      when(or(equal(name prefix) and(not(stFocusExact) strlen(name)>strlen(prefix)
        equal(substring(name 1 strlen(prefix)) prefix)
        equal(substring(name strlen(prefix)+1 1) "."))) found=t))
    found
  )
)
procedure(stFocusScalar(value)
  cond((numberp(value) value)
       (drIsWaveform(value)
         let((vec result)
           vec=drGetWaveformYVec(value)
           when(equal(drVectorLength(vec) 1) result=drGetElem(vec 0))
           if(numberp(result) then result else nil)))
       (t nil))
)
procedure(stFocusRead()
  let((port result decoded scalar params devices hits total)
    printf("ST_OP_STAGE=OPEN_RESULTS\n")
    unless(openResults(__PSF__) error("Cannot open saved PSF"))
    printf("ST_OP_RESULTS=%L\n" results())
    unless(selectResult('dcOpInfo) error("dcOpInfo result unavailable"))
    port=outfile(__TABLE__)
    unless(port error("Cannot create focused OP table"))
    fprintf(port "kind\tsignal\tparameter\tvalue\tstatus\n")
    total=0
    foreach(kind dataTypes()
      params=outputParams(kind)
      devices=outputs(?type kind ?map nil)
      hits=0
      foreach(device devices
        when(stFocusTargetP(device)
          hits=hits+1 total=total+1
          printf("ST_OP_TARGET device=%s type=%s\n" device kind)
          fprintf(port "device\t%s\t\t%s\tMETA\n" device kind)
          foreach(param params
              result=errset(pv(device param ?result 'dcOpInfo) nil)
              scalar=nil
              when(result
                decoded=errset(stFocusScalar(car(result)) nil)
                when(decoded scalar=car(decoded)))
              if(numberp(scalar) then
                fprintf(port "op\t%s\t%s\t%.17g\tOK\n" device param float(scalar))
              else
                fprintf(port "op\t%s\t%s\t\t%s\n" device param if(result then "NON_NUMERIC" else "READ_ERROR"))
                printf("ST_OP_VALUE device=%s param=%s status=%s type=%L\n"
                  device param if(result then "NON_NUMERIC" else "READ_ERROR") if(result then type(car(result)) else nil))
              )
          )
        )
      )
      printf("ST_OP_TYPE type=%s outputs=%d matched=%d\n" kind length(devices) hits))
    close(port)
    printf("ST_OP_STAGE=TARGETS_COMPLETE matched=%d\n" total)
    t
  )
)
result=errset(stFocusRead() t)
when(and(result car(result))
  port=outfile(__MARKER__) fprintf(port "OK\n") close(port))
exit()
'''.replace('__PSF__',json.dumps(str(psf))).replace('__TABLE__',json.dumps(str(table))).replace(
        '__MARKER__',json.dumps(str(table.parent/'runtime.done')))

    return script if finish else script[:script.index('result=errset(stFocusRead() t)')]

def node_context_script(psf,request,init,table,finish=True):
    q=json.dumps
    script = ('load('+q(str(init))+')\nstNodeNames=list('+ ' '.join(q(n) for n in request['nodes'] if n!='0')+')\n'
        +'stNodeSources=list('+ ' '.join(q(s['path']+':') for s in request.get('voltage_sources',[]))+')\n'
        +'stNodeCurrents=list('+ ' '.join(q(n) for n in request.get('currents',[]))+')\n'+r'''
procedure(stNodeScalar(value)
  cond((numberp(value) value)
       (drIsWaveform(value)
         let((vec result)
           vec=drGetWaveformYVec(value)
           when(equal(drVectorLength(vec) 1) result=drGetElem(vec 0))
           if(numberp(result) then result else nil)))
       (t nil))
)
procedure(stNodeWrite(port kind name)
  let((result decoded scalar)
    result=errset(getData(name) nil)
    when(result
      decoded=errset(stNodeScalar(car(result)) nil)
      when(decoded scalar=car(decoded)))
    if(numberp(scalar) then
      fprintf(port "%s\t%s\t%.17g\tOK\n" kind name float(scalar))
    else
      fprintf(port "%s\t%s\t\t%s\n" kind name
        cond((null(result) "READ_ERROR") (null(car(result)) "MISSING") (t "NON_NUMERIC"))))
  )
)
procedure(stNodeCurrentP(name)
  let((found)
    foreach(prefix stNodeSources
      when(and(strlen(name)>strlen(prefix) equal(substring(name 1 strlen(prefix)) prefix)) found=t))
    found
  )
)
procedure(stNodeRead()
  let((port signals inventory)
    unless(openResults(__PSF__) error("Cannot open saved PSF"))
    unless(selectResult('dcOp) error("dcOp node result unavailable"))
    signals=outputs(?map nil)
    inventory=outfile(__INVENTORY__)
    unless(inventory error("Cannot create node inventory"))
    foreach(name signals fprintf(inventory "%s\n" name))
    close(inventory)
    port=outfile(__TABLE__)
    unless(port error("Cannot create node table"))
    fprintf(port "kind\tsignal\tvalue\tstatus\n")
    foreach(name stNodeNames stNodeWrite(port "node" name))
    foreach(name signals when(stNodeCurrentP(name) stNodeWrite(port "current" name)))
    foreach(name stNodeCurrents stNodeWrite(port "current" name))
    close(port)
    t
  )
)
result=errset(stNodeRead() t)
when(and(result car(result))
  port=outfile(__MARKER__) fprintf(port "OK\n") close(port))
exit()
'''.replace('__PSF__',q(str(psf))).replace('__TABLE__',q(str(table))).replace('__MARKER__',q(str(table.parent/'runtime.done')))
        .replace('__INVENTORY__',q(str(table.parent/'outputs.txt'))))

    return script if finish else script[:script.index('result=errset(stNodeRead() t)')]
