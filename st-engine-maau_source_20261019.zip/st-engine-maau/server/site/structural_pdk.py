"""Read OA/CDF structure without inventing simulation or polarity data."""
import csv
import hashlib
import json
from pathlib import Path

from standalone_pdk import cdf_numeric, numeric


def build_structure_metadata(root, probe_path, rules, pdk_name=None):
    requested = root if isinstance(root, (list, tuple)) else [root]
    aliases = list(dict.fromkeys(str(Path(p).absolute()) for p in requested))
    roots = list(dict.fromkeys(str(Path(p).resolve()) for p in aliases))
    if not roots or any(not Path(p).is_dir() for p in roots):
        raise ValueError('PDK root must be an existing directory')
    groups = {}
    with Path(probe_path).open(newline='') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        required = {'oa_library', 'oa_cell', 'oa_view', 'terminal_names', 'parameter', 'cdf_type', 'default_value', 'has_schematic'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('structural inspect needs the current extended OA/CDF probe')
        for row in reader:
            if None in row:
                raise ValueError('malformed OA/CDF probe record')
            groups.setdefault((row['oa_library'], row['oa_cell']), []).append(row)
    devices, rejected = [], []
    mos_names = {'D': 'drain', 'G': 'gate', 'S': 'source', 'B': 'bulk', 'BODY': 'bulk', 'BULK': 'bulk'}
    res_names = {'PLUS': 'positive', 'P': 'positive', 'MINUS': 'negative', 'N': 'negative',
                 'B': 'substrate', 'BULK': 'substrate', 'SUB': 'substrate', 'SUBSTRATE': 'substrate'}
    for (library, cell), rows in sorted(groups.items()):
        identity = rows[0]
        if any(r['terminal_names'] != identity['terminal_names'] for r in rows):
            raise ValueError('conflicting CDF terminal order: ' + library + '/' + cell)
        names = identity['terminal_names'].split(',')
        parameters = {r['parameter']: r for r in rows if r['parameter']}
        rule = rules.get('devices', {}).get(library + '/' + cell, rules.get('devices', {}).get(cell, {}))
        if rule and not rules.get('source'):
            raise ValueError('PDK rule supplement needs an authoritative source')
        semantics = rule.get('normalized_to_cdf', {'width': 'w', 'length': 'l', 'fingers': 'nf', 'multiplier': 'm', 'resistance': 'r'})
        roles = [mos_names.get(n.upper(), 'other') for n in names]
        mos = len(names) in (3, 4) and all(roles.count(r) == 1 for r in ('drain', 'gate', 'source')) and (
            len(names) == 3 or roles.count('bulk') == 1)
        resistance = parameters.get(semantics.get('resistance', 'r'))
        if identity.get('has_schematic') != 'false' or len(set(names)) != len(names) or not all(names):
            reason = 'hierarchical or unproven primitive/terminal order'
        # Same-master structural transforms retain every original CDF value.
        # Fin-count MOS may declare l/nfin without w; do not invent a width
        # mapping or convert fw/nfin/fingers into a planar geometry.
        elif mos and semantics.get('length') in parameters and (
                semantics.get('width') in parameters or 'nfin' in parameters):
            kind, reason = 'mos', ''  # Only structural identity, no guessed N/P.
        elif resistance and resistance.get('cdf_type') in ('string', 'float', 'int'):
            roles = [res_names.get(n.upper(), 'other') for n in names]
            kind, reason = 'resistor', ''
            if len(names) not in (2, 3) or roles.count('positive') != 1 or roles.count('negative') != 1 or 'other' in roles:
                reason = 'unproven resistor terminals'
        else:
            reason = 'no proven structural MOS/resistor CDF declaration'
        if reason:
            rejected.append({'library': library, 'cell': cell, 'reason': reason})
            continue
        # Preserve every original scalar CDF property through the existing OA
        # exporter, including same-master string/enum settings. This declares
        # their names; it does not allow arbitrary undeclared properties.
        mapping = {'cdf_' + name: name for name in parameters}
        mapping.update({s: p for s, p in semantics.items() if p in parameters})
        constraints = {}
        for semantic, parameter in semantics.items():
            row = parameters.get(parameter)
            if not row:
                continue
            declared = rule.get('constraints', {}).get(semantic)
            try:
                if declared:
                    lo, hi = declared['min'], declared['max']
                else:
                    lo = cdf_numeric(row['min'], row['units'], semantic)
                    hi = cdf_numeric(row['max'], row['units'], semantic)
                if lo < 0 or hi < lo or hi <= 0:
                    raise ValueError('invalid CDF bounds')
                constraints[semantic] = {'min': lo, 'max': hi, 'grid': declared.get('grid', 0) if declared else 0,
                    'allowed': declared.get('allowed', []) if declared else []}
            except (ValueError, KeyError):
                if declared:
                    raise ValueError('invalid documented CDF bounds: ' + cell + '/' + parameter)
                # Missing range remains missing, never turn it into PDK data.
        source = str(Path(probe_path).resolve())
        dev = {'cell': cell, 'oa_library': library, 'model': identity.get('model_name', ''),
            'kind': kind, 'normalized_to_cdf': mapping, 'constraints': constraints,
            'source': source, 'cdf_source': source, 'terminalRoles': dict(zip(names, roles)),
            'missing': ['electrical_validation'], 'structural_only': True}
        if kind == 'resistor':
            try:
                value = numeric(resistance['default_value'])
                if value <= 0:
                    raise ValueError('nonpositive default')
                dev['default_resistance'] = value
            except ValueError:
                dev['missing'].append('literal_default_resistance')
        devices.append(dev)
    if not devices:
        raise ValueError('no proven structural MOS/resistor CDF declarations')
    digest = hashlib.sha256(json.dumps({'roots': roots, 'probe': Path(probe_path).read_text(), 'rules': rules}, sort_keys=True).encode()).hexdigest()
    return {'tech_name': pdk_name or Path(roots[0]).name, 'pdk_name': pdk_name or Path(roots[0]).name,
        'pdk_paths': roots, 'pdk_alias_paths': aliases, 'version': 'structure-sha256:' + digest,
        'source': str(Path(probe_path).resolve()), 'validation_scope': 'structure_only',
        'corners': [], 'temperatures': [], 'devices': devices, 'model_file_sha256': {},
        'rejected_devices': rejected, 'unreadable_model_files': [], 'non_target_devices': []}
