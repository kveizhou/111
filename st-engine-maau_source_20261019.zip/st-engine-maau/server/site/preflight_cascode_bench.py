#!/usr/bin/env python3
"""Export the actual saved Bench config for excitation review; do not run Spectre."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys

MAX_LINES = 180


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scalar(raw):
    # Accept only literal evidence, never evaluate SKILL forms or symbols.
    raw = raw.strip()
    if raw == 't': return True
    if raw == 'nil': return False
    value = json.loads(raw)
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        raise ValueError('unsupported non-scalar saved setting')
    if isinstance(value, float) and not math.isfinite(value): raise ValueError('nonfinite saved setting')
    return value


def select_settings(data, test, corner):
    if data.get('result') != 'READ_OK': raise ValueError('saved Maestro read is incomplete')
    index = {}
    for record in data['records']:
        key = (record['kind'], record['scope'], record['name'])
        if key in index or record['status'] != 'OK': raise ValueError('duplicate or unread saved setting')
        index[key] = record['raw_value']
    def get(kind, scope, name):
        if (kind, scope, name) not in index: raise ValueError('required saved setting is missing: ' + name)
        return scalar(index[kind, scope, name])
    enabled = [scope for kind, scope, name in index if kind == 'test' and name == 'enabled' and get(kind, scope, name) is True]
    if enabled != [test]: raise ValueError('exactly one enabled saved test must match --test')
    if get('test', test, 'test_name') != test: raise ValueError('saved test identity mismatch')
    if get('corner', corner, 'enabled') is not True: raise ValueError('selected Corner must be enabled')
    if get('test', test, 'simulator') != 'spectre': raise ValueError('selected saved simulator is not Spectre')
    if any(kind == 'global_variable' for kind, _, _ in index):
        raise ValueError('global variable precedence needs native resolution; preflight does not guess it')
    design = dict(zip(('lib', 'cell', 'view'), (get('test', test, 'design_' + k) for k in ('library', 'cell', 'view'))))
    if any(not isinstance(v, str) or not v or any(c in v for c in '/\t\r\n\0') for v in design.values()):
        raise ValueError('invalid saved test design identity')
    if design['view'] != 'schematic' and not design['view'].startswith('config'):
        raise ValueError('saved test view requires explicit support; no schematic fallback')
    variables = {}
    for kind, scope, name in index:
        if kind == 'test_variable' and scope == test:
            variables[name] = get(kind, scope, name)
    for kind, scope, name in index:
        if kind == 'corner_variable' and scope == corner and get('corner_variable_enabled', corner, name) is True:
            variables[name] = get(kind, scope, name)
    temperature = variables.pop('temperature', None)
    try: temperature = float(temperature)
    except (TypeError, ValueError): raise ValueError('selected Corner requires a single numeric temperature')
    if not math.isfinite(temperature) or temperature <= -273.15: raise ValueError('invalid temperature')
    for name, value in variables.items():
        if not re.fullmatch(r'[A-Za-z_][\w$]*', name) or isinstance(value, bool):
            raise ValueError('invalid design variable')
        if any(c in str(value) for c in '\t\r\n\0') or re.search(r'\S\s+\S', str(value)):
            raise ValueError('swept or unsupported variable expression: ' + name)
        variables[name] = str(value)
    models = []
    for kind, scope, name in index:
        if kind == 'corner_model_file' and scope == corner and get('corner_model_enabled', corner, name) is True:
            path = get(kind, scope, name)
            section = get('corner_model_section', corner, name)
            if not isinstance(path, str) or not isinstance(section, str): raise ValueError('model fields must be strings')
            # AXL returns a quoted section name inside its printed string.
            if section.startswith('"'): section = json.loads(section)
            if not isinstance(section, str) or not re.fullmatch(r'[A-Za-z_][\w.-]*', section):
                raise ValueError('model section requires a single literal name')
            model = Path(path)
            if not model.is_absolute() or not model.is_file(): raise ValueError('actual Corner model file unavailable')
            found = False
            with model.open(encoding='utf-8', errors='replace') as stream:
                for line in stream:
                    match = re.match(r'^\s*section\s+(\S+)', line)
                    if match and match[1] == section: found = True; break
            if not found: raise ValueError('selected section not declared in the actual model file: ' + section)
            record = dict(model_file=str(model), section_name=section, sha256=digest(model))
            if any((m['model_file'], m['section_name']) == (record['model_file'], section) for m in models):
                raise ValueError('duplicate enabled Corner model selection')
            models.append(record)
    if not models: raise ValueError('enabled Corner model selections are missing; no test-model fallback')
    return dict(test_name=test, corner=corner, design=design, temperature=temperature, variables=variables,
        models=models, model_precedence='enabled_corner_replaces_test_model_libraries',
        simulation_profile_ready=False, saved_simulation_options_imported=False, electrical_verified=False)


def check_binding(data, session):
    from site_data import read_json, verify_site_inputs
    selection = data['selection']
    if Path(selection['session']).resolve() != session or selection.get('read_only') is not True:
        raise ValueError('cached read belongs to a different source session')
    cfg_path = session / 'session.conf'
    if digest(cfg_path) != selection['session_config_sha256']: raise ValueError('source session changed since saved read')
    cfg = dict(line.split('=', 1) for line in cfg_path.read_text().splitlines() if '=' in line and not line.startswith('#'))
    cds = Path(cfg['cds_lib'])
    if cds.name != 'cds.lib' or not cds.is_absolute() or cds.resolve() != Path(selection['cds_lib']).resolve():
        raise ValueError('cached read registry differs from source session')
    if digest(cds) != selection['cds_lib_sha256']: raise ValueError('cds.lib changed since saved read')
    manifest = session / 'analysis/standalone_inputs/provider_inputs.json'
    inputs = read_json(manifest); verify_site_inputs(inputs)
    for k in ('library', 'cell', 'view'):
        if not cfg.get('source_' + k): raise ValueError('source OA identity is missing from session')
    if cfg['source_view'] != 'schematic': raise ValueError('source DUT must be the selected schematic')
    return cfg, cds, manifest, inputs


def export_script(settings, output, init):
    text = 'load(' + json.dumps(str(init)) + ')\n'
    text += 'envSetVal("asimenv.startup" "projectDir" \'string ' + json.dumps(str(output / 'generated')) + ')\n'
    text += 'simulator(\'spectre)\ndesign(' + ' '.join(json.dumps(settings['design'][k]) for k in ('lib', 'cell', 'view')) + ')\n'
    text += 'modelFile(' + ' '.join("'(" + json.dumps(m['model_file']) + ' ' + json.dumps(m['section_name']) + ')' for m in settings['models']) + ')\n'
    for name, value in settings['variables'].items(): text += 'desVar(' + json.dumps(name) + ' ' + json.dumps(value) + ')\n'
    text += 'temp(' + str(settings['temperature']) + ')\ncreateNetlist(?display nil)\n'
    return text


def run_ocean(script, work, timeout):
    from cadence_runtime import executable
    action = work/'runtime.ocn'; marker = work/'runtime.done'
    action.write_text('procedure(stPreflightAction()\n'+script+'\nt)\nresult=errset(stPreflightAction() t)\n'
        'when(and(result car(result))\np=outfile('+json.dumps(str(marker))+')\n'
        'fprintf(p "OK\\n")\nclose(p))\nexit()\n')
    with (work/'ocean.log').open('x') as log:
        result = subprocess.run([executable('ST_OCEAN_BIN','ocean'),'-nograph','-restore',str(action)],
            cwd=work, stdout=log, stderr=subprocess.STDOUT, timeout=timeout, check=False)
    if result.returncode or not marker.is_file() or marker.read_text().strip()!='OK':
        raise ValueError('OCEAN did not complete; raw log remains in ocean/ocean.log')


def analyze(text, core, settings):
    from op_provider import parse_deck
    deck = parse_deck(text)
    sources, paths, occurrences = [], [], 0
    def visit(instances, prefix, parents):
        nonlocal occurrences
        if len(parents) > 100: raise ValueError('hierarchy depth exceeds preflight bound')
        for inst in instances:
            occurrences += 1
            if occurrences > 100000: raise ValueError('hierarchy exceeds preflight bound')
            path = prefix + inst['name']; master = inst['master']
            if master == core: paths.append(path)
            if master in deck['definitions']:
                if master in parents: raise ValueError('recursive Bench hierarchy')
                visit(deck['definitions'][master]['instances'], path + '.', parents + [master])
            elif master in ('vsource', 'isource', 'bsource', 'vcvs', 'vccs', 'ccvs', 'cccs'):
                sources.append(dict(path=path, master=master, nodes=inst['nodes'], raw_parameters=inst['tail'].strip()))
    visit(deck['top'], '', [])
    if len(paths) != 1 or core not in deck['definitions']:
        raise ValueError('selected source core must have exactly one reachable netlisted reference; found ' + str(len(paths)))
    declared = set(deck['parameters'])
    if not set(settings['variables']).issubset(declared):
        raise ValueError('export did not declare every selected variable')
    # Keep the original excitation expressions, including pulse val0/val1.
    body = ['CORE_PATH=' + paths[0], 'CORE_DIRECT_INSTANCES=' + str(len(deck['definitions'][core]['instances'])),
        'SOURCE_COUNT=' + str(len(sources))]
    for source in sources:
        body.append('SOURCE path=' + source['path'] + ' master=' + source['master'] + ' nodes=' + ','.join(source['nodes']) +
                    ' parameters=' + source['raw_parameters'])
    for name in ('AVDD', 'DVDD', 'iout', 'IOUT', 'da_rst', 'da_en'):
        pattern = re.compile(r'(?<![\w$])' + re.escape(name) + r'(?![\w$])')
        used = [s['path'] for s in sources if pattern.search(s['raw_parameters'])]
        if name in settings['variables']: body.append('SOURCE_VARIABLE_USAGE ' + name + '=' + ','.join(used))
    for inst in deck['definitions'][core]['instances']:
        sizes = ' '.join(k + '=' + v for k, v in inst['params'].items() if k in ('l', 'w', 'fw', 'nfin', 'nf', 'fingers', 'm', 'mr'))
        if sizes: body.append('CORE_DEVICE instance=' + inst['name'] + ' netlist_master=' + inst['master'] + ' parameters=' + sizes)
    return body, dict(core_path=paths[0], sources=sources, direct_core_instances=deck['definitions'][core]['instances'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('session', 'maestro-read', 'test', 'corner', 'output'): parser.add_argument('--' + name, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--timeout', type=int, default=300)
    args = parser.parse_args(); output = None
    try:
        from site_data import read_json, verify_site_inputs
        from standalone import environment
        if args.timeout <= 0: raise ValueError('timeout must be positive')
        session = Path(args.session).resolve(); read = Path(args.maestro_read).resolve()
        destination = Path(args.output)
        if not destination.is_absolute() or destination.exists(): raise ValueError('output must be a new absolute directory')
        data = read_json(read); cfg, cds, manifest, inputs = check_binding(data, session)
        settings = select_settings(data, args.test, args.corner)
        selection = data['selection']; records = data['records']
        from read_maestro_setup import string_field
        for k, expected in (('library', selection['bench_library']), ('cell', selection['bench_cell']), ('view', selection['setup_view'])):
            if string_field(records, 'meta', 'setup', k) != expected: raise ValueError('cached setup identity mismatch')
        registered = Path(string_field(records, 'meta', 'setup', 'registered_library_path'))
        if not registered.is_absolute() or registered.resolve() != Path(selection['expected_library_path']).resolve():
            raise ValueError('cached registered library differs from actual repository selection')
        if (settings['design']['lib'], settings['design']['cell']) != (selection['bench_library'], selection['bench_cell']):
            raise ValueError('saved test uses a different Bench; explicit selection required')
        if not (registered / settings['design']['cell'] / settings['design']['view']).is_dir():
            raise ValueError('saved config/schematic directory is unavailable')
        fixed = {p: digest(p) for p in (read, session/'session.conf', cds, manifest)}
        destination.mkdir(parents=True, exist_ok=False); output = destination
        (output/'selected_corner.json').write_text(json.dumps(settings, ensure_ascii=False, indent=2)+'\n')
        env = environment(inputs, manifest); env.pop('ST_PREPARED_JSON_FILE', None)
        # This executable owns its environment; the parent shell/session is unchanged.
        os.environ.clear(); os.environ.update(env)
        script = export_script(settings, output, Path(inputs['init']).resolve())
        (output/'netlist_preview.ocn').write_text(script)
        if args.prepare_only:
            print('SETTINGS_PREPARED=true\nNATIVE_EXECUTION=false\nSIMULATION_PROFILE_READY=false\nELECTRICAL_VERIFIED=false')
            return 0
        work = output/'ocean'; work.mkdir()
        (work/'cds.lib').write_text('INCLUDE '+json.dumps(str(cds))+'\n')
        print('READ_CONFIG_NETLIST=START', flush=True)
        run_ocean(script, work, args.timeout)
        exports = list((output/'generated').rglob('input.scs'))
        if len(exports) != 1: raise ValueError('actual OCEAN input.scs missing or ambiguous')
        text = exports[0].read_text(); (output/'bench.scs').write_text(text)
        body, details = analyze(text, cfg['source_cell'], settings)
        verify_site_inputs(inputs)
        if any(digest(p) != value for p, value in fixed.items()): raise ValueError('fixed source or cached inputs changed while netlisting')
        if any(digest(m['model_file']) != m['sha256'] for m in settings['models']): raise ValueError('model file changed while netlisting')
        (output/'netlist_details.json').write_text(json.dumps(details, ensure_ascii=False, indent=2)+'\n')
        body = ['DESIGN=' + '/'.join(settings['design'][k] for k in ('lib','cell','view')),
                'TEST=' + args.test, 'CORNER=' + args.corner, 'TEMPERATURE=' + str(settings['temperature'])] + [
                    'VARIABLE ' + k + '=' + v for k,v in settings['variables'].items()] + [
                    'MODEL file=' + m['model_file'] + ' section=' + m['section_name'] for m in settings['models']] + body
        head = ['READ_CONFIG_NETLIST=COMPLETE', 'CHECKER=cascode-bench-preflight-v1', 'RESULT=NETLIST_READ_OK']
        tail = ['SIMULATION_PROFILE_READY=false', 'SAVED_SIMULATION_OPTIONS_IMPORTED=false', 'EXCITATION_REVIEW_REQUIRED=true',
                'ELECTRICAL_VERIFIED=false', 'VBIAS_GENERATED=false', 'RAW_DETAILS_REMAIN_ON_SERVER=true']
        budget = MAX_LINES - len(head) - len(tail) - 3
        chosen = body[:budget]
        shortened = any(len(v) > 1800 for v in chosen)
        rendered = head + [v if len(v)<=1800 else v[:1800]+' [DISPLAY_SHORTENED]' for v in chosen] + [
            'SUMMARY_TRUNCATED='+str(len(chosen)!=len(body) or shortened).lower(),
            'SUMMARY_OMITTED_LINES='+str(len(body)-len(chosen))] + tail
        (output/'summary.txt').write_text('\n'.join(rendered)+'\n')
        print('\n'.join(rendered)); return 0
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, RecursionError) as error:
        reason = ' '.join(str(error).split())[:1800]
        if output is not None: (output/'status.json').write_text(json.dumps(dict(result='INCOMPLETE', reason=reason))+'\n')
        print('cascode preflight: '+reason, file=sys.stderr)
        print('RESULT=INCOMPLETE\nELECTRICAL_VERIFIED=false\nVBIAS_GENERATED=false\nRAW_DETAILS_REMAIN_ON_SERVER=true')
        return 2


if __name__ == '__main__': sys.exit(main())
