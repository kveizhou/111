#!/usr/bin/env python3
"""Standalone Cadence command adapter. Uses OCEAN/Spectre, no Maau libraries."""
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from site_data import read_json, write_json
from pdk_discovery import helper_init


def executable(variable, default):
    requested = os.environ.get(variable, default)
    result = shutil.which(requested)
    if not result:
        raise ValueError('Cadence executable unavailable: ' + requested)
    return result


def ocean(script, directory, log):
    path = directory / 'runtime.ocn'
    marker = directory / 'runtime.done'
    if path.exists() or marker.exists():
        raise ValueError('runtime directory already used')
    path.write_text('procedure(stRuntimeAction()\n' + script + '\nt)\nresult=errset(stRuntimeAction() t)\n'
        + 'when(and(result car(result))\nout=outfile(' + json.dumps(str(marker))
        + ')\nfprintf(out "OK\\n")\nclose(out))\nexit()\n')
    with Path(log).open('w') as stream:
        status = subprocess.run([executable('ST_OCEAN_BIN', 'ocean'), '-nograph', '-restore', str(path)],
            cwd=directory, stdout=stream, stderr=subprocess.STDOUT, check=False)
    if status.returncode or not marker.is_file() or marker.read_text().strip() != 'OK':
        raise ValueError('OCEAN did not complete; inspect ' + str(log))


def wrap_dut(text, name, physical_ports, expected_ports, bench_variables=()):
    from op_provider import parse_deck, ASSIGN
    if len(set(physical_ports)) != len(physical_ports) or set(physical_ports) != set(expected_ports):
        raise ValueError('actual OA DUT/Bench port mismatch')
    deck = parse_deck(text)
    if name in deck['definitions']:
        if deck['definitions'][name]['ports'] != expected_ports:
            raise ValueError('actual exported DUT subckt port order mismatch')
        return text
    if not deck['top']:
        raise ValueError('no actual top-level DUT instances to wrap')
    indices = {inst['line'] for inst in deck['top']}
    body = [deck['lines'][i] for i in sorted(indices)]
    local_parameters = []
    # OCEAN inserts profile variables at the top of both exports. Those must
    # resolve in the Bench scope so later Corner changes reach the real DUT.
    # Actual DUT-only parameter declarations keep their local scope.
    for i, line in enumerate(deck['lines']):
        if line.strip().startswith('parameters ') and not any(d['start'] <= i <= d['end'] for d in deck['definitions'].values()):
            indices.add(i)
            values = [(key, value) for key, value in ASSIGN.findall(line) if key not in bench_variables]
            if values:
                local_parameters.append('parameters ' + ' '.join(key + '=' + value for key, value in values))
    retained = [line for i, line in enumerate(deck['lines']) if i not in indices]
    retained += ['subckt ' + name + ' ' + ' '.join(expected_ports)] + local_parameters + body + ['ends ' + name]
    return '\n'.join(retained) + '\n'


def netlist(args):
    work = Path(args.work_dir).resolve()
    work.mkdir(parents=True, exist_ok=True)
    project = Path(args.cds_path).resolve()
    (work / 'cds.lib').write_text('INCLUDE ' + json.dumps(str(project / 'cds.lib')) + '\n')
    ports = work / 'ports.txt'
    root = work / 'generated'
    profile = read_json(os.environ['ST_SIMULATION_PROFILE'])
    if args.view != 'schematic':
        raise ValueError('standalone netlisting currently requires a schematic Bench/DUT; declare an explicit schematic Bench')
    init = Path(helper_init())
    script = 'load(' + json.dumps(str(init.resolve())) + ')\n'
    script += 'envSetVal("asimenv.startup" "projectDir" \'string ' + json.dumps(str(root)) + ')\n'
    script += 'simulator(\'spectre)\ndesign(' + ' '.join(json.dumps(v) for v in (args.lib, args.cell, args.view)) + ')\n'
    first = profile['op_corners'][profile['nominal_corner']]
    script += 'modelFile(' + ' '.join("'(" + json.dumps(v['model_file']) + ' ' + json.dumps(v['section_name']) + ')' for v in first['models']) + ')\n'
    for key, value in first.get('variables', {}).items():
        script += 'desVar(' + json.dumps(key) + ' ' + json.dumps(str(value)) + ')\n'
    script += 'createNetlist(?display nil)\n'
    script += 'cv=dbOpenCellViewByType(' + ' '.join(json.dumps(v) for v in (args.lib, args.cell, args.view)) + ' "" "r")\n'
    script += 'unless(cv error("Cannot read actual DUT ports"))\np=outfile(' + json.dumps(str(ports)) + ')\n'
    script += 'foreach(term cv~>terminals fprintf(p "%s\\n" term~>name))\nclose(p)\ndbClose(cv)\n'
    ocean(script, work, work / 'ocean.log')
    exported = list(root.rglob('input.scs'))
    if len(exported) != 1:
        raise ValueError('actual OCEAN input.scs missing or ambiguous under ' + str(root))
    source = exported[0]
    text = source.read_text()
    if args.ports_from:
        from op_provider import parse_deck
        expected = parse_deck(Path(args.ports_from).read_text())['definitions'].get(args.source_subckt)
        if not expected:
            raise ValueError('physical Bench does not contain selected source DUT')
        bench_variables = {key for corner in profile['op_corners'].values() for key in corner.get('variables', {})}
        text = wrap_dut(text, args.cell, ports.read_text().splitlines(), expected['ports'], bench_variables)
    output = Path(args.output)
    if output.exists():
        raise ValueError('OA export output already exists')
    output.write_text(text)
    write_json(str(output) + '.origin.json', {'working_directory': str(source.parent), 'dc_test_name': ''})


def simulate(args):
    psf = Path(args.psf_dir)
    psf.mkdir(parents=True, exist_ok=False)
    with Path(args.log).open('w') as stream:
        status = subprocess.run([executable('ST_SPECTRE_BIN', 'spectre'), args.netlist, '+escchars',
            '-format', 'psfbin', '-raw', str(psf)], cwd=Path(args.netlist).parent,
            stdout=stream, stderr=subprocess.STDOUT, check=False)
    if status.returncode:
        raise ValueError('Spectre failed; inspect ' + args.log)
    if not (psf / 'dcOp.dc').is_file() or not (psf / 'dcOpInfo.info').is_file():
        return 71
    return 0


def read_psf(args):
    directory = Path(args.output).parent / 'psf_reader'
    directory.mkdir()
    raw = directory / 'values.tsv'
    # dcOp holds node voltages and terminal currents. dcOpInfo holds model OP.
    script = '''procedure(stRuntimeScalar(data)
  cond((numberp(data) data)
       (drIsWaveform(data)
         let((vec)
           vec=drGetWaveformYVec(data)
           unless(equal(drVectorLength(vec) 1) error("Expected a single DC point"))
           drGetElem(vec 0)))
       (t error("Unsupported non-scalar DC result")))
)
'''
    script += 'openResults(' + json.dumps(args.psf_dir) + ')\np=outfile(' + json.dumps(str(raw)) + ')\n'
    script += 'fprintf(p "signal\\tvalue\\n")\nselectResult(\'dcOp)\n'
    script += 'foreach(signal outputs() fprintf(p "%s\\t%.17g\\n" signal stRuntimeScalar(getData(signal))))\n'
    script += 'selectResult(\'dcOpInfo)\nforeach(kind dataTypes()\n'
    script += '  foreach(device outputs(?type kind)\n    foreach(parameter outputParams(kind)\n'
    script += '      fprintf(p "%s:%s\\t%.17g\\n" device parameter stRuntimeScalar(pv(device parameter)))\n)))\nclose(p)\n'
    ocean(script, directory, directory / 'ocean.log')
    values = {}
    with raw.open(newline='') as stream:
        for row in csv.DictReader(stream, delimiter='\t'):
            from site_data import finite
            value = finite(float(row['value']))
            if row['signal'] in values and values[row['signal']] != value:
                raise ValueError('conflicting signed PSF signal: ' + row['signal'])
            values[row['signal']] = value
    if not values:
        raise ValueError('empty actual raw PSF')
    with Path(args.output).open('x', newline='') as stream:
        writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
        writer.writerow(['signal', 'value'])
        writer.writerows((key, format(value, '.17g')) for key, value in sorted(values.items()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['netlist', 'simulate', 'read-psf'])
    for name in ('lib', 'cell', 'view', 'mode', 'cds-path', 'work-dir', 'output', 'netlist', 'psf-dir', 'log', 'ports-from', 'source-subckt'):
        parser.add_argument('--' + name, default='')
    args = parser.parse_args()
    try:
        if args.command == 'netlist': netlist(args)
        elif args.command == 'read-psf': read_psf(args)
        else: return simulate(args)
        return 0
    except (ValueError, OSError, KeyError) as error:
        print('standalone Cadence runtime: ' + str(error), file=sys.stderr)
        return 70


if __name__ == '__main__':
    sys.exit(main())
