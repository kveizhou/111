"""Resolve exact registered OA library paths from a read-only Cadence report."""
import csv
import os
from pathlib import Path
import subprocess

from site_data import write_json

ROOT = Path(__file__).resolve().parents[2]


def helper_init():
    path = Path(os.environ.get('ST_SKILL_INIT') or str(ROOT / 'server/skill/init.il'))
    if not path.is_absolute() or not path.is_file() or not os.access(path, os.R_OK):
        raise ValueError('ST_SKILL_INIT must be an absolute readable file; unset it to use the bundled helper')
    return str(path.resolve())


def read_discovery(report, source):
    with Path(report).open(newline='') as stream:
        rows = list(csv.DictReader(stream, delimiter='\t'))
    origins = [r for r in rows if r['role'] == 'source']
    technologies = [r for r in rows if r['role'] == 'technology']
    devices = [r for r in rows if r['role'] == 'device']
    if len(origins) != 1 or {k: origins[0][v] for k, v in
            [('lib', 'library'), ('cell', 'cell'), ('view', 'view')]} != source:
        raise ValueError('PDK discovery source does not match the selected CellView')
    if len(technologies) != 1 or not devices:
        raise ValueError('PDK discovery needs one attached technology and proven device libraries')
    technology = technologies[0]['library']
    if not technology or any(r['technology'] != technology for r in rows):
        raise ValueError('PDK discovery contains conflicting technology attachments')
    if len({r['library'] for r in devices}) != len(devices):
        raise ValueError('PDK discovery contains duplicate device libraries')
    if any(r['role'] not in ('source', 'technology', 'device') for r in rows):
        raise ValueError('unknown PDK discovery record')
    for row in rows:
        path = Path(row['path'])
        if not path.is_absolute() or not path.is_dir() or not os.access(path, os.R_OK):
            raise ValueError('registered OA library path is not an absolute readable directory: ' + row['path'])
    relevant = technologies + devices
    return {'source': source, 'technology_library': technology,
        'technology_path': technologies[0]['path'], 'device_libraries': devices,
        'pdk_paths': list(dict.fromkeys(str(Path(r['path']).resolve()) for r in relevant)),
        'pdk_alias_paths': list(dict.fromkeys(r['path'] for r in relevant)),
        'evidence': str(Path(report).resolve()),
        'method': 'source technology attachment and registered OA/CDF primitive libraries'}


def discover(backend, cds_lib, source, directory, env):
    directory = Path(directory)
    report = directory / 'discovery.tsv'
    status = subprocess.run([str(backend), 'discover-pdk', '--cds-lib', str(cds_lib),
        '--lib', source['lib'], '--cell', source['cell'], '--view', source['view'],
        '--output', str(report)], env=env, check=False)
    if status.returncode:
        raise ValueError('Cadence PDK discovery failed (exit ' + str(status.returncode) + '); retain the log')
    data = read_discovery(report, source)
    write_json(directory / 'pdk_discovery.json', data)
    libraries = directory / 'pdk_libraries.tsv'
    with libraries.open('x') as stream:
        writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
        writer.writerow(['library', 'path'])
        writer.writerows((r['library'], r['path']) for r in data['device_libraries'])
    print('源电路=' + '/'.join(source[k] for k in ('lib', 'cell', 'view')), flush=True)
    print('工艺库=' + data['technology_library'], flush=True)
    print('工艺库路径=' + data['technology_path'], flush=True)
    for row in data['device_libraries']:
        print('器件库=' + row['library'] + ' 路径=' + row['path'], flush=True)
    print('PDK_DISCOVERY_OK', flush=True)
    return data, libraries
