#!/usr/bin/env python3
"""Read actual CDF/OA terminal evidence for the master named in a failed scan."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
MARKER = 'ST_TERMINAL_DIAGNOSTIC_COMPLETE'
CONFLICT = re.compile(r'\*Error\* CDF Spectre termOrder/symbol terminal conflict for ([^/\s;]+)/([^\s;]+)')

ACTION = r'''load(getShellEnvVar("ST_SKILL_INIT"))
load(strcat(getShellEnvVar("ST_ENGINE_ROOT") "/server/skill/tech_adapter.il"))
procedure(stReadTerminalDiagnostic()
  let((library cell cdf master names symbolNames scannerNames propertyOrder
       mapping beforeOrder terminal name seen port)
    library=__LIBRARY__
    cell=__CELL__
    cdf=cdfGetBaseCellCDF(ddGetObj(library cell))
    unless(cdf error("Missing actual base CDF: %L/%L" library cell))
    beforeOrder=cdf->simInfo->spectre->termOrder
    master=dbOpenCellViewByType(library cell "symbol" "" "r")
    unless(master error("Cannot read actual symbol: %L/%L" library cell))
    foreach(terminal master~>terminals
      symbolNames=append1(symbolNames terminal~>name))
    propertyOrder=master~>stTerminalOrder
    scannerNames=stTechTerminalNames(master)
    cdf=cdfGetBaseCellCDF(ddGetObj(library cell))
    names=cdf->simInfo->spectre->termOrder
    mapping=cdf->simInfo->spectre->termMapping
    ; Capture ordinary values before closing the read-only CellView.
    dbClose(master)
    port=outfile(getShellEnvVar("ST_TERMINAL_DIAGNOSTIC_REPORT"))
    unless(port error("Cannot create terminal diagnostic report"))
    fprintf(port "MASTER=%L/%L/symbol\n" library cell)
    fprintf(port "CDF_TERM_ORDER_BEFORE_OPEN=%L\n" beforeOrder)
    fprintf(port "CDF_TERM_ORDER=%L\n" names)
    fprintf(port "OA_SYMBOL_TERMINALS=%L\n" symbolNames)
    fprintf(port "SYMBOL_ST_TERMINAL_ORDER=%L\n" propertyOrder)
    fprintf(port "SCANNER_SYMBOL_TERMINALS=%L\n" scannerNames)
    fprintf(port "CDF_TERM_MAPPING=%L\n" mapping)
    when(listp(names)
      foreach(name names
        fprintf(port "CDF_ELEMENT value=%L type=%L string=%L symbol=%L actual_OA_member=%L scanner_member=%L duplicate=%L\n"
          name type(name) stringp(name) symbolp(name)
          if(member(name symbolNames) then t else nil)
          if(member(name scannerNames) then t else nil)
          if(member(name seen) then t else nil))
        seen=cons(name seen)))
    fprintf(port "ST_TERMINAL_DIAGNOSTIC_COMPLETE\n")
    close(port)
    t
  )
)
errset(stReadTerminalDiagnostic() t)
exit()
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scan-log', required=True)
    parser.add_argument('--cds-lib', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    scan, cds, out = (Path(value).expanduser() for value in
                      (args.scan_log, args.cds_lib, args.output))
    if not scan.is_absolute() or not scan.is_file():
        raise ValueError('--scan-log must be an existing absolute file')
    if not cds.is_absolute() or not cds.is_file() or cds.name != 'cds.lib':
        raise ValueError('--cds-lib must be an existing absolute cds.lib')
    if not out.is_absolute():
        raise ValueError('--output must be a new absolute directory')
    masters = sorted(set(CONFLICT.findall(scan.read_text(encoding='utf-8', errors='replace'))))
    if len(masters) != 1:
        raise ValueError('no conflict master or multiple masters in log; need one actual failed scan')
    library, cell = masters[0]
    env = os.environ.copy()
    init = Path(env.get('ST_SKILL_INIT') or ROOT / 'server/skill/init.il')
    if not init.is_absolute() or not init.is_file():
        raise ValueError('SKILL init must be an existing absolute file: ' + str(init))
    project = ROOT
    out.mkdir(parents=True, exist_ok=False)
    action = out / 'terminal_diagnostic.il'
    action.write_text(ACTION.replace('__LIBRARY__', json.dumps(library, ensure_ascii=False))
        .replace('__CELL__', json.dumps(cell, ensure_ascii=False)), encoding='utf-8')
    print('master={}/{}/symbol'.format(library, cell), flush=True)
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return 0
    executable = shutil.which(env.get('ST_VIRTUOSO_BIN') or 'virtuoso')
    if not executable:
        raise ValueError('Virtuoso executable unavailable; retained ' + str(out))
    report = out / 'terminal_report.txt'
    log = out / 'virtuoso.log'
    env.update(ST_ENGINE_ROOT=str(project), ST_SKILL_INIT=str(init),
               ST_TERMINAL_DIAGNOSTIC_REPORT=str(report))
    with log.open('w', encoding='utf-8') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action),
            '-log', str(out / 'cadence.log')], cwd=str(cds.parent), env=env,
            stdout=stream, stderr=subprocess.STDOUT)
    text = report.read_text(encoding='utf-8') if report.is_file() else ''
    if result.returncode or MARKER not in text.splitlines():
        print(log.read_text(encoding='utf-8', errors='replace'))
        cadence = out / 'cadence.log'
        if cadence.is_file():
            print(cadence.read_text(encoding='utf-8', errors='replace'))
        print('STOP: terminal diagnostic failed; retained ' + str(out))
        return result.returncode if 0 < result.returncode < 126 else 70
    print(text, end='')
    print('TERMINAL_DIAGNOSTIC_READ_OK; this is evidence only, not scan/generation approval')
    print('证据目录=' + str(out))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
