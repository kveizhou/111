#!/usr/bin/env python3
"""Convert strict JSON to a data-only SKILL expression before launching Cadence."""
import argparse
from pathlib import Path
import sys
from site_data import read_json, skill


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        source = Path(args.input).resolve()
        data = read_json(source)
        if not isinstance(data, dict):
            raise ValueError('OA plan must be a JSON object')
        # Bind to the exact argument used by this action. The /var and
        # /private/var aliases (or a server storage symlink) need not agree
        # between Python's resolve() and Cadence's filename simplification.
        output = 'stPreparedJsonPath = ' + skill(args.input) + '\nstPreparedJsonData = ' + skill(data) + '\n'
        with Path(args.output).open('x', encoding='utf-8') as stream:
            stream.write(output)
        return 0
    except (ValueError, OSError) as error:
        print('prepare SKILL plan: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__': sys.exit(main())
