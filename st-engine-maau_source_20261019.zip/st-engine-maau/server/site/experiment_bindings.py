"""Bind the small experiment device set from native OA and saved PSF evidence.

No simulator run, source save, model-source scan or implicit polarity inference.
"""
import hashlib
import json
import math
from pathlib import Path
import re
import shutil

from site_data import read_json, write_json


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def value(records, kind, scope, name):
    matches = [r for r in records if (r['kind'], r['scope'], r['name']) == (kind, scope, name)]
    if len(matches) != 1 or matches[0]['status'] != 'OK':
        raise ValueError('missing/ambiguous native field: '+scope+'/'+kind+'/'+name)
    text = matches[0]['raw_value'].strip()
    try:
        return json.loads(text)
    except ValueError:
        return text


def polarity(raw, text=''):
    """CMG TYPE has a documented 1=N, 0=P encoding; other enums are unknown.

    https://bsim.gitbooks.io/bsimcmg/content/Ch7.2.html
    Require the native model report to identify bsimcmg and agree with pv().
    """
    choices = {'n':'mos_n', 'nmos':'mos_n', 'p':'mos_p', 'pmos':'mos_p'}
    direct = choices.get(str(raw).strip().lower())
    labels = {choices[m.lower()] for m in re.findall(
        r'(?im)^\s*type\s*(?:[=:]\s*|\s+)(nmos|pmos|n|p)\s*$', text)}
    if direct:
        labels.add(direct)
    if isinstance(raw, bool):
        raise ValueError('boolean is not a native model type')
    if not direct and str(raw).strip() in ('0','1','0.0','1.0'):
        families = re.findall(r'(?im)^\s*Type\s*:\s*(\w+)\s*$',text)
        encoded = re.findall(r'(?im)^\s*type\s*=\s*([01](?:\.0)?)\s*$',text)
        if families != ['bsimcmg'] and labels:
            pass  # An explicit textual type already provides the meaning.
        elif families != ['bsimcmg'] or (not encoded and not labels) or any(float(x)!=float(raw) for x in encoded):
            raise ValueError('numeric model type lacks a matching bsimcmg report')
        else:
            labels.add('mos_n' if float(raw)==1 else 'mos_p')
    if len(labels) != 1:
        raise ValueError('native model type is missing, numeric-only or conflicting')
    return labels.pop()


def direct_current_mapping(raw):
    # Spectre CDF disembodied property-list values may be a string or \:symbol.
    text = str(raw).strip().replace('\\:', ':')
    if not re.fullmatch(r':[A-Za-z0-9_]+', text):
        raise ValueError('positive current CDF mapping is not a direct terminal: '+text)
    return text[1:]


def terminal_order(raw):
    if not isinstance(raw,str) or not raw.startswith('(') or not raw.endswith(')'):
        raise ValueError('flat actual CDF terminal order missing')
    atom = r'"(?:\\.|[^"\\])*"|[^\s()"]+'
    if re.sub(atom,'',raw[1:-1]).strip():
        raise ValueError('nested/non-literal CDF terminal order')
    return [json.loads(x) if x.startswith('"') else x for x in re.findall(atom,raw[1:-1])]


def native_script(bundle, request, pdk, psf, output):
    q = json.dumps
    resistors = [m for m in pdk['catalog'] if m.get('kind') == 'resistor']
    # A bounded preference among already used masters; no PDK search/ranking.
    order = {'rhrpo_2t_ckt':0, 'rhrpo_3t_ckt':1}
    resistors.sort(key=lambda m:(order.get(m['oa_cell'],2),m['oa_library'],m['oa_cell']))
    candidates = []
    for m in resistors:
        names, roles = m['terminal_names'].split(','), m['terminal_roles'].split(',')
        if len(names) != len(roles) or roles.count('positive') != 1:
            continue
        candidates.append('list('+ ' '.join(q(x) for x in
            (m['oa_library'], m['oa_cell'], names[roles.index('positive')])) +')')
    code = r'''load(getShellEnvVar("ST_SKILL_INIT"))
procedure(stBindRecord(port kind scope name result)
  if(result then
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tOK\t%L\n" kind scope name car(result))
  else
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tREAD_ERROR\tnil\n" kind scope name))
)
procedure(stBindCdf(port inst)
  let((cdf param term spectre key)
    stBindRecord(port "source" inst~>name "oa_library" list(inst~>master~>libName))
    stBindRecord(port "source" inst~>name "oa_cell" list(inst~>master~>cellName))
    stBindRecord(port "source" inst~>name "oa_view" list(inst~>master~>viewName))
    cdf=cdfGetInstCDF(inst)
    unless(cdf error("Actual instance CDF missing: %L" inst~>name))
    foreach(param cdf->parameters
      stBindRecord(port "cdf_value" inst~>name param->name list(param->value)))
    foreach(term inst~>instTerms
      stBindRecord(port "terminal" inst~>name term~>term~>name list(term~>net~>name)))
    spectre=cdf->simInfo->spectre
    foreach(key list("termOrder" "termMapping" "instParameters" "propMapping")
      stBindRecord(port "cdf_mapping" inst~>name key errset(get(spectre concat(key)) t)))
    cdf
  )
)
procedure(stBindName(text)
  let((name)
    name=""
    foreach(part parseString(text "./\\")
      name=strcat(name if(equal(name "") then "" else ".") part))
    name
  )
)
let((port cv result inst candidate chosen chosenMaster cdf modelPair model rawType)
  result=errset(prog( ()
    port=outfile(__REPORT__)
    unless(port error("Cannot create binding evidence"))
    cv=dbOpenCellViewByType(__LIB__ __CELL__ __VIEW__ "" "r")
    unless(cv error("Cannot read original source CellView"))
    __TARGET_CDF__
    foreach(candidate list(__RESISTORS__)
      unless(chosen
        foreach(inst cv~>instances
          when(and(equal(inst~>master~>libName car(candidate))
                   equal(inst~>master~>cellName cadr(candidate))
                   or(not(chosen) alphalessp(inst~>name chosen~>name)))
            chosen=inst chosenMaster=candidate))))
    when(chosen
      cdf=stBindCdf(port chosen)
      stBindRecord(port "selection" "resistor" "instance" list(chosen~>name))
      stBindRecord(port "positive_current" chosen~>name "mapping"
        errset(get(cdf->simInfo->spectre->termMapping concat(caddr(chosenMaster))) t)))
    dbClose(cv) cv=nil
    openResults(__PSF__)
    selectResult('dcOpInfo)
    __MODEL_READ__
    fprintf(port "ST_MAESTRO_SETUP_READ_COMPLETE\n") close(port) port=nil
    return(t)
  ) t)
  when(cv dbClose(cv))
  when(port close(port))
  unless(and(result car(result)) printf("ST_EXPERIMENT_BIND_NATIVE_FAILED\n"))
)
exit()
'''
    calls, models = [], []
    for name, item in sorted(pdk['targets'].items()):
        master = item['master']
        calls.append('inst=nil\nforeach(candidate cv~>instances when(equal(candidate~>name '+q(name)+') inst=candidate))\n'
            'unless(and(inst equal(inst~>master~>libName '+q(master['oa_library'])+') '
            'equal(inst~>master~>cellName '+q(master['oa_cell'])+')) error("Target master changed"))\n'
            'stBindCdf(port inst)')
        path = request['targets'][name]['path']
        models.append('modelPair=errset(ocnGetInstancesModelName('+q(path)+') t)\n'
            'stBindRecord(port "model_binding" '+q(name)+' "instance_model" modelPair)\n'
            'when(and(modelPair listp(car(modelPair)) stringp(caar(modelPair)) equal(stBindName(caar(modelPair)) '+q(path)+') '
            'stringp(cadar(modelPair)))\n'
            '  model=cadar(modelPair)\n'
            '  stBindRecord(port "model_type" '+q(name)+' "type" errset(pv(model "type" ?result \'model) t))\n'
            '  selectResult(\'model)\n'
            '  errset(report(?name model ?param "type" ?output '+q(str(output/(name+'_model_type.txt')))+') t)\n'
            '  selectResult(\'dcOpInfo))')
    replacements = dict(REPORT=str(output/'native.tsv'), LIB=bundle['source']['lib'],
        CELL=bundle['source']['cell'], VIEW=bundle['source']['view'], PSF=str(psf))
    for key, text in replacements.items():
        code = code.replace('__'+key+'__', q(text))
    return code.replace('__TARGET_CDF__','\n'.join(calls)).replace('__MODEL_READ__','\n'.join(models)).replace('__RESISTORS__',' '.join(candidates))


def cached_binding_context(bridge, bundle):
    from inspect_cascode_pdk_evidence import latest
    from runtime_bridge import reader_evidence_hashes
    state = read_json(bridge/'bridge_status.json')
    root = Path(state.get('reader_cache_dir') or bridge).resolve()
    if root.parent != bridge.parent.resolve() or not root.name.startswith('runtime_bridge_'):
        raise ValueError('formal reader source outside accepted baseline')
    if state.get('reader_cache_sha256') != reader_evidence_hashes(root):
        raise ValueError('formal reader evidence changed')
    sources = read_json(root/'raw_signed.tsv.sources.json')
    nodes = latest(bridge.parent.glob('node_context_*/node_context.json'))
    report = read_json(nodes)
    request_path = nodes.parent/'node_request.json'
    request = read_json(request_path)
    complete=bool(request.get('targets')) and all(
        set(report.get('targets',{}).get(name,{}).get('terminal_voltages',{}))=={'D','G','S','B'} and
        all(isinstance(v,(int,float)) and math.isfinite(v) for v in report['targets'][name]['terminal_voltages'].values())
        for name in request.get('targets',{}))
    if request.get('core_path') != bundle.get('root_path') or not complete or report.get('target_nodes_complete') is False:
        raise ValueError('target nodes not bound to accepted source')
    bench = Path(bundle['bench_netlist'])
    if digest(bench) != bundle['bench_sha256']:
        raise ValueError('accepted source bench changed')
    from read_cascode_solver_settings import resolve_instance_nodes
    from op_provider import parse_deck
    from op_provider import read_raw
    text = bench.read_text(); deck = parse_deck(text)
    core = resolve_instance_nodes(text,bundle['root_path'])
    ports = dict(zip(deck['definitions'][core['master']]['ports'],core['nodes']))
    if ports != request['core_ports']:
        raise ValueError('cached core ports differ from accepted netlist')
    raw = read_raw(root/'raw_signed.tsv')
    for name,target in request['targets'].items():
        device = resolve_instance_nodes(text,bundle['root_path']+'.'+name)
        if target['path'] != device['path'] or target['master'] != device['master']:
            raise ValueError('target identity differs from accepted netlist')
        for term,net in target['terminals'].items():
            if (net not in device['nodes'] or report['targets'][name]['terminal_nodes'].get(term)!=net or
                    raw.get(net)!=report['targets'][name]['terminal_voltages'].get(term)):
                raise ValueError('target node data differ from accepted reader')
    for port in ('AVDD','AGND'):
        if port not in ports:
            continue  # The binder reports an unresolved rail; no alias is guessed.
        item=report['core_ports'].get(port,{})
        if item.get('node') != ports.get(port) or item.get('value') is None or raw.get(item['node']) != item['value']:
            raise ValueError('rail value differs from accepted reader: '+port)
    fingerprints={str(p):digest(p) for p in (nodes,request_path,bench)}
    fingerprints.update({str(root/name):h for name,h in reader_evidence_hashes(root).items()})
    return request, report, sources, fingerprints


def fill_facts(pdk, rules, profile, request, node, origins, records, output):
    """Fill facts only when each physical binding has explicit matching evidence."""
    from dc_results import canonical_device
    pending, bound = [], []
    core_ports = node['core_ports']
    high, low = core_ports.get('AVDD'), core_ports.get('AGND')
    rails = bool(high and low and high.get('node') != low.get('node') and
        all(isinstance(x.get('value'),(int,float)) and math.isfinite(x['value']) for x in (high,low)) and high['value'] > low['value'])
    if rails:
        profile.update(vbias_vhigh_net='AVDD', vbias_vlow_net='AGND')
        bound.append('VBIAS_RAILS=AVDD/AGND')
    else:
        pending.append('core_AVDD_AGND_binding')
    for name, item in sorted(pdk['targets'].items()):
        key = item['master']['oa_library']+'/'+item['master']['oa_cell']
        rule = rules['devices'][key]
        try:
            for field in ('oa_library','oa_cell'):
                if value(records,'source',name,field) != item['master'][field]:
                    raise ValueError('actual OA master differs')
            if value(records,'cdf_value',name,'model') != item['master']['model_name']:
                raise ValueError('actual CDF model differs')
            target = request['targets'][name]
            # The full canonical target and model association are native output,
            # never a model name guessed from a CDF prefix.
            pair = value(records,'model_binding',name,'instance_model')
            tokens = re.findall(r'"(?:\\.|[^"\\])*"', str(pair))
            if len(tokens) != 2 or canonical_device(json.loads(tokens[0])) != target['path'] or not json.loads(tokens[1]):
                raise ValueError('exact native instance/model binding missing')
            type_file = output/(name+'_model_type.txt')
            raw = value(records,'model_type',name,'type')
            model_report = type_file.read_text() if type_file.is_file() else ''
            if model_report and json.loads(tokens[1]) not in [line.strip() for line in model_report.splitlines()]:
                raise ValueError('model type report belongs to a different native model')
            kind = polarity(raw, model_report)
            if rule.get('kind') and rule['kind'] != kind:
                raise ValueError('native model polarity conflicts with prior rule')
            rule['kind'] = kind
            if terminal_order(value(records,'cdf_mapping',name,'termOrder')) != item['master']['terminal_names'].split(','):
                raise ValueError('native MOS terminal order changed')
            rail = low if kind == 'mos_n' else high
            port = 'AGND' if kind == 'mos_n' else 'AVDD'
            local_bulk = value(records,'terminal',name,'B')
            # core_ports is checked against the accepted hierarchical netlist
            # in cached_binding_context. Equal voltage alone is not an alias.
            ports = request.get('core_ports',{})
            if (not rails or not isinstance(local_bulk,str) or
                    ports.get(local_bulk) != rail['node'] or ports.get(port) != rail['node'] or
                    target['terminals']['B'] != rail['node']):
                raise ValueError('existing Bulk does not match template rail: '+str(local_bulk)+' -> '+port)
            rule['bulkRule'] = 'rail'
            rule['bulk_binding'] = dict(oa_port=local_bulk,template_port=port,resolved_node=rail['node'],
                method='accepted_core_port_mapping')
            mapping = dict(id='id',vth='vth',vdsat='vdssat',cgg='cgg',
                intrinsic_vgs='vgs',intrinsic_vds='vds')
            for param in mapping.values():
                source = origins['sources'].get(target['path']+':'+param, {})
                if (source.get('device_type') != 'bsimcmg' or source.get('parameter') != param or
                        source.get('result') != 'dcOpInfo' or canonical_device(source.get('signal','')) != target['path']):
                    raise ValueError('CMG parameter source missing: '+param)
            rule.update(dc_signals=mapping, signal_postfix='')
            bound.append('MOS '+name+' kind='+kind+' bulk='+local_bulk+' template_bulk='+port+
                ' resolved_bulk_net='+rail['node']+' geometry='+json.dumps(rule['normalized_to_cdf'],sort_keys=True))
        except (ValueError,KeyError,TypeError) as error:
            pending.append(name+': '+str(error))
    try:
        name = value(records,'selection','resistor','instance')
        library = value(records,'source',name,'oa_library'); cell = value(records,'source',name,'oa_cell')
        masters = [m for m in pdk['catalog'] if m.get('kind') == 'resistor' and (m['oa_library'],m['oa_cell'])==(library,cell)]
        if len(masters) != 1:
            raise ValueError('selected actual resistor is not uniquely catalogued')
        m = masters[0]
        if value(records,'cdf_value',name,'model') != m['model_name']:
            raise ValueError('actual resistor CDF model differs')
        suffix = direct_current_mapping(value(records,'positive_current',name,'mapping'))
        names, roles = m['terminal_names'].split(','), m['terminal_roles'].split(',')
        if len(names) != len(roles) or len(names) not in (2,3):
            raise ValueError('resistor terminals missing')
        if terminal_order(value(records,'cdf_mapping',name,'termOrder')) != names:
            raise ValueError('actual resistor terminal order differs from cached probe')
        if 'substrate' in roles and value(records,'terminal',name,names[roles.index('substrate')]) != 'AGND':
            raise ValueError('resistor substrate is not the existing AGND rail')
        actual = {r['name'] for r in records if r['kind']=='cdf_value' and r['scope']==name and r['status']=='OK'}
        mapping = {s:p for s,p in (('resistance','r'),('multiplier','m')) if p in actual}
        if 'resistance' not in mapping:
            raise ValueError('actual resistance CDF value missing')
        key = library+'/'+cell
        # Retain any known resistor facts; do not erase prior known ratings.
        metadata = [d for c in pdk.get('metadata',[]) for d in c.get('devices',[])
                    if d.get('oa_library')==library and d.get('cell')==cell]
        if len(metadata)>1:
            raise ValueError('resistor metadata is ambiguous')
        rule = dict(metadata[0].get('electrical_rules',{})) if len(metadata)==1 else {}
        if metadata:
            for field in ('constraints','resistor_ratings','voltageDomains','sim_cdf'):
                if field in metadata[0]:rule[field]=metadata[0][field]
        if rule.get('dc_signals',{}).get('current') not in (None,suffix):
            raise ValueError('known resistor current mapping conflicts with native CDF')
        rule.update(kind='resistor',model=m['model_name'],normalized_to_cdf=mapping,
            terminalRoles=dict(zip(names,roles)),dc_signals={'current':suffix},signal_postfix='')
        rules['devices'][key] = rule
        profile['experimental_parameter_seeds'][key] = dict(instance=name,native_records=str(output/'native_records.json'),
            native_records_sha256=digest(output/'native_records.json'),trials={})
        bound.append('RESISTOR '+name+' master='+key+' current=:'+suffix)
    except (ValueError,KeyError,TypeError) as error:
        pending.append('resistor: '+str(error))
    return pending, bound


def resistor_seed_context(bundle, records):
    """A seed contributes its model/parameters, not its old circuit position.

    Keep the old terminal pairs as diagnostics. New template connectivity is
    checked by the existing candidate CDF/netlist/readback gates downstream.
    """
    from op_provider import parse_deck
    name = value(records,'selection','resistor','instance')
    deck = parse_deck(Path(bundle['bench_netlist']).read_text())
    selected = [i for i in deck['definitions'][bundle['source_subckt']]['instances'] if i['name']==name]
    if len(selected)!=1 or selected[0]['master'] != value(records,'cdf_value',name,'model'):
        raise ValueError('actual resistor seed instance/model not bound to accepted source netlist')
    order = terminal_order(value(records,'cdf_mapping',name,'termOrder'))
    if len(order)!=len(selected[0]['nodes']):
        raise ValueError('actual resistor seed terminal count differs from accepted netlist')
    pairs = [dict(terminal=t,oa_net=value(records,'terminal',name,t),baseline_net=n)
             for t,n in zip(order,selected[0]['nodes'])]
    return dict(instance=name,model=selected[0]['master'],usage='model_and_parameter_seed',
        terminal_pairs=pairs,original_connections_match=all(p['oa_net']==p['baseline_net'] for p in pairs),
        candidate_connectivity_verified=False)


def reuse_native_evidence(previous, output, bridge, expected_inputs):
    """Consume complete same-baseline data; never fall back to an EDA launch."""
    from read_maestro_setup import read_records
    previous=Path(previous).resolve()
    if previous.parent!=bridge.parent.resolve() or not previous.name.startswith('experiment_inputs_'):
        raise ValueError('native evidence outside accepted baseline')
    saved=read_json(previous/'binding_evidence.json')
    if saved.get('accepted_bridge')!=str(bridge) or saved.get('validation_scope')!='experimental_dc':
        raise ValueError('native evidence baseline/scope differs')
    fingerprints=saved.get('source_cache_sha256',{})
    if not expected_inputs or any(fingerprints.get(p)!=h for p,h in expected_inputs.items()):
        raise ValueError('native evidence input identity differs')
    if any(digest(p)!=h for p,h in fingerprints.items()):
        raise ValueError('native evidence input changed')
    recorded=saved.get('native_evidence_sha256')
    if recorded:
        if any(digest(p)!=h for p,h in recorded.items()):
            raise ValueError('native evidence files changed')
    elif not (saved.get('native_executions')==1 and
              saved.get('native_error')=='actual resistor connectivity differs from accepted netlist'):
        raise ValueError('legacy evidence is not the completed v1 resistor-binding read')
    records=read_records((previous/'native.tsv').read_text())
    if records!=read_json(previous/'native_records.json'):
        raise ValueError('native TSV and JSON records differ')
    paths=[previous/'native.tsv',previous/'native_records.json']
    paths += sorted(previous.glob('*_model_type.txt'))
    paths += [previous/p for p in ('binding.ocn','ocean.log') if (previous/p).is_file()]
    for path in paths:shutil.copyfile(path,output/path.name)
    return records


def bind(output, session, batch, bridge, bundle, pdk, profile, rules, report, timeout, reuse_dir=None):
    from collect_cascode_batch import command, executable
    from read_maestro_setup import read_records
    from standalone import environment
    from experimental_pdk import build_experimental_metadata
    pending, bound, executions, native_error = [], [], 0, None
    print('EXPERIMENT_BINDING=START',flush=True)
    try:
        request, node, origins, fingerprints = cached_binding_context(bridge,bundle)
        fingerprints.update(report['source_cache_sha256'])
        manifest_path = session/'analysis/standalone_inputs/provider_inputs.json'
        manifest = read_json(manifest_path)
        for key in ('context','rules','tech','init'):
            if manifest.get(key):
                path = Path(manifest[key]).resolve()
                if manifest.get('file_sha256',{}).get(str(path)) != digest(path):
                    raise ValueError('pinned native input changed: '+key)
                fingerprints[str(path)] = digest(path)
        if reuse_dir is not None:
            records=reuse_native_evidence(reuse_dir,output,bridge,report['source_cache_sha256'])
            report.update(native_evidence_reused=True,native_evidence_origin=str(reuse_dir),psf_read=False)
        else:
            env = environment(manifest,manifest_path); env.pop('ST_PREPARED_JSON_FILE',None)
            info = list((bridge.parent/'baseline_results').rglob('dcOpInfo.info'))
            if len(info) != 1:
                raise ValueError('unique saved baseline PSF missing')
            psf = info[0].parent
            # Only filesystem stat identity here: no multi-minute full PSF rehash.
            def psf_stat():
                return {str(p):[p.stat().st_size,p.stat().st_mtime_ns] for p in psf.rglob('*') if p.is_file()}
            before = psf_stat()
            (output/'cds.lib').write_text('INCLUDE '+json.dumps(bundle['cds_lib'])+'\n')
            action = output/'binding.ocn'; action.write_text(native_script(bundle,request,pdk,psf,output))
            executable_path = executable(env,'ST_OCEAN_BIN','ocean')
            executions = 1
            try:
                command([executable_path,'-nograph','-restore',str(action)],output,env,timeout,output/'ocean.log')
            finally:
                if before != psf_stat():
                    raise ValueError('saved PSF size/mtime changed during read')
                if any(digest(p)!=h for p,h in fingerprints.items()):
                    raise ValueError('bound input changed during native read')
            records = read_records((output/'native.tsv').read_text())
            write_json(output/'native_records.json',records)
            report.update(native_evidence_reused=False,psf_stat_unchanged=True,psf_read=True)
        report.update(binding_version=3,native_executions=executions,source_cache_sha256=fingerprints,
            psf_content_rehashed=False,native_evidence_sha256={str(p):digest(p) for p in output.iterdir()
                if p.name in ('native.tsv','native_records.json','binding.ocn','ocean.log') or p.name.endswith('_model_type.txt')})
        old = read_json(batch/'native_records.json')
        # Preserve the actual baseline parameter point when re-reading targets.
        for row in old:
            if row['kind']=='cdf_value' and row['scope'] in pdk['targets'] and row['status']=='OK':
                if value(records,'cdf_value',row['scope'],row['name']) != value(old,'cdf_value',row['scope'],row['name']):
                    raise ValueError('source target CDF changed since baseline: '+row['scope']+'/'+row['name'])
        for seed in profile['experimental_parameter_seeds'].values():
            seed.update(native_records=str(output/'native_records.json'),native_records_sha256=digest(output/'native_records.json'))
        pending,bound = fill_facts(pdk,rules,profile,request,node,origins,records,output)
        try:
            report['resistor_seed_context']=resistor_seed_context(bundle,records)
        except (ValueError,KeyError,TypeError) as error:
            pending.append('resistor seed: '+str(error))
        rules['source'] = str(output/'binding_evidence.json')
        report.update(native_executions=executions,source_cache_sha256=fingerprints,
            bound=bound,required_bindings=pending)
        write_json(output/'binding_evidence.json',report)
        if not pending:
            probe=Path(profile['experimental_pdk_cache']['probe'])
            metadata=build_experimental_metadata(profile['experimental_pdk_cache']['pdk_roots'],probe,profile,rules)
            write_json(output/'experimental_metadata.preview.json',metadata)
    except (ValueError,OSError,KeyError,TypeError) as error:
        native_error=str(error); pending.append(native_error)
    ready=not pending
    report.update(bound=bound,required_bindings=pending,native_executions=executions,
        experiment_inputs_ready=ready,input_draft_only=not ready,native_error=native_error)
    write_json(output/'binding_evidence.json',report)
    write_json(output/('simulation_profile.json' if ready else 'simulation_profile.bound-draft.json'),profile)
    write_json(output/('pdk_facts.json' if ready else 'pdk_facts.bound-draft.json'),rules)
    lines=['CHECKER=cascode-experiment-binding-v3','RESULT='+('EXPERIMENT_INPUTS_BOUND' if ready else 'BINDINGS_INCOMPLETE'),
        'OUTPUT_DIR='+str(output),'SPECTRE_RERUN=false','SOURCE_OA_SAVED=false','PDK_SOURCE_SEARCH=false',
        'NATIVE_EXECUTIONS='+str(executions),'NATIVE_EVIDENCE_REUSED='+str(report.get('native_evidence_reused',False)).lower(),
        'EXPERIMENT_INPUTS_READY='+str(ready).lower()]
    lines += ['BOUND '+line for line in bound]
    lines += ['PENDING '+line for line in pending]
    if report.get('resistor_seed_context'):
        lines.append('RESISTOR_SEED_CONTEXT '+json.dumps(report['resistor_seed_context'],sort_keys=True))
    if (output/'ocean.log').is_file() and pending:
        prefix='REUSED_NATIVE_LOG ' if report.get('native_evidence_reused') else 'NATIVE_LOG '
        lines += [prefix+line[:500] for line in (output/'ocean.log').read_text(errors='replace').splitlines()[-8:]]
    if pending and (output/'native_records.json').is_file():
        records=read_json(output/'native_records.json')
        for name in sorted(pdk['targets']):
            try:lines.append('MODEL_TYPE_RAW '+name+' '+str(value(records,'model_type',name,'type')))
            except ValueError:pass
            path=output/(name+'_model_type.txt')
            if path.is_file():lines.extend('MODEL_TYPE_REPORT '+name+' '+line[:300] for line in path.read_text().splitlines()[:8])
    lines += ['RELIABILITY_VERIFIED=false','READY_FOR_SIZING=false','VBIAS_GENERATED=false',
        'DETAILS_FILE='+str(output/'binding_evidence.json')]
    (output/'summary.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
    return 0 if ready else 2
