#!/usr/bin/env python3
"""Prepare one fixed Source-resistor + shared-gate Stack editing workflow."""
import argparse
import csv
import json
import math
from pathlib import Path
import sys

from site_data import read_json, verify_site_inputs


def choose_operations(inventory, metadata):
    targets = sorted({r['instance'] for r in inventory if r.get('instance') and
        not any(c in r['instance'] for c in '<>:\t\r\n=')})
    if len(targets) < 2:
        raise ValueError('fixed workflow needs two scalar MOS in the selected current layer')
    candidates = sorted((d for d in metadata['devices'] if d['kind'] == 'resistor' and
        sorted(d.get('terminalRoles', {}).values()) == ['negative', 'positive']),
        key=lambda d: (d['oa_library'], d['cell']))
    for device in candidates:
        bounds = device['constraints'].get('resistance')
        seed = device.get('default_resistance')
        if bounds:
            lo, hi = bounds['min'], bounds['max']
            allowed = sorted(bounds.get('allowed', []))
            grid = bounds.get('grid', 0)
            seed = seed if seed is not None and lo <= seed <= hi else (math.sqrt(lo * hi) if lo > 0 else hi / 2)
            if allowed:
                seed = min(allowed, key=lambda v: (abs(v - seed), v))
                alternatives = [v for v in allowed if v != seed]
            else:
                if grid:
                    seed = round(seed / grid) * grid
                alternatives = [2 * seed, seed / 2, hi, lo]
                if grid:
                    alternatives = [round(v / grid) * grid for v in alternatives]
                alternatives = [v for v in alternatives if lo <= v <= hi and v != seed]
        else:
            grid, alternatives = 0, [2 * seed] if seed is not None else []
        alternatives = [v for v in alternatives if math.isfinite(v) and v > 0]
        if seed is None or not math.isfinite(seed) or seed <= 0 or not alternatives:
            continue
        if bounds and not lo <= seed <= hi:
            continue
        alternative = alternatives[0]
        master = 'oa_' + device['oa_library'] + '__' + device['cell']
        param = device['normalized_to_cdf']['resistance']
        if any(any(c in value for c in '\t\r\n=') for value in (master, param)):
            raise ValueError('invalid actual OA/CDF identity')
        common = ['id=op_source_resistor', 'type=resistor', 'instance=' + targets[0],
            'resistor.master=' + master, 'resistor.parameter=' + param]
        if bounds:
            common += ['resistor.min=' + format(lo, '.17g'), 'resistor.max=' + format(hi, '.17g'),
                       'resistor.grid=' + format(grid, '.17g')]
        resistor = lambda value: '\n'.join(common + ['resistor.value=' + format(value, '.17g')]) + '\n'
        stack = lambda count: '\n'.join(['id=op_mos_stack', 'type=stack', 'instance=' + targets[1],
            'stage_count=' + str(count), 'gate_policy=shared', 'intent=effective_length']) + '\n'
        selection = {'resistor_target': targets[0], 'stack_target': targets[1],
            'resistor_master': master, 'resistor_parameter': param, 'initial_resistance': seed,
            'changed_resistance': alternative, 'cdf_range_known': bool(bounds),
            'validation_scope': 'structure_only', 'electrical_verified': False,
            'selection': 'stable first two distinct current-layer scalar MOS; no electrical suitability claim',
            'value_check': 'actual CDF range when available; CDF callback/check/save and round-trip always required'}
        return selection, {'resistor_initial.conf': resistor(seed), 'resistor_changed.conf': resistor(alternative),
            'stack_two.conf': stack(2), 'stack_three.conf': stack(3)}
    raise ValueError('no two-terminal resistor with a usable literal CDF default/range and two test values')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        session, output = Path(args.session).resolve(), Path(args.output).resolve()
        pairs = dict(line.split('=', 1) for line in (session / 'session.conf').read_text().splitlines() if '=' in line)
        if pairs.get('validation_scope') != 'structure_only':
            raise ValueError('fixed workflow requires a structure_only session')
        inputs = read_json(session / 'analysis/standalone_inputs/provider_inputs.json')
        verify_site_inputs(inputs)
        configs = read_json(inputs['tech'])
        if len(configs) != 1 or configs[0].get('validation_scope') != 'structure_only':
            raise ValueError('one current structural PDK configuration is required')
        with (session / 'before/mos_inventory.tsv').open(newline='') as stream:
            inventory = list(csv.DictReader(stream, delimiter='\t'))
        selection, operations = choose_operations(inventory, configs[0])
        output.mkdir(parents=True, exist_ok=False)
        for name, body in operations.items():
            (output / name).write_text(body)
        (output / 'test_selection.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
        print('RESISTOR_TARGET=' + selection['resistor_target'])
        print('STACK_TARGET=' + selection['stack_target'])
        print('RESISTOR_MASTER=' + selection['resistor_master'])
        print('CDF_RANGE_KNOWN=' + str(selection['cdf_range_known']).lower())
        print('STRUCTURE_TEST_PREPARED files=4')
        return 0
    except (OSError, ValueError, KeyError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
