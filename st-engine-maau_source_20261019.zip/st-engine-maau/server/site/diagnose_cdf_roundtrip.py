#!/usr/bin/env python3
"""Read source/staging CDF evidence for a failed parameter round-trip; never save OA."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
MARKER = 'ST_CDF_ROUNDTRIP_DIAGNOSTIC_COMPLETE'
CONFLICT = re.compile(r'^(.+)/([^/\s]+)\.([A-Za-z_]\w*)\s+要求值=')

ACTION = r'''load(getShellEnvVar("ST_SKILL_INIT"))
procedure(stCdfDiagnosticDump(port scope library cell view instanceName parameterName)
  let((cv inst candidate cdf parameter prop key geometry spectre)
    cv=dbOpenCellViewByType(library cell view "" "r")
    unless(cv error("Cannot read diagnostic CellView %L/%L/%L" library cell view))
    foreach(candidate cv~>instances
      when(equal(candidate~>name instanceName) inst=candidate))
    unless(inst error("Cannot read diagnostic instance %L in %L/%L" instanceName library cell))
    unless(and(equal(inst~>master~>libName __MASTER_LIB__)
               equal(inst~>master~>cellName __MASTER_CELL__)
               equal(inst~>master~>viewName __MASTER_VIEW__))
      error("Diagnostic master differs from materialization plan for %L" instanceName))
    cdf=cdfGetInstCDF(inst)
    unless(cdf error("Missing actual instance CDF for %L" instanceName))
    parameter=get(cdf concat(parameterName))
    unless(parameter error("Missing actual diagnostic CDF parameter %L" parameterName))
    prop=dbFindProp(inst parameterName)
    fprintf(port "SCOPE=%s CELLVIEW=%L/%L/%L INSTANCE=%L\n" scope library cell view instanceName)
    fprintf(port "MASTER=%L/%L/%L\n" inst~>master~>libName inst~>master~>cellName inst~>master~>viewName)
    fprintf(port "CDF_PARAMETER=%L TYPE=%L VALUE=%L DEFAULT=%L\n"
      parameterName parameter~>paramType parameter~>value parameter~>defValue)
    fprintf(port "CDF_EDITABLE=%L DISPLAY=%L STORE_DEFAULT=%L PARSE_AS_NUMBER=%L\n"
      parameter~>editable parameter~>display parameter~>storeDefault parameter~>parseAsNumber)
    fprintf(port "CDF_CALLBACK=%L\n" parameter~>callback)
    fprintf(port "EXPLICIT_PROPERTY_PRESENT=%L TYPE=%L VALUE=%L\n"
      if(prop then t else nil) if(prop then prop~>valueType else nil) if(prop then prop~>value else nil))
    ; Simulator information is a DPL. Print its declarations, do not infer
    ; that a parameter is harmless from its name or from editable/display.
    spectre=cdf->simInfo->spectre
    fprintf(port "SPECTRE_INST_PARAMETERS=%L\n" spectre->instParameters)
    fprintf(port "SPECTRE_OTHER_PARAMETERS=%L\n" spectre->otherParameters)
    fprintf(port "SPECTRE_PROP_MAPPING=%L\n" spectre->propMapping)
    fprintf(port "SPECTRE_COMPONENT_NAME=%L NETLIST_PROCEDURE=%L\n"
      spectre->componentName spectre->netlistProcedure)
    foreach(key list("l" "w" "nfin" "fw" "fingers" "nf" "m" "model")
      geometry=get(cdf concat(key))
      when(geometry fprintf(port "GEOMETRY_PARAMETER=%L TYPE=%L VALUE=%L\n"
        key geometry~>paramType geometry~>value)))
    dbClose(cv)
    t
  )
)
let((result port)
  result=errset(
    prog(()
      port=outfile(getShellEnvVar("ST_CDF_ROUNDTRIP_REPORT"))
      unless(port error("Cannot create CDF round-trip diagnostic report"))
      stCdfDiagnosticDump(port "source" __SOURCE_LIB__ __SOURCE_CELL__ __SOURCE_VIEW__ __INSTANCE__ __PARAMETER__)
      stCdfDiagnosticDump(port "staging" __TARGET_LIB__ __TARGET_CELL__ __TARGET_VIEW__ __INSTANCE__ __PARAMETER__)
      fprintf(port "ST_CDF_ROUNDTRIP_DIAGNOSTIC_COMPLETE\n")
      close(port)
      port=nil
      t
    )
    t
  )
  when(port close(port))
  unless(result printf("ST_CDF_ROUNDTRIP_DIAGNOSTIC_FAILED\n"))
)
exit()
'''


def select_failure(session):
    pairs = dict(line.split('=', 1) for line in
                 (session / 'reports/validation.txt').read_text(encoding='utf-8').splitlines() if '=' in line)
    if pairs.get('ok') != 'false' or pairs.get('stage') != 'verify_roundtrip':
        raise ValueError('need an existing failed verify_roundtrip report')
    match = CONFLICT.match(pairs.get('message', ''))
    if not match:
        raise ValueError('failed report does not identify a CDF parameter mismatch')
    scope, instance, parameter = match.groups()
    plan = json.loads((session / 'materialization/plan.json').read_text(encoding='utf-8'))
    matches = []
    for generated in plan['generated_cells']:
        target = generated['schematic']
        if scope != 'oa_' + target['library'] + '__' + target['cell']:
            continue
        matches.extend((target, item) for item in generated['create_instances'] if item['name'] == instance)
    if len(matches) != 1:
        raise ValueError('failed parameter must select exactly one actual generated instance in plan.json')
    target, item = matches[0]
    params = item['cdf_parameters']
    if parameter not in params:
        raise ValueError('failed parameter absent from actual materialization plan')
    return {'source': plan['source'], 'target': target, 'master': item['master'],
            'instance': instance, 'parameter': parameter, 'expected_value': params[parameter],
            'expected_parameters': params}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    session, output = Path(args.session).resolve(), Path(args.output).expanduser()
    if not output.is_absolute():
        raise ValueError('--output needs a new absolute directory')
    selection = select_failure(session)
    # Resolve imports beside this installed script; standalone diagnostics do
    # not reinterpret or mutate the session's signed input configuration.
    from site_data import read_json, verify_site_inputs
    from standalone import environment
    manifest = session / 'analysis/standalone_inputs/provider_inputs.json'
    inputs = read_json(manifest)
    verify_site_inputs(inputs)
    config = dict(line.split('=', 1) for line in
                  (session / 'session.conf').read_text(encoding='utf-8').splitlines() if '=' in line)
    cds = Path(config['cds_lib'])
    if not cds.is_absolute() or not cds.is_file() or cds.name != 'cds.lib':
        raise ValueError('actual session cds.lib is missing')
    replacements = {'__INSTANCE__': selection['instance'], '__PARAMETER__': selection['parameter']}
    for prefix in ('source', 'target', 'master'):
        for key, token in (('library', 'LIB'), ('cell', 'CELL'), ('view', 'VIEW')):
            replacements['__' + prefix.upper() + '_' + token + '__'] = selection[prefix][key]
    action_text = ACTION
    for token, value in replacements.items():
        action_text = action_text.replace(token, json.dumps(value, ensure_ascii=False))
    output.mkdir(parents=True, exist_ok=False)
    (output / 'selection.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    action = output / 'cdf_roundtrip_diagnostic.il'
    action.write_text(action_text, encoding='utf-8')
    print('INSTANCE=' + selection['instance'] + ' PARAMETER=' + selection['parameter'])
    print('PLAN_EXPECTED_VALUE=' + repr(selection['expected_value']))
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return 0
    executable = shutil.which(os.environ.get('ST_VIRTUOSO_BIN') or 'virtuoso')
    if not executable:
        raise ValueError('Virtuoso executable unavailable; retained ' + str(output))
    env = environment(inputs, manifest)
    env.pop('ST_PREPARED_JSON_FILE', None)
    report = output / 'cdf_report.txt'
    env['ST_CDF_ROUNDTRIP_REPORT'] = str(report)
    launcher, native = output / 'launcher.log', output / 'virtuoso.log'
    with launcher.open('x', encoding='utf-8') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action), '-log', str(native)],
            cwd=str(cds.parent), env=env, stdout=stream, stderr=subprocess.STDOUT)
    content = report.read_text(encoding='utf-8', errors='replace') if report.is_file() else ''
    if result.returncode or MARKER not in content.splitlines():
        for path in (launcher, native):
            if path.is_file():
                print(path.read_text(encoding='utf-8', errors='replace'))
        if content:
            print(content)
        print('STOP: CDF round-trip diagnostic failed; retained ' + str(output))
        return result.returncode if 0 < result.returncode < 126 else 70
    print(content, end='')
    print('CDF_ROUNDTRIP_DIAGNOSTIC_READ_OK; evidence only, generation remains unverified')
    print('证据目录=' + str(output))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
