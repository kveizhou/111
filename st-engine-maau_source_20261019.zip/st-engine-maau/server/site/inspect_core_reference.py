#!/usr/bin/env python3
"""Inspect the actual core referenced by an existing read-only parent snapshot."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HEADER = '// OA structural netlist generated read-only by st-engine-maau'


def select_reference(text, instance=None):
    """Names locate a reference only; standalone.inspect still proves MOS/CDF."""
    if not text.startswith(HEADER + '\n'):
        raise ValueError('need an actual read-only OA snapshot, not pasted/transcribed text')
    starts = re.findall(r'(?m)^subckt\s+(\S+)', text)
    ends = re.findall(r'(?m)^ends\s+(\S+)', text)
    if len(starts) != 1 or ends != starts:
        raise ValueError('need one complete parent subckt with matching ends')
    records = re.findall(r'(?m)^\s*([^\s()]+)\s*\([^)]*\)\s+(oa_\S+)', text)
    candidates = []
    for name, key in records:
        parts = key[3:].split('__')
        hinted = name.endswith('_core') or (len(parts) == 2 and parts[1].endswith('_core'))
        if (instance is not None and name != instance) or (instance is None and not hinted):
            continue
        if len(parts) != 2 or not all(parts) or any('/' in value for value in parts):
            raise ValueError('cannot split actual OA master unambiguously: ' + key)
        candidates.append({'parent_cell': starts[0], 'instance': name,
                           'library': parts[0], 'cell': parts[1]})
    if not candidates:
        raise ValueError('no core reference; specify the actual --reference-instance if needed')
    if len(candidates) != 1:
        raise ValueError('multiple core references; specify --reference-instance: ' +
                         json.dumps(candidates, ensure_ascii=False))
    return candidates[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-netlist', required=True)
    parser.add_argument('--reference-instance')
    parser.add_argument('--parent-lib', required=True)
    parser.add_argument('--parent-cell', required=True)
    parser.add_argument('--cds-lib', required=True)
    parser.add_argument('--backend', default=str(ROOT / 'server/st_virtuoso_backend.sh'))
    parser.add_argument('--engine', default=str(ROOT / 'build/bin/st_circuit_tool'))
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--variant-lib', required=True)
    parser.add_argument('--variant-id', required=True)
    args = parser.parse_args()
    reference = Path(args.reference_netlist).resolve()
    original = reference.read_text(encoding='utf-8')
    selected = select_reference(original, args.reference_instance)
    if selected['parent_cell'] != args.parent_cell:
        raise ValueError('reference snapshot does not match --parent-cell')
    cds = Path(args.cds_lib).resolve()
    if not cds.is_file() or cds.name != 'cds.lib':
        raise ValueError('need the current project cds.lib')
    for value in (args.variant_lib, args.variant_id):
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value):
            raise ValueError('variant library/id must be Cadence-safe identifiers')
    work = Path(args.work_dir).resolve()
    work.mkdir(parents=True, exist_ok=False)
    check = work / 'reference_check'
    check.mkdir()
    (check / 'parent_original.scs').write_text(original, encoding='utf-8')
    policy = check / 'empty_policy.tsv'
    policy.write_text('oa_library\toa_cell\tkind\n', encoding='utf-8')
    fresh = check / 'parent_current.scs'
    from pdk_discovery import helper_init
    env = dict(os.environ)
    env.pop('ST_PREPARED_JSON_FILE', None)
    env.pop('ST_PDK_TECH_ADAPTER', None)
    env.update(ST_ENGINE_ROOT=str(ROOT), ST_SKILL_INIT=helper_init())
    # Re-read the immediate parent in the current cds.lib. Do not use a stale
    # snapshot or a historical cell name to select the next source silently.
    with (check / 'snapshot.log').open('x', encoding='utf-8') as log:
        result = subprocess.run([args.backend, 'snapshot', '--cds-lib', str(cds),
            '--lib', args.parent_lib, '--cell', args.parent_cell, '--view', 'schematic',
            '--core-subckt', args.parent_cell, '--device-policy', str(policy),
            '--netlist-output', str(fresh), '--catalog-output', str(check / 'catalog.tsv'),
            '--geometry-output', str(check / 'geometry.tsv')], env=env,
            stdout=log, stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        print('STOP: parent read failed; log=' + str(check / 'snapshot.log'), file=sys.stderr)
        return result.returncode
    current = select_reference(fresh.read_text(encoding='utf-8'), selected['instance'])
    if current != selected:
        raise ValueError('parent core reference changed; retained current snapshot=' + str(fresh))
    source = {'lib': selected['library'], 'cell': selected['cell'], 'view': 'schematic'}
    selection = check / 'core_selection.json'
    selection.write_text(json.dumps({'parent': {'lib': args.parent_lib,
        'cell': args.parent_cell, 'view': 'schematic'}, 'instance': selected['instance'],
        'source': source, 'reference_netlist': str(reference),
        'reference_sha256': hashlib.sha256(original.encode('utf-8')).hexdigest(),
        'current_parent_netlist': str(fresh), 'validation_scope': 'structure_only',
        'editable_scope': 'selected_cell_current_layer'}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('CORE_INSTANCE=' + selected['instance'], flush=True)
    print('CORE_LIBRARY=' + source['lib'], flush=True)
    print('CORE_CELL=' + source['cell'], flush=True)
    print('CORE_REFERENCE_VERIFIED', flush=True)
    # The existing source-bound PDK discovery, CDF checks and engine inventory
    # establish what can actually be transformed; reference names prove none
    # of those electrical or structural properties by themselves.
    command = [sys.executable, str(ROOT / 'server/site/standalone.py'), 'inspect',
        '--validation-scope', 'structure_only', '--engine', args.engine,
        '--backend', args.backend, '--cds-lib', str(cds), '--lib', source['lib'],
        '--cell', source['cell'], '--view', 'schematic', '--core-subckt', source['cell'],
        '--work-dir', str(work), '--variant-lib', args.variant_lib,
        '--variant-cell', source['cell'] + '__' + args.variant_id,
        '--variant-id', args.variant_id, '--skill', str(ROOT / 'skill/standalone_topology_variant.il')]
    status = subprocess.run(command, env=env, check=False).returncode
    if status:
        return status
    manifest = work / 'analysis/standalone_inputs/provider_inputs.json'
    inputs = json.loads(manifest.read_text(encoding='utf-8'))
    for path in (selection, fresh, check / 'parent_original.scs'):
        inputs['file_sha256'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest.write_text(json.dumps(inputs, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('CORE_STRUCTURAL_INSPECT_COMPLETE session=' + str(work), flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
