#!/usr/bin/env python3
"""Read Maau tech_cfg_v2.0.json using the schema in NewTechDataAccessor.

No cell-name classification, LUT-derived ratings, or invented parameter limits.
Additional electrical rules are explicit data from the site's PDK documentation.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile


def read_json(path):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('duplicate JSON key: ' + key)
            out[key] = value
        return out
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON: ' + x)))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix=path.name + '.', delete=False) as stream:
        temp = Path(stream.name)
        try:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        except Exception:
            if temp.exists():
                temp.unlink()
            raise
    os.replace(temp, path)


def finite(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError('expected finite numeric value')
    if positive and value <= 0:
        raise ValueError('expected positive value')
    return float(value)


def actual_path(value, parent):
    value = os.path.expandvars(os.path.expanduser(value))
    if '$' in value:
        raise ValueError('unset path environment variable: ' + value)
    path = Path(value)
    return str((path if path.is_absolute() else parent / path).resolve())


def unit_scale(unit, semantic):
    dimension = semantic in ('width', 'total_width', 'length')
    scales = {'m': 1, 'meter': 1, 'metre': 1, 'meters': 1, 'um': 1e-6,
              'µm': 1e-6, 'nm': 1e-9, 'mm': 1e-3}
    if dimension:
        # An empty unit does not prove whether the config uses meters or microns.
        if unit not in scales:
            raise ValueError('unproven dimension unit: ' + str(unit))
        return scales[unit]
    if semantic == 'resistance':
        if unit not in ('ohm', 'Ohm', 'ohms', 'Ohms', 'Ω'):
            raise ValueError('unproven resistance unit: ' + str(unit))
    elif unit not in ('', '1', 'integer', 'count'):
        raise ValueError('unproven count unit: ' + str(unit))
    return 1


def constraint(param, semantic):
    scale = unit_scale(param.get('units', ''), semantic)
    value = param.get('constraint')
    values = value if isinstance(value, list) else [value] if isinstance(value, (int, float)) else []
    if not values:
        return None
    values = sorted(set(finite(v, True) * scale for v in values))
    if semantic in ('fingers', 'fin', 'multiplier') and any(v != int(v) for v in values):
        raise ValueError('count constraint is not integral')
    return {'min': values[0], 'max': values[-1], 'grid': 0, 'allowed': values}


def load_tech_config(path, rules=None):
    path = Path(path).resolve()
    raw = read_json(path)
    for key in ('tech_name', 'pdk_name', 'pdk_path', 'device_categories'):
        if not raw.get(key):
            raise ValueError('missing tech field: ' + key)
    rules = rules or {}
    if rules:
        if rules.get('tech_name') != raw['tech_name']:
            raise ValueError('rules/tech identity conflict')
        if not rules.get('source'):
            raise ValueError('rules require an authoritative source')
    root_values = [raw['pdk_path']]
    if raw.get('base_pdk_path'):
        root_values.append(raw['base_pdk_path'])
    roots = [actual_path(root, path.parent) for root in root_values]
    aliases = []
    for root in root_values:
        lexical = Path(os.path.expandvars(os.path.expanduser(root)))
        lexical = lexical if lexical.is_absolute() else path.parent / lexical
        aliases.append(str(lexical.absolute()))
    corners = []
    for corner in raw.get('corners', []):
        sections = []
        for section in corner.get('sections', []):
            if not section.get('model_file') or not section.get('section_name'):
                raise ValueError('incomplete corner model section')
            sections.append({'model_file': actual_path(section['model_file'], path.parent),
                             'section_name': section['section_name']})
        if not corner.get('name') or not sections:
            raise ValueError('incomplete corner')
        corners.append({'name': corner['name'], 'sections': sections})
    if len({c['name'] for c in corners}) != len(corners):
        raise ValueError('duplicate corner')
    finfet = raw.get('tech_type') == 'TechType.FINFET'
    # In Maau planar geometry FW is per-finger width; W is total width (FW*FIN).
    # A total-width CDF alone cannot prove a per-finger sizing parameter.
    semantic_names = {'L': 'length', 'MULTI': 'multiplier', 'R': 'resistance', 'W': 'total_width'}
    semantic_names.update({'FIN': 'fin', 'FINGERS': 'fingers'} if finfet
                          else {'FW': 'width', 'FIN': 'fingers'})
    devices = []
    seen = set()
    for category_name, category in raw['device_categories'].items():
        if category_name not in ('DeviceType.MOS', 'DeviceType.RES'):
            continue
        for raw_dev in category.get('devices', []):
            if raw_dev.get('device_type') != category_name:
                raise ValueError('device/category identity conflict')
            kind = 'resistor' if category_name == 'DeviceType.RES' else {
                'SubDeviceType.NMOS': 'mos_n', 'SubDeviceType.PMOS': 'mos_p'
            }.get(raw_dev.get('sub_device_type'))
            if not kind:
                raise ValueError('unproven MOS polarity: ' + str(raw_dev.get('cell_name')))
            cell = raw_dev.get('cell_name')
            if not cell or not raw_dev.get('model_name') or cell in seen:
                raise ValueError('missing or duplicate cell/model identity')
            seen.add(cell)
            normalize = raw_dev.get('normalization', {})
            mapping = {}
            constraints = {}
            for normalized, cdf_name in normalize.get('normalize_inst_cdf_name_dict', {}).items():
                semantic = semantic_names.get(normalized)
                if not semantic:
                    continue
                if semantic in mapping and mapping[semantic] != cdf_name:
                    raise ValueError('ambiguous normalized CDF: ' + semantic)
                mapping[semantic] = cdf_name
                param = raw_dev.get('cdf_parameters', {}).get(cdf_name)
                if param is not None:
                    domain = constraint(param, semantic)
                    if domain:
                        constraints[semantic] = domain
            dev = {'cell': cell, 'model': raw_dev['model_name'], 'kind': kind,
                   'normalized_to_cdf': mapping, 'constraints': constraints,
                   'sim_cdf': normalize.get('normalize_sim_cdf_name_dict', {}),
                   'dc_signals': normalize.get('normalize_dc_signal_name_dict', {}),
                   'signal_postfix': raw_dev.get('signal_post_fix', ''),
                   'source': str(path), 'missing': []}
            rule = rules.get('devices', {}).get(cell, {})
            dev['electrical_rules'] = rule
            if rule:
                dev['rules_source'] = rules['source']
            for key in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb'):
                if key in rule:
                    dev[key] = finite(rule[key], True)
            for key in ('bulkRule', 'voltageDomains', 'terminalRoles', 'wFinFormula'):
                if key in rule:
                    dev[key] = rule[key]
            if kind != 'resistor' and not all(k in dev for k in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb')):
                dev['missing'].append('reliability')
            if kind != 'resistor' and not dev.get('bulkRule'):
                dev['missing'].append('bulk')
            if not dev.get('voltageDomains'):
                dev['missing'].append('voltage_domain')
            if not constraints:
                dev['missing'].append('cdf_constraints')
            devices.append(dev)
    unknown_rules = set(rules.get('devices', {})) - seen
    if unknown_rules:
        raise ValueError('rules refer to unknown cells: ' + ','.join(sorted(unknown_rules)))
    digest = hashlib.sha256(json.dumps({'tech': raw, 'rules': rules}, sort_keys=True,
                                      separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return {'tech_name': raw['tech_name'], 'pdk_name': raw['pdk_name'], 'pdk_paths': roots,
            'pdk_alias_paths': aliases,
            'version': 'config-sha256:' + digest, 'source': str(path), 'corners': corners,
            'temperatures': [finite(v) for v in raw.get('temperatures', [])],
            'devices': sorted(devices, key=lambda d: d['cell'])}


def pin_site_inputs(inputs):
    pinned = dict(inputs)
    files = {Path(inputs[key]).resolve() for key in ('context', 'rules', 'tech', 'adapter', 'runtime')}
    configs = read_json(inputs['tech'])
    rules = read_json(inputs['rules'])
    models = [s['model_file'] for c in configs for corner in c.get('corners', []) for s in corner['sections']]
    models += rules.get('original_model_files', [])
    models += [s['model_file'] for corner in rules.get('op_corners', {}).values() for s in corner['models']]
    files.update(Path(path).resolve() for path in models)
    pinned['file_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)}
    return pinned


def verify_site_inputs(inputs, environment=None):
    fingerprints = inputs.get('file_sha256')
    if not fingerprints:
        raise ValueError('site input fingerprints missing; create a new imported Case session')
    required = {str(Path(inputs[key]).resolve()) for key in ('context', 'rules', 'tech', 'adapter', 'runtime')}
    if not required.issubset(fingerprints):
        raise ValueError('incomplete site input fingerprints')
    if environment is not None:
        names = {'context': 'ST_SITE_CASE_CONTEXT', 'rules': 'ST_SITE_CASE_RULES',
                 'tech': 'ST_SITE_TECH_METADATA', 'adapter': 'ST_PDK_TECH_ADAPTER',
                 'runtime': 'ST_MAAU_RUNTIME_BIN'}
        for key, variable in names.items():
            active = environment.get(variable, '')
            if not active or Path(active).resolve() != Path(inputs[key]).resolve():
                raise ValueError('active site input path differs from pinned input: ' + variable)
    for path, expected in fingerprints.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError('site input changed since import; create a new session: ' + path)


def discover_tech_configs(root):
    return [load_tech_config(path) for path in sorted(Path(root).glob('*/tech_cfg_v2.0.json'))]


def match_library(library_path, configs):
    path = Path(library_path).resolve()
    matches = [config for config in configs if any(
        path == Path(root) or Path(root) in path.parents for root in config['pdk_paths'])]
    if len(matches) != 1:
        raise ValueError('ambiguous PDK path' if matches else 'unproven PDK path')
    return matches[0]


def inspect_defaults(context, extension, bench=None):
    side = extension.get('design_side')
    target = context.get('target_dut', {})
    if side is None:
        if all(target.get(k) for k in ('lib', 'cell', 'view')) and target != context['source_dut']:
            raise ValueError('Case has source and target DUT; select design_side')
        side = 'source'
    if side not in ('source', 'target'):
        raise ValueError('design_side must be source or target')
    dut = context[side + '_dut']
    benches = context.get(side + '_benches', [])
    if bench is None:
        if len(benches) != 1:
            raise ValueError('Case requires an explicit Bench selection')
        bench = benches[0]
    elif not any(all(b.get(k) == bench.get(k) for k in ('lib', 'cell', 'view')) for b in benches):
        raise ValueError('selected Bench is not in the imported Case')
    values = {'lib': dut['lib'], 'cell': dut['cell'], 'view': dut['view'],
              'bench-lib': bench['lib'], 'bench-cell': bench['cell'], 'bench-view': bench['view'],
              'cds-lib': str(Path(context[side + '_cds_path']) / 'cds.lib')}
    for key in ('nominal_corner', 'pvt_corners', 'vbias_vhigh_net', 'vbias_vlow_net',
                'max_branch_current_error', 'max_vbias_current'):
        if key in extension:
            value = extension[key]
            values[key.replace('_', '-')] = ','.join(value) if isinstance(value, list) else str(value)
    return values


def merge_explicit(defaults, explicit):
    result = dict(defaults)
    for key, value in explicit.items():
        if key in result and str(value) != str(result[key]):
            raise ValueError('imported Case/explicit option conflict: ' + key)
        result[key] = value
    return result


def skill(value):
    if value is None or value is False:
        return 'nil'
    if value is True:
        return 't'
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (int, float)):
        return format(finite(value), '.17g')
    if isinstance(value, dict):
        return 'list(' + ' '.join('list(' + skill(k) + ' ' + skill(v) + ')' for k, v in sorted(value.items())) + ')'
    return 'list(' + ' '.join(skill(v) for v in value) + ')'


def skill_metadata(config):
    descriptions = {}
    for dev in config['devices']:
        row = {'kind': dev['kind'], 'modelName': dev['model'], 'kindSource': dev['source'],
               'deviceProofSource': dev['source'], 'normalizedToCdf': [
                   k + ':' + v for k, v in sorted(dev['normalized_to_cdf'].items())],
               'parameterConstraints': []}
        for key, c in sorted(dev['constraints'].items()):
            name = dev['normalized_to_cdf'][key]
            row['parameterConstraints'].append(':'.join([key, name, str(c['min']), str(c['max']),
                str(c['grid']), ','.join(str(v) for v in c['allowed'])]))
            prefix = {'width': 'Width', 'length': 'Length', 'resistance': 'Resistance'}.get(key)
            if prefix:
                row['min' + prefix], row['max' + prefix] = c['min'], c['max']
        row['cdfSource'] = dev['source'] if dev['constraints'] else ''
        for key in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'bulkRule', 'voltageDomains', 'terminalRoles', 'wFinFormula'):
            if key in dev:
                row[key] = dev[key]
        for key in ('reliabilitySource', 'bulkSource', 'domainSource'):
            row[key] = dev.get('rules_source', '')
        descriptions[dev['cell']] = row
    return {'pdkName': config['pdk_name'], 'pdkVersion': config['version'],
            'roots': sorted(set(config['pdk_paths'] + config.get('pdk_alias_paths', []))),
            'source': config['source'], 'devices': descriptions,
            'modelFiles': sorted({s['model_file'] for c in config['corners'] for s in c['sections']}),
            'modelSections': sorted({s['section_name'] for c in config['corners'] for s in c['sections']}),
            'corners': [c['name'] for c in config['corners']]}


def write_metadata(configs, output, skill_output):
    write_json(output, configs)
    target = Path(skill_output).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    adapter = Path(__file__).resolve().parents[1] / 'skill/site_metadata_adapter.il'
    target.write_text('; Generated from real Maau tech configuration.\n' +
                      'stSiteConfigs = ' + skill([skill_metadata(c) for c in configs]) + '\n' +
                      'load(' + skill(str(adapter)) + ')\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-inputs', help='validate imported Case inputs before any cached OP reuse')
    parser.add_argument('--tech-config', action='append')
    parser.add_argument('--rules', help='PDK electrical rule JSON, for exactly one tech config')
    parser.add_argument('--output', help='normalized JSON')
    parser.add_argument('--skill-output')
    args = parser.parse_args()
    if args.verify_inputs:
        verify_site_inputs(read_json(args.verify_inputs), os.environ)
        return
    if not args.tech_config or not args.output or not args.skill_output:
        parser.error('--tech-config, --output and --skill-output are required for generation')
    if args.rules and len(args.tech_config) != 1:
        parser.error('--rules requires exactly one --tech-config')
    configs = [load_tech_config(p, read_json(args.rules) if args.rules else None) for p in args.tech_config]
    write_metadata(configs, args.output, args.skill_output)


if __name__ == '__main__':
    main()
