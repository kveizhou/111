#!/usr/bin/env python3
"""Collect cached context, native CDF/definitions and a source DC probe in one run.

This diagnostic never generates a variant or saves OA. Convergence is distinct
from electrical acceptance; raw reports, PSF, logs and details remain local.
"""
import argparse
from collections import Counter
import csv
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from preflight_cascode_bench import check_binding, digest, select_settings
from op_provider import parse_deck, parameter_value, request_dc, resolve_includes
from read_maestro_setup import read_records

TARGETS = ('I21', 'I105')
GEOMETRY = ('l', 'w', 'fw', 'nfin', 'fingers', 'nf', 'm', 'mr')
WATCH = {'iout', 'IOUT', 'da_rst', 'da_en', 'da_disable', 'da_hiz'}
MAX_LINES = 190


def canonical(value):
    return value.replace('\\', '').replace('/', '.').strip('.')


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def table(path):
    with Path(path).open(newline='') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        rows = list(reader)
    if any(None in row for row in rows):
        raise ValueError('malformed TSV: '+Path(path).name)
    return rows


def command(argv, directory, env, timeout, log):
    with Path(log).open('x') as stream:
        process = subprocess.Popen(argv, cwd=directory, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            if isinstance(error, KeyboardInterrupt):
                raise
            raise ValueError('native command timed out; retained '+Path(log).name)
    if code:
        raise ValueError('native command exit '+str(code)+'; retained '+Path(log).name)


def executable(env, variable, name):
    result = shutil.which(env.get(variable) or name, path=env.get('PATH'))
    if not result:
        raise ValueError('executable unavailable: '+name)
    return result


def inputs(args):
    session = Path(args.session).resolve(); preflight = Path(args.preflight).resolve()
    read_path = Path(args.maestro_read).resolve(); data = json.loads(read_path.read_text())
    cfg, cds, manifest, pinned = check_binding(data, session)
    settings = json.loads((preflight/'selected_corner.json').read_text())
    actual = select_settings(data, settings['test_name'], settings['corner'])
    if settings != actual:
        raise ValueError('selected Corner cache differs from the saved Maestro read')
    exports = list((preflight/'generated').rglob('input.scs'))
    if len(exports) != 1:
        raise ValueError('unique original config export is missing')
    text = (preflight/'bench.scs').read_text()
    if text != exports[0].read_text():
        raise ValueError('cached Bench differs from the original config export')
    fixed_paths = [session/'session.conf', cds, manifest, read_path, preflight/'selected_corner.json',
        preflight/'bench.scs', exports[0], session/'before/device_catalog.tsv', session/'before/mos_inventory.tsv',
        session/'analysis/standalone_inputs/pdk_probe.tsv']
    fixed = {str(p): digest(p) for p in fixed_paths}
    from standalone import environment
    env = environment(pinned, manifest); env.pop('ST_PREPARED_JSON_FILE', None)
    return dict(session=session, preflight=preflight, data=data, cfg=cfg, cds=cds,
        pinned=pinned, settings=settings, text=text, origin=exports[0].parent, env=env, fixed=fixed)


def context(bound, output):
    from preflight_cascode_bench import analyze
    deck = parse_deck(bound['text'])
    # The preflight reader requires every passed variable to be declared.
    # Use its hierarchy/source parser with only the actual declarations; the
    # saved settings remain intact and omitted names are reported below.
    declared_settings=dict(bound['settings'],variables={k:v for k,v in bound['settings']['variables'].items()
        if k in deck['parameters']})
    _, details = analyze(bound['text'], bound['cfg']['source_cell'], declared_settings)
    targets = {i['name']: i for i in details['direct_core_instances'] if i['name'] in TARGETS}
    if set(targets) != set(TARGETS):
        raise ValueError('current exported core lacks scalar I21/I105; targets are not guessed')
    not_declared=[]
    for key, value in bound['settings']['variables'].items():
        if key not in deck['parameters']:
            not_declared.append(key)
            continue
        if value != deck['parameters'][key]:
            a = parameter_value(value, bound['settings']['variables'])
            b = parameter_value(deck['parameters'][key], deck['parameters'])
            if not math.isclose(a, b, rel_tol=1e-12, abs_tol=0):
                raise ValueError('exported variable differs from selected Corner: '+key)
    # Look across all declared instances, including non-native behavioral loads.
    # These are text references, not proof of model behavior or DC activation.
    scopes = [('ROOT', deck['top'])]+[(k,v['instances']) for k,v in deck['definitions'].items()]
    refs = [dict(scope=s, **i) for s,items in scopes for i in items
        if WATCH.intersection(re.findall(r'[A-Za-z_][A-Za-z0-9_$]*', i['tail']))]
    includes = [s.strip() for s in deck['lines'] if s.strip().startswith(('include ', 'ahdl_include '))]
    result = dict(core_path=details['core_path'], targets=targets, root_instances=deck['top'],
        text_references=refs, includes=includes, sources=details['sources'],
        core_master_counts=dict(Counter(i['master'] for i in details['direct_core_instances'])),
        variables=deck['parameters'], saved_variables_not_declared=not_declared,
        direct_core_instance_count=len(details['direct_core_instances']))
    save(output/'context.json', result)
    return result


def pdk(bound, output):
    catalog = table(bound['session']/'before/device_catalog.tsv')
    inventory = table(bound['session']/'before/mos_inventory.tsv')
    probe = table(bound['session']/'analysis/standalone_inputs/pdk_probe.tsv')
    metadata = json.loads(Path(bound['pinned']['tech']).read_text())
    if not isinstance(metadata, list):
        raise ValueError('current PDK metadata must contain a configuration list')
    targets = {}
    for name in TARGETS:
        rows = [r for r in inventory if r['instance'] == name]
        if len(rows) != 1:
            raise ValueError('target missing or ambiguous in current-layer inventory: '+name)
        masters = [r for r in catalog if r['master'] == rows[0]['master']]
        if len(masters) != 1:
            raise ValueError('target master missing or ambiguous in scanned catalog: '+name)
        master = masters[0]; identity = (master['oa_library'], master['oa_cell'])
        parameters = [r for r in probe if (r['oa_library'],r['oa_cell']) == identity]
        devices = [d for c in metadata for d in c.get('devices', [])
                   if (d.get('oa_library'),d.get('cell')) == identity]
        targets[name] = dict(master=master, cdf_probe=parameters, metadata=devices,
            other_same_polarity_count=sum(r['kind']==master['kind'] and r['master']!=master['master'] for r in catalog)
                if master['kind'] in ('mos_n','mos_p') else None)
    result = dict(targets=targets, kind_counts=dict(Counter(r['kind'] for r in catalog)),
        catalog=catalog, metadata=metadata, electrical_rules_ready=False)
    save(output/'pdk.json', result)
    return result


def native_action(bound, pdk_info):
    selection = bound['data']['selection']; cfg = bound['cfg']
    code = r'''load(getShellEnvVar("ST_SKILL_INIT"))
procedure(stBatchRecord(port kind scope name result)
  if(result then
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tOK\t%L\n" kind scope name car(result))
  else
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tREAD_ERROR\tnil\n" kind scope name)
  )
)
procedure(stBatchCdf(port cv instanceName expectedLibrary expectedCell expectedView)
  let((inst candidate cdf param spectre prop key field)
    foreach(candidate cv~>instances when(equal(candidate~>name instanceName) inst=candidate))
    unless(inst error("Source scalar instance missing: %L" instanceName))
    unless(and(equal(inst~>master~>libName expectedLibrary)
               equal(inst~>master~>cellName expectedCell) equal(inst~>master~>viewName expectedView))
      error("Source master changed: %L" instanceName))
    stBatchRecord(port "source" instanceName "oa_library" list(inst~>master~>libName))
    stBatchRecord(port "source" instanceName "oa_cell" list(inst~>master~>cellName))
    stBatchRecord(port "source" instanceName "oa_view" list(inst~>master~>viewName))
    cdf=cdfGetInstCDF(inst)
    unless(cdf error("Source instance CDF missing: %L" instanceName))
    spectre=cdf->simInfo->spectre
    foreach(key list("termOrder" "propMapping" "instParameters" "otherParameters" "netlistProcedure")
      stBatchRecord(port "cdf_mapping" instanceName key errset(get(spectre concat(key)) t)))
    foreach(key list("l" "w" "fw" "nfin" "fingers" "nf" "m" "mr" "model")
      param=get(cdf concat(key))
      when(param
        stBatchRecord(port "cdf_value" instanceName key list(param->value))
        foreach(field list("paramType" "minVal" "maxVal" "choices" "callback" "parseAsNumber")
          stBatchRecord(port strcat("cdf_" field) instanceName key errset(get(param concat(field)) t)))
        prop=dbFindProp(inst key)
        stBatchRecord(port "cdf_explicit" instanceName key list(if(prop then t else nil)))
      )
    )
    t
  )
)
let((port cv result setup testSession)
  result=errset(
    prog( ()
      port=outfile(getShellEnvVar("ST_BATCH_NATIVE_REPORT"))
      unless(port error("Cannot create batch native report"))
      setup=maeOpenSetup(__BENCH_LIB__ __BENCH_CELL__ __SETUP_VIEW__ ?mode "r")
      unless(setup error("Cannot read saved Maestro setup"))
      testSession=maeGetTestSession(__TEST__ ?session setup)
      unless(testSession error("Cannot read saved test session"))
      stBatchRecord(port "definition_files" __TEST__ "files"
        errset(asiGetEnvOptionVal(testSession "definitionFiles") t))
      cv=dbOpenCellViewByType(__SOURCE_LIB__ __SOURCE_CELL__ __SOURCE_VIEW__ "" "r")
      unless(cv error("Cannot read selected source OA"))
      __CALLS__
      dbClose(cv) cv=nil
      fprintf(port "ST_MAESTRO_SETUP_READ_COMPLETE\n") close(port) port=nil
      t
    ) t)
  when(cv dbClose(cv))
  when(port close(port))
  unless(and(result car(result)) printf("ST_BATCH_NATIVE_READ_FAILED\n"))
)
exit()
'''
    values = dict(BENCH_LIB=selection['bench_library'], BENCH_CELL=selection['bench_cell'],
        SETUP_VIEW=selection['setup_view'], TEST=bound['settings']['test_name'],
        SOURCE_LIB=cfg['source_library'], SOURCE_CELL=cfg['source_cell'], SOURCE_VIEW=cfg['source_view'])
    for key, value in values.items():
        code = code.replace('__'+key+'__', json.dumps(value))
    calls = []
    for name, data in pdk_info['targets'].items():
        m = data['master']
        calls.append('stBatchCdf(port cv '+' '.join(json.dumps(v) for v in
            (name,m['oa_library'],m['oa_cell'],m.get('oa_view') or 'symbol'))+')')
    return code.replace('__CALLS__', '\n'.join(calls))


def literal_files(raw):
    if raw.strip() == 'nil':
        return []
    if not raw.strip().startswith('(') or not raw.strip().endswith(')'):
        raise ValueError('Definition Files is not a literal path list')
    body = raw.strip()[1:-1]
    matches = re.findall(r'"(?:\\.|[^"\\])*"', body)
    if re.sub(r'"(?:\\.|[^"\\])*"', '', body).strip():
        raise ValueError('Definition Files contains an unresolved expression')
    files = [Path(os.path.expandvars(os.path.expanduser(json.loads(v)))) for v in matches]
    if any(not p.is_absolute() or '$' in str(p) or not p.is_file() for p in files):
        raise ValueError('Definition Files contains a missing or unresolved absolute path')
    paths = [str(p.resolve()) for p in files]
    if len(set(paths)) != len(paths):
        raise ValueError('duplicate Definition File')
    return paths


def native(bound, pdk_info, output, timeout):
    work = output/'native'; work.mkdir()
    (work/'cds.lib').write_text('INCLUDE '+json.dumps(str(bound['cds']))+'\n')
    action = work/'read.il'; action.write_text(native_action(bound, pdk_info))
    report = work/'report.tsv'; env = dict(bound['env'], ST_BATCH_NATIVE_REPORT=str(report))
    argv = [executable(env,'ST_VIRTUOSO_BIN','virtuoso'),'-nograph','-replay',str(action),'-log',str(work/'virtuoso.log')]
    command(argv, work, env, timeout, work/'launcher.log')
    records = read_records(report.read_text())
    for name, info in pdk_info['targets'].items():
        for key in ('oa_library','oa_cell','oa_view'):
            rows = [r for r in records if (r['kind'],r['scope'],r['name']) == ('source',name,key)]
            expected = info['master'].get(key) or 'symbol'
            if len(rows)!=1 or rows[0]['status']!='OK' or json.loads(rows[0]['raw_value'])!=expected:
                raise ValueError('native source master proof incomplete: '+name+'/'+key)
    rows = [r for r in records if r['kind']=='definition_files' and r['scope']==bound['settings']['test_name']]
    save(output/'native_records.json', records)
    if len(rows)!=1 or rows[0]['status']!='OK':
        raise ValueError('saved Definition Files was not read; DC is withheld')
    files = literal_files(rows[0]['raw_value'])
    hashes = {p:digest(p) for p in files}; bound['fixed'].update(hashes)
    return dict(records=records, definition_files=files)


def run_dc(bound, native_info, output, timeout):
    work = output/'dc'; work.mkdir()
    text = resolve_includes(bound['text'], bound['origin'])
    deck = parse_deck(text)
    for model in bound['settings']['models']:
        include = 'include '+json.dumps(str(Path(model['model_file']).resolve()))+' section='+model['section_name']
        if include not in [s.strip() for s in deck['lines']]:
            raise ValueError('export does not contain selected Corner model/section: '+model['section_name'])
    text = request_dc(text)
    for path in native_info['definition_files']:
        if not any(re.match(r'^\s*include\s+'+re.escape(json.dumps(path))+r'(?:\s|$)',s) for s in deck['lines']):
            text += 'include '+json.dumps(path)+'\n'
    text += 'stBatchTemperature options temp='+str(bound['settings']['temperature'])+'\n'
    path = work/'input.scs'; path.write_text(text)
    psf = work/'psf'; psf.mkdir()
    env = bound['env']
    argv = [executable(env,'ST_SPECTRE_BIN','spectre'),str(path),'+escchars','-format','psfbin','-raw',str(psf)]
    command(argv, work, env, timeout, work/'spectre.log')
    if any(not (psf/name).is_file() or (psf/name).stat().st_size==0 for name in ('dcOp.dc','dcOpInfo.info')):
        raise ValueError('Spectre exited without nonempty DC and OP PSF files')
    return dict(psf_dir=str(psf), netlist=str(path), result='CONVERGED')


def psf_action(psf, target_paths, init, table_path):
    return 'load('+json.dumps(str(init))+')\nstBatchTargets=list('+ ' '.join(json.dumps(p) for p in target_paths)+')\n'+r'''
procedure(stBatchCanonical(value)
  let((result)
    result=""
    foreach(part parseString(value "./\\")
      result=strcat(result if(equal(result "") then "" else ".") part))
    result
  )
)
procedure(stBatchTargetP(value)
  let((name found)
    name=stBatchCanonical(value)
    foreach(prefix stBatchTargets
      when(or(equal(name prefix) and(strlen(name)>strlen(prefix)
        equal(substring(name 1 strlen(prefix)) prefix)
        equal(substring(name strlen(prefix)+1 1) "."))) found=t))
    found
  )
)
procedure(stBatchScalar(value)
  cond((numberp(value) value)
       (drIsWaveform(value)
         let((vec)
           vec=drGetWaveformYVec(value)
           unless(equal(drVectorLength(vec) 1) error("Expected one DC point"))
           drGetElem(vec 0)))
       (t error("Non-numeric DC data")))
)
procedure(stBatchReadPsf()
  let((port result params kind device param name)
    openResults(__PSF__)
    port=outfile(__TABLE__)
    unless(port error("Cannot create focused PSF table"))
    fprintf(port "kind\tsignal\tparameter\tvalue\tstatus\n")
    selectResult('dcOp)
    foreach(name outputs()
      result=errset(stBatchScalar(getData(name)) t)
      if(and(result numberp(car(result))) then
        fprintf(port "node\t%s\t\t%.17g\tOK\n" name car(result))
      else fprintf(port "node\t%s\t\t\tREAD_ERROR\n" name)))
    selectResult('dcOpInfo)
    foreach(kind dataTypes()
      params=outputParams(kind)
      foreach(device outputs(?type kind)
        when(stBatchTargetP(device)
          foreach(param list("id" "ids" "vgs" "vds" "vbs" "vth" "vdsat" "gm" "gds" "region")
            when(member(param params)
              result=errset(stBatchScalar(pv(device param)) t)
              if(and(result numberp(car(result))) then
                fprintf(port "op\t%s\t%s\t%.17g\tOK\n" device param car(result))
              else fprintf(port "op\t%s\t%s\t\tREAD_ERROR\n" device param)))))))
    close(port)
    t
  )
)
result=errset(stBatchReadPsf() t)
when(and(result car(result))
  port=outfile(__MARKER__) fprintf(port "OK\n") close(port))
exit()
'''.replace('__PSF__',json.dumps(psf)).replace('__TABLE__',json.dumps(str(table_path))).replace(
        '__MARKER__',json.dumps(str(table_path.parent/'runtime.done')))


def read_op(bound, ctx, dc_info, output, timeout):
    work = output/'op'; work.mkdir()
    target_paths = [canonical(ctx['core_path']+'.'+n) for n in TARGETS]
    path = work/'values.tsv'
    action = work/'runtime.ocn'; action.write_text(psf_action(dc_info['psf_dir'],target_paths,bound['pinned']['init'],path))
    (work/'cds.lib').write_text('INCLUDE '+json.dumps(str(bound['cds']))+'\n')
    env = dict(bound['env'], ST_BATCH_PSF_TABLE=str(path))
    command([executable(env,'ST_OCEAN_BIN','ocean'),'-nograph','-restore',str(action)],work,env,timeout,work/'ocean.log')
    marker = work/'runtime.done'
    if not marker.is_file() or marker.read_text().strip()!='OK':
        raise ValueError('OCEAN PSF reader did not write its completion marker')
    rows = table(path); seen = {}
    for row in rows:
        if set(row)!= {'kind','signal','parameter','value','status'} or row['kind'] not in ('node','op'):
            raise ValueError('invalid raw PSF row')
        if row['status']=='OK':
            value = float(row['value'])
            if not math.isfinite(value): raise ValueError('nonfinite raw PSF value')
            row['value'] = value
            key = (row['kind'],canonical(row['signal']),row['parameter'])
            if key in seen and seen[key]!=value: raise ValueError('conflicting raw PSF value')
            seen[key] = value
        elif row['status']!='READ_ERROR':
            raise ValueError('invalid raw PSF read status')
    target_rows = {n:[r for r in rows if r['kind']=='op' and (canonical(r['signal'])==p or canonical(r['signal']).startswith(p+'.'))]
                   for n,p in zip(TARGETS,target_paths)}
    result = dict(targets=target_rows, nodes=[r for r in rows if r['kind']=='node'],
        read_errors=sum(r['status']!='OK' for r in rows), result='READ_OK')
    save(output/'op.json',result)
    for name, records in target_rows.items():
        per_device = {}
        for row in records:
            if row['status']=='OK': per_device.setdefault(row['signal'],set()).add(row['parameter'])
        if not any({'vgs','vds','vdsat'}.issubset(keys) and keys.intersection({'id','ids'}) for keys in per_device.values()):
            raise ValueError('required signed MOS OP not found for '+name+'; raw table retained')
    return result


def unchanged(bound):
    from site_data import verify_site_inputs
    verify_site_inputs(bound['pinned'])
    if any(digest(p)!=sha for p,sha in bound['fixed'].items()):
        raise ValueError('fixed input changed during batch; create fresh evidence')
    if any(digest(m['model_file'])!=m['sha256'] for m in bound['settings']['models']):
        raise ValueError('selected model changed during batch')
    return dict(result='UNCHANGED')


def brief_errors(output):
    found = []
    for path in sorted(output.rglob('*.log')):
        with path.open(errors='replace') as stream:
            for line in stream:
                if line.startswith(('\\i','\\p')): continue
                if any(x in line for x in ('*Error*','ERROR (','FATAL','failed','not found')):
                    found.append(path.parent.name+'/'+path.name+': '+' '.join(line.split())[:400])
    return found[:12]


def render(output, states, results, errors):
    body = []; omitted = 0
    if 'input' in results:
        b=results['input']; s=b['settings']
        body += ['SOURCE='+ '/'.join(b['cfg']['source_'+k] for k in ('library','cell','view')),
            'CORNER='+s['corner'], 'TEMPERATURE='+str(s['temperature'])]
        body += ['SELECTED_VARIABLE '+n+'='+s['variables'][n] for n in ('AVDD','DVDD','iout','IOUT','da_rst','da_en','da_disable','da_hiz') if n in s['variables']]
    # OP and target facts precede large inventories so arrays cannot hide them.
    op=results.get('op')
    if op is None and (output/'op.json').is_file(): op=json.loads((output/'op.json').read_text())
    if op:
        for name,rows in op['targets'].items():
            devices = {}
            for r in rows:
                if r['status']=='OK': devices.setdefault(r['signal'],{})[r['parameter']]=r['value']
            body += ['OP_TARGET '+name+' device='+d+' '+' '.join(k+'='+format(v,'.9g') for k,v in values.items()) for d,values in list(devices.items())[:8]]
            body.append('OP_TARGET_DEVICE_COUNT '+name+'='+str(len(devices)))
            omitted += max(0,len(devices)-8)
        body += ['RAW_PSF_READ_ERRORS='+str(op['read_errors'])]
        wanted={'AVDD','DVDD','VDD','VOUT','LDO_SYS_VOUT'}
        nodes=[r for r in op['nodes'] if canonical(r['signal']).split('.')[-1] in wanted and r['status']=='OK']
        body += ['DC_NODE '+r['signal']+'='+format(r['value'],'.9g') for r in nodes[:12]]
        omitted += max(0,len(nodes)-12)
    ctx=results.get('context')
    if ctx:
        body += ['CORE_PATH='+ctx['core_path'], 'CORE_DIRECT_INSTANCES='+str(ctx['direct_core_instance_count']),
                 'SAVED_VARIABLES_NOT_DECLARED='+','.join(ctx['saved_variables_not_declared'])]
        body += ['TARGET '+n+' master='+i['master']+' nodes='+','.join(i['nodes'])+' parameters='+i['tail'].strip() for n,i in ctx['targets'].items()]
        body += ['SOURCE '+s['path']+' master='+s['master']+' nodes='+','.join(s['nodes'])+' parameters='+s['raw_parameters'] for s in ctx['sources'][:5]]
        omitted += max(0,len(ctx['sources'])-5)
    pd=results.get('pdk')
    if pd:
        body += ['CATALOG_KIND_COUNTS='+json.dumps(pd['kind_counts'],sort_keys=True)]
        for name,info in pd['targets'].items():
            m=info['master']; body += ['CATALOG_TARGET '+name+' master='+m['oa_library']+'/'+m['oa_cell']+' kind='+m['kind'],
                'OTHER_SAME_POLARITY_MASTER_COUNT '+name+'='+str(info['other_same_polarity_count'] if info['other_same_polarity_count'] is not None else 'UNPROVEN')]
            for dev in info['metadata']:
                missing=[k for k in ('maxAbsVgs','maxAbsVds','maxAbsVgb','bulkRule','voltageDomains','rules_source') if not dev.get(k)]
                body += ['PDK_GEOMETRY_CONSTRAINT_KEYS '+name+'='+','.join(sorted(dev.get('constraints',{}))),
                    'PDK_RULE_FIELDS_MISSING '+name+'='+','.join(missing)]
            for row in info['cdf_probe']:
                if row.get('parameter') in ('l','w','fw','nfin','fingers','nf','m','r'):
                    body.append('CACHED_CDF '+name+' '+row['parameter']+' default='+row.get('default_value','')+' min='+row.get('min','')+' max='+row.get('max','')+' choices='+row.get('choices',''))
    ni=results.get('native')
    if ni:
        body += ['DEFINITION_FILES_COUNT='+str(len(ni['definition_files'])),
                 'NATIVE_FIELD_READ_ERRORS='+str(sum(r['status']!='OK' for r in ni['records']))]
        body += ['DEFINITION_FILE='+p for p in ni['definition_files'][:5]]
        omitted += max(0,len(ni['definition_files'])-5)
        for r in ni['records']:
            if r['kind'] in ('cdf_value','cdf_mapping') or (
                    r['kind'] in ('cdf_minVal','cdf_maxVal','cdf_choices','cdf_callback')
                    and r['raw_value'].strip() not in ('nil','""')) or r['status']!='OK':
                body.append('NATIVE_'+r['kind'].upper()+' '+r['scope']+' '+r['name']+'='+
                    ' '.join(r['raw_value'].split())+(' STATUS='+r['status'] if r['status']!='OK' else ''))
    if ctx:
        fmt=lambda i: 'instance='+i['name']+' master='+i['master']+' nodes='+','.join(i['nodes'])+' parameters='+i['tail'].strip()
        body += ['ROOT '+fmt(i) for i in ctx['root_instances'][:18]]
        body += ['TEXT_REFERENCE scope='+i['scope']+' '+fmt(i) for i in ctx['text_references'][:18]]
        body += ['INCLUDE '+i for i in ctx['includes'][:8]]
        body += ['TEXT_REFERENCE_COUNT='+str(len(ctx['text_references']))]
        omitted += max(0,len(ctx['root_instances'])-18)+max(0,len(ctx['text_references'])-18)+max(0,len(ctx['includes'])-8)
    head=['CHECKER=cascode-batch-v1','RESULT='+('COLLECTED' if not errors else 'COLLECTED_WITH_ISSUES')]
    head += ['STAGE_'+n.upper()+'='+states[n] for n in states]
    head += ['ISSUE '+n+'='+v[:500] for n,v in errors.items()]
    head += ['NATIVE_ERROR '+line for line in brief_errors(output)]
    head += ['DC_PROBE='+('CONVERGED' if 'dc' in results else 'NOT_COMPLETED')]
    tail=['SIMULATION_PROFILE_READY=false','SAVED_SIMULATION_OPTIONS_IMPORTED=false','PDK_ELECTRICAL_RULES_READY=false',
        'ELECTRICAL_VERIFIED=false','VBIAS_GENERATED=false','RAW_DETAILS_REMAIN_ON_SERVER=true']
    # Seven phases print START/COMPLETE progress before this summary (14 lines).
    budget=MAX_LINES-14-len(head)-len(tail)-2
    chosen=body[:max(0,budget)]
    shortened=any(len(s)>1000 for s in chosen)
    return head+[s if len(s)<=1000 else s[:1000]+' [DISPLAY_SHORTENED]' for s in chosen]+[
        'DETAIL_ROWS_OMITTED='+str(omitted+len(body)-len(chosen)), 'DISPLAY_SHORTENED='+str(shortened).lower()]+tail


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('session','maestro-read','preflight','output'): parser.add_argument('--'+name,required=True)
    parser.add_argument('--timeout',type=int,default=600)
    args=parser.parse_args(); output=Path(args.output); states={}; results={}; errors={}
    if not output.is_absolute() or output.exists() or args.timeout<=0:
        print('RESULT=INCOMPLETE\nREASON=Output must be new/absolute and timeout positive'); return 2
    output.mkdir(parents=True,exist_ok=False)
    def stage(name, action, dependencies=()):
        print('CHECK_'+name.upper()+'=START',flush=True)
        if any(n not in results for n in dependencies):
            states[name]='SKIPPED'; errors[name]='required prior evidence is incomplete'
        else:
            try:
                results[name]=action(); states[name]='COMPLETE'
            except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError,RecursionError) as error:
                states[name]='INCOMPLETE'; errors[name]=' '.join(str(error).split())
                save(output/(name+'_error.json'),dict(error=errors[name]))
        print('CHECK_'+name.upper()+'='+states[name],flush=True)
    stage('input',lambda:inputs(args))
    stage('context',lambda:context(results['input'],output),('input',))
    stage('pdk',lambda:pdk(results['input'],output),('input',))
    stage('native',lambda:native(results['input'],results['pdk'],output,args.timeout),('input','pdk'))
    stage('dc',lambda:run_dc(results['input'],results['native'],output,args.timeout),('input','context','native'))
    stage('op',lambda:read_op(results['input'],results['context'],results['dc'],output,args.timeout),('input','context','dc'))
    stage('unchanged',lambda:unchanged(results['input']),('input',))
    save(output/'status.json',dict(states=states,errors=errors,electrical_verified=False,vbias_generated=False))
    summary=render(output,states,results,errors)
    (output/'summary.txt').write_text('\n'.join(summary)+'\n'); print('\n'.join(summary))
    return 0 if not errors else 2


if __name__=='__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('RESULT=INTERRUPTED\nDETAILS_RETAINED_ON_SERVER=true',flush=True)
        sys.exit(130)
