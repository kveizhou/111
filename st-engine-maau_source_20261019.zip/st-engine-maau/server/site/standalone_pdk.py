"""Parse the user-supplied raw PDK root, actual OA/CDF probe and model files."""
import csv
import hashlib
import json
import os
from pathlib import Path
import re

from site_data import finite, unit_scale

NUMBER = re.compile(r'^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)([TGMKkmunpf]?)$')


def numeric(text):
    match = NUMBER.fullmatch(str(text))
    if not match:
        raise ValueError('PDK numeric value is an expression or has unknown units: ' + str(text))
    scales = {'': 1, 'T': 1e12, 'G': 1e9, 'M': 1e6, 'K': 1e3, 'k': 1e3,
              'm': 1e-3, 'u': 1e-6, 'n': 1e-9, 'p': 1e-12, 'f': 1e-15}
    return finite(float(match[1]) * scales[match[2]])


def cdf_numeric(text, unit, semantic):
    match = NUMBER.fullmatch(str(text))
    if not match:
        raise ValueError('unproven literal CDF limit')
    # A literal engineering suffix is already an SI value, including native
    # CDF records whose optional units property is empty. Bare dimensions still
    # require an explicit unit; an unknown nonempty unit is never ignored.
    scale = 1 if match[2] and not unit else unit_scale(unit, semantic)
    # Engineering suffixes already express SI. Only plain numbers use the
    # declared unit. Native lengthMetric is SI and accepts 120n/45n strings.
    return numeric(text) * (1 if match[2] else scale)


def model_paths(root, profile):
    pending = set().union(*(set(root.rglob('*' + suffix)) for suffix in ('.scs', '.mdl', '.lib', '.sp', '.model')))
    pending.update(Path(s['model_file']).resolve() for c in profile.get('op_corners', {}).values() for s in c['models'])
    pending.update(Path(p).resolve() for p in profile.get('original_model_files', []))
    seen = set()
    while pending:
        path = pending.pop().resolve()
        if path in seen:
            continue
        if not path.is_file():
            raise ValueError('selected PDK model file missing: ' + str(path))
        seen.add(path)
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeError:
            continue
        for include in re.finditer(r'^\s*\.?include\s+"([^"\n]+)"', text, re.M | re.I):
            value = os.path.expandvars(os.path.expanduser(include[1]))
            if '$' in value:
                raise ValueError('unset PDK include path environment variable: ' + include[1])
            child = Path(value)
            pending.add(child if child.is_absolute() else path.parent / child)
    return sorted(seen)


def model_facts(text, source):
    # Only literal simulator model declarations prove polarity. Never names.
    text = re.sub(r'\\\s*\n\s*|\n\s*\+', ' ', text)
    facts = {}
    for line in text.splitlines():
        line = line.split('//', 1)[0].strip()
        match = re.match(r'^\.?model\s+(\S+)\s+(\w+)\s*(.*)$', line, re.I)
        if not match:
            continue
        name, primitive, tail = match.groups()
        primitive = primitive.lower()
        polarity = re.search(r'\btype\s*=\s*([np])\b', tail, re.I)
        kind = {'nmos': 'mos_n', 'pmos': 'mos_p', 'resistor': 'resistor', 'res': 'resistor', 'r': 'resistor'}.get(primitive)
        if primitive in ('capacitor', 'cap', 'diode', 'bjt', 'npn', 'pnp', 'inductor'):
            kind = 'non_target'
        if not kind and (primitive.startswith('bsim') or primitive in ('mos', 'mos1', 'mos2', 'mos3', 'psp', 'ekv')) and polarity:
            kind = 'mos_' + polarity[1].lower()
        if not kind:
            continue
        limits = {}
        for field, key in [('wmin', 'min_width'), ('wmax', 'max_width'),
                           ('lmin', 'min_length'), ('lmax', 'max_length')]:
            value = re.search(r'\b' + field + r'\s*=\s*([^\s)]+)', tail, re.I)
            if value:
                try:
                    limits[key] = numeric(value[1])
                except ValueError:
                    pass
        if name in facts and facts[name]['kind'] != kind:
            raise ValueError('conflicting actual model polarity: ' + name)
        if name in facts:
            # Common parameter domain must be valid in all scanned declarations.
            old = facts[name]['limits']
            for key, value in limits.items():
                if key in old:
                    value = max(old[key], value) if key.startswith('min_') else min(old[key], value)
                old[key] = value
        else:
            facts[name] = {'kind': kind, 'source': source, 'limits': limits}
    return facts


def build_metadata(root, probe_path, profile, rules, pdk_name=None):
    if profile.get('validation_scope') == 'experimental_dc':
        from experimental_pdk import build_experimental_metadata
        return build_experimental_metadata(root, probe_path, profile, rules, pdk_name)
    if ('experimental_parameter_seeds' in profile or 'experimental_pdk_cache' in profile or profile.get('native_parameter_trials') or
            rules.get('native_parameter_trials') or any(d.get('native_parameter_trials')
            for d in rules.get('devices', {}).values())):
        raise ValueError('native parameter trials require experimental_dc')
    requested = root if isinstance(root, (list, tuple)) else [root]
    aliases = list(dict.fromkeys(str(Path(p).absolute()) for p in requested))
    roots = list(dict.fromkeys(Path(p).resolve() for p in aliases))
    if not roots or any(not p.is_dir() for p in roots):
        raise ValueError('PDK root must be an existing directory')
    paths = sorted(set().union(*(set(model_paths(p, profile)) for p in roots)))
    models, digests, skipped = {}, {}, []
    for path in paths:
        raw = path.read_bytes()
        digests[str(path)] = hashlib.sha256(raw).hexdigest()
        try:
            facts = model_facts(raw.decode('utf-8'), str(path))
        except UnicodeError:
            skipped.append(str(path))
            continue
        for name, fact in facts.items():
            old = models.get(name)
            if old and old['kind'] != fact['kind']:
                raise ValueError('model polarity differs across PDK files: ' + name)
            if old:
                for key, value in fact['limits'].items():
                    if key in old['limits']:
                        value = max(old['limits'][key], value) if key.startswith('min_') else min(old['limits'][key], value)
                    old['limits'][key] = value
            else:
                models[name] = fact
    groups = {}
    with Path(probe_path).open(newline='') as stream:
        for row in csv.DictReader(stream, delimiter='\t'):
            groups.setdefault((row['oa_library'], row['oa_cell']), []).append(row)
    devices, rejected, non_targets = [], [], []
    for (library, cell), rows in sorted(groups.items()):
        identity = rows[0]
        rule = rules.get('devices', {}).get(library + '/' + cell, rules.get('devices', {}).get(cell, {}))
        model = rule.get('model', identity['model_name'])
        fact = models.get(model, {})
        kind = rule.get('kind', fact.get('kind'))
        if rule and not rules.get('source'):
            raise ValueError('PDK rule supplement needs an authoritative source')
        if fact and fact['kind'] != kind:
            raise ValueError('PDK rule/model polarity conflict: ' + cell)
        if kind == 'non_target' and model:
            non_targets.append({'oa_library': library, 'cell': cell, 'model': model,
                'source': fact.get('source', rules.get('source', ''))})
            continue
        if kind not in ('mos_n', 'mos_p', 'resistor'):
            rejected.append({'library': library, 'cell': cell, 'reason': 'no proven actual model type/polarity',
                'model_name': identity['model_name'], 'terminal_names': identity['terminal_names']})
            continue
        if not model:
            rejected.append({'library': library, 'cell': cell, 'reason': 'actual simulator model name missing'})
            continue
        mapping, constraints = {}, {}
        semantics = rule.get('normalized_to_cdf', {'width': 'w', 'length': 'l',
                    'fingers': 'nf', 'multiplier': 'm', 'resistance': 'r'})
        by_parameter = {row['parameter']: row for row in rows if row['parameter']}
        missing = []
        for semantic, parameter in semantics.items():
            row = by_parameter.get(parameter)
            if not row:
                continue
            mapping[semantic] = parameter
            declared = rule.get('constraints', {}).get(semantic)
            if declared:
                domain = dict(declared)
            else:
                try:
                    lo = cdf_numeric(row['min'], row['units'], semantic)
                    hi = cdf_numeric(row['max'], row['units'], semantic)
                except ValueError:
                    # Model validity bounds do not prove physical CDF bounds.
                    continue
                domain = {'min': lo, 'max': hi, 'grid': 0, 'allowed': []}
            lo, hi = finite(domain['min'], True), finite(domain['max'], True)
            lo = max(lo, fact.get('limits', {}).get('min_' + semantic, lo))
            hi = min(hi, fact.get('limits', {}).get('max_' + semantic, hi))
            if lo > hi:
                raise ValueError('empty PDK parameter domain: ' + cell + '/' + parameter)
            domain['min'], domain['max'] = lo, hi
            allowed = domain.get('allowed', [])
            domain['allowed'] = [value for value in allowed if lo <= finite(value, True) <= hi]
            if allowed and not domain['allowed']:
                raise ValueError('empty PDK allowed parameter domain: ' + cell + '/' + parameter)
            domain.setdefault('grid', 0)
            constraints[semantic] = domain
        dev = {'cell': cell, 'oa_library': library, 'model': model, 'kind': kind,
            'normalized_to_cdf': mapping, 'constraints': constraints, 'sim_cdf': rule.get('sim_cdf', {}),
            'dc_signals': rule.get('dc_signals', {'id': 'id', 'vth': 'vth', 'vdsat': 'vdsat', 'cgg': 'cgg', 'vbs': 'vbs'}),
            'signal_postfix': rule.get('signal_postfix', ''),
            'electrical_rules': rule, 'source': fact.get('source', rules.get('source', '')), 'missing': missing,
            'cdf_source': str(probe_path) + ('; documented rules: ' + rules['source'] if rule else '')}
        if rule:
            dev['rules_source'] = rules['source']
        for key in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'bulkRule', 'voltageDomains', 'terminalRoles', 'wFinFormula'):
            if key in rule:
                dev[key] = finite(rule[key], True) if key.startswith('maxAbs') else rule[key]
        if 'maxStackLevel' in rule:
            maximum = finite(rule['maxStackLevel'], True)
            if maximum != int(maximum) or maximum > 2147483647:
                raise ValueError('PDK maxStackLevel must be a positive integer: ' + cell)
            dev['maxStackLevel'] = int(maximum)
        if 'sourceDrainInterchangeable' in rule:
            if not isinstance(rule['sourceDrainInterchangeable'], bool):
                raise ValueError('PDK sourceDrainInterchangeable must be boolean: ' + cell)
            dev['sourceDrainInterchangeable'] = rule['sourceDrainInterchangeable']
        if kind != 'resistor':
            if not all(k in dev for k in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb')): missing.append('reliability')
            if not dev.get('bulkRule'): missing.append('bulk')
        if not dev.get('voltageDomains'): missing.append('voltage_domain')
        required_constraints = ('resistance',) if kind == 'resistor' else ('width', 'length')
        if not all(key in constraints for key in required_constraints): missing.append('cdf_constraints')
        devices.append(dev)
    if not devices:
        raise ValueError('no proven MOS/resistor masters in this PDK; see actual model/CDF or supply documented rules')
    corners = [{'name': name, 'sections': value['models']} for name, value in profile.get('op_corners', {}).items()]
    digest = hashlib.sha256(json.dumps({'roots': [str(p) for p in roots], 'models': digests, 'probe': Path(probe_path).read_text(),
        'rules': rules, 'profile': profile}, sort_keys=True).encode()).hexdigest()
    return {'tech_name': pdk_name or roots[0].name, 'pdk_name': pdk_name or roots[0].name,
        'pdk_paths': [str(p) for p in roots],
        'pdk_alias_paths': aliases, 'version': 'scan-sha256:' + digest,
        'source': str(probe_path), 'corners': corners, 'temperatures': [], 'devices': devices,
        'model_file_sha256': digests, 'rejected_devices': rejected, 'unreadable_model_files': skipped,
        'non_target_devices': non_targets}
