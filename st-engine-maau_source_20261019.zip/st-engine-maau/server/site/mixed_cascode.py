"""Admit already used MOS masters for the four-group functional test.

Read the existing OA/CDF probe, original OA instances and saved PSF. Never
infer polarity from a name, rerun baseline DC, or admit a CDF default as a seed.
"""
import copy
import csv
import json
import os
from pathlib import Path
import re
import sys
import tempfile

from dc_results import canonical_device, consume_query, focused_op_script, node_context_script
from experiment_bindings import digest, polarity, terminal_order, value
from run_cascode_experiment import ROOT, pairs, operation_catalog, prepare_mixed_four, make_commands, run_stage
from site_data import read_json, write_json

CMG_SIGNALS = dict(id='id', vth='vth', vdsat='vdssat', cgg='cgg',
                   intrinsic_vgs='vgs', intrinsic_vds='vds')


def table(path):
    with Path(path).open(newline='') as stream:
        return list(csv.DictReader(stream, delimiter='\t'))


def check_undo_pair(work, indices=('01', '02')):
    """Use an existing prepared pair without native discovery."""
    work = Path(work)
    folder = work/'test_operations/mixed_four'
    same, cross = (pairs(folder/(index+'.conf')) for index in indices)
    if (same.get('type') != 'same_type_cascode' or
            cross.get('type') != 'cross_flavor_cascode' or
            not same.get('id') or not cross.get('id') or same['id'] == cross['id'] or
            not same.get('instance') or not cross.get('instance') or
            same['instance'] == cross['instance']):
        raise ValueError('expected two distinct targets: same-type then cross-flavor')
    from run_cascode_experiment import admitted_cross_devices
    rows, devices = operation_catalog(work)
    targets = {r['instance']: r for r in rows}
    for op in (same, cross):
        if op['instance'] not in targets:
            raise ValueError('prepared target missing from current inventory: '+op['instance'])
    if cross.get('new_master') not in {
            d['master'] for d in admitted_cross_devices(targets[cross['instance']], devices)}:
        raise ValueError('prepared cross-flavor master is not admitted for this target')
    return same, cross


def verify_same_after_undo(work):
    """Check the generated OA readback, not merely the planned operation count."""
    from op_provider import parse_deck
    work = Path(work)
    same, cross = check_undo_pair(work)
    root = pairs(work/'session.conf')['core_subckt']
    before = parse_deck((work/'before/core_before.scs').read_text())
    actual = parse_deck((work/'analysis/variant_op/roundtrip/complete.scs').read_text())
    def instances(deck, name):
        return {i['name']: i for i in deck['definitions'][name]['instances']}
    original, parent = instances(before, root), instances(actual, root)
    kept, undone = same['instance'], cross['instance']
    restored = parent[undone]
    if (restored['master'], restored['nodes']) != (original[undone]['master'], original[undone]['nodes']):
        raise ValueError('undone target master or terminal connections differ: '+undone)
    # The wrapper must contain exactly the original MOS and its same-type CAS.
    wrapper = parent[kept]
    child = actual['definitions'][wrapper['master']]
    members = instances(actual, wrapper['master'])
    if set(members) != {kept, kept+'_CAS'}:
        raise ValueError('unexpected retained Cascode wrapper members')
    if len(child['ports']) != len(wrapper['nodes']):
        raise ValueError('retained wrapper port count mismatch')
    ports = dict(zip(child['ports'], wrapper['nodes']))
    _, devices = operation_catalog(work)
    master = original[kept]['master']
    roles = devices[master]['terminal_roles']
    if len(roles) != 4 or set(roles) != {'drain','gate','source','bulk'}:
        raise ValueError('four MOS terminal roles are required')
    def terminals(inst, mapped=False):
        if inst['master'] != master or len(inst['nodes']) != 4:
            raise ValueError('retained original/Cascode master or terminals differ')
        # Qualify internal nets so a local name cannot masquerade as a parent net.
        return dict(zip(roles, (ports.get(n, (wrapper['name'], n)) if mapped else n
                               for n in inst['nodes'])))
    old = terminals(original[kept])
    ctrl, cas = terminals(members[kept], True), terminals(members[kept+'_CAS'], True)
    if (any(ctrl[r] != old[r] for r in ('gate','source','bulk')) or
            ctrl['drain'] == old['drain'] or cas['source'] != ctrl['drain'] or
            cas['drain'] != old['drain']):
        raise ValueError('retained Cascode is not on D side with original G/S/B preserved')
    forbidden = {undone+'_CAS', 'I_VBIAS_N_'+undone, 'I_VBIAS_P_'+undone}
    if any(i['name'].lstrip('_') in forbidden for d in actual['definitions'].values() for i in d['instances']):
        raise ValueError('undone target still has Cascode/VBIAS instances')
    print('SAME_CASCODE_D_SIDE=PASS\nORIGINAL_GSB_PRESERVED=PASS')
    print('UNDONE_TARGET_RESTORED='+undone+'\nUNDONE_CASCODE_VBIAS_ABSENT=PASS')
    print('FINAL_RETAINED=same_type_cascode:'+kept,flush=True)


def prepare_combo(work, alternate=False):
    """Prepare the requested sequence from the existing four bound targets."""
    from experimental_pdk import finite
    work = Path(work)
    same, cross = check_undo_pair(work, ('03', '04') if alternate else ('01', '02'))
    folder = work/'test_operations/mixed_four'
    other_indices = ('02', '01') if alternate else ('03', '04')
    resistor_target, stack_target = (pairs(folder/(i+'.conf'))['instance'] for i in other_indices)
    names = [same['instance'], cross['instance'], resistor_target, stack_target]
    rows, devices = operation_catalog(work)
    targets = {r['instance']:r for r in rows}
    if len(set(names)) != 4 or any(n not in targets for n in names):
        raise ValueError('combined test requires four distinct bound MOS targets')
    for name in names:
        row = targets[name]
        dev = devices[row['master']]
        if (dev['kind'] != row['polarity'] or not dev['bulk_rule_complete'] or
                not all(row.get(k) for k in ('drain','gate','source','bulk'))):
            raise ValueError('target terminal/polarity/Bulk binding incomplete: '+name)
    manifest = read_json(work/'analysis/standalone_inputs/provider_inputs.json')
    selected = [d for tech in read_json(manifest['tech']) for d in tech['devices']
                if d.get('kind') == 'resistor' and d.get('native_parameter_trials')]
    if len(selected) != 1:
        raise ValueError('one already bound native resistor seed is required')
    seed = selected[0]
    matches = [d for d in devices.values() if d['kind'] == 'resistor' and
               d.get('oa_library') == seed['oa_library'] and d.get('oa_cell') == seed['cell']]
    if len(matches) != 1 or set(matches[0]['terminal_roles']) != {'positive','negative'}:
        raise ValueError('selected resistor must match the bound two-terminal master')
    resistance = finite(seed['actual_parameter_seed']['resistance'], True)
    resistor = {'id':'test_resistor_'+resistor_target, 'type':'resistor', 'instance':resistor_target,
                'resistor.master':matches[0]['master'],
                'resistor.parameter':seed['normalized_to_cdf']['resistance'],
                'resistor.value':format(resistance, '.17g'), 'resistor.grid':'0'}
    row = targets[stack_target]
    stack = {'id':'test_stack_'+stack_target, 'type':'stack', 'instance':stack_target,
             'stage_count':'2', 'gate_policy':'shared', 'intent':'effective_length',
             'tie_isolated_pmos_to_source':'false'}
    if row['polarity'] == 'mos_n':
        stack['nmos_bulk_net'] = row['bulk']
    domain = devices[row['master']].get('voltage_domain')
    if domain:
        stack['voltage_domain'] = domain
    output = work/'test_operations/combined_features'
    output.mkdir(parents=True, exist_ok=True)
    for filename, op in [('resistor.conf',resistor),('01.conf',same),('02.conf',cross),('03.conf',stack)]:
        (output/filename).write_text(''.join(k+'='+v+'\n' for k,v in op.items()))
    print('TEST_SEQUENCE=resistor,undo_resistor,same,cross,stack,generate')
    print('RESISTOR_UNDO_TARGET='+resistor_target+'\nSAME_TARGET='+same['instance']+
          '\nCROSS_TARGET='+cross['instance']+'\nSTACK_TARGET='+stack_target)
    print('STACK_STAGES=2\nINTERMEDIATE_DC_SEARCHES=0',flush=True)


def verify_combo(work):
    """Validate actual final OA connections; generation owns the DC verdict."""
    from op_provider import parse_deck, physical_signature, same_parameter_value
    work = Path(work)
    folder = work/'test_operations/combined_features'
    resistor, same, cross, stack = (pairs(folder/f) for f in ('resistor.conf','01.conf','02.conf','03.conf'))
    session = pairs(work/'session.conf')
    root = session['core_subckt']
    before = parse_deck((work/'before/core_before.scs').read_text())
    actual = parse_deck((work/'analysis/variant_op/roundtrip/complete.scs').read_text())
    _, devices = operation_catalog(work)
    def members(deck, name):
        return {i['name']:i for i in deck['definitions'][name]['instances']}
    original, parent = members(before,root), members(actual,root)
    def unchanged_parameters(old, new):
        a,b = (physical_signature(dict(i,parameters={}))[2] for i in (old,new))
        if any(k not in b or not same_parameter_value(v,b[k]) for k,v in a.items()):
            raise ValueError('original MOS parameters changed: '+old['name'])
    def terminals(inst, ports=None):
        roles = devices[inst['master']]['terminal_roles']
        if len(inst['nodes']) != 4 or len(roles) != 4 or set(roles) != {'drain','gate','source','bulk'}:
            raise ValueError('four MOS terminal roles required: '+inst['name'])
        return dict(zip(roles,(ports.get(n,('internal',n)) if ports is not None else n for n in inst['nodes'])))
    undone = resistor['instance']
    if (parent[undone]['master'],parent[undone]['nodes']) != (original[undone]['master'],original[undone]['nodes']):
        raise ValueError('undone resistor target master/connections not restored: '+undone)
    unchanged_parameters(original[undone],parent[undone])
    if any(i['name'].lstrip('_').startswith(undone+'_RS') for d in actual['definitions'].values() for i in d['instances']):
        raise ValueError('undone source resistor remains in generated circuit')
    for op in (same,cross,stack):
        name = op['instance']; old = original[name]; wrapper = parent[name]
        child = actual['definitions'][wrapper['master']]
        if len(child['ports']) != len(wrapper['nodes']):
            raise ValueError('wrapper port count mismatch: '+name)
        ports = dict(zip(child['ports'],wrapper['nodes']))
        inside = members(actual,wrapper['master'])
        base = terminals(old); ctrl = terminals(inside[name],ports)
        if inside[name]['master'] != old['master']:
            raise ValueError('original MOS master changed: '+name)
        unchanged_parameters(old,inside[name])
        if op['type'] == 'stack':
            if len(inside) != 2 or op.get('stage_count') != '2':
                raise ValueError('expected exactly two Stack stages')
            added = next(i for n,i in inside.items() if n != name)
            extra = terminals(added,ports)
            unchanged_parameters(old,added)
            if (added['master'] != old['master'] or ctrl['drain'] != base['drain'] or
                    extra['drain'] != ctrl['source'] or extra['source'] != base['source'] or
                    not isinstance(ctrl['source'],tuple) or
                    any(t[r] != base[r] for t in (ctrl,extra) for r in ('gate','bulk'))):
                raise ValueError('Stack series/Gate/Bulk connections or master differ')
            continue
        if set(inside) != {name,name+'_CAS'}:
            raise ValueError('unexpected Cascode members: '+name)
        cas_inst = inside[name+'_CAS']; cas = terminals(cas_inst,ports)
        expected_master = old['master'] if op['type']=='same_type_cascode' else op['new_master']
        if (cas_inst['master'] != expected_master or
                devices[expected_master]['kind'] != devices[old['master']]['kind'] or
                any(ctrl[r] != base[r] for r in ('gate','source','bulk')) or
                not isinstance(ctrl['drain'],tuple) or cas['source'] != ctrl['drain'] or cas['drain'] != base['drain']):
            raise ValueError('Cascode Master/D-side/original GSB mismatch: '+name)
        expected_bulk = (cas['source'] if devices[expected_master]['kind']=='mos_p' and
                         devices[expected_master].get('isolated_well') and op.get('tie_isolated_pmos_to_source')=='true'
                         else op.get('nmos_bulk_net',base['bulk']))
        if cas['bulk'] != expected_bulk:
            raise ValueError('Cascode Bulk connection mismatch: '+name)
        polarity = 'N' if devices[old['master']]['kind']=='mos_n' else 'P'
        biases = [i for i in parent.values() if i['name'].lstrip('_')=='I_VBIAS_'+polarity+'_'+name]
        if len(biases) != 1:
            raise ValueError('unique VBIAS instance missing: '+name)
        bias = biases[0]; definition = actual['definitions'][bias['master']]
        bp = dict(zip(definition['ports'],bias['nodes']))
        if (len(definition['ports']) != len(bias['nodes']) or bp.get('VBIAS_'+polarity) != cas['gate'] or
                bp.get('VG_CTRL') != base['gate'] or bp.get('VS_ORIG') != base['source'] or
                bp.get('VHIGH') != session['vbias_vhigh_net'] or bp.get('VLOW') != session['vbias_vlow_net']):
            raise ValueError('VBIAS output/control/source/supply binding mismatch: '+name)
    print('RESISTOR_UNDO_RESTORED=PASS TARGET='+undone)
    print('SAME_CASCODE_D_SIDE=PASS TARGET='+same['instance'])
    print('CROSS_CASCODE_D_SIDE=PASS TARGET='+cross['instance'])
    print('ORIGINAL_GSB_PRESERVED=PASS\nVBIAS_CONNECTIONS=PASS')
    print('STACK_SERIES_SHARED_GATE=PASS TARGET='+stack['instance']+' STAGES=2')


def unchanged_targets(original, current, names):
    """The new catalog must not turn a changed source target into cached DC."""
    from op_provider import parse_deck, physical_signature, same_parameter_value
    def read(work):
        deck=parse_deck((work/'before/core_before.scs').read_text())
        core=deck['definitions'][pairs(work/'session.conf')['core_subckt']]
        parameters=dict(deck['parameters'],**core['parameters'])
        return {d['name']:physical_signature(dict(d,parameters=parameters)) for d in core['instances'] if d['name'] in names}
    before,after=read(original),read(current)
    for name in names:
        if name not in before or name not in after:
            raise ValueError('source target missing after catalog expansion: '+name)
        a,b=before[name],after[name]
        if a[:2]!=b[:2] or set(a[2])!=set(b[2]) or any(
                not same_parameter_value(a[2][k],b[2][k]) for k in a[2]):
            raise ValueError('source target changed; saved baseline cannot be reused: '+name)


def select_used_masters(work, directory, bundle, probe):
    from op_provider import flatten_dut, read_oa_bindings, expand_physical_bindings, physical_instance_key
    inventory, devices = operation_catalog(work)
    targets = {r['instance']: r for r in inventory
               if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', r['instance']) and r['polarity'] in ('mos_n', 'mos_p')}
    for kind in ('mos_n', 'mos_p'):
        if sum(r['polarity'] == kind for r in targets.values()) < 2:
            raise ValueError('four-group test needs two scalar targets of each polarity: '+kind)
    groups = {}
    for row in table(probe):
        groups.setdefault(row['oa_library']+'/'+row['oa_cell'], []).append(row)
    bindings = expand_physical_bindings(read_oa_bindings(directory/'oa_bindings.tsv'))
    ports = {}
    leaves = flatten_dut((directory/'simulation.scs').read_text(), bundle['root_path'],
                         bundle['source']['cell'], port_bindings=ports)
    selected, alternatives = [], {}
    admitted = {(d['oa_library'], d['oa_cell']) for d in devices.values()}
    models = {d['model_name'] for d in devices.values() if d['kind'] in ('mos_n', 'mos_p')}
    for leaf in leaves:
        name = physical_instance_key(leaf['path'][len(bundle['root_path'])+1:])
        proof = bindings.get(name)
        if not proof:
            continue
        key = proof['oa_library']+'/'+proof['oa_cell']
        rows = groups.get(key, [])
        if (not rows or rows[0]['has_schematic'] != 'false' or
                set(proof['terminal_names']) != {'D','G','S','B'} or
                len(proof['terminal_names']) != 4 or len(leaf['nodes']) != 4 or
                proof['model_name'] != leaf['master']):
            continue
        entry = dict(name=name, oa_path=proof['oa_instance_name'], key=key,
                     path=canonical_device(leaf['path']), model=leaf['master'],
                     terminal_names=proof['terminal_names'], nodes=leaf['nodes'],
                     required_kind=targets.get(name, {}).get('polarity'), probe=rows)
        if name in targets:
            selected.append(entry)
        elif (proof['oa_library'], proof['oa_cell']) not in admitted:
            alternatives.setdefault(key, entry)
    if {e['name'] for e in selected} != set(targets):
        raise ValueError('original target OA/netlist binding incomplete')
    # Prefer already simulated models from the bound set. This is only a
    # bounded ordering; the native TYPE and OP report still decide admission.
    options = sorted(alternatives.values(), key=lambda e:(e['model'] not in models, e['key']))[:8]
    if not options:
        raise ValueError('saved source/probe has no different used MOS master to admit')
    for index, entry in enumerate(selected+options):
        entry['scope'] = 'mos_'+str(index)
    return selected, options, ports


def native_script(bundle, entries, psf, init, output):
    q = json.dumps
    query = dict(schema='st-dc-query-v1', nodes=sorted({n for e in entries for n in e['nodes']}),
                 device_parameters={e['path']:list(CMG_SIGNALS.values()) for e in entries}, currents=[])
    code = node_context_script(psf, query, init, output/'nodes.tsv', finish=False)
    code += focused_op_script(psf, list(query['device_parameters']), init, output/'ops.tsv', finish=False, exact=True)
    code += r'''
procedure(stMixedRecord(port kind scope name result)
  if(result then
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tOK\t%L\n" kind scope name car(result))
  else
    fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tREAD_ERROR\tnil\n" kind scope name))
)
procedure(stMixedInstance(port scope parts library cell view fullPath modelFile)
  let((cv inst found opened cdf term param key spectre result modelPair model)
    result=errset(prog( ()
      cv=dbOpenCellViewByType(library cell view "" "r")
      unless(cv error("Cannot read source OA"))
      opened=cons(cv opened)
      while(parts
        found=nil
        foreach(inst cv~>instances when(equal(inst~>name car(parts)) found=inst))
        unless(found error("Source OA path missing: %L" parts))
        parts=cdr(parts)
        when(parts
          cv=dbOpenCellViewByType(found~>master~>libName found~>master~>cellName "schematic" "" "r")
          unless(cv error("Source hierarchy missing"))
          opened=cons(cv opened)))
      inst=found
      stMixedRecord(port "source" scope "oa_library" list(inst~>master~>libName))
      stMixedRecord(port "source" scope "oa_cell" list(inst~>master~>cellName))
      stMixedRecord(port "source" scope "oa_view" list(inst~>master~>viewName))
      cdf=cdfGetInstCDF(inst)
      unless(cdf error("Instance CDF missing"))
      foreach(param cdf->parameters
        stMixedRecord(port "cdf_value" scope param->name list(param->value)))
      foreach(term inst~>instTerms
        stMixedRecord(port "terminal" scope term~>term~>name list(term~>net~>name)))
      spectre=cdf->simInfo->spectre
      foreach(key list("termOrder" "termMapping" "instParameters" "propMapping")
        stMixedRecord(port "cdf_mapping" scope key errset(get(spectre concat(key)) t)))
      selectResult('dcOpInfo)
      unless(equal(length(stMixedSignals[fullPath]) 1)
        error("Unique saved OP instance name missing"))
      modelPair=errset(ocnGetInstancesModelName(car(stMixedSignals[fullPath])) t)
      stMixedRecord(port "model_binding" scope "instance_model" modelPair)
      unless(and(modelPair listp(car(modelPair)) stringp(caar(modelPair))
                 equal(stFocusName(caar(modelPair)) fullPath) stringp(cadar(modelPair)))
        error("Exact saved model binding missing"))
      model=cadar(modelPair)
      stMixedRecord(port "model_type" scope "type" errset(pv(model "type" ?result 'model) t))
      selectResult('model)
      report(?name model ?param "type" ?output modelFile)
      return(t)
    ) t)
    foreach(cv opened dbClose(cv))
    stMixedRecord(port "read_status" scope "complete" list(if(and(result car(result)) then "OK" else "FAILED")))
    selectResult('dcOpInfo)
  )
)
'''
    code += '''result=errset(prog( ()
  stNodeRead()
  stFocusRead()
  stMixedSignals=makeTable('stMixedSignals nil)
  foreach(kind dataTypes()
    foreach(signal outputs(?type kind ?map nil)
      when(stFocusTargetP(signal)
        key=stFocusName(signal)
        stMixedSignals[key]=cons(signal stMixedSignals[key]))))
  port=outfile('''+q(str(output/'native.tsv'))+')\n'
    for entry in entries:
        # OA uses an array's declared name; the PSF uses its scalar bit path.
        parts = 'list('+' '.join(q(x) for x in entry['oa_path'].split('.'))+')'
        code += '  stMixedInstance(port '+q(entry['scope'])+' '+parts+' '+ ' '.join(q(bundle['source'][k]) for k in ('lib','cell','view'))+' '+q(entry['path'])+' '+q(str(output/(entry['scope']+'_model_type.txt')))+')\n'
    code += '  fprintf(port "ST_MAESTRO_SETUP_READ_COMPLETE\\n") close(port)\n  return(t)\n) t)\n'
    code += 'when(and(result car(result)) port=outfile('+q(str(output/'runtime.done'))+') fprintf(port "OK\\n") close(port))\nexit()\n'
    return code


def validate_entry(entry, records, nodes, ops, ports, profile, output):
    scope = entry['scope']
    if value(records, 'read_status', scope, 'complete') != 'OK':
        raise ValueError('native instance/model read failed')
    if '/'.join(value(records,'source',scope,k) for k in ('oa_library','oa_cell')) != entry['key']:
        raise ValueError('actual master differs from retained binding')
    model_fields = [key for key in ('model','modelName') if any(
        r['scope']==scope and r['kind']=='cdf_value' and r['name']==key for r in records)]
    if not model_fields or any(value(records,'cdf_value',scope,key) != entry['model'] for key in model_fields):
        raise ValueError('actual CDF model differs from retained netlist')
    if terminal_order(value(records,'cdf_mapping',scope,'termOrder')) != entry['terminal_names']:
        raise ValueError('actual CDF terminal order differs')
    pair = re.findall(r'"(?:\\.|[^"\\])*"', str(value(records,'model_binding',scope,'instance_model')))
    report = (output/(scope+'_model_type.txt')).read_text()
    if len(pair) != 2 or canonical_device(json.loads(pair[0])) != entry['path'] or json.loads(pair[1]) not in [line.strip() for line in report.splitlines()]:
        raise ValueError('native model report is not bound to exact instance')
    kind = polarity(value(records,'model_type',scope,'type'), report)
    if entry.get('required_kind') and entry['required_kind'] != kind:
        raise ValueError('target polarity changed')
    rail = profile['vbias_vlow_net' if kind == 'mos_n' else 'vbias_vhigh_net']
    bulk = entry['nodes'][entry['terminal_names'].index('B')]
    if rail not in ports or bulk != ports[rail]:
        raise ValueError('used instance bulk does not match template rail')
    query = dict(schema='st-dc-query-v1',nodes=sorted(set(entry['nodes'])),
                 device_parameters={entry['path']:list(CMG_SIGNALS.values())},currents=[])
    raw, sources = consume_query(query, [r for r in nodes if r['signal'] in query['nodes']],
                                [r for r in ops if canonical_device(r['signal']) == entry['path']])
    if any(sources[entry['path']+':'+p]['device_type'] != 'bsimcmg' for p in CMG_SIGNALS.values()):
        raise ValueError('this admission path requires measured CMG OP semantics')
    parameters = {r['parameter'] for r in entry['probe']}
    mapping = {}
    for semantic, choices in [('length',('l',)),('fin',('nfin',)),('fingers',('fingers','nf')),('multiplier',('m',))]:
        found = next((p for p in choices if p in parameters), None)
        if found:
            mapping[semantic] = found
    if 'fin' not in mapping and 'w' in parameters:
        mapping['width'] = 'w'
    if 'length' not in mapping or not ({'fin','width'} & mapping.keys()):
        raise ValueError('physical length/fin/width CDF mapping missing')
    rule = dict(kind=kind,model=entry['model'],normalized_to_cdf=mapping,bulkRule='rail',
                terminalRoles={'D':'drain','G':'gate','S':'source','B':'bulk'},
                dc_signals=dict(CMG_SIGNALS),signal_postfix='',
                bulk_binding=dict(template_port=rail,resolved_node=bulk,method='used_native_instance'))
    seed = dict(instance=scope,native_records=str(output/'native_records.json'),
                native_records_sha256=digest(output/'native_records.json'))
    return rule, seed, raw, sources


def prepare(candidate):
    from baseline_bundle import load_bundle
    from standalone import environment, validate_bundle_profile
    from collect_cascode_batch import executable, command
    from read_maestro_setup import read_records
    from experimental_pdk import build_experimental_metadata
    candidate = Path(candidate).resolve(); work = candidate/'work'
    pointer = work/'test_operations/mixed_four/candidate.txt'
    if pointer.is_file():
        destination = Path(pointer.read_text().strip())
        prepare_mixed_four(destination/'work')
        print('MIXED_TEST_SESSION_REUSED=true\nMIXED_TEST_CANDIDATE='+str(destination),flush=True)
        return destination
    # Already sufficient catalogs keep their existing tested path.
    from run_cascode_experiment import admitted_cross_devices
    inventory, catalog = operation_catalog(work)
    if all(any(r['polarity']==kind and admitted_cross_devices(r,catalog) for r in inventory) for kind in ('mos_n','mos_p')):
        prepare_mixed_four(work)
        return candidate
    manifest_path = work/'analysis/standalone_inputs/provider_inputs.json'
    manifest = read_json(manifest_path); profile = read_json(manifest['rules']); cfg = pairs(work/'session.conf')
    if profile.get('validation_scope') != 'experimental_dc':
        raise ValueError('automatic used-master admission requires experimental_dc')
    bundle = load_bundle(profile['validated_baseline_bundle'],runtime_inputs=manifest)
    validate_bundle_profile(bundle, profile)
    if [cfg['source_'+k] for k in ('library','cell','view')] != [bundle['source'][k] for k in ('lib','cell','view')]:
        raise ValueError('mixed test source differs from accepted baseline')
    retained = list((work/'analysis/baseline_op/raw_op').glob('st-op-simulation.*/binding.json'))
    if not retained:
        raise ValueError('retained original export missing')
    directory = max(retained,key=lambda p:p.stat().st_mtime_ns).parent
    binding = read_json(directory/'binding.json')
    if binding['dut'] != [bundle['source'][k] for k in ('lib','cell','view')] or binding['root_path'] != bundle['root_path']:
        raise ValueError('retained export is not the original source')
    from op_provider import flatten_dut, physical_signature
    def signature(text, master):
        return {d['path']:physical_signature(d) for d in flatten_dut(text,bundle['root_path'],master)}
    if signature((directory/'simulation.scs').read_text(),bundle['source']['cell']) != signature(Path(bundle['bench_netlist']).read_text(),bundle['source_subckt']):
        raise ValueError('retained source differs from accepted baseline')
    cache = profile['experimental_pdk_cache']; probe = Path(cache['probe'])
    if digest(probe) != cache['probe_sha256']:
        raise ValueError('cached PDK probe changed')
    targets, options, ports = select_used_masters(work,directory,bundle,probe)
    output = Path(tempfile.mkdtemp(prefix='mixed_four_',dir=str(candidate)))
    native = output/'admission'; native.mkdir()
    print('MIXED_ADMISSION=START\nPDK_PROBE_REUSED=true\nBASELINE_SPECTRE_RERUN=false',flush=True)
    print('USED_ALTERNATIVE_MASTERS='+str(len(options)),flush=True)
    info = list((Path(bundle['_bundle_path']).parent.parent.parent/'baseline_results').rglob('dcOpInfo.info'))
    if len(info) != 1:
        raise ValueError('unique accepted baseline PSF missing')
    (native/'cds.lib').write_text('INCLUDE '+json.dumps(bundle['cds_lib'])+'\n')
    action = native/'read.ocn'; action.write_text(native_script(bundle,targets+options,info[0].parent,manifest['init'],native))
    env = environment(manifest,manifest_path); env.pop('ST_PREPARED_JSON_FILE',None)
    print('MIXED_NATIVE_LOG='+str(native/'ocean.log'),flush=True)
    command([executable(env,'ST_OCEAN_BIN','ocean'),'-nograph','-restore',str(action)],native,env,240,native/'ocean.log')
    if not (native/'runtime.done').is_file() or (native/'runtime.done').read_text().strip() != 'OK':
        raise ValueError('native admission read incomplete; '+str(native/'ocean.log'))
    records = read_records((native/'native.tsv').read_text());write_json(native/'native_records.json',records)
    nodes, ops = table(native/'nodes.tsv'), table(native/'ops.tsv')
    techs = read_json(manifest['tech'])
    tech = next(t for t in techs if t['version']==cfg['pdk_version'])
    rules = dict(source=str(native/'native_records.json'),devices={d['oa_library']+'/'+d['cell']:copy.deepcopy(d['electrical_rules']) for d in tech['devices']})
    profile = copy.deepcopy(profile)
    additional = {r['polarity']:r['master'] for r in inventory
                  if admitted_cross_devices(r,catalog)}
    raw = {}; sources = {}; valid_targets=[]
    for entry in targets+options:
        try:
            rule,seed,values,origins = validate_entry(entry,records,nodes,ops,ports,profile,native)
            if entry in targets:
                # Keep the original master policy and seed, adding only tuples
                # actually read for copying these original control devices.
                profile.setdefault('experimental_preserved_seeds',{}).setdefault(entry['key'],[]).append(seed)
                valid_targets.append(entry['name']);raw.update(values);sources.update(origins)
            elif rule['kind'] not in additional:
                trial_profile=copy.deepcopy(profile); trial_rules=copy.deepcopy(rules)
                trial_profile['experimental_parameter_seeds'][entry['key']]=seed
                trial_rules['devices'][entry['key']]=rule
                build_experimental_metadata(cache['pdk_roots'],probe,trial_profile,trial_rules)
                profile,rules=trial_profile,trial_rules;additional[rule['kind']]=entry['key']
                print('ADMITTED_CROSS_MASTER polarity='+rule['kind']+' master='+entry['key'],flush=True)
        except (OSError,ValueError,KeyError,TypeError) as error:
            print('MASTER_NOT_ADMITTED='+entry['key']+' instance='+entry['name']+' reason='+str(error),flush=True)
    if set(additional) != {'mos_n','mos_p'} or any(sum(e['name'] in valid_targets and e['required_kind']==k for e in targets)<2 for k in ('mos_n','mos_p')):
        raise ValueError('saved evidence cannot admit two scalar targets and an alternative for each polarity')
    dc = native/'baseline_targets.json'
    write_json(dc,dict(source=bundle['source'],bundle=profile['validated_baseline_bundle'],raw=raw,sources=sources))
    profile['experimental_mixed_targets']=valid_targets
    profile['experimental_source_export']=str(directory)
    profile['experimental_source_dc']=str(dc)
    profile_path=output/'simulation_profile.json';rules_path=output/'pdk_facts.json'
    write_json(profile_path,profile);write_json(rules_path,rules)
    config=dict(source=bundle['source'],bench=bundle['bench'],cds_lib=bundle['cds_lib'],
                core_subckt=cfg['core_subckt'],target='mixed',profile=str(profile_path),rules=str(rules_path))
    for stage,argv in make_commands(config,output,prepare_only=True):
        run_stage(stage,argv,output,300,dict(os.environ,ST_SKILL_INIT=manifest['init']))
    unchanged_targets(work,output/'work',valid_targets)
    prepare_mixed_four(output/'work')
    pointer.parent.mkdir(parents=True,exist_ok=True);pointer.write_text(str(output)+'\n')
    print('MIXED_ADMISSION=PASS\nMIXED_ADMISSION_NATIVE_READS=1\nMIXED_TEST_CANDIDATE='+str(output),flush=True)
    return output


if __name__ == '__main__':
    try:
        if len(sys.argv)!=2:
            raise ValueError('expected original candidate directory')
        prepare(sys.argv[1])
    except (OSError,ValueError,KeyError,TypeError,RuntimeError) as error:
        print('MIXED_ADMISSION=INCOMPLETE\nISSUE='+str(error),flush=True)
        sys.exit(2)
