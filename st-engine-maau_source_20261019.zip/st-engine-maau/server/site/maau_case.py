#!/usr/bin/env python3
"""Import a real Maau Case, then invoke the existing structure-transform CLI.

The imported selection and real provider inputs are kept in the session.
Explicit CLI inputs that contradict the imported Case are refused.
"""
import argparse
import os
from pathlib import Path
import subprocess
import sys

from maau_config import (inspect_defaults, load_tech_config, merge_explicit, read_json,
                         write_json, write_metadata, pin_site_inputs, verify_site_inputs)

ROOT = Path(__file__).resolve().parents[2]


def explicit_options(arguments):
    if len(arguments) % 2:
        raise ValueError('CLI options must be --key value pairs')
    out = {}
    for index in range(0, len(arguments), 2):
        key = arguments[index]
        if not key.startswith('--') or key[2:] in out:
            raise ValueError('invalid or duplicate CLI option: ' + key)
        out[key[2:]] = arguments[index + 1]
    return out


def provider_environment(inputs):
    environment = dict(os.environ)
    environment.update({'ST_SITE_CASE_CONTEXT': inputs['context'],
                        'ST_SITE_CASE_RULES': inputs['rules'],
                        'ST_SITE_TECH_METADATA': inputs['tech'],
                        'ST_MAAU_RUNTIME_BIN': inputs['runtime'],
                        'ST_PDK_TECH_ADAPTER': inputs['adapter'],
                        'ST_SITE_INPUTS_MANIFEST': str(Path(inputs['context']).parent / 'provider_inputs.json'),
                        'ST_OP_PROVIDER_BIN': str(ROOT / 'server/site/maau_op.py')})
    return environment


def validate_inputs(inputs):
    for key, value in inputs.items():
        if key not in ('runtime', 'context', 'rules', 'tech', 'adapter'):
            continue
        if not Path(value).is_absolute() or not Path(value).is_file():
            raise ValueError('missing real site input ' + key + ': ' + value)
    if not os.access(inputs['runtime'], os.X_OK):
        raise ValueError('native runtime is not executable')


def prepare_tech(context, rules, tech_root, tech_config, pdk_rules, archive):
    side = rules.get('design_side', 'source')
    tech_name = context.get(side + '_tech_name', '')
    if tech_config is None:
        if not tech_root or not tech_name:
            raise ValueError('imported Case tech name and TECH_ROOT_PATH (or --tech-config) are required')
        tech_config = Path(tech_root) / tech_name / 'tech_cfg_v2.0.json'
    config = load_tech_config(tech_config, read_json(pdk_rules) if pdk_rules else None)
    if tech_name and config['tech_name'] != tech_name:
        raise ValueError('imported Case/tech config identity conflict')
    metadata, adapter = archive / 'tech_metadata.json', archive / 'tech_adapter.il'
    write_metadata([config], metadata, adapter)
    return metadata, adapter


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['inspect', 'generate', 'open', 'confirm', 'list', 'undo', 'fresh'])
    parser.add_argument('--engine', default=str(ROOT / 'build/bin/st_circuit_tool'))
    parser.add_argument('--case', help='actual Maau project cfg, exported by native CircuitDesignConfig')
    parser.add_argument('--case-context', help='already exported native Case JSON')
    parser.add_argument('--case-rules', help='Case electrical limits and exact OP context JSON')
    parser.add_argument('--tech-metadata', help='normalized real tech config JSON')
    parser.add_argument('--tech-adapter', help='generated real SKILL adapter')
    parser.add_argument('--tech-root', default=os.environ.get('TECH_ROOT_PATH'), help='Maau tech config root')
    parser.add_argument('--tech-config', help='explicit real tech_cfg_v2.0.json')
    parser.add_argument('--pdk-rules', help='authoritative PDK electrical rule data JSON')
    parser.add_argument('--runtime', default=os.environ.get('ST_MAAU_RUNTIME_BIN', str(ROOT / 'build/bin/st_maau_runtime')))
    args, remaining = parser.parse_known_args()
    try:
        explicit = explicit_options(remaining)
        if args.command == 'inspect':
            if not args.case_rules:
                raise ValueError('inspect requires --case-rules')
            if bool(args.tech_metadata) != bool(args.tech_adapter):
                raise ValueError('--tech-metadata and --tech-adapter must be provided together')
            session = Path(explicit['work-dir']).resolve()
            if (session / 'session.conf').exists():
                raise ValueError('session already exists; choose a new work-dir')
            archive = session / 'analysis/imported_case'
            archive.mkdir(parents=True, exist_ok=False)
            context = read_json(args.case_context) if args.case_context else None
            if context is None:
                if not args.case:
                    raise ValueError('--case or --case-context is required')
                output = archive / 'native_case.json'
                result = subprocess.run([args.runtime, 'export-case', '--case', str(Path(args.case).resolve()),
                                         '--output', str(output)], check=False)
                if result.returncode:
                    return result.returncode
                context = read_json(output)
            rules = read_json(args.case_rules)
            # Bench selection is explicit if a Case contains multiple tests.
            bench_keys = ('bench-lib', 'bench-cell', 'bench-view')
            bench = None
            if any(k in explicit for k in bench_keys):
                bench = {k: explicit['bench-' + k] for k in ('lib', 'cell', 'view')}
            defaults = inspect_defaults(context, rules, bench)
            # A prepared isolated cds.lib adds staging libs to the imported registry.
            # Verify the inclusion through the existing OA backend; source identity
            # and Bench still come from the imported Case.
            isolated_cds = explicit.pop('cds-lib', None)
            values = merge_explicit(defaults, explicit)
            if isolated_cds:
                expected = Path(defaults['cds-lib']).resolve()
                text = Path(isolated_cds).read_text()
                includes = [line.strip().split(maxsplit=1)[1].strip('"') for line in text.splitlines()
                            if line.strip().startswith('INCLUDE ')]
                if expected not in [Path(p).resolve() for p in includes] and Path(isolated_cds).resolve() != expected:
                    raise ValueError('isolated cds.lib does not include the imported Case registry')
                values['cds-lib'] = str(Path(isolated_cds).resolve())
            context_file, rules_file = archive / 'context.json', archive / 'rules.json'
            write_json(context_file, context)
            write_json(rules_file, rules)
            if args.tech_metadata:
                tech_file = archive / 'tech_metadata.json'
                write_json(tech_file, read_json(args.tech_metadata))
                adapter = Path(args.tech_adapter).resolve()
            else:
                tech_file, adapter = prepare_tech(context, rules, args.tech_root, args.tech_config,
                                                 args.pdk_rules, archive)
            inputs = {'context': str(context_file), 'rules': str(rules_file), 'tech': str(tech_file),
                      'runtime': str(Path(args.runtime).resolve()), 'adapter': str(adapter)}
            validate_inputs(inputs)
            inputs = pin_site_inputs(inputs)
            write_json(archive / 'provider_inputs.json', inputs)
            command = [args.engine, 'inspect']
            for key, value in values.items():
                command.extend(['--' + key, str(value)])
        else:
            session = Path(explicit['session']).resolve()
            inputs = read_json(session / 'analysis/imported_case/provider_inputs.json')
            validate_inputs(inputs)
            verify_site_inputs(inputs)
            command = [args.engine, args.command] + remaining
        return subprocess.run(command, env=provider_environment(inputs), check=False).returncode
    except (KeyError, OSError, ValueError) as error:
        print('Maau Case import: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
