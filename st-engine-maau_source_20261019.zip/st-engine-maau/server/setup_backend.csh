#!/bin/csh

# Source this file from the st-engine-maau root, or pass that root explicitly:
#   source server/setup_backend.csh /path/to/st-engine-maau

set st_setup_ok = 1
if ($#argv >= 1) then
    set st_engine_root = "$argv[1]"
else if (-f "$cwd/server/st_virtuoso_backend.sh") then
    set st_engine_root = "$cwd"
else
    echo "error: run from st-engine-maau root or pass the root path"
    set st_setup_ok = 0
endif

if ($st_setup_ok == 1) then
    if (! -x "$st_engine_root/server/st_virtuoso_backend.sh") then
        echo "error: backend dispatcher is not executable: $st_engine_root/server/st_virtuoso_backend.sh"
        set st_setup_ok = 0
    endif
endif

if ($st_setup_ok == 1) then
    # Site `which` aliases can source helpers and interrupt this sourced file.
    # Resolve executables in a child shell without executing tools or aliases.
    bash -c 'command -v virtuoso' >& /dev/null
    if ($status != 0) then
        # ma may be supplied only as a csh alias, invisible to bash command -v.
        set st_ma_alias = "`alias ma`"
        bash -c 'command -v ma' >& /dev/null
        set st_ma_command = $status
        if ("$st_ma_alias" != "" || $st_ma_command == 0) then
            ma icadv/18.1isr3
            ma spectre/18.1isr6
            rehash
        endif
    endif

    if (! $?ST_SKILL_INIT) then
        setenv ST_SKILL_INIT "$st_engine_root/server/skill/init.il"
    endif
    if ($?ST_SKILL_INIT) then
        if (-f "$ST_SKILL_INIT") then
            setenv SKILLPATH "$ST_SKILL_INIT:h"
        else
            echo "warning: SKILL init.il not found: $ST_SKILL_INIT"
        endif
    endif

    setenv ST_ENGINE_ROOT "$st_engine_root"
    setenv ST_VIRTUOSO_BACKEND "$st_engine_root/server/st_virtuoso_backend.sh"
    setenv ST_SCAN_PDK_RUNNER "$st_engine_root/server/bin/scan_pdk_runner.sh"
    if ($?ST_PDK_TECH_ADAPTER) then
        if ("$ST_PDK_TECH_ADAPTER" !~ /* || ! -f "$ST_PDK_TECH_ADAPTER" || ! -r "$ST_PDK_TECH_ADAPTER") then
            echo "error: ST_PDK_TECH_ADAPTER must be an absolute readable file: $ST_PDK_TECH_ADAPTER"
            unsetenv ST_PDK_TECH_ADAPTER
        endif
    endif
    setenv ST_RUN_OP_RUNNER "$st_engine_root/server/bin/run_op_runner.sh"
    if ($?ST_OP_PROVIDER_BIN) then
        if ("$ST_OP_PROVIDER_BIN" !~ /*) then
            echo "error: ST_OP_PROVIDER_BIN must be an absolute executable: $ST_OP_PROVIDER_BIN"
            unsetenv ST_OP_PROVIDER_BIN
        else if (! -x "$ST_OP_PROVIDER_BIN") then
            echo "error: ST_OP_PROVIDER_BIN is not executable: $ST_OP_PROVIDER_BIN"
            unsetenv ST_OP_PROVIDER_BIN
        endif
    else
        setenv ST_CADENCE_RUNTIME_BIN "$st_engine_root/server/site/cadence_runtime.py"
        setenv ST_OP_PROVIDER_BIN "$st_engine_root/server/site/op_provider.py"
    endif
    setenv ST_SNAPSHOT_RUNNER "$st_engine_root/server/bin/snapshot_runner.sh"
    setenv ST_CLONE_RUNNER "$st_engine_root/server/bin/clone_runner.sh"
    setenv ST_MATERIALIZE_RUNNER "$st_engine_root/server/bin/materialize_runner.sh"
    setenv ST_NETLIST_RUNNER "$st_engine_root/server/bin/netlist_runner.sh"
    setenv ST_PUBLISH_RUNNER "$st_engine_root/server/bin/publish_runner.sh"
    setenv ST_OPEN_RUNNER "$st_engine_root/server/bin/open_runner.sh"

    bash -c 'command -v virtuoso' >& /dev/null
    set st_cadence_found = $status
    set st_init_found = 0
    if ($?ST_SKILL_INIT) then
        if (-f "$ST_SKILL_INIT") set st_init_found = 1
    endif
    if ($st_cadence_found == 0 && $st_init_found == 1) then
        echo "st-engine-maau backend environment ready"
    else
        echo "st-engine-maau backend variables set, but Cadence/SKILL environment is incomplete"
    endif
endif

unset st_setup_ok
if ($?st_engine_root) unset st_engine_root
if ($?st_cadence_found) unset st_cadence_found
if ($?st_init_found) unset st_init_found
if ($?st_ma_alias) unset st_ma_alias
if ($?st_ma_command) unset st_ma_command
