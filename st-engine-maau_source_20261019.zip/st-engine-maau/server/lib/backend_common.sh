#!/usr/bin/env bash

backend_lib_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export ST_ENGINE_ROOT=${ST_ENGINE_ROOT:-$(cd "$backend_lib_dir/../.." && pwd)}

backend_die() {
    local code=$1
    shift
    printf 'error: %s\n' "$*" >&2
    exit "$code"
}

backend_parse_options() {
    BACKEND_OPT_KEYS=()
    BACKEND_OPT_VALUES=()
    while [[ $# -gt 0 ]]; do
        [[ "$1" == --* ]] || backend_die 64 "unexpected positional argument: $1"
        [[ $# -ge 2 ]] || backend_die 64 "option requires a value: $1"
        local key=$1
        local value=$2
        [[ "$value" != *$'\n'* && "$value" != *$'\r'* ]] || \
            backend_die 64 "option contains a newline: $key"
        local existing
        for existing in "${BACKEND_OPT_KEYS[@]:-}"; do
            [[ "$existing" != "$key" ]] || backend_die 64 "duplicate option: $key"
        done
        BACKEND_OPT_KEYS+=("$key")
        BACKEND_OPT_VALUES+=("$value")
        shift 2
    done
    local requested_scope
    requested_scope=$(backend_optional_option --validation-scope)
    if [[ -n "$requested_scope" && -n "${ST_VALIDATION_SCOPE:-}" &&
          "$requested_scope" != "$ST_VALIDATION_SCOPE" ]]; then
        backend_die 64 "validation scope differs from the bound session"
    fi
    export ST_VALIDATION_SCOPE=${requested_scope:-${ST_VALIDATION_SCOPE:-dc_operating_point}}
    case "$ST_VALIDATION_SCOPE" in
        dc_operating_point|structure_only|experimental_dc) ;;
        *) backend_die 64 "unsupported validation scope: $ST_VALIDATION_SCOPE" ;;
    esac
    if [[ -n "${ST_SIMULATION_PROFILE:-}" ]]; then
        python3 - "$ST_SIMULATION_PROFILE" "$ST_VALIDATION_SCOPE" <<'PY' || backend_die 64 "validation scope differs from simulation profile"
import json, sys
with open(sys.argv[1], encoding='utf-8') as stream:
    scope = json.load(stream).get('validation_scope', 'dc_operating_point')
if scope != sys.argv[2]:
    raise SystemExit(1)
PY
    fi
}

backend_option() {
    local wanted=$1
    local index
    for ((index = 0; index < ${#BACKEND_OPT_KEYS[@]}; ++index)); do
        if [[ "${BACKEND_OPT_KEYS[$index]}" == "$wanted" ]]; then
            printf '%s' "${BACKEND_OPT_VALUES[$index]}"
            return 0
        fi
    done
    backend_die 64 "missing required option: $wanted"
}

backend_optional_option() {
    local wanted=$1
    local index
    for ((index = 0; index < ${#BACKEND_OPT_KEYS[@]}; ++index)); do
        if [[ "${BACKEND_OPT_KEYS[$index]}" == "$wanted" ]]; then
            printf '%s' "${BACKEND_OPT_VALUES[$index]}"
            return 0
        fi
    done
    return 0
}

backend_allow_only() {
    local key allowed candidate found
    for key in "${BACKEND_OPT_KEYS[@]:-}"; do
        [[ "$key" == --validation-scope ]] && continue
        found=false
        for candidate in "$@"; do
            if [[ "$key" == "$candidate" ]]; then
                found=true
                break
            fi
        done
        [[ "$found" == true ]] || backend_die 64 "unsupported option: $key"
    done
}

backend_require_file() {
    local path=$1
    local description=$2
    [[ -f "$path" ]] || backend_die 66 "$description does not exist: $path"
}

backend_require_output() {
    local path=$1
    local description=$2
    [[ -s "$path" ]] || backend_die 74 "$description was not generated or is empty: $path"
}

backend_validate_site_inputs() {
    if [[ -n "${ST_CIRCUIT_CONTEXT:-}" ]]; then
        [[ -n "${ST_SITE_INPUTS_MANIFEST:-}" ]] || backend_die 64 "standalone circuit input manifest is required"
        python3 "$ST_ENGINE_ROOT/server/site/site_data.py" --verify-inputs "$ST_SITE_INPUTS_MANIFEST" || \
            backend_die 64 "standalone circuit inputs changed; create a new session"
    elif [[ -n "${ST_SITE_CASE_CONTEXT:-}" || -n "${ST_SITE_INPUTS_MANIFEST:-}" ]]; then
        [[ -n "${ST_SITE_INPUTS_MANIFEST:-}" ]] || \
            backend_die 64 "imported Case input manifest is required"
        backend_require_file "$ST_SITE_INPUTS_MANIFEST" "imported Case input manifest"
        python3 "$ST_ENGINE_ROOT/server/site/maau_config.py" \
            --verify-inputs "$ST_SITE_INPUTS_MANIFEST" || \
            backend_die 64 "imported Case electrical inputs changed; create a new session"
    fi
}

backend_resolve_executable() {
    local requested=${ST_VIRTUOSO_BIN:-virtuoso}
    if [[ "$requested" == */* ]]; then
        [[ -x "$requested" ]] || backend_die 69 "Virtuoso executable is unavailable: $requested"
        printf '%s' "$requested"
        return 0
    fi
    command -v "$requested" 2>/dev/null || \
        backend_die 69 "Virtuoso executable is unavailable: $requested"
}

backend_run_skill_batch() {
    backend_validate_site_inputs
    local action=$1
    local cds_lib=${ST_REQ_CDS_LIB:-}
    [[ -n "$cds_lib" ]] || backend_die 64 "ST_REQ_CDS_LIB is not set"
    backend_require_file "$cds_lib" "cds.lib"
    [[ "$(basename "$cds_lib")" == "cds.lib" ]] || \
        backend_die 64 "Cadence project entry must be named cds.lib: $cds_lib"

    local init_file=${ST_SKILL_INIT:-$ST_ENGINE_ROOT/server/skill/init.il}
    backend_require_file "$init_file" "SKILL init.il"
    backend_require_file "$action" "backend SKILL action"

    local virtuoso
    virtuoso=$(backend_resolve_executable)
    local run_root=${ST_BACKEND_RUN_ROOT:-${TMPDIR:-/tmp}}
    [[ -d "$run_root" && -w "$run_root" ]] || \
        backend_die 73 "backend run root is not writable: $run_root"
    local run_dir
    run_dir=$(mktemp -d "$run_root/st-virtuoso-backend.XXXXXX") || \
        backend_die 73 "cannot create backend run directory under $run_root"

    export ST_SKILL_INIT="$init_file"
    export ST_BACKEND_STATUS_FILE="$run_dir/status.txt"
    export ST_BACKEND_ACTION_FILE="$action"

    # Each launch receives data generated from this exact JSON plan. Never load
    # an arbitrary earlier plan or require a Maau JSON parser at the site.
    unset ST_PREPARED_JSON_FILE
    local plan_file=""
    case "$action" in
        */materialize.il) plan_file=${ST_REQ_PLAN:-} ;;
        */publish_transaction.il) plan_file=${ST_REQ_PUBLISH_PLAN:-} ;;
    esac
    if [[ -n "$plan_file" ]]; then
        python3 "$ST_ENGINE_ROOT/server/site/prepare_skill_plan.py" \
            --input "$plan_file" --output "$run_dir/plan_data.il" || \
            backend_die 64 "Cannot prepare this action's JSON plan"
        export ST_PREPARED_JSON_FILE="$run_dir/plan_data.il"
    fi

    local status=0
    (
        cd "$(dirname "$cds_lib")"
        "$virtuoso" -nograph -replay "$action" -log "$run_dir/virtuoso.log"
    ) || status=$?

    if [[ -f "$run_dir/virtuoso.log" ]]; then
        if [[ "$action" == */publish_transaction.il || "$action" == */scan_pdk.il ||
              "$action" == */materialize.il || $status -ne 0 ||
              ! -f "$ST_BACKEND_STATUS_FILE" ]] ||
           ! grep -qx 'OK' "$ST_BACKEND_STATUS_FILE"; then
            # PDK initialization can push the actual error beyond line 240.
            # Keep rejected candidates and property-copy evidence after
            # successful actions, plus failed-action/publish diagnostics.
            cat "$run_dir/virtuoso.log"
        else
            sed -n '1,240p' "$run_dir/virtuoso.log"
        fi
    fi
    if [[ $status -ne 0 ]]; then
        printf 'backend run directory retained: %s\n' "$run_dir" >&2
        backend_die "$status" "Virtuoso batch process failed with exit code $status"
    fi
    if [[ ! -f "$ST_BACKEND_STATUS_FILE" ]] || \
       ! grep -qx 'OK' "$ST_BACKEND_STATUS_FILE"; then
        printf 'backend run directory retained: %s\n' "$run_dir" >&2
        backend_die 70 "Virtuoso batch finished without an OK completion marker"
    fi
    rm -rf "$run_dir"
}

backend_launch_skill_gui() {
    local action=$1
    local cds_lib=${ST_REQ_CDS_LIB:-}
    [[ -n "$cds_lib" ]] || backend_die 64 "ST_REQ_CDS_LIB is not set"
    backend_require_file "$cds_lib" "cds.lib"
    [[ "$(basename "$cds_lib")" == "cds.lib" ]] || \
        backend_die 64 "Cadence project entry must be named cds.lib: $cds_lib"

    local init_file=${ST_SKILL_INIT:-$ST_ENGINE_ROOT/server/skill/init.il}
    backend_require_file "$init_file" "SKILL init.il"
    backend_require_file "$action" "backend SKILL action"

    local virtuoso
    virtuoso=$(backend_resolve_executable)
    local run_root=${ST_BACKEND_RUN_ROOT:-${TMPDIR:-/tmp}}
    [[ -d "$run_root" && -w "$run_root" ]] || \
        backend_die 73 "backend run root is not writable: $run_root"
    local run_dir
    run_dir=$(mktemp -d "$run_root/st-virtuoso-gui.XXXXXX") || \
        backend_die 73 "cannot create GUI launch directory under $run_root"

    export ST_SKILL_INIT="$init_file"
    export ST_BACKEND_STATUS_FILE="$run_dir/status.txt"
    export ST_BACKEND_ACTION_FILE="$action"

    local pid
    (
        cd "$(dirname "$cds_lib")"
        nohup "$virtuoso" -replay "$action" -log "$run_dir/virtuoso.log" \
            </dev/null >"$run_dir/launcher.out" 2>&1 &
        printf '%s\n' "$!" > "$run_dir/pid"
    )
    pid=$(cat "$run_dir/pid")

    local wait_seconds=${ST_OPEN_WAIT_SECONDS:-30}
    [[ "$wait_seconds" =~ ^[1-9][0-9]*$ ]] || \
        backend_die 64 "ST_OPEN_WAIT_SECONDS must be a positive integer"
    local waited=0
    while [[ $waited -lt $wait_seconds ]]; do
        if [[ -f "$ST_BACKEND_STATUS_FILE" ]] && \
           grep -qx 'OK' "$ST_BACKEND_STATUS_FILE"; then
            printf 'Virtuoso GUI opened target cellview; pid=%s; log=%s\n' \
                "$pid" "$run_dir/virtuoso.log"
            return 0
        fi
        if ! kill -0 "$pid" 2>/dev/null; then
            [[ -f "$run_dir/launcher.out" ]] && sed -n '1,240p' "$run_dir/launcher.out"
            [[ -f "$run_dir/virtuoso.log" ]] && sed -n '1,240p' "$run_dir/virtuoso.log"
            printf 'GUI launch directory retained: %s\n' "$run_dir" >&2
            backend_die 70 "Virtuoso GUI exited before opening the target cellview"
        fi
        sleep 1
        waited=$((waited + 1))
    done

    [[ -f "$run_dir/launcher.out" ]] && sed -n '1,240p' "$run_dir/launcher.out"
    [[ -f "$run_dir/virtuoso.log" ]] && sed -n '1,240p' "$run_dir/virtuoso.log"
    printf 'GUI launch directory retained: %s\n' "$run_dir" >&2
    backend_die 70 "Virtuoso GUI did not confirm the target cellview within ${wait_seconds}s"
}
