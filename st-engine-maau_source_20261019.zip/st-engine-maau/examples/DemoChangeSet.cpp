// 一次工作电路连续确认四类变换，最终只生成一个派生电路。
#include "st/ChangeSet.h"
#include "st/Transform.h"

#include <iostream>

namespace {

st::DeviceCatalog makeCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto addMos = [&](const std::string& master, st::DeviceKind kind) {
        st::DeviceDescriptor descriptor;
        descriptor.master = master;
        descriptor.kind = kind;
        descriptor.terminal_count = 4;
        descriptor.terminal_index = {
            { st::TerminalRole::Drain, 0 }, { st::TerminalRole::Gate, 1 },
            { st::TerminalRole::Source, 2 }, { st::TerminalRole::Bulk, 3 },
        };
        descriptor.normalized_to_cdf = { { "width", "w" }, { "length", "l" } };
        descriptor.oa_library = "demo_pdk";
        descriptor.oa_cell = master;
        descriptor.oa_view = "symbol";
        descriptor.limits.min_width = 100e-9;
        descriptor.limits.max_width = 1e-3;
        descriptor.limits.min_length = 100e-9;
        descriptor.limits.max_length = 10e-6;
        descriptor.voltage_domain = "core";
        descriptor.allowed_voltage_domains.insert("core");
        descriptor.limits.max_stack_level = 100;
        descriptor.reliability_complete = true;
        descriptor.bulk_rule_complete = true;
        descriptor.parameter_constraints["width"] =
            {"width", "w", 100e-9, 1e-3, 10e-9, {}, false};
        return descriptor;
    };
    catalog.Add(addMos("nsvt", st::DeviceKind::MosN), diagnostic);
    catalog.Add(addMos("nlvt", st::DeviceKind::MosN), diagnostic);
    catalog.Add(addMos("psvt", st::DeviceKind::MosP), diagnostic);

    st::DeviceDescriptor resistor;
    resistor.master = "r2_pdk";
    resistor.kind = st::DeviceKind::Resistor;
    resistor.terminal_count = 2;
    resistor.terminal_index = {
        { st::TerminalRole::Positive, 0 }, { st::TerminalRole::Negative, 1 },
    };
    resistor.limits.min_resistance = 1.0;
    resistor.limits.max_resistance = 1e6;
    catalog.Add(resistor, diagnostic);
    return catalog;
}

} // namespace

int main()
{
    st::Netlist base;
    st::Subckt core;
    core.name = "core";
    core.pins = { "PVDD", "VSS", "IREF_P" };
    core.instances = {
        { "M0", { "N0", "G0", "VSS", "VSS" }, "nsvt", { { "w", "2u" }, { "l", "240n" } } },
        { "M1", { "N1", "G1", "VSS", "VSS" }, "nsvt", { { "w", "2u" }, { "l", "240n" } } },
        { "MP", { "VOUT", "VGP", "PVDD", "PVDD" }, "psvt", { { "w", "20u" }, { "l", "180n" } } },
        { "M3", { "OUT3", "G3", "VSS", "VSS" }, "nsvt", { { "w", "3u" }, { "l", "240n" } } },
    };
    base.subckts.push_back(core);
    const auto catalog = makeCatalog();

    st::ChangeSet changes;
    st::Diagnostic diagnostic;
    st::CascodeTransformRequest sameCascode;
    sameCascode.subckt = "core";
    sameCascode.target = "M0";
    sameCascode.gate_policy = st::GatePolicy::SharedGate;
    sameCascode.nmos_bulk_net = "VSS";
    sameCascode.voltage_domain = "core";
    st::TransformRequest op1;
    op1.operation_id = "op-1";
    op1.target = { "/", "core", "M0" };
    op1.type = st::TransformType::SameTypeCascode;
    op1.payload = sameCascode;
    changes.Confirm(op1, diagnostic);

    auto crossCascode = sameCascode;
    crossCascode.target = "M1";
    crossCascode.new_master = "nlvt";
    st::TransformRequest op2;
    op2.operation_id = "op-2";
    op2.target = { "/", "core", "M1" };
    op2.type = st::TransformType::CrossFlavorCascode;
    op2.payload = crossCascode;
    changes.Confirm(op2, diagnostic);

    st::ResistorTransformRequest resistorRequest;
    resistorRequest.subckt = "core";
    resistorRequest.target = "MP";
    resistorRequest.requested_resistance = 1000.0;
    resistorRequest.resistor.master = "r2_pdk";
    resistorRequest.resistor.grid = 0.5;
    st::TransformRequest op3;
    op3.operation_id = "op-3";
    op3.target = { "/", "core", "MP" };
    op3.type = st::TransformType::AddSourceResistor;
    op3.payload = resistorRequest;
    changes.Confirm(op3, diagnostic);

    st::StackTransformRequest stackRequest;
    stackRequest.subckt = "core";
    stackRequest.target = "M3";
    stackRequest.stage_count = 3;
    stackRequest.gate_policy = st::GatePolicy::SharedGate;
    stackRequest.voltage_domain = "core";
    stackRequest.nmos_bulk_net = "VSS";
    st::TransformRequest op4;
    op4.operation_id = "op-4";
    op4.target = { "/", "core", "M3" };
    op4.type = st::TransformType::MosStack;
    op4.payload = stackRequest;
    changes.Confirm(op4, diagnostic);

    st::Netlist variant;
    const auto replay = changes.Generate(base, variant, catalog);

    if (!replay.ok) {
        std::cerr << "failed operation: " << replay.failed_operation_id << '\n';
        return 1;
    }
    std::cout << "confirmed operations: " << replay.applied_operation_ids.size() << '\n';
    std::cout << "one final derived circuit:\n" << st::emitSpectre(variant);
    return 0;
}
