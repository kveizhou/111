// 使用工程入口演示：端子语义来自 DeviceCatalog；共享栅 Cascode
// 不依赖尚待自动求解器提供的 VBIAS 结果。
#include "st/Netlist.h"
#include "st/Transform.h"

#include <iostream>

int main()
{
    std::vector<st::Diagnostic> parseDiagnostics;
    auto netlist = st::parseSpectre(R"(
subckt mirror_core VGA VBN1 VBP_REF VR AGND PVDD
    I25<51> (VGA VBN1 VR AGND) n18_ckt l=240n w=103n nf=4 nfin=4 mr=2
ends mirror_core
)", parseDiagnostics);
    if (!parseDiagnostics.empty()) return 1;

    st::DeviceCatalog catalog;
    st::DeviceDescriptor nmos;
    nmos.master = "n18_ckt";
    nmos.kind = st::DeviceKind::MosN;
    nmos.terminal_count = 4;
    nmos.terminal_index = {
        { st::TerminalRole::Drain, 0 }, { st::TerminalRole::Gate, 1 },
        { st::TerminalRole::Source, 2 }, { st::TerminalRole::Bulk, 3 },
    };
    nmos.normalized_to_cdf = { { "width", "w" }, { "length", "l" },
                               { "fingers", "nf" } };
    nmos.oa_library = "demo_pdk";
    nmos.oa_cell = "n18_ckt";
    nmos.oa_view = "symbol";
    nmos.limits.min_width = 1e-9;
    nmos.limits.max_width = 1e-3;
    nmos.limits.min_length = 1e-9;
    nmos.limits.max_length = 1e-3;
    nmos.voltage_domain = "core_1v2";
    nmos.allowed_voltage_domains.insert("core_1v2");
    st::Diagnostic catalogDiagnostic;
    if (!catalog.Add(nmos, catalogDiagnostic)) return 2;

    auto pmos = nmos;
    pmos.master = "p18_ckt";
    pmos.kind = st::DeviceKind::MosP;
    pmos.oa_cell = "p18_ckt";
    if (!catalog.Add(pmos, catalogDiagnostic)) return 2;

    st::CascodeTransformRequest request;
    request.subckt = "mirror_core";
    request.target = "I25<51>";
    request.gate_policy = st::GatePolicy::SharedGate;
    request.nmos_bulk_net = "AGND";
    request.voltage_domain = "core_1v2";

    std::cout << "========== before ==========\n" << st::emitSpectre(netlist) << '\n';
    const auto outcome = st::applyCascode(netlist, request, catalog);
    if (!outcome.ok()) {
        for (const auto& diagnostic : outcome.diags) {
            std::cerr << diagnostic.message << '\n';
        }
        return 4;
    }
    std::cout << "========== after ==========\n" << st::emitSpectre(netlist) << '\n';
    std::cout << "result: success; ready for OA planning, not yet simulated\n";
    return 0;
}
