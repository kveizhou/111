#!/usr/bin/env bash
set -euo pipefail

# This relay documents the stable process boundary used by st_circuit_tool.
# Point each variable at a site-owned executable that initializes the real
# Cadence/PDK environment and implements that single verb without using eval.

if [[ $# -lt 1 ]]; then
    echo "usage: $0 snapshot|clone|materialize|netlist|publish|open [arguments...]" >&2
    exit 2
fi

verb=$1
shift

case "$verb" in
    snapshot)    runner=${ST_SNAPSHOT_RUNNER:-} ;;
    clone)       runner=${ST_CLONE_RUNNER:-} ;;
    materialize) runner=${ST_MATERIALIZE_RUNNER:-} ;;
    netlist)     runner=${ST_NETLIST_RUNNER:-} ;;
    publish)     runner=${ST_PUBLISH_RUNNER:-} ;;
    open)        runner=${ST_OPEN_RUNNER:-} ;;
    *)
        echo "unsupported backend verb: $verb" >&2
        exit 2
        ;;
esac

if [[ -z "$runner" || ! -x "$runner" ]]; then
    echo "site runner for '$verb' is not configured or executable" >&2
    exit 64
fi

exec "$runner" "$@"
