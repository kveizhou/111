"""Run the settings reader; native exporters are file-writing fixtures only."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tests'))
import CascodeBatchTest as batch_fixture
ENTRY = ROOT/'server/site/read_cascode_solver_settings.py'


class CascodeSolverSettingsTest(unittest.TestCase):
    def setUp(self):
        self.assertTrue(ENTRY.is_file(), 'file-based solver settings entry is missing')

    def fixture(self, base):
        session, read, preflight, env = batch_fixture.CascodeBatchTest().fixture(base)
        batch = base/'batch'; batch.mkdir(); (batch/'status.json').write_text('{}')
        backend = base/'settings_exporter'
        backend.write_text('#!'+sys.executable+'\n'+r'''import os,re,sys,time
from pathlib import Path
code=Path(sys.argv[sys.argv.index('-replay')+1]).read_text()
Path(os.environ['ST_TEST_CAPTURE_ACTION']).write_text(code)
call=re.search(r'asiWriteOceanScript\(\s*(\w+)',code).group(1)
opened=re.search(r'(\w+)\s*=\s*asiOpenOceanScript\(getShellEnvVar\("ST_REVIEW_OCEAN"\)\)',code)
if not opened or opened.group(1)!=call:
    print('*Error* fprintf: argument #1 should be an I/O port'); sys.exit(3)
assert '?noRun t ?fullKey t' in code
assert code.index('asiCloseOceanScript('+call+')') < code.index('outfile(getShellEnvVar("ST_REVIEW_DONE"))')
assert not re.search(r'(?m)^\s*(run|asiRunSimulation|maeRunSimulation)\(',code)
mode=os.environ.get('ST_TEST_READ_MODE','normal')
if mode=='native_error': print('*Error* export failed'); sys.exit(3)
if mode=='timeout': time.sleep(3)
if mode=='changed': Path(os.environ['ST_TEST_CHANGED_INPUT']).write_text('modified fixture input')
saved=Path(os.environ['ST_REVIEW_OCEAN'])
saved.write_text('' if mode=='empty' else os.environ['ST_TEST_SAVED_SCRIPT'])
if mode!='no_marker': Path(os.environ['ST_REVIEW_DONE']).write_text('BAD\n' if mode=='bad_marker' else 'OK\n')
''')
        backend.chmod(0o755)
        env.update(ST_VIRTUOSO_BIN=str(backend), ST_TEST_CAPTURE_ACTION=str(base/'captured.il'),
                   ST_TEST_CHANGED_INPUT=str(read),
                   ST_TEST_SAVED_SCRIPT="analysis('tran ?stop \"100u\")\noption('reltol \"1e-3\")\nenvOption('analysisOrder list(\"tran\"))\ntemp(27)\nrun()\n")
        return session, read, preflight, batch, env

    def run_entry(self, session, read, preflight, batch, env):
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(session),'--maestro-read',str(read),
            '--preflight',str(preflight),'--batch',str(batch),'--timeout','1'],
            cwd=batch, env=env, capture_output=True, text=True)

    def module(self):
        spec=importlib.util.spec_from_file_location('settings_reader_under_test', ENTRY)
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

    def test_file_entry_runs_from_other_directory_preserves_inputs_and_never_launches_saved_script(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d); s,r,p,b,e=self.fixture(base)
            before={x:x.read_bytes() for x in (s/'session.conf',r,p/'bench.scs')}
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('SAVED_TEST_SCRIPT_READ_OK',result.stdout)
            self.assertIn('SAVED_TEST analysis',result.stdout)
            self.assertIn('SAVED_TEST temp(27)',result.stdout)
            self.assertIn('SELECTED_CORNER=HOT',result.stdout)
            self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout)
            self.assertNotIn('SAVED_TEST run()',result.stdout)
            for x,content in before.items(): self.assertEqual(x.read_bytes(),content)
            output=next(b.glob('dc_review_ports_*'))
            self.assertIn('run()', (output/'saved_test.ocn').read_text())
            self.assertFalse((b/'dc').exists())
            code=(base/'captured.il').read_text()
            depth=0;quoted=False;escaped=False
            for c in code:
                if quoted:
                    if escaped: escaped=False
                    elif c=='\\': escaped=True
                    elif c=='"': quoted=False
                elif c=='"': quoted=True
                elif c=='(': depth+=1
                elif c==')': depth-=1
                self.assertGreaterEqual(depth,0)
            self.assertEqual(depth,0); self.assertFalse(quoted)

    def test_missing_or_bad_marker_empty_script_native_error_and_timeout_are_incomplete(self):
        for mode in ('no_marker','bad_marker','empty','native_error','timeout'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                s,r,p,b,e=self.fixture(Path(d)); e['ST_TEST_READ_MODE']=mode
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertIn('RESULT=INCOMPLETE',result.stdout)
                self.assertNotIn('SAVED_TEST_SCRIPT_READ_OK',result.stdout)

    def test_input_changed_before_or_during_read_cannot_pass(self):
        for moment in ('before','during'):
            with self.subTest(moment=moment), tempfile.TemporaryDirectory() as d:
                s,r,p,b,e=self.fixture(Path(d))
                if moment=='before': (s/'session.conf').write_text('changed')
                else: e['ST_TEST_READ_MODE']='changed'
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('SAVED_TEST_SCRIPT_READ_OK',result.stdout)

    def test_strings_comments_and_escaped_quotes_do_not_create_fake_settings(self):
        module=self.module()
        text='; option(ignored)\n/* analysis(ignored) */\nx="temp(ignored)"\n'
        text+="analysis('tran ?note \"close ) escaped \\\" quote\" ?stop \"100u\")\noption('reltol \"1e-3\")\n"
        forms=module.extract_forms(text)
        self.assertEqual(len(forms),2)
        self.assertTrue(forms[0].startswith("analysis('tran"))
        self.assertEqual(forms[1], 'option(\'reltol "1e-3")')
        for bad in ('analysis(\'dc','option(\"unterminated','/* never closed'):
            with self.assertRaises(ValueError): module.extract_forms(bad)

    def test_long_settings_are_retained_and_summary_reserves_success_and_omission_fields(self):
        with tempfile.TemporaryDirectory() as d:
            s,r,p,b,e=self.fixture(Path(d))
            e['ST_TEST_SAVED_SCRIPT']='option(\n'+''.join("'key%d \"%s\"\n"%(i,'x'*70) for i in range(35))+')\n'
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('key34',result.stdout)
            forms=json.loads((next(b.glob('dc_review_ports_*'))/'settings_forms.json').read_text())
            self.assertIn('key34',forms[0])
            self.assertLessEqual(len(result.stdout.splitlines()),190)
        module=self.module()
        shown=module.render(['detail '+str(i) for i in range(400)],3,None)
        self.assertLessEqual(len(shown)+2,190)
        self.assertIn('SAVED_TEST_SCRIPT_READ_OK',shown)
        self.assertTrue(any(x.startswith('SUMMARY_OMITTED_LINES=') and x!='SUMMARY_OMITTED_LINES=0' for x in shown))

    def test_empty_or_malformed_forms_stop_and_help_needs_no_cadence(self):
        with tempfile.TemporaryDirectory() as d:
            for text in ('run()\n','analysis(\'dc'):
                with tempfile.TemporaryDirectory(dir=d) as sub:
                    s,r,p,b,e=self.fixture(Path(sub)); e['ST_TEST_SAVED_SCRIPT']=text
                    result=self.run_entry(s,r,p,b,e)
                    self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                    self.assertNotIn('SAVED_TEST_SCRIPT_READ_OK',result.stdout)
        result=subprocess.run([sys.executable,str(ENTRY),'--help'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0)
        self.assertIn('--maestro-read',result.stdout)


if __name__ == '__main__': unittest.main()
