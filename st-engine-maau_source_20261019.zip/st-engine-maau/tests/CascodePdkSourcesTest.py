"""Bounded source reads from previously collected evidence, no EDA tools."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT=Path(__file__).resolve().parents[1]/'server/site/read_cascode_pdk_sources.py'

class SourcesTest(unittest.TestCase):
    def fixture(self, root):
        session=root/'session';session.mkdir()
        batch=root/'batch';baseline=batch/'dc_review_ports_one';baseline.mkdir(parents=True)
        bridge=baseline/'runtime_bridge_one';(bridge/'bundle').mkdir(parents=True)
        status=bridge/'bridge_status.json';status.write_text(json.dumps(dict(cache_match=True,psf_unchanged=True)))
        bundle=bridge/'bundle/baseline_bundle.json';bundle.write_text(json.dumps(dict(session=str(session),dependency_policy='native-site')))
        bundle.with_suffix('.sha256').write_text(hashlib.sha256(bundle.read_bytes()).hexdigest())
        pdk=root/'pdk';(pdk/'.skill').mkdir(parents=True)
        calc=pdk/'res_calc.il';calc.write_text('procedure(resCalc()\n maxVoltage=1.23 ; FIXTURE ONLY\n);rhrpo_2t_ckt\n')
        init=pdk/'libInit.il';init.write_text('load(strcat(libPath "/.skill/callback.ile"))\nload(strcat(libPath "/.skill/np2_Mos_LL_CB.ile"))\n')
        (pdk/'.skill/callback.ile').write_bytes(b'\x00\xffencrypted fixture')
        (pdk/'.skill/np2_Mos_LL_CB.ile').write_text('procedure(np2_Mos_LL_CB(x)\n nfin=4\n)\n')
        evidence=baseline/'pdk_evidence_one';evidence.mkdir()
        data=dict(schema='cascode-pdk-evidence-v2',accepted_bridge=str(bridge),search_roots=[str(pdk)],
          source_cache_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (status,bundle)},
          search=dict(hits=[dict(path=str(calc),line=3),dict(path=str(init),line=1)],limited=True),
          targets={'I21':{'master':{'oa_library':'exact_Lib','oa_cell':'n18_ckt_tp'}}})
        (evidence/'evidence.json').write_text(json.dumps(data))
        return session,batch,pdk,evidence

    def call(self, session,batch):
        return subprocess.run([sys.executable,str(SCRIPT),'--session',str(session),'--batch',str(batch)],capture_output=True,text=True)

    def test_default_reads_only_resistor_and_does_not_apply_rules(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,batch,pdk,evidence=self.fixture(Path(tmp))
            before={p:p.read_bytes() for p in pdk.rglob('*') if p.is_file()}
            result=self.call(session,batch)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=PDK_SOURCES_READ_OK',result.stdout)
            self.assertIn('RESISTOR_SOURCE_READ=true',result.stdout)
            self.assertIn('maxVoltage=1.23',result.stdout)
            self.assertIn('NATIVE_EXECUTIONS=0',result.stdout)
            self.assertIn('PDK_ELECTRICAL_RULES_READY=false',result.stdout)
            self.assertEqual(before,{p:p.read_bytes() for p in before})
            report=json.loads(next(batch.glob('dc_review_ports_*/pdk_sources_*/sources.json')).read_text())
            self.assertEqual(len(report['files']),1)
            self.assertEqual(report['targets']['I21']['master']['oa_library'],'exact_Lib')

    def test_missing_plain_source_is_reported_once_as_incomplete(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,batch,pdk,_=self.fixture(Path(tmp));(pdk/'res_calc.il').unlink()
            result=self.call(session,batch)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertIn('MISSING',result.stdout)
            self.assertIn('RESISTOR_SOURCE_READ=false',result.stdout)

    def test_cache_drift_and_session_mismatch_stop_before_source_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,batch,pdk,_=self.fixture(Path(tmp))
            other=Path(tmp)/'other';other.mkdir()
            self.assertEqual(self.call(other,batch).returncode,2)
            status=next(batch.glob('dc_review_ports_*/runtime_bridge_*/bridge_status.json'))
            status.write_text(status.read_text()+' ')
            result=self.call(session,batch)
            self.assertEqual(result.returncode,2);self.assertIn('changed',result.stdout)
            self.assertFalse(list(batch.glob('dc_review_ports_*/pdk_sources_*')))

    def test_missing_resistor_hit_recovers_exact_file_from_declared_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,batch,pdk,folder=self.fixture(Path(tmp))
            path=folder/'evidence.json';data=json.loads(path.read_text())
            data['search']['hits']=[h for h in data['search']['hits'] if Path(h['path']).name!='res_calc.il']
            path.write_text(json.dumps(data))
            result=self.call(session,batch)
            self.assertEqual(result.returncode,0,result.stdout)
            self.assertIn('maxVoltage=1.23',result.stdout)
            self.assertIn('EXACT_ROOT_FILENAME',result.stdout)

    def test_no_resistor_anywhere_cannot_report_read_ok(self):
        with tempfile.TemporaryDirectory() as tmp:
            session,batch,pdk,folder=self.fixture(Path(tmp))
            (pdk/'res_calc.il').unlink()
            path=folder/'evidence.json';data=json.loads(path.read_text());data['search']['hits']=data['search']['hits'][1:]
            path.write_text(json.dumps(data))
            result=self.call(session,batch)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertIn('RESISTOR_SOURCE_READ=false',result.stdout)
            self.assertNotIn('RESULT=PDK_SOURCES_READ_OK',result.stdout)

    def test_prior_matching_evidence_retains_exact_resistor_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);session,batch,pdk,older=self.fixture(root)
            calc=pdk/'res_calc.il';outside=root/'resolved_model_location';outside.mkdir()
            moved=outside/'res_calc.il';calc.rename(moved)
            data=json.loads((older/'evidence.json').read_text());data['search']['hits'][0]['path']=str(moved)
            (older/'evidence.json').write_text(json.dumps(data))
            newer=older.parent/'pdk_evidence_newer';newer.mkdir()
            new_data=json.loads(json.dumps(data));new_data['search']['hits']=new_data['search']['hits'][1:]
            (newer/'evidence.json').write_text(json.dumps(new_data))
            import os
            os.utime(older/'evidence.json',(1,1));os.utime(newer/'evidence.json',(2,2))
            result=self.call(session,batch)
            self.assertEqual(result.returncode,0,result.stdout)
            self.assertIn('maxVoltage=1.23',result.stdout)
            self.assertIn('CACHED_EXACT_PATH',result.stdout)

    def test_recorded_symlink_name_survives_resolution(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);session,batch,pdk,_=self.fixture(root)
            calc=pdk/'res_calc.il';actual=root/'different_basename.txt';calc.rename(actual);calc.symlink_to(actual)
            result=self.call(session,batch)
            self.assertEqual(result.returncode,0,result.stdout)
            self.assertIn('maxVoltage=1.23',result.stdout)
            self.assertIn('RESISTOR_SOURCE_READ=true',result.stdout)

    def test_historical_cache_drift_is_not_used_for_path_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);session,batch,pdk,older=self.fixture(root)
            calc=pdk/'res_calc.il';outside=root/'outside';outside.mkdir();moved=outside/'res_calc.il';calc.rename(moved)
            old=json.loads((older/'evidence.json').read_text());old['search']['hits'][0]['path']=str(moved)
            newest=json.loads(json.dumps(old));newest['search']['hits']=newest['search']['hits'][1:]
            key=next(iter(old['source_cache_sha256']));old['source_cache_sha256'][key]='different'
            (older/'evidence.json').write_text(json.dumps(old))
            folder=older.parent/'pdk_evidence_newer';folder.mkdir();(folder/'evidence.json').write_text(json.dumps(newest))
            import os
            os.utime(older/'evidence.json',(1,1));os.utime(folder/'evidence.json',(2,2))
            result=self.call(session,batch)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertIn('CACHE_SKIPPED',result.stdout)
            self.assertNotIn('maxVoltage=1.23',result.stdout)

    def test_target_callback_filter_excludes_tap_dummy_and_rf(self):
        spec=importlib.util.spec_from_file_location('pdk_sources',SCRIPT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        record=dict(status='TEXT',path='/pdk/libInit.il',text='\n'.join(
            'load(strcat(libPath "/.skill/'+name+'.ile"))' for name in
            ['callback','np2_Mos_LL_CB','np2_DummyFiller_CB','np2_Tap_CB','Hotel_Callback_RFMOS']))
        names={p.name for p in m.direct_callback_paths(record)}
        self.assertEqual(names,{'callback.ile','np2_Mos_LL_CB.ile'})

    def test_no_recursive_traversal_and_source_limit(self):
        spec=importlib.util.spec_from_file_location('pdk_sources',SCRIPT);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=root/'plain.ile';p.write_text('load("elsewhere.il")\nprocedure(np2_Mos_LL_CB(x) x)')
            record=m.read_source(p,[],128)
            self.assertEqual(record['status'],'TEXT')
            self.assertNotIn('elsewhere.il',m.direct_callback_paths(record))
            p.write_bytes(b'a'*129)
            self.assertEqual(m.read_source(p,[],128)['status'],'SIZE_LIMIT')

if __name__=='__main__':unittest.main()
