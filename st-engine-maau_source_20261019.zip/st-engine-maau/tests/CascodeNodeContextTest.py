"""Directional node-read contracts; no native Cadence execution on this host."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import CascodeSavedDcTest as fixtures


class CascodeNodeContextTest(unittest.TestCase):
    def module(self):
        return fixtures.saved_fixture.CascodeSolverSettingsTest().module()

    def fixture(self, root, peripheral=False):
        old = fixtures.CascodeSavedDcTest()
        s,r,p,b,e = old.fixture(root)
        if peripheral:
            deck=e['ST_TEST_DECK'].replace('subckt core D G S B\n','subckt core D G S B IBIAS1 IBIAS0\n').replace('XCORE (VDD G 0 0)',r'XCORE (VDD G 0 0 net037\<0\> net037\<1\>)').replace('VDD (VDD 0)','VDD (VDD AGND)')
            e['ST_TEST_DECK']=deck
            (p/'bench.scs').write_text(deck)
            next((p/'generated').rglob('input.scs')).write_text(deck)
        backend=Path(e['ST_OCEAN_BIN'])
        backend.write_text(backend.read_text().replace("  requested=None", "  values.extend([('cgg',2e-15),('reversed',0)])\n  requested=None"))
        result=old.run_entry(s,r,p,b,e)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        result=self.run_entry(s,r,p,b,e,'--read-op-only')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        baseline=next(b.glob('dc_review_ports_*'))
        cache=next(baseline.glob('op_review_*'))
        (b/'status.json').write_text(json.dumps({'states':{'native':'COMPLETE','unchanged':'COMPLETE'}}))
        rows=[]
        for target,cell,model in [('I21','n','nmod'),('I105','p','pmod')]:
            for kind,name,value in [('source','oa_library','"PDK"'),('source','oa_cell',json.dumps(cell)),('source','oa_view','"symbol"'),('cdf_mapping','termOrder','(D G S B)'),('cdf_value','model',json.dumps(model))]:
                rows.append('ST_MAE_RECORD\t'+kind+'\t'+json.dumps(target)+'\t'+json.dumps(name)+'\tOK\t'+value)
        (b/'native').mkdir()
        native=b/'native/report.tsv';native.write_text('\n'.join(rows)+'\nST_MAESTRO_SETUP_READ_COMPLETE\n')
        import read_maestro_setup
        (b/'native_records.json').write_text(json.dumps(read_maestro_setup.read_records(native.read_text())))
        node=root/'node_ocean'
        node.write_text('#!'+sys.executable+'\n'+r'''import json,os,sys
from pathlib import Path
script=Path(sys.argv[-1]).read_text()
if 'createNetlist(' in script or 'run()' in script or 'pv(' in script:
 raise SystemExit('unexpected simulation or device OP reread')
(root:=Path(os.environ['ST_NODE_REQUEST'])).with_name('node_launch_observed').write_text(script)
req=json.loads(root.read_text()); table=Path(os.environ['ST_NODE_TABLE'])
values={'VDD':1.14,'G':0.43};rows=['kind\tsignal\tvalue\tstatus']
mode=os.environ.get('ST_NODE_TEST_MODE','')
for name in req['nodes']:
 if name=='0': continue
 status='MISSING' if (mode=='missing' and name=='G') or (name not in values and mode!='resolve_context') else 'OK'
 val='' if status!='OK' else str(values.get(name,0.125))
 if mode=='nonnumeric' and name=='G': status='NON_NUMERIC';val=''
 if mode=='nan' and name=='G': val='nan'
 if mode=='peripheral_nan' and name=='AGND': status='OK';val='nan'
 rows.append('node\t'+name+'\t'+val+'\t'+status)
 if mode=='duplicate' and name=='G': rows.append('node\tG\t0.44\tOK')
 if mode=='peripheral_duplicate' and name=='AGND': rows.append('node\tAGND\t0.0\tOK')
if req['voltage_sources']: rows.append('current\tVDD:p\t-0.0001\tOK')
(table.parent/'outputs.txt').write_text('VDD\nG\nVDD:p\n')
table.write_text('\n'.join(rows)+'\n')
if mode!='no_marker': (table.parent/'runtime.done').write_text('OK\n')
if mode=='mutate_psf': Path(os.environ['ST_NODE_TEST_PSF']).write_text('changed')
''')
        node.chmod(0o755);e['ST_OCEAN_BIN']=str(node)
        return s,r,p,b,e,baseline,cache

    def run_entry(self,s,r,p,b,e,mode='--read-node-context'):
        return subprocess.run([sys.executable,str(fixtures.ENTRY),'--session',str(s),'--maestro-read',str(r),'--preflight',str(p),'--batch',str(b),mode],cwd=b,env=e,text=True,capture_output=True)

    def seed_v1_node_cache(self,s,r,p,b,e,base):
        # Reproduce the historical native table/report contract, not a new native run.
        from types import SimpleNamespace
        mod=self.module();args=SimpleNamespace(session=str(s),maestro_read=str(r),preflight=str(p),batch=str(b))
        bound,baseline,psf=mod.validated_baseline(args,[])
        request=mod.node_request(bound,b);fingerprint=mod.psf_fingerprint(psf)
        cached,_=mod.cached_target_op(bound,baseline,request,fingerprint)
        out=base/'node_context_v1';work=out/'node_read';work.mkdir(parents=True)
        rows=[dict(kind='node',signal=n,value=str({'VDD':1.14,'G':.43}[n]) if n in ('VDD','G') else '',status='OK' if n in ('VDD','G') else 'MISSING') for n in request['nodes'] if n!='0']
        rows.append(dict(kind='current',signal='VDD:p',value='-0.0001',status='OK'))
        (work/'values.tsv').write_text('kind\tsignal\tvalue\tstatus\n'+''.join('\t'.join(row[k] for k in ('kind','signal','value','status'))+'\n' for row in rows))
        (work/'runtime.done').write_text('OK\n')
        report=mod.summarize_nodes(rows,request,cached)
        old_keys=('complete','node_issues','reference_zero','targets','core_ports','voltage_source_currents','total_supply_current_binding_ready','cgg_complete','optional_op_fields_missing')
        for name,value in [('node_request.json',request),('psf_before_sha256.json',fingerprint),('node_context.json',{k:report[k] for k in old_keys}),('node_read_status.json',dict(error='required node voltages incomplete; all targets reported',node_complete=False,psf_unchanged=True,op_cache_reused=True))]:
            (out/name).write_text(json.dumps(value))
        return out

    def test_target_success_retains_peripheral_gaps_and_does_not_fill_ground(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=TARGET_CONTEXT_READ_OK',result.stdout)
            self.assertIn('TARGET_NODES_COMPLETE=true',result.stdout)
            self.assertIn('CONTEXT_NODES_COMPLETE=false',result.stdout)
            self.assertIn('NODE_READ=PARTIAL',result.stdout)
            self.assertIn('UNRESOLVED_NODE_COUNT=3',result.stdout)
            self.assertIn('VSOURCE_TOPOLOGY VDD',result.stdout)
            report=json.loads(next(base.glob('node_context_*/node_context.json')).read_text())
            self.assertFalse(report['complete'])
            self.assertTrue(report['target_nodes_complete'])
            self.assertEqual(len(report['node_issues']),3)
            self.assertIsNone(report['core_ports']['IBIAS0']['value'])

    def test_v1_cache_is_reused_and_only_missing_nodes_are_queried_then_reusable_again(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
            old=self.seed_v1_node_cache(s,r,p,b,e,base)
            before={f:f.read_bytes() for f in base.rglob('*') if f.is_file()}
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('NODE_VALUES_REUSED=true',result.stdout)
            self.assertIn('NODE_QUERY_COUNT=3',result.stdout)
            queries=list(base.glob('node_context_*/node_pending_request.json'))
            self.assertEqual(len(queries),1)
            request=json.loads(queries[0].read_text())
            self.assertEqual(set(request['nodes']),{'AGND',r'net037\<0\>',r'net037\<1\>'})
            self.assertEqual(request['voltage_sources'],[])
            for f,data in before.items():self.assertEqual(f.read_bytes(),data,str(f))
            e['ST_NODE_TEST_MODE']='resolve_context'
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('NODE_READ=COMPLETE',result.stdout)
            launches=len(list(base.rglob('node_launch_observed')))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('NODE_QUERY_COUNT=0',result.stdout)
            self.assertEqual(len(list(base.rglob('node_launch_observed'))),launches)

    def test_invalid_latest_node_cache_blocks_reuse_and_no_fallback(self):
        for mode in ('request','report','raw','psf','marker','failed_latest'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
                old=self.seed_v1_node_cache(s,r,p,b,e,base)
                if mode=='request':
                    f=old/'node_request.json';data=json.loads(f.read_text());data['nodes'].append('wrong');f.write_text(json.dumps(data))
                elif mode=='report':
                    f=old/'node_context.json';data=json.loads(f.read_text());data['targets']['I21']['terminal_voltages']['D']=9;f.write_text(json.dumps(data))
                elif mode=='raw':
                    f=old/'node_read/values.tsv';f.write_text(f.read_text().replace('1.14','9'))
                elif mode=='psf':(old/'psf_before_sha256.json').write_text('{}')
                elif mode=='marker':(old/'node_read/runtime.done').write_text('BAD')
                else:
                    late=base/'node_context_later';late.mkdir();f=late/'node_read_status.json';f.write_text(json.dumps({'psf_unchanged':False,'error':'native failed'}))
                    now=(old/'node_read_status.json').stat().st_mtime_ns+1000000000;os.utime(f,ns=(now,now))
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertFalse(list(base.rglob('node_launch_observed')))

    def test_unlisted_name_is_queried_directly_and_inventory_is_saved(self):
        mod=self.module();request={'nodes':['AGND'],'voltage_sources':[]}
        code=mod.node_context_script(Path('/psf'),request,Path('/init'),Path('/work/values.tsv'))
        self.assertNotIn('if(member(name signals)',code)
        self.assertIn('getData(name)',code)
        self.assertIn('outputs.txt',code)
        # Balance forms/strings; this does not execute or prove native SKILL behavior.
        fixtures.saved_fixture.CascodeSolverSettingsTest().module().extract_forms(code)

    def test_corrupt_peripheral_values_are_errors_even_with_complete_targets(self):
        for mode in ('peripheral_nan','peripheral_duplicate'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
                e['ST_NODE_TEST_MODE']=mode
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertIn('TARGET_NODES_COMPLETE=true',result.stdout)
                self.assertIn('RESULT=INCOMPLETE',result.stdout)
                self.assertIn('NODE_TARGET I105',result.stdout)

    def test_v2_reuse_rechecks_original_native_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
            old=self.seed_v1_node_cache(s,r,p,b,e,base)
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            launches=len(list(base.rglob('node_launch_observed')))
            table=old/'node_read/values.tsv'
            table.write_text(table.read_text().replace('1.14','1.15'))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('node source changed',result.stdout)
            self.assertEqual(len(list(base.rglob('node_launch_observed'))),launches)

    def test_native_retry_failure_keeps_proven_cached_target_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp),peripheral=True)
            self.seed_v1_node_cache(s,r,p,b,e,base)
            e['ST_NODE_TEST_MODE']='no_marker'
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('TARGET_NODES_COMPLETE=true',result.stdout)
            self.assertIn('CACHED_CGG_COMPLETE=true',result.stdout)
            self.assertIn('NODE_TARGET I21 D=1.14',result.stdout)
            self.assertIn('NODE_TARGET I105 D=1.14',result.stdout)
            self.assertIn('RESULT=INCOMPLETE',result.stdout)

    def test_generated_query_status_is_independent_of_inventory_membership(self):
        mod=self.module();code=mod.node_context_script(Path('/psf'),{'nodes':['AGND'],'voltage_sources':[]},Path('/init'),Path('/work/values.tsv'))
        # Source-boundary check only: missing name -> nil, errset failure -> error,
        # present non-scalar -> NON_NUMERIC. Native execution is not emulated.
        self.assertNotIn('null(listed)',code)
        self.assertIn('(null(result) "READ_ERROR")',code)
        self.assertIn('(null(car(result)) "MISSING")',code)

    def test_reuses_successful_op_and_reads_absolute_nodes_without_simulation(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp))
            before={f:f.read_bytes() for f in b.rglob('*') if f.is_file()}
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=BASELINE_CONTEXT_READ_OK',result.stdout)
            self.assertIn('OP_CACHE_REUSED=true',result.stdout)
            self.assertIn('PSF_UNCHANGED=true',result.stdout)
            self.assertIn('SPECTRE_RERUN=false',result.stdout)
            self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout)
            self.assertLessEqual(len(result.stdout.splitlines()),190)
            output=next(base.glob('node_context_*'))
            report=json.loads((output/'node_context.json').read_text())
            self.assertEqual(report['targets']['I21']['terminal_voltages'],{'D':1.14,'G':0.43,'S':0.0,'B':0.0})
            self.assertEqual(report['targets']['I105']['cached_op']['cgg'],2e-15)
            self.assertEqual(report['voltage_source_currents'][0]['value'],-0.0001)
            self.assertFalse(report['total_supply_current_binding_ready'])
            for f,data in before.items():self.assertEqual(f.read_bytes(),data,str(f))

    def test_bad_node_results_fail_without_zero_filling_and_report_both_targets(self):
        for mode in ('missing','nonnumeric','nan','duplicate','no_marker'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e,base,cache=self.fixture(Path(tmp));e['ST_NODE_TEST_MODE']=mode
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('RESULT=BASELINE_CONTEXT_READ_OK',result.stdout)
                if mode!='no_marker':
                    self.assertIn('NODE_TARGET I21',result.stdout);self.assertIn('NODE_TARGET I105',result.stdout)
                    self.assertNotIn('G=0.0 ',result.stdout)

    def test_failed_latest_op_cache_is_not_replaced_by_an_older_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp))
            late=base/'op_review_later';late.mkdir()
            (late/'op_read_status.json').write_text(json.dumps({'op_complete':False,'psf_unchanged':True}))
            now=(cache/'op_read_status.json').stat().st_mtime_ns+1000000000
            os.utime(late/'op_read_status.json',ns=(now,now))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertFalse(list(base.rglob('node_launch_observed')))

    def test_cache_psf_binding_and_native_cdf_proof_are_required_before_launch(self):
        for mode in ('psf','cache','master','term_order','native_cache'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e,base,cache=self.fixture(Path(tmp))
                if mode=='psf':(base/'baseline_results/psf/dcOp.dc').write_text('different old result')
                elif mode=='cache':
                    f=cache/'baseline_op_report.json';d=json.loads(f.read_text());d['targets'][0]['devices'][0]['normalized']['id']=99;f.write_text(json.dumps(d))
                else:
                    f=b/'native/report.tsv';text=f.read_text()
                    if mode=='master':text=text.replace('"PDK"','"WRONG"')
                    elif mode=='term_order':text=text.replace('(D G S B)','(D G S S)')
                    else:text=text.replace('(D G S B)','(G D S B)')
                    f.write_text(text)
                    if mode!='native_cache':
                        import read_maestro_setup
                        (b/'native_records.json').write_text(json.dumps(read_maestro_setup.read_records(text)))
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout)
                self.assertFalse(list(base.rglob('node_launch_observed')))

    def test_native_terminal_order_is_used_instead_of_assuming_dgsb(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp))
            f=b/'native/report.tsv';f.write_text(f.read_text().replace('(D G S B)','(G D S B)'))
            import read_maestro_setup
            (b/'native_records.json').write_text(json.dumps(read_maestro_setup.read_records(f.read_text())))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout)
            out=next(base.glob('node_context_*'))
            voltages=json.loads((out/'node_context.json').read_text())['targets']['I21']['terminal_voltages']
            self.assertEqual(voltages,{'G':1.14,'D':0.43,'S':0.0,'B':0.0})

    def test_missing_cached_cgg_preserves_nodes_but_does_not_claim_candidate_fields_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp));mod=self.module()
            table=cache/'baseline_op/values.tsv';table.write_text('\n'.join(line for line in table.read_text().splitlines() if '\tcgg\t' not in line)+'\n')
            rows=mod.cb.table(table)
            (cache/'baseline_op.json').write_text(json.dumps(rows))
            (cache/'baseline_op_report.json').write_text(json.dumps(mod.summarize_op(rows,['XCORE.I21','XCORE.I105'])))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertIn('NODE_READ=COMPLETE',result.stdout)
            self.assertIn('CACHED_CGG_COMPLETE=false',result.stdout)
            self.assertIn('NODE_TARGET I105',result.stdout)

    def test_nested_native_terminal_order_is_rejected_before_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp))
            f=b/'native/report.tsv';f.write_text(f.read_text().replace('(D G S B)','(D (G S) B)'))
            import read_maestro_setup
            (b/'native_records.json').write_text(json.dumps(read_maestro_setup.read_records(f.read_text())))
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertFalse(list(base.rglob('node_launch_observed')))

    def test_cgg_completeness_does_not_imply_optional_region_and_reversed_available(self):
        mod=self.module()
        request={'nodes':['0'],'targets':{'I21':{'terminals':{'D':'0','G':'0','S':'0','B':'0'}}},'core_ports':{},'voltage_sources':[]}
        report=mod.summarize_nodes([],request,{'I21':{'cgg':1e-15}})
        self.assertIn('cgg_complete',report)
        self.assertTrue(report['cgg_complete'])
        self.assertEqual(report['optional_op_fields_missing'],{'I21':['region','reversed']})

    def test_psf_mutation_during_read_never_reports_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base,cache=self.fixture(Path(tmp));e['ST_NODE_TEST_MODE']='mutate_psf';e['ST_NODE_TEST_PSF']=str(base/'baseline_results/psf/dcOp.dc')
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout)
            self.assertIn('PSF_UNCHANGED=false',result.stdout)

    def test_resolves_only_requested_hierarchy_with_global_nodes_and_no_parameter_evaluation(self):
        mod=self.module()
        self.assertTrue(hasattr(mod,'resolve_instance_nodes'),'exact node binding helper absent')
        text='''simulator lang=spectre
global VSS!
subckt core D G S B
I21 (D local S B) nmod
ends core
subckt wrapper P N
X (P gate N VSS!) core undefined="unrelated_expr()"
ends wrapper
TOP (VIN 0) wrapper
'''
        self.assertEqual(mod.resolve_instance_nodes(text,'TOP.X.I21')['nodes'],['VIN','TOP.X.local','0','VSS!'])
        with self.assertRaises(ValueError):mod.resolve_instance_nodes(text,'TOP.X.I210')

    def test_node_integer_negative_zero_and_unrequested_rows_are_not_conflated(self):
        mod=self.module();self.assertTrue(hasattr(mod,'summarize_nodes'),'node consumer absent')
        request={'nodes':['0','A','B'],'targets':{'I21':{'terminals':{'D':'A','G':'B','S':'0','B':'0'}}},'core_ports':{'OUT':'A'},'voltage_sources':[]}
        cached={'I21':{'cgg':2e-15,'vgs':.3,'vds':.6,'vgst':-1,'vdst':0}}
        rows=[{'kind':'node','signal':'A','value':'0','status':'OK'},{'kind':'node','signal':'B','value':'-1','status':'OK'}]
        report=mod.summarize_nodes(rows,request,cached)
        self.assertTrue(report['complete']);self.assertEqual(report['targets']['I21']['terminal_differences'],{'vgs':-1.0,'vds':0.0,'vbs':0.0})
        with self.assertRaises(ValueError):mod.summarize_nodes(rows+[{'kind':'node','signal':'NEIGHBOR','value':'1','status':'OK'}],request,cached)

if __name__=='__main__':unittest.main()
