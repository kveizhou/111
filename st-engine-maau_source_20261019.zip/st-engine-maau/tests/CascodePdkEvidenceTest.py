"""Bounded, read-only PDK evidence discovery; no native EDA fixtures needed."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ENTRY = Path(__file__).resolve().parents[1] / 'server/site/inspect_cascode_pdk_evidence.py'


class PdkEvidenceTest(unittest.TestCase):
    def fixture(self, root):
        session = root/'session'; session.mkdir()
        batch = root/'batch'; bridge = batch/'dc_review_ports_1/runtime_bridge_1'
        (bridge/'bundle').mkdir(parents=True)
        pdk = root/'PDK'; pdk.mkdir()
        def save(path, obj):
            path.write_text(json.dumps(obj))
        save(bridge/'bridge_status.json', dict(error=None, bundle_error=None, cache_match=True, psf_unchanged=True))
        save(bridge/'bundle/baseline_bundle.json', dict(session=str(session), dependency_policy='native-site', models=[], file_sha256={}))
        path = bridge/'bundle/baseline_bundle.json'
        path.with_suffix('.sha256').write_text(hashlib.sha256(path.read_bytes()).hexdigest()+'\n')
        save(bridge/'pdk.json', dict(targets={'I21':dict(master={'oa_library':'PDK','oa_cell':'nfet_h','model_name':'nmod'}, cdf_probe=[dict(parameter='l',default_value='30n',min='',max='')],metadata=[])},catalog=[dict(kind='resistor',oa_library='PDK',oa_cell='rpoly')],metadata=[dict(pdk_paths=[str(pdk)])]))
        return session,batch,pdk,bridge

    def run_entry(self,session,batch,*extra):
        self.assertTrue(ENTRY.is_file(), 'PDK evidence entry not implemented')
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(session),'--batch',str(batch),*extra],text=True,capture_output=True)

    def test_reads_cached_cdf_and_finds_related_text_without_modifying_sources(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);s,b,p,bridge=self.fixture(root)
            (p/'nfet_h.il').write_text('procedure(nfet_hCdf()\n minVal=20n\n maxVal=200n\n)\n')
            (p/'unrelated.il').write_text('maxVgs=100\n')
            (p/'Reliability_Manual.pdf').write_bytes(b'%PDF-local-placeholder')
            (p/'model.enc').write_bytes(b'\xff\x00 encrypted')
            before={f:f.read_bytes() for f in root.rglob('*') if f.is_file()}
            result=self.run_entry(s,b)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=EVIDENCE_COLLECTED',result.stdout)
            self.assertIn('SPECTRE_RERUN=false',result.stdout)
            output=Path(next(line.split('=',1)[1] for line in result.stdout.splitlines() if line.startswith('OUTPUT_DIR=')))
            report=json.loads((output/'evidence.json').read_text())
            self.assertFalse(report['electrical_rules_ready'])
            self.assertEqual(report['targets']['I21']['cdf_probe'][0]['min'],'')
            self.assertTrue(any(h['line']==2 and 'minVal' in h['text'] for h in report['search']['hits']))
            self.assertFalse(any('unrelated' in h['path'] for h in report['search']['hits']))
            self.assertTrue(any(x['path'].endswith('.pdf') for x in report['search']['documents']))
            self.assertEqual(before,{f:f.read_bytes() for f in before})

    def test_rejects_cross_session_and_failed_latest_acceptance(self):
        with tempfile.TemporaryDirectory() as d:
            s,b,p,bridge=self.fixture(Path(d));other=Path(d)/'other';other.mkdir()
            self.assertEqual(self.run_entry(other,b).returncode,2)
            (bridge/'bridge_status.json').write_text(json.dumps(dict(error='changed',cache_match=False,psf_unchanged=True)))
            result=self.run_entry(s,b)
            self.assertEqual(result.returncode,2);self.assertIn('acceptance',result.stdout)

    def test_reports_bounded_scan_and_missing_optional_native_cache(self):
        with tempfile.TemporaryDirectory() as d:
            s,b,p,bridge=self.fixture(Path(d))
            for i in range(5):(p/('nfet_h_'+str(i)+'.il')).write_text('minVal=1\n')
            result=self.run_entry(s,b,'--max-files','2')
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            out=Path(next(x.split('=',1)[1] for x in result.stdout.splitlines() if x.startswith('OUTPUT_DIR=')))
            report=json.loads((out/'evidence.json').read_text())
            self.assertTrue(report['search']['limited']);self.assertIn('native_records.json',report['cache_notes'][0])

    def test_does_not_follow_symlinks_or_search_other_pdk_roots(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);s,b,p,bridge=self.fixture(root)
            outside=root/'otherPDK';outside.mkdir();(outside/'nfet_h.il').write_text('maxVgs=999\n')
            (p/'alias').symlink_to(outside,target_is_directory=True)
            (p/'nfet_h.il').symlink_to(outside/'nfet_h.il')
            result=self.run_entry(s,b);self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertNotIn('maxVgs=999',result.stdout)

    def test_accepts_actual_bridge_output_and_runs_as_standalone_copy(self):
        import CascodeRuntimeBridgeTest as fixture_module
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);fixture=fixture_module.CascodeRuntimeBridgeTest()
            s,r,p,b,e,base=fixture.prepare(root)
            accepted=fixture.invoke(s,r,p,b,e)
            self.assertEqual(accepted.returncode,0,accepted.stdout+accepted.stderr)
            script=root/'standalone_helper.py';script.write_bytes(ENTRY.read_bytes())
            # No repo import paths and EDA binaries intentionally unavailable.
            e.update(ST_OCEAN_BIN='/not-called',ST_VIRTUOSO_BIN='/not-called',ST_SPECTRE_BIN='/not-called')
            result=subprocess.run([sys.executable,str(script),'--session',str(s),'--batch',str(b)],cwd=root,env=e,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=EVIDENCE_COLLECTED',result.stdout)
            self.assertIn('TARGET I21 ',result.stdout)
            self.assertIn('PDK_ELECTRICAL_RULES_READY=false',result.stdout)

    def test_snippet_cap_still_discovers_documentation_in_other_bound_root(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);s,b,p,bridge=self.fixture(root)
            (p/'nfet_h.il').write_text('maxVgs=1\n'*200)
            docs=root/'docs';docs.mkdir();(docs/'nfet_h_manual.pdf').write_bytes(b'%PDF')
            result=self.run_entry(s,b,'--pdk-dir',str(docs))
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('nfet_h_manual.pdf',result.stdout)

    def test_generic_skill_functions_do_not_consume_device_search_results(self):
        with tempfile.TemporaryDirectory() as d:
            s,b,p,bridge=self.fixture(Path(d))
            native=[dict(kind='cdf_callback',scope='I21',name='l',status='OK',
                raw_value=json.dumps('if(readstring(cdfData->l->value)<70e-9 then errset(error("limit"))) HiEPDK_LL_CB("l")'))]
            (b/'native_records.json').write_text(json.dumps(native))
            (p/'libInit.il').write_text('errset(load("unrelated"))\n'*200)
            (p/'actual.il').write_text('procedure(HiEPDK_LL_CB(name)\n minVal=70n\n)\n')
            (p/'different.il').write_text('model nmod_other bsimcmg type=n\n')
            result=self.run_entry(s,b)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            out=Path(next(x.split('=',1)[1] for x in result.stdout.splitlines() if x.startswith('OUTPUT_DIR=')))
            report=json.loads((out/'evidence.json').read_text())
            self.assertNotIn('errset',report['search_tokens'])
            self.assertNotIn('readstring',report['search_tokens'])
            self.assertTrue(any('actual.il' in h['path'] for h in report['search']['hits']))
            self.assertFalse(any('libInit.il' in h['path'] or 'different.il' in h['path'] for h in report['search']['hits']))

    def test_callbacks_are_complete_and_summary_omits_cdf_passthrough_mapping(self):
        with tempfile.TemporaryDirectory() as d:
            s,b,p,bridge=self.fixture(Path(d))
            callback='if(atoi(cdfData->nfin->value)<4 then cdfData->nfin->value="4")\n'+'; padding\n'*40+'checkExtraGeometryAfterLimits()'
            (b/'native_records.json').write_text(json.dumps([dict(kind='cdf_callback',scope='I21',name='nfin',status='OK',raw_value=json.dumps(callback))]))
            data=json.loads((bridge/'pdk.json').read_text())
            mapping=','.join('cdf_noise'+str(i)+':noise'+str(i) for i in range(500))+',length:l,multiplier:m'
            data['targets']['I21']['master']['normalized_to_cdf']=mapping
            (bridge/'pdk.json').write_text(json.dumps(data))
            result=self.run_entry(s,b,'--cached-only')
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn(callback,result.stdout)
            self.assertNotIn('cdf_noise',result.stdout)
            self.assertIn('CALLBACK_OUTPUT_COMPLETE=true',result.stdout)
            self.assertIn('PDK_SEARCH=SKIPPED_CACHED_ONLY',result.stdout)
            out=Path(next(x.split('=',1)[1] for x in result.stdout.splitlines() if x.startswith('OUTPUT_DIR=')))
            self.assertEqual(json.loads((out/'evidence.json').read_text())['targets']['I21']['master']['normalized_to_cdf'],mapping)


if __name__ == '__main__': unittest.main()
