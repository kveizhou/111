"""Experimental input binding contracts; no Cadence execution is implied."""
import json
import copy
import csv
import hashlib
from pathlib import Path
import sys
import unittest
import tempfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'server/site'))
import prepare_cascode_experiment as prepare
import experiment_bindings as bind


class BindingsTest(unittest.TestCase):
    def test_generated_aliases_are_not_geometry_or_required_seed_values(self):
        master = dict(normalized_to_cdf={'length':'l', 'multiplier':'m', 'cdf_l':'l',
            'cdf_m':'m', 'cdf_model':'model', 'cdf_label':'label', 'cdf_nfin':'nfin',
            'cdf_fingers':'fingers', 'cdf_fw':'fw'})
        rows = [{'parameter':p} for p in ('l','m','model','label','nfin','fingers','fw')]
        result = prepare.geometry_mapping(master, rows)
        self.assertEqual(result, {'length':'l','multiplier':'m','fin':'nfin','fingers':'fingers'})
        self.assertEqual(len(result), len(set(result.values())))

    def test_explicit_semantics_are_preserved_and_real_conflict_rejected(self):
        rows = [{'parameter':p} for p in ('l','nf','nfin','m')]
        master = dict(normalized_to_cdf={'length':'l','fin':'nfin','fingers':'nf','multiplier':'m'})
        self.assertEqual(prepare.geometry_mapping(master, rows), master['normalized_to_cdf'])
        master['normalized_to_cdf']['width']='l'
        with self.assertRaisesRegex(ValueError, 'conflict'):
            prepare.geometry_mapping(master, rows)

    def test_missing_probe_parameter_does_not_create_mapping(self):
        self.assertEqual(prepare.geometry_mapping({'normalized_to_cdf':'length:l,cdf_nfin:nfin'},
            [{'parameter':'l'}]), {'length':'l'})

    def test_normalized_draft_is_consumable_by_real_experimental_metadata_builder(self):
        import ExperimentalPdkTest as fixture_module
        from experimental_pdk import build_experimental_metadata
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            probe,native,profile,rules=fixture_module.ExperimentalPdkTest().fixture(root)
            with probe.open() as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
            mapping={'length':'l','multiplier':'m','cdf_l':'l','cdf_m':'m','cdf_model':'model','cdf_nfin':'nfin'}
            rules['devices']['PDK/opaque']['normalized_to_cdf']=prepare.geometry_mapping({'normalized_to_cdf':mapping},rows)
            meta=build_experimental_metadata(root,probe,profile,rules)
            self.assertEqual(meta['devices'][0]['actual_parameter_seed']['fin'],6)
            self.assertNotIn('cdf_model',meta['devices'][0]['normalized_to_cdf'])

    def fixture(self, root):
        records=[]; targets={}; rules={'source':'native evidence','devices':{}}
        origins={'sources':{}}; request={'core_path':'top.core','targets':{}}
        high={'node':'top.vdd','value':1.2}; low={'node':'top.gnd','value':0.001}
        request['core_ports']={'AVDD':high['node'],'AGND':low['node']}
        node={'core_ports':{'AVDD':high,'AGND':low},'targets':{}}
        def rec(kind,name,key,val,literal=False):
            records.append(dict(kind=kind,scope=name,name=key,status='OK',raw_value=val if literal else json.dumps(val)))
        for name,cell,rail,kind in [('I21','opaque_a','AGND','n'),('I105','opaque_b','AVDD','p')]:
            master=dict(oa_library='PDK',oa_cell=cell,model_name=cell,terminal_names='D,G,S,B',terminal_roles='drain,gate,source,bulk')
            targets[name]={'master':master}
            rules['devices']['PDK/'+cell]=dict(model=cell,normalized_to_cdf=dict(length='l',fin='nfin',multiplier='m'),terminalRoles=dict(D='drain',G='gate',S='source',B='bulk'))
            request['targets'][name]=dict(path='top.core.'+name,master=cell,terminals={'B':high['node'] if kind=='p' else low['node']})
            for key,val in dict(oa_library='PDK',oa_cell=cell).items(): rec('source',name,key,val)
            for key,val in dict(l='134n',nfin='6',m='1',model=cell,label='text').items():rec('cdf_value',name,key,val)
            rec('terminal',name,'B',rail)
            rec('cdf_mapping',name,'termOrder','("D" "G" "S" "B")',True)
            rec('model_binding',name,'instance_model','("/top/core/'+name+'" "shared_opaque_model_'+kind+'")',True)
            rec('model_type',name,'type',kind)
            for param in ('id','vth','vdssat','cgg','vgs','vds'):
                origins['sources']['top.core.'+name+':'+param]=dict(signal='/top/core/'+name,device_type='bsimcmg',parameter=param,result='dcOpInfo')
        resistor=dict(kind='resistor',oa_library='PDK',oa_cell='rpoly',model_name='rpoly',terminal_names='PLUS,MINUS',terminal_roles='positive,negative')
        pdk=dict(targets=targets,catalog=[resistor],metadata=[])
        rec('selection','resistor','instance','R0')
        for key,val in dict(oa_library='PDK',oa_cell='rpoly').items():rec('source','R0',key,val)
        for key,val in dict(r='10k',m='1',model='rpoly').items():rec('cdf_value','R0',key,val)
        for key,val in dict(PLUS='AVDD',MINUS='AGND').items():rec('terminal','R0',key,val)
        rec('positive_current','R0','mapping','\\:1',True)
        rec('cdf_mapping','R0','termOrder','(PLUS MINUS)',True)
        (root/'native_records.json').write_text(json.dumps(records))
        profile={'experimental_parameter_seeds':{}}
        return pdk,rules,profile,request,node,origins,records

    def test_binds_actual_model_type_cmg_body_and_real_resistor(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);args=self.fixture(root)
            pending,bound=bind.fill_facts(*args,root)
            self.assertEqual(pending,[])
            self.assertEqual(args[1]['devices']['PDK/opaque_a']['kind'],'mos_n')
            self.assertEqual(args[1]['devices']['PDK/opaque_b']['dc_signals']['vdsat'],'vdssat')
            self.assertEqual(args[2]['vbias_vhigh_net'],'AVDD')
            self.assertEqual(args[1]['devices']['PDK/rpoly']['dc_signals'],{'current':'1'})
            self.assertEqual(len(bound),4)
            self.assertNotIn('maxAbsVgs',args[1]['devices']['PDK/opaque_a'])

    def test_missing_enum_conflicting_body_wrong_op_and_expression_current_stay_pending(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for mode in ('numeric_type','body','op','current','terminal_order'):
                with self.subTest(mode=mode):
                    args=self.fixture(root);records=args[-1]
                    if mode=='numeric_type':
                        next(r for r in records if r['kind']=='model_type')['raw_value']='1'
                    elif mode=='body':
                        next(r for r in records if r['kind']=='terminal')['raw_value']='"VOUT"'
                    elif mode=='op':
                        args[-2]['sources']['top.core.I21:vds']['device_type']='bsim4'
                    elif mode=='current':
                        next(r for r in records if r['kind']=='positive_current')['raw_value']=json.dumps('(FUNCTION minus(root("MINUS")))')
                    else:
                        next(r for r in records if r['kind']=='cdf_mapping')['raw_value']='(S G D B)'
                    pending,_=bind.fill_facts(*args,root)
                    self.assertTrue(pending)

    def test_type_labels_and_current_mapping_never_guess_numeric_encoding(self):
        self.assertEqual(bind.polarity('1',' type = n\n'),'mos_n')
        self.assertEqual(bind.polarity('p'),'mos_p')
        for raw,text in [(1,''),(-1,''),('n','type=p\n'),('n18_ckt','')]:
            with self.assertRaises(ValueError):bind.polarity(raw,text)
        self.assertEqual(bind.direct_current_mapping('\\:1'),'1')
        with self.assertRaises(ValueError):bind.direct_current_mapping('p')

    def test_native_script_is_bounded_read_only_and_balanced(self):
        import re
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);pdk,_,_,request,*_=self.fixture(root)
            code=bind.native_script({'source':dict(lib='USER',cell='core',view='schematic')},request,pdk,root/'psf',root)
            self.assertIn('ocnGetInstancesModelName',code)
            self.assertIn('cdfGetInstCDF',code)
            self.assertNotRegex(code,r'\b(?:dbSave|dbCreateInst|run|netlist|analysis)\s*\(')
            clean=re.sub(r'"(?:\\.|[^"\\])*"','""',code)
            depth=0
            for char in clean:
                depth += (char=='(')-(char==')')
                self.assertGreaterEqual(depth,0)
            self.assertEqual(depth,0)
            self.assertNotIn('__',code)

    def test_full_binding_handoff_builds_real_seed_metadata_without_simulation(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);out=root/'experiment';out.mkdir();args=self.fixture(out)
            pdk,rules,profile,request,node,origins,records=args
            session=root/'session';archive=session/'analysis/standalone_inputs';archive.mkdir(parents=True)
            (archive/'provider_inputs.json').write_text('{}')
            batch=root/'batch';bridge=batch/'dc_review_ports_1/runtime_bridge_1';bridge.mkdir(parents=True)
            (batch/'native_records.json').write_text(json.dumps([r for r in records if r['scope']!='R0']))
            psf=bridge.parent/'baseline_results/psf';psf.mkdir(parents=True);(psf/'dcOpInfo.info').write_text('fixture')
            probe=archive/'pdk_probe.tsv'
            with probe.open('w') as stream:
                w=csv.writer(stream,delimiter='\t',lineterminator='\n')
                w.writerow(['oa_library','oa_cell','model_name','terminal_names','parameter','units','has_schematic'])
                for cell,names,params in [('opaque_a','D,G,S,B',['l','nfin','m','model','label']),('opaque_b','D,G,S,B',['l','nfin','m','model','label']),('rpoly','PLUS,MINUS',['r','m','model'])]:
                    for param in params:w.writerow(['PDK',cell,cell,names,param,'lengthMetric' if param=='l' else 'resistance' if param=='r' else '', 'false'])
            profile.update(validation_scope='experimental_dc',experimental_pdk_cache={'probe':str(probe),'pdk_roots':[str(root)]},op_corners={})
            for cell,name in [('opaque_a','I21'),('opaque_b','I105')]:
                profile['experimental_parameter_seeds']['PDK/'+cell]={'instance':name,'trials':{}}
            report={'source_cache_sha256':{},'reliability_verified':False,'ready_for_sizing':False,'vbias_generated':False}
            def native(argv,directory,env,timeout,log):
                self.assertEqual(argv[0],'fake_ocean');self.assertIn('-restore',argv)
                lines=['ST_MAE_RECORD\t'+r['kind']+'\t'+json.dumps(r['scope'])+'\t'+json.dumps(r['name'])+'\t'+r['status']+'\t'+r['raw_value'] for r in records]
                (out/'native.tsv').write_text('\n'.join(lines+['ST_MAESTRO_SETUP_READ_COMPLETE'])+'\n')
            bench=root/'bench.scs';bench.write_text('subckt core AVDD AGND\nR0 (AVDD AGND) rpoly r=10k\nends core\n')
            bundle={'source':dict(lib='USER',cell='core',view='schematic'),'cds_lib':str(root/'cds.lib'),'bench_netlist':str(bench),'source_subckt':'core'}
            with patch('experiment_bindings.cached_binding_context',return_value=(request,node,origins,{})),patch('standalone.environment',return_value={}),patch('collect_cascode_batch.executable',return_value='fake_ocean'),patch('collect_cascode_batch.command',side_effect=native):
                self.assertEqual(bind.bind(out,session,batch,bridge,bundle,pdk,profile,rules,report,10),0)
            facts=json.loads((out/'pdk_facts.json').read_text())
            meta=json.loads((out/'experimental_metadata.preview.json').read_text())
            self.assertEqual(len(meta['devices']),3)
            self.assertEqual(meta['devices'][0]['actual_parameter_seed']['fin'],6)
            self.assertFalse(meta['reliability_verified'])
            self.assertNotIn('cdf_model',meta['devices'][0]['normalized_to_cdf'])

    def test_real_bridge_fixture_reuses_reader_and_node_shapes(self):
        import CascodeRuntimeBridgeTest as fixture_module
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);fixture=fixture_module.CascodeRuntimeBridgeTest()
            s,r,p,b,e,base=fixture.prepare(root)
            result=fixture.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            bridge=next(base.glob('runtime_bridge_*'))
            bundle=json.loads((bridge/'bundle/baseline_bundle.json').read_text())
            request,node,sources,hashes=bind.cached_binding_context(bridge,bundle)
            self.assertEqual(request['core_path'],bundle['root_path'])
            self.assertTrue(sources['sources'])
            self.assertTrue(hashes)
            raw=Path(json.loads((bridge/'bridge_status.json').read_text())['reader_cache_dir'])/'raw_signed.tsv'
            raw.write_text(raw.read_text()+'modified')
            with self.assertRaisesRegex(ValueError,'changed'):bind.cached_binding_context(bridge,bundle)


if __name__ == '__main__':
    unittest.main()
