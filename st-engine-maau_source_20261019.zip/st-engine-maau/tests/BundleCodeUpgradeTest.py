"""Published tool migration across real loaders; native EDA is a fixture boundary."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
OLD_DC_READER = '15e50b2ae02441eaae203ac02dfa229d77f4943456a272044f585da39774ff3f'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def retain_old_tool_versions(path):
    """Construct historical test evidence, never modify a production bundle."""
    bundle = json.loads(path.read_text())
    release = json.loads((ROOT / 'scripts/cascode_reuse_update.json').read_text())
    for relative, entry in release['files'].items():
        old = next((value for value in entry['before_sha256'] if value), None)
        if old:
            name = str(ROOT / relative)
            bundle['file_sha256'][name] = old
            bundle['historical_verified_paths'] = sorted(set(bundle['historical_verified_paths']) | {name})
    # This reader was pinned in actual old sessions, independently of whether
    # a later release author remembered to list its update.
    reader = str(ROOT / 'server/site/dc_results.py')
    bundle['file_sha256'][reader] = OLD_DC_READER
    bundle['historical_verified_paths'] = sorted(set(bundle['historical_verified_paths']) | {reader})
    path.write_text(json.dumps(bundle))
    path.with_suffix('.sha256').write_text(digest(path))


class BundleCodeUpgradeTest(unittest.TestCase):
    def fixture(self, root):
        from BaselineBundleTest import BaselineBundleTest
        from standalone import environment
        import baseline_bundle as module
        bound, baseline, output, paths = BaselineBundleTest().fixture(root)
        forms = json.loads((baseline/'settings_forms.json').read_text())
        forms.append('envOption(\'displayToolTip t \'autoDisplay t)')
        (baseline/'settings_forms.json').write_text(json.dumps(forms))
        (baseline/'saved_test.ocn').write_text('\n'.join(forms)+'\nrun()\n')
        bound['fixed'] = {name:digest(name) for name in bound['fixed']}
        spectre = root/'fixture-spectre'; spectre.write_text('fixture binary identity'); spectre.chmod(0o755)
        log = baseline/'baseline_run/ocean.log'
        log.write_text(log.read_text()+'Spectre (R) Circuit Simulator\nVersion 18.1.fixture 64bit\n')
        bound['fixed'][str(log)] = digest(log)
        with patch.dict(os.environ, {'ST_SPECTRE_BIN':str(spectre)}):
            path = module.export_bundle(bound, baseline, output)
            bundle = module.load_bundle(path)
        retain_old_tool_versions(path)
        profile = dict(validation_scope='experimental_dc', validated_baseline_bundle=str(path),
            nominal_corner=bundle['corner'], op_corners={bundle['corner']:dict(
                temperature=bundle['temperature'], models=bundle['models'], variables=bundle['variables'])})
        inputs = {}
        for key, data in [('rules', profile), ('context', {}), ('tech', {})]:
            item = root / (key + '.json'); item.write_text(json.dumps(data)); inputs[key] = str(item)
        inputs.update(adapter=str(ROOT/'server/skill/pdk_adapter.il'), runtime=str(ROOT/'server/site/cascode_runtime.py'))
        inputs['file_sha256'] = {name:digest(name) for name in inputs.values()}
        release = json.loads((ROOT/'scripts/cascode_reuse_update.json').read_text())
        inputs['file_sha256'].update({str(ROOT / name):entry['after_sha256'] for name,entry in release['files'].items()})
        manifest = root / 'provider_inputs.json'; manifest.write_text(json.dumps(inputs))
        env = environment(inputs, manifest); env['ST_SPECTRE_BIN'] = str(spectre)
        return module, path, bundle, inputs, env, paths

    def test_known_upgrade_reaches_candidate_export_and_binding_without_rewriting_history(self):
        import op_provider as op
        import cascode_runtime as runtime
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            module, path, bundle, inputs, env, _ = self.fixture(root)
            self.assertFalse(bundle['launch_contract']['complete'])
            protected = {p:p.read_bytes() for p in root.rglob('*') if p.is_file()}
            calls = []
            def native(argv, work, log, timeout):
                calls.append(argv)
                if argv[0] == env['ST_SPECTRE_BIN']:
                    Path(log).write_text('Spectre (R) Circuit Simulator\nVersion 18.1.fixture 64bit\n'
                        'Command line: spectre +aps=conservative +mt=4 input.scs\n')
                    psf = Path(argv[argv.index('-raw')+1])
                    (psf/'dcOp.dc').write_text('fixture nodes')
                    (psf/'dcOpInfo.info').write_text('fixture OP')
                    return
                # Only native execution is substituted. Production netlist,
                # port wrapping and all before/after bundle loads still run.
                (work/'runtime.done').write_text('OK\n')
                (work/'ports.txt').write_text('D\nG\nS\nB\n')
                generated = work/'generated'; generated.mkdir()
                (generated/'input.scs').write_text('simulator lang=spectre\nM0 (D G S B) nmod l=30n nfin=2\n')
            def command(executable, args, directory, label):
                self.assertEqual(label, 'export_dut')
                with patch.object(sys, 'argv', [executable] + args):
                    self.assertEqual(runtime.main(), 0)
            env['ST_SKILL_INIT'] = str(root/'unused-native-init.il')
            run = root/'candidate'; run.mkdir()
            args = SimpleNamespace(dut_lib='DERIVED', dut_cell='candidate', dut_view='schematic', corner=bundle['corner'])
            with patch.dict(os.environ, env, clear=True), patch.object(op, 'command', command), \
                    patch.object(runtime, 'native', native), patch.object(runtime, 'executable',
                        side_effect=lambda name, default: env.get(name, '/fixture/ocean')):
                actual, text, hierarchy = op.prepare_bundle_candidate(args, json.loads(Path(inputs['rules']).read_text()),
                    bundle['source'], bundle['bench'], root/'cds.lib', inputs['runtime'], run)
                self.assertEqual(module.load_bundle(path), actual)
                self.assertTrue(actual['_functional_scope'])
                self.assertEqual(actual['_tool_upgrades'],{})
                deck = run/'simulation.scs'; deck.write_text(text)
                runtime.simulate(SimpleNamespace(baseline_bundle=str(path),netlist=str(deck),
                    psf_dir=str(run/'psf'),log=str(run/'spectre.log'),timeout=10))
            self.assertEqual(len(calls), 2)
            self.assertEqual(hierarchy, 'TOP.DUT')
            self.assertIn('l=30n', text)
            self.assertIn('maxiters=150 maxsteps=10000', text)
            self.assertTrue(all(p.read_bytes() == raw for p,raw in protected.items()))

    def test_entry_checks_circuit_inputs_without_rechecking_tools_or_old_psf(self):
        for mode in ('unknown_old','active_hash','old_psf','model','bench','wrong_bundle','environment'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp).resolve()
                module,path,bundle,inputs,env,paths=self.fixture(root)
                if mode=='unknown_old':
                    value=json.loads(path.read_text())
                    value['file_sha256'][str(ROOT/'server/skill/pdk_adapter.il')]='unlisted version'
                    path.write_text(json.dumps(value))
                elif mode=='active_hash':inputs['file_sha256'][inputs['adapter']]='unlisted version'
                elif mode=='old_psf':(paths['psf']/'dcOp.dc').write_text('not used: accepted OP rows already cached')
                elif mode=='model':paths['model'].write_text('changed model')
                elif mode=='bench':Path(bundle['bench_netlist']).write_text('changed bench')
                elif mode=='wrong_bundle':
                    profile=Path(inputs['rules']);value=json.loads(profile.read_text())
                    value['validated_baseline_bundle']='other';profile.write_text(json.dumps(value))
                elif mode=='environment':env['ST_PDK_TECH_ADAPTER']=str(root/'other-adapter')
                (root/'provider_inputs.json').write_text(json.dumps(inputs))
                with patch.dict(os.environ,env,clear=True):
                    if mode in ('unknown_old','active_hash','old_psf'):
                        loaded=module.load_bundle(path,verify_content=True)
                        self.assertTrue(loaded['_functional_scope'])
                        # Internal phases must not rehash the baseline inputs.
                        with patch.object(module,'_verify_fingerprints',side_effect=AssertionError('repeated check')):
                            module.load_bundle(path)
                    else:
                        with self.assertRaises(ValueError):module.load_bundle(path,verify_content=True)


if __name__=='__main__':unittest.main()
