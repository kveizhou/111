import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import sys

MODULE = Path(__file__).resolve().parents[1] / 'server/site/maau_config.py'
spec = importlib.util.spec_from_file_location('maau_config', MODULE)
cfg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cfg)
sys.path.insert(0, str(MODULE.parent))
import maau_case


def tech(root):
    return {
        'tech_name': 'process_a', 'pdk_name': 'pdk_a', 'pdk_path': str(root / 'pdk'),
        'tech_type': 'TechType.PLANAR', 'temperatures': [-40, 27, 125],
        'corners': [{'name': 'tt', 'sections': [
            {'model_file': str(root / 'pdk/models/mos.scs'), 'section_name': 'tt'}]}],
        'device_categories': {'DeviceType.MOS': {'devices': [{
            'cell_name': 'device_without_polarity_in_name', 'model_name': 'actual_n',
            'device_type': 'DeviceType.MOS', 'sub_device_type': 'SubDeviceType.NMOS',
            'normalization': {'normalize_inst_cdf_name_dict': {'L': 'l', 'FW': 'w',
                                                              'FIN': 'nf', 'MULTI': 'm'},
                              'normalize_sim_cdf_name_dict': {'L': 'l', 'FW': 'w'},
                              'normalize_dc_signal_name_dict': {'id': 'ids'}},
            'cdf_parameters': {'l': {'units': 'um', 'constraint': [0.18, 0.36, 1]},
                               'w': {'units': 'um', 'constraint': [1, 2, 10]},
                               'nf': {'units': '', 'constraint': [1, 2]},
                               'm': {'units': '', 'constraint': 1}},
            'lut_info': {'max_vol': 99}
        }]}}
    }


class SiteConfigTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'pdk/devices').mkdir(parents=True)
        (self.root / 'pdk/models').mkdir()
        (self.root / 'pdk/models/mos.scs').write_text('// real fixture model\n')
        self.path = self.root / 'tech_cfg_v2.0.json'
        self.data = tech(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def load(self, rules=None):
        self.path.write_text(json.dumps(self.data))
        return cfg.load_tech_config(self.path, rules)

    def test_typed_polarity_discrete_si_constraints_and_no_fake_rating(self):
        result = self.load()
        dev = result['devices'][0]
        self.assertEqual(dev['kind'], 'mos_n')
        self.assertEqual(dev['normalized_to_cdf']['width'], 'w')
        self.assertAlmostEqual(dev['constraints']['length']['allowed'][0], 0.18e-6)
        self.assertEqual(dev['constraints']['length']['grid'], 0)
        self.assertNotIn('maxAbsVgs', dev)
        self.assertIn('reliability', dev['missing'])
        self.assertEqual(result['corners'][0]['name'], 'tt')

    def test_path_membership_uses_directory_boundary_and_rejects_ambiguity(self):
        config = self.load()
        self.assertEqual(cfg.match_library(self.root / 'pdk/devices', [config]), config)
        with self.assertRaisesRegex(ValueError, 'unproven'):
            cfg.match_library(self.root / 'pdk_other/devices', [config])
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            cfg.match_library(self.root / 'pdk/devices', [config, copy.deepcopy(config)])

    def test_unknown_dimension_unit_and_nonfinite_constraint_rejected(self):
        self.data['device_categories']['DeviceType.MOS']['devices'][0]['cdf_parameters']['w']['units'] = 'training_unit'
        with self.assertRaisesRegex(ValueError, 'unit'):
            self.load()
        self.data['device_categories']['DeviceType.MOS']['devices'][0]['cdf_parameters']['w']['units'] = 'um'
        self.data['device_categories']['DeviceType.MOS']['devices'][0]['cdf_parameters']['w']['constraint'] = [float('nan')]
        with self.assertRaises(ValueError):
            self.load()

    def test_finfet_does_not_treat_fin_count_as_width(self):
        self.data['tech_type'] = 'TechType.FINFET'
        result = self.load()
        self.assertNotIn('width', result['devices'][0]['normalized_to_cdf'])
        self.assertIn('fin', result['devices'][0]['normalized_to_cdf'])

    def test_planar_finger_and_total_width_are_distinct(self):
        dev = self.data['device_categories']['DeviceType.MOS']['devices'][0]
        dev['normalization']['normalize_inst_cdf_name_dict']['W'] = 'wt'
        dev['cdf_parameters']['wt'] = {'units': 'um', 'constraint': [2, 4, 20]}
        parsed = self.load()['devices'][0]
        self.assertEqual(parsed['normalized_to_cdf']['width'], 'w')
        self.assertEqual(parsed['normalized_to_cdf']['total_width'], 'wt')
        self.assertAlmostEqual(parsed['constraints']['total_width']['allowed'][0], 2e-6)
        # W alone is total width, and is not proof of a per-finger CDF.
        del dev['normalization']['normalize_inst_cdf_name_dict']['FW']
        self.assertNotIn('width', self.load()['devices'][0]['normalized_to_cdf'])

    def test_pinned_site_inputs_reject_changed_profile_before_engine(self):
        context = self.root / 'context.json'
        rules = self.root / 'rules.json'
        metadata = self.root / 'metadata.json'
        adapter = self.root / 'adapter.il'
        runtime = self.root / 'runtime'
        context.write_text('{}')
        rules.write_text(json.dumps({'op_corners': {'tt': {'temperature': 27,
            'models': [{'model_file': str(self.root / 'pdk/models/mos.scs'), 'section_name': 'tt'}],
            'variables': {'VIN': '1.8'}}}, 'supply_current_signals': [{'signal': 'V0:p', 'sign': -1}]}))
        metadata.write_text(json.dumps([self.load()]))
        adapter.write_text('; fixture')
        runtime.write_text('#!/bin/sh\nexit 0\n')
        runtime.chmod(0o755)
        inputs = dict(context=str(context), rules=str(rules), tech=str(metadata),
                      adapter=str(adapter), runtime=str(runtime))
        pinned = cfg.pin_site_inputs(inputs)
        cfg.verify_site_inputs(pinned)
        active = {'ST_SITE_CASE_CONTEXT': str(context), 'ST_SITE_CASE_RULES': str(rules),
                  'ST_SITE_TECH_METADATA': str(metadata), 'ST_PDK_TECH_ADAPTER': str(adapter),
                  'ST_MAAU_RUNTIME_BIN': str(runtime)}
        cfg.verify_site_inputs(pinned, active)
        alternate = self.root / 'alternate_rules.json'
        alternate.write_text(rules.read_text())
        active['ST_SITE_CASE_RULES'] = str(alternate)
        with self.assertRaisesRegex(ValueError, 'active.*path'):
            cfg.verify_site_inputs(pinned, active)
        profile = json.loads(rules.read_text())
        profile['op_corners']['tt']['temperature'] = 125
        rules.write_text(json.dumps(profile))
        with self.assertRaisesRegex(ValueError, 'changed'):
            cfg.verify_site_inputs(pinned)
        # Even a changed model under the same section/path invalidates caching.
        rules.write_text(json.dumps({'op_corners': {'tt': {'temperature': 27,
            'models': [{'model_file': str(self.root / 'pdk/models/mos.scs'), 'section_name': 'tt'}],
            'variables': {'VIN': '1.8'}}}, 'supply_current_signals': [{'signal': 'V0:p', 'sign': -1}]}))
        (self.root / 'pdk/models/mos.scs').write_text('// revised model\n')
        with self.assertRaisesRegex(ValueError, 'changed'):
            cfg.verify_site_inputs(pinned)

    def test_rule_identity_and_authoritative_source_required(self):
        rules = {'tech_name': 'other', 'source': 'pdk reliability manual', 'devices': {}}
        with self.assertRaisesRegex(ValueError, 'identity'):
            self.load(rules)
        rules['tech_name'] = 'process_a'
        rules['source'] = ''
        with self.assertRaisesRegex(ValueError, 'source'):
            self.load(rules)

    def test_case_unique_selection_and_explicit_conflicts(self):
        context = {'source_dut': {'lib': 'L', 'cell': 'D', 'view': 'schematic'},
                   'source_benches': [{'lib': 'L', 'cell': 'B', 'view': 'maestro'}],
                   'source_cds_path': '/actual/cds', 'raw_case': {}}
        extension = {'nominal_corner': 'tt', 'pvt_corners': ['ss', 'ff'],
                     'vbias_vhigh_net': 'AVDD', 'vbias_vlow_net': 'AGND',
                     'max_branch_current_error': 0.1, 'max_vbias_current': '10u'}
        values = cfg.inspect_defaults(context, extension)
        self.assertEqual(values['bench-view'], 'maestro')
        self.assertEqual(values['cds-lib'], '/actual/cds/cds.lib')
        context['source_benches'][0]['sch_view'] = 'schematic'
        self.assertEqual(cfg.inspect_defaults(context, extension,
            {'lib': 'L', 'cell': 'B', 'view': 'maestro'})['bench-cell'], 'B')
        with self.assertRaisesRegex(ValueError, 'conflict'):
            cfg.merge_explicit(values, {'cell': 'different'})
        context['source_benches'].append({'lib': 'L', 'cell': 'B2', 'view': 'maestro'})
        with self.assertRaisesRegex(ValueError, 'Bench'):
            cfg.inspect_defaults(context, extension)

    def test_imported_case_selects_tech_and_generates_adapter(self):
        target = self.root / 'tech_root/process_a'
        target.mkdir(parents=True)
        (target / 'tech_cfg_v2.0.json').write_text(json.dumps(self.data))
        archive = self.root / 'archive'
        metadata, adapter = maau_case.prepare_tech({'source_tech_name': 'process_a'}, {},
            self.root / 'tech_root', None, None, archive)
        self.assertEqual(cfg.read_json(metadata)[0]['tech_name'], 'process_a')
        self.assertIn('site_metadata_adapter.il', adapter.read_text())
        self.assertIn('"kind" "mos_n"', adapter.read_text())
        with self.assertRaisesRegex(ValueError, 'identity conflict'):
            maau_case.prepare_tech({'source_tech_name': 'different'}, {}, None,
                target / 'tech_cfg_v2.0.json', None, archive)


if __name__ == '__main__':
    unittest.main()
