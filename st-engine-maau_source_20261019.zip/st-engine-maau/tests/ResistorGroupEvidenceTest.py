import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts/inspect_cascode_resistor_groups.py'


class ResistorGroupEvidenceTest(unittest.TestCase):
    def module(self):
        self.assertTrue(SCRIPT.is_file(),'resistor context reader missing')
        spec=importlib.util.spec_from_file_location('res_context',SCRIPT)
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

    def test_series_graph_and_external_uses(self):
        m=self.module()
        segments=[dict(name='R0',nodes=['A','mid']),dict(name='R0_2_res_gen',nodes=['mid','B'])]
        good=m.trace_series(segments,['A','B'],segments,set())
        self.assertEqual(good['path_nodes'],['A','mid','B'])
        self.assertEqual(good['segment_signs'],[1,1])
        reversed_part=[segments[0],dict(name='R0_2_res_gen',nodes=['B','mid'])]
        self.assertEqual(m.trace_series(reversed_part,['A','B'],reversed_part,set())['segment_signs'],[1,-1])
        cycle=segments+[dict(name='extra1',nodes=['X','Y']),dict(name='extra2',nodes=['Y','X'])]
        with self.assertRaises(ValueError):m.trace_series(cycle,['A','B'],cycle,set())
        for nodes in (['A','else'],['mid','mid']):
            bad=[segments[0],dict(name='R0_2_res_gen',nodes=nodes)]
            with self.subTest(nodes=nodes),self.assertRaises(ValueError):m.trace_series(bad,['A','B'],bad,set())
        for extras,protected in (([dict(name='M',nodes=['mid','G','0','0'])],set()),([],{'mid'})):
            with self.assertRaises(ValueError):m.trace_series(segments,['A','B'],segments+extras,protected)

    def fixture(self,root):
        candidate=root/'candidate_I21_test';work=candidate/'work'
        raw=work/'analysis/baseline_op/raw_op/st-op-simulation.test'
        raw.mkdir(parents=True);(work/'before').mkdir()
        (candidate/'run_status.json').write_text('{}')
        (raw/'export_dut.log').write_text('complete')
        (raw/'binding.json').write_text(json.dumps(dict(dut=['L','core','schematic'])))
        (raw/'dut.scs').write_text('simulator lang=spectre\nsubckt core A B\nR0 (A middle) rmod l=10u \\\n  w=1u\nR0_2_res_gen (middle B) rmod l=10u w=1u\nends core\n')
        (raw/'oa_bindings.tsv').write_text('instance\toa_library\toa_cell\tterminal_names\tclassification\tmodel_name\nR0\tPDK\tR\tPLUS,MINUS\ttarget\trmod\n')
        (work/'before/core_before.scs').write_text('subckt core A B\nR0 (A B) PDK__R segments=2 r=20k\nends core\n')
        (work/'before/device_catalog.tsv').write_text('master\toa_library\toa_cell\tkind\tterminal_names\nPDK__R\tPDK\tR\tresistor\tPLUS,MINUS\n')
        return candidate,raw

    def run_cli(self,candidate):
        before={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
        run=subprocess.run([sys.executable,str(SCRIPT),'--engine',str(ROOT),'--batch',str(candidate.parent)],capture_output=True,text=True)
        self.assertEqual(run.returncode,0,run.stdout+run.stderr)
        self.assertEqual(before,{p:p.read_bytes() for p in before})
        output=list(candidate.glob('resistor_review_*/resistor_groups.json'))
        self.assertEqual(len(output),1)
        self.assertEqual(set(p for p in candidate.rglob('*') if p.is_file())-set(before),set(output))
        return json.loads(output[0].read_text())

    def test_cli_reads_full_continuations_and_matches_oa_identity_and_count(self):
        self.module()
        with tempfile.TemporaryDirectory() as tmp:
            candidate,_=self.fixture(Path(tmp))
            report=self.run_cli(candidate);group=report['groups'][0]
            self.assertEqual(group['issues'],[])
            self.assertTrue(group['series_graph_verified'])
            self.assertEqual(group['cdf_segments'],2)
            self.assertEqual(group['segments'][0]['params']['w'],'1u')
            self.assertFalse(report['production_bindings_changed'])

    def test_missing_declared_segments_or_wrong_count_is_reported(self):
        self.module()
        for params in ('r=20k','segments=3 r=20k'):
            with self.subTest(params=params),tempfile.TemporaryDirectory() as tmp:
                candidate,_=self.fixture(Path(tmp));p=candidate/'work/before/core_before.scs'
                p.write_text('subckt core A B\nR0 (A B) PDK__R '+params+'\nends core\n')
                report=self.run_cli(candidate)
                self.assertTrue(report['groups'][0]['issues'])


if __name__=='__main__':unittest.main()
