"""Native-check preparation and dispatch, not native SKILL execution locally."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class CdfTerminalNamesTest(unittest.TestCase):
    def test_native_launcher_requires_complete_cases_and_actual_master(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            cds = base / 'cds.lib'; cds.write_text('; fixture\n')
            log = base / 'scan.log'
            log.write_text('*Error* CDF Spectre termOrder/symbol terminal conflict for L/C\n')
            fake = base / 'fake_virtuoso'
            fake.write_text('#!/usr/bin/env bash\nprintf "OK cases=11 actual=true\\n" > "$ST_CDF_TERMINAL_STATUS"\nprintf "incomplete run\\n"\n')
            fake.chmod(0o755)
            env = os.environ.copy(); env['ST_VIRTUOSO_BIN'] = str(fake)
            work = base / 'native'
            result = subprocess.run([sys.executable, str(ROOT / 'tests/CdfTerminalNamesNative.py'),
                '--cds-lib', str(cds), '--scan-log', str(log), '--work-dir', str(work)],
                capture_output=True, text=True, env=env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertNotIn('CDF_TERMINAL_NATIVE_OK', result.stdout)
            self.assertIn('incomplete run', result.stdout)
            self.assertTrue((work / 'launcher.log').is_file())

    def test_native_check_prepares_current_source_and_symbol_fixtures(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            cds = base / 'cds.lib'
            cds.write_text('; fixture\n')
            log = base / 'actual scan.log'
            log.write_text('*Error* CDF Spectre termOrder/symbol terminal conflict for Actual_PDK/actual_cell\n')
            work = base / 'native check'
            result = subprocess.run([sys.executable, str(ROOT / 'tests/CdfTerminalNamesNative.py'),
                '--cds-lib', str(cds), '--scan-log', str(log), '--work-dir', str(work),
                '--prepare-only'], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('native execution not performed', result.stdout)
            action = (work / 'cdf_terminal_check.il').read_text()
            self.assertIn(str(ROOT / 'server/skill/site_metadata_adapter.il'), action)
            self.assertIn("list('PLUS 'MINUS)", action)
            self.assertIn('stSiteValidatedTerminalNames(', action)
            self.assertIn('stSiteSpectreTerminalNames("Actual_PDK" "actual_cell" "symbol")', action)
            for case in ('symbol_names', 'string_names', 'mixed_names', 'cdf_order',
                'normalized_duplicate', 'case_conflict', 'unknown_name', 'missing_name',
                'numeric_name', 'empty_name', 'nil_name', 'non_list'):
                self.assertIn('"' + case + '"', action)
            self.assertNotRegex(action, r'dbSave|cdfSaveCDF|dbReplaceProp')

    def test_native_preparation_preserves_existing_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            cds = base / 'cds.lib'; cds.write_text('; fixture\n')
            log = base / 'scan.log'
            log.write_text('*Error* CDF Spectre termOrder/symbol terminal conflict for L/C\n')
            work = base / 'native'; work.mkdir()
            keep = work / 'keep'; keep.write_text('keep evidence')
            result = subprocess.run([sys.executable, str(ROOT / 'tests/CdfTerminalNamesNative.py'),
                '--cds-lib', str(cds), '--scan-log', str(log), '--work-dir', str(work),
                '--prepare-only'], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(keep.read_text(), 'keep evidence')


if __name__ == '__main__':
    unittest.main()
