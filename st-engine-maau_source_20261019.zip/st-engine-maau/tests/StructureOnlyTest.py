#!/usr/bin/env python3
"""No-Bench structural metadata and entry-point behavior."""
import csv
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))


class StructureOnlyTest(unittest.TestCase):
    def fixture(self, base):
        pdk = base / 'pdk'
        pdk.mkdir()
        probe = base / 'probe.tsv'
        with probe.open('w', newline='') as stream:
            out = csv.writer(stream, delimiter='\t', lineterminator='\n')
            out.writerow(['oa_library', 'oa_cell', 'oa_view', 'model_name', 'terminal_names',
                'parameter', 'units', 'min', 'max', 'cdf_type', 'default_value', 'choices', 'has_schematic'])
            out.writerow(['PDK', 'arbitrary_device', 'symbol', 'opaque', 'G,S,B,D', 'w', 'lengthMetric', '', '', 'string', '2u', '', 'false'])
            out.writerow(['PDK', 'arbitrary_device', 'symbol', 'opaque', 'G,S,B,D', 'l', 'lengthMetric', '', '', 'string', '240n', '', 'false'])
            out.writerow(['PDK', 'arbitrary_device', 'symbol', 'opaque', 'G,S,B,D', 'mode', '', '', '', 'string', 'normal', '', 'false'])
            out.writerow(['PDK', 'arbitrary_res', 'symbol', '', 'PLUS,MINUS', 'r', 'Ohm', '', '', 'string', '1k', '', 'false'])
            out.writerow(['PDK', 'not_a_mos', 'symbol', '', 'IN,OUT', 'w', 'm', '1u', '10u', 'float', '2u', '', 'false'])
            out.writerow(['PDK', 'child', 'symbol', '', 'D,G,S,B', 'w', 'm', '1u', '10u', 'float', '2u', '', 'true'])
        return pdk, probe

    def builder(self):
        try:
            module = importlib.import_module('structural_pdk')
        except ImportError:
            module = None
        self.assertIsNotNone(module, 'structural metadata entry is not implemented')
        return module.build_structure_metadata

    def test_cdf_only_preserves_identity_without_inventing_polarity_or_limits(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            pdk, probe = self.fixture(base)
            data = self.builder()(pdk, probe, {}, 'actual-tech')
            devices = {d['cell']: d for d in data['devices']}
            self.assertEqual(devices['arbitrary_device']['kind'], 'mos')
            self.assertEqual(devices['arbitrary_device']['constraints'], {})
            self.assertNotIn('maxAbsVgs', devices['arbitrary_device'])
            self.assertEqual(devices['arbitrary_res']['default_resistance'], 1000)
            self.assertEqual(devices['arbitrary_res']['constraints'], {})
            self.assertEqual(data['corners'], [])
            self.assertEqual(data['model_file_sha256'], {})
            self.assertNotIn('not_a_mos', devices)
            self.assertNotIn('child', devices)

    def test_real_cdf_limits_are_retained(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            pdk, probe = self.fixture(base)
            text = probe.read_text().replace('r\tOhm\t\t\t', 'r\tOhm\t100\t10000\t')
            probe.write_text(text)
            data = self.builder()(pdk, probe, {}, 'actual-tech')
            resistor = next(d for d in data['devices'] if d['kind'] == 'resistor')
            self.assertEqual(resistor['constraints']['resistance']['min'], 100)
            self.assertEqual(resistor['constraints']['resistance']['max'], 10000)
            probe.write_text(text.replace('r\tOhm\t100\t10000\t', 'r\tOhm\t0\t10000\t'))
            data = self.builder()(pdk, probe, {}, 'actual-tech')
            resistor = next(d for d in data['devices'] if d['kind'] == 'resistor')
            self.assertEqual(resistor['constraints']['resistance']['min'], 0)
            self.assertEqual(resistor['constraints']['resistance']['max'], 10000)

    def test_fin_count_mos_without_w_keeps_actual_cdf_names(self):
        # Catches exclusion of the real l/nfin geometry solely because w is absent.
        # Values are a small literal fixture, not an electrical PDK specification.
        from site_data import skill_metadata
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            pdk, probe = self.fixture(base)
            with probe.open(newline='') as stream:
                reader = csv.DictReader(stream, delimiter='\t')
                columns, rows = reader.fieldnames, list(reader)
            rows = [r for r in rows if not (r['oa_cell'] == 'arbitrary_device' and r['parameter'] == 'w')]
            for name, param_type, value in [('nfin', 'int', '4'), ('fw', 'string', '800n'), ('fingers', 'int', '2')]:
                row = dict(rows[0], parameter=name, cdf_type=param_type, default_value=value, units='')
                rows.append(row)
            with probe.open('w', newline='') as stream:
                writer = csv.DictWriter(stream, columns, delimiter='\t', lineterminator='\n')
                writer.writeheader()
                writer.writerows(rows)
            data = self.builder()(pdk, probe, {}, 'actual-tech')
            devices = {d['cell']: d for d in data['devices']}
            self.assertIn('arbitrary_device', devices, 'valid l/nfin MOS must remain selectable without w')
            device = devices['arbitrary_device']
            self.assertEqual(device['kind'], 'mos')
            self.assertNotIn('width', device['normalized_to_cdf'])
            self.assertNotIn('width', device['constraints'])
            descriptions = skill_metadata(data)['devices']
            mappings = descriptions['PDK/arbitrary_device']['normalizedToCdf']
            for mapping in ['length:l', 'cdf_nfin:nfin', 'cdf_fw:fw', 'cdf_fingers:fingers', 'cdf_mode:mode']:
                self.assertIn(mapping, mappings)
            self.assertFalse(any(m.startswith('width:') for m in mappings))

    def test_fin_count_does_not_bypass_geometry_terminals_or_hierarchy(self):
        for case in ('missing_length', 'only_fw', 'missing_gate', 'duplicate_terminal', 'hierarchical'):
            with self.subTest(case=case), tempfile.TemporaryDirectory() as directory:
                base = Path(directory)
                pdk, probe = self.fixture(base)
                with probe.open(newline='') as stream:
                    reader = csv.DictReader(stream, delimiter='\t')
                    columns, rows = reader.fieldnames, list(reader)
                rows = [r for r in rows if not (r['oa_cell'] == 'arbitrary_device' and r['parameter'] == 'w')]
                row = dict(rows[0], parameter='fw' if case == 'only_fw' else 'nfin',
                           cdf_type='int', default_value='4', units='')
                rows.append(row)
                if case == 'missing_length':
                    rows = [r for r in rows if not (r['oa_cell'] == 'arbitrary_device' and r['parameter'] == 'l')]
                for row in rows:
                    if row['oa_cell'] != 'arbitrary_device':
                        continue
                    if case == 'missing_gate':
                        row['terminal_names'] = 'IN,S,B,D'
                    elif case == 'duplicate_terminal':
                        row['terminal_names'] = 'G,S,D,D'
                    elif case == 'hierarchical':
                        row['has_schematic'] = 'true'
                with probe.open('w', newline='') as stream:
                    writer = csv.DictWriter(stream, columns, delimiter='\t', lineterminator='\n')
                    writer.writeheader()
                    writer.writerows(rows)
                data = self.builder()(pdk, probe, {}, 'actual-tech')
                self.assertNotIn('arbitrary_device', {d['cell'] for d in data['devices']})
                self.assertIn('arbitrary_device', {d['cell'] for d in data['rejected_devices']})

    def test_conflicting_terminal_order_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            pdk, probe = self.fixture(base)
            probe.write_text(probe.read_text().replace('G,S,B,D\tl\t', 'D,G,S,B\tl\t'))
            with self.assertRaisesRegex(ValueError, 'terminal'):
                self.builder()(pdk, probe, {}, 'actual-tech')

    def test_no_profile_or_bench_is_needed_by_structural_inspect(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            pdk, probe = self.fixture(base)
            cds = base / 'cds.lib'
            cds.write_text('DEFINE PDK ' + str(pdk) + '\n')
            backend = base / 'backend.py'
            backend.write_text('#!/usr/bin/env python3\nimport pathlib,shutil,sys\n'
                'args=dict(zip(sys.argv[2::2],sys.argv[3::2]))\nshutil.copyfile(' + repr(str(probe)) + ',args["--output"])\n')
            backend.chmod(0o755)
            capture = base / 'capture.json'
            engine = base / 'engine.py'
            engine.write_text('#!/usr/bin/env python3\nimport json,os,sys\njson.dump({"args":sys.argv,'
                '"scope":os.environ.get("ST_VALIDATION_SCOPE"),"context":os.environ["ST_CIRCUIT_CONTEXT"]},open('
                + repr(str(capture)) + ',"w"))\n')
            engine.chmod(0o755)
            args = [sys.executable, str(ROOT / 'server/site/standalone.py'), 'inspect',
                '--validation-scope', 'structure_only', '--engine', str(engine),
                '--pdk-root', str(pdk), '--backend', str(backend), '--cds-lib', str(cds),
                '--lib', 'L', '--cell', 'core', '--view', 'schematic', '--work-dir', str(base / 'session')]
            result = subprocess.run(args, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            recorded = json.loads(capture.read_text())
            self.assertEqual(recorded['scope'], 'structure_only')
            self.assertEqual(json.loads(Path(recorded['context']).read_text())['source_benches'], [])
            self.assertIn('--validation-scope', recorded['args'])

    def test_default_inspect_still_requires_simulation_profile(self):
        result = subprocess.run([sys.executable, str(ROOT / 'server/site/standalone.py'),
            'inspect', '--backend', '/unused', '--work-dir', '/unused'], text=True, capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('requires --simulation-profile', result.stderr)

    def test_fixed_workflow_chooses_two_scalar_targets_and_real_resistor_default(self):
        try:
            helper = importlib.import_module('prepare_structure_test')
        except ImportError:
            helper = None
        self.assertIsNotNone(helper, 'fixed structural test preparation is not implemented')
        inventory = [{'instance': 'I0<31:0>'}, {'instance': 'I11'}, {'instance': 'I10'}]
        metadata = {'devices': [{'kind': 'resistor', 'oa_library': 'REAL', 'cell': 'R',
            'terminalRoles': {'P': 'positive', 'N': 'negative'}, 'default_resistance': 1000,
            'normalized_to_cdf': {'resistance': 'res'}, 'constraints': {}}]}
        selection, operations = helper.choose_operations(inventory, metadata)
        self.assertEqual(selection['resistor_target'], 'I10')
        self.assertEqual(selection['stack_target'], 'I11')
        self.assertIn('resistor.master=oa_REAL__R', operations['resistor_initial.conf'])
        self.assertIn('resistor.parameter=res', operations['resistor_initial.conf'])
        self.assertIn('resistor.value=1000', operations['resistor_initial.conf'])
        self.assertIn('resistor.value=2000', operations['resistor_changed.conf'])
        self.assertIn('stage_count=3', operations['stack_three.conf'])
        self.assertNotIn('voltage_domain', operations['stack_three.conf'])
        self.assertNotIn('resistor.min', operations['resistor_initial.conf'])

    def test_fixed_workflow_rejects_missing_targets(self):
        try:
            helper = importlib.import_module('prepare_structure_test')
        except ImportError:
            helper = None
        self.assertIsNotNone(helper, 'fixed structural test preparation is not implemented')
        with self.assertRaisesRegex(ValueError, 'two scalar'):
            helper.choose_operations([{'instance': 'I0'}], {'devices': []})


if __name__ == '__main__':
    unittest.main()
