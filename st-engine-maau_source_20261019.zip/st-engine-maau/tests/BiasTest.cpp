#include "st/Bias.h"

#include <iostream>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

} // namespace

int main()
{
    const st::VoltageWindow window{0.78, 0.84};
    CHECK(window.Valid() && window.Contains(0.80) && !window.Contains(0.85) &&
              window.Midpoint() == 0.81,
          "保留供自动求解器复用的中性电压窗");

    st::BiasResolution resolved;
    resolved.ok = true;
    resolved.output_net = "VBIAS_M0";
    resolved.nominal_voltage = 0.81;
    resolved.iq_delta = 4e-6;
    resolved.cost = {4e-6, "AVDD", "VSS", 4.8e-6};
    resolved.elements.push_back({"VBIAS_M0_DEVICE", "p18", {"AVDD", "VBIAS_M0"},
                                 {{"w", "2u"}}});
    CHECK(resolved.ok && resolved.cost.current == resolved.iq_delta &&
              resolved.elements.front().params.at("w") == "2u",
          "保留自动模板可消费的Bias元素计划和成本结果");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Bias tests passed\n";
    } else {
        std::cout << failures << " Bias tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
