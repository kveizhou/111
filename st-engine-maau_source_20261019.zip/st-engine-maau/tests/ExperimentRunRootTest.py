"""Run the actual shell backend with a provider spy; never invokes Cadence."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class RunRootTest(unittest.TestCase):
    def run_backend(self, scope, blocked=False, existing_global=False):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name).resolve(); work=root/'candidate with spaces'; work.mkdir()
            cds=root/'cds.lib';cds.write_text('')
            provider=root/'spy.sh';capture=root/'capture'
            provider.write_text('#!/bin/sh\nprintf "%s\\n" "$@" > "$CAPTURE"\nexit 69\n')
            provider.chmod(0o755)
            stale=root/'old_run/raw_op'
            if existing_global:stale.mkdir(parents=True)
            if blocked:(work/'raw_op').write_text('not a directory')
            env={k:v for k,v in os.environ.items() if not k.startswith('ST_')}
            env.update(ST_OP_RUN_ROOT=str(stale), ST_OP_PROVIDER_BIN=str(provider),CAPTURE=str(capture))
            options=dict(cds_lib=str(cds),dut_lib='SRC',dut_cell='core',dut_view='schematic',
                bench_lib='TB',bench_cell='bench',bench_view='config',corner='C',dut_hash='d',
                bench_hash='b',pdk_version='p',topology_hash='t',parameter_hash='g',solver_version='s',
                identity_output=str(work/'identity.tsv'),mos_output=str(work/'mos.tsv'),validation_scope=scope)
            args=[item for k,v in options.items() for item in ('--'+k.replace('_','-'),v)]
            result=subprocess.run(['bash',str(ROOT/'server/bin/run_op_runner.sh'),*args],env=env,text=True,capture_output=True)
            called=capture.read_text().splitlines() if capture.exists() else []
            simulation=called[called.index('--simulation-dir')+1] if called else ''
            return result,simulation,str(work/'raw_op'),str(stale)

    def test_experiment_ignores_missing_global_root_and_reaches_provider(self):
        result,simulation,local,_=self.run_backend('experimental_dc')
        self.assertEqual(result.returncode,69,result.stderr) # The deliberate provider exit.
        self.assertEqual(str(Path(simulation).parent),local)
        self.assertIn('OP_RUN_ROOT='+local,result.stdout)

    def test_existing_global_root_cannot_mix_experiment_outputs(self):
        result,simulation,local,_=self.run_backend('experimental_dc',existing_global=True)
        self.assertEqual(result.returncode,69,result.stderr)
        self.assertEqual(str(Path(simulation).parent),local)

    def test_formal_mode_retains_invalid_root_error(self):
        result,simulation,_,_=self.run_backend('dc_operating_point')
        self.assertEqual(result.returncode,73,result.stderr)
        self.assertFalse(simulation)

    def test_uncreatable_local_directory_fails_before_provider(self):
        result,simulation,_,_=self.run_backend('experimental_dc',blocked=True)
        self.assertEqual(result.returncode,73,result.stderr)
        self.assertFalse(simulation)


if __name__=='__main__':unittest.main()
