"""Actual bus-port incident fixtures; no native Cadence execution."""
import importlib
from pathlib import Path
import sys
import unittest

SITE=Path(__file__).resolve().parents[1]/'server/site'
sys.path.insert(0,str(SITE))


class BusPortsTest(unittest.TestCase):
    def wrap(self,*args,**kwargs):
        runtime=importlib.import_module('cascode_runtime')
        self.assertTrue(hasattr(runtime,'wrap_oa_dut'),'OA bus adapter missing')
        return runtime.wrap_oa_dut(*args,**kwargs)

    def fixture(self):
        oa=['OCP','AGND','AVDD','ENP_DELAY','EN','IBP4P0','PVDD','VFB','VBN3A',
            'VREF_SS','VGA','VGP','VREF','VOUT','VBN3B','ENP_OCP2','OCP_SET<1:0>',
            'OCP_OUT_BP','ENP_OCP','CAP_SET','IBN1P0','IBIAS_SET<1:0>']
        ports=[r'IBIAS_SET\<1\>',r'IBIAS_SET\<0\>','VBN3A','VBN3B',r'OCP_SET\<1\>',
               r'OCP_SET\<0\>','VFB','VOUT','AVDD','AGND','OCP','ENP_DELAY','ENP_OCP2',
               'PVDD','EN','VREF','VREF_SS','VGP','OCP_OUT_BP','IBN1P0','ENP_OCP','VGA','CAP_SET','IBP4P0']
        # Literal pin order makes swapping bits observable in the flattened result.
        body='X0 (OCP_SET\\<0\\> OCP_SET\\<1\\> AVDD AGND) nmod\n'
        text='simulator lang=spectre\n'+body
        baseline='simulator lang=spectre\nsubckt core '+' '.join(ports)+'\n'+body+'ends core\n'
        return oa,ports,text,baseline

    def test_observed_22_to_24_wrap_keeps_body_and_positional_bit_binding(self):
        oa,ports,text,baseline=self.fixture()
        wrapped,evidence=self.wrap(text,'core',oa,ports,baseline_text=baseline,source_subckt='core')
        self.assertIn('subckt core '+' '.join(ports)+'\n',wrapped)
        self.assertIn('X0 (OCP_SET\\<0\\> OCP_SET\\<1\\> AVDD AGND) nmod',wrapped)
        self.assertEqual(evidence['expanded_port_count'],24)
        self.assertIn(r'IBIAS_SET\<1\>',evidence['unused_in_both'])
        from op_provider import flatten_dut
        instance='ROOT (b1 b0 n3a n3b c1 c0 fb out vdd gnd ocp delay ocp2 pvdd en ref ss gp bp ib enocp ga cap ibp) core\n'
        flat=flatten_dut(wrapped+instance,'ROOT','core')
        self.assertEqual(flat[0]['nodes'],['c0','c1','vdd','gnd'])

    def test_ascending_range_and_scalar_bit_accept_equivalent_names(self):
        for oa in (['DATA<0:1>','G'],['DATA<1>','DATA<0>','G']):
            with self.subTest(oa=oa):
                text='M (DATA\\<0\\> DATA\\<1\\> G G) n\n'
                wrapped,_=self.wrap(text,'core',oa,[r'DATA\<1\>',r'DATA\<0\>','G'])
                self.assertIn('subckt core DATA\\<1\\> DATA\\<0\\> G',wrapped)

    def test_missing_extra_overlapping_ambiguous_and_wrong_bus_names_fail(self):
        for oa,ports in [(['DATA<1:0>'],[r'DATA\<0\>']),
                         (['DATA<1:0>','DATA<0>'],[r'DATA\<1\>',r'DATA\<0\>']),
                         (['DATA<1:0>'],[r'DATA\<1\>',r'DATA\<0\>','DATA<0>']),
                         (['OTHER<1:0>'],[r'DATA\<1\>',r'DATA\<0\>']),
                         (['DATA<1:0:2>'],[r'DATA\<1\>',r'DATA\<0\>'])]:
            with self.subTest(oa=oa,ports=ports),self.assertRaises(ValueError):
                self.wrap('M (G G G G) n\n','core',oa,ports)

    def test_connected_baseline_port_lost_is_not_treated_as_unused(self):
        oa,ports,text,baseline=self.fixture()
        baseline=baseline.replace('ends core','R (IBIAS_SET\\<1\\> AGND) resistor r=1\nends core')
        with self.assertRaisesRegex(ValueError,'connected baseline port missing'):
            self.wrap(text,'core',oa,ports,baseline_text=baseline,source_subckt='core')

    def test_exported_header_order_and_actual_node_spelling_are_not_silently_rewritten(self):
        ports=[r'A\<1\>',r'A\<0\>']
        for text in ('subckt core A\\<0\\> A\\<1\\>\nM (A\\<0\\> A\\<1\\>) r\nends core\n',
                     'M (A<0> A<1>) r\n'):
            with self.subTest(text=text),self.assertRaises(ValueError):
                self.wrap(text,'core',['A<1:0>'],ports)


if __name__=='__main__':unittest.main()
