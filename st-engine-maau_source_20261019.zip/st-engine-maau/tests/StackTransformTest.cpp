#include "st/Transform.h"

#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::DeviceCatalog catalog()
{
    st::DeviceCatalog result;
    st::Diagnostic diagnostic;
    st::DeviceDescriptor nmos;
    nmos.master = "nmos_core";
    nmos.kind = st::DeviceKind::MosN;
    nmos.terminal_count = 4;
    // B/S/G/D，确保 Stack 全程依赖端子语义。
    nmos.terminal_index = {
        { st::TerminalRole::Bulk, 0 },
        { st::TerminalRole::Source, 1 },
        { st::TerminalRole::Gate, 2 },
        { st::TerminalRole::Drain, 3 },
    };
    nmos.limits.max_stack_level = 100;
    nmos.limits.min_width = 100e-9;
    nmos.limits.max_width = 100e-6;
    nmos.limits.min_length = 100e-9;
    nmos.limits.max_length = 10e-6;
    nmos.voltage_domain = "core_2v0";
    nmos.allowed_voltage_domains.insert("core_2v0");
    result.Add(nmos, diagnostic);
    return result;
}

st::Netlist circuit(bool collisions = false)
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "core";
    core.instances.push_back({ "M0", { "VSS", "SOURCE", "CTRL", "OUT" },
        "nmos_core", { { "w", "2u" }, { "l", "240n" }, { "nf", "4" } } });
    if (collisions) {
        core.instances.push_back({ "M0_S1", { "VSS", "SOURCE", "CTRL", "M0_MID1" },
            "nmos_core", {} });
        core.instances.push_back({ "KEEP", { "VSS", "SOURCE", "CTRL", "M0_MID1" },
            "nmos_core", {} });
    }
    netlist.subckts.push_back(core);
    return netlist;
}

st::StackTransformRequest sharedRequest(int count)
{
    st::StackTransformRequest request;
    request.subckt = "core";
    request.target = "M0";
    request.stage_count = count;
    request.intent = st::StackIntent::EffectiveLength;
    request.gate_policy = st::GatePolicy::SharedGate;
    request.voltage_domain = "core_2v0";
    request.nmos_bulk_net = "VSS";
    return request;
}

} // namespace

int main()
{
    const auto devices = catalog();

    auto sharedCircuit = circuit();
    const auto sharedBefore = st::emitSpectre(sharedCircuit);
    auto sharedPlan = st::planStack(sharedCircuit, sharedRequest(2), devices);
    CHECK(sharedPlan.ok() && sharedPlan.stack.stage_count == 2,
        "N=2 Shared-gate Stack可生成逻辑计划");
    CHECK(st::emitSpectre(sharedCircuit) == sharedBefore,
        "生成逻辑Stack计划不会修改工作电路");
    CHECK(sharedPlan.stack.stage_instance_names.size() == 2 &&
            sharedPlan.stack.stage_instance_names ==
                std::vector<std::string>({ "M0", "M0_S1" }) &&
            sharedPlan.stack.middle_nets.size() == 1,
        "逻辑对象按Drain到Source记录原实例名和N-1个特征化名称");
    CHECK(sharedPlan.stack.gate_nets == std::vector<std::string>({ "CTRL", "CTRL" }),
        "Shared-gate所有级都接原Gate");
    CHECK(sharedPlan.stack.stage_params[0] == sharedPlan.stack.original_params &&
            sharedPlan.stack.stage_params[1] == sharedPlan.stack.original_params,
        "每一级以原MOS完整尺寸参数作为初值，不做W/N");

    auto sharedResult = st::materializeStack(sharedCircuit, sharedPlan.stack, devices);
    auto* sharedCore = sharedCircuit.find("core");
    auto* drainSide = sharedCore->find("M0");
    auto* sourceSide = sharedCore->find("M0_S1");
    CHECK(sharedResult.ok() && drainSide && sourceSide &&
          sharedResult.removedInstances.empty(),
        "物化时保留Drain侧原MOS身份，只新增N-1只真实MOS");
    CHECK(drainSide && drainSide->nets ==
            std::vector<std::string>({ "VSS", "M0_MID1", "CTRL", "OUT" }),
        "原M0位于Drain侧，按B/S/G/D物理顺序正确连接");
    CHECK(sourceSide && sourceSide->nets ==
            std::vector<std::string>({ "VSS", "SOURCE", "CTRL", "M0_MID1" }),
        "M0_S1位于原M0的Source方向且保持外部Source边界");
    CHECK(sharedResult.parameter_groups.at("M0_STACK_COMMON_SIZE").size() == 2,
        "Stack默认使用公共尺寸组进入Sizing");

    auto hundredCircuit = circuit();
    const auto hundredBefore = st::emitSpectre(hundredCircuit);
    auto hundredPlan = st::planStack(hundredCircuit, sharedRequest(100), devices);
    CHECK(hundredPlan.ok() && hundredPlan.stack.stage_count == 100 &&
            hundredPlan.stack.stage_instance_names.size() == 100 &&
            hundredPlan.stack.middle_nets.size() == 99,
        "逻辑Stack支持上限100级");
    CHECK(st::emitSpectre(hundredCircuit) == hundredBefore &&
            hundredPlan.stack.sizing_groups.size() == 1,
        "100级默认仍是一个逻辑对象和一个公共尺寸组，不在数据库中展开");

    auto tooSmall = st::planStack(hundredCircuit, sharedRequest(1), devices);
    auto tooLarge = st::planStack(hundredCircuit, sharedRequest(101), devices);
    CHECK(!tooSmall.ok() && !tooLarge.ok() &&
            tooSmall.diags[0].code == st::DiagCode::BadParam &&
            tooLarge.diags[0].code == st::DiagCode::BadParam,
        "Stack级数只允许2到100且受PDK上限约束");

    auto collisionCircuit = circuit(true);
    auto collisionPlan = st::planStack(collisionCircuit, sharedRequest(2), devices);
    CHECK(collisionPlan.ok() && collisionPlan.stack.stage_instance_names[0] == "M0" &&
            collisionPlan.stack.stage_instance_names[1] == "M0_S1_2" &&
            collisionPlan.stack.middle_nets[0] == "M0_MID1_2",
        "Stack实例和内部网络冲突时确定性避让");

    st::DeviceCatalog structuralDevices;
    st::DeviceDescriptor threePin;
    threePin.master = "actual_three_pin";
    threePin.kind = st::DeviceKind::Mos;
    threePin.terminal_count = 3;
    threePin.terminal_index = {{st::TerminalRole::Gate, 0},
        {st::TerminalRole::Source, 1}, {st::TerminalRole::Drain, 2}};
    st::Diagnostic structuralDiagnostic;
    structuralDevices.Add(threePin, structuralDiagnostic);
    st::Netlist threePinCircuit;
    st::Subckt structuralCore;
    structuralCore.name = "core";
    structuralCore.instances.push_back({"M0", {"CTRL", "SOURCE", "OUT"},
        threePin.master, {{"w", "2u"}, {"l", "240n"}, {"mode", "normal"}}});
    threePinCircuit.subckts.push_back(structuralCore);
    auto structuralRequest = sharedRequest(3);
    structuralRequest.voltage_domain.clear();
    structuralRequest.nmos_bulk_net.clear();
    structuralRequest.structure_only = true;
    const auto structuralPlan = st::planStack(threePinCircuit, structuralRequest, structuralDevices);
    CHECK(structuralPlan.ok() && structuralPlan.stack.original_bulk_net.empty(),
        "结构模式三端MOS无需N/P、电压域或外部Bulk输入");
    const auto structuralResult = st::materializeStack(threePinCircuit, structuralPlan.stack, structuralDevices);
    const auto* threePinCore = threePinCircuit.find("core");
    CHECK(structuralResult.ok() && threePinCore->instances.size() == 3 &&
        threePinCore->find("M0")->nets == std::vector<std::string>({"CTRL", "M0_MID1", "OUT"}) &&
        threePinCore->find("M0_S2")->nets == std::vector<std::string>({"CTRL", "SOURCE", "M0_MID2"}) &&
        threePinCore->find("M0_S2")->params.at("mode") == "normal",
        "三端Stack按实际G/S/D顺序串联、共栅并保留原参数，不造第四端");

    auto experimentalDescriptor = *devices.Find("nmos_core");
    experimentalDescriptor.voltage_domain.clear();
    experimentalDescriptor.allowed_voltage_domains.clear();
    experimentalDescriptor.bulk_rule_complete = true;
    experimentalDescriptor.native_parameter_trials = true;
    st::DeviceCatalog experimentalCatalog;
    st::Diagnostic experimentalDiagnostic;
    experimentalCatalog.Add(experimentalDescriptor, experimentalDiagnostic);
    auto experimentalRequest = sharedRequest(2);
    CHECK(!st::planStack(circuit(), experimentalRequest, experimentalCatalog).ok(),
          "正式Stack拒绝原生试点目录");
    experimentalRequest.experimental_dc = true;
    CHECK(st::planStack(circuit(), experimentalRequest, experimentalCatalog).ok(),
          "实验Stack可在域未知时保留已证明极性和Bulk继续");
    experimentalRequest.structure_only = true;
    CHECK(!st::planStack(circuit(), experimentalRequest, experimentalCatalog).ok(),
          "实验Stack不能混用structure_only绕过门禁");
    experimentalRequest.structure_only = false;
    experimentalRequest.nmos_bulk_net.clear();
    CHECK(!st::planStack(circuit(), experimentalRequest, experimentalCatalog).ok(),
          "实验Stack仍拒绝缺失NMOS Bulk网络");
    experimentalRequest.nmos_bulk_net = "VSS";
    experimentalDescriptor.voltage_domain = "io";
    experimentalDescriptor.allowed_voltage_domains.insert("io");
    st::DeviceCatalog mismatchedExperimentalCatalog;
    mismatchedExperimentalCatalog.Add(experimentalDescriptor, experimentalDiagnostic);
    CHECK(!st::planStack(circuit(), experimentalRequest, mismatchedExperimentalCatalog).ok(),
          "实验Stack仍拒绝已知电压域不匹配");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Stack transform tests passed\n";
    } else {
        std::cout << failures << " Stack transform tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
