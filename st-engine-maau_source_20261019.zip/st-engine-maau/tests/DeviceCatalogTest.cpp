#include "st/Netlist.h"
#include "st/Types.h"

#include <iostream>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::DeviceDescriptor makeReverseOrderedNmos()
{
    st::DeviceDescriptor descriptor;
    descriptor.master = "nmos_bs_gd";
    descriptor.kind = st::DeviceKind::MosN;
    descriptor.terminal_count = 4;
    descriptor.terminal_index = {
        { st::TerminalRole::Bulk, 0 },
        { st::TerminalRole::Source, 1 },
        { st::TerminalRole::Gate, 2 },
        { st::TerminalRole::Drain, 3 },
    };
    return descriptor;
}

} // namespace

int main()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    CHECK(catalog.Add(makeReverseOrderedNmos(), diagnostic),
        "接受由 PDK 明确给出的非 D/G/S/B 端子顺序");

    st::Instance instance;
    instance.name = "M0";
    instance.model = "nmos_bs_gd";
    instance.nets = { "VSS", "SOURCE_NET", "CTRL", "OUT" };

    std::string net;
    CHECK(st::getTerminalNet(instance, catalog, st::TerminalRole::Drain, net, diagnostic) && net == "OUT",
        "按 Drain 语义取得 OUT，而不是把第一个端子误认为 Drain");
    CHECK(st::getTerminalNet(instance, catalog, st::TerminalRole::Gate, net, diagnostic) && net == "CTRL",
        "按 Gate 语义取得 CTRL");
    CHECK(st::getTerminalNet(instance, catalog, st::TerminalRole::Source, net, diagnostic) && net == "SOURCE_NET",
        "按 Source 语义取得 SOURCE_NET");
    CHECK(st::getTerminalNet(instance, catalog, st::TerminalRole::Bulk, net, diagnostic) && net == "VSS",
        "按 Bulk 语义取得 VSS");

    CHECK(st::setTerminalNet(instance, catalog, st::TerminalRole::Drain, "MID", diagnostic) &&
            instance.nets == std::vector<std::string>({ "VSS", "SOURCE_NET", "CTRL", "MID" }),
        "只改写 PDK 所声明的 Drain 端子");

    auto duplicateIndex = makeReverseOrderedNmos();
    duplicateIndex.master = "bad_duplicate";
    duplicateIndex.terminal_index[st::TerminalRole::Gate] = 3;
    CHECK(!catalog.Add(duplicateIndex, diagnostic) && diagnostic.code == st::DiagCode::InvalidTerminalMap,
        "拒绝两个端子语义映射到同一物理位置");

    auto missingBulk = makeReverseOrderedNmos();
    missingBulk.master = "bad_missing_bulk";
    missingBulk.terminal_index.erase(st::TerminalRole::Bulk);
    CHECK(catalog.Add(missingBulk, diagnostic),
        "保留扫描到但缺Bulk语义的MOS，以便目录报告给出明确拒绝原因");
    std::size_t missingBulkIndex = 0;
    CHECK(!catalog.ResolveTerminal("bad_missing_bulk", st::TerminalRole::Bulk, 4,
                                   missingBulkIndex, diagnostic) &&
          diagnostic.code == st::DiagCode::InvalidTerminalMap,
        "四端MOS缺Bulk语义时仍拒绝把未知端子当作三端器件");

    auto incompleteOaOrder = makeReverseOrderedNmos();
    incompleteOaOrder.master = "bad_oa_order";
    incompleteOaOrder.terminal_names_by_index = { "B", "S", "G" };
    CHECK(!catalog.Add(incompleteOaOrder, diagnostic) &&
            diagnostic.code == st::DiagCode::InvalidTerminalMap,
        "OA terminalOrder数量与器件端子数不一致时拒绝");

    auto conflictingRoles = makeReverseOrderedNmos();
    conflictingRoles.master = "bad_role_order";
    conflictingRoles.terminal_roles_by_index = {
        st::TerminalRole::Drain, st::TerminalRole::Source,
        st::TerminalRole::Gate, st::TerminalRole::Bulk
    };
    CHECK(!catalog.Add(conflictingRoles, diagnostic) &&
            diagnostic.code == st::DiagCode::InvalidTerminalMap,
        "OA物理端子语义与terminal_index矛盾时拒绝");

    st::Instance unknown = instance;
    unknown.model = "not_registered";
    CHECK(!st::getTerminalNet(unknown, catalog, st::TerminalRole::Drain, net, diagnostic) &&
            diagnostic.code == st::DiagCode::UnknownModel,
        "器件 master 未登记时明确拒绝，不猜端子顺序");

    st::Instance shortInstance = instance;
    shortInstance.nets.pop_back();
    CHECK(!st::getTerminalNet(shortInstance, catalog, st::TerminalRole::Drain, net, diagnostic) &&
            diagnostic.code == st::DiagCode::InvalidTerminalMap,
        "实例实际端子数与 PDK 描述不一致时拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "DeviceCatalog tests passed\n";
    } else {
        std::cout << failures << " DeviceCatalog tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
