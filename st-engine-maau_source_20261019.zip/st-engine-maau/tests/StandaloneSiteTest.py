import importlib
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import unittest
from unittest.mock import patch

SITE = Path(__file__).resolve().parents[1] / 'server/site'
sys.path.insert(0, str(SITE))


class StandaloneSiteTest(unittest.TestCase):
    def test_model_polarity_comes_from_declaration_not_name(self):
        pdk = importlib.import_module('standalone_pdk')
        facts = pdk.model_facts('''simulator lang=spectre
model misleading_p bsim4 type=n wmin=1u wmax=20u lmin=0.18u lmax=2u
model misleading_n bsim4 type=p
model rreal resistor
model unknown bsim4
''', 'actual.scs')
        self.assertEqual(facts['misleading_p']['kind'], 'mos_n')
        self.assertEqual(facts['misleading_n']['kind'], 'mos_p')
        self.assertEqual(facts['rreal']['kind'], 'resistor')
        self.assertNotIn('unknown', facts)
        self.assertAlmostEqual(facts['misleading_p']['limits']['min_width'], 1e-6)

    def test_raw_pdk_root_and_oa_probe_produce_metadata_without_maau(self):
        pdk = importlib.import_module('standalone_pdk')
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            models = root / 'models.scs'
            models.write_text('model physical bsim4 type=n wmin=1u wmax=10u lmin=0.2u lmax=2u\n')
            probe = root / 'probe.tsv'
            probe.write_text('oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
                'PDK\tunnamed\tsymbol\tphysical\tD,G,S,B\tw\tm\t1e-6\t1e-5\n'
                'PDK\tunnamed\tsymbol\tphysical\tD,G,S,B\tl\tm\t2e-7\t2e-6\n')
            profile = {'op_corners': {'tt': {'temperature': 27, 'models': [
                {'model_file': str(models), 'section_name': 'tt'}]}}}
            metadata = pdk.build_metadata(root, probe, profile, {})
            self.assertEqual(metadata['devices'][0]['kind'], 'mos_n')
            self.assertEqual(metadata['pdk_paths'], [str(root.resolve())])
            self.assertIn('reliability', metadata['devices'][0]['missing'])
            self.assertNotIn('maxAbsVgs', metadata['devices'][0])
            self.assertNotIn('KimiCode', json.dumps(metadata))
            with self.assertRaisesRegex(ValueError, 'root'):
                pdk.build_metadata(root / 'absent', probe, profile, {})

    def test_dut_top_level_wrap_requires_real_ports(self):
        runtime = importlib.import_module('cadence_runtime')
        text = 'simulator lang=spectre\nglobal 0\nM0 (OUT G VSS VSS) nmod w=1u l=1u\n'
        wrapped = runtime.wrap_dut(text, 'candidate', ['OUT', 'G', 'VSS'], ['G', 'OUT', 'VSS'])
        self.assertIn('subckt candidate G OUT VSS', wrapped)
        self.assertIn('M0 (OUT G VSS VSS)', wrapped)
        with self.assertRaisesRegex(ValueError, 'port'):
            runtime.wrap_dut(text, 'candidate', ['OUT', 'G', 'VSS'], ['OUT', 'OTHER', 'VSS'])

    def test_dut_wrap_keeps_corner_variables_in_bench_scope(self):
        runtime = importlib.import_module('cadence_runtime')
        op = importlib.import_module('op_provider')
        text = ('simulator lang=spectre\nparameters WBIAS=1u LOCAL_L=0.2u\n'
                'M0 (OUT G VSS VSS) nmod w=WBIAS l=LOCAL_L\n')
        wrapped = runtime.wrap_dut(text, 'candidate', ['OUT', 'G', 'VSS'],
                                   ['G', 'OUT', 'VSS'], {'WBIAS'})
        with tempfile.TemporaryDirectory() as temp:
            model = Path(temp) / 'models.scs'
            model.write_text('// fixture')
            bench = ('simulator lang=spectre\ninclude ' + json.dumps(str(model)) + ' section=tt\n'
                     'parameters WBIAS=1u\nsubckt core G OUT VSS\nends core\n'
                     'X0 (G OUT 0) core\n')
            bound, root = op.bind_dut(bench, wrapped, 'core', 'candidate')
            hot = op.apply_corner(bound, {'sections': [{'model_file': str(model), 'section_name': 'ff'}]},
                                  125, [str(model)], {'WBIAS': '2u'})
            device = op.flatten_dut(hot, root, 'candidate')[0]
            self.assertAlmostEqual(op.parameter_value(device['params']['w'], device['parameters']), 2e-6)
            self.assertAlmostEqual(op.parameter_value(device['params']['l'], device['parameters']), 0.2e-6)

    def test_cdf_suffix_native_units_and_model_intersection(self):
        pdk = importlib.import_module('standalone_pdk')
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            model = root / 'models.scs'
            model.write_text('model nreal bsim4 type=n wmin=2u wmax=10u\n')
            probe = root / 'probe.tsv'
            header = 'oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
            profile = {'op_corners': {'tt': {'models': [{'model_file': str(model), 'section_name': 'tt'}]}}}
            for unit in ('um', 'lengthMetric'):
                probe.write_text(header + 'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\t' + unit + '\t1u\t20u\n')
                domain = pdk.build_metadata(root, probe, profile, {})['devices'][0]['constraints']['width']
                self.assertAlmostEqual(domain['min'], 2e-6)
                self.assertAlmostEqual(domain['max'], 10e-6)
            probe.write_text(header + 'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\tum\t3\t8\n')
            domain = pdk.build_metadata(root, probe, profile, {})['devices'][0]['constraints']['width']
            self.assertAlmostEqual(domain['min'], 3e-6)
            probe.write_text(header + 'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\tlengthMetric\t11u\t20u\n')
            with self.assertRaisesRegex(ValueError, 'empty.*domain'):
                pdk.build_metadata(root, probe, profile, {})
            probe.write_text(header + 'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\tunknown\t1\t20\n')
            device = pdk.build_metadata(root, probe, profile, {})['devices'][0]
            self.assertNotIn('width', device['constraints'])
            self.assertIn('cdf_constraints', device['missing'])

    def test_unresolved_oa_master_kept_for_documented_rules_and_diagnostics(self):
        pdk = importlib.import_module('standalone_pdk')
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'model.scs').write_text('model known bsim4 type=n\n')
            probe = root / 'probe.tsv'
            probe.write_text('oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
                'PDK\tN\tsymbol\tknown\tD,G,S,B\tw\tlengthMetric\t1u\t10u\n'
                'PDK\tOpaque\tsymbol\t\tD,G,S,B\tw\tlengthMetric\t1u\t10u\n')
            raw = pdk.build_metadata(root, probe, {}, {})
            self.assertEqual(raw['rejected_devices'][0]['cell'], 'Opaque')
            rules = {'source': '/actual/documentation', 'devices': {
                'PDK/Opaque': {'model': 'opaque_real', 'kind': 'mos_p', 'maxStackLevel': 3}}}
            supplemented = pdk.build_metadata(root, probe, {}, rules)
            device = next(d for d in supplemented['devices'] if d['cell'] == 'Opaque')
            self.assertEqual(device['kind'], 'mos_p')
            self.assertEqual(device['maxStackLevel'], 3)
            data = importlib.import_module('site_data')
            self.assertEqual(data.skill_metadata(supplemented)['devices']['PDK/Opaque']['maxStackLevel'], 3)

    def test_external_selected_models_are_scanned_and_pinned(self):
        pdk = importlib.import_module('standalone_pdk')
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            root = base / 'oa'
            root.mkdir()
            model = base / 'models.scs'
            child = base / 'mos.scs'
            model.write_text('include "mos.scs" section=tt\n')
            child.write_text('model external bsim4 type=p\n')
            probe = base / 'probe.tsv'
            probe.write_text('oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
                'PDK\tP\tsymbol\texternal\tD,G,S,B\tw\tlengthMetric\t1u\t10u\n')
            profile = {'op_corners': {'tt': {'models': [{'model_file': str(model), 'section_name': 'tt'}]}}}
            metadata = pdk.build_metadata(root, probe, profile, {})
            self.assertEqual(metadata['devices'][0]['kind'], 'mos_p')
            self.assertIn(str(child.resolve()), metadata['model_file_sha256'])

    def test_default_setup_has_no_maau_runtime_or_install_path(self):
        text = (SITE.parent / 'setup_backend.csh').read_text()
        self.assertNotIn('st_maau_runtime', text)
        self.assertNotIn('/tmpdata/', text)
        self.assertIn('op_provider.py', text)

    def test_standalone_entry_archives_each_input_root_and_restores_commands(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            pdk = base / 'actual PDK'
            pdk.mkdir()
            pdk_alias = base / 'current PDK'
            pdk_alias.symlink_to(pdk, target_is_directory=True)
            model = pdk / 'model.scs'
            model.write_text('model nreal bsim4 type=n wmin=1u wmax=10u lmin=0.2u lmax=2u\n')
            cds = base / 'cds.lib'
            cds.write_text('DEFINE PDK ' + str(pdk) + '\n')
            init = base / 'actual_init.il'
            init.write_text('; actual test helper')
            profile = base / 'profile.json'
            profile.write_text(json.dumps({'nominal_corner': 'tt', 'op_corners': {'tt': {
                'temperature': 27, 'models': [{'model_file': str(model), 'section_name': 'tt'}]}}}))
            backend = base / 'probe.py'
            backend.write_text('#!/usr/bin/env python3\nimport pathlib,sys\n'
                'import os\nassert pathlib.Path(os.environ["ST_SKILL_INIT"]).is_absolute()\n'
                'args=dict(zip(sys.argv[2::2],sys.argv[3::2]))\n'
                'pathlib.Path(args["--output"]).write_text(' + repr(
                'oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
                'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\tm\t1e-6\t1e-5\n'
                'PDK\tN\tsymbol\tnreal\tD,G,S,B\tl\tm\t2e-7\t2e-6\n') + ')\n')
            backend.chmod(0o755)
            capture = base / 'capture.json'
            engine = base / 'engine.py'
            engine.write_text('#!/usr/bin/env python3\nimport json,os,pathlib,sys\n'
                'json.dump({"argv":sys.argv,"context":os.environ["ST_CIRCUIT_CONTEXT"],'
                '"metadata":os.environ["ST_PDK_METADATA"],"provider":os.environ["ST_OP_PROVIDER_BIN"],'
                '"init":os.environ["ST_SKILL_INIT"]},'
                'open(' + repr(str(capture)) + ',"w"))\n')
            engine.chmod(0o755)
            session = base / 'session'
            args = [sys.executable, str(SITE / 'standalone.py'), 'inspect', '--engine', str(engine),
                '--pdk-root', str(pdk_alias), '--simulation-profile', str(profile), '--backend', str(backend),
                '--cds-lib', str(cds), '--lib', 'L', '--cell', 'core', '--view', 'schematic',
                '--bench-lib', 'L', '--bench-cell', 'B', '--bench-view', 'schematic', '--work-dir', str(session)]
            env = dict(os.environ, ST_SKILL_INIT=str(init.resolve()))
            result = subprocess.run(args, capture_output=True, text=True, env=env)
            self.assertEqual(result.returncode, 0, result.stderr)
            captured = json.loads(capture.read_text())
            metadata = json.loads(Path(captured['metadata']).read_text())
            self.assertEqual(metadata[0]['pdk_paths'], [str(pdk.resolve())])
            self.assertEqual(metadata[0]['pdk_alias_paths'], [str(pdk_alias.absolute())])
            self.assertTrue(captured['provider'].endswith('/op_provider.py'))
            self.assertEqual(captured['init'], str(init.resolve()))
            command = [sys.executable, str(SITE / 'standalone.py'), 'generate', '--engine', str(engine), '--session', str(session)]
            self.assertEqual(subprocess.run(command, capture_output=True).returncode, 0)
            self.assertIn('generate', json.loads(capture.read_text())['argv'])
            self.assertEqual(json.loads(capture.read_text())['init'], str(init.resolve()))
            relative_args = [str(base / 'invalid_session') if item == str(session) else item for item in args]
            relative = subprocess.run(relative_args, capture_output=True, text=True,
                                      env=dict(env, ST_SKILL_INIT='actual_init.il'))
            self.assertEqual(relative.returncode, 2)
            self.assertIn('absolute', relative.stderr)
            model.write_text('model nreal bsim4 type=p\n')
            changed = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(changed.returncode, 2)
            self.assertIn('changed', changed.stderr)

    def test_cadence_runtime_processes_use_tool_commands_and_preserve_signs(self):
        runtime = importlib.import_module('cadence_runtime')
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            fake_ocean = base / 'ocean.py'
            fake_ocean.write_text('#!/usr/bin/env python3\nimport pathlib,re,sys,json\n'
                'text=pathlib.Path(sys.argv[sys.argv.index("-restore")+1]).read_text()\n'
                'paths=[json.loads(s) for s in re.findall(r\'outfile\\(("(?:\\\\.|[^"\\\\])*")\\)\',text)]\n'
                'if "createNetlist" in text:\n'
                ' root=json.loads(re.search(r\'projectDir" \\\'string ("[^"\\n]+")\',text)[1])\n'
                ' out=pathlib.Path(root)/"cell/spectre/schematic/netlist/input.scs"\n'
                ' out.parent.mkdir(parents=True)\n'
                ' out.write_text("simulator lang=spectre\\nM0 (OUT G VSS VSS) nreal w=1u l=1u\\n")\n'
                ' pathlib.Path(paths[0]).write_text("OUT\\nG\\nVSS\\n")\n'
                'else:\n pathlib.Path(paths[0]).write_text("signal\\tvalue\\nM0:id\\t-1e-5\\n")\n'
                'pathlib.Path(paths[-1]).write_text("OK\\n")\n')
            fake_ocean.chmod(0o755)
            fake_spectre = base / 'spectre.py'
            fake_spectre.write_text('#!/usr/bin/env python3\nimport pathlib,sys\n'
                'psf=pathlib.Path(sys.argv[sys.argv.index("-raw")+1])\n'
                'assert sys.argv[sys.argv.index("-format")+1]=="psfbin"\n'
                '[(psf/n).write_text("fixture") for n in ("dcOp.dc","dcOpInfo.info")]\n')
            fake_spectre.chmod(0o755)
            profile = base / 'profile.json'
            profile.write_text(json.dumps({'nominal_corner': 'tt', 'op_corners': {'tt': {
                'models': [{'model_file': '/fixture/models.scs', 'section_name': 'tt'}]}}}))
            init = base / 'actual_pdk_init.il'
            init.write_text('; fixture PDK initialization')
            (base / 'cds.lib').write_text('// fixture')
            bench = base / 'bench.scs'
            bench.write_text('simulator lang=spectre\nsubckt core G OUT VSS\nends core\n')
            args = SimpleNamespace(work_dir=str(base / 'oa'), cds_path=str(base), lib='L', cell='candidate',
                view='schematic', output=str(base / 'dut.scs'), ports_from=str(bench), source_subckt='core')
            with patch.dict(os.environ, {'ST_OCEAN_BIN': str(fake_ocean), 'ST_SPECTRE_BIN': str(fake_spectre),
                                         'ST_SIMULATION_PROFILE': str(profile), 'ST_SKILL_INIT': str(init)}):
                runtime.netlist(args)
                script = (base / 'oa/runtime.ocn').read_text()
                self.assertIn('load(' + json.dumps(str(init.resolve())) + ')', script)
                self.assertLess(script.index('load('), script.index("simulator('spectre)"))
                self.assertIn('subckt candidate G OUT VSS', Path(args.output).read_text())
                origin = json.loads(Path(args.output + '.origin.json').read_text())
                self.assertTrue(origin['working_directory'].endswith('/netlist'))
                sim = SimpleNamespace(psf_dir=str(base / 'psf'), netlist=args.output, log=str(base / 'spectre.log'))
                self.assertEqual(runtime.simulate(sim), 0)
                runtime.read_psf(SimpleNamespace(output=str(base / 'raw.tsv'), psf_dir=sim.psf_dir))
            self.assertIn('-1.0000000000000001e-05', (base / 'raw.tsv').read_text())


if __name__ == '__main__':
    unittest.main()
