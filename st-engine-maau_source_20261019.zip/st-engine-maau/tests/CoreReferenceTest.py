"""Select a core from an actual parent snapshot; never reuse a historic cell name."""
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
HEADER = '// OA structural netlist generated read-only by st-engine-maau\n'
PARENT = HEADER + 'subckt main_v100 A B\nref_core ( A B ) oa_SOURCE__different_core\nends main_v100\n'


class CoreReferenceTest(unittest.TestCase):
    def module(self):
        try:
            module = importlib.import_module('inspect_core_reference')
        except ImportError:
            module = None
        self.assertIsNotNone(module, 'automatic core-reference inspection is missing')
        return module

    def test_selects_actual_master_instead_of_historical_core(self):
        found = self.module().select_reference(PARENT)
        self.assertEqual(found, {'parent_cell': 'main_v100', 'instance': 'ref_core',
                                'library': 'SOURCE', 'cell': 'different_core'})

    def test_accepts_wrapped_master_record(self):
        text = PARENT.replace(') oa_SOURCE', ')\n oa_SOURCE')
        self.assertEqual(self.module().select_reference(text)['cell'], 'different_core')

    def test_ambiguous_references_need_exact_instance(self):
        text = PARENT.replace('ends main_v100', 'second_core ( A B ) oa_OTHER__another_core\nends main_v100')
        module = self.module()
        with self.assertRaisesRegex(ValueError, 'multiple'):
            module.select_reference(text)
        found = module.select_reference(text, 'second_core')
        self.assertEqual((found['library'], found['cell']), ('OTHER', 'another_core'))

    def test_rejects_absent_or_malformed_reference(self):
        module = self.module()
        for text in (PARENT.replace('ref_core', 'other').replace('different_core', 'other'),
                     PARENT.replace('oa_SOURCE__different_core', 'oa_broken'),
                     PARENT.replace('ends main_v100', 'ends wrong_parent'),
                     PARENT.replace(HEADER, '')):
            with self.subTest(text=text), self.assertRaises(ValueError):
                module.select_reference(text)

    def fixture(self, base, current=PARENT, snapshot_status=0):
        source = base / 'reference.scs'
        source.write_text(PARENT)
        cds = base / 'cds.lib'
        cds.write_text('DEFINE SOURCE /unused\n')
        pdk = base / 'pdk'
        pdk.mkdir()
        capture = base / 'engine.json'
        engine = base / 'engine.py'
        engine.write_text('#!/usr/bin/env python3\nimport json,os,sys\n'
            'json.dump({"argv":sys.argv,"context":os.environ["ST_CIRCUIT_CONTEXT"]},open('
            + repr(str(capture)) + ',"w"))\n')
        engine.chmod(0o755)
        backend = base / 'backend.py'
        probe = ('oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\tcdf_type\tdefault_value\tchoices\thas_schematic\n'
                 'PDK\tactual_mos\tsymbol\tdevice\tD,G,S,B\tl\tm\t\t\tstring\t240n\t\tfalse\n'
                 'PDK\tactual_mos\tsymbol\tdevice\tD,G,S,B\tnfin\t\t\t\tint\t4\t\tfalse\n')
        backend.write_text('#!/usr/bin/env python3\nimport pathlib,sys\n'
            'verb=sys.argv[1]; a=dict(zip(sys.argv[2::2],sys.argv[3::2]))\n'
            'if verb=="snapshot":\n'
            ' sys.exit(' + str(snapshot_status) + ') if ' + str(snapshot_status) + ' else None\n'
            ' pathlib.Path(a["--netlist-output"]).write_text(' + repr(current) + ')\n'
            ' pathlib.Path(a["--catalog-output"]).write_text("master\\n")\n'
            ' pathlib.Path(a["--geometry-output"]).write_text("instance\\n")\n'
            'elif verb=="discover-pdk":\n'
            ' assert (a["--lib"],a["--cell"])==("SOURCE","different_core")\n'
            ' pathlib.Path(a["--output"]).write_text("role\\tlibrary\\tpath\\ttechnology\\tcell\\tview\\n"'
            ' + "source\\tSOURCE\\t"+' + repr(str(base)) + '+"\\tTECH\\tdifferent_core\\tschematic\\n"'
            ' + "technology\\tTECH\\t"+' + repr(str(pdk)) + '+"\\tTECH\\t\\t\\n"'
            ' + "device\\tPDK\\t"+' + repr(str(pdk)) + '+"\\tTECH\\t\\t\\n")\n'
            'elif verb=="probe-pdk":\n'
            ' pathlib.Path(a["--output"]).write_text(' + repr(probe) + ')\n'
            'else: sys.exit("unexpected mutation/action: "+verb)\n')
        backend.chmod(0o755)
        command = [sys.executable, str(ROOT / 'server/site/inspect_core_reference.py'),
                   '--reference-netlist', str(source), '--parent-lib', 'SOURCE', '--parent-cell', 'main_v100',
                   '--cds-lib', str(cds), '--backend', str(backend), '--engine', str(engine),
                   '--work-dir', str(base / 'session'), '--variant-lib', 'DERIVED', '--variant-id', 'TS_NEW']
        env = dict(os.environ)
        env.pop('ST_SKILL_INIT', None)
        return command, env, capture

    def test_workflow_inspects_core_and_preserves_reference_evidence(self):
        with tempfile.TemporaryDirectory(prefix='core reference ') as tmp:
            base = Path(tmp).resolve()
            command, env, capture = self.fixture(base)
            result = subprocess.run(command, env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            recorded = json.loads(capture.read_text())
            options = dict(zip(recorded['argv'][2::2], recorded['argv'][3::2]))
            self.assertEqual(options['--lib'], 'SOURCE')
            self.assertEqual(options['--cell'], 'different_core')
            self.assertEqual(options['--core-subckt'], 'different_core')
            self.assertEqual(options['--variant-cell'], 'different_core__TS_NEW')
            context = json.loads(Path(recorded['context']).read_text())
            self.assertEqual(context['source_dut'], {'lib': 'SOURCE', 'cell': 'different_core', 'view': 'schematic'})
            self.assertEqual(context['source_benches'], [])
            reference = base / 'session/reference_check'
            self.assertEqual((reference / 'parent_current.scs').read_text(), PARENT)
            selection = json.loads((reference / 'core_selection.json').read_text())
            self.assertEqual(selection['source']['cell'], 'different_core')
            manifest = json.loads((base / 'session/analysis/standalone_inputs/provider_inputs.json').read_text())
            self.assertIn(str(reference / 'core_selection.json'), manifest['file_sha256'])

    def test_changed_parent_reference_stops_before_core_inspect(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            command, env, capture = self.fixture(base, PARENT.replace('different_core', 'changed_core'))
            result = subprocess.run(command, env=env, text=True, capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('changed', result.stderr)
            self.assertFalse(capture.exists())

    def test_snapshot_failure_is_propagated_and_no_core_is_inspected(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            command, env, capture = self.fixture(base, snapshot_status=70)
            result = subprocess.run(command, env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 70)
            self.assertFalse(capture.exists())


if __name__ == '__main__':
    unittest.main()
