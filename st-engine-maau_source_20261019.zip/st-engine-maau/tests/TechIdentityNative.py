"""Execute the production technology resolver in native SKILL, read-only."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]

ACTION = r'''; Fixture values exercise the production resolver; no Cadence API replacement.
load(getShellEnvVar("ST_TECH_IDENTITY_ADAPTER"))
stTechIdentityFixtures = list(
  list("D" list(list("databaseOwner" "W") list("attachedTechnology" "W")))
  list("W" list(list("databaseOwner" "T") list("attachedTechnology" "T")))
  list("T" list(list("databaseOwner" "T") list("attachedTechnology" nil)))
  list("F" list(list("databaseOwner" "F") list("attachedTechnology" nil)))
  list("INC" list(list("databaseOwner" "INC") list("attachedTechnology" "T")))
  list("BROKEN" list(list("databaseOwner" "UNREGISTERED")))
  list("A" list(list("databaseOwner" "B")))
  list("B" list(list("databaseOwner" "A")))
  list("EMPTY" list(list("databaseOwner" "")))
)
procedure(stTechIdentityFixtureReader(library)
  let((pair)
    pair=assoc(library stTechIdentityFixtures)
    when(pair cadr(pair))
  )
)
; A valid root beyond the maximum must not be silently accepted.
for(index 0 64
  stTechIdentityFixtures=append1(stTechIdentityFixtures
    list(sprintf(nil "DEEP%d" index)
      list(list("databaseOwner" sprintf(nil "DEEP%d" index+1)))))
)
stTechIdentityFixtures=append1(stTechIdentityFixtures
  list("DEEP65" list(list("databaseOwner" "DEEP65"))))
let((spec identity count port sourceLibrary sourceIdentity attached deviceIdentity)
  count=0
  foreach(spec list(
      list("chain_source" "D" "T" list("D" "W" "T"))
      list("chain_device" "W" "T" list("W" "T"))
      list("root" "T" "T" list("T"))
      list("foreign" "F" "F" list("F"))
      list("incremental" "INC" "INC" list("INC"))
      list("missing" "UNKNOWN" nil nil)
      list("dangling" "BROKEN" nil nil)
      list("cycle" "A" nil nil)
      list("deep" "DEEP0" nil nil)
      list("empty" "EMPTY" nil nil))
    identity=stTechResolveLibraryIdentity(cadr(spec) 'stTechIdentityFixtureReader)
    unless(and(equal(stTechGet(identity "processId") caddr(spec))
               equal(stTechGet(identity "technologyChain") nth(3 spec)))
      error("TECH_IDENTITY_CASE_FAILED fixture=%L identity=%L" car(spec) identity))
    count=count+1
    printf("TECH_IDENTITY_CASE_OK fixture=%L identity=%L\n" car(spec) identity)
  )
  sourceLibrary=getShellEnvVar("ST_TECH_IDENTITY_SOURCE")
  when(and(stringp(sourceLibrary) not(equal(sourceLibrary "")))
    printf("TECH_IDENTITY_SOURCE_RECORD library=%L record=%L\n"
      sourceLibrary stTechReadLibraryTechnology(sourceLibrary))
    sourceIdentity=stTechDefaultLibraryIdentity(sourceLibrary)
    printf("TECH_IDENTITY_SOURCE library=%L identity=%L\n" sourceLibrary sourceIdentity)
    unless(sourceIdentity error("Source technology identity is unproven: %L" sourceLibrary))
    attached=stTechGet(sourceIdentity "attachedTechnology")
    when(and(stringp(attached) not(equal(attached "")))
      deviceIdentity=stTechDefaultLibraryIdentity(attached)
      printf("TECH_IDENTITY_ATTACHED library=%L identity=%L\n" attached deviceIdentity)
      ; Report both identities; incremental tech may legitimately differ.
      ; The real discovery gate, not this diagnostics harness, judges devices.
    )
  )
  port=outfile(getShellEnvVar("ST_TECH_IDENTITY_STATUS"))
  unless(port error("Cannot create native technology check status"))
  fprintf(port "OK cases=%d\n" count)
  close(port)
)
exit()
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cds-lib', required=True)
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--source-lib')
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    cds, work = Path(args.cds_lib), Path(args.work_dir)
    if not cds.is_absolute() or not cds.is_file() or cds.name != 'cds.lib':
        raise SystemExit('STOP: --cds-lib requires a readable absolute cds.lib')
    if not work.is_absolute():
        raise SystemExit('STOP: --work-dir requires a new absolute directory')
    work.mkdir(parents=True, exist_ok=False)
    action = work / 'tech_identity_check.il'
    # Load the actual current source, with no translated/duplicated resolver.
    action.write_text(ACTION.replace('load(getShellEnvVar("ST_TECH_IDENTITY_ADAPTER"))',
        'load("' + str(ROOT / 'server/skill/tech_adapter.il').replace('\\', '\\\\').replace('"', '\\"') + '")'))
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return
    executable = shutil.which(os.environ.get('ST_VIRTUOSO_BIN') or 'virtuoso')
    if not executable:
        raise SystemExit('STOP: Virtuoso executable unavailable')
    env = dict(os.environ)
    status = work / 'status.txt'
    env['ST_TECH_IDENTITY_STATUS'] = str(status)
    env['ST_TECH_IDENTITY_SOURCE'] = args.source_lib or ''
    log = work / 'virtuoso.log'
    with (work / 'launcher.log').open('x') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action), '-log', str(log)],
            cwd=str(cds.parent), env=env, stdout=stream, stderr=subprocess.STDOUT)
    if log.exists():
        print('\n'.join(log.read_text(errors='replace').splitlines()[-100:]))
    if result.returncode or not status.is_file() or status.read_text().strip() != 'OK cases=10':
        raise SystemExit('STOP: native technology identity check failed; retain ' + str(work))
    print('TECH_IDENTITY_NATIVE_OK cases=10')


if __name__ == '__main__':
    main()
