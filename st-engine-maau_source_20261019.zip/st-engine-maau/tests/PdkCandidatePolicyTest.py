"""Native policy preparation/dispatch only; no local SKILL/OA emulation."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import pin_site_inputs, write_json


class PdkCandidatePolicyTest(unittest.TestCase):
    def fixture(self, base):
        session = base / 'failed session'
        archive = session / 'analysis/standalone_inputs'
        archive.mkdir(parents=True)
        (session / 'logs').mkdir()
        (session / 'logs/scan_pdk.log').write_text(
            '*Error* Unproven CDF Spectre termOrder for Actual/bad_3t; cdfOrder=(D G S B) symbolNames=("G" "S" "D")\n')
        cds_dir = base / 'cadence'; cds_dir.mkdir()
        (cds_dir / 'cds.lib').write_text('; fixture\n')
        paths = {key: str(archive / (key + ('.json' if key in ('context', 'rules', 'tech') else '.il')))
                 for key in ('context', 'rules', 'tech', 'adapter', 'runtime', 'init')}
        write_json(paths['context'], {'source_cds_path': str(cds_dir),
            'source_dut': {'lib': 'DUT', 'cell': 'core', 'view': 'schematic'}, 'source_benches': []})
        write_json(paths['rules'], {'validation_scope': 'structure_only'})
        write_json(paths['tech'], [{'corners': [], 'devices': [
            {'oa_library': 'Actual', 'cell': 'bad_3t', 'kind': 'mos'},
            {'oa_library': 'Actual', 'cell': 'valid_4t', 'kind': 'mos'}]}])
        for key in ('adapter', 'runtime', 'init'):
            Path(paths[key]).write_text('; fixture\n')
        write_json(archive / 'provider_inputs.json', pin_site_inputs(paths))
        return session

    def run_entry(self, session, work, extra=(), env=None):
        return subprocess.run([sys.executable, str(ROOT / 'tests/PdkCandidatePolicyNative.py'),
            '--session', str(session), '--work-dir', str(work)] + list(extra),
            capture_output=True, text=True, env=env)

    def test_prepare_uses_actual_failure_and_current_production_policy(self):
        # Missing production policy must prevent producing an executable check.
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base)
            work = base / 'native check'
            result = self.run_entry(session, work, ['--prepare-only'])
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('native execution not performed', result.stdout)
            self.assertTrue((work / 'candidate_policy_check.il').is_file())

    def test_no_success_marker_never_counts_as_native_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base)
            fake = base / 'fake process'
            fake.write_text('#!/usr/bin/env bash\nprintf "OK cases=3 actual=true\\n" > "$ST_CANDIDATE_POLICY_STATUS"\nprintf "incomplete native run\\n"\n')
            fake.chmod(0o755)
            env = dict(os.environ, ST_VIRTUOSO_BIN=str(fake))
            work = base / 'native check'
            result = self.run_entry(session, work, env=env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertIn('incomplete native run', result.stdout)
            self.assertNotIn('CANDIDATE_POLICY_NATIVE_OK', result.stdout)
            self.assertTrue((work / 'launcher.log').is_file())

    def test_old_evidence_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base)
            work = base / 'native check'; work.mkdir()
            keep = work / 'keep'; keep.write_text('original evidence')
            result = self.run_entry(session, work, ['--prepare-only'])
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(keep.read_text(), 'original evidence')

    def test_successful_scan_keeps_rejection_evidence_after_line_240(self):
        # Only the external Virtuoso process is replaced; the real backend must
        # retain a late candidate rejection even when scan status is OK.
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            cds = base / 'cds.lib'; cds.write_text('; fixture\n')
            init = base / 'init.il'; init.write_text('; fixture\n')
            fake = base / 'fake_virtuoso'
            fake.write_text('''#!/usr/bin/env bash
set -eu
log="$(dirname "$ST_BACKEND_STATUS_FILE")/virtuoso.log"
for ((i=0; i<260; ++i)); do printf 'initialization %s\\n' "$i"; done > "$log"
printf 'ST_PDK_CANDIDATE_REJECTED master="Actual"/"bad_3t" reason=description_error\\n' >> "$log"
printf 'master\\tkind\\toa_library\\nM0\\tmos\\tActual\\n' > "$ST_REQ_CATALOG_OUTPUT"
printf 'source_library\\tprocess_identity\\tcontext_complete\\tscan_complete\\tdiagnostic\\tcandidate_libraries\\nDUT\\tTech\\ttrue\\ttrue\\t\\tActual\\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\\n' > "$ST_BACKEND_STATUS_FILE"
''')
            fake.chmod(0o755)
            env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
            env.update(ST_VIRTUOSO_BIN=str(fake), ST_SKILL_INIT=str(init), ST_BACKEND_RUN_ROOT=str(base))
            result = subprocess.run([str(ROOT / 'server/st_virtuoso_backend.sh'), 'scan-pdk',
                '--cds-lib', str(cds), '--lib', 'DUT', '--cell', 'core', '--view', 'schematic',
                '--catalog-output', str(base / 'catalog.tsv'), '--identity-output', str(base / 'identity.tsv')],
                capture_output=True, text=True, env=env)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('ST_PDK_CANDIDATE_REJECTED master="Actual"/"bad_3t"', result.stdout)

    def test_successful_materialize_keeps_property_copy_evidence_after_line_240(self):
        # Exercise the real logging/cleanup path; this process fixture does not
        # execute SKILL or claim that OA properties were copied on a server.
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve()
            cds = base / 'cds.lib'; cds.write_text('; fixture\n')
            init = base / 'init.il'; init.write_text('; fixture\n')
            plan = base / 'plan.json'; plan.write_text('{"schema_version":3}\n')
            work = base / 'work'; work.mkdir()
            fake = base / 'fake_virtuoso'
            fake.write_text('''#!/usr/bin/env bash
set -eu
log="$(dirname "$ST_BACKEND_STATUS_FILE")/virtuoso.log"
for ((i=0; i<260; ++i)); do printf 'initialization %s\\n' "$i"; done > "$log"
printf 'ST_TOPOLOGY_PROPERTIES_COPIED instance="M0" from="M0" callbacks=nil\\n' >> "$log"
printf 'OK\\n' > "$ST_BACKEND_STATUS_FILE"
''')
            fake.chmod(0o755)
            env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
            env.update(ST_VIRTUOSO_BIN=str(fake), ST_SKILL_INIT=str(init), ST_BACKEND_RUN_ROOT=str(base))
            result = subprocess.run([str(ROOT / 'server/st_virtuoso_backend.sh'), 'materialize',
                '--cds-lib', str(cds), '--work-dir', str(work),
                '--skill', str(ROOT / 'skill/standalone_topology_variant.il'), '--plan', str(plan)],
                capture_output=True, text=True, env=env)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('ST_TOPOLOGY_PROPERTIES_COPIED instance="M0" from="M0" callbacks=nil', result.stdout)
            self.assertEqual(list(base.glob('st-virtuoso-backend.*')), [])


if __name__ == '__main__':
    unittest.main()
