"""Check the production terminal reader in native SKILL, including a real master."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from diagnose_terminals import CONFLICT

ACTION = r'''; Load the actual production functions; no translated checker or OA stubs.
load(__TECH_ADAPTER__)
load(__SITE_ADAPTER__)
let((spec result count port actualNames inputNames inputSnapshot)
  count=0
  foreach(spec list(
    list("symbol_names" list('PLUS 'MINUS) list("PLUS" "MINUS") list("PLUS" "MINUS"))
    list("string_names" list("PLUS" "MINUS") list("PLUS" "MINUS") list("PLUS" "MINUS"))
    list("mixed_names" list('PLUS "MINUS") list("PLUS" "MINUS") list("PLUS" "MINUS"))
    list("cdf_order" list('MINUS 'PLUS) list("PLUS" "MINUS") list("MINUS" "PLUS"))
    list("normalized_duplicate" list('PLUS "PLUS") list("PLUS" "MINUS") nil)
    list("case_conflict" list('plus 'MINUS) list("PLUS" "MINUS") nil)
    list("unknown_name" list('PLUS 'WRONG) list("PLUS" "MINUS") nil)
    list("missing_name" list('PLUS) list("PLUS" "MINUS") nil)
    list("numeric_name" list(1 2) list("PLUS" "MINUS") nil)
    list("empty_name" list("" "MINUS") list("" "MINUS") nil)
    list("nil_name" list(nil 'MINUS) list("nil" "MINUS") nil)
    list("non_list" "PLUS,MINUS" list("PLUS" "MINUS") nil))
    inputNames=cadr(spec)
    inputSnapshot=sprintf(nil "%L" inputNames)
    ; Suppress expected negative-case errors, fail if they are accepted.
    result=errset(stSiteValidatedTerminalNames(inputNames caddr(spec) "fixture" "terminals") nil)
    if(nth(3 spec) then
      unless(and(result equal(car(result) nth(3 spec)))
        error("CDF_TERMINAL_CASE_FAILED fixture=%L result=%L" car(spec) result))
    else
      when(result error("CDF_TERMINAL_INVALID_ACCEPTED fixture=%L result=%L" car(spec) result))
    )
    unless(equal(inputSnapshot sprintf(nil "%L" inputNames))
      error("CDF_TERMINAL_INPUT_MUTATED fixture=%L" car(spec)))
    count=count+1
    printf("CDF_TERMINAL_CASE_OK fixture=%L\n" car(spec))
  )
  actualNames=stSiteSpectreTerminalNames(__LIBRARY__ __CELL__ "symbol")
  printf("CDF_TERMINAL_ACTUAL_OK master=%L/%L/symbol normalized=%L\n" __LIBRARY__ __CELL__ actualNames)
  port=outfile(getShellEnvVar("ST_CDF_TERMINAL_STATUS"))
  unless(port error("Cannot create native terminal check status"))
  fprintf(port "OK cases=%d actual=true\n" count)
  close(port)
)
exit()
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cds-lib', required=True)
    parser.add_argument('--scan-log', required=True)
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    cds, scan, work = (Path(value).expanduser() for value in
                        (args.cds_lib, args.scan_log, args.work_dir))
    if not cds.is_absolute() or not cds.is_file() or cds.name != 'cds.lib':
        raise ValueError('--cds-lib requires an existing absolute cds.lib')
    if not scan.is_absolute() or not scan.is_file():
        raise ValueError('--scan-log requires an existing absolute failed scan log')
    if not work.is_absolute():
        raise ValueError('--work-dir requires a new absolute directory')
    masters = sorted(set(CONFLICT.findall(scan.read_text(encoding='utf-8', errors='replace'))))
    if len(masters) != 1:
        raise ValueError('need exactly one actual conflict master in the failed scan log')
    library, cell = masters[0]
    action_text = ACTION.replace('__TECH_ADAPTER__', json.dumps(str(ROOT / 'server/skill/tech_adapter.il'), ensure_ascii=False))
    action_text = action_text.replace('__SITE_ADAPTER__', json.dumps(str(ROOT / 'server/skill/site_metadata_adapter.il'), ensure_ascii=False))
    action_text = action_text.replace('__LIBRARY__', json.dumps(library, ensure_ascii=False)).replace('__CELL__', json.dumps(cell, ensure_ascii=False))
    work.mkdir(parents=True, exist_ok=False)
    action = work / 'cdf_terminal_check.il'
    action.write_text(action_text, encoding='utf-8')
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return 0
    executable = shutil.which(os.environ.get('ST_VIRTUOSO_BIN') or 'virtuoso')
    if not executable:
        raise ValueError('Virtuoso executable unavailable; retained ' + str(work))
    env = os.environ.copy()
    status = work / 'status.txt'
    env['ST_CDF_TERMINAL_STATUS'] = str(status)
    log, launcher = work / 'virtuoso.log', work / 'launcher.log'
    with launcher.open('x', encoding='utf-8') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action), '-log', str(log)],
            cwd=str(cds.parent), env=env, stdout=stream, stderr=subprocess.STDOUT)
    valid = status.is_file() and status.read_text().strip() == 'OK cases=12 actual=true'
    if result.returncode or not valid:
        for file in (launcher, log):
            if file.is_file():
                print(file.read_text(encoding='utf-8', errors='replace'))
        print('STOP: native terminal check failed; retain ' + str(work))
        return result.returncode if 0 < result.returncode < 126 else 70
    if log.is_file():
        print('\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-60:]))
    print('CDF_TERMINAL_NATIVE_OK cases=12 actual_master=' + library + '/' + cell + '/symbol')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
