#include "st/JsonWriter.h"
#include "st/OaPlan.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::OaMaterializationPlan plan()
{
    st::OaMaterializationPlan result;
    result.source = { "LDO_LIB", "capless_ldo", "schematic" };
    result.target = { "LDO_VARIANTS", "capless_ldo__work", "schematic" };
    result.clone_map.push_back({ result.source, result.target, "/" });
    result.delete_instances.push_back({ "/", "M0" });

    st::OaCreateInstance ctrl;
    ctrl.hierarchy_path = "/";
    ctrl.name = "M0";
    ctrl.master = { "PDK", "nmos_svt", "symbol" };
    ctrl.location = { 10.0, 20.0 };
    ctrl.orientation = "R0";
    ctrl.expected_terminal_count = 4;
    ctrl.connections = {
        { "Drain", "D", "M0_MID" },
        { "Gate", "G", "CTRL" },
        { "Source", "S", "VSS" },
        { "Bulk", "B", "VSS" },
    };
    ctrl.cdf_parameters = { { "l", "240n" }, { "w", "2u" } };
    result.create_instances.push_back(ctrl);

    st::OaCreateInstance cas = ctrl;
    cas.name = "M0_CAS";
    cas.location = { 10.0, 24.0 };
    cas.connections[0].net = "OUT";
    cas.connections[1].net = "VBN_CAS";
    cas.connections[2].net = "M0_MID";
    result.create_instances.push_back(cas);

    result.create_ports.push_back({ "/", "VBN_CAS", "input", "VBN_CAS", { 2.0, 24.0 } });
    result.wires.push_back({ "/", "M0_MID", { { 10.0, 21.0 }, { 10.0, 23.0 } } });
    result.preview = { "variant-001", "pset-initial", "oa-materializer-v1" };
    return result;
}

std::string readFile(const std::filesystem::path& path)
{
    std::ifstream stream(path);
    std::ostringstream contents;
    contents << stream.rdbuf();
    return contents.str();
}

} // namespace

int main()
{
    const auto validPlan = plan();
    auto diagnostics = st::ValidateOaPlan(validPlan);
    CHECK(diagnostics.empty(), "源图和隔离目标图不同且计划字段完整");

    st::Netlist baseline;
    st::Subckt baseCore;
    baseCore.name = "core";
    baseCore.pins = { "OUT", "CTRL", "VSS" };
    baseCore.instances.push_back({ "M0", { "OUT", "CTRL", "VSS", "VSS" },
        "nmos_svt", { { "l", "240n" }, { "w", "2u" } } });
    baseline.subckts.push_back(baseCore);
    auto variant = baseline;
    variant.find("core")->find("M0")->nets[0] = "M0_MID";
    variant.find("core")->instances.push_back({ "M0_CAS",
        { "OUT", "VBN_CAS", "M0_MID", "VSS" }, "nmos_svt",
        { { "l", "240n" }, { "w", "2u" } } });

    st::DeviceCatalog catalog;
    st::DeviceDescriptor nmos;
    nmos.master = "nmos_svt";
    nmos.kind = st::DeviceKind::MosN;
    nmos.terminal_count = 4;
    nmos.terminal_index = {
        { st::TerminalRole::Drain, 0 }, { st::TerminalRole::Gate, 1 },
        { st::TerminalRole::Source, 2 }, { st::TerminalRole::Bulk, 3 }
    };
    nmos.terminal_names_by_index = { "D", "G", "S", "B" };
    nmos.terminal_roles_by_index = { st::TerminalRole::Drain, st::TerminalRole::Gate,
        st::TerminalRole::Source, st::TerminalRole::Bulk };
    nmos.oa_library = "PDK";
    nmos.oa_cell = "nmos_svt";
    nmos.oa_view = "symbol";
    st::Diagnostic catalogDiagnostic;
    catalog.Add(nmos, catalogDiagnostic);

    st::OaPlanBuildContext buildContext;
    buildContext.source = validPlan.source;
    buildContext.target = validPlan.target;
    buildContext.clone_map = validPlan.clone_map;
    buildContext.hierarchy_by_subckt["core"] = "/";
    buildContext.locations["/:M0"] = { 10.0, 20.0 };
    buildContext.locations["/:M0_CAS"] = { 10.0, 24.0 };
    buildContext.wires = {
        { "/", "M0_MID", { { 10.0, 21.0 }, { 10.0, 23.0 } } },
        { "/", "CTRL", { { 8.0, 20.0 }, { 10.0, 20.0 } } },
        { "/", "VSS", { { 10.0, 18.0 }, { 10.0, 19.0 } } },
        { "/", "OUT", { { 10.0, 25.0 }, { 10.0, 26.0 } } },
        { "/", "VBN_CAS", { { 8.0, 24.0 }, { 10.0, 24.0 } } },
    };
    buildContext.preview = validPlan.preview;
    auto built = st::BuildOaMaterializationPlan(baseline, variant, catalog, buildContext);
    CHECK(built.ok() && built.plan.delete_instances.size() == 1 &&
            built.plan.create_instances.size() == 2 &&
            built.plan.create_instances[1].connections.size() == 4,
        "OA计划由baseline/variant真实diff生成，修改管和新管都带完整端子");
    CHECK(built.plan.create_instances[1].connections[1].pdk_terminal == "G" &&
            built.plan.create_instances[1].connections[1].net == "VBN_CAS",
        "OA计划使用PDK terminalOrder建立因果一致的连接");
    const auto builtJson = st::WritePlanJson(built.plan);
    CHECK(builtJson.find("\"direct_wires\":[{") != std::string::npos &&
            builtJson.find("\"net\":\"M0_MID\"") != std::string::npos &&
            builtJson.find("\"from_instance\":\"M0\"") != std::string::npos &&
            builtJson.find("\"from_terminal\":\"D\"") != std::string::npos &&
            builtJson.find("\"to_instance\":\"M0_CAS\"") != std::string::npos &&
            builtJson.find("\"to_terminal\":\"S\"") != std::string::npos,
        "新增内部网络明确生成两个真实器件引脚之间的点到点实体导线");

    auto missingTerminalCatalog = catalog;
    st::DeviceDescriptor badDevice = nmos;
    badDevice.master = "bad";
    badDevice.terminal_names_by_index.clear();
    missingTerminalCatalog.Add(badDevice, catalogDiagnostic);
    auto badVariant = variant;
    badVariant.find("core")->find("M0_CAS")->model = "bad";
    auto badBuilt = st::BuildOaMaterializationPlan(
        baseline, badVariant, missingTerminalCatalog, buildContext);
    CHECK(!badBuilt.ok(), "缺少PDK terminalOrder时不生成不完整OA计划");

    const auto json1 = st::WritePlanJson(validPlan);
    const auto json2 = st::WritePlanJson(validPlan);
    CHECK(json1 == json2, "相同OA计划生成字节级确定的JSON");
    CHECK(json1.find("\"schema_version\":1") != std::string::npos &&
            json1.find("\"source\":{") < json1.find("\"target\":{") &&
            json1.find("\"target\":{") < json1.find("\"clone_on_write\":["),
        "JSON契约具有固定顶层字段和顺序");
    CHECK(json1.find("\"delete_instances\":[{\"hierarchy_path\":\"/\",\"name\":\"M0\"}]") !=
            std::string::npos,
        "计划明确删除目标实例");
    CHECK(json1.find("\"semantic_terminal\":\"Drain\",\"pdk_terminal\":\"D\"") !=
            std::string::npos,
        "每个连接同时包含电气语义与PDK实际terminal");
    CHECK(json1.find("\"cdf_parameters\":{\"l\":\"240n\",\"w\":\"2u\"}") !=
            std::string::npos,
        "创建实例明确携带CDF参数且字段稳定排序");
    CHECK(json1.find("\"check_and_save\":true") != std::string::npos &&
            json1.find("\"variant_id\":\"variant-001\"") != std::string::npos &&
            json1.find("\"topology_hash\":\"") != std::string::npos,
        "计划包含check/save、预览身份和topology hash");
    CHECK(st::ComputeTopologyHash(validPlan) == st::ComputeTopologyHash(validPlan),
        "Topology hash对相同输入稳定");

    auto changed = validPlan;
    changed.create_instances[1].connections[1].net = "VBN_OTHER";
    CHECK(st::ComputeTopologyHash(validPlan) != st::ComputeTopologyHash(changed),
        "任何电气连接变化都会改变Topology hash");

    auto packagedPlan = validPlan;
    packagedPlan.schema_version = 3;
    packagedPlan.create_instances.clear();
    packagedPlan.create_ports.clear();
    packagedPlan.direct_wires.clear();
    packagedPlan.wires.clear();
    st::OaGeneratedCell generated;
    generated.package_id = "PKG0001";
    generated.schematic = {"LDO_VARIANTS", "capless_ldo__PKG0001", "schematic"};
    generated.symbol = {"LDO_VARIANTS", "capless_ldo__PKG0001", "symbol"};
    generated.symbol_lower_left = {-1.5, -1.0};
    generated.symbol_upper_right = {1.5, 1.0};
    auto generatedCtrl = validPlan.create_instances[0];
    generatedCtrl.hierarchy_path = "/@generated/PKG0001";
    generatedCtrl.location = {4.0, 2.0};
    auto generatedCas = validPlan.create_instances[1];
    generatedCas.hierarchy_path = "/@generated/PKG0001";
    generatedCas.location = {4.0, 6.0};
    generated.create_instances = {generatedCtrl, generatedCas};
    generated.create_ports = {
        {"/@generated/PKG0001", "OUT", "inputOutput", "OUT", {-4.0, 0.0}},
        {"/@generated/PKG0001", "CTRL", "inputOutput", "CTRL", {-4.0, -2.0}},
        {"/@generated/PKG0001", "VSS", "inputOutput", "VSS", {-4.0, -4.0}},
        {"/@generated/PKG0001", "VBN_CAS", "inputOutput", "VBN_CAS", {-4.0, -6.0}},
    };
    generated.direct_wires.push_back({"/@generated/PKG0001", "M0_MID",
        "M0", "D", "M0_CAS", "S"});
    packagedPlan.generated_cells.push_back(generated);

    st::OaCreateInstance wrapper;
    wrapper.hierarchy_path = "/";
    wrapper.name = "M0";
    wrapper.master = generated.symbol;
    wrapper.location = {120.0, 80.0};
    wrapper.expected_terminal_count = 4;
    wrapper.connections = {
        {"Other", "OUT", "OUT"}, {"Other", "CTRL", "CTRL"},
        {"Other", "VSS", "VSS"}, {"Other", "VBN_CAS", "VBN_CAS"},
    };
    packagedPlan.create_instances.push_back(wrapper);
    CHECK(st::ValidateOaPlan(packagedPlan).empty(),
          "封装OA计划允许先创建子schematic和symbol，再在核心图放一个wrapper");
    const auto packagedJson = st::WritePlanJson(packagedPlan);
    CHECK(packagedJson.find("\"schema_version\":3") != std::string::npos &&
          packagedJson.find("\"generated_cells\":[{") != std::string::npos &&
          packagedJson.find("\"package_id\":\"PKG0001\"") != std::string::npos &&
          packagedJson.find("\"symbol\":{") != std::string::npos &&
          packagedJson.find("\"create_ports\":[{") != std::string::npos,
          "JSON计划完整携带生成子Cell、symbol和端口定义");

    auto overwrite = validPlan;
    overwrite.target = overwrite.source;
    auto overwriteDiagnostics = st::ValidateOaPlan(overwrite);
    CHECK(!overwriteDiagnostics.empty() &&
            overwriteDiagnostics[0].code == st::DiagCode::SourceDesignProtected,
        "OA计划禁止把目标cellview指向原设计");
    auto revisionBypass = validPlan;
    revisionBypass.target = revisionBypass.source;
    revisionBypass.target.revision = "different-revision";
    revisionBypass.clone_map[0].target = revisionBypass.target;
    CHECK(!st::ValidateOaPlan(revisionBypass).empty(),
        "仅修改revision字段不能绕过源cellview保护");

    auto missingScope = validPlan;
    missingScope.create_instances[0].hierarchy_path = "/XCORE";
    auto missingScopeDiagnostics = st::ValidateOaPlan(missingScope);
    CHECK(!missingScopeDiagnostics.empty() &&
            missingScopeDiagnostics[0].code == st::DiagCode::OaPlanInvalid,
        "每个层级操作都必须存在对应的clone-on-write目标映射");

    auto hierarchical = validPlan;
    hierarchical.clone_map.push_back({
        { "LDO_LIB", "ldo_core", "schematic" },
        { "LDO_VARIANTS", "ldo_core__work", "schematic" },
        "/XCORE", "/", "XCORE"
    });
    hierarchical.create_instances[0].hierarchy_path = "/XCORE";
    CHECK(st::ValidateOaPlan(hierarchical).empty(),
        "明确克隆映射后允许修改层级内MOS");
    auto missingRebind = hierarchical;
    missingRebind.clone_map[1].parent_instance_name.clear();
    CHECK(!st::ValidateOaPlan(missingRebind).empty(),
        "非根层级必须声明父实例重绑定，防止同cell其他分支被一起修改");

    const auto projectRoot = std::filesystem::path(__FILE__).parent_path().parent_path();
    const auto skill = readFile(projectRoot / "skill" / "topology_variant.il");
    const auto adapter = readFile(projectRoot / "server" / "skill" / "pdk_adapter.il");
    const auto exporter = readFile(projectRoot / "server" / "skill" / "export_snapshot.il");
    const auto devicePolicy = readFile(projectRoot / "server" / "config" /
                                       "device_policy.tsv");
    CHECK(skill.find("procedure(MaauTopologyVariantMaterialize(planFile)") != std::string::npos &&
            skill.find("procedure(MaauTopologyVariantMaterializeData(plan)") != std::string::npos,
        "SKILL同时提供planFile入口和SkillExecutor已解析JSON入口");
    CHECK(skill.find("dbOpenCellViewByType") != std::string::npos &&
            skill.find("dbCreateInst") != std::string::npos &&
            skill.find("MaauTopologyConnectTerminal") != std::string::npos &&
            skill.find("cdfGetInstCDF") != std::string::npos &&
            skill.find("MaauTopologyCheckAndSave") != std::string::npos &&
            skill.find("dbSave") != std::string::npos,
        "SKILL静态契约覆盖打开、创建、连线、CDF、检查和保存");
    CHECK(skill.find("procedure(maauTvCreateGeneratedCell") != std::string::npos &&
            skill.find("MaauTopologyCreateWrapperSymbol") != std::string::npos &&
            adapter.find("procedure(StTopologyCreateWrapperSymbol") != std::string::npos &&
            adapter.find("dbCreateTerm") != std::string::npos &&
            adapter.find("dbCreatePin") != std::string::npos,
        "SKILL先生成封装schematic与symbol，再由父图引用wrapper");
    CHECK(exporter.find("procedure(stBackendWriteCatalogPolicyRow") != std::string::npos &&
            exporter.find("foreach(policy policies") != std::string::npos,
        "snapshot目录输出全部已批准PDK策略行，不只输出原图已用器件");
    CHECK(skill.find("maauTvOpenScope") != std::string::npos &&
            skill.find("clone_on_write") != std::string::npos,
        "SKILL按hierarchy_path打开对应的隔离克隆cellview");
    CHECK(skill.find("MaauTopologyApplyCdfParameters") != std::string::npos &&
            skill.find("cdfUpdateInstParam") == std::string::npos,
        "CDF参数必须走宿主的PDK回调适配器，避免通用刷新覆盖用户尺寸");
    CHECK(skill.find("MaauTopologyConnectTerminal") != std::string::npos &&
            skill.find("dbCreateConnByName") == std::string::npos &&
            skill.find("maauTvCreateDirectWire") != std::string::npos &&
            skill.find("maauTvConnectionIsDirect") != std::string::npos &&
            skill.find("maauTvNetHasDirectWire") != std::string::npos &&
            adapter.find("procedure(MaauTopologyConnectTerminal") != std::string::npos &&
            adapter.find("procedure(MaauTopologyConnectInstances") != std::string::npos &&
            adapter.find("dbFindTermByName") != std::string::npos &&
            adapter.find("dbTransformPoint") != std::string::npos &&
            adapter.find("schCreateWire") != std::string::npos &&
            adapter.find("schCreateWireLabel") != std::string::npos &&
            adapter.find("dbCreateConnByName") == std::string::npos,
        "新内部网络用引脚间实体线，其余网络用真实引脚短线标签，不预造逻辑连接");
    CHECK(adapter.find("procedure(stTopologyStubCrossesOtherTerminal") !=
                std::string::npos &&
            adapter.find("procedure(stTopologyWireStubEnd(inst terminalName pinCenter)") !=
                std::string::npos &&
            adapter.find("stTopologyWireStubEnd(inst terminalName pinCenter)") !=
                std::string::npos,
        "端子短线必须避开同一器件的其他引脚，防止相邻Bulk与Source被误连");
    CHECK(exporter.find("stBackendPolicyTerminalNames") != std::string::npos &&
            exporter.find("stBackendFindInstTermByName") != std::string::npos,
        "回读网表按明确PDK端子顺序查找实例端子，不依赖instTerms遍历顺序");
    CHECK(exporter.find("cv~>bBox") != std::string::npos &&
            exporter.find("cell_left\\tcell_bottom") != std::string::npos &&
            exporter.find("cell_right\\tcell_top") != std::string::npos,
        "snapshot导出完整原理图边界供新增器件隔离放置使用");
    CHECK(devicePolicy.find("\tterminal_order\n") != std::string::npos &&
            devicePolicy.find("pdk_logic_rv200\tnio_l240_nfin4_s4\tmos_n") !=
                std::string::npos &&
            devicePolicy.find("\tB,D,G,S\n") != std::string::npos,
        "服务器PDK策略显式记录真实nio器件的B,D,G,S端子顺序");
    CHECK(skill.find("sourceCv") == std::string::npos,
        "SKILL不打开或保存源cellview，只操作预先复制的隔离目标");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "OA plan tests passed\n";
    } else {
        std::cout << failures << " OA plan tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
