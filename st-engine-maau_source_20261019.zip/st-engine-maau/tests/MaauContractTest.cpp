#include "../integration/maau/topology_variant_adapter.h"
#include "../integration/maau/topology_variant_materializer.h"
#include "../integration/maau/tech_catalog_provider.h"
#include "../integration/maau/op_simulation_provider.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::Netlist baseCircuit()
{
    st::Netlist result;
    st::Subckt core;
    core.name = "core";
    core.instances.push_back({ "M0", { "OUT", "CTRL", "VSS", "VSS" },
        "nmos", { { "w", "2u" }, { "l", "240n" } } });
    result.subckts.push_back(core);
    return result;
}

st::Netlist expectedCircuit()
{
    auto result = baseCircuit();
    auto* core = result.find("core");
    core->find("M0")->nets[0] = "M0_MID";
    core->instances.push_back({ "M0_CAS", { "OUT", "VBIAS", "M0_MID", "VSS" },
        "nmos", { { "w", "2u" }, { "l", "240n" } } });
    return result;
}

st::DeviceCatalog deviceCatalog()
{
    st::DeviceCatalog result;
    st::DeviceDescriptor descriptor;
    descriptor.master = "nmos";
    descriptor.kind = st::DeviceKind::MosN;
    descriptor.terminal_count = 4;
    descriptor.terminal_index = {
        { st::TerminalRole::Drain, 0 }, { st::TerminalRole::Gate, 1 },
        { st::TerminalRole::Source, 2 }, { st::TerminalRole::Bulk, 3 },
    };
    descriptor.terminal_names_by_index = { "D", "G", "S", "B" };
    descriptor.oa_library = "PDK";
    descriptor.oa_cell = "nmos";
    descriptor.oa_view = "symbol";
    st::Diagnostic diagnostic;
    result.Add(descriptor, diagnostic);
    return result;
}

st::OaMaterializationPlan oaPlan()
{
    st::OaPlanBuildContext context;
    context.source = { "SRC", "ldo", "schematic", "/cds/source", "r1" };
    context.target = { "STAGING", "ldo__staging", "schematic", "/work/staging", "r1" };
    context.clone_map.push_back({ context.source, context.target, "/" });
    context.hierarchy_by_subckt["core"] = "/";
    context.locations["/:M0"] = { 10.0, 10.0 };
    context.locations["/:M0_CAS"] = { 10.0, 14.0 };
    context.wires = {
        { "/", "M0_MID", { { 10.0, 11.0 }, { 10.0, 13.0 } } },
        { "/", "CTRL", { { 8.0, 10.0 }, { 10.0, 10.0 } } },
        { "/", "VSS", { { 10.0, 8.0 }, { 10.0, 9.0 } } },
        { "/", "OUT", { { 10.0, 15.0 }, { 10.0, 16.0 } } },
        { "/", "VBIAS", { { 8.0, 14.0 }, { 10.0, 14.0 } } },
    };
    context.preview = { "variant-1", "pset-1", "materializer-v1" };
    auto built = st::BuildOaMaterializationPlan(
        baseCircuit(), expectedCircuit(), deviceCatalog(), context);
    return built.plan;
}

class FakeSnapshotSource : public st::maau::SnapshotSource {
public:
    std::vector<std::string> calls;

    st::maau::HostStatus ReadCircuitDesignInfo(st::CellViewRef& design,
                                               std::string& techName) override
    {
        calls.push_back("CircuitDesignInfo");
        design = { "SRC", "ldo", "schematic", "/cds/source", "r1" };
        techName = "demo_pdk";
        return { true, {}, {}, {} };
    }

    st::maau::HostStatus ReadSchematicNetlist(st::Netlist& netlist) override
    {
        calls.push_back("schematic::Netlist");
        netlist = baseCircuit();
        return { true, {}, {}, {} };
    }

    st::maau::HostStatus ReadTechCatalog(st::DeviceCatalog& catalog) override
    {
        calls.push_back("Tech");
        catalog = deviceCatalog();
        return { true, {}, {}, {} };
    }
};

st::DeviceCatalog catalogFor(const std::string& pdkName,
                             const std::string& pdkVersion,
                             const std::string& master)
{
    auto descriptor = *deviceCatalog().Find("nmos");
    descriptor.master = master;
    descriptor.oa_library = pdkName;
    descriptor.oa_cell = master;
    descriptor.pdk_name = pdkName;
    descriptor.pdk_version = pdkVersion;
    st::DeviceCatalog result;
    st::Diagnostic diagnostic;
    result.Add(descriptor, diagnostic);
    return result;
}

class FakeCurrentDutTechSource : public st::maau::CurrentDutTechSource {
public:
    std::vector<st::CellViewRef> requests;

    bool IsVerifiedPdkDeviceCell(
        const st::CellViewRef&,
        const st::DeviceDescriptor& descriptor) const override
    {
        return descriptor.oa_library == "PDK_A" ||
               descriptor.oa_library == "PDK_B";
    }

    st::maau::HostStatus ReadCurrentDutTechCatalog(
        const st::CellViewRef& dut,
        st::DeviceCatalog& catalog,
        std::string& pdkName,
        std::string& pdkVersion) override
    {
        requests.push_back(dut);
        if (dut.library == "DUT_A") {
            pdkName = "PDK_A";
            pdkVersion = "A1";
            catalog = catalogFor(pdkName, pdkVersion, "nmos_a");
            return {true, {}, {}, {}};
        }
        if (dut.library == "DUT_B") {
            pdkName = "PDK_B";
            pdkVersion = "B2";
            catalog = catalogFor(pdkName, pdkVersion, "nmos_b");
            return {true, {}, {}, {}};
        }
        if (dut.library == "DUT_MIXED") {
            pdkName = "PDK_A";
            pdkVersion = "A1";
            catalog = catalogFor(pdkName, pdkVersion, "nmos_a");
            auto foreign = *catalogFor("PDK_B", "B2", "nmos_b").Find("nmos_b");
            st::Diagnostic diagnostic;
            catalog.Add(foreign, diagnostic);
            return {true, {}, {}, {}};
        }
        if (dut.library == "DUT_USER") {
            pdkName = "PDK_A";
            pdkVersion = "A1";
            catalog = catalogFor(pdkName, pdkVersion, "user_mos");
            auto descriptor = *catalog.Find("user_mos");
            descriptor.oa_library = "DUT_USER";
            catalog = {};
            st::Diagnostic diagnostic;
            catalog.Add(descriptor, diagnostic);
            return {true, {}, {}, {}};
        }
        if (dut.library == "DUT_GENERATED") {
            pdkName = "PDK_A";
            pdkVersion = "A1";
            catalog = catalogFor(pdkName, pdkVersion, "generated_mos");
            auto descriptor = *catalog.Find("generated_mos");
            descriptor.oa_library = "DERIVED";
            catalog = {};
            st::Diagnostic diagnostic;
            catalog.Add(descriptor, diagnostic);
            return {true, {}, {}, {}};
        }
        return {false, "unknown DUT", {}, {}};
    }
};

class FakeMaterializationHost : public st::maau::MaterializationHost {
public:
    std::vector<std::string> calls;
    std::string failAt;
    st::Netlist roundTrip = expectedCircuit();
    st::Netlist sourceAfter = baseCircuit();

    st::maau::HostStatus CopyCircuits(
        const std::vector<st::OaCloneMapping>& cloneMap) override
    {
        calls.push_back("CircuitCopyer");
        if (cloneMap.empty()) return { false, "empty clone map", {}, {} };
        for (const auto& mapping : cloneMap) {
            if (mapping.source == mapping.target) {
                return { false, "source equals target", {}, {} };
            }
        }
        return status("CircuitCopyer");
    }

    st::maau::HostStatus WritePlanFile(const std::string&, const std::string& json) override
    {
        calls.push_back("WritePlanJson");
        if (json.find("topology_hash") == std::string::npos) {
            return { false, "missing hash", {}, {} };
        }
        return status("WritePlanJson");
    }

    st::maau::HostStatus ExecuteSkill(const std::string&, const std::string&,
                                      const std::string&) override
    {
        calls.push_back("SkillExecutor");
        auto result = status("SkillExecutor");
        result.log_path = "/work/MaauTopologyVariantMaterialize.log";
        return result;
    }

    st::maau::HostStatus RegenerateNetlist(const st::CellViewRef& target,
                                           const std::string&,
                                           st::Netlist& netlist) override
    {
        const bool source = target.library == "SRC";
        const std::string stage = source ? "NetlistCreatorSource" : "NetlistCreatorTarget";
        calls.push_back(stage);
        auto result = status(stage);
        if (result.ok) {
            netlist = source ? sourceAfter : roundTrip;
            result.artifact_path = source ? "/work/source_after.scs" : "/work/roundtrip.scs";
        }
        return result;
    }

    st::maau::HostStatus PublishCircuits(
        const std::vector<st::OaCloneMapping>& publishMap) override
    {
        calls.push_back("PublishCircuit");
        if (publishMap.empty()) return { false, "empty publish map", {}, {} };
        return status("PublishCircuit");
    }

private:
    st::maau::HostStatus status(const std::string& stage) const
    {
        if (stage == failAt) return { false, stage + " failed", "/work/failure.log", {} };
        return { true, {}, {}, {} };
    }
};

class FakeOpSimulationHost : public st::maau::OpSimulationHost {
public:
    std::vector<std::string> calls;
    std::string failAt;
    int spectreExitCode = 0;
    st::CellViewRef dut;
    st::CellViewRef bench;
    std::string corner;
    std::filesystem::path simulationDirectory;
    bool benchMissing = false;
    bool includeResistor = false;

    int ValidateBench(const st::CellViewRef& requestedBench,
                      std::string& message) override
    {
        calls.push_back("ValidateBench");
        bench = requestedBench;
        if (benchMissing) {
            message = "Bench does not exist";
            return 64;
        }
        if (failAt == "ValidateBench") {
            message = "Bench validation infrastructure failed";
            return 70;
        }
        return 0;
    }

    st::maau::HostStatus RebindDutInTemporaryCase(
        const st::CellViewRef& requestedDut,
        const st::CellViewRef& requestedBench,
        const std::filesystem::path& requestedSimulationDirectory) override
    {
        calls.push_back("RebindDut");
        dut = requestedDut;
        bench = requestedBench;
        simulationDirectory = requestedSimulationDirectory;
        return status("RebindDut");
    }

    st::maau::HostStatus PreserveBenchEnvironment(
        const st::CellViewRef&, const std::string& requestedCorner) override
    {
        calls.push_back("PreserveBenchEnvironment");
        corner = requestedCorner;
        return status("PreserveBenchEnvironment");
    }

    st::maau::HostStatus RequestDcOpAndOppoint() override
    {
        calls.push_back("RequestDcOpAndOppoint");
        return status("RequestDcOpAndOppoint");
    }

    int RunSpectre(const std::filesystem::path& requestedSimulationDirectory,
                   std::string& message) override
    {
        calls.push_back("RunSpectre");
        simulationDirectory = requestedSimulationDirectory;
        if (spectreExitCode != 0) message = "fake Spectre failure";
        return spectreExitCode;
    }

    st::maau::HostStatus ExtractOperatingPoint(
        st::OperatingPointSnapshot& snapshot) override
    {
        calls.push_back("ExtractOperatingPoint");
        const auto result = status("ExtractOperatingPoint");
        if (!result.ok) return result;
        snapshot.identity = {"dut-hash", "bench-hash", "pdk-1", corner,
                             "topology-a", "parameters-a", "solver-1"};
        snapshot.total_supply_current = 0.001;
        snapshot.mos["M0"] = {1.2, 0.8, 0.0, 0.0, 0.0001,
                               0.8, 1.2, 0.0, 0.3, 0.2, 1e-13};
        if (includeResistor) {
            snapshot.resistors["R_REF_N"] = {"pdk_r", "w=2u", 1.2, 0.2,
                1e-4, 1.5, 2e-4, 0.0, "pdk/tt_25c"};
        }
        return result;
    }

private:
    st::maau::HostStatus status(const std::string& stage) const
    {
        if (stage == failAt) return {false, stage + " failed", {}, {}};
        return {true, {}, {}, {}};
    }
};

} // namespace

int main()
{
    const auto opRoot = std::filesystem::temp_directory_path() /
        "st_maau_op_contract_test";
    std::filesystem::remove_all(opRoot);
    std::filesystem::create_directories(opRoot);
    st::maau::OpSimulationRequest opRequest;
    opRequest.dut = {"DERIVED", "core__TV0001", "schematic", "/work/dut", "r2"};
    opRequest.bench = {"BENCH", "tb_core", "schematic", "/work/bench", "r7"};
    opRequest.corner = "tt_25c";
    opRequest.requested_identity = {"dut-hash", "bench-hash", "pdk-1",
                                    "tt_25c", "topology-a", "parameters-a",
                                    "solver-1"};
    opRequest.identity_output = opRoot / "identity.tsv";
    opRequest.mos_output = opRoot / "mos.tsv";
    opRequest.simulation_directory = opRoot / "raw-simulation";
    FakeOpSimulationHost opHost;
    st::maau::MaauOpSimulationProvider opProvider;
    const auto opResult = opProvider.Run(opRequest, opHost);
    CHECK(opResult.ok && opResult.exit_code == 0 &&
          opResult.simulation_directory == opRequest.simulation_directory,
          "Maau OP provider成功时返回并保留原始仿真目录");
    CHECK(opHost.calls == std::vector<std::string>({
              "ValidateBench", "RebindDut", "PreserveBenchEnvironment",
              "RequestDcOpAndOppoint", "RunSpectre", "ExtractOperatingPoint"}),
          "Maau OP provider以固定顺序执行重绑定、保留环境、"
          "dcOp/oppoint、仿真和提取");
    CHECK(opHost.dut == opRequest.dut && opHost.bench == opRequest.bench &&
          opHost.corner == "tt_25c" &&
          opHost.simulationDirectory == opRequest.simulation_directory,
          "Fake host收到完整DUT、Bench、Corner和原始仿真目录");
    st::OperatingPointSnapshot loadedOp;
    std::vector<st::Diagnostic> opDiagnostics;
    CHECK(st::LoadOperatingPointTsv(opRequest.identity_output, opRequest.mos_output,
                                    loadedOp, opDiagnostics) &&
          loadedOp.identity.corner == "tt_25c" && loadedOp.mos.count("M0") == 1,
          "Maau OP provider写出核心loader可解析的标准TSV");

    FakeOpSimulationHost baselineWithResistorHost;
    baselineWithResistorHost.includeResistor = true;
    CHECK(opProvider.Run(opRequest, baselineWithResistorHost).ok,
          "基线两文件OP允许宿主提取额外电阻数据而不强制输出第三文件");

    opRequest.resistor_output = opRoot / "resistor.tsv";
    FakeOpSimulationHost resistorHost;
    resistorHost.includeResistor = true;
    CHECK(opProvider.Run(opRequest, resistorHost).ok &&
          st::LoadOperatingPointTsv(opRequest.identity_output,
                                    opRequest.mos_output,
                                    opRequest.resistor_output,
                                    loadedOp, opDiagnostics) &&
          loadedOp.resistors.count("R_REF_N") == 1,
          "Maau OP provider能输出实际电阻端电位、电流和PDK额定值");
    opRequest.resistor_output.clear();

    FakeOpSimulationHost missingBenchHost;
    missingBenchHost.benchMissing = true;
    const auto missingBench = opProvider.Run(opRequest, missingBenchHost);
    CHECK(!missingBench.ok && missingBench.exit_code == 64,
          "字段完整但实际Bench不存在时返64");

    FakeOpSimulationHost benchValidationFailureHost;
    benchValidationFailureHost.failAt = "ValidateBench";
    const auto benchValidationFailure = opProvider.Run(
        opRequest, benchValidationFailureHost);
    CHECK(!benchValidationFailure.ok &&
          benchValidationFailure.exit_code == 70,
          "Bench解析基础设施失败而非Bench不存在时返70");

    FakeOpSimulationHost configurationFailureHost;
    configurationFailureHost.failAt = "PreserveBenchEnvironment";
    const auto configurationFailure = opProvider.Run(opRequest,
                                                       configurationFailureHost);
    CHECK(!configurationFailure.ok && configurationFailure.exit_code == 70,
          "Bench存在但配置失败时返70");

    FakeOpSimulationHost launchFailureHost;
    launchFailureHost.spectreExitCode = 70;
    const auto launchFailure = opProvider.Run(opRequest, launchFailureHost);
    CHECK(!launchFailure.ok && launchFailure.exit_code == 70 &&
          launchFailure.simulation_directory == opRequest.simulation_directory,
          "Spectre启动失败返回70并保留仿真目录");
    FakeOpSimulationHost convergenceFailureHost;
    convergenceFailureHost.spectreExitCode = 71;
    const auto convergenceFailure = opProvider.Run(opRequest, convergenceFailureHost);
    CHECK(!convergenceFailure.ok && convergenceFailure.exit_code == 71,
          "Spectre不收敛返回71");
    FakeOpSimulationHost extractFailureHost;
    extractFailureHost.failAt = "ExtractOperatingPoint";
    const auto extractFailure = opProvider.Run(opRequest, extractFailureHost);
    CHECK(!extractFailure.ok && extractFailure.exit_code == 74,
          "dcOp结果提取失败返回74");

    std::vector<std::string> cliArguments = {
        "st_maau_op_provider",
        "--dut-lib", "DERIVED", "--dut-cell", "core__TV0001",
        "--dut-view", "schematic", "--bench-lib", "BENCH",
        "--bench-cell", "tb_core", "--bench-view", "schematic",
        "--corner", "tt_25c",
        "--dut-hash", "dut-hash", "--bench-hash", "bench-hash",
        "--pdk-version", "pdk-1", "--topology-hash", "topology-a",
        "--parameter-hash", "parameters-a", "--solver-version", "solver-1",
        "--identity-output", (opRoot / "cli-identity.tsv").string(), "--mos-output",
        (opRoot / "cli-mos.tsv").string(), "--simulation-dir",
        (opRoot / "cli-raw").string(),
    };
    std::vector<char*> cliArgv;
    for (auto& argument : cliArguments) cliArgv.push_back(argument.data());
    FakeOpSimulationHost cliHost;
    std::ostringstream cliOut;
    std::ostringstream cliErr;
    CHECK(st::maau::RunMaauOpProviderCli(
              static_cast<int>(cliArgv.size()), cliArgv.data(), cliHost,
              cliOut, cliErr) == 0 && cliHost.calls.size() == 6,
          "st_maau_op_provider真实解析参数并调用可注入宿主");
    cliArguments.pop_back();
    cliArguments.pop_back();
    cliArgv.clear();
    for (auto& argument : cliArguments) cliArgv.push_back(argument.data());
    FakeOpSimulationHost incompleteCliHost;
    cliErr.str({});
    cliErr.clear();
    CHECK(st::maau::RunMaauOpProviderCli(
              static_cast<int>(cliArgv.size()), cliArgv.data(), incompleteCliHost,
              cliOut, cliErr) == 64 && incompleteCliHost.calls.empty(),
          "st_maau_op_provider在调用宿主前拒绝缺失必填参数");

    FakeCurrentDutTechSource techSource;
    st::maau::TechCatalogProvider techProvider;
    const auto scanA = techProvider.ScanCurrentDut(
        {"DUT_A", "core", "schematic", {}, "r1"}, techSource);
    const auto scanB = techProvider.ScanCurrentDut(
        {"DUT_B", "core", "schematic", {}, "r2"}, techSource);
    const auto mixedScan = techProvider.ScanCurrentDut(
        {"DUT_MIXED", "core", "schematic", {}, "r3"}, techSource);
    const auto userLibraryScan = techProvider.ScanCurrentDut(
        {"DUT_USER", "core", "schematic", {}, "r4"}, techSource);
    const auto generatedLibraryScan = techProvider.ScanCurrentDut(
        {"DUT_GENERATED", "core", "schematic", {}, "r5"}, techSource);
    CHECK(scanA.ok && scanA.pdk_name == "PDK_A" && scanA.pdk_version == "A1" &&
          scanA.catalog.Find("nmos_a") != nullptr &&
          scanA.catalog.Find("nmos_b") == nullptr,
          "Maau provider只返回当前DUT A绑定的PDK目录");
    CHECK(scanB.ok && scanB.pdk_name == "PDK_B" && scanB.pdk_version == "B2" &&
          scanB.catalog.Find("nmos_b") != nullptr &&
          scanB.catalog.Find("nmos_a") == nullptr &&
          techSource.requests.size() == 5 &&
          techSource.requests[0].library == "DUT_A" &&
          techSource.requests[1].library == "DUT_B" &&
          techSource.requests[2].library == "DUT_MIXED" &&
          techSource.requests[3].library == "DUT_USER" &&
          techSource.requests[4].library == "DUT_GENERATED",
          "切换当前DUT时provider按DUT身份隔离两个PDK");
    CHECK(!mixedScan.ok && mixedScan.message.find("does not belong") != std::string::npos,
          "Maau provider拒绝当前DUT目录混入另一tech identity记录");
    CHECK(!userLibraryScan.ok &&
          userLibraryScan.message.find("not a verified PDK primitive") != std::string::npos,
          "Maau provider拒绝same-tech用户library记录冒充PDK primitive");
    CHECK(!generatedLibraryScan.ok &&
          generatedLibraryScan.message.find("not a verified PDK primitive") != std::string::npos,
          "Maau provider拒绝same-tech生成library记录冒充PDK primitive");

    FakeSnapshotSource source;
    st::maau::TopologyVariantAdapter adapter;
    auto snapshot = adapter.BuildSnapshot(source);
    CHECK(snapshot.ok && snapshot.snapshot.source.cell == "ldo" &&
            snapshot.snapshot.tech_name == "demo_pdk",
        "适配器从CircuitDesignInfo、网表和Tech构建设计快照");
    CHECK(source.calls == std::vector<std::string>({
            "CircuitDesignInfo", "schematic::Netlist", "Tech" }),
        "BuildSnapshot调用顺序固定且边界可替换");

    st::maau::GenerationRequest request;
    request.plan = oaPlan();
    request.baseline = baseCircuit();
    request.expected_variant = expectedCircuit();
    request.root_subckt = "core";
    request.work_dir = "/work/variant-1";
    request.plan_path = "/work/variant-1/plan.json";
    request.skill_script_path = "/opt/maau/topology_variant.il";
    request.publish_clone_map.push_back({ request.plan.target,
        { "DST", "ldo__variant", "schematic", "/work/published", "r1" }, "/" });
    request.parameter_groups["M0_CASCODE_SIZE"] = { "M0", "M0_CAS" };
    request.iq_delta = 5e-6;

    FakeMaterializationHost host;
    st::maau::TopologyVariantMaterializer materializer;
    auto generated = materializer.Generate(request, host);
    CHECK(generated.ok && !generated.ready_for_sizing &&
            generated.stage == st::maau::MaterializationStage::Complete,
        "完整round-trip通过但未请求真实DC时不冒充ready_for_sizing");
    CHECK(host.calls == std::vector<std::string>({
            "CircuitCopyer", "WritePlanJson", "SkillExecutor",
            "NetlistCreatorSource", "NetlistCreatorTarget", "PublishCircuit" }),
        "Maau先验证源图和staging回读，最后才发布最终变体");
    CHECK(generated.netlist_path == "/work/roundtrip.scs" &&
            generated.log_path == "/work/MaauTopologyVariantMaterialize.log" &&
            generated.source_netlist_path == "/work/source_after.scs" &&
            generated.iq_delta == 5e-6 && !generated.topology_hash.empty(),
        "交接结果包含网表、日志、IQ、参数组和Topology hash");

    FakeMaterializationHost skillFailureHost;
    skillFailureHost.failAt = "SkillExecutor";
    auto failed = materializer.Generate(request, skillFailureHost);
    CHECK(!failed.ok && !failed.ready_for_sizing &&
            failed.stage == st::maau::MaterializationStage::ExecuteSkill,
        "SKILL失败时返回准确阶段且不能进入Sizing");
    CHECK(skillFailureHost.calls == std::vector<std::string>({
            "CircuitCopyer", "WritePlanJson", "SkillExecutor" }),
        "失败后不继续重新网表化或伪造成功");

    FakeMaterializationHost sourceMutationHost;
    sourceMutationHost.sourceAfter.find("core")->find("M0")->nets[0] = "CORRUPTED";
    auto sourceMutation = materializer.Generate(request, sourceMutationHost);
    CHECK(!sourceMutation.ok &&
            sourceMutation.stage == st::maau::MaterializationStage::VerifySource &&
            sourceMutationHost.calls.back() == "NetlistCreatorSource",
        "源图网表在SKILL后有任何变化都不发布staging结果");

    FakeMaterializationHost mismatchHost;
    mismatchHost.roundTrip.find("core")->find("M0_CAS")->nets[1] = "WRONG";
    auto mismatch = materializer.Generate(request, mismatchHost);
    CHECK(!mismatch.ok && !mismatch.ready_for_sizing &&
            mismatch.stage == st::maau::MaterializationStage::VerifyRoundTrip,
        "OA结果连接不一致时停在round-trip验证阶段");

    auto unsafeRequest = request;
    unsafeRequest.plan.target = unsafeRequest.plan.source;
    FakeMaterializationHost unsafeHost;
    auto unsafe = materializer.Generate(unsafeRequest, unsafeHost);
    CHECK(!unsafe.ok && unsafe.stage == st::maau::MaterializationStage::ValidatePlan &&
            unsafeHost.calls.empty(),
        "目标指向源图时在调用CircuitCopyer前拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Maau contract tests passed\n";
    } else {
        std::cout << failures << " Maau contract tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
