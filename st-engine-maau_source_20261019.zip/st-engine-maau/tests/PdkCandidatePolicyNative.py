"""Run candidate failure isolation against current SKILL and actual OA/CDF."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import read_json, verify_site_inputs
from standalone import environment

CONFLICT = re.compile(r'\*Error\* (?:Unproven CDF Spectre termOrder|CDF Spectre termOrder/symbol terminal conflict) for ([^/\s;]+)/([^\s;]+)')
STATUS = 'OK cases=4 actual=true'
ACTION = r'''load(getShellEnvVar("ST_SKILL_INIT"))
load(__COMMON__)
load(__TECH__)
load(__ADAPTER__)
load(__POLICY__)
stScanSkippedLibraries=nil
let((result entry valid requiredDescription candidateDescription port expectedSkip)
  ; The same strict reader must reject this actual inconsistent OA master.
  result=errset(stScanDescribeDevice(__BAD_LIB__ __BAD_CELL__ "symbol" t) nil)
  when(result error("CANDIDATE_POLICY_FAILED invalid required master accepted"))
  unless(not(stScanSkippedLibraries)
    error("CANDIDATE_POLICY_FAILED required error was recorded as optional"))
  printf("CANDIDATE_POLICY_CASE_OK required_invalid_rejected\n")
  result=errset(stScanDescribeDevice(__BAD_LIB__ __BAD_CELL__ "symbol" nil) t)
  expectedSkip=strcat(__BAD_LIB__ ":description_error:" __BAD_CELL__)
  unless(and(result not(car(result)) member(expectedSkip stScanSkippedLibraries))
    error("CANDIDATE_POLICY_FAILED invalid candidate was accepted or aborted result=%L" result))
  printf("CANDIDATE_POLICY_CASE_OK optional_invalid_excluded\n")
  ; Find a real positive control from the session's declared MOS masters.
  foreach(entry __GOOD_MASTERS__
    unless(valid
      result=errset(stScanDescribeDevice(car(entry) cadr(entry) "symbol" t) nil)
      when(and(result car(result))
        valid=entry
        requiredDescription=car(result)))
  )
  unless(valid error("CANDIDATE_POLICY_FAILED no actual valid MOS positive control"))
  printf("CANDIDATE_POLICY_CASE_OK required_valid master=%L/%L\n" car(valid) cadr(valid))
  candidateDescription=stScanDescribeDevice(car(valid) cadr(valid) "symbol" nil)
  unless(and(candidateDescription
      equal(stTechGet(candidateDescription "terminalNames") stTechGet(requiredDescription "terminalNames"))
      equal(stTechGet(candidateDescription "kind") stTechGet(requiredDescription "kind")))
    error("CANDIDATE_POLICY_FAILED valid candidate lost its actual description"))
  printf("CANDIDATE_POLICY_CASE_OK optional_valid master=%L/%L\n" car(valid) cadr(valid))
  port=outfile(getShellEnvVar("ST_CANDIDATE_POLICY_STATUS"))
  unless(port error("Cannot create native candidate policy status"))
  fprintf(port "OK cases=4 actual=true\n")
  close(port)
)
exit()
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    session, work = Path(args.session).resolve(), Path(args.work_dir).expanduser()
    if not work.is_absolute():
        raise ValueError('--work-dir requires a new absolute directory')
    manifest = session / 'analysis/standalone_inputs/provider_inputs.json'
    inputs = read_json(manifest)
    verify_site_inputs(inputs)
    context = read_json(inputs['context'])
    cds = Path(context['source_cds_path']) / 'cds.lib'
    if not cds.is_absolute() or not cds.is_file():
        raise ValueError('session source cds.lib is missing')
    log = session / 'logs/scan_pdk.log'
    masters = sorted(set(CONFLICT.findall(log.read_text(encoding='utf-8', errors='replace'))))
    if len(masters) != 1:
        raise ValueError('need exactly one actual terminal conflict master in scan_pdk.log')
    bad = masters[0]
    configs = read_json(inputs['tech'])
    declared = {(d['oa_library'], d['cell']) for config in configs for d in config['devices']}
    if bad not in declared:
        raise ValueError('failed master is absent from the actual session metadata')
    good = sorted({(d['oa_library'], d['cell']) for config in configs for d in config['devices']
                   if d['kind'] in ('mos', 'mos_n', 'mos_p')} - {bad})
    if not good:
        raise ValueError('actual session has no MOS positive control candidates')
    policy = ROOT / 'server/skill/scan_device_policy.il'
    if not policy.is_file():
        raise ValueError('current production candidate policy is missing: ' + str(policy))
    replacements = {'__COMMON__': str(ROOT / 'server/skill/backend_common.il'),
        '__TECH__': str(ROOT / 'server/skill/tech_adapter.il'), '__ADAPTER__': inputs['adapter'],
        '__POLICY__': str(policy), '__BAD_LIB__': bad[0], '__BAD_CELL__': bad[1]}
    action_text = ACTION
    for token, value in replacements.items():
        action_text = action_text.replace(token, json.dumps(value, ensure_ascii=False))
    literal = 'list(' + ' '.join('list(' + json.dumps(lib, ensure_ascii=False) + ' ' +
        json.dumps(cell, ensure_ascii=False) + ')' for lib, cell in good) + ')'
    action_text = action_text.replace('__GOOD_MASTERS__', literal)
    work.mkdir(parents=True, exist_ok=False)
    action = work / 'candidate_policy_check.il'
    action.write_text(action_text, encoding='utf-8')
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return 0
    executable = shutil.which(os.environ.get('ST_VIRTUOSO_BIN') or 'virtuoso')
    if not executable:
        raise ValueError('Virtuoso executable unavailable; retained ' + str(work))
    env = environment(inputs, manifest)
    env.pop('ST_PREPARED_JSON_FILE', None)
    for field in ('lib', 'cell', 'view'):
        env['ST_REQ_' + field.upper()] = context['source_dut'][field]
    status = work / 'status.txt'
    env['ST_CANDIDATE_POLICY_STATUS'] = str(status)
    native_log, launcher = work / 'virtuoso.log', work / 'launcher.log'
    with launcher.open('x', encoding='utf-8') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action), '-log', str(native_log)],
            cwd=str(cds.parent), env=env, stdout=stream, stderr=subprocess.STDOUT)
    valid = status.is_file() and status.read_text().strip() == STATUS
    if result.returncode or not valid:
        for file in (launcher, native_log):
            if file.is_file():
                print(file.read_text(encoding='utf-8', errors='replace'))
        print('STOP: native candidate policy check failed; retain ' + str(work))
        return result.returncode if 0 < result.returncode < 126 else 70
    if native_log.is_file():
        print('\n'.join(native_log.read_text(encoding='utf-8', errors='replace').splitlines()[-60:]))
    print('CANDIDATE_POLICY_NATIVE_OK cases=4 actual_master=' + '/'.join(bad))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print('STOP: ' + str(error), file=sys.stderr)
        sys.exit(2)
