#include "st/Naming.h"
#include "st/Transaction.h"

#include <iostream>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::Netlist makeCircuit()
{
    st::Netlist netlist;
    st::Subckt subckt;
    subckt.name = "core";
    subckt.pins = { "OUT", "IN", "VSS" };
    subckt.instances.push_back({ "M0", { "OUT", "IN", "VSS", "VSS" }, "nmos", {} });
    subckt.instances.push_back({ "M0_CAS", { "OUT", "IN", "VSS", "VSS" }, "nmos", {} });
    subckt.instances.push_back({ "M0_CAS_2", { "M0_MID", "IN", "VSS", "VSS" }, "nmos", {} });
    netlist.subckts.push_back(subckt);
    return netlist;
}

} // namespace

int main()
{
    const auto original = makeCircuit();

    st::NameAllocator allocator(original);
    CHECK(allocator.Allocate(st::NameKind::Instance, "M0_CAS") == "M0_CAS_3",
        "实例名冲突时从稳定的最小可用后缀继续");
    CHECK(allocator.Allocate(st::NameKind::Instance, "M0_CAS") == "M0_CAS_4",
        "同一轮连续分配不会产生重复实例名");
    CHECK(allocator.Allocate(st::NameKind::Net, "M0_MID") == "M0_MID_2",
        "网络名与已有网络冲突时稳定避让");
    CHECK(allocator.Allocate(st::NameKind::Subckt, "core") == "core_2",
        "新建辅助 subckt 不覆盖原 subckt");

    st::NameAllocator allocatorAgain(original);
    CHECK(allocatorAgain.Allocate(st::NameKind::Instance, "M0_CAS") == "M0_CAS_3",
        "相同输入和相同操作顺序产生相同名字");

    st::Netlist rollbackTarget = original;
    const std::string beforeRollback = st::emitSpectre(rollbackTarget);
    {
        st::NetlistTransaction transaction(rollbackTarget);
        transaction.Working().find("core")->instances.clear();
        // 模拟后续校验失败：不调用 Commit。
    }
    CHECK(st::emitSpectre(rollbackTarget) == beforeRollback,
        "未提交事务析构后原网表完全不变");

    st::Netlist commitTarget = original;
    {
        st::NetlistTransaction transaction(commitTarget);
        transaction.Working().find("core")->instances.back().name = "M_RENAMED";
        transaction.Commit();
    }
    CHECK(commitTarget.find("core")->find("M_RENAMED") != nullptr,
        "Commit 后一次性替换调用方结果");
    CHECK(commitTarget.find("core")->find("M0_CAS_2") == nullptr,
        "提交结果不保留被事务修改掉的旧实例");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Naming/transaction tests passed\n";
    } else {
        std::cout << failures << " naming/transaction tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
