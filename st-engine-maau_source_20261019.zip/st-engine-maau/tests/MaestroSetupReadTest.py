"""Test read-only reader dispatch and report gates; no native Cadence API is simulated."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import pin_site_inputs, write_json

ENTRY = ROOT / 'server/site/read_maestro_setup.py'
MARKER = 'ST_MAESTRO_SETUP_READ_COMPLETE'


def row(kind, scope, name, value, status='OK'):
    return '\t'.join(['ST_MAE_RECORD', kind, json.dumps(scope), json.dumps(name), status, value]) + '\n'


class MaestroSetupReadTest(unittest.TestCase):
    def fixture(self, base, extra='', exit_code=0, marker=True):
        session = base / 'source session'
        archive = session / 'analysis/standalone_inputs'; archive.mkdir(parents=True)
        cds = base / 'cadence/cds.lib'; cds.parent.mkdir(); cds.write_text('; fixture\n')
        (session / 'session.conf').write_text('cds_lib=' + str(cds) + '\nvalidation_scope=structure_only\n')
        paths = {key: str(archive / (key + '.json')) for key in ('context', 'rules', 'tech', 'adapter', 'runtime', 'init')}
        for key, path in paths.items():
            write_json(path, {'validation_scope': 'structure_only'} if key == 'rules' else {})
        write_json(archive / 'provider_inputs.json', pin_site_inputs(paths))
        bench = base / 'repository/BENCHLIB'; bench.mkdir(parents=True)
        report = ''.join(row('meta', 'setup', key, json.dumps(value)) for key, value in {
            'library': 'BENCHLIB', 'cell': 'testbench', 'view': 'maestro_pvt_ea',
            'registered_library_path': str(bench)}.items())
        report += row('test', 'saved_dc', 'test_name', '"saved_dc"')
        for name, value in [('design_library', 'BENCHLIB'), ('design_cell', 'testbench'), ('design_view', 'config_presim')]:
            report += row('test', 'saved_dc', name, json.dumps(value))
        report += row('test', 'saved_dc', 'models', '(("/pdk/model.scs" "tt"))')
        report += row('global_variable', 'setup', 'AVDD', '"1.8"')
        report += row('corner_variable', 'TT', 'temperature', '"27"')
        report += row('corner', 'TT', 'enabled', 't')
        report += extra + (MARKER + '\n' if marker else '')
        fake = base / 'external Cadence process'
        fake.write_text('#!' + sys.executable + '\nimport os\nfrom pathlib import Path\n'
                        'Path(os.environ["ST_MAESTRO_REPORT"]).write_text(' + repr(report) + ')\n'
                        'print("PRIVATE_RAW_LAUNCHER_LOG")\n'
                        'p=os.environ.get("ST_TEST_MUTATE_INPUT")\n'
                        'if p: Path(p).write_text("changed")\n'
                        'raise SystemExit(' + str(exit_code) + ')\n')
        fake.chmod(0o755)
        env = dict(os.environ, ST_VIRTUOSO_BIN=str(fake))
        return session, bench, fake, env

    def run_entry(self, session, bench, output, env=None, extra=()):
        return subprocess.run([sys.executable, str(ENTRY), '--session', str(session),
            '--bench-lib', 'BENCHLIB', '--bench-cell', 'testbench', '--setup-view', 'maestro_pvt_ea',
            '--expected-library-path', str(bench), '--output', str(output)] + list(extra),
            capture_output=True, text=True, env=env)

    def test_prepare_does_not_claim_read_or_change_old_session(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base)
            original = (session / 'session.conf').read_bytes()
            result = self.run_entry(session, bench, base / 'evidence', env, ['--prepare-only'])
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('NATIVE_EXECUTION=false', result.stdout)
            self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)
            self.assertEqual((session / 'session.conf').read_bytes(), original)
            self.assertFalse((base / 'evidence/maestro_report.tsv').exists())

    def test_report_keeps_config_view_sweeps_and_no_profile_claim(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            extra = row('test_variable', 'saved_dc', 'ILOAD', '"1m 10m 200m"')
            session, bench, _, env = self.fixture(base, extra)
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('MAESTRO_SETUP_READ_OK', result.stdout)
            self.assertIn('config_presim', result.stdout)
            self.assertIn('1m 10m 200m', result.stdout)
            self.assertIn('SIMULATION_PROFILE_READY=false', result.stdout)
            self.assertNotIn('PRIVATE_RAW_LAUNCHER_LOG', result.stdout + result.stderr)
            data = json.loads((base / 'evidence/maestro_read.json').read_text())
            self.assertEqual(data['records'][-1]['raw_value'], '"1m 10m 200m"')
            self.assertFalse((session / 'simulation_profile.json').exists())

    def test_missing_marker_rejected_without_raw_log_export(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base, marker=False)
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertIn('RESULT=INCOMPLETE', result.stdout)
            self.assertNotIn('PRIVATE_RAW_LAUNCHER_LOG', result.stdout + result.stderr)

    def test_failed_process_rejected_even_with_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base, exit_code=7)
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertIn('NATIVE_EXIT_CODE=7', result.stdout)
            self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)

    def test_optional_api_error_is_partial_not_ready(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            session, bench, _, env = self.fixture(base, row('test', 'saved_dc', 'models', 'nil', 'READ_ERROR'))
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
            self.assertIn('RESULT=PARTIAL', result.stdout)
            self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)

    def test_registered_path_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base)
            other = base / 'other library'; other.mkdir()
            result = self.run_entry(session, other, base / 'evidence', env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertIn('registered library path differs', (base / 'evidence/status.json').read_text())

    def test_empty_tests_or_wrong_setup_are_rejected(self):
        for wrong_setup in (False, True):
            with self.subTest(wrong_setup=wrong_setup), tempfile.TemporaryDirectory() as directory:
                base = Path(directory); session, bench, fake, env = self.fixture(base)
                body = ''.join(row('meta', 'setup', key, json.dumps(value)) for key, value in {
                    'library': 'OTHER' if wrong_setup else 'BENCHLIB', 'cell': 'testbench',
                    'view': 'maestro_pvt_ea', 'registered_library_path': str(bench)}.items())
                fake.write_text('#!' + sys.executable + '\nimport os\nfrom pathlib import Path\n'
                    'Path(os.environ["ST_MAESTRO_REPORT"]).write_text(' + repr(body + MARKER + '\n') + ')\n')
                result = self.run_entry(session, bench, base / 'evidence', env)
                self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
                self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)

    def test_existing_output_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base)
            out = base / 'evidence'; out.mkdir(); (out / 'keep').write_text('original')
            result = self.run_entry(session, bench, out, env)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual((out / 'keep').read_text(), 'original')
            self.assertFalse((out / 'status.json').exists())

    def test_input_changes_before_or_during_read_are_rejected(self):
        for during in (False, True):
            with self.subTest(during=during), tempfile.TemporaryDirectory() as directory:
                base = Path(directory); session, bench, _, env = self.fixture(base)
                init = session / 'analysis/standalone_inputs/init.json'
                if during: env['ST_TEST_MUTATE_INPUT'] = str(init)
                else: init.write_text('changed')
                result = self.run_entry(session, bench, base / 'evidence', env)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)

    def test_summary_is_bounded_and_raw_values_remain_local(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            extra = ''.join(row('test_variable', 'saved_dc', 'v' + str(n), json.dumps('x' * 1000)) for n in range(400))
            session, bench, _, env = self.fixture(base, extra)
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertLessEqual(len(result.stdout.splitlines()), 190)
            self.assertIn('SUMMARY_TRUNCATED=true', result.stdout)
            data = json.loads((base / 'evidence/maestro_read.json').read_text())
            self.assertEqual(data['records'][-1]['raw_value'], json.dumps('x' * 1000))

    def test_malformed_report_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory); session, bench, _, env = self.fixture(base, 'unexpected report text\n')
            result = self.run_entry(session, bench, base / 'evidence', env)
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertNotIn('MAESTRO_SETUP_READ_OK', result.stdout)


if __name__ == '__main__':
    unittest.main()
