"""Read retained native export fixtures without launching tools or changing files."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts/inspect_cascode_ports.py'


class PortEvidenceTest(unittest.TestCase):
    def fixture(self, root, oa='VDD\nA<1:0>\nVSS\n', ports=r'VDD A\<1\> A\<0\> VSS'):
        candidate = root / 'candidate_I21_test'
        sim = candidate / 'work/analysis/baseline_op/raw_op/st-op-simulation.test'
        dut = sim / 'dut_oa'
        generated = dut / 'generated/dut/spectre/schematic/netlist/input.scs'
        generated.parent.mkdir(parents=True)
        generated.write_text('simulator lang=spectre\nM0 (A\\<1\\> A\\<0\\> VSS VSS) nmos\n')
        bench = sim / 'bench.scs'
        bench.write_text('simulator lang=spectre\nsubckt core ' + ports + '\nends core\n')
        (dut / 'ports.txt').write_text(oa)
        (dut / 'runtime.ocn').write_text('design("LIB" "core" "schematic")\n')
        (dut / 'runtime.done').write_text('OK\n')
        (sim / 'export_dut.log').write_text('Cascode Cadence runtime: actual OA DUT/Bench port mismatch\n')
        bundle = root / 'bundle.json';bundle.write_text(json.dumps({'source_subckt': 'core'}))
        profile = root / 'profile.json';profile.write_text(json.dumps({'validated_baseline_bundle': str(bundle)}))
        (candidate / 'inputs.json').write_text(json.dumps({'profile': str(profile)}))
        (candidate / 'run_status.json').write_text('{"result":"INCOMPLETE","failed_stage":"generate"}')
        pinned = candidate / 'work/analysis/standalone_inputs/provider_inputs.json'
        pinned.parent.mkdir(parents=True)
        pinned.write_text(json.dumps({'file_sha256': {
            str(ROOT / 'server/site' / f): hashlib.sha256((ROOT / 'server/site' / f).read_bytes()).hexdigest()
            for f in ('op_provider.py', 'cadence_runtime.py')}}))
        return candidate, sim

    def run_script(self, root):
        return subprocess.run([sys.executable, str(SCRIPT), '--engine', str(ROOT), '--batch', str(root)],
                              text=True, capture_output=True, timeout=10)

    def test_bus_evidence_is_exact_and_no_inputs_or_artifacts_are_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);self.fixture(root)
            before = {str(p): p.read_bytes() for p in root.rglob('*') if p.is_file()}
            result = self.run_script(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
            self.assertEqual(fields['RESULT'], 'PORT_EVIDENCE_READ_OK')
            self.assertEqual(json.loads(fields['OA_ONLY']), ['A<1:0>'])
            self.assertEqual(json.loads(fields['BENCH_ONLY']), [r'A\<0\>', r'A\<1\>'])
            self.assertEqual(fields['REPLAY_ERROR'], 'actual OA DUT/Bench port mismatch')
            self.assertEqual(fields['NATIVE_EXECUTIONS'], '0')
            self.assertEqual(fields['PARSER_MATCHES_SESSION'], 'true')
            self.assertEqual(before, {str(p): p.read_bytes() for p in root.rglob('*') if p.is_file()})

    def test_scalar_missing_and_order_only_are_distinguished_by_production_check(self):
        for oa, expected in [('VDD\nMISSING\nVSS\n', 'false'), ('VSS\nA\nVDD\n', 'true')]:
            with self.subTest(oa=oa), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp);self.fixture(root, oa, 'VDD A VSS')
                result = self.run_script(root)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('RAW_PORT_SET_MATCH=' + expected, result.stdout)
                self.assertIn('WRAP_REPLAY_PASSED=' + expected, result.stdout)

    def test_latest_incomplete_export_is_not_silently_replaced_by_older_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);candidate, sim = self.fixture(root)
            latest = sim.parent / 'st-op-simulation.new';latest.mkdir()
            log = latest / 'export_dut.log';log.write_text('native error before ports')
            os.utime(log, (sim.stat().st_mtime + 10, sim.stat().st_mtime + 10))
            result = self.run_script(root)
            self.assertEqual(result.returncode, 2)
            self.assertIn('st-op-simulation.new', result.stdout)
            self.assertIn('RESULT=INCOMPLETE', result.stdout)
            self.assertNotIn('RESULT=PORT_EVIDENCE_READ_OK', result.stdout)


if __name__ == '__main__': unittest.main()
