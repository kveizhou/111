"""Exercise environment setup in real csh with site aliases present."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


@unittest.skipUnless(shutil.which('csh'), 'csh is required for sourced setup tests')
class ServerSetupTest(unittest.TestCase):
    def setUp(self):
        self.project = Path(__file__).resolve().parents[1]
        self.temporary = tempfile.TemporaryDirectory(prefix='st-setup-test-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.tools = self.root / 'tools with spaces'
        self.tools.mkdir()
        self.tool_marker = self.root / 'tool-launched'
        for name in ('virtuoso', 'ocean', 'spectre'):
            path = self.tools / name
            path.write_text('#!/bin/sh\nprintf launched >> "$ST_TEST_TOOL_MARKER"\nexit 93\n')
            path.chmod(0o755)
        self.bad_lookup = self.root / 'site-which.csh'
        self.bad_lookup.write_text('echo ST_SITE_LOOKUP_ABORTED\nexit 1\n')
        self.ma_loader = self.root / 'site-ma.csh'
        self.ma_loader.write_text('echo "$argv" >> "$ST_TEST_MA_MARKER"\n'
                                  'set path = ( "$ST_TEST_TOOL_ROOT" $path )\n')
        self.env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
        self.env.update(ST_TEST_PROJECT=str(self.project),
                        ST_TEST_SETUP_FILE=str(self.project / 'server/setup_backend.csh'),
                        ST_TEST_WHICH_HELPER=str(self.bad_lookup),
                        ST_TEST_MA_LOADER=str(self.ma_loader),
                        ST_TEST_MA_MARKER=str(self.root / 'ma-calls'),
                        ST_TEST_TOOL_ROOT=str(self.tools),
                        ST_TEST_TOOL_MARKER=str(self.tool_marker),
                        PATH='/bin:/usr/bin')

    def run_setup(self, before=''):
        script = ("alias which 'source \"$ST_TEST_WHICH_HELPER\" \\!*'\n" + before +
                  'source "$ST_TEST_SETUP_FILE" "$ST_TEST_PROJECT"\n'
                  'set st_result = $status\n'
                  'echo ST_SETUP_STATUS=$st_result\n'
                  'printenv ST_SKILL_INIT\n'
                  'printenv ST_OP_PROVIDER_BIN\n'
                  'alias which\n')
        result = subprocess.run([shutil.which('csh'), '-f'], input=script, text=True,
                                env=self.env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=20)
        return result

    def assert_ready(self, result):
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('ST_SETUP_STATUS=0', result.stdout)
        self.assertIn('st-engine-maau backend environment ready', result.stdout)
        self.assertIn(str(self.project / 'server/skill/init.il'), result.stdout)
        self.assertIn(str(self.project / 'server/site/op_provider.py'), result.stdout)
        self.assertNotIn('ST_SITE_LOOKUP_ABORTED', result.stdout)
        self.assertIn('$ST_TEST_WHICH_HELPER', result.stdout)
        self.assertFalse(self.tool_marker.exists(), 'setup must not launch Cadence tools')

    def test_path_tools_configure_environment_without_invoking_site_which_alias(self):
        self.env['PATH'] = str(self.tools) + ':/bin:/usr/bin'
        self.assert_ready(self.run_setup())
        self.assertFalse((self.root / 'ma-calls').exists())

    def test_alias_only_ma_can_load_tools_without_invoking_site_which_alias(self):
        result = self.run_setup("alias ma 'source \"$ST_TEST_MA_LOADER\" \\!*'\n")
        self.assert_ready(result)
        self.assertEqual((self.root / 'ma-calls').read_text().splitlines(),
                         ['icadv/18.1isr3', 'spectre/18.1isr6'])

    def test_missing_tools_report_incomplete_without_invoking_site_which_alias(self):
        result = self.run_setup()
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('backend variables set, but Cadence/SKILL environment is incomplete', result.stdout)
        self.assertNotIn('backend environment ready', result.stdout)
        self.assertNotIn('ST_SITE_LOOKUP_ABORTED', result.stdout)
        self.assertIn(str(self.project / 'server/skill/init.il'), result.stdout)


if __name__ == '__main__':
    unittest.main()
