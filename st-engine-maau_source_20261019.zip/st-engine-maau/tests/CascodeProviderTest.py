"""Formal candidate contracts; native subprocesses remain fixture boundaries."""
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace

SITE=Path(__file__).resolve().parents[1]/'server/site'
sys.path.insert(0,str(SITE))


class CascodeProviderTest(unittest.TestCase):
    def test_escaped_array_query_consumer_cmg_sources_and_mos_values_agree(self):
        import op_provider as op
        from dc_results import canonical_device,consume_query
        mapping=dict(id='id',vth='vth',vdsat='vdssat',cgg='cgg',intrinsic_vgs='vgs',intrinsic_vds='vds')
        path=r'X.I93\<5\>.I2.M0';key=canonical_device(path+'.M')
        device=dict(path=path,signal_path=key,nodes=['D',r'G\<0\>','S','B'])
        catalog=dict(kind='mos_n',terminal_roles=['drain','gate','source','bulk'])
        dev=dict(signal_postfix='.M',dc_signals=mapping,electrical_rules={})
        physical=[(device,catalog,dev)]
        query=op.build_dc_query(physical,[])
        self.assertEqual(list(query['device_parameters']),[key])
        self.assertIn(r'G\<0\>',query['nodes'])
        nodes=[dict(kind='node',signal=n,value=str(v),status='OK')
               for n,v in zip(device['nodes'],[.6,.66,.26,0.])]
        ops=[dict(kind='device',signal=path+'.M',parameter='',value='bsimcmg',status='META')]
        ops += [dict(kind='op',signal=path+'.M',parameter=k,value=str(v),status='OK')
                for k,v in dict(id=1e-6,vth=.43,vdssat=.16,cgg=3e-15,vgs=.4,vds=.34).items()]
        raw,sources=consume_query(query,nodes,ops)
        op.require_supported_voltage_semantics(physical,dict(sources=sources))
        row=op.mos_row(device,raw,catalog,mapping)
        self.assertEqual(row[0],path);self.assertEqual(row[5],1e-6)
        self.assertAlmostEqual(row[6],.4);self.assertEqual(row[-2:],[.4,.34])
        alias=(dict(device,path=canonical_device(path)),catalog,dev)
        with self.assertRaisesRegex(ValueError,'multiple OA devices'):
            op.build_dc_query(physical+[alias],[])

    def test_intrinsic_cmg_saturation_cannot_reach_electrical_success_contract(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'require_supported_voltage_semantics'),'CMG consumer gate missing')
        physical=[(dict(path='X.P'),dict(kind='mos_p'),dict(dc_signals={'vdsat':'vdssat'},electrical_rules={}))]
        with self.assertRaisesRegex(ValueError,'intrinsic'):op.require_supported_voltage_semantics(physical)
        physical[0][2]['dc_signals']['vdsat']='vdsat'
        sources={'sources':{'X.P:vdsat':dict(kind='op',device_type='bsimcmg')}}
        with self.assertRaisesRegex(ValueError,'intrinsic'):op.require_supported_voltage_semantics(physical,sources)
        op.require_supported_voltage_semantics(physical,{'sources':{'X.P:vdsat':dict(kind='op',device_type='bsim4')}})

    def test_cmg_query_row_and_native_source_contract(self):
        op=importlib.import_module('op_provider')
        mapping=dict(id='id',vth='vth',vdsat='vdssat',cgg='cgg',intrinsic_vgs='vgs',intrinsic_vds='vds')
        device=dict(path='X.P',signal_path='X.P.M',nodes=['D','G','S','B'])
        catalog=dict(kind='mos_p',terminal_roles=['drain','gate','source','bulk'])
        dev=dict(signal_postfix='.M',dc_signals=mapping,electrical_rules={})
        physical=[(device,catalog,dev)]
        op.require_supported_voltage_semantics(physical)
        query=op.build_dc_query(physical,[])
        self.assertEqual(query['device_parameters']['X.P.M'],['cgg','id','vds','vdssat','vgs','vth'])
        sources={'sources':{'X.P.M:'+p:dict(kind='op',device_type='bsimcmg',parameter=p) for p in ('vgs','vds','vdssat')}}
        op.require_supported_voltage_semantics(physical,sources)
        raw=dict(D=1.07,G=.68,S=1.11,B=1.14)
        raw.update({'X.P.M:'+k:v for k,v in dict(id=-4e-7,vgs=.43,vds=.037,vdssat=.18,vth=-.41,cgg=6e-16).items()})
        row=op.mos_row(device,raw,catalog,mapping)
        self.assertAlmostEqual(row[6],-.43);self.assertAlmostEqual(row[7],-.04)
        self.assertEqual(row[-2:],[.43,.037]) # raw signs never inferred from PMOS polarity
        for bad in ('missing','wrong_type','wrong_parameter','wrong_device'):
            evidence=json.loads(json.dumps(sources))
            if bad=='missing':del evidence['sources']['X.P.M:vds']
            if bad=='wrong_type':evidence['sources']['X.P.M:vds']['device_type']='bsim4'
            if bad=='wrong_parameter':evidence['sources']['X.P.M:vds']['parameter']='vdst'
            if bad=='wrong_device':evidence['sources']['Other:vds']=evidence['sources'].pop('X.P.M:vds')
            with self.subTest(bad=bad),self.assertRaises(ValueError):op.require_supported_voltage_semantics(physical,evidence)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'mos.tsv'
            op.write_mos_tsv(path,[row,row[:12]])
            lines=path.read_text().splitlines()
            self.assertTrue(lines[0].endswith('intrinsic_vgs\tintrinsic_vds'))
            self.assertTrue(lines[2].endswith('NA\tNA'))
        legacy=importlib.import_module('maau_op')
        with self.assertRaisesRegex(ValueError,'formal Bundle'):
            legacy.mos_row(device,raw,catalog,mapping)
        mapping['intrinsic_vds']='vdst'
        with self.assertRaises(ValueError):op.require_supported_voltage_semantics(physical)

    def test_bundle_candidate_only_exports_actual_dut_and_preserves_baseline_controls(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'prepare_bundle_candidate'),'formal Bundle provider branch missing')
        import BaselineBundleTest as fixture
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);mod,bundle,path,_,_,_=fixture.BaselineBundleTest().export(root)
            runtime=root/'runtime';runtime.write_text('#!'+sys.executable+'\n'+'''import json,sys
from pathlib import Path
assert sys.argv[1]=='netlist'
args=dict(zip(sys.argv[2::2],sys.argv[3::2]))
assert args['--cell']=='candidate' and '--baseline-bundle' in args
out=Path(args['--output'])
out.write_text('simulator lang=spectre\\nsubckt candidate D G S B\\nM0 (D G S B) nmod l=30n nfin=2\\nends candidate\\n')
Path(str(out)+'.origin.json').write_text(json.dumps({'working_directory':str(out.parent),'dc_test_name':''}))
''');runtime.chmod(0o755)
            run=root/'run';run.mkdir()
            args=SimpleNamespace(dut_lib='DERIVED',dut_cell='candidate',dut_view='schematic',corner=bundle['corner'])
            extension=dict(validated_baseline_bundle=str(path),nominal_corner=bundle['corner'],op_corners={bundle['corner']:dict(temperature=bundle['temperature'],models=bundle['models'],variables=bundle['variables'])})
            actual,text,root_path=op.prepare_bundle_candidate(args,extension,bundle['source'],bundle['bench'],root/'cds.lib',str(runtime),run)
            self.assertEqual(root_path,'TOP.DUT')
            self.assertIn('maxiters=150 maxsteps=10000',text)
            self.assertIn('ic G=0.3',text);self.assertIn('nodeset G=0.4',text)
            self.assertIn('l=30n',text)
            self.assertFalse((run/'export_bench.log').exists())
            self.assertEqual((run/'bench.scs').read_text(),Path(bundle['bench_netlist']).read_text())

    def test_query_is_built_from_physical_nodes_and_explicit_pdk_mappings(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'build_dc_query'),'formal candidate query integration missing')
        physical=[(dict(path='X0.P',nodes=['OUT','G','VDD','VDD']),
            dict(kind='mos_p',terminal_roles=['drain','gate','source','bulk']),
            dict(signal_postfix='.M',dc_signals={'id':'ids','vth':'vth','vdsat':'vdssat','cgg':'cgg'},electrical_rules={})),
            (dict(path='X0.R',nodes=['OUT','0']),dict(kind='resistor',terminal_roles=['positive','negative']),
             dict(signal_postfix='',dc_signals={},electrical_rules={'dc_signals':{'current':'1'}}))]
        query=op.build_dc_query(physical,[{'signal':'V0:p','sign':-1}])
        self.assertEqual(set(query['nodes']),{'OUT','G','VDD','0'})
        self.assertEqual(query['device_parameters'],{'X0.P.M':['cgg','ids','vdssat','vth']})
        self.assertEqual(query['currents'],['V0:p','X0.R:1'])
        physical[0][2]['dc_signals'].pop('vdsat')
        with self.assertRaisesRegex(ValueError,'mapping'):op.build_dc_query(physical,[{'signal':'V0:p','sign':-1}])

    def test_total_supply_measurement_is_optional_and_configured_bindings_remain_strict(self):
        op=importlib.import_module('op_provider')
        physical=[(dict(path='X.P',nodes=['D','G','S','B']),
            dict(kind='mos_n',terminal_roles=['drain','gate','source','bulk']),
            dict(signal_postfix='',dc_signals={'id':'id','vth':'vth','vdsat':'vdsat','cgg':'cgg'},electrical_rules={}))]
        self.assertEqual(op.build_dc_query(physical,[])['currents'],[])
        for module in ('op_provider','maau_op'):
            provider=importlib.import_module(module)
            self.assertTrue(hasattr(provider,'total_supply_measurement'))
            self.assertEqual(provider.total_supply_measurement({},[]),'NA')
            self.assertEqual(provider.total_supply_measurement({'V:p':-0.001},[{'signal':'V:p','sign':-1}]),0.001)
            for bindings in ([{'signal':'V:p','sign':0}],[{'sign':1}],[{'signal':'missing','sign':1}]):
                with self.subTest(module=module,bindings=bindings),self.assertRaises(ValueError):
                    provider.total_supply_measurement({'V:p':-0.001},bindings)

    def test_bundle_profile_checks_single_corner_and_case_sensitive_variables(self):
        mod=importlib.import_module('standalone')
        self.assertTrue(hasattr(mod,'validate_bundle_profile'),'new session Bundle validation missing')
        bundle=dict(corner='hot',temperature=125,models=[dict(model_file='/model',section_name='ss',sha256='h')],variables={'iout':'10m','IOUT':'200m'})
        profile=dict(nominal_corner='hot',op_corners={'hot':dict(temperature=125,models=[dict(model_file='/model',section_name='ss')],variables={'iout':'10m','IOUT':'200m'})},pvt_corners=[])
        mod.validate_bundle_profile(bundle,profile)
        for bad in ('temp','variable','other_corner','nominal'):
            item=json.loads(json.dumps(profile))
            if bad=='temp':item['op_corners']['hot']['temperature']=27
            if bad=='variable':item['op_corners']['hot']['variables']['iout']='200m'
            if bad=='other_corner':item['pvt_corners']=['cold']
            if bad=='nominal':item['nominal_corner']='cold'
            with self.subTest(bad=bad),self.assertRaises(ValueError):mod.validate_bundle_profile(bundle,item)


if __name__=='__main__':unittest.main()
