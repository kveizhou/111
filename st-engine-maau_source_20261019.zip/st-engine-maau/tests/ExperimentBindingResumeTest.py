"""Server-shaped CMG reports and cached input binding; no Cadence execution."""
import csv
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server/site'))
import ExperimentBindingsTest as fixtures
import experiment_bindings as binding


class ResumeTest(unittest.TestCase):
    def test_bulk_alias_uses_net_identity_instead_of_local_port_spelling(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);args=fixtures.BindingsTest().fixture(root)
            request,node,records=args[3],args[4],args[-1]
            request['core_ports']['PVDD']='top.vdd'
            node['core_ports']['PVDD']={'node':'top.vdd','value':1.2}
            next(r for r in records if r['scope']=='I105' and r['kind']=='terminal' and r['name']=='B')['raw_value']='"PVDD"'
            pending,bound=binding.fill_facts(*args,root)
            self.assertEqual(pending,[])
            self.assertTrue(any('MOS I105' in x and 'bulk=PVDD' in x for x in bound))
            self.assertEqual(args[1]['devices']['PDK/opaque_b']['bulkRule'],'rail')

    def test_bulk_alias_rejects_equal_voltage_different_net_and_missing_evidence(self):
        for mode in ('different_net','missing_port','wrong_target','wrong_template'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                root=Path(d);args=fixtures.BindingsTest().fixture(root)
                request,node,records=args[3],args[4],args[-1]
                request['core_ports']['PVDD']='top.vdd'
                node['core_ports']['PVDD']={'node':'top.vdd','value':1.2}
                next(r for r in records if r['scope']=='I105' and r['kind']=='terminal' and r['name']=='B')['raw_value']='"PVDD"'
                if mode=='different_net':
                    request['core_ports']['PVDD']='top.other_vdd'
                    node['core_ports']['PVDD']['node']='top.other_vdd' # Still the same voltage.
                elif mode=='missing_port':request['core_ports'].pop('PVDD')
                elif mode=='wrong_target':request['targets']['I105']['terminals']['B']='top.other_vdd'
                else:request['core_ports']['AVDD']='top.other_vdd'
                pending,_=binding.fill_facts(*args,root)
                self.assertTrue(any('I105' in x and 'Bulk' in x for x in pending))

    def test_native_cmg_numeric_enum_with_report_and_shared_model(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);args=fixtures.BindingsTest().fixture(root)
            for name,number,shared in [('I21',1,'top.core.I85.n18_ckt.4'),('I105',0,'top.core.I105.p18_ckt.4')]:
                next(r for r in args[-1] if r['scope']==name and r['kind']=='model_type')['raw_value']=str(number)
                next(r for r in args[-1] if r['scope']==name and r['kind']=='model_binding')['raw_value']='('+json.dumps(f'/top/core/{name}')+' '+json.dumps(shared)+')'
                (root/(name+'_model_type.txt')).write_text(f'\nType : bsimcmg\n{shared}\nparent model = ignored\ntype = {number}\n')
            pending,bound=binding.fill_facts(*args,root)
            self.assertEqual(pending,[])
            self.assertEqual(args[1]['devices']['PDK/opaque_a']['kind'],'mos_n')
            self.assertEqual(args[1]['devices']['PDK/opaque_b']['kind'],'mos_p')

    def test_numeric_enum_requires_exact_cmg_type_and_matching_report(self):
        for raw,report in [(0,'Type : bsim4\ntype = 0'),(2,'Type : bsimcmg\ntype = 2'),(1,'Type : bsimcmg\ntype = 0'),(True,'Type : bsimcmg\ntype = 1')]:
            with self.subTest(raw=raw,report=report):
                with self.assertRaises(ValueError):binding.polarity(raw,report)
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);args=fixtures.BindingsTest().fixture(root)
            (root/'I21_model_type.txt').write_text('Type : bsimcmg\nwrong_model\ntype = 1\n')
            next(r for r in args[-1] if r['scope']=='I21' and r['kind']=='model_type')['raw_value']='1'
            pending,_=binding.fill_facts(*args,root)
            self.assertTrue(any('I21' in x for x in pending))

    def make_case(self,root):
        batch=root/'batch';base=batch/'dc_review_ports_1';bridge=base/'runtime_bridge_1';bridge.mkdir(parents=True)
        old=base/'experiment_inputs_old';old.mkdir();out=base/'experiment_inputs_new';out.mkdir()
        args=fixtures.BindingsTest().fixture(old);pdk,rules,profile,request,node,origins,records=args
        request['core_ports']['PVDD']='top.vdd'
        node['core_ports']['PVDD']={'node':'top.vdd','value':1.2}
        next(r for r in records if r['scope']=='I105' and r['kind']=='terminal' and r['name']=='B')['raw_value']='"PVDD"'
        for name,number in [('I21',1),('I105',0)]:
            next(r for r in records if r['kind']=='model_type' and r['scope']==name)['raw_value']=str(number)
            shared='shared_opaque_model_'+('n' if number else 'p')
            (old/(name+'_model_type.txt')).write_text(f'Type : bsimcmg\n{shared}\ntype = {number}\n')
        (old/'native_records.json').write_text(json.dumps(records))
        lines=['ST_MAE_RECORD\t'+r['kind']+'\t'+json.dumps(r['scope'])+'\t'+json.dumps(r['name'])+'\t'+r['status']+'\t'+r['raw_value'] for r in records]
        (old/'native.tsv').write_text('\n'.join(lines+['ST_MAESTRO_SETUP_READ_COMPLETE'])+'\n')
        (old/'ocean.log').write_text('ST_EXPERIMENT_BIND_NATIVE_FAILED\n') # v1 prog() false failure
        session=root/'session';inputs=session/'analysis/standalone_inputs';inputs.mkdir(parents=True)
        (inputs/'provider_inputs.json').write_text('{}')
        (batch/'native_records.json').write_text(json.dumps([r for r in records if r['scope']!='R0']))
        probe=inputs/'pdk_probe.tsv'
        with probe.open('w') as stream:
            w=csv.writer(stream,delimiter='\t');w.writerow(['oa_library','oa_cell','model_name','terminal_names','parameter','units','has_schematic'])
            for cell,terms,params in [('opaque_a','D,G,S,B',['l','nfin','m','model','label']),('opaque_b','D,G,S,B',['l','nfin','m','model','label']),('rpoly','PLUS,MINUS',['r','m','model'])]:
                for param in params:w.writerow(['PDK',cell,cell,terms,param,'lengthMetric' if param=='l' else 'resistance' if param=='r' else '', 'false'])
        bench=root/'bench.scs';bench.write_text('subckt core AVDD AGND\nR0 (net__01 net__02) rpoly r=10k\nends core\n')
        profile.update(validation_scope='experimental_dc',experimental_pdk_cache={'probe':str(probe),'pdk_roots':[str(root)]},op_corners={})
        for cell,name in [('opaque_a','I21'),('opaque_b','I105')]:profile['experimental_parameter_seeds']['PDK/'+cell]={'instance':name,'trials':{}}
        hashes={str(probe):hashlib.sha256(probe.read_bytes()).hexdigest()}
        report={'schema':'cascode-experiment-preparation-v1','accepted_bridge':str(bridge),'validation_scope':'experimental_dc','source_cache_sha256':hashes,'reliability_verified':False,'ready_for_sizing':False,'vbias_generated':False}
        historical=dict(report,native_executions=1,native_error='actual resistor connectivity differs from accepted netlist',experiment_inputs_ready=False)
        (old/'binding_evidence.json').write_text(json.dumps(historical))
        bundle={'source':dict(lib='USER',cell='core',view='schematic'),'cds_lib':str(root/'cds.lib'),'bench_netlist':str(bench),'source_subckt':'core'}
        return out,old,session,batch,bridge,bundle,pdk,profile,rules,report,request,node,origins

    def test_reuses_complete_v1_read_and_relocatable_seed_without_eda(self):
        with tempfile.TemporaryDirectory() as d:
            out,old,session,batch,bridge,bundle,pdk,profile,rules,report,request,node,origins=self.make_case(Path(d))
            original={p.name:p.read_bytes() for p in old.iterdir()}
            with patch('experiment_bindings.cached_binding_context',return_value=(request,node,origins,{})),patch('standalone.environment',side_effect=AssertionError('must not prepare EDA')),patch('collect_cascode_batch.command',side_effect=AssertionError('must not run EDA')):
                rc=binding.bind(out,session,batch,bridge,bundle,pdk,profile,rules,report,10,reuse_dir=old)
            self.assertEqual(rc,0,(out/'summary.txt').read_text())
            result=json.loads((out/'binding_evidence.json').read_text())
            self.assertEqual(result['native_executions'],0)
            self.assertTrue(result['native_evidence_reused'])
            self.assertFalse(result['resistor_seed_context']['original_connections_match'])
            self.assertEqual(len(json.loads((out/'experimental_metadata.preview.json').read_text())['devices']),3)
            self.assertEqual(original,{p.name:p.read_bytes() for p in old.iterdir()})
            self.assertFalse(result['ready_for_sizing'])
            again=out.parent/'experiment_inputs_again';again.mkdir()
            reused=binding.reuse_native_evidence(out,again,bridge,report['source_cache_sha256'])
            self.assertTrue(reused)
            (out/'I21_model_type.txt').write_text('changed after binding')
            with self.assertRaisesRegex(ValueError,'files changed'):
                binding.reuse_native_evidence(out,again,bridge,report['source_cache_sha256'])

    def test_reuse_rejects_drift_cross_baseline_and_incomplete_read(self):
        for mode in ('drift','baseline','marker','records'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                out,old,session,batch,bridge,bundle,pdk,profile,rules,report,request,node,origins=self.make_case(Path(d))
                previous=json.loads((old/'binding_evidence.json').read_text())
                if mode=='drift':Path(next(iter(report['source_cache_sha256']))).write_text('changed')
                elif mode=='baseline':previous['accepted_bridge']=str(bridge.parent/'different_bridge')
                elif mode=='marker':(old/'native.tsv').write_text((old/'native.tsv').read_text().replace('ST_MAESTRO_SETUP_READ_COMPLETE','INCOMPLETE'))
                else:(old/'native_records.json').write_text('[]')
                (old/'binding_evidence.json').write_text(json.dumps(previous))
                with self.assertRaises(ValueError):binding.reuse_native_evidence(old,out,bridge,report['source_cache_sha256'])
                self.assertFalse((out/'pdk_facts.json').exists())

    def test_resistor_seed_still_requires_same_model(self):
        with tempfile.TemporaryDirectory() as d:
            case=self.make_case(Path(d));out,old,_,_,_,bundle,*_=case
            records=json.loads((old/'native_records.json').read_text())
            Path(bundle['bench_netlist']).write_text('subckt core AVDD AGND\nR0 (AVDD AGND) different_model r=10k\nends core\n')
            with self.assertRaisesRegex(ValueError,'model'):
                binding.resistor_seed_context(bundle,records)


if __name__=='__main__':unittest.main()
