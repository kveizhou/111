"""Exercise a read-only audit of retained OA/native netlist records."""
import importlib.util
import contextlib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'scripts/inspect_cascode_bindings.py'
sys.path.insert(0,str(ROOT/'server/site'))
import op_provider


class BindingEvidenceTest(unittest.TestCase):
    def module(self):
        self.assertTrue(SCRIPT.is_file(),'retained binding audit missing')
        spec=importlib.util.spec_from_file_location('binding_audit',SCRIPT)
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

    def catalog(self):
        return {'nmod':[({'oa_library':'PDK','oa_cell':'N','terminal_names':['D','G','S','B'],
                          'terminal_roles':['drain','gate','source','bulk']},{})]}

    def binding(self,model='nmod'):
        return dict(oa_library='PDK',oa_cell='N',oa_view='symbol',terminal_names=['D','G','S','B'],
                    classification='target',model_name=model)

    def device(self,name):
        return dict(path='TOP.'+name,master='nmod',nodes=['d','g','s','b'])

    def test_distinguishes_escape_and_array_hints_without_changing_binding(self):
        m=self.module()
        bindings={'I93<5:4>.I2.M0':self.binding(),'I94<0>.M0':self.binding()}
        before=repr(bindings)
        leaves=[self.device(r'I93\<5\>.I2.M0'),self.device(r'I93\<4\>.I2.M0'),self.device(r'I94\<0\>.M0')]
        report=m.audit(leaves,'TOP',self.catalog(),bindings,op_provider)
        self.assertEqual(report['counts']['array_name_candidate'],2)
        self.assertEqual(report['counts']['escape_only_candidate'],1)
        self.assertEqual(report['counts']['unresolved'],0)
        self.assertEqual(repr(bindings),before)
        self.assertEqual(report['unmatched_expanded_paths'],[])

    def test_missing_hierarchy_ambiguous_binding_and_model_conflict_are_not_hidden(self):
        m=self.module()
        cases=[({'I93<5>.I2':self.binding()},'unresolved'),
               ({'I93<5>.I2.M0':self.binding(),r'I93\<5\>.I2.M0':self.binding()},'ambiguous'),
               ({'I93<5>.I2.M0':self.binding('other_model')},'identity_conflict')]
        for bindings,status in cases:
            with self.subTest(status=status):
                report=m.audit([self.device(r'I93\<5\>.I2.M0')],'TOP',self.catalog(),bindings,op_provider)
                self.assertEqual(report['counts'][status],1)

    def test_all_missing_devices_and_unused_array_bits_are_reported(self):
        m=self.module()
        bindings={'I93<5:3>.I2.M0':self.binding()}
        leaves=[self.device(r'I93\<5\>.I2.M0'),self.device('UNKNOWN1'),self.device('UNKNOWN2')]
        report=m.audit(leaves,'TOP',self.catalog(),bindings,op_provider)
        self.assertEqual(report['counts']['unresolved'],2)
        self.assertEqual(report['unmatched_expanded_paths'],['I93<3>.I2.M0','I93<4>.I2.M0'])
        self.assertEqual(len(report['differences']),3)

    def test_real_blockers_are_not_hidden_behind_array_name_samples(self):
        m=self.module()
        self.assertTrue(hasattr(m,'emit_differences'),'blocker-first summary missing')
        report=dict(differences=[dict(status='array_name_candidate',netlist_instance='A'+str(n)) for n in range(3134)]+
                    [dict(status='unresolved',netlist_instance='MISSING'+str(n)) for n in range(39)])
        stream=io.StringIO()
        with contextlib.redirect_stdout(stream):m.emit_differences(report)
        output=stream.getvalue().splitlines()
        blockers=[json.loads(line.split('=',1)[1]) for line in output if line.startswith('BINDING_BLOCKER=')]
        self.assertEqual([x['netlist_instance'] for x in blockers],['MISSING'+str(n) for n in range(39)])
        self.assertIn('SUMMARY_OMITTED_BLOCKERS=0',output)
        self.assertLessEqual(sum(line.startswith('BINDING_NAME_SAMPLE=') for line in output),6)

    def test_cli_reads_retained_files_and_preserves_inputs(self):
        with tempfile.TemporaryDirectory() as temporary:
            candidate=Path(temporary)/'candidate_I21_test'
            work=candidate/'work'
            simulation=work/'analysis/baseline_op/raw_op/st-op-simulation.test'
            simulation.mkdir(parents=True)
            def write(path,text):
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_text(text)
                return path
            def js(path,value):return write(path,json.dumps(value))
            def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
            deck=write(simulation/'simulation.scs',r'''simulator lang=spectre
subckt core D G S B
I93\<5\> (D G S B) child
ends core
subckt child D G S B
I2 (D G S B) transistor
ends child
subckt transistor D G S B
M0 (D G S B) nmod
ends transistor
TOP (D G 0 0) core
''')
            write(simulation/'export_dut.log','PORT_BINDING=BUS_BITS_VERIFIED OA=22 BITS=24\n')
            catalog=write(work/'analysis/pdk_scan/run_0001/raw_catalog.tsv',
                'model_name\tpdk_version\toa_library\toa_cell\tkind\tterminal_names\tterminal_roles\n'
                'nmod\tv\tPDK\tN\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\n')
            js(simulation/'binding.json',dict(root_path='TOP',dut=['L','core','schematic'],
                simulation_sha256=sha(deck),scanned_catalog_sha256=sha(catalog)))
            write(simulation/'oa_bindings.tsv',
                'instance\toa_library\toa_cell\toa_view\tterminal_names\tclassification\tmodel_name\n'
                'I93<5:4>.I2.M0\tPDK\tN\tsymbol\tD,G,S,B\ttarget\tnmod\n')
            tech=js(candidate/'tech.json',[dict(version='v',devices=[dict(cell='N',kind='mos_n')])])
            rules=js(candidate/'rules.json',dict(validation_scope='experimental_dc'))
            provider=ROOT/'server/site/op_provider.py'
            manifest=js(candidate/'resume_generate_test/provider_inputs.json',
                dict(tech=str(tech),rules=str(rules),file_sha256={str(provider):sha(provider)}))
            js(candidate/'run_status.json',dict())
            js(manifest.parent/'run_status.json',dict(provider_manifest=str(manifest)))
            before={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
            run=subprocess.run([sys.executable,str(SCRIPT),'--engine',str(ROOT),'--candidate',str(candidate)],
                               text=True,capture_output=True)
            self.assertEqual(run.returncode,0,run.stdout+run.stderr)
            self.assertIn('PARSER_MATCHES_SESSION=true',run.stdout)
            # The mapped bit is now accepted; the absent fourth bit must still fail.
            self.assertIn('PRODUCTION_REPLAY=physical PDK bindings not exported by netlist: I93<4>.I2.M0',run.stdout)
            reports=list(candidate.glob('binding_review_*/binding_evidence.json'))
            self.assertEqual(len(reports),1)
            report=json.loads(reports[0].read_text())
            self.assertEqual(report['counts']['array_name_candidate'],1)
            self.assertEqual(report['unmatched_expanded_paths'],['I93<4>.I2.M0'])
            self.assertEqual(before,{p:p.read_bytes() for p in before})
            self.assertEqual(set(p for p in candidate.rglob('*') if p.is_file())-set(before),set(reports))


if __name__=='__main__':unittest.main()
