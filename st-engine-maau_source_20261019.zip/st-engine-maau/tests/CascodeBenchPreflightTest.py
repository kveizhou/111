"""Exercise cached settings and preflight gates; external OCEAN is a file-writing fixture."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import pin_site_inputs, write_json

ENTRY = ROOT / 'server/site/preflight_cascode_bench.py'


class CascodeBenchPreflightTest(unittest.TestCase):
    def setUp(self):
        self.assertTrue(ENTRY.is_file(), 'preflight entry is not implemented')

    def fixture(self, base):
        session = base / 'session'; archive = session / 'analysis/standalone_inputs'
        archive.mkdir(parents=True)
        cds = base / 'cadence/cds.lib'; cds.parent.mkdir(); cds.write_text('; actual registry fixture\n')
        (session / 'session.conf').write_text('cds_lib=' + str(cds) + '\nsource_library=CORELIB\n'
            'source_cell=core\nsource_view=schematic\nvalidation_scope=structure_only\n')
        paths = {key: str(archive / (key + '.json')) for key in ('context', 'rules', 'tech', 'adapter', 'runtime', 'init')}
        for key, path in paths.items(): write_json(path, {'validation_scope': 'structure_only'} if key == 'rules' else {})
        write_json(archive / 'provider_inputs.json', pin_site_inputs(paths))
        bench = base / 'repository/BENCHLIB'; (bench / 'bench/config_presim').mkdir(parents=True)
        model = base / 'models with spaces.scs'
        model.write_text('library actual\nsection ss_mos\nendsection ss_mos\nsection pre\nendsection pre\nendlibrary actual\n')
        records = []
        def add(kind, scope, name, value):
            records.append(dict(kind=kind, scope=scope, name=name, status='OK', raw_value=value))
        for key, value in [('library', 'BENCHLIB'), ('cell', 'bench'), ('view', 'maestro_pvt_ea'),
                           ('registered_library_path', str(bench))]: add('meta', 'setup', key, json.dumps(value))
        for key, value in [('test_name', 'presim'), ('design_library', 'BENCHLIB'), ('design_cell', 'bench'),
                           ('design_view', 'config_presim'), ('simulator', 'spectre')]:
            add('test', 'presim', key, json.dumps(value))
        add('test', 'presim', 'enabled', 't')
        add('test', 'presim', 'all_global_variables_disabled', 'nil')
        add('test', 'presim', 'models', '(("/unused/test.scs" "test_tt"))')
        for key, value in [('AVDD', '1.8'), ('iout', '1m'), ('IOUT', '200m'), ('da_rst', '1')]:
            add('test_variable', 'presim', key, json.dumps(value))
        add('corner', 'HOT', 'enabled', 't')
        for key, value in [('temperature', '125'), ('AVDD', '1.14'), ('iout', '10m')]:
            add('corner_variable', 'HOT', key, json.dumps(value)); add('corner_variable_enabled', 'HOT', key, 't')
        for i, section in enumerate(('ss_mos', 'pre')):
            name = 'model:' + str(i)
            add('corner_model_file', 'HOT', name, json.dumps(str(model)))
            add('corner_model_section', 'HOT', name, json.dumps('"' + section + '"'))
            add('corner_model_enabled', 'HOT', name, 't')
        selection = {'session': str(session), 'cds_lib': str(cds), 'bench_library': 'BENCHLIB',
            'bench_cell': 'bench', 'setup_view': 'maestro_pvt_ea', 'expected_library_path': str(bench),
            'read_only': True, 'session_config_sha256': hashlib.sha256((session/'session.conf').read_bytes()).hexdigest(),
            'cds_lib_sha256': hashlib.sha256(cds.read_bytes()).hexdigest()}
        read = base / 'maestro_read.json'
        read.write_text(json.dumps(dict(result='READ_OK', selection=selection, records=records)))
        fake = base / 'external_ocean'
        fake.write_text('#!' + sys.executable + '\nimport os,re,sys,json\nfrom pathlib import Path\n'
            'p=Path(sys.argv[-1]); text=p.read_text(); (p.parent/"captured_script.txt").write_text(text)\n'
            'if os.environ.get("ST_TEST_WAIT"): __import__("time").sleep(3)\n'
            'registry=p.parent/"cds.lib"\n'
            'assert registry.is_file(), "isolated OCEAN registry is missing"\n'
            '(p.parent/"captured_registry.txt").write_text(registry.read_text())\n'
            'root=Path(json.loads(re.search(r"projectDir\\\"\\s+\'string\\s+(\\\"(?:\\\\.|[^\\\"])*\\\")",text)[1]))\n'
            '(root/"Spectre/bench/netlist").mkdir(parents=True)\n'
            'if not os.environ.get("ST_TEST_NO_NETLIST"):\n'
            ' (root/"Spectre/bench/netlist/input.scs").write_text(os.environ.get("ST_TEST_DECK", ""))\n'
            'if not os.environ.get("ST_TEST_NO_MARKER"): (p.parent/"runtime.done").write_text("OK\\n")\n')
        fake.chmod(0o755)
        deck = ('simulator lang=spectre\nparameters AVDD=1.14 iout=10m IOUT=200m da_rst=1\n'
            'subckt core D G S B\nM0 (D G S B) finmod l=134n nfin=6 fw=166n nf=1\nends core\n'
            'subckt top A B\nXCORE (A G 0 0) core\nends top\nXTOP (VDD 0) top\n'
            'VDD (VDD 0) vsource type=pulse val0=0 val1=AVDD delay=5u rise=20u\n'
            'ILOAD (VDD 0) isource dc=iout\nIOTHER (VDD 0) isource dc=IOUT\n')
        env = dict(os.environ, ST_OCEAN_BIN=str(fake), ST_TEST_DECK=deck)
        return session, read, env

    def run_entry(self, session, read, output, env, prepare=False, extra=()):
        return subprocess.run([sys.executable, str(ENTRY), '--session', str(session), '--maestro-read', str(read),
            '--test', 'presim', '--corner', 'HOT', '--output', str(output)] + (['--prepare-only'] if prepare else []) + list(extra),
            capture_output=True, text=True, env=env)

    def change(self, read, kind, scope, name, value):
        data = json.loads(read.read_text())
        next(r for r in data['records'] if (r['kind'], r['scope'], r['name']) == (kind, scope, name))['raw_value'] = value
        read.write_text(json.dumps(data))

    def test_prepare_preserves_case_and_uses_enabled_corner_models(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); original=(s/'session.conf').read_bytes()
            result=self.run_entry(s,r,b/'out',e,True)
            self.assertEqual(result.returncode,0,result.stderr)
            settings=json.loads((b/'out/selected_corner.json').read_text())
            self.assertEqual(settings['variables']['iout'],'10m'); self.assertEqual(settings['variables']['IOUT'],'200m')
            self.assertEqual(settings['temperature'],125)
            self.assertEqual([m['section_name'] for m in settings['models']],['ss_mos','pre'])
            self.assertNotIn('test_tt',json.dumps(settings)); self.assertFalse(settings['simulation_profile_ready'])
            self.assertIn('NATIVE_EXECUTION=false',result.stdout); self.assertEqual((s/'session.conf').read_bytes(),original)

    def test_native_dispatch_preserves_config_and_reports_real_source_excitation(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); result=self.run_entry(s,r,b/'out',e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            script=(b/'out/ocean/captured_script.txt').read_text()
            self.assertIn('design("BENCHLIB" "bench" "config_presim")',script)
            self.assertIn('INCLUDE '+json.dumps(str(b/'cadence/cds.lib')), (b/'out/ocean/captured_registry.txt').read_text())
            self.assertNotIn('run()',script); self.assertNotIn('hdbSave',script)
            self.assertIn('SOURCE path=VDD',result.stdout); self.assertIn('val0=0',result.stdout)
            self.assertIn('CORE_PATH=XTOP.XCORE',result.stdout)
            self.assertIn('nfin=6',result.stdout); self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout)
            self.assertIn('SIMULATION_PROFILE_READY=false',result.stdout)

    def test_old_output_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); out=b/'out'; out.mkdir(); (out/'keep').write_text('original')
            result=self.run_entry(s,r,out,e,True)
            self.assertNotEqual(result.returncode,0); self.assertEqual((out/'keep').read_text(),'original')

    def test_session_change_rejects_stale_read(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); (s/'session.conf').write_text((s/'session.conf').read_text()+'# changed\n')
            result=self.run_entry(s,r,b/'out',e,True)
            self.assertNotEqual(result.returncode,0); self.assertIn('session',result.stderr.lower())

    def test_disabled_corner_not_reused(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); self.change(r,'corner','HOT','enabled','nil')
            result=self.run_entry(s,r,b/'out',e,True)
            self.assertNotEqual(result.returncode,0); self.assertIn('enabled',result.stderr)

    def test_sweep_and_unread_fields_fail_before_native_call(self):
        for value in ('"-40 125"','(+ 125 5)'):
            with self.subTest(value=value), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,e=self.fixture(b); self.change(r,'corner_variable','HOT','temperature',value)
                result=self.run_entry(s,r,b/'out',e,True)
                self.assertNotEqual(result.returncode,0)
                self.assertFalse((b/'out/ocean').exists())

    def test_global_override_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); data=json.loads(r.read_text())
            data['records'].append(dict(kind='global_variable',scope='setup',name='AVDD',status='OK',raw_value='"9"'))
            r.write_text(json.dumps(data)); result=self.run_entry(s,r,b/'out',e,True)
            self.assertNotEqual(result.returncode,0); self.assertIn('global',result.stderr)

    def test_duplicate_settings_and_multiple_enabled_tests_rejected(self):
        for duplicate in (True,False):
            with self.subTest(duplicate=duplicate), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,e=self.fixture(b); data=json.loads(r.read_text())
                data['records'].append(data['records'][0] if duplicate else dict(kind='test',scope='other',name='enabled',status='OK',raw_value='t'))
                r.write_text(json.dumps(data)); result=self.run_entry(s,r,b/'out',e,True)
                self.assertNotEqual(result.returncode,0)

    def test_missing_model_or_wrong_section_fail_early(self):
        for missing_file in (True,False):
            with self.subTest(missing_file=missing_file), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,e=self.fixture(b)
                if missing_file: (b/'models with spaces.scs').unlink()
                else: self.change(r,'corner_model_section','HOT','model:0','"missing"')
                result=self.run_entry(s,r,b/'out',e,True)
                self.assertNotEqual(result.returncode,0)

    def test_missing_completion_or_netlist_is_not_success(self):
        for key in ('ST_TEST_NO_MARKER','ST_TEST_NO_NETLIST'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,e=self.fixture(b); e[key]='1'; result=self.run_entry(s,r,b/'out',e)
                self.assertNotEqual(result.returncode,0); self.assertNotIn('RESULT=NETLIST_READ_OK',result.stdout)

    def test_timeout_preserves_evidence_without_success(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b); e['ST_TEST_WAIT']='1'
            result=self.run_entry(s,r,b/'out',e,extra=['--timeout','1'])
            self.assertNotEqual(result.returncode,0)
            self.assertIn('RESULT=INCOMPLETE',result.stdout)
            self.assertTrue((b/'out/ocean/ocean.log').is_file())

    def test_ambiguous_core_or_unknown_language_is_incomplete(self):
        for suffix in ('XOTHER (VDD G 0 0) core\n','simulator lang=spice\n'):
            with self.subTest(suffix=suffix), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,e=self.fixture(b); e['ST_TEST_DECK']+=suffix
                result=self.run_entry(s,r,b/'out',e)
                self.assertNotEqual(result.returncode,0); self.assertNotIn('RESULT=NETLIST_READ_OK',result.stdout)

    def test_summary_is_bounded_and_retains_raw_on_server(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,e=self.fixture(b)
            e['ST_TEST_DECK']+=''.join('V%d (P%d 0) vsource dc=1\n'%(i,i) for i in range(250))
            result=self.run_entry(s,r,b/'out',e)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertLessEqual(len(result.stdout.splitlines()),180)
            self.assertIn('SUMMARY_TRUNCATED=true',result.stdout)
            self.assertIn('EXCITATION_REVIEW_REQUIRED=true',result.stdout)
            self.assertIn('V249', (b/'out/bench.scs').read_text())


if __name__ == '__main__': unittest.main()
