"""Exercise diagnostic selection/dispatch; native CDF semantics need Cadence."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import pin_site_inputs, write_json


class CdfRoundtripDiagnosticsTest(unittest.TestCase):
    def fixture(self, base):
        session = base / 'failed session'
        archive = session / 'analysis/standalone_inputs'
        archive.mkdir(parents=True)
        (session / 'reports').mkdir()
        (session / 'materialization').mkdir()
        cds = base / 'cadence/cds.lib'
        cds.parent.mkdir()
        cds.write_text('; fixture\n')
        (session / 'session.conf').write_text('cds_lib=' + str(cds) + '\n')
        paths = {k: str(archive / (k + ('.json' if k in ('context', 'rules', 'tech') else '.il')))
                 for k in ('context', 'rules', 'tech', 'adapter', 'runtime', 'init')}
        write_json(paths['context'], {})
        write_json(paths['rules'], {})
        write_json(paths['tech'], [{'corners': []}])
        for key in ('adapter', 'runtime', 'init'):
            Path(paths[key]).write_text('; fixture\n')
        write_json(archive / 'provider_inputs.json', pin_site_inputs(paths))
        write_json(session / 'materialization/plan.json', {
            'source': {'library': 'DUT', 'cell': 'core', 'view': 'schematic'},
            'generated_cells': [{'schematic': {'library': 'VAR__STAGING', 'cell': 'core__PKG0001',
                'view': 'schematic'}, 'create_instances': [{'name': 'I105', 'master': {
                    'library': 'PDK', 'cell': 'p18', 'view': 'symbol'},
                    'cdf_parameters': {'cellHeight_misMatch': '', 'l': '134n', 'nfin': '6'}}]}]})
        (session / 'reports/validation.txt').write_text(
            'ok=false\nstage=verify_roundtrip\n'
            'message=oa_VAR__STAGING__core__PKG0001/I105.cellHeight_misMatch 要求值=，round-trip 值缺失或不同\n')
        return session

    def run_entry(self, session, out, extra=(), env=None):
        return subprocess.run([sys.executable, str(ROOT / 'server/site/diagnose_cdf_roundtrip.py'),
            '--session', str(session), '--output', str(out)] + list(extra),
            capture_output=True, text=True, env=env)

    def test_prepare_keeps_empty_expected_value_and_selects_exact_package(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base); out = base / 'evidence'
            result = self.run_entry(session, out, ['--prepare-only'])
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            selected = json.loads((out / 'selection.json').read_text())
            self.assertEqual(selected['expected_value'], '')
            self.assertEqual(selected['target']['cell'], 'core__PKG0001')
            self.assertEqual(selected['source']['library'], 'DUT')
            self.assertIn('native execution not performed', result.stdout)
            self.assertNotIn('CDF_ROUNDTRIP_DIAGNOSTIC_READ_OK', result.stdout)

    def test_missing_native_marker_is_failure_even_when_process_exits_zero(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base)
            fake = base / 'fake process'
            fake.write_text('#!/bin/sh\nprintf "SOURCE_READ_OK\\n" > "$ST_CDF_ROUNDTRIP_REPORT"\n')
            fake.chmod(0o755)
            result = self.run_entry(session, base / 'evidence', env=dict(os.environ, ST_VIRTUOSO_BIN=str(fake)))
            self.assertEqual(result.returncode, 70, result.stdout + result.stderr)
            self.assertNotIn('CDF_ROUNDTRIP_DIAGNOSTIC_READ_OK', result.stdout)

    def test_native_failure_is_not_overridden_by_report_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base)
            fake = base / 'fake process'
            fake.write_text('#!/bin/sh\nprintf "ST_CDF_ROUNDTRIP_DIAGNOSTIC_COMPLETE\\n" > "$ST_CDF_ROUNDTRIP_REPORT"\nexit 7\n')
            fake.chmod(0o755)
            result = self.run_entry(session, base / 'evidence', env=dict(os.environ, ST_VIRTUOSO_BIN=str(fake)))
            self.assertEqual(result.returncode, 7)
            self.assertNotIn('CDF_ROUNDTRIP_DIAGNOSTIC_READ_OK', result.stdout)

    def test_existing_evidence_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base); out = base / 'evidence'
            out.mkdir(); (out / 'keep').write_text('original')
            result = self.run_entry(session, out, ['--prepare-only'])
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual((out / 'keep').read_text(), 'original')

    def test_a_successful_validation_cannot_be_used_as_failed_roundtrip(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base); out = base / 'evidence'
            (session / 'reports/validation.txt').write_text('ok=true\nstage=complete\n')
            result = self.run_entry(session, out, ['--prepare-only'])
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(out.exists())

    def test_changed_pinned_inputs_are_rejected_before_launch(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory).resolve(); session = self.fixture(base); out = base / 'evidence'
            (session / 'analysis/standalone_inputs/init.il').write_text('; changed\n')
            result = self.run_entry(session, out, ['--prepare-only'])
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(out.exists())


if __name__ == '__main__':
    unittest.main()
