"""Real parsing and cache invalidation; no Cadence results are simulated."""
import copy
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/site'))
import op_provider as op

SEGMENT_COUNTS={'R0':25,'R1':8,'R3':8,'R4':2}

def segmented_resistors(model='r'):
    """Synthetic connectivity; only names/counts come from the server summary."""
    lines=[]
    for parent,count in SEGMENT_COUNTS.items():
        nodes=['G']+[parent+'_mid'+str(i) for i in range(1,count)]+['S']
        for index in range(1,count+1):
            name=parent if index==1 else parent+'_'+str(index)+'__res_gen'
            lines.append(name+' ('+nodes[index-1]+' '+nodes[index]+') '+model+' r=2k')
    return '\n'.join(lines)+'\n'

class PreservedResistorsTest(unittest.TestCase):
    def fixture(self):
        text='''simulator lang=spectre
parameters bias=1
subckt core D G S B
M (D G S B) n l=100n
R0 (G mid) r r=2k
R0_2_res_gen (mid S) r r=2k
ends core
TOP (d g 0 0) core
'''
        n=dict(kind='mos_n',oa_library='P',oa_cell='N',terminal_names=['D','G','S','B'],terminal_roles=['drain','gate','source','bulk'])
        r=dict(kind='resistor',oa_library='P',oa_cell='R',terminal_names=['PLUS','MINUS'],terminal_roles=['positive','negative'])
        cats={'n':[(n,{})],'r':[(r,{})]}
        bindings={name:dict(oa_library='P',oa_cell=cell,terminal_names=pins,classification='target',model_name=model) for name,cell,pins,model in [('M','N',n['terminal_names'],'n'),('R0','R',r['terminal_names'],'r')]}
        return text,cats,bindings

    def test_unchanged_group_not_measured_or_given_fake_oa_bindings(self):
        text,cats,b=self.fixture();before=copy.deepcopy(b);report=[]
        self.assertIn('baseline_text',__import__('inspect').signature(op.bind_physical_devices).parameters)
        result=op.bind_physical_devices(text,'TOP','core',cats,b,baseline_text=text,baseline_master='core',preserved_report=report)
        self.assertEqual([d['output_name'] for d,_,_ in result],['M'])
        self.assertEqual(report,[{'instance':'R0','segments':['R0','R0_2_res_gen'],'measurements_extracted':False}])
        self.assertEqual(b,before)

    def test_changed_added_or_incomplete_group_is_not_exempt(self):
        text,cats,b=self.fixture()
        self.assertIn('baseline_text',__import__('inspect').signature(op.bind_physical_devices).parameters)
        for changed in (text.replace('mid S','mid D'),text.replace('r=2k','r=3k'),text.replace('R0_2_res_gen','R0_3_res_gen'),text.replace('R0','R1')):
            with self.subTest(changed=changed),self.assertRaises(ValueError):
                op.bind_physical_devices(changed,'TOP','core',cats,b,baseline_text=text,baseline_master='core')
        with self.assertRaises(ValueError):op.bind_physical_devices(text,'TOP','core',cats,b)

    def test_four_groups_with_39_double_underscore_extra_segments(self):
        text,cats,b=self.fixture()
        text=text.replace('R0 (G mid) r r=2k\nR0_2_res_gen (mid S) r r=2k\n',segmented_resistors())
        for name in SEGMENT_COUNTS:b[name]=dict(b['R0'])
        report=[]
        result=op.bind_physical_devices(text,'TOP','core',cats,b,baseline_text=text,
                                       baseline_master='core',preserved_report=report)
        self.assertEqual([d['output_name'] for d,_,_ in result],['M'])
        self.assertEqual({r['instance']:len(r['segments']) for r in report},SEGMENT_COUNTS)
        self.assertEqual(sum(len(r['segments'])-1 for r in report),39)
        self.assertIn('R3_2__res_gen',next(r['segments'] for r in report if r['instance']=='R3'))

    def test_mixed_suffixes_and_literal_parent_names_preserve_exact_paths(self):
        text,cats,b=self.fixture()
        text=text.replace('R0_2_res_gen (mid S)','R0_2__res_gen (mid other)')
        text=text.replace('ends core','R0_3_res_gen (other S) r r=2k\nends core')
        text=text.replace('R0','block_R_0');b['block_R_0']=b.pop('R0');report=[]
        op.bind_physical_devices(text,'TOP','core',cats,b,baseline_text=text,
                                 baseline_master='core',preserved_report=report)
        self.assertEqual(report[0]['segments'],['block_R_0','block_R_0_2__res_gen','block_R_0_3_res_gen'])

    def test_double_underscore_exemption_still_rejects_real_changes(self):
        text,cats,b=self.fixture();text=text.replace('_res_gen','__res_gen')
        changes=[text.replace('mid S','mid D'),text.replace('r=2k','r=3k'),
                 text.replace('R0_2__res_gen','R0_2_res_gen'),
                 text.replace('ends core','R0_3__res_gen (G S) r r=2k\nends core'),
                 text.replace('ends core','R0_3_res_gen (G S) r r=2k\nends core'),
                 text.replace('ends core','C (mid 0) capacitor c=1p\nends core'),
                 text.replace('ends core','Rnew (G x) r r=2k\nRnew_2__res_gen (x S) r r=2k\nends core')]
        for changed in changes:
            with self.subTest(changed=changed),self.assertRaises(ValueError):
                op.bind_physical_devices(changed,'TOP','core',cats,b,baseline_text=text,baseline_master='core')
        # If all extra segments disappear, the remaining OA-bound parent can
        # follow strict extraction, but the old group must not be exempted.
        missing=text.replace('R0_2__res_gen (mid S) r r=2k\n','');report=[]
        result=op.bind_physical_devices(missing,'TOP','core',cats,b,baseline_text=text,
                                       baseline_master='core',preserved_report=report)
        self.assertEqual(report,[])
        self.assertIn('R0',[d['output_name'] for d,_,_ in result])

    def test_parent_parameter_changes_invalidate_exemption(self):
        text,cats,b=self.fixture();text=text.replace('r=2k','r=bias')
        self.assertIn('baseline_text',__import__('inspect').signature(op.bind_physical_devices).parameters)
        with self.assertRaises(ValueError):
            op.bind_physical_devices(text.replace('bias=1','bias=2'),'TOP','core',cats,b,baseline_text=text,baseline_master='core')

    def test_model_identity_and_external_tap_changes_not_exempt(self):
        text,cats,b=self.fixture()
        self.assertIn('baseline_text',__import__('inspect').signature(op.bind_physical_devices).parameters)
        for changed in (text.replace('ends core','C (mid 0) capacitor c=1p\nends core'),text.replace(') r ',') n ')):
            with self.subTest(changed=changed),self.assertRaises(ValueError):
                op.bind_physical_devices(changed,'TOP','core',cats,b,baseline_text=text,baseline_master='core')

class ReuseTest(unittest.TestCase):
    def test_current_code_resumes_without_a_version_whitelist_but_data_must_match(self):
        sys.path.insert(0,str(ROOT/'scripts'))
        import resume_cascode_experiment as resume
        import CascodeExperimentResumeTest as fixture
        with tempfile.TemporaryDirectory() as tmp:
            _,inputs=fixture.ResumeTest().fixture(Path(tmp).resolve())
            for name in ('op_provider.py','dc_results.py','site_data.py','cascode_runtime.py'):
                inputs['file_sha256'][str(ROOT/'server/site'/name)]='unknown older implementation'
            with patch.object(resume,'read_json',side_effect=AssertionError('no release manifest needed')):
                updated,_=resume.reuse_updated_inputs(inputs)
            self.assertEqual(updated,inputs)
            Path(inputs['tech']).write_text('{}')
            with self.assertRaises(ValueError):resume.reuse_updated_inputs(inputs)

    def test_cache_content_drift_cannot_reuse(self):
        self.assertTrue((ROOT/'server/site/experiment_reuse.py').is_file(),'reuse implementation missing')
        reuse=importlib.import_module('experiment_reuse')
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'evidence';p.write_text('known')
            pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest()}
            reuse.check_files(pins);p.write_text('changed')
            with self.assertRaisesRegex(ValueError,'changed'):reuse.check_files(pins)

    def test_only_original_baseline_gets_cached_rows(self):
        self.assertTrue((ROOT/'server/site/experiment_reuse.py').is_file(),'reuse implementation missing')
        reuse=importlib.import_module('experiment_reuse')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);row=['M',1,.5,0,0,1e-6,.5,1,0,.3,.2,1e-15]
            receipt=dict(source=['L','core','schematic'],bench=['TB','tb','maestro'],corner='TT',dut_hash='dh',bench_hash='bh',pdk_version='p',mos_rows=[row],total_supply_current='NA')
            args=SimpleNamespace(dut_lib='L',dut_cell='core',dut_view='schematic',bench_lib='TB',bench_cell='tb',bench_view='maestro',corner='TT',dut_hash='dh',bench_hash='bh',pdk_version='p',solver_version='st-dc-solver-v3-experimental_dc',topology_hash='th',parameter_hash='ph',identity_output=str(root/'identity'),mos_output=str(root/'mos'),resistor_output=str(root/'res'))
            self.assertTrue(reuse.write_baseline(args,receipt))
            self.assertIn('M\t1', (root/'mos').read_text())
            for key,val in [('dut_cell','candidate'),('corner','FF'),('dut_hash','changed')]:
                bad=copy.copy(args);setattr(bad,key,val)
                if key=='dut_cell':self.assertFalse(reuse.write_baseline(bad,receipt))
                else:
                    with self.assertRaises(ValueError):reuse.write_baseline(bad,receipt)

class ReuseIntegrationTest(unittest.TestCase):
    def test_local_model_statement_change_cannot_reuse_baseline(self):
        import experiment_reuse as reuse
        with tempfile.TemporaryDirectory() as tmp:
            candidate,inputs,_=self.fixture(Path(tmp))
            directory=next((candidate/'work/analysis/baseline_op/raw_op').iterdir())
            deck=directory/'simulation.scs'
            deck.write_text(deck.read_text().replace('ends core','model unexpected resistor r=2\nends core'))
            path=directory/'binding.json';binding=json.loads(path.read_text())
            binding['simulation_sha256']=hashlib.sha256(deck.read_bytes()).hexdigest();path.write_text(json.dumps(binding))
            self.assertEqual(reuse.prepare_receipt(candidate,inputs)['mos_rows'],[])

    def fixture(self,root,segmented=False,peripheral_mos=0):
        import csv
        import BaselineBundleTest as fixture
        from dc_results import consume_query
        from runtime_bridge import reader_evidence_hashes
        root=root.resolve()
        bound,base,_,_=fixture.BaselineBundleTest().fixture(root)
        if segmented or peripheral_mos:
            extras=(segmented_resistors('rmod') if segmented else '')
            extras+=''.join('PERIPH'+str(i)+' (D G S B) nmod l=20n nfin=2\n' for i in range(peripheral_mos))
            for deck in base.rglob('*.scs'):
                deck.write_text(deck.read_text().replace('ends core',extras+'ends core'))
            bound['fixed']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in bound['fixed']}
        bridge=base/'runtime_bridge_test';bridge.mkdir()
        module=fixture.BaselineBundleTest().module()
        path=module.export_bundle(bound,base,bridge/'bundle');bundle=module.load_bundle(path)
        query=dict(schema='st-dc-query-v1',nodes=['VIN','G','0'],device_parameters={'TOP.DUT.M0':['id','vth','vdsat','cgg','vgs','vds']},currents=[])
        nodes=[dict(kind='node',signal=n,value=str(v),status='OK') for n,v in [('VIN',1.14),('G',.43)]]
        ops=[dict(kind='op',signal='TOP.DUT.M0',parameter=k,value=str(v),status='OK') for k,v in dict(id=1e-6,vth=.3,vdsat=.2,cgg=2e-15,vgs=.43,vds=1.14).items()]
        ops.insert(0,dict(kind='device',signal='TOP.DUT.M0',parameter='',value='bsim4',status='META'))
        raw,origins=consume_query(query,nodes,ops)
        reader=bridge/'psf_reader';reader.mkdir()
        for name,rows in [('nodes.tsv',nodes),('ops.tsv',ops)]:
            with (reader/name).open('w') as out:
                w=csv.DictWriter(out,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
        (reader/'runtime.done').write_text('OK');(reader/'runtime.ocn').write_text('fixture');(bridge/'formal_reader.log').write_text('fixture')
        op.write_tsv(bridge/'raw_signed.tsv',['signal','value'],list(raw.items()))
        for name,obj in [('query.json',query),('expected_values.json',raw),('comparison.json',dict(compared=len(raw),differences={})),('raw_signed.tsv.sources.json',dict(query=query,psf_sha256={},sources=origins,intrinsic_op_preserved=True,terminal_differences_computed_by_consumer=True))]:
            (bridge/name).write_text(json.dumps(obj))
        (bridge/'bridge_status.json').write_text(json.dumps(dict(error=None,bundle_error=None,cache_match=True,psf_unchanged=True,reader_cache_dir=str(bridge),reader_cache_sha256=reader_evidence_hashes(bridge))))
        candidate=root/'candidate';work=candidate/'work';(work/'before').mkdir(parents=True);(work/'changes').mkdir()
        cfg=dict(validation_scope='experimental_dc',source_library='LIB',source_cell='core',source_view='schematic',bench_library='BENCH',bench_cell='tb',bench_view='config_presim',nominal_corner=bundle['corner'],dut_hash='dh',bench_hash='bh',pdk_version='p',cds_lib=bundle['cds_lib'])
        (work/'session.conf').write_text(''.join(k+'='+v+'\n' for k,v in cfg.items()));(work/'changes/001.conf').write_text('instance=M0\n')
        (work/'before/core_before.scs').write_text('structural fixture')
        directory=work/'analysis/baseline_op/raw_op/st-op-simulation.test';(directory/'dut_oa').mkdir(parents=True)
        text=Path(bundle['bench_netlist']).read_text()
        for name in ('dut.scs','bench.scs','simulation.scs'):(directory/name).write_text(text)
        (directory/'dut_oa/runtime.done').write_text('OK')
        op.write_tsv(directory/'oa_bindings.tsv',['instance','oa_library','oa_cell','oa_view','terminal_names','classification','model_name'],[['M0','P','N','symbol','D,G,S,B','target','nmod']])
        scan=work/'analysis/pdk_scan/run_0001';scan.mkdir(parents=True)
        op.write_tsv(scan/'raw_catalog.tsv',['master','kind','oa_library','oa_cell','model_name','pdk_version','terminal_names','terminal_roles'],[['P/N','mos_n','P','N','nmod','p','D,G,S,B','drain,gate,source,bulk']])
        (scan/'pdk_identity.tsv').write_text('fixture identity')
        if segmented:
            with (directory/'oa_bindings.tsv').open('a') as out:
                for name in SEGMENT_COUNTS:out.write(name+'\tP\tR\tsymbol\tPLUS,MINUS\ttarget\trmod\n')
            with (scan/'raw_catalog.tsv').open('a') as out:
                out.write('P/R\tresistor\tP\tR\trmod\tp\tPLUS,MINUS\tpositive,negative\n')
        binding=dict(dut=['LIB','core','schematic'],corner=bundle['corner'],root_path='TOP.DUT',scanned_catalog_sha256=hashlib.sha256((scan/'raw_catalog.tsv').read_bytes()).hexdigest())
        for name,field in [('dut.scs','physical_dut_sha256'),('bench.scs','physical_bench_sha256'),('simulation.scs','simulation_sha256')]:binding[field]=hashlib.sha256((directory/name).read_bytes()).hexdigest()
        (directory/'binding.json').write_text(json.dumps(binding))
        inputs={}
        for key,obj in [('rules',dict(validation_scope='experimental_dc',validated_baseline_bundle=str(path),nominal_corner=bundle['corner'],op_corners={bundle['corner']:dict(temperature=bundle['temperature'],models=bundle['models'],variables=bundle['variables'])})),('context',{}),('tech',[dict(version='p',devices=[dict(oa_library='P',cell='N',kind='mos_n',model='nmod',signal_postfix='',dc_signals=dict(id='id',vth='vth',vdsat='vdsat',cgg='cgg'),electrical_rules={})])])]:
            f=candidate/(key+'.json');f.write_text(json.dumps(obj));inputs[key]=str(f)
        if segmented:
            tech=json.loads(Path(inputs['tech']).read_text())
            tech[0]['devices'].append(dict(oa_library='P',cell='R',kind='resistor',model='rmod',signal_postfix='',dc_signals=dict(current='1'),electrical_rules={}))
            Path(inputs['tech']).write_text(json.dumps(tech))
        return candidate,inputs,bundle

    def test_prepare_real_cached_files_and_run_baseline_without_native(self):
        import experiment_reuse as reuse
        with tempfile.TemporaryDirectory() as tmp:
            candidate,inputs,bundle=self.fixture(Path(tmp))
            with patch('subprocess.run',side_effect=AssertionError('must not launch native')):
                receipt=reuse.prepare_receipt(candidate,inputs)
            self.assertEqual(len(receipt['mos_rows']),1)
            self.assertEqual(receipt['mos_rows'][0][0],'M0')
            self.assertEqual(receipt['mos_rows'][0][5],1e-6)
            self.assertEqual(receipt['total_supply_current'],'NA')
            # A changed physical circuit retains export reuse, never its old DC.
            directory=Path(receipt['simulation_directory']);deck=directory/'simulation.scs'
            deck.write_text(deck.read_text().replace('l=20n','l=40n'))
            path=directory/'binding.json';binding=json.loads(path.read_text());binding['simulation_sha256']=hashlib.sha256(deck.read_bytes()).hexdigest();path.write_text(json.dumps(binding))
            fresh=reuse.prepare_receipt(candidate,inputs)
            self.assertEqual(fresh['mos_rows'],[])

    def test_resume_pins_receipt_reuses_scan_and_baseline_and_preserves_inputs(self):
        import subprocess
        import experiment_reuse as reuse
        sys.path.insert(0,str(ROOT/'scripts'))
        import resume_cascode_experiment as resume
        with tempfile.TemporaryDirectory() as tmp:
            candidate,inputs,bundle=self.fixture(Path(tmp),segmented=True);work=candidate/'work'
            for key in ('adapter','runtime'):
                f=candidate/key;f.write_text('fixture');inputs[key]=str(f)
            inputs['runtime']=str(ROOT/'server/site/cascode_runtime.py')
            inputs['file_sha256']={p:reuse.digest(p) for p in inputs.values()}
            # Match standalone import, which pins every site module, not just
            # files already enumerated by the update manifest.
            inputs['file_sha256'].update({str(p.resolve()):reuse.digest(p)
                for p in (ROOT/'server/site').glob('*.py')})
            inputs['file_sha256'][str(ROOT/'server/skill/pdk_adapter.il')]='dd479ea5b02293b0502ee571c992851bd47d451e7c4060d51253add99a8ae035'
            inputs['file_sha256'][str(ROOT/'server/site/op_provider.py')]='b4f059a824b4a34db82b8319478cd333001916b084478271cbeaa64991d8e605'
            from BundleCodeUpgradeTest import retain_old_tool_versions, OLD_DC_READER
            inputs['file_sha256'][str(ROOT/'server/site/dc_results.py')]=OLD_DC_READER
            retain_old_tool_versions(Path(bundle['_bundle_path']))
            manifest=work/'analysis/standalone_inputs/provider_inputs.json';manifest.parent.mkdir(parents=True);manifest.write_text(json.dumps(inputs))
            (candidate/'inputs.json').write_text(json.dumps(dict(target='M0',input_sha256={})))
            (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',failed_stage='generate')))
            # Real shell validation still consumes the proven identity columns.
            scan=work/'analysis/pdk_scan/run_0001'
            (scan/'pdk_identity.tsv').write_text('process_identity\tcontext_complete\tscan_complete\tdiagnostic\tcandidate_libraries\nP\ttrue\ttrue\t\tP\n')
            originals={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()};calls=[]
            def runner(stage,argv,output,timeout,env=None):
                calls.append(argv)
                receipt=json.loads(Path(env['ST_EXPERIMENT_REUSE_MANIFEST']).read_text())
                self.assertEqual({r['instance']:len(r['segments']) for r in receipt['preserved_resistors']},SEGMENT_COUNTS)
                self.assertTrue(receipt['mos_rows'])
                result=subprocess.run(['bash',str(ROOT/'server/bin/scan_pdk_runner.sh'),'--cds-lib',bundle['cds_lib'],
                    '--lib','LIB','--cell','core','--view','schematic','--catalog-output',str(output/'catalog'),
                    '--identity-output',str(output/'pdk_identity')],env=env,text=True,capture_output=True)
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                self.assertIn('PDK_SCAN_REUSED=true',result.stdout)
                args=SimpleNamespace(dut_lib='LIB',dut_cell='core',dut_view='schematic',bench_lib='BENCH',bench_cell='tb',bench_view='config_presim',
                    corner=bundle['corner'],dut_hash='dh',bench_hash='bh',pdk_version='p',solver_version='st-dc-solver-v3-experimental_dc',
                    topology_hash='th',parameter_hash='ph',identity_output=str(output/'identity'),mos_output=str(output/'mos'),
                    resistor_output=str(output/'res'),device_catalog=str(output/'catalog'),simulation_dir=str(output/'op'))
                with patch.dict(os.environ,env),patch.object(op,'command',side_effect=AssertionError('baseline must not run native')):
                    op.run(args)
                    # Read the same historical bundle from the candidate side,
                    # after actual resume/scan/source-OP reuse has completed.
                    from baseline_bundle import load_bundle
                    loaded=load_bundle(bundle['_bundle_path'])
                    self.assertTrue(loaded['_functional_scope'])
                    self.assertEqual(loaded['_tool_upgrades'],{})
                self.assertAlmostEqual(float((output/'mos').read_text().splitlines()[1].split('\t')[1]),1.14)
                log=output/'generate.log';log.write_text('candidate execution remains to be tested on server')
                raise resume.StageFailure(stage,3,log)
            self.assertEqual(resume.resume(candidate,10,runner=runner,reuse_verified_inputs=True),2)
            self.assertEqual(resume.resume(candidate,10,runner=runner),2)
            self.assertEqual(len(calls),2)
            self.assertTrue(all(p.read_bytes()==raw for p,raw in originals.items()))
            # A malformed retained launch must fail before generate creates
            # another candidate. Keep the actual launch parser in this test.
            import baseline_bundle
            original_load=baseline_bundle.load_bundle
            def missing_launch(*args,**kwargs):
                loaded=original_load(*args,**kwargs)
                loaded['launch_command_evidence']=[]
                return loaded
            with patch.object(baseline_bundle,'load_bundle',side_effect=missing_launch):
                with self.assertRaisesRegex(ValueError,'baseline Spectre command missing'):
                    resume.resume(candidate,10,runner=runner)
            self.assertEqual(len(calls),2)
            # The existing receipt omits nested model files. Resume must still
            # detect this before invoking the expensive generate runner.
            Path(bundle['models'][0]['model_file']).write_text('changed model')
            with self.assertRaisesRegex(ValueError,'baseline dependency changed'):
                resume.resume(candidate,10,runner=runner)
            self.assertEqual(len(calls),2)

if __name__=='__main__':unittest.main()
