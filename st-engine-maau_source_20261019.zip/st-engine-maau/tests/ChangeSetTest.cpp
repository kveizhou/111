#include "st/ChangeSet.h"
#include "st/Netlist.h"
#include "st/OaPlan.h"

#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::TransformRequest request(std::string id, std::string instance,
                             st::TransformType type = st::TransformType::SameTypeCascode)
{
    st::TransformRequest value;
    value.operation_id = std::move(id);
    value.target.subckt = "core";
    value.target.instance = std::move(instance);
    value.type = type;
    if (type == st::TransformType::MosStack) {
        st::StackTransformRequest payload;
        payload.subckt = value.target.subckt;
        payload.target = value.target.instance;
        payload.stage_count = 2;
        payload.gate_policy = st::GatePolicy::SharedGate;
        payload.voltage_domain = "core";
        payload.nmos_bulk_net = "B0";
        value.payload = payload;
    } else if (type == st::TransformType::AddSourceResistor) {
        st::ResistorTransformRequest payload;
        payload.subckt = value.target.subckt;
        payload.target = value.target.instance;
        value.payload = payload;
    } else {
        st::CascodeTransformRequest payload;
        payload.subckt = value.target.subckt;
        payload.target = value.target.instance;
        payload.gate_policy = st::GatePolicy::SharedGate;
        payload.nmos_bulk_net = "B0";
        value.payload = payload;
    }
    return value;
}

st::Netlist makeCircuit()
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "core";
    core.instances.push_back({ "M0", { "D0", "G0", "S0", "B0" }, "nmos",
        { { "w", "2u" }, { "l", "240n" } } });
    core.instances.push_back({ "M1", { "D1", "G1", "S1", "B1" }, "nmos",
        { { "w", "3u" }, { "l", "300n" } } });
    netlist.subckts.push_back(core);
    return netlist;
}

} // namespace

int main()
{
    st::ChangeSet changes;
    st::Diagnostic diagnostic;

    CHECK(changes.Confirm(request("op-1", "M0"), diagnostic),
        "确认第一项变换只写入 Change Set");
    CHECK(changes.Confirm(request("op-2", "M1", st::TransformType::MosStack), diagnostic),
        "同一工作电路可以连续确认第二项变换");
    CHECK(changes.Size() == 2 && changes.Changes()[0].request.operation_id == "op-1" &&
            changes.Changes()[1].request.operation_id == "op-2",
        "Change Set 保留用户确认顺序");

    const auto duplicateId = request("op-2", "M2");
    CHECK(!changes.Confirm(duplicateId, diagnostic) && diagnostic.code == st::DiagCode::DuplicateOperation,
        "拒绝重复 operation id");
    CHECK(changes.Size() == 2, "拒绝重复 id 后 Change Set 不变");

    const auto duplicateTarget = request("op-3", "M0", st::TransformType::AddSourceResistor);
    CHECK(!changes.Confirm(duplicateTarget, diagnostic) && diagnostic.code == st::DiagCode::TargetConflict &&
            diagnostic.message.find("op-1") != std::string::npos,
        "同一原始目标重复变换时返回冲突操作 id");

    CHECK(changes.UndoLast() && changes.Size() == 1 && changes.Changes().back().request.operation_id == "op-1",
        "撤销只删除最后一次确认");
    CHECK(changes.UndoLast() && changes.Empty(), "可以继续撤销到空草稿");
    CHECK(!changes.UndoLast(), "空草稿撤销返回 false 而不是异常");

    CHECK(changes.Confirm(request("op-4", "M0"), diagnostic), "Fresh 前可重新确认操作");
    changes.Fresh();
    CHECK(changes.Empty(), "Fresh 清空全部未生成操作");

    auto badStack = request("op-bad", "M0", st::TransformType::MosStack);
    std::get<st::StackTransformRequest>(badStack.payload).stage_count = 101;
    CHECK(!changes.Confirm(badStack, diagnostic) && diagnostic.code == st::DiagCode::BadParam,
        "确认阶段拒绝超过100级的 Stack");

    CHECK(changes.Confirm(request("op-5", "M0"), diagnostic), "为 Replay 加入第一项操作");
    CHECK(changes.Confirm(request("op-6", "M1"), diagnostic), "为 Replay 加入第二项操作");

    const st::Netlist base = makeCircuit();
    st::Netlist output = base;
    const std::string outputBefore = st::emitSpectre(output);
    int applyCount = 0;
    auto failed = changes.Replay(base, output,
        [&applyCount](st::Netlist& working, const st::TransformRequest& change) {
            ++applyCount;
            working.find(change.target.subckt)->find(change.target.instance)->params["touched"] = "yes";
            if (change.operation_id == "op-6") {
                return std::vector<st::Diagnostic>{
                    { st::DiagCode::BadParam, "模拟第二步失败" }
                };
            }
            return std::vector<st::Diagnostic>{};
        });
    CHECK(!failed.ok && applyCount == 2 && failed.failed_operation_id == "op-6",
        "Replay 精确指出失败的操作");
    CHECK(st::emitSpectre(output) == outputBefore,
        "Replay 中途失败不提交任何部分修改");
    CHECK(changes.Size() == 2, "生成失败不删除或改写 Change Set");

    auto succeeded = changes.Replay(base, output,
        [](st::Netlist& working, const st::TransformRequest& change) {
            working.find(change.target.subckt)->find(change.target.instance)->params["operation"] =
                change.operation_id;
            return std::vector<st::Diagnostic>{};
        });
    CHECK(succeeded.ok && succeeded.applied_operation_ids == std::vector<std::string>({ "op-5", "op-6" }),
        "Replay 成功时按确认顺序报告已应用操作");
    CHECK(output.find("core")->find("M0")->params.at("operation") == "op-5" &&
            output.find("core")->find("M1")->params.at("operation") == "op-6",
        "全部操作成功后一次性提交最终电路");

    st::DeviceCatalog catalog;
    st::DeviceDescriptor nmos;
    nmos.master = "nmos";
    nmos.kind = st::DeviceKind::MosN;
    nmos.terminal_count = 4;
    nmos.terminal_index = {
        { st::TerminalRole::Drain, 0 }, { st::TerminalRole::Gate, 1 },
        { st::TerminalRole::Source, 2 }, { st::TerminalRole::Bulk, 3 }
    };
    nmos.normalized_to_cdf = { { "width", "w" }, { "length", "l" } };
    nmos.terminal_names_by_index = { "D", "G", "S", "B" };
    nmos.oa_library = "PDK";
    nmos.oa_cell = "nmos";
    nmos.oa_view = "symbol";
    nmos.limits.min_width = 100e-9;
    nmos.limits.max_width = 100e-6;
    nmos.limits.min_length = 100e-9;
    nmos.limits.max_length = 10e-6;
    nmos.voltage_domain = "core";
    nmos.allowed_voltage_domains.insert("core");
    catalog.Add(nmos, diagnostic);

    st::ChangeSet engineeringChanges;
    auto formalCascode = request("formal-1", "M0");
    auto& cascodePayload = std::get<st::CascodeTransformRequest>(formalCascode.payload);
    cascodePayload.voltage_domain = "core";
    CHECK(engineeringChanges.Confirm(formalCascode, diagnostic),
        "Change Set保存Cascode的完整请求快照");
    auto formalStack = request("formal-2", "M1", st::TransformType::MosStack);
    CHECK(engineeringChanges.Confirm(formalStack, diagnostic),
        "Change Set保存Stack级数、Gate和Bulk策略");
    st::Netlist generated;
    const auto generatedResult = engineeringChanges.Generate(base, generated, catalog);
    CHECK(generatedResult.ok && generatedResult.outcomes.size() == 2 &&
            generated.find("core")->find("M0_CAS") != nullptr &&
            generated.find("core")->find("M1") != nullptr &&
            generated.find("core")->find("M1_S1") != nullptr,
        "生成电路直接重放保存的完payload，不依赖UI当前表单");
    CHECK(generatedResult.parameter_groups.size() == 2 && generatedResult.iq_delta == 0.0,
        "Change Set合并四类变换的Sizing参数组和新增IQ元数据");

    st::OaPlanBuildContext oaContext;
    oaContext.source = { "SRC", "core", "schematic", "/src", "r1" };
    oaContext.target = { "STAGING", "core__staging", "schematic", "/staging", "r1" };
    oaContext.clone_map.push_back({ oaContext.source, oaContext.target, "/" });
    oaContext.hierarchy_by_subckt["core"] = "/";
    oaContext.preview = { "variant-1", "initial", "materializer-v1" };
    oaContext.locations = {
        { "/:M0", { 10.0, 10.0 } }, { "/:M0_CAS", { 10.0, 14.0 } },
        { "/:M1", { 20.0, 10.0 } }, { "/:M1_S1", { 20.0, 14.0 } },
    };
    const std::vector<std::string> visibleNets = {
        "M0_MID", "G0", "S0", "B0", "D0", "M1_MID1", "G1", "S1", "D1"
    };
    double wireY = 0.0;
    for (const auto& net : visibleNets) {
        oaContext.wires.push_back({ "/", net, { { 0.0, wireY }, { 1.0, wireY } } });
        wireY += 1.0;
    }
    const auto oaBuild = st::BuildOaMaterializationPlan(base, generated, catalog, oaContext);
    CHECK(oaBuild.ok() && oaBuild.plan.delete_instances.size() == 2 &&
            oaBuild.plan.create_instances.size() == 4,
        "最终Change Set网表可直接生成完整OA实例与连接计划");

    auto nlvt = nmos;
    nlvt.master = "nlvt";
    nlvt.oa_cell = "nlvt";
    nmos.compatible_masters.insert("nlvt");
    catalog.Add(nmos, diagnostic);
    catalog.Add(nlvt, diagnostic);

    st::ChangeSet mislabeledSame;
    auto sameWithOtherMaster = request("bad-same", "M0");
    std::get<st::CascodeTransformRequest>(sameWithOtherMaster.payload).new_master = "nlvt";
    CHECK(!mislabeledSame.Confirm(sameWithOtherMaster, diagnostic),
        "同型Cascode请求不能夹带不同master绕过类型语义");

    st::ChangeSet mislabeledCross;
    auto crossWithSameMaster = request("bad-cross", "M0", st::TransformType::CrossFlavorCascode);
    std::get<st::CascodeTransformRequest>(crossWithSameMaster.payload).new_master = "nmos";
    CHECK(mislabeledCross.Confirm(crossWithSameMaster, diagnostic),
        "跨Flavor请求在确认阶段保存完整目标master");
    st::Netlist rejectedCross;
    const auto rejectedCrossResult = mislabeledCross.Generate(base, rejectedCross, catalog);
    CHECK(!rejectedCrossResult.ok && !rejectedCrossResult.diagnostics.empty() &&
          rejectedCrossResult.diagnostics.front().code == st::DiagCode::DeviceIncompatible,
        "跨Flavor目标master与原master相同时在生成前拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "ChangeSet tests passed\n";
    } else {
        std::cout << failures << " ChangeSet tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
