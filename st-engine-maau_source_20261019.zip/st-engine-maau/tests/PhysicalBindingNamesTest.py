"""Production OA array bindings must identify exact exported scalar instances."""
import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server/site'))
import op_provider as op


class PhysicalBindingNamesTest(unittest.TestCase):
    def proof(self,classification='target'):
        return dict(oa_library='PDK',oa_cell='N',terminal_names=['D','G','S','B'],
                    model_name='n18_ckt',classification=classification)

    def catalog(self):
        return {'n18_ckt':[(dict(oa_library='PDK',oa_cell='N',terminal_names=['D','G','S','B'],
                                terminal_roles=['drain','gate','source','bulk']),{})]}

    def deck(self,names):
        return ('simulator lang=spectre\nsubckt core D G S B\n'+
                ''.join(n+' (D G S B) n18_ckt\n' for n in names)+
                'ends core\nTOP (d g 0 0) core\n')

    def bind(self,names,bindings):
        return op.bind_physical_devices(self.deck(names),'TOP','core',self.catalog(),bindings)

    def test_native_array_and_escaped_scalars_preserve_psf_names_and_proofs(self):
        names=[r'I93\<5\>.I2.M0',r'I93\<4\>.I2.M0',r'I21\<0\>']
        bindings={'I93<5:4>.I2.M0':self.proof('non_target'),'I21<0>':self.proof()}
        original=copy.deepcopy(bindings)
        result=self.bind(names,bindings)
        self.assertEqual(len(result),1)
        self.assertEqual(result[0][0]['output_name'],r'I21\<0\>')
        self.assertEqual(result[0][0]['path'],r'TOP.I21\<0\>')
        self.assertEqual(result[0][0]['nodes'],['d','g','0','0'])
        self.assertEqual(bindings,original)

    def test_nested_ascending_and_descending_arrays_consume_each_bit(self):
        names=[r'A\<0\>.B\<2\>.M',r'A\<0\>.B\<1\>.M',r'A\<1\>.B\<2\>.M',r'A\<1\>.B\<1\>.M']
        result=self.bind(names,{'A<0:1>.B<2:1>.M':self.proof()})
        self.assertEqual([d['output_name'] for d,_,_ in result],names)

    def test_actual_subcircuit_hierarchy_preserves_each_resolved_connection(self):
        deck=r'''simulator lang=spectre
subckt branch D G S B
M0 (D G S B) n18_ckt
ends branch
subckt core A B G S
I93\<1\> (A G S S) branch
I93\<0\> (B G S S) branch
ends core
TOP (left right gate 0) core
'''
        result=op.bind_physical_devices(deck,'TOP','core',self.catalog(),{'I93<1:0>.M0':self.proof()})
        self.assertEqual([d['nodes'] for d,_,_ in result],[['left','gate','0','0'],['right','gate','0','0']])
        self.assertEqual([d['path'] for d,_,_ in result],[r'TOP.I93\<1\>.M0',r'TOP.I93\<0\>.M0'])
        self.assertEqual([d['oa_instance_name'] for d,_,_ in result],['I93<1:0>.M0','I93<1:0>.M0'])

    def test_escaped_or_single_bit_ranges_are_supported(self):
        result=self.bind([r'M\<5\>'],{r'M\<5:5\>':self.proof()})
        self.assertEqual(len(result),1)

    def test_colliding_oa_names_and_duplicate_exported_names_are_rejected(self):
        cases=[(['M<5>'],{'M<5>':self.proof(),r'M\<5\>':self.proof()}),
               (['M<5>'],{'M<5:5>':self.proof(),'M<5>':self.proof()}),
               (['M<5>',r'M\<5\>'],{'M<5>':self.proof()})]
        for names,bindings in cases:
            with self.subTest(names=names,bindings=bindings),self.assertRaisesRegex(ValueError,'duplicate|ambiguous|collision'):
                self.bind(names,bindings)

    def test_unused_array_bits_and_missing_hierarchy_are_not_ignored(self):
        with self.assertRaisesRegex(ValueError,'not exported'):
            self.bind([r'M\<5\>'],{'M<5:4>':self.proof()})
        with self.assertRaisesRegex(ValueError,'binding missing'):
            self.bind([r'A\<5\>.I2.M0'],{'A<5>.M0':self.proof()})

    def test_target_identity_conflicts_still_fail_after_name_adaptation(self):
        for key,value in [('oa_cell','WRONG'),('model_name','WRONG'),('terminal_names',['G','D','S','B'])]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                proof=self.proof();proof[key]=value
                self.bind([r'M\<1\>'],{'M<1:1>':proof})

    def test_non_target_model_and_terminal_conflicts_still_fail(self):
        for key,value in [('model_name','WRONG'),('terminal_names',['D','G','S'])]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                proof=self.proof('non_target');proof[key]=value
                self.bind([r'M\<1\>'],{'M<1:1>':proof})

    def test_expansion_is_bounded_and_other_escape_characters_are_not_removed(self):
        with self.assertRaisesRegex(ValueError,'limit'):
            self.bind(['M<1>'],{'M<999999999:0>':self.proof()})
        with self.assertRaisesRegex(ValueError,'binding missing'):
            self.bind([r'M\x'],{'Mx':self.proof()})


if __name__=='__main__':unittest.main()
