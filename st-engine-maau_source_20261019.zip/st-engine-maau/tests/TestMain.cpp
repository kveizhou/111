// =============================================================
// TestMain.cpp — 引擎单元测试
// 数值基准全部来自真实 capless LDO 解剖（见 _analysis/server_report2.txt）：
//   I25 电流镜：G=VBN1=0.6607  S=VR=0.3791  D=VGA=0.6813 → VDS=0.302
//   MP 功率管 ：VG=0.6813  VS=1.1395  VD=0.7413 → |VDS|=0.398，ID≈8.2mA
// =============================================================
#include "st/Netlist.h"
#include "st/LegacyPrototype.h"
#include "st/Solver.h"
#include "st/Transform.h"
#include "st/Validate.h"

#include <cmath>
#include <iostream>
#include <string>

static int failures = 0;
#define CHECK(cond, msg)                                                     \
    do {                                                                     \
        if (!(cond)) { ++failures; std::cout << "FAIL: " << msg << "\n"; }   \
        else { std::cout << "ok:   " << msg << "\n"; }                       \
    } while (0)

static bool near(double a, double b, double eps = 1e-3) {
    return std::fabs(a - b) < eps;
}

// 真实 LDO core 的简化片段（器件名/网络/模型名与解剖结果一致）
static const char* kNetlistText = R"(// Generated for: spectre （测试片段）
subckt mirror_core VGA VBN1 VR AGND PVDD VOUT VGP VFB
    I25<51> (VGA VBN1 VR AGND) n18_ckt l=240n w=103n nf=4
+  nfin=4 mr=2
    C3 (VGP net_0175 AGND) mom_3t c=1p
    MP (VOUT VGP PVDD PVDD) p18_ckt l=134n w=166n nfin=6 mr=66
    Rfb (VOUT VFB) rhrpo_2t_ckt lr=8u wr=800n
ends mirror_core

subckt hv_core OUT G0 IN VSS AVDD
    parameters scale=2 mode=normal
    save M0:oppoint
    M0 (OUT G0 IN VSS) n18_ckt l=240n w=103n nf=4 nfin=4
ends hv_core
)";

static st::ModelDb makeDb() {
    st::ModelDb db;
    db["n18_ckt"]     = {st::DeviceKind::MosN, 4, false};
    db["p18_ckt"]     = {st::DeviceKind::MosP, 4, true}; // 允许源衬相连
    db["p18_lvt_ckt"] = {st::DeviceKind::MosP, 4, true}; // 假设的 lvt flavor
    db["n18_lvt_ckt"] = {st::DeviceKind::MosN, 4, false};
    db["rhrpo_2t_ckt"]= {st::DeviceKind::Resistor, 2, false};
    db["mom_3t"]      = {st::DeviceKind::Capacitor, 3, false};
    return db;
}

static st::Netlist parseFresh(std::vector<st::Diagnostic>& diags) {
    return st::parseSpectre(kNetlistText, diags);
}

int main() {
    auto db = makeDb();

    // ---------- 1. 解析 ----------
    {
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        CHECK(nl.subckts.size() == 2, "解析出 2 个 subckt");
        auto* s = nl.find("mirror_core");
        CHECK(s && s->instances.size() == 4, "mirror_core 有 4 个实例");
        auto* m = s ? s->find("I25<51>") : nullptr;
        CHECK(m != nullptr, "找到含尖括号的实例 I25<51>");
        CHECK(m && m->nets.size() == 4 && m->nets[0] == "VGA" && m->nets[3] == "AGND",
              "I25<51> 端子解析正确");
        CHECK(m && m->params.count("nfin") && m->params.at("nfin") == "4",
              "行首 + 续行的参数 nfin=4 被合入");
        CHECK(m && m->params.at("l") == "240n", "参数 l=240n 解析正确");
        auto* hv = nl.find("hv_core");
        CHECK(hv && hv->params.at("scale") == "2" &&
              hv->bodyDirectives == std::vector<std::string>({ "save M0:oppoint" }),
              "subckt参数和局部指令保留在原层级");
        const auto emitted = st::emitSpectre(nl);
        CHECK(emitted.find("subckt hv_core OUT G0 IN VSS AVDD\n    parameters mode=normal scale=2\n"
                           "    save M0:oppoint\n") != std::string::npos,
              "发射网表不会丢失subckt参数或把局部指令搬到全局");
        bool ok = false;
        CHECK(near(st::parseSuffixValue("166n", ok), 1.66e-7, 1e-15) && ok,
              "后缀数值 166n 解析");
        CHECK(near(st::parseSuffixValue("800n", ok), 8e-7, 1e-15) && ok,
              "后缀数值 800n 解析");
        CHECK(near(st::parseSuffixValue("1.5443148800M", ok), 1544314.88, 1e-8) && ok,
              "CDF大写M按兆解析，覆盖服务器800段电阻回读");
        CHECK(near(st::parseSuffixValue("1.5443148800m", ok), 0.00154431488, 1e-15) && ok,
              "小写m仍为毫，不与M混淆");
        CHECK(near(st::parseSuffixValue("1.5443148800MEG", ok), 1544314.88, 1e-8) && ok &&
              near(st::parseSuffixValue("1.5443148800meg", ok), 1544314.88, 1e-8) && ok,
              "已有meg/MEG兆单位保持兼容");
    }

    // ---------- 2. 求解器数值（真实算例）----------
    {
        // I25 cascode：Vx = 0.3791 + 0.10 + 0.05 = 0.5291；VBIAS = 0.5291 + 0.28 ≈ 0.81
        auto cb = st::solveCascodeBias(st::DeviceKind::MosN, 0.3791, 0.10, 0.05, 0.28);
        CHECK(near(cb.vx, 0.5291) && near(cb.vbias, 0.8091),
              "I25 cascode 偏置求解 Vx=0.5291 / VBIAS≈0.81");
        // PMOS 镜像
        auto cbp = st::solveCascodeBias(st::DeviceKind::MosP, 1.1395, 0.10, 0.05, 0.45);
        CHECK(near(cbp.vx, 0.9895) && near(cbp.vbias, 0.5395),
              "PMOS cascode 镜像求解");
        // 保留纯数值工具的历史回归；产品Source串联电阻不使用该值作默认。
        bool ok = false;
        double r = st::solveRdc(0.398, 8.2e-3, ok);
        CHECK(ok && near(r, 48.54, 0.01), "MP 直流等效 Rdc≈48.5Ω");
        CHECK(near(st::snapToGrid(48.54, 0.5), 48.5, 1e-9), "阻值量化 48.54→48.5");
    }

    // ---------- 3. 同型 cascode：I25（通过路径）----------
    {
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        st::CascodeOptions o;
        o.op.valid = true; o.op.vds = 0.302;      // I25 真实 VDS
        o.vdsat1 = o.vdsat2 = 0.10; o.margin = 0.05;
        o.nmosBulkNet = "AGND";
        // 旧入口也不再内联电阻分压，VBIAS由固定有源模板接管。
        auto out = st::applyCascode(nl, "mirror_core", "I25<51>", o, db);
        CHECK(out.ok(), "I25 cascode 通过校验并生成");
        auto* s = nl.find("mirror_core");
        auto* m1 = s->find("I25<51>");
        auto* m2 = s->find("I25<51>_CAS");
        CHECK(m1 && m1->nets[0] == "I25<51>_MID" && m1->nets[1] == "VBN1",
              "M1 漏极改接中间节点，栅保持原信号");
        CHECK(m2 && m2->nets[0] == "VGA" && m2->nets[1] == "VBIAS_1" &&
              m2->nets[2] == "I25<51>_MID" && m2->nets[3] == "AGND",
              "新管 M2 连接正确（D/VBIAS/X/bulk=AGND）");
        CHECK(m2 && m2->params.at("w") == "103n" && m2->params.at("l") == "240n",
              "M2 初值 1:1 继承原管");
        CHECK(!s->find("I25<51>_DIVT") && !s->find("I25<51>_DIVB"),
              "Cascode不内联生成电阻分压VBIAS");
        std::string emitted = st::emitSpectre(nl);
        CHECK(emitted.find("VBIAS_1") != std::string::npos &&
              emitted.find("I25<51>_CAS") != std::string::npos,
              "发射的网表包含新器件与新网络");
    }

    // ---------- 4. 异型 cascode 极性校验 ----------
    {
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        st::CascodeOptions o;
        o.newMaster = "p18_ckt";                  // N 管换 P 管 → 必须拒
        auto out = st::applyCascode(nl, "mirror_core", "I25<51>", o, db);
        CHECK(!out.ok() && out.diags[0].code == st::DiagCode::PolarityMismatch,
              "N↔P 混串被 PolarityMismatch 拒绝");
        std::vector<st::Diagnostic> d2;
        auto nl2 = parseFresh(d2);
        st::CascodeOptions o2;
        o2.newMaster = "n18_lvt_ckt";             // 同极性换 flavor → 放行
        auto out2 = st::applyCascode(nl2, "mirror_core", "I25<51>", o2, db);
        auto* m2 = nl2.find("mirror_core")->find("I25<51>_CAS");
        CHECK(out2.ok() && m2 && m2->model == "n18_lvt_ckt",
              "同极性 lvt flavor 放行");
    }

    // 同型/异型PMOS的旧入口也必须只改变原Drain。
    for (const auto& master : {std::string(""), std::string("p18_lvt_ckt")}) {
        for (bool sourceTied : {false, true}) {
            std::vector<st::Diagnostic> diags;
            auto nl = parseFresh(diags);
            st::CascodeOptions options;
            options.newMaster = master;
            options.sourceTiedBulk = sourceTied;
            const auto result = st::applyCascode(nl, "mirror_core", "MP", options, db);
            const auto* core = nl.find("mirror_core");
            const auto* original = core->find("MP");
            const auto* added = core->find("MP_CAS");
            CHECK(result.ok() && original && added &&
                  original->nets == std::vector<std::string>({"MP_MID", "VGP", "PVDD", "PVDD"}) &&
                  added->nets == std::vector<std::string>({"VOUT", "VBIAS_1", "MP_MID",
                                                         sourceTied ? "MP_MID" : "PVDD"}),
                  "旧入口同型/异型PMOS在D侧串管，原G/S/B不变，新增源衬策略跟随实际S");
        }
    }

    // ---------- 5. MP cascode：headroom 拒绝路径 ----------
    {
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        st::CascodeOptions o;
        o.op.valid = true; o.op.vds = 0.398;      // MP 真实 |VDS|
        o.vdsat1 = o.vdsat2 = 0.20; o.margin = 0.10; // 每管需 0.3V，共需 0.6V
        o.sourceTiedBulk = true;
        auto out = st::applyCascode(nl, "mirror_core", "MP", o, db);
        CHECK(!out.ok() && out.diags[0].code == st::DiagCode::HeadroomInsufficient,
              "MP cascode 被 headroom 校验拒绝（0.398V < 0.6V）");
        CHECK(nl.find("mirror_core")->instances.size() == 4,
              "拒绝后网表未被改动");
    }

    // ---------- 6. MP Source 串联电阻 ----------
    {
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        double r = 1000.0;
        st::ResistorOptions o;
        o.resModel = "rhrpo_2t_ckt";
        o.rTarget = r; o.rSeed = r;               // 带内
        auto out = st::applyResistor(nl, "mirror_core", "MP", o, db);
        CHECK(out.ok(), "MP Source串联电阻生成成功");
        auto* s = nl.find("mirror_core");
        auto* mp = s->find("MP");
        auto* req = s->find("MP_RS");
        CHECK(mp && mp->nets[0] == "VOUT" && mp->nets[1] == "VGP" &&
              mp->nets[2] == "MP_RS_INT" && mp->nets[3] == "PVDD",
              "原管MP保留Drain/Gate/Bulk，Source改接内部节点");
        CHECK(req && req->nets.size() == 2 && req->nets[0] == "MP_RS_INT" &&
              req->nets[1] == "PVDD", "电阻串在MOS Source与原Source网络之间");
        // 出带拒绝
        std::vector<st::Diagnostic> d2;
        auto nl2 = parseFresh(d2);
        st::ResistorOptions o2 = o;
        o2.rSeed = r; o2.rTarget = 3 * r;         // 超 2× 带
        auto out2 = st::applyResistor(nl2, "mirror_core", "MP", o2, db);
        CHECK(!out2.ok() && out2.diags[0].code == st::DiagCode::BadParam,
              "R 超 0.5~2×Rseed 搜索带被拒");
    }

    // ---------- 7. stack：天花板拒绝 + 正常生成 ----------
    {
        // 非法级数拒绝。
        std::vector<st::Diagnostic> diags;
        auto nl = parseFresh(diags);
        st::StackOptions o;
        o.n = 101;
        auto out = st::applyStack(nl, "hv_core", "M0", o, db);
        CHECK(!out.ok() && out.diags[0].code == st::DiagCode::BadParam,
              "stack N=101 超过产品上限时拒绝");
        CHECK(nl.find("hv_core")->instances.size() == 1, "拒绝后网表未被改动");

        // N=2共栅Stack。
        std::vector<st::Diagnostic> d2;
        auto nl2 = parseFresh(d2);
        st::StackOptions o2 = o;
        o2.n = 2;
        auto out2 = st::applyStack(nl2, "hv_core", "M0", o2, db);
        CHECK(out2.ok(), "stack N=2 通过校验并生成");
        auto* s = nl2.find("hv_core");
        auto* s0 = s->find("M0");
        auto* s1 = s->find("M0_S1");
        CHECK(s0 && s0->nets[0] == "OUT" && s0->nets[1] == "G0" &&
              s0->nets[2] == "M0_MID1",
              "Drain侧保留原M0实例名");
        CHECK(s1 && s1->nets[0] == "M0_MID1" && s1->nets[1] == "G0" &&
              s1->nets[2] == "IN", "M0_S1向Source侧展开且与M0共Gate");
        CHECK(nl2.find("stlad_M0_N2") == nullptr && s->find("M0_LAD") == nullptr,
              "同栅Stack不生成分压阶梯或独立VBIAS");
        std::string emitted = st::emitSpectre(nl2);
        CHECK(emitted.find("M0_S1") != std::string::npos,
              "发射网表包含特征化命名的Stack器件");
    }

    // ---------- 汇总 ----------
    std::cout << "\n========================================\n";
    if (failures == 0) std::cout << "全部测试通过\n";
    else std::cout << failures << " 项失败\n";
    return failures == 0 ? 0 : 1;
}
