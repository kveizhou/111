#!/usr/bin/env bash
set -euo pipefail

project_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
backend="$project_dir/server/st_virtuoso_backend.sh"
failures=0
test_root=$(mktemp -d "${TMPDIR:-/tmp}/st-server-backend-test.XXXXXX")
trap 'rm -rf "$test_root"' EXIT
# Fake backend processes belong to this test, never to an inherited site run.
export ST_BACKEND_RUN_ROOT="$test_root"

check() {
    local condition=$1
    local message=$2
    if [[ "$condition" == true ]]; then
        printf 'ok:   %s\n' "$message"
    else
        printf 'FAIL: %s\n' "$message"
        failures=$((failures + 1))
    fi
}

first_source_line() {
    local file=$1
    local text=$2
    grep -nF -- "$text" "$file" | awk -F: 'NR == 1 { print $1 }' || true
}

source_condition_deletes_path() {
    local file=$1
    local condition=$2
    local deletion=$3
    awk -v condition="$condition" -v deletion="$deletion" '
        index($0, condition) {
            if (getline > 0 && index($0, deletion)) {
                found = 1
                exit
            }
        }
        END { exit(found ? 0 : 1) }
    ' "$file"
}

source_has_order() {
    local source=$1
    shift
    local previous_line=0 token line
    for token in "$@"; do
        line=$(printf '%s\n' "$source" | grep -nF -- "$token" | \
            awk -F: 'NR == 1 { print $1 }' || true)
        [[ -n "$line" && "$line" -gt "$previous_line" ]] || return 1
        previous_line=$line
    done
}

skill_parentheses_balanced() {
    awk '
        BEGIN { depth = 0; in_string = 0 }
        {
            escaped = 0
            for (char_index = 1; char_index <= length($0); ++char_index) {
                character = substr($0, char_index, 1)
                if (in_string) {
                    if (escaped) {
                        escaped = 0
                    } else if (character == "\\\\") {
                        escaped = 1
                    } else if (character == "\"") {
                        in_string = 0
                    }
                    continue
                }
                if (character == ";") break
                if (character == "\"") {
                    in_string = 1
                } else if (character == "(") {
                    ++depth
                } else if (character == ")") {
                    --depth
                    if (depth < 0) exit 1
                }
            }
        }
        END { if (depth != 0 || in_string) exit 1 }
    ' "$1"
}

check "$([[ -x "$backend" ]] && printf true || printf false)" \
    "服务器后端 dispatcher 存在且可执行"

if [[ -x "$backend" ]]; then
    set +e
    output=$("$backend" unsupported 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 2 ]] && printf true || printf false)" \
        "未知后端动词返回退出码2"
    check "$([[ "$output" == *"unsupported backend verb"* ]] && printf true || printf false)" \
        "未知后端动词给出明确错误"
fi

for verb in probe_pdk scan_pdk run_op device_bindings snapshot clone materialize netlist publish open; do
    runner="$project_dir/server/bin/${verb}_runner.sh"
    check "$([[ -x "$runner" ]] && printf true || printf false)" \
        "$verb Runner 存在且可执行"
done

mkdir -p "$test_root/project" "$test_root/output with spaces"
test_root_real=$(cd "$test_root" && pwd -P)
printf 'DEFINE TEST %s\n' "$test_root/project" > "$test_root/project/cds.lib"
printf '; fake init\n' > "$test_root/init.il"

# Process contract only: real OA/CDF behavior requires Cadence acceptance.
cat > "$test_root/fake_bindings_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
[[ "$ST_BACKEND_ACTION_FILE" == */skill/device_bindings.il ]]
printf 'instance\toa_library\toa_cell\toa_view\tterminal_names\nM0\tPDK\tN\tsymbol\tD,G,S,B\n' > "$ST_REQ_BINDINGS_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
chmod +x "$test_root/fake_bindings_virtuoso.sh"
printf '; fixture adapter\n' > "$test_root/adapter.il"
ST_VIRTUOSO_BIN="$test_root/fake_bindings_virtuoso.sh" \
ST_PDK_TECH_ADAPTER="$test_root/adapter.il" ST_SKILL_INIT="$test_root/init.il" \
    "$backend" device-bindings --cds-lib "$test_root/project/cds.lib" \
    --lib SOURCE --cell CORE --view schematic --output "$test_root/physical_bindings.tsv"
check "$(grep -q '^M0' "$test_root/physical_bindings.tsv" && printf true || printf false)" \
    "physical OA bindings沿用批量Virtuoso入口并输出实例master和CDF端序"
set +e
ST_VIRTUOSO_BIN="$test_root/fake_bindings_virtuoso.sh" \
ST_PDK_TECH_ADAPTER="$test_root/adapter.il" ST_SKILL_INIT="$test_root/init.il" \
    "$backend" device-bindings --cds-lib "$test_root/project/cds.lib" \
    --lib SOURCE --cell CORE --view schematic --output "$test_root/physical_bindings.tsv" >/dev/null 2>&1
binding_status=$?
set -e
check "$([[ $binding_status -eq 64 ]] && printf true || printf false)" \
    "physical OA bindings拒绝覆盖已有证据文件"

run_op_runner="$project_dir/server/bin/run_op_runner.sh"
if [[ -x "$run_op_runner" ]]; then
    cat > "$test_root/fake_op_provider.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

while [[ $# -gt 0 ]]; do
    [[ "$1" == --* && $# -ge 2 ]] || exit 64
    case "$1" in
        --dut-lib) dut_lib=$2 ;;
        --dut-cell) dut_cell=$2 ;;
        --dut-view) dut_view=$2 ;;
        --bench-lib) bench_lib=$2 ;;
        --bench-cell) bench_cell=$2 ;;
        --bench-view) bench_view=$2 ;;
        --corner) corner=$2 ;;
        --dut-hash) dut_hash=$2 ;;
        --bench-hash) bench_hash=$2 ;;
        --pdk-version) pdk_version=$2 ;;
        --topology-hash) topology_hash=$2 ;;
        --parameter-hash) parameter_hash=$2 ;;
        --solver-version) solver_version=$2 ;;
        --identity-output) identity_output=$2 ;;
        --mos-output) mos_output=$2 ;;
        --resistor-output) resistor_output=$2 ;;
        --simulation-dir) simulation_dir=$2 ;;
        --dut-storage|--bench-storage) ;;
        *) exit 64 ;;
    esac
    shift 2
done
printf '%s|%s/%s/%s|%s/%s/%s|%s|%s|%s|%s\n' \
    "${ST_TEST_OP_MODE:-success}" \
    "${dut_lib:-}" "${dut_cell:-}" "${dut_view:-}" \
    "${bench_lib:-}" "${bench_cell:-}" "${bench_view:-}" \
    "${corner:-}" "${identity_output:-}" \
    "${mos_output:-}" "${simulation_dir:-}" \
    > "${ST_TEST_OP_CAPTURE:?}"

case "${ST_TEST_OP_MODE:-success}" in
    fail70) exit 70 ;;
    fail71) exit 71 ;;
    missing) exit 0 ;;
    malformed)
        printf 'wrong\theader\n' > "$identity_output"
        printf 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\n' \
            > "$mos_output"
        exit 0
        ;;
    symlink_output)
        printf 'dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\tparameter_hash\tsolver_version\ttotal_supply_current\n' > "$simulation_dir/identity-target.tsv"
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t0.002\n' "$dut_hash" "$bench_hash" "$pdk_version" "$corner" "$topology_hash" "$parameter_hash" "$solver_version" >> "$simulation_dir/identity-target.tsv"
        ln -s "$simulation_dir/identity-target.tsv" "$identity_output"
        printf 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\nM0\t1.2\t0.7\t0\t0\t0.001\t0.7\t1.2\t0\t0.4\t0.3\t1e-12\n' > "$mos_output"
        exit 0
        ;;
    fifo_output)
        mkfifo "$identity_output"
        printf 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\nM0\t1.2\t0.7\t0\t0\t0.001\t0.7\t1.2\t0\t0.4\t0.3\t1e-12\n' > "$mos_output"
        exit 0
        ;;
    directory_output)
        mkdir "$identity_output"
        printf 'retain\n' > "$identity_output/provider-file"
        printf 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\nM0\t1.2\t0.7\t0\t0\t0.001\t0.7\t1.2\t0\t0.4\t0.3\t1e-12\n' > "$mos_output"
        exit 0
        ;;
esac

printf 'dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\tparameter_hash\tsolver_version\ttotal_supply_current\n' \
    > "$identity_output"
identity_corner=$corner
identity_current=0.002
[[ "${ST_TEST_OP_MODE:-success}" == wrongcorner ]] && identity_corner=ss
[[ "${ST_TEST_OP_MODE:-success}" == overflow_identity ]] && identity_current=1e9999
printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$dut_hash" "$bench_hash" "$pdk_version" "$identity_corner" \
    "$topology_hash" "$parameter_hash" "$solver_version" "$identity_current" \
    >> "$identity_output"
printf 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\n' \
    > "$mos_output"
mos_vd=1.2
[[ "${ST_TEST_OP_MODE:-success}" == overflow_mos ]] && mos_vd=1e9999
printf 'M0\t%s\t0.7\t0\t0\t0.001\t0.7\t1.2\t0\t0.4\t0.3\t1e-12\n' "$mos_vd" \
    >> "$mos_output"
if [[ -n "${resistor_output:-}" && "${ST_TEST_OP_MODE:-success}" != missing_resistor ]]; then
    printf 'instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\tmax_voltage\tmax_power\tmax_current\trating_source\n' > "$resistor_output"
    if [[ "${ST_TEST_OP_MODE:-success}" == bad_resistor ]]; then
        printf 'R_REF_N\tpdk_r\tw=2u\t1.2\t0\tnan\t1.5\t1e-3\t0\tpdk/tt\n' >> "$resistor_output"
    else
        printf 'R_REF_N\tpdk_r\tw=2u\t1.2\t0\t1e-4\t1.5\t1e-3\t0\tpdk/tt\n' >> "$resistor_output"
    fi
fi
EOF
    chmod +x "$test_root/fake_op_provider.sh"

    run_op_common=(
        --cds-lib "$test_root/project/cds.lib"
        --dut-lib TEST --dut-cell core --dut-view schematic
        --bench-lib TEST_TB --bench-cell core_tb --bench-view schematic
        --corner 'tt 25/C'
        --dut-hash dut-a --bench-hash bench-a --pdk-version pdk-1
        --topology-hash topology-a --parameter-hash parameters-a
        --solver-version solver-1
    )
    op_identity="$test_root/output with spaces/op identity.tsv"
    op_mos="$test_root/output with spaces/op mos.tsv"
    op_capture="$test_root/op-capture.txt"
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$op_identity" --mos-output "$op_mos" 2>&1)
    status=$?
    op_sim_dir=$(awk -F'|' 'NR == 1 { print $7 }' "$op_capture")
    check "$([[ $status -eq 0 && -s "$op_identity" && -s "$op_mos" && \
        -d "$op_sim_dir" && "$op_sim_dir" == /* && \
        "$(awk -F'|' 'NR == 1 { print $2 "|" $3 "|" $4 }' "$op_capture")" == \
        'TEST/core/schematic|TEST_TB/core_tb/schematic|tt 25/C' && \
        "$(awk -F'|' 'NR == 1 { print $5 }' "$op_capture")" == "$test_root_real/output with spaces/op identity.tsv.tmp" && \
        "$(awk -F'|' 'NR == 1 { print $6 }' "$op_capture")" == "$test_root_real/output with spaces/op mos.tsv.tmp" ]] && printf true || printf false)" \
        "run-op只调用绝对路径provider，完整传递DUT/Bench/Corner并事务发布双TSV"
    check "$([[ "$output" == *"simulation directory retained: $op_sim_dir"* ]] && printf true || printf false)" \
        "run-op成功仍明确保留可追溯的原始仿真目录"

    resistor_dir="$test_root/op-resistor"
    mkdir -p "$resistor_dir"
    for file in identity mos resistor; do
        printf 'old %s\n' "$file" > "$resistor_dir/$file.tsv"
    done
    for op_mode in missing_resistor bad_resistor success; do
        set +e
        output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
            ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
            ST_TEST_OP_MODE="$op_mode" \
            "$backend" run-op "${run_op_common[@]}" \
            --identity-output "$resistor_dir/identity.tsv" \
            --mos-output "$resistor_dir/mos.tsv" \
            --resistor-output "$resistor_dir/resistor.tsv" 2>&1)
        status=$?
        set -e
        if [[ "$op_mode" == success ]]; then
            check "$([[ $status -eq 0 && \
                "$(head -1 "$resistor_dir/resistor.tsv")" == instance* && \
                ! -e "$resistor_dir/resistor.tsv.tmp" ]] && printf true || printf false)" \
                "run-op三份工作点证据一起校验并发布"
        else
            check "$([[ $status -eq 74 && \
                "$(cat "$resistor_dir/identity.tsv")" == 'old identity' && \
                "$(cat "$resistor_dir/mos.tsv")" == 'old mos' && \
                "$(cat "$resistor_dir/resistor.tsv")" == 'old resistor' ]] && printf true || printf false)" \
                "run-op的${op_mode}电阻证据失败时还原三份旧正式输出"
        fi
    done
    resistor_identity_before=$(cat "$resistor_dir/identity.tsv")
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$resistor_dir/identity.tsv" \
        --mos-output "$resistor_dir/mos.tsv" \
        --resistor-output "$resistor_dir/identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && \
        "$(cat "$resistor_dir/identity.tsv")" == "$resistor_identity_before" ]] && \
        printf true || printf false)" \
        "run-op在清理前拒绝电阻输出与身份输出重合"

    set +e
    output=$(env ST_OP_PROVIDER_BIN=relative-provider \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/relative-provider-id.tsv" \
        --mos-output "$test_root/relative-provider-mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 69 && "$output" == *"ST_OP_PROVIDER_BIN must be an absolute executable"* && \
        "$output" == *"simulation directory retained: /"* ]] && printf true || printf false)" \
        "run-op拒绝PATH或相对provider，返69并保留绝对仿真目录"

    set +e
    output=$(env -u ST_OP_PROVIDER_BIN ST_OP_RUN_ROOT="$test_root" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/missing-provider-id.tsv" \
        --mos-output "$test_root/missing-provider-mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 69 && "$output" == *"ST_OP_PROVIDER_BIN must be an absolute executable"* ]] && printf true || printf false)" \
        "run-op在provider未配置或不可执行时返69"

    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op --cds-lib "$test_root/project/cds.lib" \
        --dut-lib TEST --dut-cell core --dut-view schematic \
        --bench-lib TEST_TB --bench-cell core_tb \
        --corner tt --identity-output "$test_root/bad-bench-id.tsv" \
        --mos-output "$test_root/bad-bench-mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$output" == *"missing required option: --bench-view"* ]] && printf true || printf false)" \
        "run-op在调用provider前拒绝缺失Bench L/C/V并返64"

    for op_mode in fail70 fail71; do
        op_case_dir="$test_root/provider-$op_mode"
        mkdir -p "$op_case_dir"
        printf 'old identity\n' > "$op_case_dir/identity.tsv"
        printf 'old mos\n' > "$op_case_dir/mos.tsv"
        printf 'old identity temp\n' > "$op_case_dir/identity.tsv.tmp"
        printf 'old mos temp\n' > "$op_case_dir/mos.tsv.tmp"
        set +e
        output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
            ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
            ST_TEST_OP_MODE="$op_mode" \
            "$backend" run-op "${run_op_common[@]}" \
            --identity-output "$op_case_dir/identity.tsv" \
            --mos-output "$op_case_dir/mos.tsv" 2>&1)
        status=$?
        set -e
        expected_status=${op_mode#fail}
        check "$([[ $status -eq $expected_status && \
            "$(cat "$op_case_dir/identity.tsv")" == 'old identity' && \
            "$(cat "$op_case_dir/mos.tsv")" == 'old mos' && \
            "$(cat "$op_case_dir/identity.tsv.tmp")" == 'old identity temp' && \
            "$(cat "$op_case_dir/mos.tsv.tmp")" == 'old mos temp' && \
            "$output" == *"simulation directory retained: /"* ]] && printf true || printf false)" \
            "run-op传播${expected_status}失败、保留仿真目录并还原调用前四个输出"
    done

    dangling_dir="$test_root/op-dangling"
    mkdir -p "$dangling_dir"
    ln -s "$dangling_dir/missing-old-identity" "$dangling_dir/identity.tsv"
    ln -s "$dangling_dir/missing-old-mos" "$dangling_dir/mos.tsv"
    ln -s "$dangling_dir/missing-old-identity-temp" "$dangling_dir/identity.tsv.tmp"
    ln -s "$dangling_dir/missing-old-mos-temp" "$dangling_dir/mos.tsv.tmp"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        ST_TEST_OP_MODE=fail70 \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$dangling_dir/identity.tsv" \
        --mos-output "$dangling_dir/mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 70 && -L "$dangling_dir/identity.tsv" && \
        -L "$dangling_dir/mos.tsv" && -L "$dangling_dir/identity.tsv.tmp" && \
        -L "$dangling_dir/mos.tsv.tmp" && \
        "$(readlink "$dangling_dir/identity.tsv")" == "$dangling_dir/missing-old-identity" && \
        "$(readlink "$dangling_dir/mos.tsv")" == "$dangling_dir/missing-old-mos" && \
        "$(readlink "$dangling_dir/identity.tsv.tmp")" == "$dangling_dir/missing-old-identity-temp" && \
        "$(readlink "$dangling_dir/mos.tsv.tmp")" == "$dangling_dir/missing-old-mos-temp" ]] && printf true || printf false)" \
        "run-op容许保护symlink对象并在失败后原样恢复四个悬空链接"

    for op_mode in missing malformed; do
        op_case_dir="$test_root/provider-$op_mode"
        mkdir -p "$op_case_dir"
        set +e
        output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
            ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
            ST_TEST_OP_MODE="$op_mode" \
            "$backend" run-op "${run_op_common[@]}" \
            --identity-output "$op_case_dir/identity.tsv" \
            --mos-output "$op_case_dir/mos.tsv" 2>&1)
        status=$?
        set -e
        check "$([[ $status -eq 74 && "$output" == *"simulation directory retained: /"* && \
            ! -e "$op_case_dir/identity.tsv" && ! -e "$op_case_dir/mos.tsv" ]] && printf true || printf false)" \
            "run-op将$op_mode provider结果判为74且不发布不完整TSV"
    done

    for op_mode in wrongcorner overflow_identity overflow_mos symlink_output fifo_output directory_output; do
        op_case_dir="$test_root/provider-$op_mode"
        mkdir -p "$op_case_dir"
        printf 'old identity\n' > "$op_case_dir/identity.tsv"
        printf 'old mos\n' > "$op_case_dir/mos.tsv"
        set +e
        output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
            ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
            ST_TEST_OP_MODE="$op_mode" \
            "$backend" run-op "${run_op_common[@]}" \
            --identity-output "$op_case_dir/identity.tsv" \
            --mos-output "$op_case_dir/mos.tsv" 2>&1)
        status=$?
        set -e
        check "$([[ $status -eq 74 && \
            "$(cat "$op_case_dir/identity.tsv")" == 'old identity' && \
            "$(cat "$op_case_dir/mos.tsv")" == 'old mos' ]] && printf true || printf false)" \
            "run-op将${op_mode}判为74并恢复旧正式输出"
    done

    mkdir -p "$test_root/op-existing-directory/identity.tsv"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-existing-directory/identity.tsv" \
        --mos-output "$test_root/op-existing-directory/mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && -d "$test_root/op-existing-directory/identity.tsv" ]] && printf true || printf false)" \
        "run-op在移动前拒绝已有目录且不破坏它"

    mkdir -p "$test_root/op-existing-fifo"
    mkfifo "$test_root/op-existing-fifo/identity.tsv"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-existing-fifo/identity.tsv" \
        --mos-output "$test_root/op-existing-fifo/mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && -p "$test_root/op-existing-fifo/identity.tsv" ]] && printf true || printf false)" \
        "run-op在移动前拒绝已有FIFO且不挂起或破坏它"

    mkdir -p "$test_root/op-canonical/same"
    printf 'must remain\n' > "$test_root/op-canonical/one.tsv"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-canonical/same/../one.tsv" \
        --mos-output "$test_root/op-canonical/one.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/op-canonical/one.tsv")" == 'must remain' ]] && printf true || printf false)" \
        "run-op在任何清理前拒绝规范化后相同的双输出"

    mkdir -p "$test_root/op-hardlink"
    printf 'hardlink remains\n' > "$test_root/op-hardlink/identity.tsv"
    ln "$test_root/op-hardlink/identity.tsv" "$test_root/op-hardlink/mos.tsv"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-hardlink/identity.tsv" \
        --mos-output "$test_root/op-hardlink/mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/op-hardlink/identity.tsv")" == 'hardlink remains' && \
        "$(cat "$test_root/op-hardlink/mos.tsv")" == 'hardlink remains' ]] && printf true || printf false)" \
        "run-op在清理前拒绝正式输出硬链接同一inode"

    mkdir -p "$test_root/op-symlink"
    printf 'symlink remains\n' > "$test_root/op-symlink/identity.tsv"
    ln -s "$test_root/op-symlink/identity.tsv" "$test_root/op-symlink/mos.tsv"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-symlink/identity.tsv" \
        --mos-output "$test_root/op-symlink/mos.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/op-symlink/identity.tsv")" == 'symlink remains' && \
        "$(cat "$test_root/op-symlink/mos.tsv")" == 'symlink remains' ]] && printf true || printf false)" \
        "run-op在清理前拒绝正式输出符号链接同一inode"

    mkdir -p "$test_root/op-temp-cross"
    printf 'identity remains\n' > "$test_root/op-temp-cross/identity.tsv"
    printf 'mos remains\n' > "$test_root/op-temp-cross/identity.tsv.tmp"
    set +e
    output=$(env ST_OP_PROVIDER_BIN="$test_root/fake_op_provider.sh" \
        ST_OP_RUN_ROOT="$test_root" ST_TEST_OP_CAPTURE="$op_capture" \
        "$backend" run-op "${run_op_common[@]}" \
        --identity-output "$test_root/op-temp-cross/identity.tsv" \
        --mos-output "$test_root/op-temp-cross/identity.tsv.tmp" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/op-temp-cross/identity.tsv")" == 'identity remains' && \
        "$(cat "$test_root/op-temp-cross/identity.tsv.tmp")" == 'mos remains' ]] && printf true || printf false)" \
        "run-op在清理前拒绝正式输出与另一.tmp输出冲突"
fi

if [[ -x "$project_dir/server/bin/snapshot_runner.sh" ]]; then
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/not-a-command" \
        ST_SKILL_INIT="$test_root/init.il" \
        "$backend" snapshot \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic --core-subckt core \
        --netlist-output "$test_root/output with spaces/core.scs" \
        --catalog-output "$test_root/output with spaces/catalog.tsv" \
        --geometry-output "$test_root/output with spaces/geometry.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 69 ]] && printf true || printf false)" \
        "Cadence 可执行程序不存在时返回退出码69"
    check "$([[ "$output" == *"Virtuoso executable"* ]] && printf true || printf false)" \
        "Cadence 缺失错误可直接定位"

    cat > "$test_root/fake_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf '%s|%s|%s|%s\n' \
    "$ST_REQ_LIB" "$ST_REQ_CELL" "$ST_REQ_VIEW" "$ST_REQ_NETLIST_OUTPUT" \
    > "$ST_TEST_CAPTURE"
if [[ -n "${ST_TEST_POLICY_CAPTURE:-}" ]]; then
    printf '%s\n' "$ST_DEVICE_POLICY" > "$ST_TEST_POLICY_CAPTURE"
fi
printf 'subckt %s P N\nends %s\n' "$ST_REQ_CORE_SUBCKT" "$ST_REQ_CORE_SUBCKT" \
    > "$ST_REQ_NETLIST_OUTPUT"
if [[ "$ST_REQ_EXPORT_MODE" == snapshot ]]; then
    printf 'master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\n' \
        > "$ST_REQ_CATALOG_OUTPUT"
    printf 'instance\tx\ty\nI0\t0\t0\n' > "$ST_REQ_GEOMETRY_OUTPUT"
fi
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_virtuoso.sh"

    capture="$test_root/capture.txt"
    env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$capture" \
        "$backend" snapshot \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic --core-subckt core \
        --netlist-output "$test_root/output with spaces/core.scs" \
        --catalog-output "$test_root/output with spaces/catalog.tsv" \
        --geometry-output "$test_root/output with spaces/geometry.tsv"
    check "$([[ "$(cat "$capture")" == "TEST|core|schematic|$test_root/output with spaces/core.scs" ]] && printf true || printf false)" \
        "snapshot 参数通过环境无损传入 Virtuoso"

    policy_capture="$test_root/policy-capture.txt"
    printf 'oa_library\toa_cell\tkind\nPDK\tn\tmos_n\n' > "$test_root/scanned-policy.tsv"
    env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$capture" \
        ST_TEST_POLICY_CAPTURE="$policy_capture" \
        "$backend" snapshot \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic --core-subckt core \
        --netlist-output "$test_root/output with spaces/policy-core.scs" \
        --catalog-output "$test_root/output with spaces/policy-catalog.tsv" \
        --geometry-output "$test_root/output with spaces/policy-geometry.tsv" \
        --device-policy "$test_root/scanned-policy.tsv"
    check "$([[ "$(cat "$policy_capture")" == "$test_root/scanned-policy.tsv" ]] && printf true || printf false)" \
        "snapshot把本会话扫描得到的器件策略交给SKILL导出器"
    env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$capture" \
        ST_TEST_POLICY_CAPTURE="$policy_capture" \
        "$backend" netlist \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic --core-subckt core \
        --output "$test_root/output with spaces/policy-roundtrip.scs" \
        --device-policy "$test_root/scanned-policy.tsv"
    check "$([[ "$(cat "$policy_capture")" == "$test_root/scanned-policy.tsv" ]] && printf true || printf false)" \
        "回读网表复用同一份动态器件策略"

    cat > "$test_root/fake_without_marker.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf 'subckt core P N\nends core\n' > "$ST_REQ_NETLIST_OUTPUT"
printf 'catalog\n' > "$ST_REQ_CATALOG_OUTPUT"
printf 'geometry\n' > "$ST_REQ_GEOMETRY_OUTPUT"
EOF
    chmod +x "$test_root/fake_without_marker.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_without_marker.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        "$backend" snapshot \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic --core-subckt core \
        --netlist-output "$test_root/no-marker.scs" \
        --catalog-output "$test_root/no-marker-catalog.tsv" \
        --geometry-output "$test_root/no-marker-geometry.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 70 ]] && printf true || printf false)" \
        "Virtuoso 未写完成标记时返回退出码70"

    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        "$backend" clone \
        --cds-lib "$test_root/project/cds.lib" --hierarchy / \
        --source-lib TEST --source-cell core --source-view schematic \
        --source-storage "$test_root/project" \
        --target-lib TEST --target-cell core --target-view schematic \
        --target-storage "$test_root/project" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$output" == *"must be different"* ]] && printf true || printf false)" \
        "clone 在调用 Virtuoso 前拒绝覆盖源 cellview"
fi

if [[ -x "$project_dir/server/bin/scan_pdk_runner.sh" ]]; then
    set +e
    output=$(env ST_PDK_TECH_ADAPTER=relative/site_tech_adapter.il \
        ST_VIRTUOSO_BIN="$test_root/not-called-virtuoso" \
        ST_SKILL_INIT="$test_root/init.il" \
        "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/invalid-adapter-catalog.tsv" \
        --identity-output "$test_root/invalid-adapter-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$output" == *"ST_PDK_TECH_ADAPTER must be an absolute readable file"* ]] && printf true || printf false)" \
        "scan-pdk在调用Virtuoso前拒绝相对或不可读的现场PDK元数据适配器"

    cat > "$test_root/fake_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${ST_TEST_EXPECT_CLEAN_OUTPUTS:-false}" == true ]]; then
    [[ ! -e "$ST_REQ_CATALOG_OUTPUT" && ! -e "$ST_REQ_IDENTITY_OUTPUT" &&
       ! -e "${ST_REQ_CATALOG_OUTPUT}.tmp" &&
       ! -e "${ST_REQ_IDENTITY_OUTPUT}.tmp" ]] || exit 88
fi
printf '%s|%s|%s|%s|%s|%s\n' \
    "$ST_REQ_LIB" "$ST_REQ_CELL" "$ST_REQ_VIEW" \
    "$ST_REQ_CATALOG_OUTPUT" "$ST_REQ_IDENTITY_OUTPUT" \
    "$ST_BACKEND_ACTION_FILE" > "$ST_TEST_CAPTURE"
printf '%b\n' 'master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\tnormalized_to_cdf\tmin_width\tmax_width\tmin_length\tmax_length\tmin_resistance\tmax_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\tallowed_voltage_domains\tisolated_well\tsource_drain_interchangeable\tpdk_name\tpdk_version\tmodel_name\tw_fin_formula\tparameter_constraints\tmodel_sections\tcorners\treliability_complete\tbulk_rule_complete' > "$ST_REQ_CATALOG_OUTPUT"
printf '%b\n' 'oa_PDK__n18\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn18\tsymbol\tcore\twidth:w\t1e-7\t1e-3\t1e-7\t1e-5\t\t\t1.2\t1.2\t1.2\t100\tcore\ttrue\ttrue\tPDK_TECH\t1.0\tn18\t\twidth:w:1e-7:1e-3:1e-8:\ttt\ttt\ttrue\ttrue' >> "$ST_REQ_CATALOG_OUTPUT"
printf 'source_library\tprocess_identity\tidentity_source\tcontext_complete\tmodel_context_complete\tscan_complete\tdiagnostic\tcandidate_libraries\nSRC\tPDK_TECH\ttech_attachment\ttrue\tfalse\ttrue\t\tPDK\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_scan_virtuoso.sh"
    scan_capture="$test_root/scan-capture.txt"
    env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/output with spaces/pdk-catalog.tsv" \
        --identity-output "$test_root/output with spaces/pdk-identity.tsv"
    check "$([[ "$(cat "$scan_capture")" == "TEST|core|schematic|$test_root_real/output with spaces/pdk-catalog.tsv|$test_root_real/output with spaces/pdk-identity.tsv|"*scan_pdk.il ]] && printf true || printf false)" \
        "scan-pdk将当前DUT和双输出路径无损传入Virtuoso"
    check "$(awk -F '\t' 'NR == 1 { header = NF } NR == 2 { row = NF } END { if (header == 31 && row == header) print "true" }' "$test_root/output with spaces/pdk-catalog.tsv")" \
        "scan-pdk成功夹具输出完整Task2 TSV schema和可解析记录"
    check "$(awk -F '\t' 'NR == 1 { for (i=1;i<=NF;i++) c[$i]=i } NR == 2 && $(c["model_context_complete"]) == "false" && $(c["scan_complete"]) == "true" { print "true" }' "$test_root/output with spaces/pdk-identity.tsv")" \
        "当前模型上下文缺失时保持incomplete但不伪造为扫描失败或完成上下文"
    cp "$test_root/output with spaces/pdk-catalog.tsv" "$test_root/valid-scan-catalog.tsv"

    mkdir -p "$test_root/runner-cleans-four-paths"
    printf 'stale catalog\n' > "$test_root/runner-cleans-four-paths/catalog.tsv"
    printf 'stale identity\n' > "$test_root/runner-cleans-four-paths/identity.tsv"
    printf 'stale catalog temp\n' > "$test_root/runner-cleans-four-paths/catalog.tsv.tmp"
    printf 'stale identity temp\n' > "$test_root/runner-cleans-four-paths/identity.tsv.tmp"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        ST_TEST_EXPECT_CLEAN_OUTPUTS=true \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/runner-cleans-four-paths/catalog.tsv" \
        --identity-output "$test_root/runner-cleans-four-paths/identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 0 && ! -e "$test_root/runner-cleans-four-paths/catalog.tsv.tmp" && ! -e "$test_root/runner-cleans-four-paths/identity.tsv.tmp" && "$(head -n 1 "$test_root/runner-cleans-four-paths/catalog.tsv")" != 'stale catalog' && "$(head -n 1 "$test_root/runner-cleans-four-paths/identity.tsv")" != 'stale identity' ]] && printf true || printf false)" \
        "scan-pdk仅在四路径冲突校验通过后，于调用Virtuoso前清理正式和临时输出"

    cat > "$test_root/fake_header_only_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
head -n 1 "$ST_TEST_VALID_CATALOG" > "$ST_REQ_CATALOG_OUTPUT"
printf 'source_library\tprocess_identity\tidentity_source\tcontext_complete\tmodel_context_complete\tscan_complete\tdiagnostic\tcandidate_libraries\nSRC\tPDK_TECH\ttech_attachment\ttrue\tfalse\ttrue\t\tPDK\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_header_only_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_header_only_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        ST_TEST_VALID_CATALOG="$test_root/valid-scan-catalog.tsv" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/header-only-catalog.tsv" \
        --identity-output "$test_root/header-only-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"scan output validation failed"* && ! -e "$test_root/header-only-catalog.tsv" && ! -e "$test_root/header-only-identity.tsv" ]] && printf true || printf false)" \
        "scan-pdk拒绝header-only catalog而不把零器件扫描当成功"

    cat > "$test_root/fake_incomplete_identity_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
cp "$ST_TEST_VALID_CATALOG" "$ST_REQ_CATALOG_OUTPUT"
printf 'source_library\tprocess_identity\tidentity_source\tcontext_complete\tmodel_context_complete\tscan_complete\tdiagnostic\tcandidate_libraries\nSRC\tPDK_TECH\ttech_attachment\ttrue\tfalse\tfalse\tno accepted primitive\tPDK\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_incomplete_identity_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_incomplete_identity_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        ST_TEST_VALID_CATALOG="$test_root/valid-scan-catalog.tsv" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/incomplete-catalog.tsv" \
        --identity-output "$test_root/incomplete-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"scan output validation failed"* && ! -e "$test_root/incomplete-catalog.tsv" && ! -e "$test_root/incomplete-identity.tsv" ]] && printf true || printf false)" \
        "scan-pdk拒绝scan_complete=false的identity证据"

    cat > "$test_root/fake_unverified_library_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
awk -F '\t' 'BEGIN { OFS="\t" } NR == 1 { print; next } { $5="DUT_USER"; print }' \
    "$ST_TEST_VALID_CATALOG" > "$ST_REQ_CATALOG_OUTPUT"
printf 'source_library\tprocess_identity\tidentity_source\tcontext_complete\tmodel_context_complete\tscan_complete\tdiagnostic\tcandidate_libraries\nSRC\tPDK_TECH\ttech_attachment\ttrue\tfalse\ttrue\t\tPDK\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_unverified_library_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_unverified_library_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        ST_TEST_VALID_CATALOG="$test_root/valid-scan-catalog.tsv" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/unverified-catalog.tsv" \
        --identity-output "$test_root/unverified-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"scan output validation failed"* && ! -e "$test_root/unverified-catalog.tsv" && ! -e "$test_root/unverified-identity.tsv" ]] && printf true || printf false)" \
        "scan-pdk拒绝不在已证明candidate_libraries中的same-tech用户库记录"

    relative_capture="$test_root/relative-scan-capture.txt"
    set +e
    (
        cd "$test_root"
        env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
            ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$relative_capture" \
            "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
            --lib TEST --cell core --view schematic \
            --catalog-output direct-catalog.tsv \
            --identity-output nested/direct-identity.tsv
    )
    status=$?
    set -e
    check "$([[ $status -eq 0 && -f "$relative_capture" && "$(cat "$relative_capture")" == "TEST|core|schematic|$test_root_real/direct-catalog.tsv|$test_root_real/nested/direct-identity.tsv|"*scan_pdk.il && -s "$test_root/direct-catalog.tsv" && -s "$test_root/nested/direct-identity.tsv" ]] && printf true || printf false)" \
        "scan-pdk在切换到Cadence项目目录前固定单文件和子目录相对输出的绝对路径"

    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/catalog.tsv" \
        --identity-output "$test_root/identity.tsv" --unexpected value 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$output" == *"unsupported option: --unexpected"* ]] && printf true || printf false)" \
        "scan-pdk在调用Virtuoso前拒绝未知参数"

    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/catalog.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$output" == *"missing required option: --identity-output"* ]] && printf true || printf false)" \
        "scan-pdk在调用Virtuoso前拒绝缺失参数"

    mkdir -p "$test_root/same"
    printf 'must remain\n' > "$test_root/collision.tsv"
    set +e
    output=$(
        cd "$test_root" && env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
            ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
            "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
            --lib TEST --cell core --view schematic \
            --catalog-output same/../collision.tsv \
            --identity-output collision.tsv 2>&1
    )
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/collision.tsv")" == "must remain" ]] && printf true || printf false)" \
        "scan-pdk在清理前拒绝规范化后相同的双输出路径"

    mkdir -p "$test_root/same-inode-hardlink"
    printf 'hardlink must remain\n' > "$test_root/same-inode-hardlink/catalog.tsv"
    ln "$test_root/same-inode-hardlink/catalog.tsv" \
        "$test_root/same-inode-hardlink/identity.tsv"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/same-inode-hardlink/catalog.tsv" \
        --identity-output "$test_root/same-inode-hardlink/identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -ne 0 && "$(cat "$test_root/same-inode-hardlink/catalog.tsv")" == "hardlink must remain" && "$(cat "$test_root/same-inode-hardlink/identity.tsv")" == "hardlink must remain" ]] && printf true || printf false)" \
        "scan-pdk在rm前拒绝catalog/identity硬链接同一inode并保留旧输出"

    mkdir -p "$test_root/same-inode-symlink"
    printf 'symlink must remain\n' > "$test_root/same-inode-symlink/catalog.tsv"
    ln -s "$test_root/same-inode-symlink/catalog.tsv" \
        "$test_root/same-inode-symlink/identity.tsv"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/same-inode-symlink/catalog.tsv" \
        --identity-output "$test_root/same-inode-symlink/identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -ne 0 && "$(cat "$test_root/same-inode-symlink/catalog.tsv")" == "symlink must remain" && "$(cat "$test_root/same-inode-symlink/identity.tsv")" == "symlink must remain" ]] && printf true || printf false)" \
        "scan-pdk在rm前拒绝catalog/identity符号链接同一inode并保留旧输出"

    mkdir -p "$test_root/tmp-cross"
    printf 'catalog must remain\n' > "$test_root/tmp-cross/catalog.tsv"
    printf 'identity must remain\n' > "$test_root/tmp-cross/catalog.tsv.tmp"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/tmp-cross/catalog.tsv" \
        --identity-output "$test_root/tmp-cross/catalog.tsv.tmp" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/tmp-cross/catalog.tsv")" == "catalog must remain" && "$(cat "$test_root/tmp-cross/catalog.tsv.tmp")" == "identity must remain" ]] && printf true || printf false)" \
        "scan-pdk在清理前拒绝catalog临时路径等于identity正式路径"

    mkdir -p "$test_root/tmp-cross-reverse"
    printf 'reverse catalog must remain\n' > "$test_root/tmp-cross-reverse/identity.tsv.tmp"
    printf 'reverse identity must remain\n' > "$test_root/tmp-cross-reverse/identity.tsv"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$scan_capture" \
        "$backend" scan-pdk --cds-lib "$test_root/project/cds.lib" \
        --lib TEST --cell core --view schematic \
        --catalog-output "$test_root/tmp-cross-reverse/identity.tsv.tmp" \
        --identity-output "$test_root/tmp-cross-reverse/identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 64 && "$(cat "$test_root/tmp-cross-reverse/identity.tsv.tmp")" == "reverse catalog must remain" && "$(cat "$test_root/tmp-cross-reverse/identity.tsv")" == "reverse identity must remain" ]] && printf true || printf false)" \
        "scan-pdk在清理前拒绝identity临时路径等于catalog正式路径"

    cat > "$test_root/fake_failed_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
exit 9
EOF
    chmod +x "$test_root/fake_failed_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_failed_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/failed-catalog.tsv" \
        --identity-output "$test_root/failed-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 9 ]] && printf true || printf false)" \
        "scan-pdk传播Virtuoso非零退出"

    cat > "$test_root/fake_missing_catalog_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf 'source_library\tprocess_identity\nSRC\tPDK_TECH\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_missing_catalog_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_missing_catalog_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/missing-catalog.tsv" \
        --identity-output "$test_root/present-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"device catalog was not generated or is empty"* ]] && printf true || printf false)" \
        "scan-pdk退出0但catalog缺失时失败"

    cat > "$test_root/fake_missing_identity_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf 'master\tkind\nPDK/n18\tmos_n\n' > "$ST_REQ_CATALOG_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_missing_identity_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_missing_identity_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/present-catalog.tsv" \
        --identity-output "$test_root/missing-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"PDK identity was not generated or is empty"* ]] && printf true || printf false)" \
        "scan-pdk退出0但identity缺失时失败"

    cat > "$test_root/fake_empty_scan_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
: > "$ST_REQ_CATALOG_OUTPUT"
printf 'pdk_name\tpdk_version\nPDK\t1.0\n' > "$ST_REQ_IDENTITY_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
    chmod +x "$test_root/fake_empty_scan_virtuoso.sh"
    set +e
    output=$(env ST_VIRTUOSO_BIN="$test_root/fake_empty_scan_virtuoso.sh" \
        ST_SKILL_INIT="$test_root/init.il" \
        "$backend" scan-pdk \
        --cds-lib "$test_root/project/cds.lib" --lib TEST --cell core \
        --view schematic --catalog-output "$test_root/empty-catalog.tsv" \
        --identity-output "$test_root/nonempty-identity.tsv" 2>&1)
    status=$?
    set -e
    check "$([[ $status -eq 74 && "$output" == *"device catalog was not generated or is empty"* ]] && printf true || printf false)" \
        "scan-pdk退出0但任一输出为空时仍失败"
fi

scan_skill="$project_dir/server/skill/scan_pdk.il"
tech_scan_adapter="$project_dir/server/skill/tech_adapter.il"
common_skill="$project_dir/server/skill/backend_common.il"
scan_publish_source=$(awk '
    /procedure\(stScanPdk\(\)/ { capture=1 }
    capture { print }
    capture && /^\)$/ { exit }
' "$scan_skill")
scan_conflict_line=$(first_source_line "$scan_skill" 'when(stScanPathsConflictP(list(catalogPath identityPath catalogTempPath identityTempPath))')
scan_refusal_line=$(first_source_line "$scan_skill" 'when(or(isFile(catalogPath) isFile(identityPath) isFile(catalogTempPath) isFile(identityTempPath))')
scan_cleanup_registration_line=$(first_source_line "$scan_skill" 'stScanIdentityTempPath = identityTempPath')
scan_catalog_temp_created_line=$(first_source_line "$scan_skill" 'stScanCatalogTempCreated = t')
scan_identity_temp_created_line=$(first_source_line "$scan_skill" 'stScanIdentityTempCreated = t')
scan_catalog_rename_line=$(first_source_line "$scan_skill" 'renameResult = errset(renameFile(stScanCatalogTempPath catalogPath) t)')
scan_catalog_published_line=$(first_source_line "$scan_skill" 'stScanCatalogPublished = t')
scan_identity_rename_line=$(first_source_line "$scan_skill" 'renameResult = errset(renameFile(stScanIdentityTempPath identityPath) t)')
scan_identity_published_line=$(first_source_line "$scan_skill" 'stScanIdentityPublished = t')
scan_order_tokens=(
    'when(stScanPathsConflictP(list(catalogPath identityPath catalogTempPath identityTempPath))'
    'when(or(isFile(catalogPath) isFile(identityPath) isFile(catalogTempPath) isFile(identityTempPath))'
    'stScanIdentityTempPath = identityTempPath'
    'stScanCatalogTempCreated = t'
    'stScanIdentityTempCreated = t'
    'renameResult = errset(renameFile(stScanCatalogTempPath catalogPath) t)'
    'stScanCatalogPublished = t'
    'renameResult = errset(renameFile(stScanIdentityTempPath identityPath) t)'
    'stScanIdentityPublished = t'
)
scan_order_broken_source=$(printf '%s\n' \
    "${scan_order_tokens[0]}" "${scan_order_tokens[1]}" \
    "${scan_order_tokens[2]}" "${scan_order_tokens[3]}" \
    "${scan_order_tokens[4]}" "${scan_order_tokens[5]}" \
    "${scan_order_tokens[7]}" "${scan_order_tokens[6]}" \
    "${scan_order_tokens[8]}")
set +e
source_has_order "$scan_order_broken_source" "${scan_order_tokens[@]}"
scan_order_mutation_status=$?
set -e
check "$(grep -q 'libraryObject~>cells' "$scan_skill" && ! grep -q '~>children' "$scan_skill" && printf true || printf false)" \
    "PDK库按官方dd library cells契约枚举且不使用children"
check "$(grep -q 'procedure(stScanVisitCellView' "$scan_skill" && grep -q 'stScanVisited' "$scan_skill" && grep -q 'StTechPdkDeviceCellP' "$scan_skill" && printf true || printf false)" \
    "PDK扫描递归只读遍历层次并以visited防环和positive proof过滤原语"
check "$(python3 - "$scan_skill" <<'PY'
from pathlib import Path
import sys
source = Path(sys.argv[1]).read_text()
start = source.index('procedure(stScanDescriptionProvenP(description)')
end = source.index('procedure(stScanAcceptDescription(', start)
predicate = source[start:end]
required = ('stScanMosTerminalRolesProvenP(description)',
            'stScanResistorTerminalRolesProvenP(description)',
            'stScanProvenSourceP(stScanGet(description "kindSource"))',
            'stScanProvenSourceP(stScanGet(description "terminalSource"))',
            'stScanProvenSourceP(stScanGet(description "deviceProofSource"))')
mos_branch = predicate.find('member(stScanGet(description "kind") list("mos_n" "mos_p" "mos"))')
resistor_branch = predicate.find('stScanResistorTerminalRolesProvenP(description)')
print('true' if all(item in predicate for item in required)
      and 0 <= mos_branch < resistor_branch
      and 'stScanCompleteReliability(description)' not in predicate
      and 'stScanCompleteBulk(description)' not in predicate else 'false')
PY
)" \
    "MOS和电阻按各自端子证据进入目录，MOS完整可靠性与Bulk留给后续操作门禁"
check "$(grep -q 'analogLib' "$scan_skill" && grep -q 'basic' "$scan_skill" && grep -q 'StTechGeneratedLibraryP' "$scan_skill" && printf true || printf false)" \
    "analogLib、basic和生成库不会被当成PDK候选库"
check "$(grep -q 'process_identity' "$scan_skill" && grep -q 'identity_source' "$scan_skill" && grep -q 'context_complete' "$scan_skill" && printf true || printf false)" \
    "PDK identity产物记录source tech process及证据完整度"
check "$(grep -q 'model_context_complete' "$scan_skill" && printf true || printf false)" \
    "无法证明model sections/corners时identity明确标记模型上下文不完整"
check "$(grep -q 'scan_complete' "$scan_skill" && grep -q 'renameFile' "$scan_skill" && grep -q 'No accepted PDK device records' "$scan_skill" && printf true || printf false)" \
    "扫描仅在源上下文和至少一条器件记录成立后原子发布complete产物"
check "$(grep -q 'stScanPathsConflictP' "$scan_skill" && grep -q 'stScanCatalogTempPath' "$scan_skill" && grep -q 'stScanIdentityTempPath' "$scan_skill" && printf true || printf false)" \
    "SKILL在清理或写入前交叉校验正式与临时输出路径"
check "$(printf '%s\n' "$scan_publish_source" | grep -q 'catalogTempPath = strcat(catalogPath ".tmp")' && printf '%s\n' "$scan_publish_source" | grep -q 'identityTempPath = strcat(identityPath ".tmp")' && printf '%s\n' "$scan_publish_source" | grep -q 'stScanPathsConflictP(list(catalogPath identityPath catalogTempPath identityTempPath))' && printf true || printf false)" \
    "SKILL先以局部四路径冲突检查，冲突时不登记全局清理路径"
check "$([[ -n "$scan_conflict_line" && -n "$scan_refusal_line" && -n "$scan_cleanup_registration_line" && -n "$scan_catalog_temp_created_line" && -n "$scan_identity_temp_created_line" && -n "$scan_catalog_rename_line" && -n "$scan_catalog_published_line" && -n "$scan_identity_rename_line" && -n "$scan_identity_published_line" && "$scan_conflict_line" -lt "$scan_refusal_line" && "$scan_refusal_line" -lt "$scan_cleanup_registration_line" && "$scan_cleanup_registration_line" -lt "$scan_catalog_temp_created_line" && "$scan_catalog_temp_created_line" -lt "$scan_identity_temp_created_line" && "$scan_identity_temp_created_line" -lt "$scan_catalog_rename_line" && "$scan_catalog_rename_line" -lt "$scan_catalog_published_line" && "$scan_catalog_published_line" -lt "$scan_identity_rename_line" && "$scan_identity_rename_line" -lt "$scan_identity_published_line" ]] && printf true || printf false)" \
    "SKILL事务顺序完整覆盖冲突预检、拒绝、登记、双临时创建、双rename与双发布"
check "$([[ $scan_order_mutation_status -ne 0 ]] && printf true || printf false)" \
    "顺序断言会拒绝identity rename早于catalog published的半发布错误控制流"
check "$(source_has_order "$scan_publish_source" "${scan_order_tokens[@]}" && printf true || printf false)" \
    "真实SKILL满足完整事务顺序，而不是只包含孤立关键字"
check "$(printf '%s\n' "$scan_publish_source" | grep -q 'when(or(isFile(catalogPath) isFile(identityPath) isFile(catalogTempPath) isFile(identityTempPath))' && grep -q 'stScanCatalogTempCreated = nil' "$scan_skill" && grep -q 'stScanIdentityTempCreated = nil' "$scan_skill" && ! grep -Fq 'when(isFile(catalogPath) deleteFile(catalogPath))' "$scan_skill" && ! grep -Fq 'when(isFile(identityPath) deleteFile(identityPath))' "$scan_skill" && source_condition_deletes_path "$scan_skill" 'when(and(stScanCatalogTempCreated isFile(stScanCatalogTempPath))' 'deleteFile(stScanCatalogTempPath)' && source_condition_deletes_path "$scan_skill" 'when(and(stScanIdentityTempCreated isFile(stScanIdentityTempPath))' 'deleteFile(stScanIdentityTempPath)' && source_condition_deletes_path "$scan_skill" 'when(and(stScanCatalogPublished isFile(stScanCatalogPath))' 'deleteFile(stScanCatalogPath)' && source_condition_deletes_path "$scan_skill" 'when(and(stScanIdentityPublished isFile(stScanIdentityPath))' 'deleteFile(stScanIdentityPath)' && printf true || printf false)" \
    "失败清理的四个条件各自只删除其本轮拥有的临时或已发布正式路径"
check "$([[ "$scan_catalog_published_line" -lt "$scan_identity_rename_line" && "$scan_identity_rename_line" -lt "$scan_identity_published_line" ]] && source_condition_deletes_path "$scan_skill" 'when(and(stScanCatalogPublished isFile(stScanCatalogPath))' 'deleteFile(stScanCatalogPath)' && source_condition_deletes_path "$scan_skill" 'when(and(stScanIdentityPublished isFile(stScanIdentityPath))' 'deleteFile(stScanIdentityPath)' && printf true || printf false)" \
    "catalog已发布而identity尚未发布时，失败清理只回收catalog正式产物"
check "$(grep -q 'procedure(StTechLibraryIdentity' "$tech_scan_adapter" && grep -q 'procedure(StTechSameProcessP' "$tech_scan_adapter" && grep -q 'techGetTechFile' "$tech_scan_adapter" && printf true || printf false)" \
    "默认技术适配器从tech attachment建立并比较process identity"
check "$(grep -q 'procedure(StTechPdkDeviceCellP' "$tech_scan_adapter" && grep -q 'procedure(StTechDeviceLibraryP' "$tech_scan_adapter" && grep -q 'cdfGetBaseCellCDF' "$tech_scan_adapter" && printf true || printf false)" \
    "PDK primitive归属需通过可覆盖的library、Base CDF和model正向证明"
check "$(python3 - "$scan_skill" "$tech_scan_adapter" <<'PY'
from pathlib import Path
import sys
scan = Path(sys.argv[1]).read_text()
base = 'load(strcat(getShellEnvVar("ST_ENGINE_ROOT") "/server/skill/tech_adapter.il"))'
site = 'getShellEnvVar("ST_PDK_TECH_ADAPTER")'
ok = base in scan and site in scan and scan.index(base) < scan.index(site)
print('true' if ok else 'false')
PY
)" \
    "scan-pdk先加载稳定基础适配器，再加载显式的现场PDK元数据适配器"
check "$(grep -q 'procedure(StTechCurrentModelContext' "$tech_scan_adapter" && grep -q 'envGetVal("spectre.envOpts" "modelFiles")' "$tech_scan_adapter" && printf true || printf false)" \
    "默认适配器尽力读取当前Spectre modelFiles上下文而不静态冒充完成"
model_context_source=$(awk '
    /procedure\(stTechDefaultCurrentModelContext/ { capture=1 }
    /procedure\(StTechCurrentModelContext/ { capture=0 }
    capture { print }
' "$tech_scan_adapter")
check "$(printf '%s\n' "$model_context_source" | grep -q '(stringp(raw)' && printf '%s\n' "$model_context_source" | grep -q '(listp(raw)' && ! printf '%s\n' "$model_context_source" | grep -Eq '\(\((stringp|listp)\(raw\)\)' && printf true || printf false)" \
    "modelFiles类型cond使用合法SKILL分支语法而不调用布尔结果"
check "$(grep -q 'parseString(entry ";")' "$tech_scan_adapter" && grep -q 'stTechModelEntryDisabledP' "$tech_scan_adapter" && ! printf '%s\n' "$model_context_source" | grep -Eq '(car|cadr)\(raw\)' && printf true || printf false)" \
    "modelFiles逐entry按分号解析、过滤disabled且不把整串第二文件当section"
check "$(grep -q 'procedure(stTechBoundOverride' "$tech_scan_adapter" && grep -q 'ST_SITE_PROCESS_ID' "$tech_scan_adapter" && ! grep -q 'stBackendOptionalEnv("ST_PDK_VERSION"' "$tech_scan_adapter" && printf true || printf false)" \
    "环境覆盖显式绑定source process identity而非全局套用"
check "$(grep -q 'paramObject~>value' "$tech_scan_adapter" && grep -q 'paramObject~>defValue' "$tech_scan_adapter" && printf true || printf false)" \
    "Instance Effective CDF优先当前value并仅在空值时回退defValue"
check "$(! grep -Eq 'list\([^)]*"m"' "$tech_scan_adapter" && printf true || printf false)" \
    "CDF参数m不再误映射为fingers"
check "$(grep -q 'not(lessp(length(terminalNames) 2))' "$tech_scan_adapter" && grep -q 'SUBSTRATE' "$common_skill" && printf true || printf false)" \
    "电阻识别允许三端以上并保留可证明的substrate/bulk角色"
if skill_parentheses_balanced "$scan_skill" && \
   skill_parentheses_balanced "$tech_scan_adapter" && \
   skill_parentheses_balanced "$project_dir/server/skill/probe_pdk.il" && \
   skill_parentheses_balanced "$project_dir/server/skill/device_bindings.il" && \
   skill_parentheses_balanced "$project_dir/server/skill/site_metadata_adapter.il"; then
    scan_skills_balanced=true
else
    scan_skills_balanced=false
fi
check "$scan_skills_balanced" \
    "动态PDK扫描与技术适配SKILL的括号在注释和字符串之外保持平衡"

setup_file="$project_dir/server/setup_backend.csh"
check "$([[ -f "$setup_file" ]] && printf true || printf false)" \
    "csh 服务器环境配置文件存在"
site_host_header="$project_dir/integration/maau/site_op_simulation_host.h"
site_host_source="$project_dir/integration/maau/site_op_simulation_host.cc"
provider_source="$project_dir/app/st_maau_op_provider.cpp"
check "$([[ -s "$site_host_header" && -s "$site_host_source" ]] && printf true || printf false)" \
    "生产OP provider具有显式的现场Host工厂桥接"
check "$(! grep -q 'UnlinkedMaauOpHost' "$provider_source" && \
          grep -q 'CreateSiteOpSimulationHost' "$provider_source" && printf true || printf false)" \
    "生产OP provider不再内置固定失败的占位Host"
check "$(grep -q 'ST_BUILD_MAAU_SITE_PROVIDER' "$project_dir/CMakeLists.txt" && \
          grep -q 'ST_MAAU_SITE_HOST_LIBRARY' "$project_dir/CMakeLists.txt" && printf true || printf false)" \
    "生产OP provider只能在显式配置现地Host库时构建"
if [[ -f "$setup_file" ]]; then
    for variable in ST_SCAN_PDK_RUNNER ST_RUN_OP_RUNNER ST_OP_PROVIDER_BIN ST_SNAPSHOT_RUNNER ST_CLONE_RUNNER ST_MATERIALIZE_RUNNER \
        ST_NETLIST_RUNNER ST_PUBLISH_RUNNER ST_OPEN_RUNNER; do
        check "$(grep -q "setenv $variable" "$setup_file" && printf true || printf false)" \
            "setup_backend.csh 设置 $variable"
    done
    check "$(grep -q 'ST_PDK_TECH_ADAPTER must be an absolute readable file' "$setup_file" && printf true || printf false)" \
        "setup_backend.csh对用户指定的现场PDK适配器失效闭合"
    if command -v csh >/dev/null 2>&1; then
        python3 "$project_dir/tests/ServerSetupTest.py"
        setup_explicit_provider="$test_root/explicit-op-provider"
        printf '#!/usr/bin/env bash\nexit 70\n' > "$setup_explicit_provider"
        chmod +x "$setup_explicit_provider"
        setup_output=$(csh -f -c \
            "setenv ST_OP_PROVIDER_BIN '$setup_explicit_provider'; source '$setup_file' '$project_dir'; echo ST_TEST_OP_PROVIDER=\${ST_OP_PROVIDER_BIN}")
        check "$(printf '%s\n' "$setup_output" | grep -Fqx "ST_TEST_OP_PROVIDER=$setup_explicit_provider" && printf true || printf false)" \
            "setup_backend.csh不覆盖用户显式设置的有效OP provider"
        setup_output=$(csh -f -c \
            "unsetenv ST_OP_PROVIDER_BIN; source '$setup_file' '$project_dir'; if (\$?ST_OP_PROVIDER_BIN) printenv ST_OP_PROVIDER_BIN | sed 's|^|ST_TEST_OP_PROVIDER=|'; if (! \$?ST_OP_PROVIDER_BIN) echo ST_TEST_OP_PROVIDER=UNSET")
        expected_setup_provider="$project_dir/server/site/op_provider.py"
        check "$(printf '%s\n' "$setup_output" | grep -Fqx "ST_TEST_OP_PROVIDER=$expected_setup_provider" && printf true || printf false)" \
            "setup_backend.csh默认选择独立Cadence OP入口，不要求Maau原生链接"
    fi
fi

snapshot_skill="$project_dir/server/skill/export_snapshot.il"
common_skill="$project_dir/server/skill/backend_common.il"
policy_file="$project_dir/server/config/device_policy.tsv"
check "$([[ -s "$common_skill" ]] && printf true || printf false)" \
    "SKILL 公共运行时存在"
check "$(grep -q 'dbOpenCellViewByType' "$snapshot_skill" && printf true || printf false)" \
    "snapshot 从真实 OA cellview 读取"
check "$(grep -q 'ST_REQ_EXPORT_MODE' "$snapshot_skill" && printf true || printf false)" \
    "snapshot 和 round-trip netlist 共用确定性导出器"
check "$(grep -q 'stBackendNormalizeNetName' "$snapshot_skill" && printf true || printf false)" \
    "snapshot 显式归一化阵列重复网络表达式"
check "$(! grep -q 'dbSave' "$snapshot_skill" && printf true || printf false)" \
    "snapshot 只读脚本不保存源 cellview"
check "$(grep -q $'oa_library\toa_cell\tkind' "$policy_file" 2>/dev/null && printf true || printf false)" \
    "真实 PDK 器件策略表存在"

cat > "$test_root/fake_copy_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf '%s|%s/%s/%s|%s/%s/%s|%s\n' \
    "$ST_REQ_COPY_MODE" \
    "$ST_REQ_SOURCE_LIB" "$ST_REQ_SOURCE_CELL" "$ST_REQ_SOURCE_VIEW" \
    "$ST_REQ_TARGET_LIB" "$ST_REQ_TARGET_CELL" "$ST_REQ_TARGET_VIEW" \
    "$ST_BACKEND_ACTION_FILE" > "$ST_TEST_CAPTURE"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
chmod +x "$test_root/fake_copy_virtuoso.sh"

copy_capture="$test_root/copy-capture.txt"
env ST_VIRTUOSO_BIN="$test_root/fake_copy_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$copy_capture" \
    "$backend" clone \
    --cds-lib "$test_root/project/cds.lib" --hierarchy / \
    --source-lib TEST --source-cell core --source-view schematic \
    --source-storage "$test_root/project" \
    --target-lib TEST_STAGING --target-cell core__STAGING --target-view schematic \
    --target-storage "$test_root/project"
check "$([[ "$(cat "$copy_capture")" == clone\|TEST/core/schematic\|TEST_STAGING/core__STAGING/schematic\|*copy_cellview.il ]] && printf true || printf false)" \
    "clone 将隔离源目标和 copy 动作传给 Virtuoso"

env ST_VIRTUOSO_BIN="$test_root/fake_copy_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$copy_capture" \
    "$backend" publish \
    --cds-lib "$test_root/project/cds.lib" --hierarchy / \
    --source-lib TEST_STAGING --source-cell core__STAGING --source-view schematic \
    --source-storage "$test_root/project" \
    --target-lib TEST_VARIANT --target-cell core__TV0001 --target-view schematic \
    --target-storage "$test_root/project"
check "$([[ "$(cat "$copy_capture")" == publish\|TEST_STAGING/core__STAGING/schematic\|TEST_VARIANT/core__TV0001/schematic\|*copy_cellview.il ]] && printf true || printf false)" \
    "publish 使用同一受保护复制动作但保留发布语义"

copy_skill="$project_dir/server/skill/copy_cellview.il"
check "$(grep -q 'dbCopyCellView' "$copy_skill" && printf true || printf false)" \
    "clone/publish 使用 Cadence 数据库 cellview 复制 API"
check "$(grep -q 'ddGetObj' "$copy_skill" && printf true || printf false)" \
    "clone/publish 在复制前验证目标库和目标不存在"
check "$(grep -q 'stBackendWriteOk' "$copy_skill" && printf true || printf false)" \
    "clone/publish 只在复制保存完成后写成功标记"

# Batch publication uses one Cadence process and retains the exact full map.
cat > "$test_root/publish-plan.json" <<'EOF'
{"clone_on_write":[{"source":{"library":"TEST_STAGING","cell":"core","view":"schematic"},"target":{"library":"TEST_VARIANT","cell":"core","view":"schematic"},"hierarchy_path":"/"},{"source":{"library":"TEST_STAGING","cell":"child","view":"symbol"},"target":{"library":"TEST_VARIANT","cell":"child","view":"symbol"},"hierarchy_path":"@child/symbol"}]}
EOF
cat > "$test_root/fake_publish_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
[[ "$ST_BACKEND_ACTION_FILE" == *publish_transaction.il ]] || exit 67
python3 - "$ST_REQ_PUBLISH_PLAN" "$ST_TEST_CAPTURE" <<'PYCODE'
import json, pathlib, sys
views = json.loads(pathlib.Path(sys.argv[1]).read_text())['clone_on_write']
assert len(views) == 2 and views[1]['target']['view'] == 'symbol'
pathlib.Path(sys.argv[2]).write_text('batch-map-forwarded')
PYCODE
if [[ ${ST_TEST_PUBLISH_FAIL:-0} == 1 ]]; then exit 9; fi
log_path=''
while [[ $# -gt 0 ]]; do
    if [[ "$1" == -log ]]; then log_path=$2; shift; fi
    shift
done
[[ -n "$log_path" ]] || exit 68
python3 - "$log_path" <<'PYCODE'
import pathlib, sys
pathlib.Path(sys.argv[1]).write_text('PDK helper startup\n' * 250 + 'ST_BACKEND_PUBLISH_COMPLETE views=2\n')
PYCODE
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
chmod +x "$test_root/fake_publish_virtuoso.sh"
env ST_VIRTUOSO_BIN="$test_root/fake_publish_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$copy_capture" \
    "$backend" publish --cds-lib "$test_root/project/cds.lib" \
    --publish-plan "$test_root/publish-plan.json" > "$test_root/publish-success.log" 2>&1
check "$([[ "$(cat "$copy_capture")" == batch-map-forwarded ]] && printf true || printf false)" \
    "整组发布计划与symbol映射传给一次专用原生事务入口"
check "$(grep -q 'ST_BACKEND_PUBLISH_COMPLETE views=2' "$test_root/publish-success.log" && printf true || printf false)" \
    "启动日志超过240行仍保留完整发布完成证据"
set +e
env ST_VIRTUOSO_BIN="$test_root/fake_publish_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$copy_capture" \
    ST_TEST_PUBLISH_FAIL=1 "$backend" publish \
    --cds-lib "$test_root/project/cds.lib" --publish-plan "$test_root/publish-plan.json" \
    > "$test_root/publish-failure.log" 2>&1
publish_batch_status=$?
set -e
check "$([[ $publish_batch_status -ne 0 ]] && printf true || printf false)" \
    "原生发布进程失败不得返回成功"
publish_skill="$project_dir/server/skill/publish_transaction.il"
check "$(grep -q 'stage = "preflight"' "$publish_skill" && grep -q 'stage = "copy"' "$publish_skill" && grep -q 'refusing overwrite' "$publish_skill" && printf true || printf false)" \
    "发布事务在全组preflight后才复制且拒绝覆盖已有目标"
check "$(grep -Fq 'created = cons(target created)' "$publish_skill" && grep -q 'foreach(ref created' "$publish_skill" && grep -q 'ddDeleteObj(obj)' "$publish_skill" && printf true || printf false)" \
    "异常回滚清单只登记本次复制返回的新view"
check "$(grep -Fq 'inst~>master = masterCv' "$publish_skill" && grep -q 'still depends on staging' "$publish_skill" && grep -q 'MaauTopologyCheckAndSave' "$publish_skill" && printf true || printf false)" \
    "原生发布重绑全部master并check/save，拒绝暂存依赖残留"

materialize_skill="$project_dir/server/skill/materialize.il"
pdk_adapter="$project_dir/server/skill/pdk_adapter.il"
check "$(grep -q 'pdk_adapter.il' "$materialize_skill" && printf true || printf false)" \
    "materialize 在结构写入前加载 PDK 适配器"
check "$(grep -q 'StTopologyVariantMaterialize' "$materialize_skill" && printf true || printf false)" \
    "materialize 调用独立结构物化入口"
check "$(grep -q 'procedure(StTopologyApplyCdfParameters' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "PDK 适配器实现 CDF 参数写入"
check "$(grep -q 'cdfData = if(parameterList then cdfGetInstCDF(inst) else t)' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "固定尺寸PDK器件没有CDF参数需要写入时直接成功"
check "$(grep -q 'CCSinvokeInstCdfCallbacks' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "PDK 适配器按实例触发已部署的 CDF callback"
check "$(grep -q 'paramObject~>paramType' "$pdk_adapter" 2>/dev/null && \
        grep -q '"cyclic" "radio"' "$pdk_adapter" 2>/dev/null && \
        ! grep -q 'valueType = paramObject~>type' "$pdk_adapter" 2>/dev/null && \
        printf true || printf false)" \
    "CDF 参数使用 paramType 映射合法 OA 属性类型，不把 instData 当作 propType"
check "$(grep -q 'procedure(StTopologyCreatePort' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "PDK 适配器创建可见 schematic 端口"
check "$(grep -q 'procedure(StTopologyCreateWrapperSymbol' "$pdk_adapter" 2>/dev/null && grep -q 'dbCreateTerm' "$pdk_adapter" 2>/dev/null && grep -q 'dbCreatePin' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "PDK 适配器为封装子Cell创建带真实terminal和pin的symbol"
check "$(grep -q 'dbReplaceProp(cv "stTerminalOrder" "string"' "$pdk_adapter" 2>/dev/null && \
        grep -q 'orderValue = inst~>master~>stTerminalOrder' "$snapshot_skill" 2>/dev/null && \
        ! grep -q 'dbFindPropByName' "$snapshot_skill" 2>/dev/null && \
        printf true || printf false)" \
    "动态封装symbol显式保存端口顺序且使用ICADVM18.1支持的属性读取方式"
check "$(grep -q 'schCheck' "$pdk_adapter" 2>/dev/null && grep -q 'dbSave' "$pdk_adapter" 2>/dev/null && printf true || printf false)" \
    "PDK 适配器执行 schematic check/save"
check "$(! grep -R -q 'intern(' "$project_dir/server/skill" "$project_dir/skill/topology_variant.il" && printf true || printf false)" \
    "SKILL 动态 CDF 属性名不使用当前服务器不兼容的 intern"
check "$(grep -q 'get(cdfData concat(' "$snapshot_skill" && grep -q 'get(cdfData concat(' "$pdk_adapter" && printf true || printf false)" \
    "snapshot 与物化器用 concat 取得动态 CDF 属性"
check "$(! grep -E -q '^[[:space:]]+\(\(' "$common_skill" "$pdk_adapter" && printf true || printf false)" \
    "SKILL cond 分支不把判断结果误当成函数调用"
check "$(grep -q 'Replicated net expressions are forbidden' "$project_dir/skill/topology_variant.il" && printf true || printf false)" \
    "OA 物化拒绝把阵列重复表达式创建成普通网络"
if skill_parentheses_balanced "$project_dir/skill/topology_variant.il"; then
    skill_balanced=true
else
    skill_balanced=false
fi
check "$skill_balanced" \
    "结构物化 SKILL 的括号在注释和字符串之外保持平衡"

set +e
output=$(env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" \
    "$backend" materialize --cds-lib "$test_root/project/cds.lib" \
    --work-dir "$test_root/work" --skill "$project_dir/skill/standalone_topology_variant.il" \
    --plan "$test_root/missing-plan.json" 2>&1)
status=$?
set -e
check "$([[ $status -eq 66 && "$output" == *"materialization plan"* ]] && printf true || printf false)" \
    "materialize 在启动 Virtuoso 前拒绝缺失的计划文件"

cat > "$test_root/fake_netlist_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf '%s|%s|%s|%s|%s\n' \
    "$ST_BACKEND_ACTION_FILE" "$ST_REQ_LIB" "$ST_REQ_CELL" "$ST_REQ_VIEW" \
    "$ST_REQ_CORE_SUBCKT" \
    > "$ST_TEST_CAPTURE"
printf 'subckt %s P N\nends %s\n' "$ST_REQ_CORE_SUBCKT" "$ST_REQ_CORE_SUBCKT" \
    > "$ST_REQ_NETLIST_OUTPUT"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
chmod +x "$test_root/fake_netlist_virtuoso.sh"

netlist_capture="$test_root/netlist-capture.txt"
env ST_VIRTUOSO_BIN="$test_root/fake_netlist_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$netlist_capture" \
    "$backend" netlist --cds-lib "$test_root/project/cds.lib" \
    --lib TEST --cell core__TV0001 --view schematic --core-subckt core \
    --output "$test_root/roundtrip.scs"
check "$([[ "$(cat "$netlist_capture")" == *export_snapshot.il\|TEST\|core__TV0001\|schematic\|core ]] && printf true || printf false)" \
    "netlist 复用确定性OA导出器并区分物理Cell名和逻辑subckt名"
check "$([[ -s "$test_root/roundtrip.scs" ]] && printf true || printf false)" \
    "netlist 只在回读结构网表实际生成后成功"

set +e
output=$(env ST_VIRTUOSO_BIN="$test_root/fake_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" \
    "$backend" open --cds-lib "$test_root/project/cds.lib" \
    --lib TEST --view schematic 2>&1)
status=$?
set -e
check "$([[ $status -eq 64 && "$output" == *"missing required option: --cell"* ]] && printf true || printf false)" \
    "open 在启动 Virtuoso 前拒绝缺失的 L/C/V"

cat > "$test_root/fake_gui_virtuoso.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$*" > "$ST_TEST_CAPTURE"
printf '%s|%s|%s\n' "$ST_REQ_LIB" "$ST_REQ_CELL" "$ST_REQ_VIEW" \
    >> "$ST_TEST_CAPTURE"
printf 'OK\n' > "$ST_BACKEND_STATUS_FILE"
EOF
chmod +x "$test_root/fake_gui_virtuoso.sh"

open_capture="$test_root/open-capture.txt"
env ST_VIRTUOSO_BIN="$test_root/fake_gui_virtuoso.sh" \
    ST_SKILL_INIT="$test_root/init.il" ST_TEST_CAPTURE="$open_capture" \
    ST_OPEN_WAIT_SECONDS=3 \
    "$backend" open --cds-lib "$test_root/project/cds.lib" \
    --lib TEST --cell core --view schematic
check "$(! grep -q -- '-nograph' "$open_capture" && grep -q -- '-replay' "$open_capture" && printf true || printf false)" \
    "open 使用带界面的 Virtuoso，而不是 -nograph 批处理"
check "$(grep -q '^TEST|core|schematic$' "$open_capture" && printf true || printf false)" \
    "open 将派生 L/C/V 无损传给 GUI 动作"

open_skill="$project_dir/server/skill/open_cellview.il"
check "$(grep -q 'deOpenCellView' "$open_skill" 2>/dev/null && printf true || printf false)" \
    "open SKILL 显式打开目标 cellview"
check "$(grep -q 'stBackendWriteOk' "$open_skill" 2>/dev/null && printf true || printf false)" \
    "open 只在窗口创建后写完成标记"

prepare_script="$project_dir/server/prepare_session.sh"
check "$([[ -x "$prepare_script" ]] && printf true || printf false)" \
    "独立 Cadence 会话库准备脚本存在且可执行"
if [[ -x "$prepare_script" ]]; then
    prepared_root="$test_root/prepared-cadence"
    prepared_cds=$(
        "$prepare_script" --source-cds-lib "$test_root/project/cds.lib" \
            --session-dir "$prepared_root" --variant-lib TEST_VARIANT
    )
    prepared_root_real=$(cd "$prepared_root" && pwd -P)
    source_project_real=$(cd "$test_root/project" && pwd -P)
    check "$([[ "$prepared_cds" == "$prepared_root_real/cds.lib" && -f "$prepared_cds" ]] && printf true || printf false)" \
        "会话准备脚本返回新 cds.lib 路径"
    check "$(grep -Fqx "INCLUDE $source_project_real/cds.lib" "$prepared_cds" && printf true || printf false)" \
        "新 cds.lib 只读包含原项目库表"
    check "$(grep -Fqx "DEFINE TEST_VARIANT $prepared_root_real/libraries/TEST_VARIANT" "$prepared_cds" && printf true || printf false)" \
        "新 cds.lib 定义最终派生库"
    check "$(grep -Fqx "DEFINE TEST_VARIANT__STAGING $prepared_root_real/libraries/TEST_VARIANT__STAGING" "$prepared_cds" && printf true || printf false)" \
        "新 cds.lib 定义隔离 staging 库"
    check "$([[ -d "$prepared_root/libraries/TEST_VARIANT" && -d "$prepared_root/libraries/TEST_VARIANT__STAGING" ]] && printf true || printf false)" \
        "最终库和 staging 库目录分离"

    prepared_again=$(
        "$prepare_script" --source-cds-lib "$test_root/project/cds.lib" \
            --session-dir "$prepared_root" --variant-lib TEST_VARIANT
    )
    check "$([[ "$prepared_again" == "$prepared_cds" ]] && printf true || printf false)" \
        "完全相同的会话准备可安全重复执行"
fi

if [[ $failures -ne 0 ]]; then
    printf '\n%d server backend contract tests failed\n' "$failures"
    exit 1
fi

printf '\nserver backend contract tests passed\n'
