"""Cache-only experiment draft preparation, not a native circuit acceptance."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import CascodePdkEvidenceTest as evidence_fixture

ENTRY = Path(__file__).resolve().parents[1]/'server/site/prepare_cascode_experiment.py'


class PreparationTest(unittest.TestCase):
    def run_entry(self, session, batch):
        return subprocess.run([sys.executable, str(ENTRY), '--session', str(session), '--batch', str(batch)],
                              text=True, capture_output=True)

    def test_no_source_search_no_default_seed_and_no_success_promotion(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            session, batch, pdk, bridge = evidence_fixture.PdkEvidenceTest().fixture(root)
            before = {p: p.read_bytes() for p in root.rglob('*') if p.is_file()}
            result = self.run_entry(session, batch)
            self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
            self.assertIn('RESULT=INPUT_DRAFT_PREPARED', result.stdout)
            self.assertIn('EXPERIMENT_INPUTS_READY=false', result.stdout)
            self.assertIn('NATIVE_EXECUTIONS=0', result.stdout)
            output = Path(next(line.split('=', 1)[1] for line in result.stdout.splitlines() if line.startswith('OUTPUT_DIR=')))
            profile = json.loads((output/'simulation_profile.draft.json').read_text())
            facts = json.loads((output/'pdk_facts.draft.json').read_text())
            report = json.loads((output/'preparation.json').read_text())
            self.assertEqual(profile['validation_scope'], 'experimental_dc')
            self.assertEqual(profile['experimental_parameter_seeds']['PDK/nfet_h']['trials'], {})
            self.assertNotIn('kind', facts['devices']['PDK/nfet_h'])
            self.assertIn('I21: proven_polarity', report['required_bindings'])
            self.assertIn('complete_MOS_and_resistor_ratings_before_experiment', report['deferred'])
            self.assertFalse(report['reliability_verified'])
            self.assertFalse(report['ready_for_sizing'])
            self.assertTrue(all(p.read_bytes() == raw for p, raw in before.items()))

    def test_rejects_failed_acceptance_and_cross_session(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            session, batch, _, bridge = evidence_fixture.PdkEvidenceTest().fixture(root)
            other = root/'other'; other.mkdir()
            self.assertEqual(self.run_entry(other, batch).returncode, 2)
            (bridge/'bridge_status.json').write_text(json.dumps(dict(error='failed', cache_match=False, psf_unchanged=True)))
            result = self.run_entry(session, batch)
            self.assertEqual(result.returncode, 2)
            self.assertIn('acceptance', result.stdout)


if __name__ == '__main__':
    unittest.main()
