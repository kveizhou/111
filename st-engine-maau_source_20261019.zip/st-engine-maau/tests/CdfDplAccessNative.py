"""Run actual CDF lookup expressions in native SKILL; no PDK writes or sizing."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cds-lib', required=True)
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    cds, work = Path(args.cds_lib), Path(args.work_dir)
    if not cds.is_absolute() or not cds.is_file() or cds.name != 'cds.lib':
        raise SystemExit('STOP: --cds-lib requires a readable absolute cds.lib')
    if not work.is_absolute():
        raise SystemExit('STOP: --work-dir requires a new absolute directory')
    expressions = []
    pattern = r'(?:cdf|cdfData)(?:->|~>)simInfo(?:->|~>)spectre(?:(?:->|~>)termOrder)?'
    for name in ('discover_pdk', 'probe_pdk', 'tech_adapter', 'site_metadata_adapter'):
        source = (ROOT / 'server/skill' / (name + '.il')).read_text()
        matches = re.findall(pattern, source)
        if len(matches) != 1:
            raise SystemExit('STOP: expected one CDF simulator lookup in ' + name)
        expressions.append((name, matches[0], 'termOrder' in matches[0]))
    work.mkdir(parents=True, exist_ok=False)
    (work / 'expressions.json').write_text(json.dumps(expressions, indent=2) + '\n')
    readers = 'list(' + ' '.join('list(' + json.dumps(name) + ' ' + json.dumps(expr) +
        (' t)' if terminals else ' nil)') for name, expr, terminals in expressions) + ')'
    action = work / 'cdf_dpl_check.il'
    action.write_text('''; Expressions copied from current production readers, evaluated by real SKILL.
let((cdf cdfData spec spectre expected result reader count port)
  count=0
  foreach(spec list("ports_IN_OUT" "missing_simInfo" "missing_spectre")
    spectre=if(equal(spec "ports_IN_OUT") then
      list(nil 'termOrder list("IN" "OUT") 'modelName "IN") else nil)
    cdf=if(equal(spec "missing_simInfo") then list(nil 'simInfo nil)
      else list(nil 'simInfo list(nil 'spectre spectre)))
    cdfData=cdf
    foreach(reader READERS
      expected=if(caddr(reader) then getq(spectre termOrder) else spectre)
      result=errset(evalstring(cadr(reader)) t)
      unless(and(result equal(car(result) expected))
        error("CDF_DPL_ACCESS_FAILED reader=%s fixture=%s" car(reader) spec))
      count=count+1
      printf("CDF_DPL_CASE_OK reader=%s fixture=%s\\n" car(reader) spec)
    )
  )
  port=outfile(getShellEnvVar("ST_CDF_DPL_STATUS"))
  unless(port error("Cannot create CDF DPL check status"))
  fprintf(port "OK cases=%d\\n" count)
  close(port)
)
exit()
'''.replace('READERS', readers))
    if args.prepare_only:
        print('SKILL_INPUT_PREPARED=' + str(action) + '; native execution not performed')
        return
    requested = os.environ.get('ST_VIRTUOSO_BIN') or 'virtuoso'
    executable = shutil.which(requested)
    if not executable:
        raise SystemExit('STOP: Virtuoso executable unavailable: ' + requested)
    env = dict(os.environ)
    status_file = work / 'status.txt'
    env['ST_CDF_DPL_STATUS'] = str(status_file)
    log = work / 'virtuoso.log'
    with (work / 'launcher.log').open('x') as stream:
        result = subprocess.run([executable, '-nograph', '-replay', str(action), '-log', str(log)],
            cwd=str(cds.parent), env=env, stdout=stream, stderr=subprocess.STDOUT)
    if log.exists():
        print('\n'.join(log.read_text(errors='replace').splitlines()[-80:]))
    if result.returncode or not status_file.is_file() or status_file.read_text().strip() != 'OK cases=12':
        raise SystemExit('STOP: native CDF DPL access check failed; retain ' + str(work))
    print('CDF_DPL_NATIVE_OK cases=12')


if __name__ == '__main__':
    main()
