"""Read-only diagnostics dispatch and evidence handling (no native OA locally)."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / 'server/site/diagnose_terminals.py'


class TerminalDiagnosticsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.cds = self.base / 'project space' / 'cds.lib'
        self.cds.parent.mkdir()
        self.cds.write_text('DEFINE PDK /fixture\n')
        self.scan = self.base / 'scan.log'
        self.scan.write_text('\\e *Error* CDF Spectre termOrder/symbol terminal conflict for Real_PDK/actual_res\n')
        self.out = self.base / 'diagnostic space'

    def run_entry(self, *options, env=None):
        return subprocess.run([sys.executable, str(ENTRY), '--scan-log', str(self.scan),
            '--cds-lib', str(self.cds), '--output', str(self.out)] + list(options),
            env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def fake(self, body):
        fake = self.base / 'fake_virtuoso'
        fake.write_text('#!/usr/bin/env bash\nset -euo pipefail\n' + body)
        fake.chmod(0o755)
        env = os.environ.copy()
        env['ST_VIRTUOSO_BIN'] = str(fake)
        return env

    def test_auto_master_from_real_error_and_prepare_does_not_claim_execution(self):
        # No executable exists: preparation must still succeed without launching.
        env = os.environ.copy()
        env['ST_VIRTUOSO_BIN'] = '/missing/virtuoso'
        result = self.run_entry('--prepare-only', env=env)
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('master=Real_PDK/actual_res/symbol', result.stdout)
        self.assertIn('native execution not performed', result.stdout)
        action = (self.out / 'terminal_diagnostic.il').read_text()
        self.assertIn('library="Real_PDK"', action)
        self.assertIn('cell="actual_res"', action)
        self.assertIn('"" "r"', action)
        self.assertNotIn('dbSave(', action)
        self.assertNotIn('dbReplaceProp(', action)

    def test_multiple_masters_rejected_before_creating_output(self):
        with self.scan.open('a') as stream:
            stream.write('*Error* CDF Spectre termOrder/symbol terminal conflict for Other_PDK/other_res\n')
        result = self.run_entry('--prepare-only')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('multiple', result.stdout)
        self.assertFalse(self.out.exists())

    def test_existing_output_preserved(self):
        self.out.mkdir()
        evidence = self.out / 'evidence'
        evidence.write_text('preserve')
        result = self.run_entry('--prepare-only')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(evidence.read_text(), 'preserve')

    def test_success_report_printed_and_full_raw_log_retained(self):
        env = self.fake('printf "CDF_TERM_ORDER=(PLUS MINUS)\\nST_TERMINAL_DIAGNOSTIC_COMPLETE\\n" > "$ST_TERMINAL_DIAGNOSTIC_REPORT"\nprintf "native output\\n"\n')
        result = self.run_entry(env=env)
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertIn('CDF_TERM_ORDER=', result.stdout)
        self.assertIn('TERMINAL_DIAGNOSTIC_READ_OK', result.stdout)
        self.assertEqual((self.out / 'virtuoso.log').read_text(), 'native output\n')

    def test_missing_marker_never_claims_success_and_preserves_failed_log(self):
        env = self.fake('printf "actual failure\\n"\n')
        result = self.run_entry(env=env)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('TERMINAL_DIAGNOSTIC_READ_OK', result.stdout)
        self.assertIn('actual failure', result.stdout)
        self.assertEqual((self.out / 'virtuoso.log').read_text(), 'actual failure\n')

    def test_nonzero_native_exit_preserved_even_with_report_marker(self):
        env = self.fake('printf "ST_TERMINAL_DIAGNOSTIC_COMPLETE\\n" > "$ST_TERMINAL_DIAGNOSTIC_REPORT"\nexit 42\n')
        result = self.run_entry(env=env)
        self.assertEqual(result.returncode, 42, result.stdout)
        self.assertNotIn('TERMINAL_DIAGNOSTIC_READ_OK', result.stdout)


if __name__ == '__main__':
    unittest.main()
