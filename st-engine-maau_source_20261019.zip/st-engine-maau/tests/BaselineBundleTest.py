"""Immutable baseline/candidate contracts; no native Cadence execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / 'server/site/baseline_bundle.py'
sys.path.insert(0, str(ENTRY.parent))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class BaselineBundleTest(unittest.TestCase):
    def test_native_site_binding_leaves_model_internals_to_simulator(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound,baseline,output,paths=self.fixture(Path(tmp))
            paths['model'].write_text('encrypted opaque PDK content\n')
            paths['ahdl'].write_text('`include "constants.h"\n`include "disciplines.h"\nmodule load(p,n); inout p,n; endmodule\n')
            bound['settings']['models'][0]['sha256']=digest(paths['model'])
            manifest=module.export_bundle(bound,baseline,output)
            bundle=module.load_bundle(manifest)
            self.assertEqual(bundle['dependency_policy'],'native-site')
            self.assertEqual(bundle['schema_version'],2)
            self.assertFalse(bundle['dependency_closure_complete'])
            self.assertFalse(bundle['model_internals_checked'])
            self.assertFalse(bundle['recursive_dependencies_historically_verified'])
            self.assertEqual(set(bundle['dependency_sha256']),{str(paths[k]) for k in ('model','definition','ahdl')})
            paths['leaf'].write_text('internal contents not inspected or claimed frozen\n')
            module.load_bundle(manifest)
            candidate='subckt trial D G S B\nM0 (D G S B) nmod l=30n nfin=2\nends trial\n'
            text,_=module.prepare_candidate_deck(bundle,candidate,Path(tmp),'trial')
            self.assertIn('l=30n',text)
            paths['model'].write_text('changed external root model\n')
            with self.assertRaises(ValueError):module.load_bundle(manifest)

    def test_native_site_binding_rejects_changed_host(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound,baseline,output,_=self.fixture(Path(tmp))
            manifest=module.export_bundle(bound,baseline,output)
            with patch('platform.node',return_value='another-machine'):
                with self.assertRaisesRegex(ValueError,'host'):module.load_bundle(manifest)

    def test_native_site_binding_tracks_executable_and_candidate_version(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);bound,baseline,output,_=self.fixture(root)
            executable=root/'spectre18';executable.write_text('#!/bin/sh\nexit 0\n');executable.chmod(0o755)
            log=baseline/'baseline_run/ocean.log'
            log.write_text(log.read_text()+'Spectre (R) Circuit Simulator\nVersion 18.1.0.321.isr6 64bit\n')
            bound['fixed'][str(log)]=digest(log)
            with patch.dict('os.environ',ST_SPECTRE_BIN=str(executable)):
                manifest=module.export_bundle(bound,baseline,output)
                bundle=module.load_bundle(manifest)
                self.assertEqual(bundle['simulator_identity']['baseline_versions'],['18.1.0.321.isr6'])
                with patch.dict('os.environ',ST_SPECTRE_BIN=str(root/'spectre99')):
                    with self.assertRaisesRegex(ValueError,'executable'):module.load_bundle(manifest)
                module.verify_candidate_simulator(bundle,str(executable),'Spectre (R) Circuit Simulator\nVersion 18.1.0.321.isr6 64bit\n')
                with self.assertRaisesRegex(ValueError,'version'):
                    module.verify_candidate_simulator(bundle,str(executable),'Spectre (R) Circuit Simulator\nVersion 99.1 64bit\n')
                executable.write_text('#!/bin/sh\nexit 1\n')
                with self.assertRaisesRegex(ValueError,'executable'):module.load_bundle(manifest)

    def test_numeric_section_names_preserve_exact_reference_and_case_rules(self):
        module=self.module()
        for dialect in ('spice','spectre'):
            with self.subTest(dialect=dialect),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp).resolve();model=root/'model.lib';leaf=root/'leaf.scs'
                leaf.write_text('model nf bsimcmg type=n\n')
                if dialect=='spice':
                    model.write_text('.lib root\n.lib "model.lib" 18_total_HF\n.endl root\n.lib 18_TOTAL_hf\n.include "leaf.scs"\n.endl 18_total_HF\n')
                    deck='.lib "model.lib" root\n'
                else:
                    model.write_text('section root\ninclude "model.lib" section=18_total_HF\nendsection root\nsection 18_total_HF\ninclude "leaf.scs"\nendsection 18_total_HF\n')
                    deck='include "model.lib" section=root\n'
                hashes,refs=module._dependencies(deck,root)
                self.assertEqual(set(hashes),{str(model),str(leaf)})
                self.assertEqual(refs[1]['section'],'18_total_HF')
                direct='include "model.lib" section=18_total_HF\n'
                absolute=module._absolute_deck(direct,root)
                self.assertIn('section=18_total_HF',absolute)
                module._dependencies(absolute,root)
                with self.assertRaises(ValueError):module._dependencies(direct.replace('18_total_HF','18_total_HF2'),root)
                if dialect=='spectre':
                    with self.assertRaises(ValueError):module._dependencies(direct.replace('18_total_HF','18_TOTAL_HF'),root)

    def test_dependency_failures_are_aggregated_without_returning_partial_bundle(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();model=root/'model.scs'
            model.write_text('section tt\ninclude "missing_a.scs"\ninclude "missing_b.scs"\nendsection tt\n')
            deck='include "model.scs" section=tt\ninclude "missing_c.scs"\n'
            with self.assertRaises(ValueError) as caught:module._dependencies(deck,root)
            issues=getattr(caught.exception,'issues',[])
            self.assertEqual(len(issues),3)
            for name in ('missing_a.scs','missing_b.scs','missing_c.scs'):
                self.assertTrue(any(name in issue['message'] for issue in issues))

    def test_final_file_drifts_preserve_previously_collected_dependency_issues(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();model=root/'model.scs'
            leaves=[root/'leaf_a.scs',root/'leaf_b.scs']
            model.write_text('section tt\ninclude "missing.scs"\ninclude "leaf_a.scs"\ninclude "leaf_b.scs"\nendsection tt\n')
            for leaf in leaves:leaf.write_text('model nf bsimcmg type=n\n')
            original_digest=module._digest;calls={}
            def mutate_before_final_hash(path):
                path=Path(path);calls[path]=calls.get(path,0)+1
                if path in leaves and calls[path]==3:
                    path.write_text(path.read_text()+'// changed during dependency scan\n')
                return original_digest(path)
            with patch.object(module,'_digest',side_effect=mutate_before_final_hash):
                with self.assertRaises(ValueError) as caught:
                    module._dependencies('include "model.scs" section=tt\n',root)
            issues=getattr(caught.exception,'issues',[])
            self.assertEqual(len(issues),3)
            self.assertTrue(any('missing.scs' in item['message'] for item in issues))
            for leaf in leaves:
                self.assertTrue(any(str(leaf) in item['message'] and 'changed' in item['message'] for item in issues))

    def test_ahdl_section_variable_is_not_a_model_library_boundary(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();ahdl=root/'block.va';header=root/'header.vams'
            header.write_text('`define LOCAL_VALUE 1\n')
            ahdl.write_text('`include "header.vams"\nmodule probe; integer section; integer endsection;\nanalog begin\nsection = 1;\nendsection = 2;\nend\nendmodule\n')
            hashes,_=module._dependencies('ahdl_include "block.va"\n',root)
            self.assertEqual(set(hashes),{str(ahdl),str(header)})

    def test_same_file_different_sections_and_returning_file_do_not_form_a_cycle(self):
        for dialect in ('spice','spectre'):
            with self.subTest(dialect=dialect),tempfile.TemporaryDirectory() as tmp:
                module=self.module();root=Path(tmp).resolve();a=root/'a.lib';b=root/'b.lib';leaf=root/'leaf.scs'
                leaf.write_text('model nf bsimcmg type=n\n')
                if dialect=='spice':
                    a.write_text('.lib entry\n.lib "a.lib" local\n.lib "b.lib" mid\n.endl entry\n.lib local\n.inc "leaf.scs"\n.endl local\n.lib end\n.endl end\n.lib unused\n.inc missing.inc\n.endl unused\n')
                    b.write_text('.lib mid\n.lib "a.lib" end\n.endl mid\n')
                    deck='.lib "a.lib" entry\n'
                else:
                    a.write_text('library models\nsection entry\ninclude "a.lib" section=local\ninclude "b.lib" section=mid\nendsection entry\nsection local\ninclude "leaf.scs"\nendsection local\nsection end\nendsection end\nsection unused\ninclude "missing.inc"\nendsection unused\nendlibrary models\n')
                    b.write_text('section mid\ninclude "a.lib" section=end\nendsection mid\n')
                    deck='include "a.lib" section=entry\n'
                before={p:p.read_bytes() for p in (a,b,leaf)}
                hashes,refs=module._dependencies(deck,root)
                self.assertEqual(set(hashes),{str(a),str(b),str(leaf)})
                self.assertEqual([r['section'] for r in refs],['entry','local',None,'mid','end'])
                for p,data in before.items():self.assertEqual(p.read_bytes(),data)

    def test_section_cycle_reports_file_and_section_chain(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();(root/'a.lib').write_text('.lib start\n.lib "b.lib" other\n.endl start\n')
            (root/'b.lib').write_text('.lib other\n.lib "a.lib" start\n.endl other\n')
            with self.assertRaisesRegex(ValueError,r'recursive dependency.*section=start.*section=other.*section=start'):
                module._dependencies('.lib "a.lib" start\n',root)

    def test_selected_section_missing_duplicate_or_unclosed_is_rejected(self):
        module=self.module()
        for content in ('.lib different\n.endl\n','.lib chosen\n.endl\n.lib CHOSEN\n.endl\n',
                        'section chosen\n','section chosen\nendsection other\n',
                        'section chosen\nendsection\nsection chosen\nendsection\n'):
            with self.subTest(content=content),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp).resolve();(root/'a.lib').write_text(content)
                with self.assertRaises(ValueError):module._dependencies('include "a.lib" section=chosen\n',root)

    def test_second_selected_section_is_scanned_even_when_file_already_hashed(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();(root/'a.lib').write_text('section first\nendsection\nsection second\ninclude "missing.scs"\nendsection\n')
            with self.assertRaisesRegex(ValueError,'missing.scs'):
                module._dependencies('include "a.lib" section=first\ninclude "a.lib" section=second\n',root)

    def test_bundle_exports_and_loads_selected_model_sections_without_whole_file_rescan(self):
        module=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound,baseline,output,paths=self.fixture(Path(tmp))
            paths['model'].write_text('section tt\ninclude "model.scs" section=inner\nendsection tt\nsection inner\ninclude "device.scs"\nendsection inner\nsection unused\ninclude "missing.scs"\nendsection unused\n')
            bound['settings']['models'][0]['sha256']=digest(paths['model'])
            manifest=module.export_bundle(bound,baseline,output,dependency_policy="recursive")
            bundle=module.load_bundle(manifest)
            self.assertEqual(bundle['dependency_sha256'][str(paths['leaf'])],digest(paths['leaf']))
            paths['leaf'].write_text('changed\n')
            with self.assertRaises(ValueError):module.load_bundle(manifest)

    def test_spice_library_sections_and_external_references_are_distinct(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            (root/'device.inc').write_text('.model nf nmos\n')
            (root/'models.lib').write_text(".LIB mos_si_flag_on\n.inc 'device.inc'\n.ENDL mos_si_flag_on\n")
            for path in ('models.lib', '"models.lib"', "'models.lib'"):
                deck = '.lib '+path+' mos_si_flag_on\n'
                hashes, refs = module._dependencies(deck, root)
                self.assertEqual(set(hashes), {str(root/'models.lib'), str(root/'device.inc')})
                self.assertEqual(refs[0]['section'], 'mos_si_flag_on')
                absolute = module._absolute_deck(deck, root)
                self.assertIn('.lib '+json.dumps(str(root/'models.lib'))+' mos_si_flag_on', absolute)
                self.assertEqual(module._dependencies(absolute, root), (hashes, refs))

    def test_spice_section_boundaries_and_missing_nested_file_are_rejected(self):
        module = self.module()
        for content in ('.lib alone\n', '.endl\n', '.lib one\n.endl two\n',
                        '.lib one\n.lib two\n.endl two\n.endl one\n',
                        '.lib one\n.include missing.inc\n.endl one\n'):
            with self.subTest(content=content), tempfile.TemporaryDirectory() as tmp:
                with self.assertRaises(ValueError):
                    module._dependencies(content, Path(tmp))

    def test_spice_continuation_and_comment_do_not_hide_file_dependency(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();(root/'x.lib').write_text('.lib tt\n* comment "\n.endl\n')
            hashes, refs = module._dependencies('.LIB "x.lib"\n+ tt\n', root)
            self.assertEqual(set(hashes), {str(root/'x.lib')})
            self.assertEqual(refs[0]['section'], 'tt')

    def test_spice_comments_do_not_break_spectre_or_verilog_block_comments(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve();leaf=root/'leaf.scs';leaf.write_text('model nf bsimcmg type=n\n')
            text='/*\n * model documentation\n */\ninclude "leaf.scs"\n'
            hashes,_=module._dependencies(text,root)
            self.assertEqual(set(hashes),{str(leaf)})

    def module(self):
        self.assertTrue(ENTRY.is_file(), 'BaselineBundle implementation is missing')
        spec = importlib.util.spec_from_file_location('baseline_bundle_under_test', ENTRY)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def fixture(self, root):
        root = root.resolve()
        baseline = root / 'session/batch/dc_review_ports_fixture'
        origin = baseline / 'baseline_generated'
        origin.mkdir(parents=True)
        shared = root / 'shared'
        shared.mkdir()
        model = shared / 'model.scs'
        leaf = shared / 'device.scs'
        leaf.write_text('model nmod bsimcmg type=n\n')
        model.write_text('section tt\ninclude "device.scs"\nendsection tt\n')
        definition = shared / 'definition.scs'
        extra = shared / 'constants.scs'
        extra.write_text('parameters EXTRA=1\n')
        definition.write_text('include "constants.scs"\n')
        ahdl = shared / 'load.va'
        header = shared / 'local.vams'
        header.write_text('`define LOCAL_CONST 1\n')
        ahdl.write_text('`include "local.vams"\nmodule load(p,n); inout p,n; endmodule\n')
        forms = [
            'analysis(\'dc ?anaName "dc" ?saveOppoint t ?oppoint "rawfile" ?maxiters "150" ?maxsteps "10000")',
            'analysis(\'tran ?stop "1u")',
            'option(\'reltol "1e-3")',
            'option(?categ \'turboOpts \'uniMode "APS" \'errorLevel "Conservative" \'mtOption "Manual" \'numThreads "4")',
            'ic("G" 0.3)',
            'nodeset("G" 0.4)',
            'temp(27)',
        ]
        deck = '''simulator lang=spectre
global 0 VSS!
parameters VIN=1.14
include "../../../../shared/model.scs" section=tt
include "../../../../shared/definition.scs"
ahdl_include "../../../../shared/load.va"
model localmod resistor r=1
subckt core D G S B
M0 (D G S B) nmod l=20n nfin=2
ends core
subckt wrap P Q R T
DUT (P Q R T) core
ends wrap
TOP (VIN G 0 0) wrap
V0 (VIN 0) vsource dc=VIN
simulatorOptions options temp=125 reltol=1e-3
dcOp dc maxiters=150 maxsteps=10000
dcOpInfo info what=oppoint where=rawfile
saveOptions options save=all currents=all subcktprobelvl=99
ic G=0.3
nodeset G=0.4
'''
        (origin / 'input.scs').write_text(deck)
        (baseline / 'baseline_run.scs').write_text(deck)
        (baseline / 'baseline_netlist.scs').write_text(deck)
        (baseline / 'saved_test.ocn').write_text('\n'.join(forms) + '\nrun()\n')
        (baseline / 'settings_forms.json').write_text(json.dumps(forms))
        (baseline / 'definition_files.txt').write_text('(' + json.dumps(str(definition)) + ')\n')
        (baseline / 'baseline_definition_hashes.json').write_text(json.dumps({str(definition): digest(definition)}))
        (baseline / 'baseline_status.json').write_text(json.dumps({'converged': True}))
        work = baseline / 'baseline_run'
        work.mkdir()
        (work / 'runtime.done').write_text('OK\n')
        (work / 'ocean.log').write_text('Command line: spectre +aps=conservative +mt=4 input.scs\n')
        psf = baseline / 'baseline_results/psf'
        psf.mkdir(parents=True)
        (psf / 'dcOp.dc').write_text('fixture nodes')
        (psf / 'dcOpInfo.info').write_text('fixture OP')
        session = baseline.parent.parent
        (session / 'session.conf').write_text('source_library=LIB\nsource_cell=core\nsource_view=schematic\n')
        cds = root / 'cds.lib'
        cds.write_text('DEFINE LIB /fixture/oa\n')
        fixed = [p for p in baseline.rglob('*') if p.is_file()] + [session / 'session.conf', cds]
        bound = {
            'session': session,
            'cfg': {'source_library': 'LIB', 'source_cell': 'core', 'source_view': 'schematic'},
            'cds': cds,
            'fixed': {str(p): digest(p) for p in fixed},
            'settings': {'design': {'lib': 'BENCH', 'cell': 'tb', 'view': 'config_presim'},
                         'test_name': 'saved_dc', 'corner': 'Copy_PT_FUNC_703', 'temperature': 125.0,
                         'variables': {'VIN': '1.14'},
                         'models': [{'model_file': str(model), 'section_name': 'tt', 'sha256': digest(model)}]},
            'data': {'selection': {'bench_library': 'BENCH', 'bench_cell': 'maestro_tb', 'setup_view': 'maestro'}},
        }
        return bound, baseline, root / 'bundle', {'model': model, 'leaf': leaf, 'definition': definition,
                                                 'extra': extra, 'ahdl': ahdl, 'header': header, 'psf': psf}

    def export(self, root):
        module = self.module()
        bound, baseline, output, paths = self.fixture(root)
        manifest = module.export_bundle(bound, baseline, output, dependency_policy="recursive")
        return module, module.load_bundle(manifest), manifest, bound, baseline, paths

    def test_exports_fixed_config_dc_and_recursive_dependencies_without_mutating_inputs(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, paths = self.fixture(Path(tmp))
            before = {p: p.read_bytes() for p in Path(tmp).rglob('*') if p.is_file()}
            manifest = module.export_bundle(bound, baseline, output, dependency_policy="recursive")
            bundle = module.load_bundle(manifest, expected_source={'lib': 'LIB', 'cell': 'core', 'view': 'schematic'},
                                        expected_bench=bound['settings']['design'], corner='Copy_PT_FUNC_703')
            self.assertEqual(bundle['root_path'], 'TOP.DUT')
            self.assertEqual(bundle['source_subckt'], 'core')
            self.assertEqual(bundle['bench']['view'], 'config_presim')
            self.assertEqual(bundle['launch_contract']['argv'], ['+aps=conservative', '+mt=4'])
            self.assertEqual(bundle['variables'], {'VIN': '1.14'})
            self.assertEqual(bundle['maestro']['view'], 'maestro')
            for name in ('model', 'leaf', 'definition', 'extra', 'ahdl', 'header'):
                self.assertEqual(bundle['file_sha256'][str(paths[name])], digest(paths[name]))
            self.assertFalse(bundle['simulation_profile_ready'])
            self.assertFalse(bundle['pdk_electrical_rules_ready'])
            text = Path(bundle['bench_netlist']).read_text()
            self.assertIn('include ' + json.dumps(str(paths['model'])) + ' section=tt', text)
            self.assertIn('dcOp dc maxiters=150 maxsteps=10000', text)
            self.assertIn('ic G=0.3\nnodeset G=0.4', text)
            for path, content in before.items():
                self.assertEqual(path.read_bytes(), content)

    def test_load_rejects_source_bench_and_corner_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, path, *_ = self.export(Path(tmp))
            for kwargs in ({'expected_source': {'lib': 'WRONG', 'cell': 'core', 'view': 'schematic'}},
                           {'expected_bench': {'lib': 'BENCH', 'cell': 'tb', 'view': 'schematic'}},
                           {'corner': 'other'}):
                with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                    module.load_bundle(path, **kwargs)

    def test_load_rejects_changed_fixed_recursive_dependency_psf_or_bundle_deck(self):
        for key in ('model', 'leaf', 'definition', 'extra', 'ahdl', 'header', 'fixed', 'psf', 'deck'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                module, bundle, manifest, bound, baseline, paths = self.export(Path(tmp))
                path = (bound['session'] / 'session.conf' if key == 'fixed' else
                        paths['psf'] / 'dcOp.dc' if key == 'psf' else
                        Path(bundle['bench_netlist']) if key == 'deck' else paths[key])
                path.write_text(path.read_text() + '\nchanged\n')
                with self.assertRaises(ValueError):
                    module.load_bundle(manifest)

    def test_manifest_content_is_hash_bound(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, _, manifest, *_ = self.export(Path(tmp))
            value = json.loads(manifest.read_text())
            value['temperature'] = 27
            manifest.write_text(json.dumps(value))
            with self.assertRaises(ValueError):
                module.load_bundle(manifest)

    def test_export_rejects_drift_before_creating_a_bundle(self):
        for key in ('fixed', 'model', 'definition'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                target = bound['session'] / 'session.conf' if key == 'fixed' else paths[key]
                target.write_text(target.read_text() + '\nchanged\n')
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output, dependency_policy="recursive")
                self.assertFalse(output.exists())

    def test_unresolved_and_nonliteral_dependency_is_rejected(self):
        for include in ('include "missing.scs"', 'include dynamic_path',
                        'include "$UNDEFINED_BASELINE_BUNDLE_TEST/model.scs"',
                        '`include "missing.vams"'):
            with self.subTest(include=include), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                paths['leaf'].write_text(include + '\n')
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output, dependency_policy="recursive")

    def test_unsupported_launch_or_missing_effective_controls_is_rejected(self):
        for mode in ('classic', 'threads', 'controls', 'launch'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                if mode in ('classic', 'threads'):
                    replacement = ('"APS"', '"Spectre"') if mode == 'classic' else ('"4"', '"4;evil"')
                    for name in ('settings_forms.json', 'saved_test.ocn'):
                        p = baseline / name
                        p.write_text(p.read_text().replace(*replacement))
                        bound['fixed'][str(p)] = digest(p)
                elif mode == 'controls':
                    for p in (baseline / 'baseline_run.scs', baseline / 'baseline_generated/input.scs'):
                        p.write_text(p.read_text().replace('maxiters=150', 'maxiters=2'))
                        bound['fixed'][str(p)] = digest(p)
                else:
                    p = baseline / 'baseline_run/ocean.log'
                    p.write_text('Command line: spectre input.scs\n')
                    bound['fixed'][str(p)] = digest(p)
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output, dependency_policy="recursive")

    def test_candidate_replaces_only_dut_and_preserves_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            candidate = '''simulator lang=spectre
subckt candidate D G S B
M0 (D G S B) nmod l=20n nfin=3
ends candidate
'''
            text, root = module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')
            self.assertEqual(root, 'TOP.DUT')
            self.assertIn('DUT (P Q R T) candidate', text)
            self.assertIn('M0 (D G S B) nmod l=20n nfin=3', text)
            for line in ('V0 (VIN 0) vsource dc=VIN', 'simulatorOptions options temp=125 reltol=1e-3',
                         'dcOp dc maxiters=150 maxsteps=10000', 'ic G=0.3', 'nodeset G=0.4'):
                self.assertIn(line, text)

    def test_candidate_top_level_changes_cannot_be_silently_dropped(self):
        for extra in ('include "candidate_only.scs"', 'global NEW_GLOBAL', 'parameters VIN=2',
                      'model localmod resistor r=2', 'model unseen resistor r=2'):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                module, bundle, _, *_ = self.export(root)
                (root / 'candidate_only.scs').write_text('model added resistor r=1\n')
                candidate = 'simulator lang=spectre\n' + extra + '\nsubckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\n'
                with self.assertRaises(ValueError):
                    module.prepare_candidate_deck(bundle, candidate, root, 'candidate')

    def test_candidate_root_port_drift_is_rejected(self):
        candidate = 'subckt candidate G D S B\nM0 (D G S B) nmod\nends candidate\n'
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            with self.assertRaisesRegex(ValueError, 'port'):
                module.prepare_candidate_deck(bundle, 'simulator lang=spectre\n' + candidate, Path(tmp), 'candidate')

    def test_shared_definition_gets_private_copy_without_changing_bench_wiring(self):
        from op_provider import parse_deck
        candidate = ('subckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\n'
                     'subckt wrap P Q R T\nDUT (Q P R T) core\nends wrap\n')
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            text, root = module.prepare_candidate_deck(bundle, 'simulator lang=spectre\n' + candidate, Path(tmp), 'candidate')
            definitions = parse_deck(text)['definitions']
            self.assertEqual(root, 'TOP.DUT')
            self.assertEqual(definitions['wrap']['instances'][0]['nodes'], ['P','Q','R','T'])
            self.assertEqual(definitions['wrap']['instances'][0]['master'], 'candidate')
            private = definitions['candidate__ST_DUT_1']['instances'][0]
            self.assertEqual(private['nodes'], ['Q','P','R','T'])
            self.assertEqual(private['master'], 'core')

    def test_candidate_rechecks_bundle_files_and_rejects_mutated_loaded_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, _, _, paths = self.export(Path(tmp))
            candidate = 'simulator lang=spectre\nsubckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\n'
            changed = dict(bundle, root_path='WRONG')
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(changed, candidate, Path(tmp), 'candidate')
            paths['leaf'].write_text('model changed resistor r=1\n')
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')

    def test_existing_output_is_never_overwritten(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            output.mkdir()
            (output / 'keep').write_text('untouched')
            with self.assertRaises(ValueError):
                module.export_bundle(bound, baseline, output, dependency_policy="recursive")
            self.assertEqual((output / 'keep').read_text(), 'untouched')

    def test_extra_launch_flags_require_saved_values_and_matching_native_evidence(self):
        for proven in (False, True):
            with self.subTest(proven=proven), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, _ = self.fixture(Path(tmp))
                forms = json.loads((baseline / 'settings_forms.json').read_text())
                forms += ['envOption(\'licQueueTimeOut "900")', 'option(\'maxwarns "5" \'maxnotes "7")']
                (baseline / 'settings_forms.json').write_text(json.dumps(forms))
                (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
                log = baseline / 'baseline_run/ocean.log'
                if proven:
                    log.write_text('Command line: spectre +aps=conservative +mt=4 +lqtimeout 900 -maxw 5 -maxn 7 input.scs\n')
                for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                    p = baseline / name
                    bound['fixed'][str(p)] = digest(p)
                bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
                contract = bundle['launch_contract']
                self.assertEqual(contract['complete'], proven)
                if proven:
                    self.assertEqual(contract['argv'], ['+aps=conservative', '+mt=4', '+lqtimeout', '900', '-maxw', '5', '-maxn', '7'])
                    self.assertEqual(contract['omitted_launch_options'], [])
                else:
                    self.assertEqual({item['name'] for item in contract['omitted_launch_options']}, {'licQueueTimeOut', 'maxwarns', 'maxnotes'})

    def test_multiple_sections_of_same_model_are_preserved(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, paths = self.fixture(Path(tmp))
            paths['model'].write_text(paths['model'].read_text()+'section pre\nendsection pre\n')
            bound['settings']['models'][0]['sha256']=digest(paths['model'])
            bound['settings']['models'].append(dict(bound['settings']['models'][0], section_name='pre'))
            for name in ('baseline_run.scs', 'baseline_generated/input.scs'):
                p = baseline / name
                p.write_text(p.read_text().replace('section=tt', 'section=tt\ninclude "../../../../shared/model.scs" section=pre'))
                bound['fixed'][str(p)] = digest(p)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
            self.assertEqual([m['section_name'] for m in bundle['models']], ['tt', 'pre'])

    def test_extended_native_turbo_settings_are_preserved_without_claiming_full_launch_replay(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms[3] = forms[3][:-1] + ' \'cktpreset "None" \'digitalspeed "2" \'dcOPSolver "APS" \'disableVddOverride t \'optvdd "3.3" \'psrOption "Default" \'psrXpsmsOption "Default" \'preserveOption "None" \'rfmtOption "Disable")'
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            for name in ('settings_forms.json', 'saved_test.ocn'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
            self.assertEqual(bundle['launch_contract']['saved_turbo_options']['dcOPSolver'], 'APS')
            self.assertEqual(bundle['launch_contract']['saved_turbo_options']['disableVddOverride'], 't')
            self.assertFalse(bundle['launch_contract']['complete'])
            self.assertIn('cktpreset', {item['name'] for item in bundle['launch_contract']['omitted_launch_options']})

    def test_saved_extra_launch_flags_are_verified_from_full_multiline_native_command(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms += ['envOption(\'licQueueTimeOut "900")', 'option(\'maxwarns "5" \'maxnotes "7")']
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            (baseline / 'baseline_run/ocean.log').write_text('Command line:\n    spectre input.scs +escchars \\\n    +aps=conservative +mt=4 \\\n    +lqtimeout 900 -maxw 5 -maxn 7\n\nSimulator ready\n')
            for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
            self.assertTrue(bundle['launch_contract']['complete'])
            self.assertIn('+lqtimeout', bundle['launch_contract']['argv'])
            self.assertIn('-maxn', bundle['launch_contract']['argv'])

    def test_candidate_cannot_add_untracked_include_inside_subcircuit(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            (Path(tmp) / 'other.scs').write_text('model another resistor r=2\n')
            candidate = 'simulator lang=spectre\nsubckt candidate D G S B\ninclude "other.scs"\nM0 (D G S B) nmod\nends candidate\n'
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')

    def test_exact_native_aps_variant_is_preserved_and_conflicting_flags_are_rejected(self):
        for flags in ('++aps=conservative +mt=4', '+aps=conservative +mt=4 +mt=8'):
            with self.subTest(flags=flags), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, _ = self.fixture(Path(tmp))
                log = baseline / 'baseline_run/ocean.log'
                log.write_text('Command line: spectre ' + flags + ' input.scs\n')
                bound['fixed'][str(log)] = digest(log)
                if flags.startswith('++'):
                    bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
                    self.assertEqual(bundle['launch_contract']['argv'][0], '++aps=conservative')
                else:
                    with self.assertRaises(ValueError):
                        module.export_bundle(bound, baseline, output, dependency_policy="recursive")

    def test_ambiguous_extra_launch_flags_and_unproven_environment_are_explicitly_omitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self.module()
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms += ['envOption(\'licQueueTimeOut "900" \'customRunMode "saved")']
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            (baseline / 'baseline_run/ocean.log').write_text('Command line: spectre +aps=conservative +mt=4 +lqtimeout 900 +lqtimeout 10 input.scs\n')
            for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output, dependency_policy="recursive"))
            contract = bundle['launch_contract']
            self.assertFalse(contract['complete'])
            self.assertNotIn('+lqtimeout', contract['argv'])
            self.assertEqual({item['name'] for item in contract['omitted_launch_options']}, {'licQueueTimeOut', 'customRunMode'})

    def test_bundle_retains_pinned_hashes_and_distinguishes_new_dependency_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self.module()
            bound, baseline, output, paths = self.fixture(Path(tmp))
            pinned = baseline.parent.parent / 'pinned_init.il'
            pinned.write_text('; original pinned initialization\n')
            bound['pinned'] = {'file_sha256': {str(pinned): digest(pinned)}}
            manifest = module.export_bundle(bound, baseline, output, dependency_policy="recursive")
            bundle = module.load_bundle(manifest)
            self.assertEqual(bundle['file_sha256'][str(pinned)], digest(pinned))
            historical = set(bundle['historical_verified_paths'])
            first_seen = set(bundle['first_fingerprinted_at_export_paths'])
            self.assertIn(str(pinned), historical)
            self.assertIn(str(paths['model']), historical)
            self.assertIn(str(paths['definition']), historical)
            self.assertIn(str(paths['leaf']), first_seen)
            self.assertIn(str(paths['header']), first_seen)
            self.assertNotIn(str(paths['leaf']), historical)
            self.assertFalse(historical & first_seen)
            self.assertEqual(historical | first_seen, set(bundle['file_sha256']))
            self.assertFalse(bundle['recursive_dependencies_historically_verified'])
            pinned.write_text('; changed after bundle export\n')
            with self.assertRaises(ValueError):
                module.load_bundle(manifest)

    def test_stale_or_conflicting_pinned_fingerprints_are_not_recomputed(self):
        for mode in ('stale', 'conflicting_fixed', 'conflicting_model'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                pinned = baseline.parent.parent / 'pinned_init.il'
                pinned.write_text('; original pinned initialization\n')
                old_hash = digest(pinned)
                bound['pinned'] = {'file_sha256': {str(pinned): old_hash}}
                if mode == 'stale':
                    pinned.write_text('; drift before export\n')
                elif mode == 'conflicting_fixed':
                    bound['fixed'][str(pinned)] = '0' * 64
                else:
                    bound['pinned']['file_sha256'][str(paths['model'])] = '0' * 64
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output, dependency_policy="recursive")
                self.assertFalse(output.exists())


if __name__ == '__main__':
    unittest.main()
