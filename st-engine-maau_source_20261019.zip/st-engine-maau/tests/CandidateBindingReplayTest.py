"""Read-only replay of retained candidate files, never native EDA."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT/'scripts/inspect_cascode_candidate_bindings.py'


class CandidateBindingReplayTest(unittest.TestCase):
    def module(self):
        self.assertTrue(ENTRY.is_file(), 'candidate replay script missing')
        spec = importlib.util.spec_from_file_location('candidate_replay', ENTRY)
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        return module

    def fixture(self, root, mode):
        from ExperimentalReuseTest import ReuseIntegrationTest
        candidate, inputs, bundle = ReuseIntegrationTest().fixture(root, segmented=True)
        work = candidate/'work'
        original = work/'analysis/baseline_op/raw_op/st-op-simulation.test'
        run = work/'analysis/candidates/candidate_004/raw_op/st-op-simulation.new'; run.mkdir(parents=True)
        text = (original/'simulation.scs').read_text().replace('subckt core ', 'subckt changed ').replace('ends core', 'ends changed').replace(') core', ') changed')
        if mode == 'spelling': text = text.replace('R1_2__res_gen', 'R1_2_res_gen')
        if mode == 'node': text = text.replace('R1_mid1', 'R1_private_new')
        if mode == 'parameter': text = text.replace('R1_2__res_gen (R1_mid1 R1_mid2) rmod r=2k', 'R1_2__res_gen (R1_mid1 R1_mid2) rmod r=3k')
        if mode == 'new': text = text.replace('ends changed','NEW (G new_mid) rmod r=2k\nNEW_2_res_gen (new_mid S) rmod r=2k\nends changed')
        if mode == 'tap': text = text.replace('ends changed','Cnew (R1_mid1 S) capacitor c=1p\nends changed')
        (run/'simulation.scs').write_text(text)
        bindings = (original/'oa_bindings.tsv').read_text()
        if mode == 'new': bindings += 'NEW\tP\tR\tsymbol\tPLUS,MINUS\ttarget\trmod\n'
        (run/'oa_bindings.tsv').write_text(bindings)
        binding = json.loads((original/'binding.json').read_text())
        binding.update(dut=['DERIVED','changed','schematic'], simulation_sha256=hashlib.sha256(text.encode()).hexdigest())
        (run/'binding.json').write_text(json.dumps(binding))
        manifest = work/'analysis/standalone_inputs/provider_inputs.json'; manifest.parent.mkdir(parents=True)
        inputs['file_sha256'] = {v:hashlib.sha256(Path(v).read_bytes()).hexdigest() for v in inputs.values()}
        manifest.write_text(json.dumps(inputs))
        (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',failed_stage='generate')))
        return candidate, run

    def test_latest_selection_never_uses_baseline_op(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);old=root/'work/analysis/baseline_op/raw_op/st-op-simulation.old';old.mkdir(parents=True)
            new=root/'work/analysis/candidates/candidate_004/raw_op/st-op-simulation.new';new.mkdir(parents=True)
            (new/'binding.json').write_text('{}');(old/'binding.json').write_text('{}')
            self.assertEqual(m.select_simulation(root), new.resolve())

    def test_all_failure_reasons_are_read_without_native_or_input_changes(self):
        m=self.module()
        cases={'spelling':'segment_names_changed','node':'segment_nodes_changed','parameter':'segment_parameters_changed',
               'new':'absent_from_baseline','tap':'internal_node_contacts_changed'}
        for mode, reason in cases.items():
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
                candidate,run=self.fixture(Path(tmp).resolve(),mode)
                protected={p:p.read_bytes() for p in candidate.parent.rglob('*') if p.is_file()}
                with patch('subprocess.run',side_effect=AssertionError('must not run native')):
                    report=m.inspect(candidate,ROOT)
                self.assertEqual(report['simulation_directory'],str(run))
                self.assertFalse(report['binding_replay_passed'])
                self.assertIn('validation.txt',report['production_error'])
                groups={row['parent']:row for row in report['groups']}
                self.assertIn(reason,groups['NEW' if mode=='new' else 'R1']['reasons'])
                self.assertEqual(report['native_executions'],0)
                self.assertTrue(all(p.read_bytes()==data for p,data in protected.items()))

    def test_unchanged_candidate_can_be_replayed_without_claiming_dc_success(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            candidate,_=self.fixture(Path(tmp).resolve(),'unchanged')
            report=m.inspect(candidate,ROOT)
            self.assertTrue(report['binding_replay_passed'])
            self.assertEqual(report['groups'],[])
            self.assertFalse(report['electrical_verified'])

    def test_retained_deck_drift_rejected_before_replay(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as tmp:
            candidate,run=self.fixture(Path(tmp).resolve(),'node')
            (run/'simulation.scs').write_text('changed after failure')
            with self.assertRaisesRegex(ValueError,'retained simulation fingerprint'):
                m.inspect(candidate,ROOT)

    def test_new_parent_checked_readback_replay_and_require_pass_exit(self):
        import op_provider as op
        m=self.module()
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            candidate,run=self.fixture(Path(tmp).resolve(),'new')
            with patch.object(sys,'argv',[str(ENTRY),'--engine',str(ROOT),'--candidate',str(candidate),'--require-pass']):
                self.assertEqual(m.main(),2)
            native=(run/'simulation.scs').read_text();deck=op.parse_deck(native)
            core=deck['definitions']['changed']
            logical='\n'.join(deck['lines'][core['start']:core['end']+1])+'\n'
            logical=logical.replace('subckt changed ','subckt core ').replace('ends changed','ends core')
            logical=logical.replace('NEW (G new_mid) rmod r=2k\nNEW_2_res_gen (new_mid S) rmod r=2k',
                'NEW (G S) P/R r=4k segments=2')
            folder=run.parent.parent
            for name in ('expected/core_expected.scs','roundtrip/complete.scs'):
                p=folder/name;p.parent.mkdir();p.write_text(logical)
            (folder/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            with patch('subprocess.run',side_effect=AssertionError('must not launch native')):
                report=m.inspect(candidate,ROOT)
                with patch.object(sys,'argv',[str(ENTRY),'--engine',str(ROOT),'--candidate',str(candidate),'--require-pass']):
                    self.assertEqual(m.main(),0)
            self.assertTrue(report['binding_replay_passed'])
            self.assertEqual(report['missing_instances'],[])
            self.assertEqual(report['groups'],[])
            self.assertEqual(report['aggregates'][0]['segment_count'],2)
            self.assertEqual(len(report['query']['currents']),2)
            self.assertFalse(report['electrical_verified'])
            with patch.object(op,'build_dc_query',side_effect=ValueError('query failed')):
                failed=m.inspect(candidate,ROOT)
            self.assertFalse(failed['binding_replay_passed'])
            self.assertTrue(failed['device_binding_passed'])
            self.assertEqual(failed['failure_stage'],'dc_query')
            self.assertEqual(failed['missing_instances'],[])
            self.assertEqual(failed['groups'],[])
            self.assertEqual(failed['aggregates'][0]['segment_count'],2)


if __name__=='__main__': unittest.main()
