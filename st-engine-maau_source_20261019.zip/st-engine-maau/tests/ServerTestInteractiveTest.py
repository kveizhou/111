"""Narrow tests for the server helper's input and failure gates, not Cadence evidence."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/server_test_interactive.py'


class InteractiveServerTest(unittest.TestCase):
    def module(self):
        self.assertTrue(SCRIPT.is_file(), '缺少用户要求的交互式服务器测试入口')
        spec = importlib.util.spec_from_file_location('server_interactive', SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_failed_command_stops_and_records_actual_exit_code(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            runner = module.Runner(Path(tmp), Path(tmp), {})
            with self.assertRaises(module.CommandFailure):
                runner.run('failed', [sys.executable, '-c', 'print("actual failure"); raise SystemExit(7)'])
            history = json.loads((Path(tmp) / 'commands.jsonl').read_text().strip())
            self.assertEqual(history['exit_code'], 7)
            self.assertIn('actual failure', (Path(tmp) / 'failed.log').read_text())

    def test_existing_run_is_preserved_and_new_run_is_selected(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            old = Path(tmp) / 'used'
            old.mkdir()
            (old / 'evidence').write_text('keep')
            with patch('builtins.input', side_effect=['used', 'new']):
                created = module.new_run(Path(tmp))
            self.assertEqual(created.name, 'new')
            self.assertEqual((old / 'evidence').read_text(), 'keep')

    def test_manual_profile_keeps_real_sections_signs_and_current_limits(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            model = Path(tmp) / 'actual models.scs'
            model.write_text('// selected model file')
            answers = ['tt', 'ss', 'VDD', 'AGND', '0.02', '1e-5', 'core',
                       '27', str(model), 'tt', '', '{"WBIAS":"1u"}',
                       '-40', str(model), 'ss', '', '{"WBIAS":"2u"}',
                       'VSUP:p', '-1', '']
            with patch('builtins.input', side_effect=answers):
                profile = module.collect_profile('core')
            self.assertEqual(profile['pvt_corners'], ['ss'])
            self.assertEqual(profile['op_corners']['ss']['temperature'], -40)
            self.assertEqual(profile['op_corners']['ss']['models'][0]['section_name'], 'ss')
            self.assertEqual(profile['supply_current_signals'], [{'signal': 'VSUP:p', 'sign': -1}])
            self.assertEqual(profile['max_branch_current_error'], 0.02)
            self.assertEqual(profile['max_vbias_current'], 1e-5)

    def test_no_spec_profile_omits_optional_limits_and_keeps_nominal_conditions(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            model = Path(tmp) / 'actual.scs'
            model.write_text('// actual model')
            answers = ['tt', '', 'VDD', 'AGND', '', '', 'core',
                       '27', str(model), 'tt', '', '{}', 'VSUP:p', '-1', '']
            with patch('builtins.input', side_effect=answers):
                profile = module.collect_profile('core')
            self.assertNotIn('max_branch_current_error', profile)
            self.assertNotIn('max_vbias_current', profile)
            self.assertEqual(profile['vbias_vhigh_net'], 'VDD')
            self.assertEqual(profile['pvt_corners'], [])
            self.assertEqual(profile['op_corners']['tt']['models'][0]['model_file'], str(model.resolve()))

    def test_zero_exit_does_not_override_failed_validation_or_changed_source(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            for name in ('reports', 'before', 'after'): (work / name).mkdir()
            report = work / 'reports/validation.txt'
            report.write_text('ok=false\nready_for_sizing=false\nstage=nominal_dc_check\n')
            (work / 'before/core_before.scs').write_text('original')
            (work / 'after/source_roundtrip.scs').write_text('original')
            with self.assertRaisesRegex(ValueError, 'validation'):
                module.check_final(work)
            report.write_text('ok=true\nready_for_sizing=true\nstage=complete\n')
            (work / 'after/source_roundtrip.scs').write_text('changed')
            with self.assertRaisesRegex(ValueError, '源电路'):
                module.check_final(work)
            (work / 'after/source_roundtrip.scs').write_text('original')
            module.check_final(work)

    def test_unknown_required_input_stops_without_inventing_a_value(self):
        module = self.module()
        with patch('builtins.input', return_value='?'):
            with self.assertRaises(module.InputPending):
                module.ask('实际限值')

    def test_interactive_process_stops_before_tests_when_build_fails(self):
        self.module()
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'engine'
            (root / 'scripts').mkdir(parents=True)
            (root / 'docs/validation/2026-10-07').mkdir(parents=True)
            build = root / 'scripts/build.sh'
            build.write_text('echo actual_build_failure\nexit 7\n')
            (root / 'scripts/test.sh').write_text('touch should_not_exist\n')
            hashes = {'scripts/build.sh': hashlib.sha256(build.read_bytes()).hexdigest()}
            (root / 'docs/validation/2026-10-07/server-source-sha256.json').write_text(json.dumps(hashes))
            parent = Path(tmp) / 'runs'
            result = subprocess.run([sys.executable, str(SCRIPT), '--project', str(root)],
                        input='1\n' + str(parent) + '\nfresh\n', text=True, capture_output=True)
            self.assertEqual(result.returncode, 7, result.stdout + result.stderr)
            self.assertFalse((root / 'should_not_exist').exists())
            self.assertIn('actual_build_failure', (parent / 'fresh/logs/01_build.log').read_text())
            build.write_text('exit 0\n')
            drift = subprocess.run([sys.executable, str(SCRIPT), '--project', str(root)],
                                   input='', text=True, capture_output=True)
            self.assertEqual(drift.returncode, 2)
            self.assertIn('源码不匹配', drift.stderr)

    def test_source_resistor_operation_uses_scanned_cdf_and_retains_mos_semantics(self):
        module = self.module()
        mos = [{'instance': 'I53', 'polarity': 'mos_n', 'master': 'N', 'bulk': 'AGND'}]
        devices = [{'master': 'realR', 'kind': 'resistor',
                    'normalized_to_cdf': {'resistance': 'r'},
                    'parameter_constraints': {'resistance': {'cdf_name': 'r', 'minimum': 10,
                                             'maximum': 1e5, 'grid': 10}},
                    'terminal_roles': ['positive', 'negative'], 'terminal_count': 2}]
        with patch('builtins.input', side_effect=['1', 'I53', 'realR', '1000']):
            operation = module.collect_operation(mos, devices)
        self.assertEqual(operation['type'], 'resistor')
        self.assertEqual(operation['resistor.parameter'], 'r')
        self.assertEqual(operation['resistor.grid'], '10')
        self.assertEqual(operation['instance'], 'I53')
        self.assertNotIn('critical_dynamic_gate', operation)


if __name__ == '__main__':
    unittest.main()
