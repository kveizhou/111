"""Local contracts for discovery; the OA reader itself requires server acceptance."""
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))


class DiscoveryTest(unittest.TestCase):
    def test_process_identity_uses_database_owner_instead_of_direct_attachment(self):
        source = (ROOT / 'server/skill/tech_adapter.il').read_text()
        self.assertIn('procedure(stTechResolveLibraryIdentity', source,
                      'Missing shared canonical technology-database resolver')
        self.assertIn('procedure(stTechReadLibraryTechnology', source)
        resolver = source.split('procedure(stTechResolveLibraryIdentity', 1)[1].split(
            'procedure(stTechDefaultLibraryIdentity', 1)[0]
        self.assertIn('"databaseOwner"', resolver)
        self.assertNotRegex(resolver, r'owner\s*=\s*stTechGet\([^\n]*"attachedTechnology"',
                            'Direct attachment is diagnostic only, not process identity')
        self.assertIn('member(current chain)', resolver)
        self.assertIn('length(chain) < 64', resolver)
        self.assertIn('equal(owner current)', resolver)
        self.assertIn('"technologyChain"', resolver)
        discovery = (ROOT / 'server/skill/discover_pdk.il').read_text()
        self.assertIn('sourceChain=%L', discovery)
        self.assertIn('deviceChain=%L', discovery)

    def test_native_identity_check_contains_real_production_resolver(self):
        native = ROOT / 'tests/TechIdentityNative.py'
        self.assertTrue(native.is_file(), 'Native SKILL resolver acceptance entry missing')
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            cds = base / 'cds.lib'
            cds.write_text('// fixture\n')
            work = base / 'native'
            result = subprocess.run([sys.executable, str(native), '--cds-lib', str(cds),
                '--work-dir', str(work), '--prepare-only'], text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            action = (work / 'tech_identity_check.il').read_text()
            self.assertIn(str(ROOT / 'server/skill/tech_adapter.il'), action)
            self.assertIn('stTechResolveLibraryIdentity', action)
            for fixture in ('chain_source', 'chain_device', 'root', 'foreign',
                            'incremental', 'missing', 'dangling', 'cycle', 'deep', 'empty'):
                self.assertIn('"' + fixture + '"', action)
            self.assertIn('TECH_IDENTITY_NATIVE_OK cases=10', native.read_text())
            self.assertIn('native execution not performed', result.stdout)

    def test_discovery_errors_do_not_dereference_closed_source_objects(self):
        source = (ROOT / 'server/skill/discover_pdk.il').read_text()
        errors = re.findall(r'dbClose\(cv\)\s*error\((.*?)\)\s*\)', source, re.S)
        self.assertTrue(errors, 'Expected close-and-report error paths')
        for error in errors:
            self.assertNotRegex(error, r'\b(?:inst|cv)\s*(?:~>|->)',
                                'Error reporting dereferences an OA object after dbClose')

    def test_builtin_libraries_are_excluded_before_primitive_cdf_inspection(self):
        source = (ROOT / 'server/skill/discover_pdk.il').read_text()
        body = source.split('procedure(stDiscoverPrimitiveCellP', 1)[1].split('procedure(stDiscoverRecord', 1)[0]
        gate = body.find('unless(stTechBuiltinLibraryP(library)')
        read = body.find('cdfGetBaseCellCDF')
        self.assertGreaterEqual(gate, 0, 'Builtin libraries must not be classified as foundry primitives')
        self.assertLess(gate, read, 'Builtin gate must precede CDF inspection')

    def test_cdf_simulator_property_lists_do_not_use_mapping_access(self):
        # simInfo and Spectre are DPLs containing scalar/string values (IN,
        # model names, etc.), not lists of objects. ~> maps over those values.
        for name in ('discover_pdk', 'probe_pdk', 'tech_adapter', 'site_metadata_adapter'):
            with self.subTest(reader=name):
                source = (ROOT / 'server/skill' / (name + '.il')).read_text()
                chains = re.findall(r'(?:cdf|cdfData)(?:->|~>)simInfo(?:->|~>)spectre(?:(?:->|~>)termOrder)?', source)
                self.assertTrue(chains, 'CDF simulator lookup missing in ' + name)
                for chain in chains:
                    self.assertNotIn('~>', chain, 'CDF DPL lookup maps over scalar values: ' + chain)

    def test_failed_batch_exposes_late_skill_error_and_preserves_exit_status(self):
        for process_status in (0, 7):
            with self.subTest(process_status=process_status), tempfile.TemporaryDirectory() as tmp:
                base = Path(tmp).resolve()
                cds = base / 'cds.lib'
                cds.write_text('// fixture\n')
                init = base / 'init.il'
                init.write_text('; fixture\n')
                virtuoso = base / 'virtuoso.py'
                virtuoso.write_text('#!/usr/bin/env python3\nimport pathlib,sys\n'
                    'log=pathlib.Path(sys.argv[sys.argv.index("-log")+1])\n'
                    'log.write_text("startup\\n"*385 + \'*Error* get/getq: first arg - "IN"\\n\')\n'
                    'raise SystemExit(' + str(process_status) + ')\n')
                virtuoso.chmod(0o755)
                env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
                env.update(ST_VIRTUOSO_BIN=str(virtuoso), ST_SKILL_INIT=str(init), ST_BACKEND_RUN_ROOT=str(base))
                result = subprocess.run([str(ROOT / 'server/st_virtuoso_backend.sh'), 'discover-pdk',
                    '--cds-lib', str(cds), '--lib', 'L', '--cell', 'core', '--view', 'schematic',
                    '--output', str(base / 'discovery.tsv')], env=env, capture_output=True, text=True)
                self.assertEqual(result.returncode, process_status or 70)
                self.assertIn('*Error* get/getq: first arg - "IN"', result.stdout + result.stderr)
                retained = list(base.glob('st-virtuoso-backend.*'))
                self.assertEqual(len(retained), 1)
                self.assertIn('"IN"', (retained[0] / 'virtuoso.log').read_text())

    def fixture(self, base):
        tech, devices = base / 'tech library', base / 'device library'
        tech.mkdir(); devices.mkdir()
        model = base / 'models.scs'
        model.write_text('model nreal bsim4 type=n\n')
        (base / 'unrelated.scs').write_text('model nreal bsim4 type=p\n')
        cds = base / 'cds.lib'; cds.write_text('// fixture\n')
        discovery = ('role\tlibrary\tpath\ttechnology\tcell\tview\n'
            'source\tL\t' + str(base) + '\tTECH\tcore\tschematic\n'
            'technology\tTECH\t' + str(tech) + '\tTECH\t\t\n'
            'device\tPDK\t' + str(devices) + '\tTECH\t\t\n')
        probe = ('oa_library\toa_cell\toa_view\tmodel_name\tterminal_names\tparameter\tunits\tmin\tmax\n'
            'PDK\tN\tsymbol\tnreal\tD,G,S,B\tw\tlengthMetric\t1u\t10u\n')
        backend = base / 'backend.py'
        backend.write_text('#!/usr/bin/env python3\nimport pathlib,sys\n'
            'a=dict(zip(sys.argv[2::2],sys.argv[3::2]))\n'
            'if sys.argv[1]=="discover-pdk":\n'
            ' assert a["--lib"]=="L" and a["--cell"]=="core"\n'
            ' pathlib.Path(a["--output"]).write_text(' + repr(discovery) + ')\n'
            'elif sys.argv[1]=="probe-pdk":\n'
            ' assert "--libraries-file" in a and "--pdk-root" not in a\n'
            ' pathlib.Path(a["--output"]).write_text(' + repr(probe) + ')\n'
            'else: raise SystemExit(64)\n')
        backend.chmod(0o755)
        env = dict(os.environ)
        for key in list(env):
            if key.startswith('ST_'): env.pop(key)
        return tech, devices, model, cds, backend, discovery, env

    def test_discover_without_helper_or_pdk_input_preserves_exact_library_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            tech, devices, model, cds, backend, raw, env = self.fixture(base)
            out = base / 'discovered'
            command = [sys.executable, str(ROOT / 'server/site/standalone.py'), 'discover-pdk',
                '--backend', str(backend), '--cds-lib', str(cds), '--lib', 'L', '--cell', 'core',
                '--view', 'schematic', '--output', str(out)]
            result = subprocess.run(command, env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads((out / 'pdk_discovery.json').read_text())
            self.assertEqual(data['source'], {'lib': 'L', 'cell': 'core', 'view': 'schematic'})
            self.assertEqual(data['technology_library'], 'TECH')
            self.assertEqual(data['pdk_paths'], [str(tech), str(devices)])
            self.assertEqual((out / 'pdk_libraries.tsv').read_text(), 'library\tpath\nPDK\t' + str(devices) + '\n')
            self.assertIn('PDK_DISCOVERY_OK', result.stdout)
            again = subprocess.run(command, env=env, capture_output=True)
            self.assertNotEqual(again.returncode, 0)
            self.assertEqual((out / 'discovery.tsv').read_text(), raw)

    def test_inspect_automatically_uses_discovery_and_pins_its_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            tech, devices, model, cds, backend, raw, env = self.fixture(base)
            profile = base / 'profile.json'
            profile.write_text(json.dumps({'nominal_corner': 'tt', 'op_corners': {
                'tt': {'models': [{'model_file': str(model), 'section_name': 'tt'}]}}}))
            capture = base / 'capture.json'
            engine = base / 'engine.py'
            engine.write_text('#!/usr/bin/env python3\nimport json,os,pathlib\n'
                'json.dump({"metadata":os.environ["ST_PDK_METADATA"],"init":os.environ["ST_SKILL_INIT"]},'
                'open(' + repr(str(capture)) + ',"w"))\n')
            engine.chmod(0o755)
            session = base / 'session'
            result = subprocess.run([sys.executable, str(ROOT / 'server/site/standalone.py'), 'inspect',
                '--engine', str(engine), '--simulation-profile', str(profile), '--backend', str(backend),
                '--cds-lib', str(cds), '--lib', 'L', '--cell', 'core', '--view', 'schematic',
                '--bench-lib', 'L', '--bench-cell', 'bench', '--work-dir', str(session)],
                env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            record = json.loads(capture.read_text())
            metadata = json.loads(Path(record['metadata']).read_text())[0]
            self.assertEqual(metadata['pdk_paths'], [str(tech), str(devices)])
            self.assertEqual(metadata['pdk_name'], 'TECH')
            self.assertEqual(record['init'], str(ROOT / 'server/skill/init.il'))
            manifest = json.loads((session / 'analysis/standalone_inputs/provider_inputs.json').read_text())
            evidence = session / 'analysis/standalone_inputs/pdk_discovery.json'
            self.assertIn(str(evidence), manifest['file_sha256'])
            evidence.write_text('{}')
            changed = subprocess.run([sys.executable, str(ROOT / 'server/site/standalone.py'), 'generate',
                '--engine', str(engine), '--session', str(session)], env=env, text=True, capture_output=True)
            self.assertEqual(changed.returncode, 2)
            self.assertIn('changed', changed.stderr)

    def test_foreign_technology_or_wrong_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            tech, devices, model, cds, backend, raw, env = self.fixture(base)
            module = importlib.import_module('pdk_discovery')
            report = base / 'discovery.tsv'
            report.write_text(raw.replace('PDK\t' + str(devices) + '\tTECH', 'PDK\t' + str(devices) + '\tOTHER'))
            with self.assertRaisesRegex(ValueError, 'technology'):
                module.read_discovery(report, {'lib': 'L', 'cell': 'core', 'view': 'schematic'})
            report.write_text(raw)
            with self.assertRaisesRegex(ValueError, 'source'):
                module.read_discovery(report, {'lib': 'WRONG', 'cell': 'core', 'view': 'schematic'})

    def test_plan_conversion_keeps_json_data_and_rejects_nonfinite_duplicates(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            source = base / 'plan.json'; out = base / 'plan.il'
            source.write_text('{"x":[true,false,null,1.25],"name":"a\\\"b","nested":{"key":"value"}}')
            command = [sys.executable, str(ROOT / 'server/site/prepare_skill_plan.py'),
                       '--input', str(source), '--output', str(out)]
            result = subprocess.run(command, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            text = out.read_text()
            self.assertIn('list("x" list(t nil nil 1.25))', text)
            self.assertIn('list("nested" list(list("key" "value")))', text)
            for invalid in ('{"x":NaN}', '{"x":1,"x":2}'):
                source.write_text(invalid)
                result = subprocess.run(command, text=True, capture_output=True)
                self.assertNotEqual(result.returncode, 0)

    def test_actual_backend_launcher_defaults_helper_and_prepares_exact_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve()
            cds = base / 'cds.lib'; cds.write_text('// fixture\n')
            source = base / 'plan.json'; source.write_text('{"x":[true,false,null,1.25]}')
            capture = base / 'captured.json'
            virtuoso = base / 'virtuoso.py'
            virtuoso.write_text('#!/usr/bin/env python3\nimport json,os,pathlib\n'
                'prepared=pathlib.Path(os.environ["ST_PREPARED_JSON_FILE"]).read_text()\n'
                'json.dump({"init":os.environ["ST_SKILL_INIT"],"plan":prepared},'
                'open(' + repr(str(capture)) + ',"w"))\n'
                'pathlib.Path(os.environ["ST_BACKEND_STATUS_FILE"]).write_text("OK\\n")\n')
            virtuoso.chmod(0o755)
            env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
            env['ST_VIRTUOSO_BIN'] = str(virtuoso)
            result = subprocess.run([str(ROOT / 'server/st_virtuoso_backend.sh'), 'materialize',
                '--cds-lib', str(cds), '--work-dir', str(base), '--skill',
                str(ROOT / 'skill/standalone_topology_variant.il'), '--plan', str(source)],
                env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(capture.read_text())
            self.assertEqual(data['init'], str(ROOT / 'server/skill/init.il'))
            self.assertIn('stPreparedJsonPath = "' + str(source) + '"', data['plan'])
            self.assertIn('list("x" list(t nil nil 1.25))', data['plan'])


if __name__ == '__main__': unittest.main()
