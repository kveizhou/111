"""Hand-checked graph fixtures; only the external Cadence export is replaced."""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))
from site_data import pin_site_inputs, write_json

BASE = '''// OA structural netlist generated read-only by st-engine-maau
subckt core DP GP SP BP DN GN SN BN
A (DP GP SP BP) oa_PDK__p l=134n nfin=6 aux= m=1 m=1
B (DN GN SN BN) oa_PDK__n l=134n nfin=6 aux= m=1
KEEP (DN GN SN BN) oa_PDK__n l=240n
OPAQUE (GP GN) oa_OTHER__child
ends core
'''
ROOT_NET = '''// OA structural netlist generated read-only by st-engine-maau
subckt core DP GP SP BP DN GN SN BN
WR (DP GP SP BP) oa_PUBLIC__variant__PKG1
WT (DN GN SN BN) oa_PUBLIC__variant__PKG2
KEEP (DN GN SN BN) oa_PDK__n l=240n
OPAQUE (GP GN) oa_OTHER__child
ends core
'''
PKG1 = '''// OA structural netlist generated read-only by st-engine-maau
subckt oa_PUBLIC__variant__PKG1 DP GP SP BP
A (DP GP internal BP) oa_PDK__p l=134n nfin=6 aux= m=1
RS (internal SP) oa_PDK__r r=100m helper=default
ends oa_PUBLIC__variant__PKG1
'''
PKG2 = '''// OA structural netlist generated read-only by st-engine-maau
subckt oa_PUBLIC__variant__PKG2 DN GN SN BN
B (DN GN x1 BN) oa_PDK__n l=134n nfin=6 aux= m=1
B_S1 (x1 GN x2 BN) oa_PDK__n l=134n nfin=6 aux= m=1
B_S2 (x2 GN SN BN) oa_PDK__n l=134n nfin=6 aux= m=1
ends oa_PUBLIC__variant__PKG2
'''


class ResultCheckTest(unittest.TestCase):
    def fixture(self, base):
        w = base / 'session'; fresh = base / 'actual'
        for name in ('before', 'expected', 'materialization', 'reports', 'changes',
                     'analysis/standalone_inputs'):
            (w / name).mkdir(parents=True)
        fresh.mkdir()
        for name, text in [('source', BASE), ('root', ROOT_NET), ('package_1', PKG1), ('package_2', PKG2)]:
            (fresh / (name + '.scs')).write_text(text)
        (w / 'before/core_before.scs').write_text(BASE)
        expected = ROOT_NET + PKG1.replace(' helper=default', '') + PKG2
        (w / 'expected/core_expected.scs').write_text(expected.replace('oa_PUBLIC__variant__', 'oa_PUBLIC__STAGING__variant__'))
        cds = base / 'cds.lib'; cds.write_text('; no real OA fixture\n')
        backend = base / 'backend.py'
        backend.write_text('#!' + sys.executable + '\n' + '''import os,sys
from pathlib import Path
args=sys.argv[1:]
assert args.pop(0)=="netlist"
opt=dict(zip(args[::2],args[1::2]))
assert opt["--view"]=="schematic"
assert Path(opt["--device-policy"]).is_file()
assert os.environ["ST_VALIDATION_SCOPE"]=="structure_only"
assert Path(os.environ["ST_BACKEND_RUN_ROOT"]).is_dir()
key=(opt["--lib"],opt["--cell"])
which={('SOURCE','core'):'source',('PUBLIC','variant'):'root',('PUBLIC','variant__PKG1'):'package_1',('PUBLIC','variant__PKG2'):'package_2'}[key]
assert opt["--core-subckt"]==('core' if which in ('source','root') else 'oa_PUBLIC__'+opt['--cell'])
file=Path(__file__).parent/'actual'/(which+'.scs')
if not file.exists():
 print('RAW_SECRET_backend_error',file=sys.stderr);sys.exit(70)
Path(opt['--output']).write_bytes(file.read_bytes())
''')
        backend.chmod(0o755)
        config = {'validation_scope': 'structure_only', 'backend': str(backend), 'cds_lib': str(cds),
            'source_library': 'SOURCE', 'source_cell': 'core', 'source_view': 'schematic',
            'core_subckt': 'core', 'variant_library': 'PUBLIC', 'variant_cell': 'variant'}
        (w / 'session.conf').write_text(''.join(k + '=' + v + '\n' for k, v in config.items()))
        (w / 'reports/validation.txt').write_text('ok=true\nstructural_ready=true\nstage=complete\nvalidation_scope=structure_only\ngenerated_cells=2\nsource=SOURCE/core/schematic\ntarget=PUBLIC/variant/schematic\n')
        source = {'library': 'SOURCE', 'cell': 'core', 'view': 'schematic'}
        generated = []
        for num, members in [(1, [('A', []), ('RS', ['helper'])]), (2, [('B', []), ('B_S1', []), ('B_S2', [])])]:
            generated.append({'package_id': 'PKG' + str(num), 'schematic': {'library': 'PUBLIC__STAGING',
                'cell': 'variant__PKG' + str(num), 'view': 'schematic'},
                'create_instances': [{'name': n, 'allowed_extra_cdf_parameters': extra} for n, extra in members]})
        write_json(w / 'materialization/plan.json', {'source': source,
            'target': {'library': 'PUBLIC__STAGING', 'cell': 'variant__STAGING', 'view': 'schematic'},
            'generated_cells': generated})
        (w / 'changes/0001.conf').write_text('id=res\ntype=resistor\ninstance=A\nresistor.master=oa_PDK__r\nresistor.parameter=r\nresistor.value=0.1\n')
        (w / 'changes/0002.conf').write_text('id=stack\ntype=stack\ninstance=B\nstage_count=3\ngate_policy=shared\nintent=effective_length\n')
        fields = ['master', 'kind', 'terminal_names', 'terminal_roles', 'oa_library', 'oa_cell', 'normalized_to_cdf']
        with (w / 'before/device_catalog.tsv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fields, delimiter='\t'); writer.writeheader()
            for cell, kind, names, roles, params in [
                ('p','mos_p','D,G,S,B','drain,gate,source,bulk','length:l,fin:nfin,cdf_aux:aux,multiplier:m'),
                ('n','mos_n','D,G,S,B','drain,gate,source,bulk','length:l,fin:nfin,cdf_aux:aux,multiplier:m'),
                ('r','resistor','PLUS,MINUS','positive,negative','resistance:r,cdf_helper:helper')]:
                writer.writerow(dict(zip(fields, ['oa_PDK__'+cell, kind, names, roles, 'PDK', cell, params])))
        (w / 'analysis/device_policy.tsv').write_text('oa_library\toa_cell\tterminal_order\nPDK\tp\tD,G,S,B\nPDK\tn\tD,G,S,B\nPDK\tr\tPLUS,MINUS\n')
        archive = w / 'analysis/standalone_inputs'
        inputs = {k: str(archive / k) for k in ('context','rules','tech','adapter','runtime','init')}
        for key in ('context','rules','tech'): write_json(inputs[key], {'validation_scope':'structure_only'} if key=='rules' else [] if key=='tech' else {})
        for key in ('adapter','runtime','init'): Path(inputs[key]).write_text('; fixture\n')
        write_json(archive / 'provider_inputs.json', pin_site_inputs(inputs))
        return w, fresh

    def run_case(self, change=None):
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory); w,fresh=self.fixture(base); out=base/'check'
            if change: change(w,fresh,out)
            result=subprocess.run([sys.executable,str(ROOT/'server/site/check_structure_result.py'),
                '--session',str(w),'--output',str(out)],capture_output=True,text=True)
            details=json.loads((out/'details.json').read_text()) if (out/'details.json').exists() else {}
            return result,details

    def mutate(self, name, old, new, expected=False):
        def apply(w,fresh,out):
            path=fresh/(name+'.scs'); path.write_text(path.read_text().replace(old,new))
            if expected:
                path=w/'expected/core_expected.scs';path.write_text(path.read_text().replace(old,new))
        return apply

    def test_valid_published_structure_and_approved_resistor_defaults(self):
        r,d=self.run_case();self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        self.assertIn('RESULT=PASS',r.stdout);self.assertEqual(d['result'],'PASS')
        self.assertNotIn('oa_PDK',r.stdout);self.assertNotIn('DP',r.stdout);self.assertLess(len(r.stdout.splitlines()),200)

    def test_wrong_gate_fails_even_if_expected_netlist_was_changed_to_match(self):
        r,d=self.run_case(self.mutate('package_1','A (DP GP internal BP)','A (DP SP internal BP)',True))
        self.assertEqual(r.returncode,1,r.stdout+r.stderr);self.assertIn('R_GATE',str(d))

    def test_resistor_on_drain_fails_even_if_expected_is_also_wrong(self):
        def change(w,fresh,out):
            old='A (DP GP internal BP)';new='A (internal GP SP BP)'
            for path in (fresh/'package_1.scs',w/'expected/core_expected.scs'):
                path.write_text(path.read_text().replace(old,new).replace('RS (internal SP)','RS (internal DP)'))
        r,d=self.run_case(change);self.assertEqual(r.returncode,1);self.assertIn('R_DRAIN',str(d))

    def test_bypassed_stack_fails_even_when_expected_matches(self):
        r,d=self.run_case(self.mutate('package_2','B_S1 (x1 GN x2 BN)','B_S1 (x1 GN SN BN)',True))
        self.assertEqual(r.returncode,1);self.assertIn('STACK_CHAIN',str(d))

    def test_missing_stack_stage_is_not_accepted(self):
        r,d=self.run_case(self.mutate('package_2','B_S2 (x2 GN SN BN) oa_PDK__n l=134n nfin=6 aux= m=1\n',''))
        self.assertEqual(r.returncode,1);self.assertIn('STACK_COUNT',str(d))

    def test_changed_dimensions_or_filled_empty_default_are_rejected(self):
        for old,new in [('l=134n','l=240n'),('aux=','aux=598.5n'),('oa_PDK__n','oa_PDK__p')]:
            with self.subTest(new=new):
                r,d=self.run_case(self.mutate('package_2',old,new));self.assertEqual(r.returncode,1)

    def test_source_changes_and_untouched_root_instances_are_rejected(self):
        for name in ('source','root'):
            with self.subTest(name=name):
                r,d=self.run_case(self.mutate(name,'KEEP (DN GN SN BN)','KEEP (DN GN DN BN)'))
                self.assertEqual(r.returncode,1)

    def test_wrong_resistance_or_unknown_extra_parameter_are_rejected(self):
        for old,new in [('r=100m','r=200m'),('helper=default','helper=default unknown=1')]:
            r,d=self.run_case(self.mutate('package_1',old,new));self.assertEqual(r.returncode,1)

    def test_engineering_suffix_and_continuation_are_supported_without_tolerance(self):
        r,d=self.run_case(self.mutate('package_1','r=100m helper=default','r=0.1\n+ helper=default'))
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        r,d=self.run_case(self.mutate('package_1','r=100m','r=0.10000000001'))
        self.assertEqual(r.returncode,1)

    def test_changed_bulk_and_wrong_wrapper_mapping_fail_even_when_expected_matches(self):
        r,d=self.run_case(self.mutate('package_2','B_S1 (x1 GN x2 BN)','B_S1 (x1 GN x2 SN)',True))
        self.assertEqual(r.returncode,1);self.assertIn('STACK_BULK',str(d))
        r,d=self.run_case(self.mutate('root','WR (DP GP SP BP)','WR (DP SP GP BP)',True))
        self.assertEqual(r.returncode,1);self.assertIn('R_GATE',str(d))

    def test_equivalent_duplicate_suffixes_and_mixed_layout_continuations_are_valid(self):
        r,d=self.run_case(self.mutate('package_1','r=100m helper=default','r=0.1 r=100M \\\n+ helper=default'))
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)

    def test_failed_report_or_wrong_plan_cannot_authorize_export(self):
        def report(w,fresh,out):
            p=w/'reports/validation.txt';p.write_text(p.read_text().replace('ok=true','ok=false'))
        r,d=self.run_case(report);self.assertEqual(r.returncode,2);self.assertEqual(d['exports_completed'],0)
        def plan(w,fresh,out):
            p=w/'materialization/plan.json';j=json.loads(p.read_text());j['source']['cell']='OTHER';write_json(p,j)
        r,d=self.run_case(plan);self.assertEqual(r.returncode,2);self.assertEqual(d['exports_completed'],0)

    def test_nonpositive_resistance_cannot_pass_even_when_expected_matches(self):
        def negative(w,fresh,out):
            p=w/'changes/0001.conf';p.write_text(p.read_text().replace('resistor.value=0.1','resistor.value=-0.1'))
            for p in (fresh/'package_1.scs',w/'expected/core_expected.scs'):
                p.write_text(p.read_text().replace('r=100m','r=-100m'))
        r,d=self.run_case(negative);self.assertEqual(r.returncode,2);self.assertEqual(d['exports_completed'],0)

    def test_staging_reference_and_terminal_order_changes_are_rejected(self):
        r,d=self.run_case(self.mutate('root','oa_PUBLIC__variant__PKG1','oa_PUBLIC__STAGING__variant__PKG1'))
        self.assertEqual(r.returncode,1)
        def policy(w,fresh,out):
            p=w/'analysis/device_policy.tsv';p.write_text(p.read_text().replace('D,G,S,B','D,S,G,B'))
        r,d=self.run_case(policy);self.assertNotEqual(r.returncode,0)

    def test_malformed_missing_or_conflicting_duplicate_parameter_is_incomplete(self):
        for old,new in [('ends oa_PUBLIC__variant__PKG1',''),('helper=default','helper=default RAW_SECRET_unknown_statement'),('r=100m','r=100m r=200m')]:
            r,d=self.run_case(self.mutate('package_1',old,new));self.assertEqual(r.returncode,2)
            self.assertNotIn('RAW_SECRET',r.stdout+r.stderr)

    def test_backend_failure_and_changed_pinned_input_cannot_report_pass(self):
        def missing(w,fresh,out): (fresh/'package_2.scs').unlink()
        r,d=self.run_case(missing);self.assertEqual(r.returncode,2);self.assertNotIn('RAW_SECRET',r.stdout+r.stderr)
        def changed(w,fresh,out): (w/'analysis/standalone_inputs/init').write_text('; changed')
        r,d=self.run_case(changed);self.assertEqual(r.returncode,2)

    def test_existing_output_is_preserved(self):
        def exists(w,fresh,out): out.mkdir();(out/'keep').write_text('keep')
        r,d=self.run_case(exists);self.assertEqual(r.returncode,2);self.assertNotIn('RESULT=PASS',r.stdout)

    def test_many_differences_have_bounded_nonraw_summary(self):
        extra=' '.join('SECRET_'+str(i)+'=1' for i in range(500))
        r,d=self.run_case(self.mutate('package_2','aux= m=1','aux= m=1 '+extra))
        self.assertEqual(r.returncode,1);self.assertLess(len(r.stdout.splitlines()),200)
        self.assertNotIn('SECRET_',r.stdout+r.stderr)


if __name__=='__main__': unittest.main()
