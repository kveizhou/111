"""Exercise baseline settings inheritance; Cadence remains an external fixture."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import CascodeSolverSettingsTest as saved_fixture
ENTRY = saved_fixture.ENTRY

SAVED = '''analysis('dc ?anaName "dc" ?saveOppoint t ?oppoint "rawfile" ?maxiters "150" ?maxsteps "10000")
analysis('tran ?stop "200u" ?dynParamSetParam list("da_en"))
analysis('stb ?probe "/ldo/IPRB1")
envOption('analysisOrder list("dc" "stb" "tran") 'userCmdLineOption "")
option('reltol "1e-3" 'temp "27")
option(?categ 'turboOpts 'uniMode "APS" 'errorLevel "Conservative" 'mtOption "Manual" 'numThreads "4")
temp(27)
run()
'''


class CascodeSavedDcTest(unittest.TestCase):
    def fixture(self, base):
        s, r, p, b, env = saved_fixture.CascodeSolverSettingsTest().fixture(base)
        env['ST_TEST_SAVED_SCRIPT'] = SAVED
        native = Path(env['ST_VIRTUOSO_BIN'])
        native.write_text(native.read_text() + '\nif os.environ.get("ST_REVIEW_DEFINITIONS"): Path(os.environ["ST_REVIEW_DEFINITIONS"]).write_text("nil\\n")\n')
        backend = base/'baseline_ocean'
        backend.write_text('#!'+sys.executable+'\n'+r'''import json,os,re,sys
from pathlib import Path
action=Path(sys.argv[-1]); code=action.read_text()
if os.environ.get('ST_BASELINE_STAGE'):
 stage=os.environ['ST_BASELINE_STAGE']; root=Path(os.environ['ST_BASELINE_ROOT'])
 (root/('captured_'+stage+'.ocn')).write_text(code)
 assert 'config_presim' in code
 assert '?maxiters "150"' in code and '?maxsteps "10000"' in code
 assert 'turboOpts' in code and 'numThreads "4"' in code
 assert "analysis('tran" not in code and "analysis('stb" not in code
 assert code.rfind('temp(125') > code.find("'temp \"27\"")
 assert "hostMode('local)" in code
 if os.environ.get('ST_TEST_RUN_FAIL') and stage=='run': print('ERROR (SPECTRE-7): fixture simulation failure'); sys.exit(3)
 if os.environ.get('ST_TEST_RUN_WAIT') and stage=='run': __import__('time').sleep(3)
 dest=Path(os.environ['ST_BASELINE_GENERATED'])/'spectre/bench/netlist'; dest.mkdir(parents=True,exist_ok=True)
 deck=os.environ['ST_TEST_DECK']+'\nsimulatorOptions options temp=125 reltol=1e-3\ndcOp dc maxiters=150 maxsteps=10000\ndcOpInfo info what=oppoint where=rawfile\n'
 if os.environ.get('ST_TEST_IGNORED_SETTINGS'): deck=deck.replace('maxiters=150 maxsteps=10000','')
 if os.environ.get('ST_TEST_WRONG_TEMPERATURE'): deck=deck.replace('temp=125','temp=27')
 if os.environ.get('ST_TEST_CHANGED_DECK')==stage: deck=deck.replace('l=134n','l=135n')
 (dest/'input.scs').write_text(deck)
 if stage=='run':
  psf=Path(os.environ['ST_BASELINE_RESULTS'])/'psf'; psf.mkdir(parents=True)
  if not os.environ.get('ST_TEST_NO_BASELINE_PSF'):
   (psf/'dcOp.dc').write_text('fixture node voltages'); (psf/'dcOpInfo.info').write_text('fixture OP')
  print('Command line: spectre input.scs' if os.environ.get('ST_TEST_MISSING_APS') else 'Command line: spectre +aps=conservative +mt=4 input.scs')
 if not os.environ.get('ST_TEST_BASELINE_NO_MARKER'): Path(os.environ['ST_BASELINE_MARKER']).write_text('OK\n')
else:
 if os.environ.get('ST_TEST_REJECT_BULK_NODE_READ') and 'getData(' in code:
  print('*Error* Non-numeric DC data'); sys.exit(3)
 (action.parent/'captured_op.ocn').write_text(code)
 print('ST_OP_STAGE=TARGETS_COMPLETE')
 if os.environ.get('ST_TEST_MUTATE_PSF'): Path(os.environ['ST_TEST_MUTATE_PSF']).write_text('changed during read')
 out=Path(os.environ['ST_BATCH_PSF_TABLE']); rows=['kind\tsignal\tparameter\tvalue\tstatus']
 for inst,sign in [('I21',1),('I105',-1)]:
  if os.environ.get('ST_TEST_OP_MISSING') and inst=='I105': continue
  values=[('id',sign*1e-6),('vgs',sign*.5),('vds',sign*.7),('vdsat',sign*.15)]
  if os.environ.get('ST_TEST_MIXED_OP'):
   values=[('id',0 if inst=='I21' else -1e-6),('vgs',sign*.5),('vds',sign*.7),('vdsat',sign*.15),('region',1 if inst=='I105' else 0)]
  if os.environ.get('ST_TEST_CMG_OP'):
   values=[('id',sign*1e-6),('vgs',sign*.5),('vds',sign*.7),('vdssat',sign*.15),('vdst',sign*.8),('vgst',sign*.6),('ves',sign*.01),('region',1)]
  if os.environ.get('ST_TEST_NO_SAT'): values=[(k,v) for k,v in values if k not in ('vdsat','vdssat')]
  if 'device\\t%s' in code: rows.append('device\tXCORE.'+inst+'\t\tbsimcmg\tMETA')
  # Emulate the device's parameter inventory; request selection comes from generated code.
  requested=None if 'foreach(param params' in code else set(re.findall(r'"([^"\n]+)"',code.split('foreach(param list(',1)[1].split(')',1)[0]))
  for k,v in values:
   if requested is not None and k not in requested: continue
   if os.environ.get('ST_TEST_MIXED_OP'):
    # Exercise the generated numeric write boundary only, not a SKILL interpreter.
    # Python's %g silently accepts int; native SKILL %g does not.
    call=re.search(r'fprintf\(port "op\\t%s\\t%s\\t(%[.0-9]*g)\\tOK\\n" device param (scalar|float\(scalar\))\)',code)
    assert call, 'unmodeled numeric output expression; update boundary fixture'
    numeric=float(v) if call.group(2)=='float(scalar)' else v
    if type(numeric) is not float:
     print('*Error* fprintf/sprintf: format spec. incompatible with data - integer '+str(numeric)); sys.exit(3)
    value=call.group(1) % numeric
   else: value=str(v)
   rows.append('op\tXCORE.'+inst+'\t'+k+'\t'+value+'\tOK')
 out.write_text('\n'.join(rows)+'\n'); (action.parent/'runtime.done').write_text('OK\n')
''')
        backend.chmod(0o755); env['ST_OCEAN_BIN']=str(backend)
        return s,r,p,b,env

    def run_entry(self,s,r,p,b,env,extra=()):
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(s),'--maestro-read',str(r),
            '--preflight',str(p),'--batch',str(b),'--run-dc','--dc-timeout','2']+list(extra),
            cwd=b,env=env,capture_output=True,text=True)

    def test_inherits_native_settings_preserves_corner_and_reads_signed_op(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp)); before={x:x.read_bytes() for x in (s/'session.conf',r,p/'bench.scs')}
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('BASELINE_DC=CONVERGED',result.stdout)
            self.assertIn('OP_TARGET I105',result.stdout); self.assertIn('id=-',result.stdout)
            self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout)
            self.assertIn('VBIAS_GENERATED=false',result.stdout)
            self.assertLessEqual(len(result.stdout.splitlines()),190)
            out=next(b.glob('dc_review_ports_*'))
            self.assertNotIn('run()', (out/'captured_netlist.ocn').read_text())
            self.assertIn('run()', (out/'captured_run.ocn').read_text())
            for x,v in before.items(): self.assertEqual(x.read_bytes(),v)

    def test_circuit_change_prevents_simulation_and_after_run_change_prevents_pass(self):
        for stage in ('netlist','run'):
            with self.subTest(stage=stage),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e=self.fixture(Path(tmp)); e['ST_TEST_CHANGED_DECK']=stage
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('BASELINE_DC=CONVERGED',result.stdout)
                if stage=='netlist': self.assertFalse(list(b.rglob('captured_run.ocn')))

    def test_native_failure_timeout_missing_marker_psf_and_op_do_not_pass(self):
        for key in ('ST_TEST_RUN_FAIL','ST_TEST_RUN_WAIT','ST_TEST_BASELINE_NO_MARKER','ST_TEST_NO_BASELINE_PSF','ST_TEST_OP_MISSING'):
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e=self.fixture(Path(tmp)); e[key]='1'
                result=self.run_entry(s,r,p,b,e,('--dc-timeout','1'))
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('RESULT=BASELINE_READ_OK',result.stdout)

    def test_unsupported_code_sweeps_and_missing_dc_stop_before_native_simulation(self):
        for text in (SAVED.replace('?anaName "dc"','?param "AVDD" ?start "0" ?stop "1"'),
                     SAVED.replace('"1e-3"','system("bad")'), SAVED.replace("analysis('dc", "analysis('ac")):
            with self.subTest(text=text[:50]),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e=self.fixture(Path(tmp)); e['ST_TEST_SAVED_SCRIPT']=text
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertFalse(list(b.rglob('captured_run.ocn')))

    def test_default_read_only_behavior_still_does_not_simulate(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp))
            result=subprocess.run([sys.executable,str(ENTRY),'--session',str(s),'--maestro-read',str(r),
                '--preflight',str(p),'--batch',str(b)],env=e,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('SPECTRE_RERUN=false',result.stdout); self.assertFalse(list(b.rglob('captured_run.ocn')))

    def test_ignored_native_settings_wrong_temperature_and_missing_aps_are_incomplete(self):
        for key in ('ST_TEST_IGNORED_SETTINGS','ST_TEST_WRONG_TEMPERATURE','ST_TEST_MISSING_APS'):
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e=self.fixture(Path(tmp)); e[key]='1'
                result=self.run_entry(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('RESULT=BASELINE_READ_OK',result.stdout)
                if key!='ST_TEST_MISSING_APS': self.assertFalse(list(b.rglob('captured_run.ocn')))

    def test_quoted_transient_table_does_not_block_or_enter_dc_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp))
            e['ST_TEST_SAVED_SCRIPT']=SAVED.replace('?dynParamSetParam list("da_en")',
                '?dynParamSetParam list("da_en") ?dynParamSetTab \'(("0" "0") ("30u" "1"))')
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('RESULT=BASELINE_READ_OK',result.stdout)
            self.assertIn('SKIPPED_NON_DC index=2 analysis=tran',result.stdout)
            self.assertIn('SKIPPED_NON_DC index=3 analysis=stb',result.stdout)
            code=next(b.rglob('captured_run.ocn')).read_text()
            self.assertNotIn('dynParamSetTab',code)

    def test_all_state_and_duplicate_option_issues_reported_before_netlisting(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp))
            e['ST_TEST_SAVED_SCRIPT']=SAVED.replace("'userCmdLineOption \"\"",
                "'userCmdLineOption \"\" 'restart \"/\" 'savestate \"/\"").replace(
                "option('reltol", "option('abstol \"1e-6\" 'abstol \"1e-12\" 'reltol")
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            for wanted in ('FAILED_SAVED_FORM index=4','FAILED_SAVED_FORM index=5',
                           'restart','savestate','value="/"','duplicate saved option','abstol'):
                self.assertIn(wanted,result.stdout)
            self.assertFalse(list(b.rglob('captured_netlist.ocn')))

    def test_needed_setting_syntax_failure_identifies_character_and_form(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp))
            e['ST_TEST_SAVED_SCRIPT']=SAVED.replace("option('reltol", "option('unparsed @ 'reltol")
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            for wanted in ('FAILED_SAVED_FORM index=5','offset=','U+0040','context='):
                self.assertIn(wanted,result.stdout)
            self.assertFalse(list(b.rglob('captured_netlist.ocn')))

    def test_focused_op_does_not_depend_on_bulk_node_conversion(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp)); e['ST_TEST_REJECT_BULK_NODE_READ']='1'
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('OP_TARGET I105',result.stdout)
            code=next(b.rglob('captured_op.ocn')).read_text()
            depth=0; quoted=False; escaped=False
            for c in code:
                if quoted:
                    if escaped: escaped=False
                    elif c=='\\': escaped=True
                    elif c=='"': quoted=False
                elif c=='"': quoted=True
                elif c=='(': depth+=1
                elif c==')': depth-=1
                self.assertGreaterEqual(depth,0)
            self.assertEqual(depth,0); self.assertFalse(quoted)

    def resume(self,s,r,p,b,e):
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(s),'--maestro-read',str(r),
            '--preflight',str(p),'--batch',str(b),'--read-op-only'],cwd=b,env=e,capture_output=True,text=True)

    def prepare_converged_with_failed_op(self,tmp):
        s,r,p,b,e=self.fixture(Path(tmp)); e['ST_TEST_OP_MISSING']='1'
        result=self.run_entry(s,r,p,b,e)
        self.assertEqual(result.returncode,2,result.stdout+result.stderr)
        self.assertIn('BASELINE_DC=CONVERGED',result.stdout)
        log=next(b.glob('dc_review_ports_*/baseline_op/ocean.log'))
        log.write_text(log.read_text()+'*Error* Non-numeric DC data\n')
        e.pop('ST_TEST_OP_MISSING')
        e['ST_VIRTUOSO_BIN']='/missing/never-read-maestro-again'
        e['ST_TEST_RUN_FAIL']='1'
        return s,r,p,b,e

    def test_resume_reuses_psf_without_exporting_netlisting_or_simulating(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.prepare_converged_with_failed_op(tmp)
            root=next(b.glob('dc_review_ports_*')); before={f:f.read_bytes() for f in root.rglob('*') if f.is_file()}
            result=self.resume(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            for wanted in ('SPECTRE_RERUN=false','RESULT=BASELINE_READ_OK','SAVED_SETTINGS_APPLIED_TO_BASELINE=true','OP_TARGET I21'):
                self.assertIn(wanted,result.stdout)
            for f,data in before.items(): self.assertEqual(f.read_bytes(),data,f)
            self.assertEqual(len(list(root.rglob('captured_run.ocn'))),1)

    def test_resume_serializes_integer_region_zero_current_and_signed_floats(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.prepare_converged_with_failed_op(tmp)
            root=next(b.glob('dc_review_ports_*'))
            before={f:f.read_bytes() for f in root.rglob('*') if f.is_file()}
            e['ST_TEST_MIXED_OP']='1'
            result=self.resume(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            for flag in ('OP_READ=COMPLETE','SPECTRE_RERUN=false','PSF_UNCHANGED=true'):
                self.assertIn(flag,result.stdout)
            rows=json.loads(next(root.glob('op_review_*/baseline_op.json')).read_text())
            actual={(r['signal'],r['parameter']):float(r['value']) for r in rows if r['kind']=='op'}
            for inst,sign in [('I21',1),('I105',-1)]:
                expected={'id':0 if inst=='I21' else -1e-6, 'region':0 if inst=='I21' else 1,
                          'vgs':sign*.5,'vds':sign*.7,'vdsat':sign*.15}
                for param,value in expected.items(): self.assertEqual(actual[('XCORE.'+inst,param)],value)
            for f,data in before.items(): self.assertEqual(f.read_bytes(),data,f)
            self.assertEqual(len(list(root.rglob('captured_run.ocn'))),1)

    def op_module(self):
        spec=importlib.util.spec_from_file_location('saved_op_under_test',ENTRY)
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        return module

    def op_rows(self,changes=None):
        rows=[]
        for inst,sign in [('I21',1),('I105',-1)]:
            values={'id':sign*1e-6,'vgs':sign*.5,'vds':sign*.7,'vdssat':sign*.15,
                    'vdst':sign*.8,'vgst':sign*.6,'region':1}
            if changes: changes(inst,values)
            rows.append(dict(kind='device',signal='XCORE.'+inst,parameter='',value='bsimcmg',status='META'))
            rows.extend(dict(kind='op',signal='XCORE.'+inst,parameter=k,value=str(v),status='OK') for k,v in values.items())
        return rows

    def summarize(self,rows):
        return self.op_module().summarize_op(rows,['XCORE.I21','XCORE.I105'])

    def test_cmg_resume_discovers_vdssat_and_keeps_terminal_values_separate(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.prepare_converged_with_failed_op(tmp); e['ST_TEST_CMG_OP']='1'
            result=self.resume(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            for text in ('OP_REQUIRED_FIELDS_COMPLETE=true','vdsat=vdssat','vdst=-0.8','vds=-0.7','OP_TARGET I21','OP_TARGET I105','type=bsimcmg'):
                self.assertIn(text,result.stdout)
            rows=json.loads(next(b.glob('dc_review_ports_*/op_review_*/baseline_op.json')).read_text())
            self.assertTrue(any(row['parameter']=='ves' for row in rows))
            self.assertFalse(any(row['parameter']=='vdsat' for row in rows))

    def test_missing_saturation_returns_both_targets_and_distinct_read_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.prepare_converged_with_failed_op(tmp);e['ST_TEST_NO_SAT']='1'
            result=self.resume(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            for text in ('OP_READ=COMPLETE','OP_REQUIRED_FIELDS_COMPLETE=false','OP_TARGET I21','OP_TARGET I105','OP_MISSING I21','OP_MISSING I105','OP_AVAILABLE I21','OP_AVAILABLE I105','PSF_UNCHANGED=true'):
                self.assertIn(text,result.stdout)
            self.assertNotIn('RESULT=BASELINE_READ_OK',result.stdout)

    def test_alias_normalization_retains_original_fields_and_signed_values(self):
        result=self.summarize(self.op_rows())
        self.assertTrue(result['required_fields_complete'])
        for target,sign in zip(result['targets'],(1,-1)):
            device=target['devices'][0]
            self.assertEqual(device['normalized']['vdsat'],sign*.15)
            self.assertEqual(device['sources']['vdsat'],'vdssat')
            self.assertNotIn('vdsat',device['raw'])
            self.assertEqual(device['normalized']['vds'],sign*.7)
            self.assertEqual(device['normalized']['vdst'],sign*.8)

    def test_conflicting_aliases_cannot_pass_and_all_targets_are_reported(self):
        result=self.summarize(self.op_rows(lambda inst,v:v.update(vdsat=.2)))
        self.assertFalse(result['required_fields_complete'])
        self.assertEqual(len(result['targets']),2)
        self.assertTrue(all(t['devices'][0]['conflicts'] for t in result['targets']))

    def test_missing_or_invalid_sat_is_not_replaced_with_another_parameter(self):
        for value in (None,'nan','inf','not-a-number'):
            def change(inst,values):
                if value is None: values.pop('vdssat')
                else: values['vdssat']=value
            with self.subTest(value=value):
                result=self.summarize(self.op_rows(change))
                self.assertFalse(result['required_fields_complete'])
                self.assertTrue(all('vdsat' in t['devices'][0]['missing'] for t in result['targets']))

    def test_fields_do_not_merge_across_devices_or_prefix_neighbors(self):
        rows=self.op_rows()
        for row in rows:
            if row['signal']=='XCORE.I21' and row['parameter']=='vdssat': row['signal']='XCORE.I21.child'
        rows.extend(dict(row,signal='XCORE.I210') for row in self.op_rows() if row['signal']=='XCORE.I105')
        result=self.summarize(rows)
        self.assertFalse(result['required_fields_complete'])
        self.assertEqual(result['targets'][0]['complete_device_count'],0)
        self.assertEqual(result['targets'][1]['complete_device_count'],1)

    def test_ambiguous_complete_devices_and_duplicate_conflicts_are_blocked(self):
        for mode in ('ambiguous','duplicate'):
            rows=self.op_rows()
            if mode=='ambiguous': rows.extend(dict(r,signal='XCORE.I21.child') for r in self.op_rows() if r['signal']=='XCORE.I21')
            else: rows.append(dict(kind='op',signal='XCORE.I21',parameter='id',value='2e-6',status='OK'))
            with self.subTest(mode=mode): self.assertFalse(self.summarize(rows)['required_fields_complete'])

    def test_equivalent_numeric_duplicates_do_not_create_false_conflict(self):
        rows=self.op_rows()
        rows.append(dict(kind='op',signal='XCORE.I21',parameter='region',value='1.000',status='OK'))
        self.assertTrue(self.summarize(rows)['required_fields_complete'])

    def test_optional_nonnumeric_is_retained_and_alias_never_fills_other_fields(self):
        rows=self.op_rows()
        rows.append(dict(kind='op',signal='XCORE.I21',parameter='description',value='',status='NON_NUMERIC'))
        report=self.summarize(rows)
        self.assertTrue(report['required_fields_complete'])
        self.assertEqual(report['targets'][0]['devices'][0]['raw']['description']['status'],'NON_NUMERIC')
        rows=[r for r in rows if not (r['signal']=='XCORE.I21' and r['parameter'] in ('id','vgs'))]
        report=self.summarize(rows)
        self.assertFalse(report['required_fields_complete'])
        self.assertIn('vgs',report['targets'][0]['devices'][0]['missing'])
        self.assertIn('id|ids',report['targets'][0]['devices'][0]['missing'])

    def test_resume_invalid_evidence_never_starts_native_reader(self):
        for mode in ('not_converged','changed_deck','missing_psf','missing_marker','changed_selected_controls'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e=self.prepare_converged_with_failed_op(tmp)
                root=next(b.glob('dc_review_ports_*'))
                if mode=='not_converged': (root/'baseline_status.json').write_text('{"converged":false}')
                if mode=='changed_deck':
                    f=root/'baseline_run.scs'; f.write_text(f.read_text().replace('l=134n','l=135n'))
                if mode=='missing_psf': next((root/'baseline_results').rglob('dcOpInfo.info')).unlink()
                if mode=='missing_marker': (root/'baseline_run/runtime.done').unlink()
                if mode=='changed_selected_controls':
                    f=root/'settings_forms.json'; f.write_text(f.read_text().replace('150','151'))
                e['ST_OCEAN_BIN']='/missing/must-not-launch'
                result=self.resume(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertNotIn('executable unavailable',result.stdout)
                self.assertFalse(list(root.glob('op_review_*/baseline_op/captured_op.ocn')))

    def test_op_failure_preserves_applied_settings_and_prioritizes_op_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.fixture(Path(tmp)); e['ST_TEST_OP_MISSING']='1'
            result=self.run_entry(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('SAVED_SETTINGS_APPLIED_TO_BASELINE=true',result.stdout)
            self.assertIn('LOG_TAIL baseline_op/ocean.log',result.stdout)

    def test_psf_changed_during_resume_cannot_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e=self.prepare_converged_with_failed_op(tmp)
            root=next(b.glob('dc_review_ports_*'))
            e['ST_TEST_MUTATE_PSF']=str(next((root/'baseline_results').rglob('dcOpInfo.info')))
            result=self.resume(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('saved PSF changed during OP read',result.stdout)
            self.assertIn('PSF_UNCHANGED=false',result.stdout)


if __name__=='__main__': unittest.main()
