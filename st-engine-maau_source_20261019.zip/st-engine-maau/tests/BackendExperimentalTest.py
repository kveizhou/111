"""Process-boundary scope and OP schema regression tests; no native EDA."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class BackendExperimentalTest(unittest.TestCase):
    def environment(self, **extra):
        env = {k: v for k, v in os.environ.items() if not k.startswith('ST_')}
        env.update(extra)
        return env

    def parse(self, arguments, **extra):
        command = 'source "$1"; shift; backend_parse_options "$@"; backend_allow_only; printf "%s" "$ST_VALIDATION_SCOPE"'
        return subprocess.run(['bash', '-c', command, 'test', str(ROOT/'server/lib/backend_common.sh'), *arguments],
                              env=self.environment(**extra), capture_output=True, text=True)

    def test_explicit_scope_is_preserved_and_conflicts_reject_before_native(self):
        result = self.parse(['--validation-scope', 'experimental_dc'])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'experimental_dc')
        self.assertEqual(self.parse(['--validation-scope', 'experimental_dc'], ST_VALIDATION_SCOPE='dc_operating_point').returncode, 64)
        self.assertEqual(self.parse(['--validation-scope', 'invalid']).returncode, 64)
        self.assertEqual(self.parse(['--validation-scope', 'experimental_dc', '--validation-scope', 'experimental_dc']).returncode, 64)
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory)/'profile.json'
            profile.write_text(json.dumps({'validation_scope': 'dc_operating_point'}))
            self.assertEqual(self.parse(['--validation-scope', 'experimental_dc'], ST_SIMULATION_PROFILE=str(profile)).returncode, 64)

    def test_publish_rejects_experiment_before_touching_paths(self):
        result = subprocess.run(['bash', str(ROOT/'server/bin/publish_runner.sh'), '--validation-scope', 'experimental_dc'],
                                env=self.environment(), capture_output=True, text=True)
        self.assertEqual(result.returncode, 64)
        self.assertIn('publishing is disabled', result.stderr)

    def validate(self, mos_extra, ratings, scope):
        source = (ROOT/'server/bin/run_op_runner.sh').read_text()
        body = source.split('run_op_valid_outputs() {', 1)[1].split("<<'PY'\n", 1)[1].split('\nPY\n', 1)[0]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            identity, mos, resistor = (root/name for name in ('identity.tsv', 'mos.tsv', 'resistor.tsv'))
            identity.write_text('dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\tparameter_hash\tsolver_version\ttotal_supply_current\n' +
                                'dut\tbench\tpdk\ttt\ttopo\tparam\tsolver\t0\n')
            header = 'instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg'
            if mos_extra is not None:
                header += '\tintrinsic_vgs\tintrinsic_vds'
            row = 'M1\t1\t0.7\t0\t0\t0.00001\t0.7\t1\t0\t0.4\t0.2\t1e-15'
            if mos_extra is not None:
                row += '\t'+'\t'.join(mos_extra)
            mos.write_text(header+'\n'+row+'\n')
            resistor.write_text('instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\tmax_voltage\tmax_power\tmax_current\trating_source\n' +
                                'R1\tPDK/R\tr=1k\t1\t0\t0.001\t'+'\t'.join(ratings)+'\n')
            return subprocess.run([sys.executable, '-c', body, str(identity), str(mos), str(resistor),
                                   'dut', 'bench', 'pdk', 'tt', 'topo', 'param', 'solver'],
                                  env=self.environment(ST_VALIDATION_SCOPE=scope), capture_output=True, text=True)

    def test_cmg_extended_schema_and_unknown_ratings_are_scope_bound(self):
        unknown = ['NA', 'NA', 'NA', '-']
        accepted = self.validate(['0.69', '0.99'], unknown, 'experimental_dc')
        self.assertEqual(accepted.returncode, 0, accepted.stderr)
        self.assertNotEqual(self.validate(['0.69', '0.99'], unknown, 'dc_operating_point').returncode, 0)
        self.assertNotEqual(self.validate(['NA', '0.99'], unknown, 'experimental_dc').returncode, 0)
        self.assertNotEqual(self.validate(['0.69', 'nan'], unknown, 'experimental_dc').returncode, 0)
        self.assertNotEqual(self.validate(None, ['NA', '-1', 'NA', 'PDK'], 'experimental_dc').returncode, 0)
        self.assertNotEqual(self.validate(None, ['1.2', 'NA', 'NA', '-'], 'experimental_dc').returncode, 0)
        self.assertEqual(self.validate(None, ['1.2', '0.1', '0', 'PDK'], 'dc_operating_point').returncode, 0)


if __name__ == '__main__':
    unittest.main()
