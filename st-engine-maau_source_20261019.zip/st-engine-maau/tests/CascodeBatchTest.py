"""Real Python batch flow with file-writing external Cadence fixtures only."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
sys.path.insert(0, str(ROOT / 'server/site'))
import CascodeBenchPreflightTest as fixture_module
from site_data import pin_site_inputs, write_json

ENTRY = ROOT / 'server/site/collect_cascode_batch.py'


class CascodeBatchTest(unittest.TestCase):
    def setUp(self):
        self.assertTrue(ENTRY.is_file(), 'batch entry is not implemented')

    def fixture(self, base):
        source = fixture_module.CascodeBenchPreflightTest()
        session, read, env = source.fixture(base)
        archive = session / 'analysis/standalone_inputs'
        write_json(archive / 'tech.json', [{'devices': [
            {'oa_library': 'PDK', 'cell': 'n', 'kind': 'mos', 'constraints': {}, 'missing': ['electrical_validation']},
            {'oa_library': 'PDK', 'cell': 'p', 'kind': 'mos', 'constraints': {}, 'missing': ['electrical_validation']}]}])
        paths = json.loads((archive / 'provider_inputs.json').read_text())
        write_json(archive / 'provider_inputs.json', pin_site_inputs(paths))
        (session / 'before').mkdir()
        fields = ['master', 'kind', 'oa_library', 'oa_cell', 'oa_view', 'normalized_to_cdf']
        with (session / 'before/device_catalog.tsv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fields, delimiter='\t'); writer.writeheader()
            for cell, kind in [('n', 'mos_n'), ('p', 'mos_p'), ('n_alt', 'mos_n'), ('r', 'resistor')]:
                writer.writerow(dict(zip(fields, ['oa_PDK__'+cell, kind, 'PDK', cell, 'symbol', 'length:l,fin:nfin'])))
        with (session / 'before/mos_inventory.tsv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, ['instance', 'master'], delimiter='\t'); writer.writeheader()
            writer.writerows([{'instance': 'I21', 'master': 'oa_PDK__n'}, {'instance': 'I105', 'master': 'oa_PDK__p'}])
        (archive / 'pdk_probe.tsv').write_text('oa_library\toa_cell\tparameter\tmin\tmax\tcdf_type\tdefault_value\tchoices\n'
            'PDK\tn\tl\t\t\tstring\t134n\t\nPDK\tn\tnfin\t\t\tstring\t6\t\n'
            'PDK\tp\tl\t\t\tstring\t134n\t\nPDK\tp\tnfin\t\t\tstring\t6\t\n')
        env['ST_TEST_DECK'] = ('simulator lang=spectre\nparameters AVDD=1.14 iout=10m IOUT=200m da_rst=1\n'
            'subckt core D G S B\nI21 (D G S B) nmod l=134n nfin=6\nI105 (D G S B) pmod l=134n nfin=6\n'
            + ''.join('I25\\<%d\\> (D G S B) nmod l=240n nfin=4\n'%i for i in range(1000)) + 'ends core\n'
            'XCORE (VDD G 0 0) core\nVDD (VDD 0) vsource dc=AVDD type=pwl wave=[ 0 0 20u AVDD ]\n'
            'ILOAD (VDD 0) actual_load dc=iout alternate=IOUT\nBITS (G 0) bit_driver reset=da_rst\n')
        # Actual selected includes must be present, as in the real preflight export.
        model = base / 'models with spaces.scs'
        env['ST_TEST_DECK'] += 'include '+json.dumps(str(model))+' section=ss_mos\ninclude '+json.dumps(str(model))+' section=pre\n'
        preflight = base / 'preflight'
        result = source.run_entry(session, read, preflight, env)
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        native = base / 'native_reader'
        native.write_text('#!'+sys.executable+'\nimport json,os,sys,time\nfrom pathlib import Path\n'
            'if os.environ.get("ST_TEST_NATIVE_FAIL"): print("*Error* actual native read failed"); sys.exit(7)\n'
            'if os.environ.get("ST_TEST_NATIVE_WAIT"): time.sleep(3)\n'
            'out=[]\n'
            'def rec(kind,scope,name,value): out.append("ST_MAE_RECORD\\t"+kind+"\\t"+json.dumps(scope)+"\\t"+json.dumps(name)+"\\tOK\\t"+value)\n'
            'rec("definition_files","presim","files",os.environ.get("ST_TEST_DEFINITIONS","nil"))\n'
            'for inst,cell in [("I21","n"),("I105","p")]:\n'
            ' for k,v in [("oa_library","PDK"),("oa_cell",cell),("oa_view","symbol")]: rec("source",inst,k,json.dumps(v))\n'
            ' rec("cdf_value",inst,"l",json.dumps("134n")); rec("cdf_value",inst,"nfin",json.dumps("6"))\n'
            ' rec("cdf_choices",inst,"nfin","(4 6 8)")\n'
            ' rec("cdf_mapping",inst,"propMapping","(nil w fw nf fingers mr m)")\n'
            'Path(os.environ["ST_BATCH_NATIVE_REPORT"]).write_text("\\n".join(out)+"\\nST_MAESTRO_SETUP_READ_COMPLETE\\n")\n')
        native.chmod(0o755)
        spectre = base / 'spectre_probe'
        spectre.write_text('#!'+sys.executable+'\nimport os,sys,time\nfrom pathlib import Path\n'
            'net=Path(sys.argv[1]); (net.parent/"captured_input.scs").write_text(net.read_text())\n'
            'if os.environ.get("ST_TEST_SPECTRE_FAIL"): print("ERROR (SPECTRE-7): actual simulation failed"); sys.exit(7)\n'
            'if os.environ.get("ST_TEST_SPECTRE_WAIT"): time.sleep(3)\n'
            'psf=Path(sys.argv[sys.argv.index("-raw")+1]); psf.mkdir(exist_ok=True)\n'
            'if not os.environ.get("ST_TEST_NO_PSF"):\n'
            ' (psf/"dcOp.dc").write_text("fixture DC"); (psf/"dcOpInfo.info").write_text("fixture OP")\n')
        spectre.chmod(0o755)
        reader = base / 'psf_reader'
        reader.write_text('#!'+sys.executable+'\nimport os,re,sys,json\nfrom pathlib import Path\n'
            'action=Path(sys.argv[-1]); text=action.read_text()\n'
            'if os.environ.get("ST_TEST_READER_FAIL"): print("*Error* PSF reader failed"); sys.exit(7)\n'
            'out=Path(os.environ["ST_BATCH_PSF_TABLE"]); rows=["kind\\tsignal\\tparameter\\tvalue\\tstatus","node\\tVDD\\t\\t1.14\\tOK"]\n'
            'for inst,sign in [("I21",1),("I105",-1)]:\n'
            ' if os.environ.get("ST_TEST_MISSING_TARGET") and inst=="I105": continue\n'
            ' for k,v in [("id",sign*1e-6),("vgs",sign*.5),("vds",sign*.7),("vdsat",sign*.15)]: rows.append("op\\tXCORE."+inst+"\\t"+k+"\\t"+str(v)+"\\tOK")\n'
            'out.write_text("\\n".join(rows)+"\\n")\n'
            'if not os.environ.get("ST_TEST_NO_READER_MARKER"): (action.parent/"runtime.done").write_text("OK\\n")\n')
        reader.chmod(0o755)
        env.update(ST_VIRTUOSO_BIN=str(native), ST_SPECTRE_BIN=str(spectre), ST_OCEAN_BIN=str(reader))
        return session, read, preflight, env

    def run_entry(self, session, read, preflight, env, output, extra=()):
        return subprocess.run([sys.executable, str(ENTRY), '--session', str(session), '--maestro-read', str(read),
            '--preflight', str(preflight), '--output', str(output), '--timeout', '2']+list(extra),
            capture_output=True, text=True, env=env)

    def test_batch_collects_all_context_and_signed_dc_without_source_mutation(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b); original=(p/'bench.scs').read_bytes(); result=self.run_entry(s,r,p,e,b/'out')
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('DC_PROBE=CONVERGED',result.stdout); self.assertIn('OP_TARGET I105',result.stdout)
            self.assertIn('id=-',result.stdout); self.assertIn('actual_load',result.stdout)
            self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout); self.assertIn('VBIAS_GENERATED=false',result.stdout)
            self.assertEqual((p/'bench.scs').read_bytes(),original)
            used=(b/'out/dc/captured_input.scs').read_text()
            self.assertIn('dc=AVDD type=pwl',used); self.assertIn('reset=da_rst',used)
            self.assertIn('temp=125',used); self.assertIn('nfin=6',used)
            self.assertIn('SAVED_SIMULATION_OPTIONS_IMPORTED=false',result.stdout)
            self.assertIn('NATIVE_CDF_CHOICES I21 nfin=(4 6 8)',result.stdout)

    def test_cached_corner_or_original_export_change_stops_native_work(self):
        for mode in ('corner','export','session','model'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,p,e=self.fixture(b)
                if mode=='corner':
                    v=json.loads((p/'selected_corner.json').read_text()); v['variables']['AVDD']='9'; (p/'selected_corner.json').write_text(json.dumps(v))
                elif mode=='export': (p/'bench.scs').write_text((p/'bench.scs').read_text()+'Vextra (X 0) vsource dc=1\n')
                elif mode=='session': (s/'session.conf').write_text((s/'session.conf').read_text()+'# changed\n')
                else: (b/'models with spaces.scs').write_text('changed')
                result=self.run_entry(s,r,p,e,b/'out'); self.assertNotEqual(result.returncode,0)
                self.assertFalse((b/'out/dc').exists()); self.assertFalse((b/'out/native').exists())

    def test_exported_variables_must_match_but_omitted_saved_variables_are_reported(self):
        for mode in ('undeclared_unused','mismatch'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,p,e=self.fixture(b)
                text=(p/'bench.scs').read_text()
                text=text.replace(' IOUT=200m','').replace(' alternate=IOUT','') if mode=='undeclared_unused' else text.replace('AVDD=1.14','AVDD=1.16')
                (p/'bench.scs').write_text(text); next((p/'generated').rglob('input.scs')).write_text(text)
                result=self.run_entry(s,r,p,e,b/'out')
                if mode=='undeclared_unused':
                    self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                    self.assertIn('SAVED_VARIABLES_NOT_DECLARED=IOUT',result.stdout)
                    self.assertNotIn('IOUT=200m',(b/'out/dc/captured_input.scs').read_text())
                else:
                    self.assertNotEqual(result.returncode,0)
                    self.assertIn('exported variable differs from selected Corner: AVDD',result.stdout)
                    self.assertFalse((b/'out/dc').exists())

    def test_unknown_definition_stops_dc_but_retains_independent_pdk_and_context(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b); e['ST_TEST_DEFINITIONS']='(strcat "a" "b")'
            result=self.run_entry(s,r,p,e,b/'out'); self.assertNotEqual(result.returncode,0)
            self.assertFalse((b/'out/dc').exists()); self.assertTrue((b/'out/context.json').is_file())
            self.assertTrue((b/'out/pdk.json').is_file()); self.assertIn('STAGE_NATIVE=INCOMPLETE',result.stdout)

    def test_saved_definition_file_is_included_without_editing_it(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b); definition=b/'definitions with spaces.scs'
            definition.write_text('parameters savedDefinition=1\n')
            e['ST_TEST_DEFINITIONS']='('+json.dumps(str(definition))+')'
            result=self.run_entry(s,r,p,e,b/'out'); self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertIn('DEFINITION_FILES_COUNT=1',result.stdout)
            self.assertIn('include '+json.dumps(str(definition.resolve())),(b/'out/dc/captured_input.scs').read_text())
            self.assertEqual(definition.read_text(),'parameters savedDefinition=1\n')

    def test_generated_native_actions_have_balanced_forms_and_strings(self):
        from types import SimpleNamespace
        import collect_cascode_batch as batch
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b)
            bound=batch.inputs(SimpleNamespace(session=s,maestro_read=r,preflight=p))
            info=batch.pdk(bound,b)
            actions=[batch.native_action(bound,info),batch.psf_action('/psf',['CORE.I21','CORE.I105'],bound['pinned']['init'],b/'values.tsv')]
            for code in actions:
                depth=0; quoted=False; escape=False; comment=False
                for char in code:
                    if comment:
                        if char=='\n': comment=False
                    elif quoted:
                        if escape: escape=False
                        elif char=='\\': escape=True
                        elif char=='"': quoted=False
                    elif char==';': comment=True
                    elif char=='"': quoted=True
                    elif char=='(': depth+=1
                    elif char==')': depth-=1
                    self.assertGreaterEqual(depth,0)
                self.assertEqual(depth,0,'unbalanced native action')
                self.assertFalse(quoted,'unclosed native string')

    def test_interrupted_command_terminates_its_native_process_group(self):
        import collect_cascode_batch as batch
        class Process:
            pid=987654321
            calls=0
            def wait(self, timeout=None):
                self.calls+=1
                if self.calls==1: raise KeyboardInterrupt()
                return -15
        with tempfile.TemporaryDirectory() as d:
            process=Process()
            with patch.object(batch.subprocess,'Popen',return_value=process), patch.object(batch.os,'killpg') as terminate:
                with self.assertRaises(KeyboardInterrupt):
                    batch.command(['fixture'],d,{},2,Path(d)/'run.log')
                terminate.assert_called_once_with(process.pid,batch.signal.SIGTERM)
                self.assertEqual(process.calls,2)

    def test_native_failure_still_returns_other_stage_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b); e['ST_TEST_NATIVE_FAIL']='1'
            result=self.run_entry(s,r,p,e,b/'out'); self.assertNotEqual(result.returncode,0)
            self.assertIn('STAGE_CONTEXT=COMPLETE',result.stdout); self.assertIn('STAGE_PDK=COMPLETE',result.stdout)
            self.assertIn('actual native read failed',result.stdout); self.assertFalse((b/'out/dc').exists())

    def test_simulator_failure_timeout_and_missing_psf_are_not_convergence(self):
        for key in ('ST_TEST_SPECTRE_FAIL','ST_TEST_SPECTRE_WAIT','ST_TEST_NO_PSF'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,p,e=self.fixture(b); e[key]='1'
                result=self.run_entry(s,r,p,e,b/'out',('--timeout','1')); self.assertNotEqual(result.returncode,0)
                self.assertNotIn('DC_PROBE=CONVERGED',result.stdout); self.assertTrue((b/'out/dc/spectre.log').is_file())
                self.assertIn('STAGE_PDK=COMPLETE',result.stdout)

    def test_op_reader_failure_missing_marker_and_missing_target_are_reported(self):
        for key in ('ST_TEST_READER_FAIL','ST_TEST_NO_READER_MARKER','ST_TEST_MISSING_TARGET'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as d:
                b=Path(d); s,r,p,e=self.fixture(b); e[key]='1'
                result=self.run_entry(s,r,p,e,b/'out'); self.assertNotEqual(result.returncode,0)
                self.assertIn('DC_PROBE=CONVERGED',result.stdout); self.assertNotIn('STAGE_OP=COMPLETE',result.stdout)
                self.assertIn('ELECTRICAL_VERIFIED=false',result.stdout)

    def test_old_output_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b); out=b/'out'; out.mkdir(); (out/'keep').write_text('original')
            result=self.run_entry(s,r,p,e,out); self.assertNotEqual(result.returncode,0); self.assertEqual((out/'keep').read_text(),'original')

    def test_long_context_is_bounded_and_details_are_retained(self):
        with tempfile.TemporaryDirectory() as d:
            b=Path(d); s,r,p,e=self.fixture(b)
            # Extend both originals; cached export correspondence still holds.
            extra=''.join('LOAD%d (VDD 0) actual_load dc=iout\n'%i for i in range(300))
            (p/'bench.scs').write_text((p/'bench.scs').read_text()+extra)
            exported=next((p/'generated').rglob('input.scs')); exported.write_text((p/'bench.scs').read_text())
            result=self.run_entry(s,r,p,e,b/'out'); self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertLessEqual(len(result.stdout.splitlines()),190)
            self.assertIn('DETAIL_ROWS_OMITTED=',result.stdout); self.assertIn('OP_TARGET I105',result.stdout)
            self.assertIn('LOAD299',(b/'out/context.json').read_text())


if __name__ == '__main__': unittest.main()
