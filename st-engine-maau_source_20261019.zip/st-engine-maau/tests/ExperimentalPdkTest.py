import copy
import csv
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'server/site'))
from standalone_pdk import build_metadata
from site_data import skill_metadata


class ExperimentalPdkTest(unittest.TestCase):
    def resistor_check_fixture(self, callback='pdk_resistor_callback()', minimum=None, maximum=None):
        dev=dict(normalized_to_cdf={'resistance':'r','cdf_segments':'segments'},
                 actual_parameter_seed={'resistance':48259.84,'cdf_segments':25})
        columns={'r':[48259.84,376426.75199999998,772157.44], 'segments':[25,195,400]}
        bounds={'r':({'units':'resistance'},'resistance',{}),
                'segments':({'units':''},'cdf_segments',{})}
        records=[]
        def add(i,kind,name,value):
            records.append(dict(scope=str(i+1),kind=kind,name=name,status='OK',raw_value=json.dumps(value)))
        for i in range(3):
            add(i,'r_status','apply','OK')
            for name,values in columns.items():
                add(i,'r_value',name,('376.426752K' if i==1 and name=='r' else values[i]))
                add(i,'r_min',name,minimum)
                add(i,'r_max',name,maximum)
                add(i,'r_callback',name,callback)
        return dev,columns,bounds,records

    def test_resistor_native_rule_required_and_corrections_excluded(self):
        from experimental_pdk import accepted_resistor_trials
        args=self.resistor_check_fixture()
        accepted,rejected=accepted_resistor_trials(*args)
        self.assertEqual(accepted,[0,1,2]);self.assertEqual(rejected,[])
        for mode in ('clamp','reject','missing'):
            dev,columns,bounds,records=self.resistor_check_fixture()
            for row in records:
                if row['scope']=='2' and row['kind']=='r_value' and row['name']=='segments':
                    row['raw_value']='100' if mode=='clamp' else 'null' if mode=='missing' else row['raw_value']
                if mode=='reject' and row['scope']=='2' and row['kind']=='r_status':row['raw_value']='"REJECTED"'
            accepted,rejected=accepted_resistor_trials(dev,columns,bounds,records)
            self.assertEqual(accepted,[0,2]);self.assertEqual(rejected[0]['point'],2)
        dev,columns,bounds,records=self.resistor_check_fixture()
        for row in records:
            if row['scope']=='2' and row['kind']=='r_status':row['raw_value']='"CALLBACK_ERROR"'
        records.append(dict(scope='2',kind='r_error',name='apply',status='OK',
                            raw_value=json.dumps('segments exceeds PDK maximum: 195')))
        accepted,rejected=accepted_resistor_trials(dev,columns,bounds,records)
        self.assertEqual(accepted,[0,2])
        self.assertIn('segments exceeds PDK maximum: 195',rejected[0]['reason'])
        accepted,rejected=accepted_resistor_trials(*self.resistor_check_fixture(callback=None))
        self.assertEqual(accepted,[])
        self.assertTrue(all('no native PDK adjustment rule' in r['reason'] for r in rejected))
        # A callback on the r display cannot stand in for an unknown segment rule.
        dev,columns,bounds,records=self.resistor_check_fixture(callback=None)
        dev['cell']='rhrpo_2t_ckt'
        for row in records:
            if row['kind']=='r_callback' and row['name']=='r':row['raw_value']='"display_r()"'
        self.assertEqual(accepted_resistor_trials(dev,columns,bounds,records)[0],[])
        for row in records:
            if row['kind']=='r_callback' and row['name']=='segments':row['raw_value']='"check_segments()"'
        self.assertEqual(accepted_resistor_trials(dev,columns,bounds,records)[0],[0,1,2])

    def test_native_explicit_limits_and_discrete_holes_are_enforced(self):
        from experimental_pdk import accepted_resistor_trials
        args=self.resistor_check_fixture(callback=None,minimum=1,maximum=1000000)
        self.assertEqual(accepted_resistor_trials(*args)[0],[0,1,2])
        dev,columns,bounds,records=self.resistor_check_fixture()
        for row in records:
            if row['kind']=='r_max' and row['name']=='segments':row['raw_value']='200'
        self.assertEqual(accepted_resistor_trials(dev,columns,bounds,records)[0],[0,1])
        for i in range(3):
            for j,n in enumerate((25,400)):
                records.append(dict(scope=str(i+1),kind='r_choice',name='segments:'+str(j),status='OK',raw_value=str(n)))
        self.assertEqual(accepted_resistor_trials(dev,columns,bounds,records)[0],[0])
        # A lone bound without a callback is not a complete adjustment range.
        self.assertEqual(accepted_resistor_trials(*self.resistor_check_fixture(callback=None,minimum=1))[0],[])
        # Missing report fields are execution errors, not electrical failures.
        dev,columns,bounds,records=self.resistor_check_fixture();records.pop()
        with self.assertRaisesRegex(ValueError,'report incomplete'):
            accepted_resistor_trials(dev,columns,bounds,records)

    def test_native_resistor_batch_uses_existing_adapter_and_one_session(self):
        from experimental_pdk import native_resistor_trials, native_trial_text
        from read_maestro_setup import MARKER
        self.assertEqual(native_trial_text(240*1e-9),'240n')
        self.assertEqual(native_trial_text(240e-9),'2.3999999999999998e-07')
        self.assertEqual(native_trial_text(376426.75199999998),'376426.75199999998')
        self.assertEqual(native_trial_text(0),'0')
        self.assertEqual(native_trial_text(195),'195')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);work=root/'work';work.mkdir();out=root/'out';out.mkdir()
            cds=root/'cds.lib';cds.write_text('DEFINE existing /existing\n')
            (work/'session.conf').write_text('cds_lib='+str(cds)+'\nvariant_library=EXPERIMENT\n'
                'source_library=SOURCE\nsource_cell=core\nsource_view=schematic\n')
            tech=root/'tech.json'
            tech.write_text(json.dumps([dict(devices=[dict(oa_library='MOS_PDK',cell='n18',kind='mos_n'),
                dict(oa_library='MOS_PDK',cell='p18',kind='mos_p')],
                non_target_devices=[dict(oa_library='UNSELECTED',cell='unused',kind='mos_n')])]))
            manifest={'tech':str(tech)}
            dev,columns,bounds,records=self.resistor_check_fixture()
            dev.update(oa_library='PDK',cell='rhrpo_2t_ckt')
            seed=dict(scope='seed',kind='r_status',name='apply',status='OK',raw_value='"OK"')
            records=[seed]+records
            def native(argv,directory,env,timeout,log):
                action=Path(argv[argv.index('-replay')+1]);script=action.read_text()
                self.assertEqual(directory,cds.parent.resolve())
                self.assertIn('maauTvSetCdf(inst values)',script)
                self.assertIn('standalone_topology_variant.il',script)
                self.assertIn('EXPERIMENT__STAGING',script)
                self.assertIn('list("SOURCE" "core" "schematic")',script)
                self.assertIn('list("MOS_PDK" "n18" "symbol")',script)
                self.assertIn('list("MOS_PDK" "p18" "symbol")',script)
                self.assertNotIn('UNSELECTED',script)
                self.assertLess(script.index('foreach(contextRef'),script.index('master=dbOpenCellViewByType'))
                self.assertIn('foreach(point cons(list("seed"',script)
                self.assertIn('when(equal(scope "seed")\n          error("RESISTOR_PDK_SEED_FAILED',script)
                self.assertIn('failureText=if(result then nil else sprintf(nil "%L" errset.errset))',script)
                self.assertNotIn('dbSave',script);self.assertNotIn('spectre',script)
                self.assertNotIn('__POINTS__',script)
                # Every proposal has a fresh instance; values follow C++ map order.
                self.assertIn('dbDeleteObject(inst)',script)
                self.assertIn('return(t)\n  ) t)',script)
                self.assertLess(script.index('list("name" "r")'),script.index('list("name" "segments")'))
                text=''.join('ST_MAE_RECORD\t'+r['kind']+'\t'+json.dumps(r['scope'])+'\t'+
                    json.dumps(r['name'])+'\tOK\t'+r['raw_value']+'\n' for r in records)+MARKER+'\n'
                (action.parent/'native.tsv').write_text(text)
            with patch('standalone.environment',return_value={'PATH':'/bin','ST_PREPARED_JSON_FILE':'stale'}), \
                 patch('collect_cascode_batch.executable',return_value='/bin/virtuoso'), \
                 patch('collect_cascode_batch.command',side_effect=native) as call:
                self.assertEqual(native_resistor_trials(work,manifest,out,dev,columns),records)
                self.assertEqual(call.call_count,1)
                self.assertNotIn('ST_PREPARED_JSON_FILE',call.call_args.args[2])
            # A native process failure must not yield an accepted search table.
            other=root/'failed';other.mkdir()
            with patch('standalone.environment',return_value={}), \
                 patch('collect_cascode_batch.executable',return_value='/bin/virtuoso'), \
                 patch('collect_cascode_batch.command',side_effect=ValueError('native failed')):
                with self.assertRaisesRegex(ValueError,'native failed'):
                    native_resistor_trials(work,manifest,other,dev,columns)
            # Both exit paths must preserve the original error, not report an
            # empty legal range. A partial report containing only the seed is
            # sufficient; no adjustment or DC needs to execute.
            for exit_error in (False,True):
                failed=root/('seed_failure_'+str(exit_error));failed.mkdir()
                def seed_failure(argv,directory,env,timeout,log):
                    action=Path(argv[argv.index('-replay')+1])
                    (action.parent/'native.tsv').write_text(
                        'ST_MAE_RECORD\tr_status\t"seed"\t"apply"\tOK\t"CALLBACK_ERROR"\n'
                        'ST_MAE_RECORD\tr_error\t"seed"\t"apply"\tOK\t'+
                        json.dumps('eval: undefined function - siteResistorCallback')+'\n'+MARKER+'\n')
                    if exit_error:raise ValueError('native exit 70')
                with patch('standalone.environment',return_value={}), \
                     patch('collect_cascode_batch.executable',return_value='/bin/virtuoso'), \
                     patch('collect_cascode_batch.command',side_effect=seed_failure) as native_call:
                    with self.assertRaisesRegex(ValueError,'original resistor seed callback failed.*siteResistorCallback'):
                        native_resistor_trials(work,manifest,failed,dev,columns)
                    self.assertEqual(native_call.call_count,1)

    def fixture(self, root):
        probe = root / 'probe.tsv'
        fields = ['oa_library', 'oa_cell', 'oa_view', 'model_name', 'terminal_names',
                  'parameter', 'units', 'min', 'max', 'default_value', 'has_schematic']
        with probe.open('w') as out:
            writer = csv.writer(out, delimiter='\t', lineterminator='\n')
            writer.writerow(fields)
            for parameter, unit, value in [('l', 'lengthMetric', '134n'), ('nfin', '', '4'), ('m', '', '1')]:
                writer.writerow(['PDK', 'opaque', 'symbol', 'actual_model', 'D,G,S,B', parameter,
                                 unit, '', '', value, 'false'])
        native = root / 'native_records.json'
        native.write_text(json.dumps([dict(kind='cdf_value', scope='M0', name=k, status='OK', raw_value=json.dumps(v))
                                     for k, v in dict(l='140n', nfin='6', m='2', model='actual_model').items()] +
                                    [dict(kind='source', scope='M0', name=k, status='OK', raw_value=json.dumps(v))
                                     for k, v in dict(oa_library='PDK', oa_cell='opaque').items()]))
        profile = dict(validation_scope='experimental_dc', experimental_parameter_seeds={
            'PDK/opaque': dict(instance='M0', native_records=str(native),
                              native_records_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),
                              trials={'fin': [5, 6, 7]})})
        rules = dict(source='PDK connectivity and model evidence', devices={'PDK/opaque': dict(
            kind='mos_n', normalized_to_cdf={'length': 'l', 'fin': 'nfin', 'multiplier': 'm'},
            terminalRoles={'D': 'drain', 'G': 'gate', 'S': 'source', 'B': 'bulk'}, bulkRule='isolated_well')})
        return probe, native, profile, rules

    def test_trial_metadata_uses_actual_seeds_and_never_scans_model_tree(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            with patch('standalone_pdk.model_paths', side_effect=AssertionError('full PDK scan')):
                data = build_metadata(root, probe, profile, rules)
            dev = data['devices'][0]
            self.assertTrue(dev['native_parameter_trials'])
            self.assertEqual(dev['constraints']['length']['allowed'], [140e-9])
            self.assertEqual(dev['constraints']['multiplier']['allowed'], [2.0])
            self.assertEqual(dev['constraints']['fin']['allowed'], [6.0, 5.0, 7.0])
            self.assertEqual(dev['constraints']['fin']['min'], 5)
            self.assertEqual(dev['constraints']['fin']['max'], 7)
            self.assertFalse(data['parameter_domain_verified'])
            self.assertEqual(skill_metadata(data)['devices']['PDK/opaque']['nativeParameterTrials'], True)
            self.assertIn(str(native.resolve()), data['source_file_sha256'])
            self.assertNotIn('maxAbsVgs', dev)

    def test_actual_seed_required_even_with_cdf_defaults(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            native.write_text('[]')
            profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
            with self.assertRaisesRegex(ValueError, 'actual.*seed'):
                build_metadata(root, probe, profile, rules)

    def test_known_explicit_and_one_sided_cdf_bound_reject_trials(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            rules['devices']['PDK/opaque']['constraints'] = {'fin': {'min': 4, 'max': 6}}
            with self.assertRaisesRegex(ValueError, 'known.*bound'):
                build_metadata(root, probe, profile, rules)
            rules['devices']['PDK/opaque'].pop('constraints')
            probe.write_text(probe.read_text().replace('nfin\t\t\t\t4', 'nfin\t\t\t6\t4'))
            with self.assertRaisesRegex(ValueError, 'known.*bound'):
                build_metadata(root, probe, profile, rules)

    def test_proven_polarity_pin_mapping_and_body_are_mandatory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            for key in ('kind', 'terminalRoles', 'bulkRule'):
                invalid = copy.deepcopy(rules); invalid['devices']['PDK/opaque'].pop(key)
                with self.assertRaises(ValueError):
                    build_metadata(root, probe, profile, invalid)

    def test_bulk_strategy_only_accepts_supported_explicit_template_conventions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            rule = rules['devices']['PDK/opaque']
            for kind in ('mos_n', 'mos_p'):
                rule['kind'] = kind
                for strategy in ('ground', 'my_custom_body', 'tied_to_source', 'fixed_rail'):
                    rule['bulkRule'] = strategy
                    with self.assertRaisesRegex(ValueError, 'supported Bulk strategy'):
                        build_metadata(root, probe, profile, rules)
                for strategy in ('rail', 'isolated_well'):
                    rule['bulkRule'] = strategy
                    self.assertEqual(build_metadata(root, probe, profile, rules)['devices'][0]['bulkRule'], strategy)

    def test_strict_pipeline_rejects_trial_configuration_and_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            data = build_metadata(root, probe, profile, rules)
            data['validation_scope'] = 'dc_operating_point'
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                skill_metadata(data)
            profile['validation_scope'] = 'dc_operating_point'
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                build_metadata(root, probe, profile, rules)

    def test_seed_drift_duplicate_records_and_nonfinite_trial_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            original = native.read_text(); native.write_text(original + '\n')
            with self.assertRaisesRegex(ValueError, 'changed'):
                build_metadata(root, probe, profile, rules)
            native.write_text(original)
            profile['experimental_parameter_seeds']['PDK/opaque']['trials']['fin'] = [float('nan')]
            with self.assertRaises(ValueError):
                build_metadata(root, probe, profile, rules)

    def test_native_length_suffix_without_units_and_frozen_zero_property(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            probe.write_text(probe.read_text().replace('lengthMetric', '') +
                             'PDK\topaque\tsymbol\tactual_model\tD,G,S,B\tdiffColor\t\t\t\t1\tfalse\n')
            records = json.loads(native.read_text())
            records.append(dict(kind='cdf_value', scope='M0', name='diffColor', status='OK', raw_value='0'))
            native.write_text(json.dumps(records))
            profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
            dev = build_metadata(root, probe, profile, rules)['devices'][0]
            self.assertEqual(dev['constraints']['length']['allowed'], [140e-9])
            self.assertEqual(dev['constraints']['cdf_diffColor']['allowed'], [0])

    def test_cached_inspect_prepares_inputs_without_native_discovery_or_probe(self):
        import standalone
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            source = dict(lib='design', cell='core', view='schematic')
            profile.update(nominal_corner='tt', op_corners={'tt': {'temperature': 27, 'models': []}},
                           experimental_pdk_cache=dict(probe=str(probe), probe_sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),
                                                       pdk_roots=[str(root)], source_dut=source))
            profile_path = root/'profile.json'; profile_path.write_text(json.dumps(profile))
            rules_path = root/'rules.json'; rules_path.write_text(json.dumps(rules))
            args = ['standalone.py', 'inspect', '--validation-scope', 'experimental_dc', '--simulation-profile', str(profile_path),
                    '--pdk-rules', str(rules_path), '--work-dir', str(root/'new-session'), '--backend', '/must-not-run',
                    '--cds-lib', str(root/'cds.lib'), '--lib', 'design', '--cell', 'core',
                    '--bench-lib', 'design', '--bench-cell', 'bench']
            with patch.object(sys, 'argv', args), patch('standalone.subprocess.run', return_value=SimpleNamespace(returncode=0)) as run:
                self.assertEqual(standalone.main(), 0)
            self.assertEqual(run.call_count, 1)
            self.assertEqual(run.call_args.args[0][1], 'inspect')
            metadata = json.loads((root/'new-session/analysis/standalone_inputs/pdk_metadata.json').read_text())
            self.assertEqual(metadata[0]['validation_scope'], 'experimental_dc')

    def test_op_provider_rejects_trial_catalog_in_strict_profile(self):
        from op_provider import load_scanned_catalog
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            tech = build_metadata(root, probe, profile, rules)
            catalog = root/'catalog.tsv'
            catalog.write_text('model_name\tpdk_version\toa_library\toa_cell\tkind\tterminal_names\tterminal_roles\tmaster\tnative_parameter_trials\n'
                'actual_model\t'+tech['version']+'\tPDK\topaque\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\toa_PDK__opaque\ttrue\n')
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                load_scanned_catalog(catalog, tech, tech['version'])
            self.assertIn('actual_model', load_scanned_catalog(catalog, tech, tech['version'], 'experimental_dc'))

    def test_native_master_binding_and_duplicate_values_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            records = json.loads(native.read_text())
            for mutated in (records + [records[0]], [dict(r, raw_value='"wrong"') if r['name'] == 'oa_cell' else r for r in records]):
                native.write_text(json.dumps(mutated))
                profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
                with self.assertRaisesRegex(ValueError, 'actual instance seed'):
                    build_metadata(root, probe, profile, rules)


if __name__ == '__main__':
    unittest.main()
