#pragma once

#include "Netlist.h"

namespace st {

// 在副本上执行一组结构操作。校验失败时调用方不执行 Commit，
// 原始 Netlist 因而保持不变。
class NetlistTransaction {
public:
    explicit NetlistTransaction(Netlist& target);

    Netlist& Working();
    const Netlist& Working() const;
    void Commit();
    bool Committed() const;

private:
    Netlist* target_ = nullptr;
    Netlist working_;
    bool committed_ = false;
};

} // namespace st
