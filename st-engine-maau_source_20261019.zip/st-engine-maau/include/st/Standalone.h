#pragma once

#include "ChangeSet.h"
#include "Netlist.h"
#include "OaPlan.h"

#include <filesystem>
#include <map>
#include <string>
#include <vector>

namespace st::standalone {

struct DirectMosDevice {
    std::string instance;
    std::string master;
    DeviceKind kind = DeviceKind::Other;
    std::string drain_net;
    std::string gate_net;
    std::string source_net;
    std::string bulk_net;
    std::map<std::string, std::string> parameters;
    // 仅列出当前动态 PDK 目录通过所有准入规则的异型 Cascode 候选。
    std::vector<std::string> cross_flavor_candidates;
    std::map<std::string, std::vector<std::string>> candidate_rejections;
};

struct MosInventoryResult {
    bool ok = false;
    std::vector<DirectMosDevice> devices;
    std::vector<Diagnostic> diagnostics;
};

struct TransformRequestParseResult {
    bool ok = false;
    TransformRequest request;
    std::vector<Diagnostic> diagnostics;
};

struct RootGeometry {
    std::map<std::string, OaPoint> instance_locations;
    bool has_cell_bbox = false;
    OaPoint cell_lower_left;
    OaPoint cell_upper_right;
};

struct RootOaContextResult {
    bool ok = false;
    OaPlanBuildContext context;
    std::vector<Diagnostic> diagnostics;
};

bool LoadDeviceCatalogTsv(const std::filesystem::path& path,
                          DeviceCatalog& catalog,
                          std::vector<Diagnostic>& diagnostics);

// CellView 身份哈希：同一 L/C/V + 存储路径得到同一确定值（FNV-1a 64）。
// CLI 用它把 DUT/Bench 身份写进会话 Manifest，后端回读的工作点 identity
// 必须用同一函数自算，两侧才能在不交换实现细节的情况下相互校验。
std::string CellViewIdentityHash(const std::string& library,
                                 const std::string& cell,
                                 const std::string& view,
                                 const std::string& storagePath);

MosInventoryResult ListDirectMos(const Netlist& netlist,
                                 const std::string& coreSubckt,
                                 const DeviceCatalog& catalog,
                                 bool experimental_dc = false);

bool WriteMosInventoryTsv(const std::filesystem::path& path,
                          const MosInventoryResult& inventory,
                          std::string& error);

bool WriteCrossFlavorCandidatesJson(const std::filesystem::path& path,
                                    const MosInventoryResult& inventory,
                                    std::string& error);

TransformRequestParseResult ParseTransformRequest(
    const std::filesystem::path& path,
    const std::string& defaultSubckt);

bool LoadRootGeometryTsv(const std::filesystem::path& path,
                         RootGeometry& geometry,
                         std::vector<Diagnostic>& diagnostics);

RootOaContextResult BuildRootOaContext(
    const Netlist& baseline,
    const Netlist& variant,
    const std::string& coreSubckt,
    const CellViewRef& source,
    const CellViewRef& staging,
    const RootGeometry& geometry,
    const PreviewIdentity& preview);

} // namespace st::standalone
