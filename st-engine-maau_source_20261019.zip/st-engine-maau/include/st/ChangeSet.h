#pragma once

#include "Transform.h"

#include <cstddef>
#include <functional>
#include <string>
#include <vector>
#include <variant>

namespace st {

enum class TransformType {
    SameTypeCascode,
    CrossFlavorCascode,
    AddSourceResistor,
    MosStack,
};

struct InstancePath {
    // 当前独立核心用 subckt + instance 表达目标；Maau adapter 负责把
    // 稳定层级路径解析成对应的 clone-on-write cell 和局部实例名。
    std::string hierarchy;
    std::string subckt;
    std::string instance;

    std::string Canonical() const;
};

struct TransformRequest {
    std::string operation_id;
    InstancePath target;
    TransformType type = TransformType::SameTypeCascode;
    // 这是用户点“确认变换”时的完整不可变快照。生成电路时
    // 只重放这份 payload，不再从当前 UI 表单猜 Bias/W/L/端口等参数。
    std::variant<std::monostate, CascodeTransformRequest,
                 ResistorTransformRequest, StackTransformRequest> payload;
};

struct ConfirmedChange {
    TransformRequest request;
    std::size_t sequence = 0;
};

struct ReplayResult {
    bool ok = false;
    std::string failed_operation_id;
    std::vector<std::string> applied_operation_ids;
    std::vector<TransformOutcome> outcomes;
    std::map<std::string, std::vector<std::string>> parameter_groups;
    std::vector<BiasResolution::Cost> bias_costs;
    double iq_delta = 0.0;
    std::vector<Diagnostic> diagnostics;
};

using ChangeApplier =
    std::function<std::vector<Diagnostic>(Netlist&, const TransformRequest&)>;

class ChangeSet {
public:
    bool Confirm(const TransformRequest& request, Diagnostic& diagnostic);
    bool UndoLast();
    void Fresh();

    bool Empty() const;
    std::size_t Size() const;
    const std::vector<ConfirmedChange>& Changes() const;

    ReplayResult Replay(const Netlist& base, Netlist& output,
                        const ChangeApplier& apply) const;
    ReplayResult Generate(const Netlist& base, Netlist& output,
                          const DeviceCatalog& catalog) const;

private:
    std::vector<ConfirmedChange> changes_;
};

} // namespace st
