#pragma once

#include "Types.h"

#include <string>
#include <vector>

namespace st {

struct VoltageWindow {
    double minimum = 0.0;
    double maximum = 0.0;

    bool Contains(double value) const;
    double Midpoint() const;
    bool Valid() const;
};

struct BiasElementPlan {
    std::string name;
    std::string model;
    std::vector<std::string> nets;
    std::map<std::string, std::string> params;
};

struct BiasResolution {
    bool ok = false;
    std::string output_net;
    double nominal_voltage = 0.0;
    double iq_delta = 0.0;
    struct Cost {
        double current = 0.0;
        std::string supply_net;
        std::string return_net;
        double estimated_power = 0.0;
    } cost;
    std::vector<BiasElementPlan> elements;
    std::vector<Diagnostic> diagnostics;
};

} // namespace st
