#pragma once
// =============================================================
// Validate.h — 变换前的电气校验（拒绝路径是正常产品行为，
// 每个拒绝都必须给出可解释的诊断码与原因）
// =============================================================
#include "Types.h"

namespace st {

// cascode headroom：可用 |VDS| 必须 ≥ (vdsat1+margin) + (vdsat2+margin)，
// 且给 M1 分到 vx 后 M2 剩余压降 ≥ vdsat2+margin
Diagnostic checkCascodeHeadroom(double vdsAvailAbs,
                                double vdsat1, double vdsat2,
                                double margin, double vx);

// stack 电压天花板：所需最高栅压 + margin 不得超过顶轨电压（不造电荷泵）
Diagnostic checkStackCeiling(double vbHighNeeded, double topRailV);

// 异型 cascode 兼容：只允许同极性换 flavor（N↔P 混串不支持）
Diagnostic checkPolarity(DeviceKind original, DeviceKind replacement);

// bulk 策略解析：不统一规定接 source。
//   NMOS → 全局衬底网络（共衬底工艺硬约束）
//   PMOS → PDK 允许隔离阱时 tieToSource=true（接本级 source），
//          否则继承原管 bulk 网络
// 两条都走不通 → BulkPolicyUnresolved
Diagnostic resolveBulk(DeviceKind polarity, bool sourceTiedAllowed,
                       const std::string& nmosBulkNet,
                       const std::string& originalBulkNet,
                       bool& tieToSource, std::string& outNet);

} // namespace st
