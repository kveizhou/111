#pragma once
// =============================================================
// AutoBias.h — 自给电 VBIAS 模板（VBIAS_N/P_CASCODE_AUTO）
// 每个 Cascode 操作生成一个独立模板：模板内部自带参考支路，
// 不接收 IREF、手工 VBIAS 或固定模板 Cell 名。
// 拓扑与端口顺序见批准规格 §7；参数由 Task 6 求解器填入 BiasSizing。
// =============================================================
#include "Bias.h"
#include "Types.h"

#include <map>
#include <string>
#include <vector>

namespace st {

// 求解结果（Task 6 产生）：新增 Cascode 管参数 + 模板内各角色参数。
// element_parameters 必须按角色名存取（如 "P_REF"、"R_REF_N"），
// 禁止按实例顺序对应。
struct BiasSizing {
    std::map<std::string, std::string> cascode_parameters;
    std::map<std::string, std::map<std::string, std::string>> element_parameters;
    double nominal_voltage = 0.0;
    double iq_delta = 0.0;
    // 求解选中的真实master。重建、PVT、封装必须使用这组身份；两者必须同填。
    std::string mirror_master;
    std::string resistor_master;
};

struct AutoBiasTemplateRequest {
    std::string operation_id;
    DeviceKind polarity = DeviceKind::Other;   // 只允许 MosN / MosP
    std::string voltage_domain;
    std::string vhigh_net;
    std::string vlow_net;
    std::string original_source_net;           // 变换前原 MOS 的 Source 网络
    std::string control_gate_net;              // 原 MOS Gate 网络（只感知，不改写）
    std::string control_master;                // 原管 master（Control Replica 使用）
    std::string cascode_master;                // 新增管 master（Cascode Replica 使用）
    bool experimental_dc = false;
};

// 模板器件选型结果：Task 6 求解器预检与模板构建共享同一份规则，
// 禁止两处各自实现选型导致口径分叉。
struct AutoBiasDevicePlan {
    const DeviceDescriptor* control = nullptr;
    const DeviceDescriptor* cascode = nullptr;
    const DeviceDescriptor* mirror = nullptr;
    const DeviceDescriptor* resistor = nullptr;
};

// 按与 BuildAutoBiasTemplate 完全一致的顺序校验请求并选出四类器件。
// 失败返回 false，diagnostic 为第一个原因（诊断码与消息和模板构建一致）。
bool SelectAutoBiasDevices(const AutoBiasTemplateRequest& request,
                           const DeviceCatalog& catalog,
                           AutoBiasDevicePlan& plan,
                           Diagnostic& diagnostic);

// 返回一个已核实的兼容 Mirror MOS / 真实电阻固定组合。
// 优先控制管来源 Library，同级按稳定 master 名选择，不按性能排名。
bool SelectAutoBiasDeviceCandidates(const AutoBiasTemplateRequest& request,
                                    const DeviceCatalog& catalog,
                                    std::vector<AutoBiasDevicePlan>& plans,
                                    Diagnostic& diagnostic);

// 只接受目录明确登记的数值CDF参数，校验映射、类型与范围后量化。
// require_unchanged 用于原管Replica，任何量化改值都应拒绝以保持与原管一致。
// native_parameter_trials 仅 experimental_dc 接受，输入必须已属于有限试点集合。
bool QuantizeAutoBiasParameters(
    const DeviceDescriptor& descriptor,
    const std::map<std::string, std::string>& parameters,
    const std::string& role,
    std::map<std::string, std::string>& out,
    Diagnostic& diagnostic,
    bool require_unchanged = false,
    bool experimental_dc = false);

// 工程格式不能精确回读时使用17位有效数字，保持量化值的double往返精度。
std::string FormatAutoBiasParameter(double value);

struct AutoBiasTemplateResult {
    bool ok = false;
    std::string template_id;                   // VBIAS_N_CASCODE_AUTO / VBIAS_P_CASCODE_AUTO
    std::string output_net;                    // VBIAS_N / VBIAS_P
    std::vector<std::string> ports;            // 固定端口顺序
    std::vector<BiasElementPlan> elements;     // 模板内部五个角色，命名与顺序固定
    std::vector<Diagnostic> diagnostics;
};

// 从动态 PDK 目录选择镜像管与电阻，按批准规格构造固定拓扑。
// 失败时 ok=false 且 diagnostics 给出第一个原因；不做任何猜测性降级。
AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest& request,
    const BiasSizing& sizing,
    const DeviceCatalog& catalog);

} // namespace st
