#pragma once

#include "Materialization.h"
#include "OperatingPoint.h"

#include <filesystem>
#include <string>
#include <vector>

namespace st::standalone {

struct ProcessResult {
    int exit_code = -1;
    std::string message;
};

class ProcessRunner {
public:
    virtual ~ProcessRunner() = default;
    virtual ProcessResult Run(const std::vector<std::string>& arguments,
                              const std::filesystem::path& logPath) = 0;
};

class PosixProcessRunner : public ProcessRunner {
public:
    ProcessResult Run(const std::vector<std::string>& arguments,
                      const std::filesystem::path& logPath) override;
};

struct BackendPaths {
    std::filesystem::path cds_lib;
    std::filesystem::path source_roundtrip;
    std::filesystem::path target_roundtrip;
    std::filesystem::path log_dir;
    std::string core_subckt;
    // Per-session policy derived from the current DUT's scanned PDK catalog.
    // Empty only for read-only PDK discovery or legacy direct backend calls.
    std::filesystem::path device_policy{};
    std::filesystem::path operating_point_catalog{};
    bool structure_only = false;
    bool experimental_dc = false;
};

struct SnapshotOutputs {
    std::filesystem::path netlist;
    std::filesystem::path catalog;
    std::filesystem::path geometry;
};

struct PdkScanOutputs {
    std::filesystem::path raw_catalog_tsv;
    std::filesystem::path pdk_identity_tsv;
};

struct OperatingPointOutputs {
    std::filesystem::path identity_tsv;
    std::filesystem::path mos_tsv;
    std::filesystem::path resistor_tsv{}; // Optional; required for added resistor checks.
};

class ProcessVirtuosoBackend : public MaterializationHost {
public:
    ProcessVirtuosoBackend(std::filesystem::path executable,
                           BackendPaths paths,
                           ProcessRunner& runner);

    HostStatus Snapshot(const CellViewRef& source,
                        const std::string& coreSubckt,
                        const SnapshotOutputs& outputs);

    HostStatus ScanPdk(const CellViewRef& source,
                       const PdkScanOutputs& outputs);

    // Bind the exact catalog accepted by this generate run, including proof fields.
    void UseOperatingPointCatalog(const std::filesystem::path& catalog);

    // 只对 dut 指向的真实 OA CellView 求直流工作点。
    // 候选网表旁路被禁止：求解器必须先物化唯一候选 CellView。
    HostStatus RunOperatingPoint(const CellViewRef& dut,
                                 const CellViewRef& bench,
                                 const AnalysisIdentity& identity,
                                 const OperatingPointOutputs& outputs);

    HostStatus CopyCircuits(const std::vector<OaCloneMapping>& cloneMap) override;
    HostStatus WritePlanFile(const std::string& path,
                             const std::string& json) override;
    HostStatus ExecuteSkill(const std::string& workDir,
                            const std::string& skillScriptPath,
                            const std::string& planPath) override;
    HostStatus RunVariantOperatingPoint(const CellViewRef& target,
                                        const CellViewRef& bench,
                                        const AnalysisIdentity& identity,
                                        const std::string& identityTsvPath,
                                        const std::string& mosTsvPath) override;
    HostStatus RunVariantOperatingPoint(const CellViewRef& target,
                                        const CellViewRef& bench,
                                        const AnalysisIdentity& identity,
                                        const std::string& identityTsvPath,
                                        const std::string& mosTsvPath,
                                        const std::string& resistorTsvPath) override;
    HostStatus RegenerateNetlist(const CellViewRef& target,
                                 const std::string& logicalSubckt,
                                 Netlist& netlist) override;
    // Candidate audits use their own files and do not advance the final
    // source/target/package round-trip sequence.
    HostStatus RegenerateNetlistTo(const CellViewRef& target,
                                   const std::string& logicalSubckt,
                                   const std::filesystem::path& output,
                                   const std::filesystem::path& log,
                                   Netlist& netlist);
    HostStatus PublishCircuits(const std::vector<OaCloneMapping>& publishMap) override;

    HostStatus Open(const CellViewRef& target);

private:
    HostStatus Run(const std::string& verb,
                   std::vector<std::string> arguments,
                   const std::filesystem::path& logPath);
    std::filesystem::path executable_;
    BackendPaths paths_;
    ProcessRunner& runner_;
    std::size_t netlist_call_count_ = 0;
};

} // namespace st::standalone
