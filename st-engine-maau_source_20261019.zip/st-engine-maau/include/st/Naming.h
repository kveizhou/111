#pragma once

#include "Netlist.h"

#include <map>
#include <set>
#include <string>

namespace st {

enum class NameKind {
    Instance,
    Net,
    Subckt,
};

// 为一次物化分配可重复、无冲突的名称。同样的原电路和操作顺序
// 必须得到完全相同的结果，因此这里不使用随机数、时间戳或进程号。
class NameAllocator {
public:
    explicit NameAllocator(const Netlist& netlist, const std::string& subcktScope = {});

    std::string Allocate(NameKind kind, const std::string& base);

private:
    std::set<std::string>& Names(NameKind kind);

    std::set<std::string> instanceNames_;
    std::set<std::string> netNames_;
    std::set<std::string> subcktNames_;
};

} // namespace st
