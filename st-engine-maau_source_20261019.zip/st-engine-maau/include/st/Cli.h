#pragma once

#include "VirtuosoBackend.h"

#include <iosfwd>
#include <string>
#include <vector>

namespace st::standalone {

int RunCli(const std::vector<std::string>& arguments,
           std::ostream& output,
           std::ostream& error,
           ProcessRunner& runner);

void PrintCliHelp(std::ostream& output);

} // namespace st::standalone
