#pragma once

// 仅用于保留最初 st-engine 演示和数值回归。这里的接口假设 MOS 物理端子
// 顺序为 D/G/S/B，不能用于 Maau/PDK 正式接入。其电阻与Stack拓扑仍与
// 正式路径保持一致：Source串联电阻、Drain侧保留原Stack实例、全部Gate共栅。
// 新代码只包含 Transform.h。

#include "Transform.h"

namespace st {

struct CascodeOptions {
    std::string newMaster;
    std::string biasNet;
    OpPoint op;
    double vdsat1 = 0.0, vdsat2 = 0.0;
    double margin = 0.0;
    bool sourceTiedBulk = false;
    std::string nmosBulkNet = "VSS";
};
TransformOutcome applyCascode(Netlist& nl, const std::string& subName,
                              const std::string& target,
                              const CascodeOptions& options, const ModelDb& db);

struct ResistorOptions {
    std::string resModel;
    double rTarget = 0.0;
    double grid = 0.0;
    double rSeed = 0.0;
};
TransformOutcome applyResistor(Netlist& nl, const std::string& subName,
                               const std::string& target,
                               const ResistorOptions& options, const ModelDb& db);

struct StackOptions {
    int n = 2;
    bool sourceTiedBulk = false;
    std::string nmosBulkNet = "VSS";
};
TransformOutcome applyStack(Netlist& nl, const std::string& subName,
                            const std::string& target,
                            const StackOptions& options, const ModelDb& db);

} // namespace st
