#pragma once
// =============================================================
// Solver.h — 结构变换的参数求解（纯函数，公式口径见评审版 §3.2
// 与串讲会问答文档的演算节；这里把人工演算固化成代码）
// =============================================================
#include "Types.h"

namespace st {

struct CascodeBias {
    double vx = 0.0;     // 中间节点电压目标（保 M1 饱和的最小压降点）
    double vbias = 0.0;  // 新管栅压目标
};

// cascode 偏置目标：NMOS  Vx = Vs + VDSAT + margin，VBIAS = Vx + VGS2
//                   PMOS  镜像：Vx = Vs − |VDSAT| − margin，VBIAS = Vx − |VGS2|
// 注：这里给的是搜索种子；最终值由 PDK 模型 DC 求解（引擎之外的求解器）
CascodeBias solveCascodeBias(DeviceKind polarity, double vs,
                             double vdsat, double margin, double vgs2);

// 直流等效电阻：Rdc = |VDS| / |ID|；id 过小视为不可等效，ok=false
double solveRdc(double vdsAbs, double idAbs, bool& ok);

// 阻值量化：对齐到 grid 的最近倍数（grid<=0 原样返回）
double snapToGrid(double r, double grid);

} // namespace st
