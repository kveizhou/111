#pragma once

#include "OaPlan.h"

#include <string>

namespace st {

std::string EscapeJson(const std::string& input);
std::string ComputeTopologyHash(const OaMaterializationPlan& plan);
std::string WritePlanJson(const OaMaterializationPlan& plan);

} // namespace st
