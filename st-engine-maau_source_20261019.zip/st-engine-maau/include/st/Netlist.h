#pragma once
// =============================================================
// Netlist.h — spectre 网表（.scs 子集）的数据模型、解析与发射
// 支持：// 注释、行尾 \ 续行、行首 + 续行、subckt/ends、
//       parameters 行、含 <...> 的数组实例名、k=v 参数
// =============================================================
#include "Types.h"

namespace st {

struct Instance {
    std::string name;                       // 实例名，可含 <i>（如 I25<51>）
    std::vector<std::string> nets;          // 端子网络，顺序依 ModelDb 约定
    std::string model;                      // 模型 / 子电路名（master）
    std::map<std::string, std::string> params; // w=166n 等，值保留原文
};

struct Subckt {
    std::string name;
    std::vector<std::string> pins;
    std::vector<Instance> instances;
    std::map<std::string, std::string> params; // subckt 内 parameters 行
    std::vector<std::string> bodyDirectives;  // subckt 内 save/include/未知但需保留的原文

    Instance* find(const std::string& instName);
    const Instance* find(const std::string& instName) const;
    bool remove(const std::string& instName);            // 找到并删除返回 true
    int netRefCount(const std::string& net) const;       // 网络被实例端子引用次数
    // 在 refName 实例之后插入；refName 为空则追加到末尾
    void insertAfter(const std::string& refName, const Instance& inst);
};

struct Netlist {
    std::vector<std::string> preamble;   // 顶层指令原文（model/include/分析语句等）
    std::vector<Subckt> subckts;
    std::vector<Instance> topInstances;  // 顶层散落实例（testbench 的 V/R/I 等）

    Subckt* find(const std::string& subName);
    const Subckt* find(const std::string& subName) const;
};

// 按 PDK 提供的端子语义读取或改写网络。失败时不修改实例。
bool getTerminalNet(const Instance& instance, const DeviceCatalog& catalog,
                    TerminalRole role, std::string& net, Diagnostic& diagnostic);
bool setTerminalNet(Instance& instance, const DeviceCatalog& catalog,
                    TerminalRole role, const std::string& net, Diagnostic& diagnostic);

// 解析；失败不抛异常，诊断写入 diags
Netlist parseSpectre(const std::string& text, std::vector<Diagnostic>& diags);

// 发射为 spectre 文本；实例参数过长时以 "+ " 续行折行，确定性输出
std::string emitSpectre(const Netlist& nl);

// "166n" -> 1.66e-7；Spectre/CDF 的 M=1e6、m=1e-3；
// 其余支持 n/u/p/f/k/meg/g 的大小写形式。
double parseSuffixValue(const std::string& s, bool& ok);

// 工程计数法输出：48540 -> "48.54k"，0.001 -> "1m"；用于生成的参数值
std::string formatEngineering(double v);

} // namespace st
