#pragma once

#include "Netlist.h"

#include <string>
#include <map>
#include <utility>
#include <set>
#include <vector>

namespace st {

struct VariantVerificationReport {
    bool ok = false;
    bool ready_for_sizing = false;
    std::string baseline_topology_hash;
    std::string expected_topology_hash;
    std::string actual_topology_hash;
    std::vector<std::string> mismatches;
    std::vector<Diagnostic> diags;
};

struct VariantVerificationPolicy {
    // PDK netlister可能补写 AD/AS/PD/PS 等派生参数；只有明确白名单才允许。
    std::set<std::string> allowed_extra_instance_parameters;
    // Approval is local to one generated subckt/instance, never the source.
    std::map<std::pair<std::string, std::string>, std::set<std::string>>
        allowed_extra_parameters_by_instance{};
};

// Hash 只描述结构：层级、pin、实例名、master 和按 PDK 顺序发射的网络；
// 不含实例输出顺序和参数，参数由 VerifyVariantRoundTrip 单独逐项核对。
std::string ComputeNetlistTopologyHash(const Netlist& netlist);

// Hash 描述网表的全部电气参数（subckt 参数和实例参数）。
// 与 topology hash 配对使用，防止同一拓扑的不同候选参数误复用工作点。
std::string ComputeNetlistParameterHash(const Netlist& netlist);

// expected 是结构变换引擎生成并已提交的最终逻辑 Variant；actual 是 OA
// 物化后由 NetlistCreator 重新生成并解析的网表。只有全部匹配才允许 Sizing。
VariantVerificationReport VerifyVariantRoundTrip(const Netlist& baseline,
                                                 const Netlist& expected,
                                                 const Netlist& actual,
                                                 const VariantVerificationPolicy& policy = {});

} // namespace st
