#pragma once

#include "Types.h"

#include <map>
#include <string>
#include <vector>

namespace st {

struct CandidateSelection {
    std::vector<const DeviceDescriptor*> accepted;
    std::map<std::string, std::vector<std::string>> rejected_reasons;
};

// 验证来自 PDK/CDF 的参数域。false 时可选 reason 说明第一个违反的规则。
bool ValidateParameterConstraint(const ParameterConstraint& constraint,
                                 std::string* reason = nullptr);

double QuantizeParameter(double value, const ParameterConstraint& constraint);

// Unknown metadata is unconstrained here; callers separately enforce strict completeness.
// Every known domain set must share at least one common supported domain.
bool HaveCompatibleVoltageDomains(const std::vector<const DeviceDescriptor*>& descriptors);

CandidateSelection SelectCrossFlavorCandidates(
    const DeviceDescriptor& original,
    const DeviceCatalog& catalog,
    const std::string& voltage_domain,
    bool experimental_dc = false);

// 归一化、稳定排序的 PDK 目录 JSON。调用者负责把文本写入会话产物。
std::string WritePdkCatalogJson(const DeviceCatalog& catalog);

} // namespace st
