#include "op_simulation_provider.h"

#include <filesystem>
#include <map>
#include <ostream>
#include <set>
#include <vector>

namespace st::maau {
namespace {

bool completeCellView(const CellViewRef& value)
{
    return !value.library.empty() && !value.cell.empty() && !value.view.empty();
}

bool completeIdentity(const AnalysisIdentity& value)
{
    return !value.dut_hash.empty() && !value.bench_hash.empty() &&
        !value.pdk_version.empty() && !value.corner.empty() &&
        !value.topology_hash.empty() && !value.parameter_hash.empty() &&
        !value.solver_version.empty();
}

OpSimulationResult failure(const OpSimulationRequest& request,
                           int exitCode,
                           const std::string& message)
{
    return {false, exitCode, message, request.simulation_directory};
}

} // namespace

OpSimulationResult MaauOpSimulationProvider::Run(
    const OpSimulationRequest& request, OpSimulationHost& host) const
{
    if (!completeCellView(request.dut)) {
        return failure(request, 64, "DUT L/C/V is incomplete");
    }
    if (!completeCellView(request.bench)) {
        return failure(request, 64, "Bench L/C/V is incomplete");
    }
    if (request.corner.empty() || request.identity_output.empty() ||
        request.mos_output.empty() || request.simulation_directory.empty()) {
        return failure(request, 64,
            "corner, output paths and simulation directory are required");
    }
    if (!completeIdentity(request.requested_identity) ||
        request.requested_identity.corner != request.corner) {
        return failure(request, 64,
            "complete requested analysis identity matching corner is required");
    }

    std::error_code directoryError;
    std::filesystem::create_directories(
        request.simulation_directory, directoryError);
    if (directoryError) {
        return failure(request, 70, "cannot create simulation directory: " +
            directoryError.message());
    }

    std::string benchMessage;
    const int benchCode = host.ValidateBench(request.bench, benchMessage);
    if (benchCode != 0) {
        return failure(request, benchCode == 64 ? 64 : 70,
            benchMessage.empty() ? "cannot resolve requested Bench" : benchMessage);
    }

    auto status = host.RebindDutInTemporaryCase(
        request.dut, request.bench, request.simulation_directory);
    if (!status.ok) return failure(request, 70, status.message);
    status = host.PreserveBenchEnvironment(request.bench, request.corner);
    if (!status.ok) return failure(request, 70, status.message);
    status = host.RequestDcOpAndOppoint();
    if (!status.ok) return failure(request, 70, status.message);

    std::string runMessage;
    const int runCode = host.RunSpectre(request.simulation_directory, runMessage);
    if (runCode != 0) {
        return failure(request, runCode == 71 ? 71 : 70,
                       runMessage.empty() ? "Spectre execution failed" : runMessage);
    }

    OperatingPointSnapshot snapshot;
    status = host.ExtractOperatingPoint(snapshot);
    if (!status.ok) return failure(request, 74, status.message);
    if (!IsReusable(snapshot, request.requested_identity)) {
        return failure(request, 74,
            "extracted operating-point identity does not match the request");
    }
    std::vector<Diagnostic> diagnostics;
    if (!WriteOperatingPointTsv(request.identity_output, request.mos_output,
                                request.resistor_output,
                                snapshot, diagnostics)) {
        return failure(request, 74, diagnostics.empty()
            ? "cannot write operating-point TSV"
            : diagnostics.front().message);
    }
    return {true, 0, {}, request.simulation_directory};
}

int RunMaauOpProviderCli(int argc,
                         char** argv,
                         OpSimulationHost& host,
                         std::ostream& output,
                         std::ostream& error)
{
    const std::set<std::string> allowed = {
        "--dut-lib", "--dut-cell", "--dut-view", "--dut-storage",
        "--bench-lib", "--bench-cell", "--bench-view", "--bench-storage",
        "--dut-hash", "--bench-hash", "--pdk-version", "--topology-hash",
        "--parameter-hash", "--solver-version",
        "--corner", "--identity-output", "--mos-output", "--resistor-output",
        "--simulation-dir",
    };
    std::map<std::string, std::string> options;
    for (int index = 1; index < argc; index += 2) {
        if (index + 1 >= argc) {
            error << "option requires a value: " << argv[index] << '\n';
            return 64;
        }
        const std::string key(argv[index]);
        if (allowed.count(key) == 0) {
            error << "unsupported option: " << key << '\n';
            return 64;
        }
        if (options.count(key) != 0) {
            error << "duplicate option: " << key << '\n';
            return 64;
        }
        options.emplace(key, argv[index + 1]);
    }
    const std::vector<std::string> required = {
        "--dut-lib", "--dut-cell", "--dut-view",
        "--bench-lib", "--bench-cell", "--bench-view",
        "--dut-hash", "--bench-hash", "--pdk-version", "--topology-hash",
        "--parameter-hash", "--solver-version",
        "--corner", "--identity-output", "--mos-output", "--simulation-dir",
    };
    for (const auto& key : required) {
        if (options[key].empty()) {
            error << "missing required option: " << key << '\n';
            return 64;
        }
    }

    OpSimulationRequest request;
    request.dut = {options["--dut-lib"], options["--dut-cell"],
                   options["--dut-view"], options["--dut-storage"], {}};
    request.bench = {options["--bench-lib"], options["--bench-cell"],
                     options["--bench-view"], options["--bench-storage"], {}};
    request.corner = options["--corner"];
    request.requested_identity = {options["--dut-hash"], options["--bench-hash"],
        options["--pdk-version"], options["--corner"],
        options["--topology-hash"], options["--parameter-hash"],
        options["--solver-version"]};
    request.identity_output = options["--identity-output"];
    request.mos_output = options["--mos-output"];
    request.resistor_output = options["--resistor-output"];
    request.simulation_directory = options["--simulation-dir"];

    const auto result = MaauOpSimulationProvider().Run(request, host);
    if (!result.ok) {
        error << "Maau operating-point provider failed: " << result.message << '\n';
        error << "simulation directory retained: "
              << std::filesystem::absolute(result.simulation_directory).lexically_normal()
              << '\n';
        return result.exit_code;
    }
    output << "operating-point TSV generated; simulation directory retained: "
           << std::filesystem::absolute(result.simulation_directory).lexically_normal()
           << '\n';
    return 0;
}

} // namespace st::maau
