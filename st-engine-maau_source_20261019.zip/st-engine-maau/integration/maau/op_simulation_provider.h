#pragma once

#include "topology_variant_adapter.h"
#include "st/OperatingPoint.h"

#include <filesystem>
#include <iosfwd>
#include <string>

namespace st::maau {

struct OpSimulationRequest {
    CellViewRef dut;
    CellViewRef bench;
    std::string corner;
    AnalysisIdentity requested_identity;
    std::filesystem::path identity_output;
    std::filesystem::path mos_output;
    std::filesystem::path resistor_output;
    std::filesystem::path simulation_directory;
};

struct OpSimulationResult {
    bool ok = false;
    int exit_code = 70;
    std::string message;
    std::filesystem::path simulation_directory;
};

// Public, injectable boundary for the private Maau Case/Bench API.  A site
// adapter implements these operations against the site's Maau runtime.
// maau_site_runtime.cc + server/site/maau_op.py provide the process-backed
// implementation using physical OA netlists, Simulator and signed raw PSF.
class OpSimulationHost {
public:
    virtual ~OpSimulationHost() = default;

    // Resolve the requested Bench before any Case mutation.  Return 0 when it
    // exists, 64 when the complete L/C/V names no real Bench, and another
    // non-zero value for site/configuration failures (normalized to 70).
    virtual int ValidateBench(const CellViewRef& bench,
                              std::string& message) = 0;

    virtual HostStatus RebindDutInTemporaryCase(
        const CellViewRef& dut,
        const CellViewRef& bench,
        const std::filesystem::path& simulationDirectory) = 0;
    virtual HostStatus PreserveBenchEnvironment(
        const CellViewRef& bench,
        const std::string& corner) = 0;
    virtual HostStatus RequestDcOpAndOppoint() = 0;

    // Returns 0 on success, 70 when Spectre cannot be started and 71 when it
    // runs but does not converge.  Other non-zero codes are normalized to 70.
    virtual int RunSpectre(const std::filesystem::path& simulationDirectory,
                           std::string& message) = 0;
    virtual HostStatus ExtractOperatingPoint(
        OperatingPointSnapshot& snapshot) = 0;
};

class MaauOpSimulationProvider {
public:
    OpSimulationResult Run(const OpSimulationRequest& request,
                           OpSimulationHost& host) const;
};

int RunMaauOpProviderCli(int argc,
                         char** argv,
                         OpSimulationHost& host,
                         std::ostream& output,
                         std::ostream& error);

} // namespace st::maau
