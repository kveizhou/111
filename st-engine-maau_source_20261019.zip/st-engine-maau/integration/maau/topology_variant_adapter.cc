#include "topology_variant_adapter.h"

namespace st::maau {

namespace {

bool applyFailure(const HostStatus& status, const std::string& stage, SnapshotResult& result)
{
    if (status.ok) return false;
    result.stage = stage;
    result.message = status.message;
    result.log_path = status.log_path;
    return true;
}

} // namespace

SnapshotResult TopologyVariantAdapter::BuildSnapshot(SnapshotSource& source) const
{
    SnapshotResult result;
    auto status = source.ReadCircuitDesignInfo(result.snapshot.source,
                                               result.snapshot.tech_name);
    if (applyFailure(status, "CircuitDesignInfo", result)) return result;

    status = source.ReadSchematicNetlist(result.snapshot.netlist);
    if (applyFailure(status, "schematic::Netlist", result)) return result;

    status = source.ReadTechCatalog(result.snapshot.catalog);
    if (applyFailure(status, "Tech", result)) return result;

    result.ok = true;
    result.stage = "complete";
    return result;
}

} // namespace st::maau
