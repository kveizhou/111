#pragma once

#include "op_simulation_provider.h"

#include <memory>

namespace st::maau {

// Production boundary implemented by a separately linked site library.  The
// public repository deliberately does not guess private Maau API names.
std::unique_ptr<OpSimulationHost> CreateSiteOpSimulationHost();

} // namespace st::maau
