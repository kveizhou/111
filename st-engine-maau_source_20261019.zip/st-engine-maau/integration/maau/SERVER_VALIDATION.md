# 服务器真实 Maau / PDK / Virtuoso 验证清单

## 当前只需做什么

把 `st-engine-maau` 合入服务器上的 Maau 临时开发分支，补齐 `SnapshotSource` 和 `MaterializationHost` 的真实适配，然后严格按 B0～B5 顺序执行。每一步返回：实际命令、退出码、完整日志路径、目标 lib/cell/view、OA check/save 结果、重新生成的网表和结构差异摘要。

在这些证据返回以前，本文件中所有真实 Virtuoso 项均为 `planned_not_run`。

## 一、合入前必须确认的工程输入

1. 当前操作设计的 schematic/config/testbench 的 lib、cell、view；
2. Maau `CircuitDesignInfo` 与当前调优设计之间的绑定方式；
3. `schematic::Netlist` 的层级路径和实例稳定 ID；
4. `Tech`、CDF、symbol 或 subckt `termOrder` 给出的真实端子顺序；
5. MOS 真实 master、极性、端子角色、可靠性（maxAbsVgs/Vds/Vgb）、Bulk/Well 规则、电压域、W/L/nf/m 等参数语义与约束（异型 Cascode 为同极性、不同 master，由工具从这些权威数据动态筛选）；
6. 可用电阻 master、2/3/多端端子、阻值参数或几何反解接口、合法范围，以及当前几何/Corner/温度的额定电压、功耗或电流；
7. NMOS/PMOS Bulk/Well 规则以及哪些 master 允许独立阱源体连接；
8. 导入 Case 的真实 Bench、VHIGH/VLOW、Corner、主支路电流允许偏差和新增 VBIAS 电流上限；
9. 通用 N/P 互补自给电模板的真实 PDK 器件及 CDF 参数；不复用原 Bias，不接受外部 IREF；
10. `CircuitCopyer`、`SkillExecutor`、`NetlistCreator` 的真实构建 target、头文件和错误返回格式；
11. `$SKILLPATH/init.il` 中 `parse_json_file` / `dump_json_file` 的实际 JSON 对象表示；
12. 当前 Virtuoso 版本可用的 CDF callback、schematic wire/pin 和 check/save API。

任何一项无法确认时必须返回 `blocked` 和缺失项，不能猜测端子顺序或 PDK 参数。

## 二、正式适配关系

```text
TopologyVariantAdapter::BuildSnapshot
  CircuitDesignInfo + schematic::Netlist + Tech/CDF

TopologyVariantMaterializer::Generate
  CircuitCopyer(source -> staging, full hierarchy clone map)
  -> WritePlanJson
  -> SkillExecutor(SkillTaskConfig)
  -> MaauTopologyVariantMaterializeData(input)
  -> NetlistCreator::Run(source) -> VerifySourceUnchanged
  -> NetlistCreator::Run(staging) -> VerifyVariantRoundTrip
  -> PublishCircuits(staging -> final)
  -> ready_for_sizing
```

建议使用现有 `SkillExecutor` 的 `json_data`：它写出 `data.json`，由 `$SKILLPATH/init.il` 的 `parse_json_file` 得到 `input`，命令加载 `topology_variant.il` 后调用 `MaauTopologyVariantMaterializeData(input)`；`GetResult()` 读取结构化 `output.json`。

## 三、公共执行规则

- 每次实验都先创建新的staging cellview，源设计必须只读；只有源图不变和staging round-trip都通过后，才原子发布最终目标。
- 每次都从同一基线重新复制，不能在上一次实验结果上叠加，除非专门验证 Change Set 多次修改。
- 先保存基线网表和 hash，再运行 SKILL；失败时保留计划、replay log 和未保存目标用于排查。
- 宿主`MaauTopologyCheckAndSave`必须解析当前Virtuoso版本的schematic check错误结果，只在无错时保存；随后必须用`NetlistCreator`分别回读源图和staging。
- 重新网表必须与引擎期望 Variant 比较实例、master、按真实 termOrder 的连接、port 和要求参数。
- “原理图能打开”不是通过；“结构正确”也不表示性能提升。
- 本需求的首轮目标是证明结构能可靠变换和显示，不把性能是否提高作为结构功能验收条件。

## 四、实验顺序

### B0：无修改 round-trip

目的：先证明复制、打开、CDF 不变写回、check/save、重新网表化不会破坏原设计。

通过条件：

- 源设计 hash 不变；
- 目标图可打开且 check/save 成功；
- 重新网表的实例、master、端口连接和原始要求参数与基线一致；
- 不出现 CDF 参数恢复默认值、层级丢失或 config 指向源图的问题。

### B1：MOS Source 串联电阻最小闭环

选择一个经人工确认允许修改、且 gate 不是关键动态控制的 MOS。原 MOS 保留，
在其电气 Source 路径串联 PDK 电阻。阻值取值优先级固定为：

```text
1. 用户在操作文件中显式填写的 resistor.value；
2. Case 预置值；
3. PDK 有限正合法阻值区间的几何中点（再按网格量化）。
```

不从 DC 工作点反推阻值（旧的 `Rseed=(Vp-Vn)/Ip` 口径已废弃）。多端电阻的
substrate/well 使用 ResistorTemplate，不能复制 MOS Bulk。

通过条件：原 MOS 保留，Drain/Gate/Bulk 不变，Source 改接新增内部节点；
电阻跨接在内部节点与原 Source 网之间；附加端子正确；量化后的阻值与
回读网表一致；原 G/B 网络未误删或误接。

### B2：2 级同型 Stack

先使用 SharedGate / EffectiveLength：两级同 master、同极性、完整继承原尺寸，两 gate 都接原 G，N−1 个内部节点唯一，所有 Bulk 按 PDK 规则连接。

通过条件：业务数据仍是一个 `LogicalMosStack(N=2)`；OA/网表物化为恰好两个 MOS；外部 D/S 边界不变；没有 `W/N`；parameter group 正确。

### B3：同型 Cascode（自动 VBIAS 求解）

使用一个工作点明确、headroom 可行的 MOS。不搜索原电路 VBIAS，也不允许
用户手工填写偏置窗口/工作点：按极性生成自给电模板 `VBIAS_N_CASCODE_AUTO`
或 `VBIAS_P_CASCODE_AUTO`（无 IREF 外部参考端口），模板内部 MOS 由工具从
当前 PDK/Case 目录自动选择；偏置电压与模板器件参数由自动求解器经真实
Spectre 候选复验选出（基线 OP → 候选 OA 物化及父子 Cell 回读校验 →
候选 OP → MOS/电阻可靠性与 Case 电流门禁 → 排名）。

通过条件：控制管与新增管连接符合方案（NMOS 在 Drain 侧、PMOS 在 Source
侧、原 Gate 不变）；中间节点唯一；求解轨迹非空且选中结果写入
`analysis/resolved_parameters.json`；名义 DC 检查通过；Bulk 正确；
重新网表与期望一致。

### B4：同极性不同 master Cascode（自动 VBIAS 求解）

只从工具对真实 PDK 目录动态筛选出的同极性候选中选择实例（筛选条件：
真实 master 与原管不同、OA master 完整、D/G/S 及实际存在的 Bulk/附加端子角色齐全、可靠性与 Bulk 规则完整、电压域支持、
参数约束可解），例如同为 NMOS
的 SVT/LVT；候选以 inspect 生成的 `analysis/cross_flavor_candidates.json`
为准（被拒原因记录在 candidate_rejections），空则停止，不允许凭器件名
猜测。没有现成参考实例时标记为实验性，
不把"同极性"单独当作足够条件。VBIAS 同样走 B3 的 `_AUTO` 模板自动求解。

通过条件：新增 master、termOrder、尺寸参数、额外端子、电压可靠性和 Bulk
全部由 PDK 数据确认；N/P 混串和未通过动态筛选的组合必须被拒绝；自动求解
与名义 DC 检查口径同 B3。

### B5：100 级 Stack 压力测试

业务层只保存 `LogicalMosStack(N=100)`；验证 UI/数据库不创建 100 个普通逻辑对象。仅在临时仿真/OA 物化阶段展开 100 个真实 MOS 和 99 个内部节点。

通过条件：命名无冲突、耗时和计划大小有记录、展开数量准确、公共尺寸组没有变成 100 组完全独立 W/L；源设计无修改。

## 五、Bias 专项检查

每个 Cascode 操作都必须有独立记录，落盘位置为
`analysis/resolved_parameters.json`：模板 ID（`VBIAS_N_CASCODE_AUTO` /
`VBIAS_P_CASCODE_AUTO`）、当前 PDK 自动选定的真实 Mirror/Replica MOS、
各 CDF 参数、输出偏置电压、求解增加的 IQ（模板支路电流计入 IQ 静态电流
口径）以及逐 Corner 复验结果。

每个 Cascode 操作生成**独立的** VBIAS 封装 CellView，多个操作之间不共享
模板、器件或输出网。模板为自给电结构，直接接父层声明的
`--vbias-vhigh-net/--vbias-vlow-net` 轨网，**没有 IREF 外部参考端口**；
不允许 `ReuseExistingNet` 或 `ExternalPort` 路径，也不允许任何参考电流
直接连接 MOS gate。

## 六、每一步必须返回的产物

建议每个实验使用独立目录：

```text
result/topology_variant_<case_id>/
  command.txt
  exit_code.txt
  input_snapshot.json
  device_catalog.json
  plan.json
  skill.il
  MaauTopologyVariantMaterialize.log
  output.json
  source_before.scs
  source_after.scs
  staging_roundtrip.scs
  publish_map.json
  expected_variant.scs
  roundtrip_variant.scs
  verification.json
  summary.md
```

`summary.md` 至少写明：状态 `pass/failed/blocked/planned_not_run`、源/目标 cellview、选中实例、变换类型、Bias 来源、增删改实例、端口和参数差异、check/save、round-trip、源图 hash 是否不变。

## 七、最终判定

只有同时满足以下条件才把单个实验标为结构变换 `pass`：

1. 命令实际执行且退出码为 0；
2. SKILL 返回结构化成功，日志无未处理错误；
3. 目标 cellview check/save 成功；
4. 源 cellview 与基线 hash 不变；
5. 目标重新网表化成功；
6. `VerifyVariantRoundTrip` 通过；
7. 验证报告四状态齐全：`structural_ready=true`、
   `nominal_dc_ready=true`、`parameters_quantized=true`，且
   `ready_for_sizing=true`；
8. 涉及 FixedBias Cascode 时，`analysis/resolved_parameters.json` 有该
   操作的求解结果、`analysis/solver_trace.jsonl` 非空；
9. 返回所有原始证据文件。

补充口径：

- 会话产物须包含 `analysis/` 全套（pdk_catalog.json、baseline_op.json、
  candidates/、solver_trace.jsonl、resolved_parameters.json、variant_op/），
  缺失即证据不全。
- 配置了 PVT Corner 时，任一 Corner 复验失败都必须阻塞发布：
  `pvt_ready=false`、`ready_for_sizing=false`，并在
  `resolved_parameters.json` 和 `validation.txt` 中记录失败 Corner 与约束。
- DC/OP smoke 可以用来发现悬空、错误 Bias 或不收敛，但性能提升不是本轮
  结构功能的通过条件。Sizing 和完整仿真由后续流程启动，不应由"生成电路"
  按钮自动触发。
