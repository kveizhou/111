# Maau 结构变换接入边界

**本目录为可选历史集成。** 用户最新确认本项目独立编译运行，KimiCode 只作参考。
当前产品使用 `server/site/standalone.py` 输入原始 PDK 根目录并直接调用 Cadence/OCEAN/Spectre；
见 `docs/standalone-pdk-server-validation.md`。下文要求 Maau 运行时的描述不适用于默认产品入口。

本目录包含公开接入契约，以及依据现有 KimiCode 声明编写的具体 Maau 原生运行时。
优先使用 [KIMICODE_SITE_INTEGRATION.md](KIMICODE_SITE_INTEGRATION.md) 的进程接入：
实际 Case 导出、按导入工艺自动发现配置、OA/CDF 扫描适配、OA 网表生成、Spectre 执行和有符号 PSF 提取均已有代码。
原生运行时需要完整 Maau 环境编译/链接；本地参考树私有头文件缺损，当前不能称该运行时已真实链接或仿真通过。
下面的接口表与外部 factory 是另一种嵌入式接法，保留兼容用途：

| 本模块接口 | Maau 现有能力 | 用途 |
|---|---|---|
| `SnapshotSource::ReadCircuitDesignInfo` | `CircuitDesignInfo` | 取得当前操作的 lib/cell/view、config 和工程身份 |
| `SnapshotSource::ReadSchematicNetlist` | `schematic::Netlist` | 取得层级实例、网络和原始参数快照 |
| `SnapshotSource::ReadTechCatalog` | `Tech` + CDF/termOrder 采集 | 建立 master、端子语义、参数映射和工艺限制 |
| `MaterializationHost::CopyCircuits` | `CircuitCopyer` | 按完整层级clone map复制到staging，源图只读 |
| `MaterializationHost::ExecuteSkill` | `SkillExecutor::SkillTaskConfig`、`SkillExecutor::operator()`、`GetResult()` | 加载 `skill/topology_variant.il` 并执行 OA 计划 |
| `MaterializationHost::RegenerateNetlist` | `NetlistCreator::Run()` | 从目标 cellview 重新生成网表并解析 |
| `MaterializationHost::PublishCircuits` | 服务器原子复制/重命名适配 | 源图和staging验证通过后才发布最终派生设计 |

## 真实 Maau/Spectre OP Host

`ST_BUILD_MAAU_COMPAT=ON` 只编译公开契约和假 Host 单测。
具体运行时通过 `scripts/build_maau_runtime.sh` 构建，`server/site/maau_case.py`
恢复会话上下文后选择 `server/site/maau_op.py` 为 Provider。
如果选择旧嵌入式接法，现场私有库须实现 `OpSimulationHost` 的六个操作，并导出：

```cpp
extern "C" st::maau::OpSimulationHost*
st_maau_create_site_op_simulation_host();
```

然后显式构建：

```bash
ST_BUILD_MAAU_SITE_PROVIDER=ON \
ST_MAAU_SITE_HOST_LIBRARY=/absolute/path/to/libst_maau_site_host.so \
./scripts/build.sh
```

只有完成真实库链接的构建才会生成
`build/bin/st_maau_op_provider.site-linked`。`setup_backend.csh` 仅在该标记存在时
自动选择工程内 Provider；也可显式把 `ST_OP_PROVIDER_BIN` 指向另一个经验证的
绝对可执行路径。未链接私有 Maau API 时会直接拒绝，不会再伪造一个固定返回
70 的“生产”程序。

含新增电阻的候选或最终变体会向 Provider 传入 `--resistor-output`。
站点 Host 的 `ExtractOperatingPoint` 必须同时取出电阻两端实际电位、支路电流，
以及当前 PDK 对该 master、实例几何、Corner/温度的额定端电压和允许功耗或电流。
标准 TSV 表头为
`instance master geometry vpos vneg current max_voltage max_power max_current rating_source`
（Tab 分隔）；缺额定值、来源、实例 OP 或层级匹配失败会阻止候选及最终发布。
`max_power` 或 `max_current` 可为 0 表示该类额定值未提供，但两者不得同时为 0。
不可把 MOS 的 VGS/VDS/VGB 限值或 `I*R` 估算当成电阻应力证明。

最终变体的调用顺序为（配置电气检查时，staging 还须执行名义 OP 和各 PVT Corner）：

```text
BuildSnapshot
  -> CircuitCopyer(source -> staging，含所有被改层级)
  -> WritePlanJson
  -> SkillExecutor
  -> NominalDcCheck + ConfiguredPvtChecks
  -> NetlistCreator::Run(source) + VerifySourceUnchanged
  -> NetlistCreator::Run(staging) + VerifyVariantRoundTrip
  -> PublishCircuits(staging -> final)
  -> ready_for_sizing
```

自动 VBIAS 的每个候选另走 `clone → materialize → 父图及全部子 Cell 回读校验 → run-op`；回读不符时不启动该候选仿真。每次生成分配新的候选 OA 名称和证据目录。真实 `run-op` 依赖上面的站点 Host，不能通过兼容测试构建替代。

任何阶段失败都返回阶段、日志和已有产物路径，`ready_for_sizing=false`。SKILL失败只可留下staging调试副本，不可发布为最终变体。本层不会启动 Sizing，也不会覆盖原 schematic/config/netlist。

`SkillExecutor` 可使用两种入口：直接将 plan JSON 作为 `json_data` 后调用 `MaauTopologyVariantMaterializeData(input)`，或把 JSON 写成文件后调用 `MaauTopologyVariantMaterialize(planFile)`。推荐前者，以复用现有 `parse_json_file` / `dump_json_file` 基础设施。

服务器合入前必须补齐并验证以下 PDK 相关实现：`MaauTopologyApplyCdfParameters`、`MaauTopologyCreatePort`、`MaauTopologyCheckAndSave`，symbol/subckt的完terminalOrder，局部布局模板坐标和导线，层级clone/publish map，config/testbench重绑定。独立环境只能验证C++契约，不能把静态脚本检查当成Virtuoso已成功执行。
