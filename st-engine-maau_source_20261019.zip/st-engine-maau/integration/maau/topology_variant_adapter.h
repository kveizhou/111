#pragma once

#include "st/Materialization.h"
#include "st/OaPlan.h"
#include "st/Netlist.h"

#include <string>

namespace st::maau {

using HostStatus = ::st::HostStatus;

struct DesignSnapshot {
    CellViewRef source;
    std::string tech_name;
    Netlist netlist;
    DeviceCatalog catalog;
};

struct SnapshotResult {
    bool ok = false;
    std::string stage;
    std::string message;
    std::string log_path;
    DesignSnapshot snapshot;
};

// 正式 Maau 仓库用 CircuitDesignInfo、schematic::Netlist 和 Tech 分别实现
// 这三个读取函数；独立核心不包含或伪造 Maau 私有类型。
class SnapshotSource {
public:
    virtual ~SnapshotSource() = default;
    virtual HostStatus ReadCircuitDesignInfo(CellViewRef& design,
                                             std::string& techName) = 0;
    virtual HostStatus ReadSchematicNetlist(Netlist& netlist) = 0;
    virtual HostStatus ReadTechCatalog(DeviceCatalog& catalog) = 0;
};

class TopologyVariantAdapter {
public:
    SnapshotResult BuildSnapshot(SnapshotSource& source) const;
};

} // namespace st::maau
