// Concrete Maau entry points verified against the supplied KimiCode sources.
// Build inside the complete Maau environment; no replacement API declarations.
#include "common/core/ops/netlist_creator/netlist_creator.h"
#include "common/core/ops/simulator/simulator.h"
#include "common/projectmanager/project_config.h"
#include "platform/psf/dchelper.h"

#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using Options = std::map<std::string, std::string>;
std::string Required(const Options& options, const std::string& key) {
    const auto found = options.find(key);
    if (found == options.end() || found->second.empty())
        throw std::runtime_error("missing --" + key);
    return found->second;
}
std::string Quote(const std::string& value) {
    std::string out = "\"";
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c < 32) {
            const char* hex = "0123456789abcdef";
            out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15];
        } else out += static_cast<char>(c);
    }
    return out + "\"";
}
std::string Design(const maau::DesignStruct& d) {
    return "{\"lib\":" + Quote(d.lib) + ",\"cell\":" + Quote(d.cell) +
           ",\"view\":" + Quote(d.view) + ",\"sch_view\":" + Quote(d.sch_view) + "}";
}
std::string Benches(std::vector<maau::DesignStruct> designs, const maau::DesignStruct& single) {
    if (!single.lib.empty() && !single.cell.empty() && !single.view.empty()) {
        bool found = false;
        for (const auto& design : designs) if (design == single) found = true;
        if (!found) designs.push_back(single);
    }
    std::string out = "[";
    bool first = true;
    for (const auto& design : designs) {
        if (design.lib.empty() || design.cell.empty() || design.view.empty()) continue;
        if (!first) out += ',';
        first = false; out += Design(design);
    }
    return out + "]";
}
void Write(const std::string& path, const std::string& data) {
    if (std::filesystem::exists(path)) throw std::runtime_error("output already exists: " + path);
    std::ofstream stream(path);
    stream << data << '\n'; stream.close();
    if (!stream) throw std::runtime_error("cannot write " + path);
}
std::string Read(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("cannot read " + path.string());
    return {std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()};
}
} // namespace

int main(int argc, char** argv) {
    try {
        if (argc < 2 || (argc - 2) % 2) throw std::runtime_error("command followed by --key value pairs required");
        const std::string command = argv[1];
        Options options;
        for (int i = 2; i < argc; i += 2) {
            std::string key = argv[i];
            if (key.rfind("--", 0) != 0 || !options.emplace(key.substr(2), argv[i + 1]).second)
                throw std::runtime_error("invalid or duplicate option " + key);
        }
        if (command == "export-case") {
            maau::CircuitDesignConfig config;
            config.LoadFromFile(Required(options, "case"));
            const auto json = "{\"source_dut\":" + Design(config.GetSourceDutDesign()) +
                ",\"target_dut\":" + Design(config.GetTargetDutDesign()) +
                ",\"source_benches\":" + Benches(config.GetSourceTbList(), config.GetSourceTbDesign()) +
                ",\"target_benches\":" + Benches(config.GetTargetTbList(), config.GetTargetTbDesign()) +
                ",\"source_cds_path\":" + Quote(config.GetSourceCdsPath()) +
                ",\"target_cds_path\":" + Quote(config.GetTargetCdsPath()) +
                ",\"source_tech_name\":" + Quote(config.GetSourceTechName()) +
                ",\"target_tech_name\":" + Quote(config.GetTargetTechName()) +
                ",\"raw_case\":" + config.ToJsonString() + "}";
            Write(Required(options, "output"), json);
        } else if (command == "bench-info") {
            maau::TestBenchManager manager(Required(options, "work-dir"), Required(options, "cds-path"));
            const auto& bench = manager.GetTestBenchInfo(Required(options, "lib"),
                Required(options, "cell"), Required(options, "view"));
            maau::platform::BaseData data;
            bench.ToBaseData(data);
            Write(Required(options, "output"), data.toStyledString());
        } else if (command == "netlist") {
            maau::circuit::ops::NetlistBuilder::Input input;
            input.work_dir = Required(options, "work-dir");
            input.cds_path = Required(options, "cds-path");
            input.lib = Required(options, "lib"); input.cell = Required(options, "cell");
            input.view = Required(options, "view"); input.output_file = Required(options, "output");
            const auto mode = Required(options, "mode");
            if (mode != "ocean" && mode != "fast") throw std::runtime_error("mode must be ocean or fast");
            std::string origin = std::filesystem::path(input.output_file).parent_path().string();
            std::string testName;
            if (mode == "ocean") {
                maau::circuit::ops::OceanNetlistCreator::Args args;
                args.work_dir = input.work_dir; args.cds_path = input.cds_path;
                args.lib = input.lib; args.cell = input.cell; args.view = input.view;
                args.output_file = input.output_file; args.token = {};
                const auto result = maau::circuit::ops::OceanNetlistCreator{}(args);
                if (!result.s.Ok()) throw std::runtime_error(result.s.ToString());
                testName = result.dc_test_name;
                const auto exported = Read(input.output_file);
                std::set<std::string> origins;
                for (const auto& item : std::filesystem::recursive_directory_iterator(result.ocean_log_dir)) {
                    if (item.is_regular_file() && item.path().filename() == "input.scs" && Read(item.path()) == exported)
                        origins.insert(item.path().parent_path().string());
                }
                if (origins.size() != 1) throw std::runtime_error("Ocean input.scs origin missing or ambiguous");
                origin = *origins.begin();
            } else {
                input.mode = maau::circuit::ops::NetlistBuilder::Mode::fast;
                const auto status = maau::circuit::ops::NetlistBuilder{}(input);
                if (!status.Ok()) throw std::runtime_error(status.ToString());
                // SimpleNetlistCreator::Simple exports here before copying to output_file.
                const auto source = std::filesystem::path(input.work_dir) / input.cell /
                    "spectre" / input.view / "netlist" / "input.scs";
                if (Read(source) != Read(input.output_file))
                    throw std::runtime_error("fast input.scs origin does not match the OA export");
                origin = source.parent_path().string();
            }
            if (!std::filesystem::is_regular_file(input.output_file) ||
                std::filesystem::file_size(input.output_file) == 0)
                throw std::runtime_error("Maau did not export a nonempty OA netlist");
            Write(input.output_file + ".origin.json", "{\"working_directory\":" + Quote(origin) +
                ",\"dc_test_name\":" + Quote(testName) + "}");
        } else if (command == "simulate") {
            maau::common::Simulator::Input input;
            input.scs_path = Required(options, "netlist");
            input.psf_dir = Required(options, "psf-dir");
            input.psf_log_path = Required(options, "log");
            input.simulator_type = maau::common::Simulator::Input::SPECTRE;
            const auto status = maau::common::Simulator{}(input);
            if (!status.Ok()) throw std::runtime_error(status.ToString());
            if (!std::filesystem::is_regular_file(std::filesystem::path(input.psf_dir) / "dcOp.dc")) {
                std::cerr << "Spectre returned without dcOp.dc\n"; return 71;
            }
        } else if (command == "read-psf") {
            // Read both node voltages/currents and device OP data. Preserve signs.
            std::map<std::string, double> values;
            for (const auto& name : {"dcOp.dc", "dcOpInfo.info"}) {
                const auto file = std::filesystem::path(Required(options, "psf-dir")) / name;
                if (!std::filesystem::is_regular_file(file)) throw std::runtime_error("missing raw PSF: " + file.string());
                maau::platform::DCHelper helper(file.string());
                for (const auto& item : helper.ReadRawPsfData()) {
                    if (!std::isfinite(item.second) || item.first.find_first_of("\t\r\n") != std::string::npos)
                        throw std::runtime_error("invalid raw PSF value or name");
                    const auto inserted = values.emplace(item.first, item.second);
                    if (!inserted.second && inserted.first->second != item.second)
                        throw std::runtime_error("conflicting PSF signal: " + item.first);
                }
            }
            if (values.empty()) throw std::runtime_error("empty raw PSF");
            const auto path = Required(options, "output");
            if (std::filesystem::exists(path)) throw std::runtime_error("output already exists: " + path);
            std::ofstream stream(path); stream << "signal\tvalue\n" << std::setprecision(17);
            for (const auto& item : values) stream << item.first << '\t' << item.second << '\n';
            stream.close(); if (!stream) throw std::runtime_error("cannot write raw PSF TSV");
        } else throw std::runtime_error("unknown command: " + command);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 70;
    }
}
