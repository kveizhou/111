#include "tech_catalog_provider.h"

namespace st::maau {

TechCatalogScanResult TechCatalogProvider::ScanCurrentDut(
    const CellViewRef& dut, CurrentDutTechSource& source) const
{
    TechCatalogScanResult result;
    if (dut.library.empty() || dut.cell.empty() || dut.view.empty()) {
        result.message = "current DUT L/C/V is incomplete";
        return result;
    }

    auto status = source.ReadCurrentDutTechCatalog(
        dut, result.catalog, result.pdk_name, result.pdk_version);
    if (!status.ok) {
        result.message = status.message;
        result.log_path = status.log_path;
        return result;
    }
    if (result.pdk_name.empty() || result.catalog.Descriptors().empty()) {
        result.message = "current DUT PDK identity or catalog is empty";
        return result;
    }
    for (const auto& entry : result.catalog.Descriptors()) {
        const auto& descriptor = entry.second;
        if (!source.IsVerifiedPdkDeviceCell(dut, descriptor)) {
            result.message = "catalog record is not a verified PDK primitive: " +
                descriptor.master;
            return result;
        }
        if (descriptor.pdk_name != result.pdk_name ||
            descriptor.pdk_version != result.pdk_version) {
            result.message = "catalog record does not belong to the current DUT PDK: " +
                descriptor.master;
            return result;
        }
    }
    result.ok = true;
    return result;
}

} // namespace st::maau
