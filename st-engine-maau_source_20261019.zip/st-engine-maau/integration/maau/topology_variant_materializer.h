#pragma once

#include "topology_variant_adapter.h"
#include "st/Materialization.h"

namespace st::maau {

using MaterializationStage = ::st::MaterializationStage;
using GenerationRequest = ::st::GenerationRequest;
using GenerationResult = ::st::GenerationResult;
using MaterializationHost = ::st::MaterializationHost;
using TopologyVariantMaterializer = ::st::TopologyVariantMaterializer;

} // namespace st::maau
