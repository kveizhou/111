#pragma once

#include "topology_variant_adapter.h"

#include <string>

namespace st::maau {

// The public repository deliberately stops at this boundary.  The real Maau
// integration implements it with the current DUT's CircuitDesignInfo/Tech
// object; no private Maau type or method is invented here.
class CurrentDutTechSource {
public:
    virtual ~CurrentDutTechSource() = default;
    virtual HostStatus ReadCurrentDutTechCatalog(
        const CellViewRef& dut,
        DeviceCatalog& catalog,
        std::string& pdkName,
        std::string& pdkVersion) = 0;

    // The host adapter must positively prove that this exact catalog record is
    // a primitive device cell owned by the current DUT's PDK.  Matching only a
    // process name or tech attachment is insufficient for user/generated libs.
    virtual bool IsVerifiedPdkDeviceCell(
        const CellViewRef& dut,
        const DeviceDescriptor& descriptor) const = 0;
};

struct TechCatalogScanResult {
    bool ok = false;
    std::string message;
    std::string log_path;
    std::string pdk_name;
    std::string pdk_version;
    DeviceCatalog catalog;
};

class TechCatalogProvider {
public:
    TechCatalogScanResult ScanCurrentDut(
        const CellViewRef& dut,
        CurrentDutTechSource& source) const;
};

} // namespace st::maau
