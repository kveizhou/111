#include "topology_variant_materializer.h"

// Compatibility translation unit. The host-neutral implementation lives in
// src/Materialization.cpp; the st::maau names are aliases declared in the header.
