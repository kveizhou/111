# 已有 Maau 源码的实际接入（2026-10-07）

**历史可选接入，已撤回为产品必需路径。** 用户确认本项目独立编译运行，KimiCode 仅供参考。
当前产品入口是 `server/site/standalone.py`，文档为 `docs/standalone-pdk-server-validation.md`。
下文的 Maau Case、Registry、原生运行时链接要求只适用于主动选择该旧接入方式，不是当前需求或服务器验证的前置条件。

这条接入路径已经写出具体实现，不再要求先另写一个外部 Host factory。
原有 OA 读取、克隆、封装、布线、回读、发布及打开后端继续复用。
用户报告旧 Capless 命令已经跑通；本轮没有重新取得那些服务器日志。

## 实现及源码依据

| 实现 | 依据 `/Users/zkw/Desktop/KimiCode/src/` 中的实际声明/调用 |
|---|---|
| `server/site/maau_config.py` | `common/core/tech/details/new_techdata_accessor.cc` 的 v2 JSON schema、`techdata_accessor.h` 的 L/FW/FIN/FINGERS/MULTI；器件 N/P 来自 `sub_device_type` |
| `server/skill/site_metadata_adapter.il` | 配置定义类型及 master 成员；现场 OA 库实际路径、tech attachment、symbol 端子和真实 CDF 验证归属与参数映射；端序取真实 `simInfo.spectre.termOrder` 并对照 symbol |
| `server/skill/device_bindings.il` | 沿用现有 Virtuoso 批量入口，只读遍历实际 DUT 层级，输出每个使用中器件的 OA library/cell/view 及 CDF Spectre 端序；不是用户可选 MOS 清单 |
| `server/site/maau_case.py` | 导入原生 Case 导出数据，按唯一 Bench 或显式 L/C/V 选择；从 Case 的 tech name 与 `TECH_ROOT_PATH` 自动找本次工艺配置；与显式 DUT/Bench 冲突则拒绝 |
| `integration/maau/maau_site_runtime.cc` | `CircuitDesignConfig::LoadFromFile`、DUT/Bench/工艺 getters、`ToJsonString`；`TestBenchManager::GetTestBenchInfo` / `TestBench::ToBaseData`；`OceanNetlistCreator`、`NetlistBuilder`、`Simulator`、`DCHelper::ReadRawPsfData` |
| `server/site/maau_op.py` | 隔离导出实际 OA DUT/Bench，严格校验唯一 DUT 和端口顺序，保留 Bench 源与参数；只执行声明的 OP Corner；按完整 PSF 名称取有符号电位/电流与器件 OP |

CDF `constraint` 数组保留为离散允许集合，不把两个端点当成任意连续区间。
单位不明、缺少器件身份、Bulk/Well、电压域或可靠性规则时明确拒绝相应候选。
`lut_info.max_vol` 没有可靠性额定值的证明，不能填入 VGS/VDS/VGB 门禁。
FinFET 的 FIN 不当成米制 W。当前解析器支持 Maau v2 配置；遇到 v1 或未知 schema 会报错，须依据实际文件处理。
平面工艺的 `FW` 保留为单指宽度，`W` 单独保留为总宽度；两者不能互换。

## 本地证据与现场边界

- 普通 C++ 和兼容 Host 构建已通过；完整测试含 20 个 C++ 测试程序、2 个 demo、CLI help、server backend contract、16 项 shell 语法检查及 18 项新增配置/OP 测试。
- 新增 OP 流程测试使用进程契约 fixture，覆盖实际导出文本的替换、层级端口映射、符号保持、几何/Corner/温度额定值及证据输出；它不是一次 Spectre 测量。
- 原生 `maau_site_runtime.cc` 尚未在完整 Maau 工程编译/链接。本地参考树的 `dchelper.h/.cc` 等私有依赖是零字节，部分头文件包含转写缺损，不能用替代声明冒充真实编译。
- 本地使用 `scripts/build.sh` / `scripts/test.sh` 验证；本机没有 CMake，CMake 配置路径未验证。现场 Python 需 3.8 或更高版本。
- 现场 SKILL、OA、真实器件映射、原始 PSF 和实际 PVT 待服务器验证；如果实际配置或原生 API 有差异，需要根据该原始数据修正，并再次回归。
- 日志：`docs/validation/2026-10-07/site-build.log`、`site-tests.log`。

## 构建真实原生接口

使用完整 Maau 工程现有的编译 include/define 和链接库，保持其编译环境。
新增 `scripts/build_maau_runtime.sh` 接受两个参数文件，每行一个真实编译/链接参数，不通过 shell eval 执行字符串。

```csh
setenv ST_MAAU_SOURCE_DIR /absolute/path/to/complete/maau
setenv ST_MAAU_COMPILE_ARGS_FILE /absolute/path/to/maau_compile_args.txt
setenv ST_MAAU_LINK_ARGS_FILE /absolute/path/to/maau_link_args.txt
./scripts/build_maau_runtime.sh
```

这三个路径需要现场完整工程/构建产物；上述为参数形式，不是已经验证的服务器路径。
成功才产生 `build/bin/st_maau_runtime.site-linked`，现有 `setup_backend.csh` 可自动选用该运行时和 Python OP Provider。
也可以将 `maau_site_runtime.cc` 加入完整 Maau 现有构建，链接对应 projectmanager、netlist、simulator、PSF 及其依赖。
旧 `ST_MAAU_SITE_HOST_LIBRARY` 接法仍可使用，不是这条具体实现的前置开发任务。

## 每个实际 Case 的输入

1. 实际 Maau Case 文件、PDK 根目录及 `TECH_ROOT_PATH` / `tech_cfg_v2.0.json`；Case 的工艺和真实 OA 库路径必须对应。
2. Case 确定的 Bench、名义/验收 Corner、温度及模型 sections；多源/目标 DUT 或多个 Bench 时显式选择。
3. Case 的 VHIGH/VLOW 轨网、两项已约定的电流上限，及明确的电源电流信号/正负号；整机 IQ 是否扣除负载仍待用户确认，不能把总电源电流直接称为 IQ。
4. 真实 PDK 给出的 VGS/VDS/VGB、Bulk/Well、电压域、电阻几何/温度额定值和来源。已有配置没有的字段需要从实际 PDK 材料补成数据；不能自动制造数值。

Case 规则 JSON 的字段为 `design_side`（source/target）、`nominal_corner`、`pvt_corners`、
`vbias_vhigh_net`、`vbias_vlow_net`、`max_branch_current_error`、`max_vbias_current`、
`source_subckt`（若真实 netlist 名称与 Cell 不同）、`bench_test_name`（ADE 时）、
`original_model_files`、`op_corners` 和 `supply_current_signals`。
`op_corners[corner]` 包含实际 `temperature`、`models`（model_file/section_name）与 `variables`。
电源项为 `{signal: 完整PSF名称, sign: 1或-1}`。这些电气绑定不会按 VDD/IQ 等名字猜。

PDK 规则 JSON 包含 `tech_name`、`source`、`devices`；器件规则支持
`maxAbsVgs/maxAbsVds/maxAbsVgb`、`bulkRule`、`voltageDomains`、特殊端子名称的 `terminalRoles`、
真实 `dc_signals` 和 `resistor_ratings`。每项电阻额定值必须声明 `corner`、
`temperature_min/max`、`geometry`（实际 Spectre 参数的 min/max）、`max_voltage`，
以及 `max_power` 或 `max_current`，并附 `source`。匹配缺失或多义均不能通过。

## 导入入口与后续命令

原 `prepare_session.sh` 创建隔离 `cds.lib` 的步骤继续使用。
将旧 `st_circuit_tool inspect` 的实际后端、隔离 `cds.lib`、work-dir、variant 与 skill 参数保留，
使用下面入口自动合并导入 Case 的 DUT/Bench/工艺。隔离 `cds.lib` 必须 INCLUDE Case 的原始 registry。

```text
python3 server/site/maau_case.py inspect
  --case REAL_CASE_JSON
  --case-rules CONFIRMED_CASE_RULES_JSON
  --pdk-rules ACTUAL_PDK_RULES_JSON
  --runtime ABSOLUTE_ST_MAAU_RUNTIME
  --backend ABSOLUTE_EXISTING_OA_BACKEND
  --cds-lib PREPARED_ISOLATED_CDS_LIB
  --work-dir NEW_WORK_DIR
  --variant-lib DERIVED_LIBRARY
  --variant-cell NEW_VARIANT_CELL
  --variant-id NEW_VARIANT_ID
  --skill ABSOLUTE_STANDALONE_SKILL
```

这是参数清单，现场使用一整条命令。Case 工艺配置优先由 `TECH_ROOT_PATH/<tech name>/tech_cfg_v2.0.json`
发现，也可显式 `--tech-config`；轨网/两项电流限值来自确认后的 Case 数据。
导入产物保存于 `analysis/imported_case/`。后续 `confirm/list/generate/open` 等由同一入口
执行，例如 `python3 server/site/maau_case.py generate --session NEW_WORK_DIR`，它恢复该会话的实际 Provider 上下文。
直接调用原 CLI 时，需设置相同的 `ST_SITE_CASE_CONTEXT`、`ST_SITE_CASE_RULES`、
`ST_SITE_TECH_METADATA`、`ST_MAAU_RUNTIME_BIN`、`ST_PDK_TECH_ADAPTER`、`ST_OP_PROVIDER_BIN`
及 `ST_SITE_INPUTS_MANIFEST=该会话/analysis/imported_case/provider_inputs.json`。
导入时固定 Case、规则、工艺 metadata、adapter、原生 runtime 和模型文件的 SHA256；
后续包装入口及实际 SKILL 后端在使用缓存之前校验。条件改动需要创建新会话。
校验同时检查当前环境中的输入路径与固定路径相同，不能保留旧 manifest 而换用另一份规则。

## 实际 OP 的检查顺序

1. 校验固定的现场输入及本轮 PDK catalog 版本、类型、master/model 映射与 Case/Corner。扫描全目录可以包含多个 OA master 共用一个模型。
2. 对 ADE Bench 读取真实 metadata；当前通用 OP 路径要求一个启用的测试，且 Ocean 导出的 DC test 对应它。复杂 sweep/Monte Carlo 不隐式挑一个条件。
3. 导出实际 Bench 与 DUT，记录原网表 SHA256 和原始输出目录，将相对 include 解析为原文件位置。
4. 比较原 Bench 电气条件摘要（忽略时间戳注释）；在 DUT 替换前应用本 Corner 的温度/变量/模型 sections，并单独保存该 Corner 的有效 Bench 摘要。一个模型文件的多个 sections 全部保留。
5. 替换唯一 DUT，校验端口名称/顺序和共享子电路冲突；只接入实际 OA 导出的定义，root/外层 wrapper 参数覆盖按父层作用域求值。
6. 使用只读 `device-bindings` 取得实际使用中的 OA master/CDF Spectre 端序；同模型候选必须精确匹配真实 OA 身份及端序，未用别名不阻止仿真；全部物理 PDK 绑定必须被实际网表消费，模型失配或漏实例在仿真之前拒绝；添加 DC/OP 保存指令。
7. Maau `Simulator` 执行 Spectre，`DCHelper` 原始读取 `dcOp.dc` / `dcOpInfo.info`，保持符号；信号缺失立即报错，禁止宽松子串匹配。
8. 输出 DUT 相对实例名称的 `identity.tsv` / `mos.tsv` / `resistor.tsv`，电阻绑定当前几何与 Corner/温度额定值。缺额定值的电阻记录在 `extraction.json`，新增电阻会被核心门禁拒绝。

保留 `bench_info.json`、OA 网表、origin JSON、`binding.json`、完整 scanned catalog 摘要、
`oa_bindings.tsv`、`simulation.scs`、Spectre 日志、原始 PSF、`raw_signed.tsv` 与 `extraction.json`。
工作点保存语法参考 [Cadence 的 DC/OP 说明](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/52153/spectre-netlist)。

收到实际 PDK/工艺/Case 路径后，再将以上参数清单替换为已知 Capless 的完整命令和真实数据。

## 独立审查后的修复

独立审查复现的七项问题已对应修正：CDF Spectre 端序、缓存前的电气输入指纹、
同文件多个模型 sections、FW/W 区分、fast 导出原始 include 目录、同模型 OA master 精确匹配、
root/Bench wrapper 参数作用域。新增回归均为本地契约证据；不代替真实 Maau/Cadence 验收。
复审继续补齐活动输入路径绑定和全部 PDK 实例的模型覆盖检查，避免静默换规则或漏 MOS。
