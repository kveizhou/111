#include "site_op_simulation_host.h"

// The site integration library must export this exact factory.  Leaving the
// symbol unresolved is intentional: a production provider cannot link unless
// a real Maau/Spectre host implementation is supplied.
extern "C" st::maau::OpSimulationHost*
st_maau_create_site_op_simulation_host();

namespace st::maau {

std::unique_ptr<OpSimulationHost> CreateSiteOpSimulationHost()
{
    return std::unique_ptr<OpSimulationHost>(
        st_maau_create_site_op_simulation_host());
}

} // namespace st::maau
