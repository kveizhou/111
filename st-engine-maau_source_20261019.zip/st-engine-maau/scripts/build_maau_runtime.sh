#!/usr/bin/env bash
set -euo pipefail
project_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
build_dir=${ST_BUILD_DIR:-"$project_dir/build"}
maau_source=${ST_MAAU_SOURCE_DIR:?set ST_MAAU_SOURCE_DIR to the complete Maau source root}
compile_file=${ST_MAAU_COMPILE_ARGS_FILE:?set ST_MAAU_COMPILE_ARGS_FILE (one compiler argument per line)}
link_file=${ST_MAAU_LINK_ARGS_FILE:?set ST_MAAU_LINK_ARGS_FILE (one link argument per line)}
for path in "$maau_source/src/common/projectmanager/project_config.h" \
            "$maau_source/src/platform/psf/dchelper.h" "$compile_file" "$link_file"; do
    [[ "$path" == /* && -f "$path" && -s "$path" ]] || {
        echo "error: real Maau header/argument file must be nonempty and absolute: $path" >&2
        exit 2
    }
done
compiler=${CXX:-c++}
compile_args=()
link_args=()
while IFS= read -r argument || [[ -n "$argument" ]]; do
    [[ -z "$argument" || "$argument" == \#* ]] || compile_args+=("$argument")
done < "$compile_file"
while IFS= read -r argument || [[ -n "$argument" ]]; do
    [[ -z "$argument" || "$argument" == \#* ]] || link_args+=("$argument")
done < "$link_file"
mkdir -p "$build_dir/bin"
output="$build_dir/bin/st_maau_runtime"
rm -f "$output.site-linked"
"$compiler" -std=c++17 -I"$maau_source/src" "${compile_args[@]}" \
    "$project_dir/integration/maau/maau_site_runtime.cc" "${link_args[@]}" -o "$output"
printf 'maau_native_runtime_v1\n' > "$output.site-linked"
chmod +x "$project_dir/server/site/maau_op.py" "$project_dir/server/site/maau_case.py"
echo "built concrete Maau runtime: $output"
