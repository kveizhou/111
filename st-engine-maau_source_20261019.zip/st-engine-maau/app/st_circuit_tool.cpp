#include "st/Cli.h"

#include <iostream>
#include <string>
#include <vector>

int main(int argc, char** argv)
{
    std::vector<std::string> arguments;
    for (int index = 1; index < argc; ++index) arguments.emplace_back(argv[index]);
    st::standalone::PosixProcessRunner runner;
    return st::standalone::RunCli(arguments, std::cout, std::cerr, runner);
}
