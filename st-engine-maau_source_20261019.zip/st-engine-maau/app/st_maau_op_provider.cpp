#include "../integration/maau/site_op_simulation_host.h"

#include <iostream>

int main(int argc, char** argv)
{
    auto host = st::maau::CreateSiteOpSimulationHost();
    if (!host) {
        std::cerr << "Maau site host factory returned null\n";
        return 70;
    }
    return st::maau::RunMaauOpProviderCli(
        argc, argv, *host, std::cout, std::cerr);
}
