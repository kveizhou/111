// =============================================================
// Validate.cpp — 电气校验实现
// =============================================================
#include "st/Validate.h"
#include <cmath>
#include <sstream>

namespace st {

Diagnostic checkCascodeHeadroom(double vdsAvailAbs,
                                double vdsat1, double vdsat2,
                                double margin, double vx) {
    double need1 = std::fabs(vdsat1) + std::fabs(margin);
    double need2 = std::fabs(vdsat2) + std::fabs(margin);
    double avail = std::fabs(vdsAvailAbs);
    if (avail < need1 + need2) {
        std::ostringstream os;
        os << "headroom 不足：可用 |VDS|=" << avail
           << "V，两管保饱和共需 " << need1 + need2
           << "V（每管 vdsat+margin = " << need1 << "/" << need2 << "）";
        return {DiagCode::HeadroomInsufficient, os.str()};
    }
    if (vx < need1) {
        std::ostringstream os;
        os << "Vx=" << vx << "V 低于 M1 保饱和所需 " << need1 << "V";
        return {DiagCode::HeadroomInsufficient, os.str()};
    }
    if (avail - vx < need2) {
        std::ostringstream os;
        os << "Vx=" << vx << "V 时 M2 仅剩 " << avail - vx
           << "V，低于所需 " << need2 << "V";
        return {DiagCode::HeadroomInsufficient, os.str()};
    }
    return {DiagCode::Ok, ""};
}

Diagnostic checkStackCeiling(double vbHighNeeded, double topRailV) {
    if (vbHighNeeded > topRailV) {
        std::ostringstream os;
        os << "stack 所需最高栅压 " << vbHighNeeded
           << "V 超过电源轨 " << topRailV
           << "V（不生成电荷泵，判定不可行）";
        return {DiagCode::StackCeilingExceeded, os.str()};
    }
    return {DiagCode::Ok, ""};
}

Diagnostic checkPolarity(DeviceKind original, DeviceKind replacement) {
    bool n = (original == DeviceKind::MosN && replacement == DeviceKind::MosN);
    bool p = (original == DeviceKind::MosP && replacement == DeviceKind::MosP);
    if (n || p) return {DiagCode::Ok, ""};
    return {DiagCode::PolarityMismatch,
            "异型 cascode 仅支持同极性换 flavor，N/P 混串电气上不成立"};
}

Diagnostic resolveBulk(DeviceKind polarity, bool sourceTiedAllowed,
                       const std::string& nmosBulkNet,
                       const std::string& originalBulkNet,
                       bool& tieToSource, std::string& outNet) {
    tieToSource = false;
    if (polarity == DeviceKind::MosN) {
        if (nmosBulkNet.empty())
            return {DiagCode::BulkPolicyUnresolved, "未提供 NMOS 全局衬底网络"};
        outNet = nmosBulkNet;   // 共衬底工艺：只能接全局衬底
        return {DiagCode::Ok, ""};
    }
    if (polarity == DeviceKind::MosP) {
        if (sourceTiedAllowed) {  // 独立阱：源衬相连，消体效应
            tieToSource = true;
            return {DiagCode::Ok, ""};
        }
        if (!originalBulkNet.empty()) {  // 继承原管 bulk 网络（通常 VDD/PVDD）
            outNet = originalBulkNet;
            return {DiagCode::Ok, ""};
        }
        return {DiagCode::BulkPolicyUnresolved,
                "PMOS 不允许源衬相连且无原 bulk 网络可继承"};
    }
    return {DiagCode::NotMos, "bulk 策略仅适用于 MOS"};
}

} // namespace st
