#include "st/Transaction.h"

#include <utility>

namespace st {

NetlistTransaction::NetlistTransaction(Netlist& target)
    : target_(&target), working_(target)
{}

Netlist& NetlistTransaction::Working()
{
    return working_;
}

const Netlist& NetlistTransaction::Working() const
{
    return working_;
}

void NetlistTransaction::Commit()
{
    if (!committed_) {
        *target_ = std::move(working_);
        committed_ = true;
    }
}

bool NetlistTransaction::Committed() const
{
    return committed_;
}

} // namespace st
