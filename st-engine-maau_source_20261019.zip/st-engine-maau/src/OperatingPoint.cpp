#include "st/OperatingPoint.h"

#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <limits>
#include <set>
#include <sstream>

namespace st {
namespace {

const std::vector<std::string> kIdentityHeader = {
    "dut_hash", "bench_hash", "pdk_version", "corner",
    "topology_hash", "parameter_hash", "solver_version",
    "total_supply_current",
};
const std::vector<std::string> kMosHeader = {
    "instance", "vd", "vg", "vs", "vb", "id", "vgs", "vds",
    "vbs", "vth", "vdsat", "cgg",
};
const std::vector<std::string> kIntrinsicMosHeader = {
    "instance", "vd", "vg", "vs", "vb", "id", "vgs", "vds",
    "vbs", "vth", "vdsat", "cgg", "intrinsic_vgs", "intrinsic_vds",
};
const std::vector<std::string> kResistorHeader = {
    "instance", "master", "geometry", "vpos", "vneg", "current",
    "max_voltage", "max_power", "max_current", "rating_source",
};

std::vector<std::string> splitTsv(const std::string& line)
{
    std::vector<std::string> fields;
    std::size_t begin = 0;
    while (true) {
        const auto end = line.find('\t', begin);
        fields.push_back(line.substr(begin, end - begin));
        if (end == std::string::npos) break;
        begin = end + 1;
    }
    return fields;
}

bool fail(std::vector<Diagnostic>& diagnostics, const std::string& message)
{
    diagnostics.push_back({DiagCode::MissingInput, message});
    return false;
}

bool parseFinite(const std::string& text, double& value)
{
    if (text.empty()) return false;
    errno = 0;
    char* end = nullptr;
    const double parsed = std::strtod(text.c_str(), &end);
    if (errno == ERANGE || end == text.c_str() || end == nullptr || *end != '\0' ||
        !std::isfinite(parsed)) {
        return false;
    }
    value = parsed;
    return true;
}

bool validTextField(const std::string& value)
{
    return !value.empty() && value.find_first_of("\t\r\n") == std::string::npos;
}

bool readRequiredLine(std::ifstream& input, std::string& line)
{
    return static_cast<bool>(std::getline(input, line));
}

bool hasExtraLine(std::ifstream& input)
{
    std::string line;
    return static_cast<bool>(std::getline(input, line));
}

bool validSnapshot(const OperatingPointSnapshot& snapshot,
                   std::vector<Diagnostic>& diagnostics,
                   bool validateResistors,
                   bool allowMissingRatings = false)
{
    if (!validTextField(snapshot.identity.dut_hash) ||
        !validTextField(snapshot.identity.bench_hash) ||
        !validTextField(snapshot.identity.pdk_version) ||
        !validTextField(snapshot.identity.corner) ||
        !validTextField(snapshot.identity.topology_hash) ||
        !validTextField(snapshot.identity.parameter_hash) ||
        !validTextField(snapshot.identity.solver_version)) {
        return fail(diagnostics, "operating-point identity fields must be non-empty TSV text");
    }
    if (snapshot.total_supply_current && !std::isfinite(*snapshot.total_supply_current)) {
        return fail(diagnostics, "total_supply_current must be finite");
    }
    if (snapshot.mos.empty()) {
        return fail(diagnostics, "operating-point MOS data has no records");
    }
    for (const auto& entry : snapshot.mos) {
        if (!validTextField(entry.first)) {
            return fail(diagnostics, "MOS instance name must be non-empty TSV text");
        }
        const auto& point = entry.second;
        if (!HasValidIntrinsicVoltages(point)) {
            return fail(diagnostics, "intrinsic voltages must be a finite pair or both absent");
        }
        const double values[] = {point.vd, point.vg, point.vs, point.vb, point.id,
            point.vgs, point.vds, point.vbs, point.vth, point.vdsat, point.cgg};
        for (const double value : values) {
            if (!std::isfinite(value)) {
                return fail(diagnostics, "MOS operating-point values must be finite");
            }
        }
    }
    if (validateResistors) {
        for (const auto& entry : snapshot.resistors) {
            const auto& point = entry.second;
            if (!validTextField(entry.first) || !validTextField(point.master) ||
                !validTextField(point.geometry) ||
                (!allowMissingRatings && !validTextField(point.rating_source)) ||
                !std::isfinite(point.vpos) || !std::isfinite(point.vneg) ||
                !std::isfinite(point.current) || !std::isfinite(point.max_voltage) ||
                !std::isfinite(point.max_power) || !std::isfinite(point.max_current) ||
                point.max_voltage < 0.0 || point.max_power < 0.0 ||
                point.max_current < 0.0 ||
                (!allowMissingRatings && (point.max_voltage == 0.0 ||
                 (point.max_power == 0.0 && point.max_current == 0.0)))) {
                return fail(diagnostics, "resistor OP requires finite terminals, PDK master/geometry/source and positive ratings");
            }
        }
    }
    return true;
}

} // namespace

bool HasValidIntrinsicVoltages(const MosOperatingPoint& point)
{
    return point.intrinsic_vgs.has_value() == point.intrinsic_vds.has_value() &&
        (!point.intrinsic_vgs || (std::isfinite(*point.intrinsic_vgs) && std::isfinite(*point.intrinsic_vds)));
}

bool IsReusable(const OperatingPointSnapshot& snapshot,
                const AnalysisIdentity& requested)
{
    const auto& actual = snapshot.identity;
    return !actual.dut_hash.empty() && !actual.bench_hash.empty() &&
        !actual.pdk_version.empty() && !actual.corner.empty() &&
        !actual.topology_hash.empty() && !actual.parameter_hash.empty() &&
        !actual.solver_version.empty() &&
        actual.dut_hash == requested.dut_hash &&
        actual.bench_hash == requested.bench_hash &&
        actual.pdk_version == requested.pdk_version &&
        actual.corner == requested.corner &&
        actual.topology_hash == requested.topology_hash &&
        actual.parameter_hash == requested.parameter_hash &&
        actual.solver_version == requested.solver_version;
}

const MosOperatingPoint* FindMosOp(const OperatingPointSnapshot& snapshot,
                                   const std::string& name)
{
    const auto found = snapshot.mos.find(name);
    return found == snapshot.mos.end() ? nullptr : &found->second;
}

bool LoadOperatingPointTsv(const std::filesystem::path& identityTsv,
                           const std::filesystem::path& mosTsv,
                           const std::filesystem::path& resistorTsv,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics)
{
    std::ifstream identityInput(identityTsv);
    if (!identityInput) {
        return fail(diagnostics, "cannot open operating-point identity TSV: " +
            identityTsv.string());
    }
    std::string line;
    if (!readRequiredLine(identityInput, line) || splitTsv(line) != kIdentityHeader) {
        return fail(diagnostics, "operating-point identity TSV header is invalid");
    }
    if (!readRequiredLine(identityInput, line)) {
        return fail(diagnostics, "operating-point identity TSV data row is missing");
    }
    const auto identityFields = splitTsv(line);
    if (identityFields.size() != kIdentityHeader.size()) {
        return fail(diagnostics, "operating-point identity TSV row has the wrong field count");
    }
    if (hasExtraLine(identityInput)) {
        return fail(diagnostics, "operating-point identity TSV must contain exactly one data row");
    }

    OperatingPointSnapshot parsed;
    parsed.identity = {identityFields[0], identityFields[1], identityFields[2],
                       identityFields[3], identityFields[4], identityFields[5],
                       identityFields[6]};
    if (!validTextField(parsed.identity.dut_hash) ||
        !validTextField(parsed.identity.bench_hash) ||
        !validTextField(parsed.identity.pdk_version) ||
        !validTextField(parsed.identity.corner) ||
        !validTextField(parsed.identity.topology_hash) ||
        !validTextField(parsed.identity.parameter_hash) ||
        !validTextField(parsed.identity.solver_version)) {
        return fail(diagnostics, "operating-point identity fields must not be empty");
    }
    if (identityFields[7] != "NA") {
        double measuredCurrent;
        if (!parseFinite(identityFields[7], measuredCurrent)) {
            return fail(diagnostics, "total_supply_current is not a finite number or NA");
        }
        parsed.total_supply_current = measuredCurrent;
    }

    std::ifstream mosInput(mosTsv);
    if (!mosInput) {
        return fail(diagnostics, "cannot open MOS operating-point TSV: " + mosTsv.string());
    }
    if (!readRequiredLine(mosInput, line)) {
        return fail(diagnostics, "MOS operating-point TSV header is missing");
    }
    const auto mosHeader = splitTsv(line);
    const bool intrinsic = mosHeader == kIntrinsicMosHeader;
    if (mosHeader != kMosHeader && !intrinsic) {
        return fail(diagnostics, "MOS operating-point TSV header is invalid");
    }
    std::size_t row = 1;
    while (std::getline(mosInput, line)) {
        ++row;
        const auto fields = splitTsv(line);
        if (fields.size() != mosHeader.size() || !validTextField(fields[0])) {
            return fail(diagnostics, "MOS operating-point TSV row " +
                std::to_string(row) + " is incomplete");
        }
        if (parsed.mos.count(fields[0]) != 0) {
            return fail(diagnostics, "duplicate MOS operating-point instance: " + fields[0]);
        }
        MosOperatingPoint point;
        double* values[] = {&point.vd, &point.vg, &point.vs, &point.vb, &point.id,
            &point.vgs, &point.vds, &point.vbs, &point.vth, &point.vdsat, &point.cgg};
        for (std::size_t index = 0; index < 11; ++index) {
            if (!parseFinite(fields[index + 1], *values[index])) {
                return fail(diagnostics, "MOS operating-point TSV row " +
                    std::to_string(row) + " contains a non-finite or invalid number");
            }
        }
        if (intrinsic && (fields[12] != "NA" || fields[13] != "NA")) {
            double vgs = 0.0, vds = 0.0;
            if (!parseFinite(fields[12], vgs) || !parseFinite(fields[13], vds)) {
                return fail(diagnostics, "intrinsic voltages must be a finite pair or NA/NA");
            }
            point.intrinsic_vgs = vgs;
            point.intrinsic_vds = vds;
        }
        parsed.mos.emplace(fields[0], point);
    }
    if (parsed.mos.empty()) {
        return fail(diagnostics, "MOS operating-point TSV has no data rows");
    }
    if (!resistorTsv.empty()) {
        std::ifstream resistorInput(resistorTsv);
        if (!resistorInput) {
            return fail(diagnostics, "cannot open resistor operating-point TSV: " +
                resistorTsv.string());
        }
        if (!readRequiredLine(resistorInput, line) ||
            splitTsv(line) != kResistorHeader) {
            return fail(diagnostics, "resistor operating-point TSV header is invalid");
        }
        row = 1;
        while (std::getline(resistorInput, line)) {
            ++row;
            const auto fields = splitTsv(line);
            if (fields.size() != kResistorHeader.size() ||
                !validTextField(fields[0]) || !validTextField(fields[1]) ||
                !validTextField(fields[2]) || !validTextField(fields[9])) {
                return fail(diagnostics, "resistor operating-point TSV row " +
                    std::to_string(row) + " is incomplete");
            }
            if (parsed.resistors.count(fields[0]) != 0) {
                return fail(diagnostics, "duplicate resistor operating-point instance: " +
                    fields[0]);
            }
            ResistorOperatingPoint point;
            point.master = fields[1];
            point.geometry = fields[2];
            point.rating_source = fields[9] == "-" ? "" : fields[9];
            double* values[] = {&point.vpos, &point.vneg, &point.current,
                &point.max_voltage, &point.max_power, &point.max_current};
            for (std::size_t index = 0; index < 6; ++index) {
                if (index >= 3 && fields[index + 3] == "NA") continue;
                if (!parseFinite(fields[index + 3], *values[index])) {
                    return fail(diagnostics, "resistor operating-point TSV row " +
                        std::to_string(row) + " has an invalid number");
                }
            }
            const bool explicitMissing = fields[6] == "NA" || fields[7] == "NA" || fields[8] == "NA";
            if ((point.max_voltage <= 0.0 && fields[6] != "NA") ||
                point.max_power < 0.0 || point.max_current < 0.0 ||
                (!explicitMissing && point.max_power == 0.0 && point.max_current == 0.0) ||
                (point.rating_source.empty() &&
                 (point.max_voltage > 0.0 || point.max_power > 0.0 || point.max_current > 0.0))) {
                return fail(diagnostics, "resistor rating absent values require explicit NA; known ratings require a source");
            }
            parsed.resistors.emplace(fields[0], std::move(point));
        }
        if (!validSnapshot(parsed, diagnostics, true, true)) return false;
    }
    snapshot = std::move(parsed);
    return true;
}

bool LoadOperatingPointTsv(const std::filesystem::path& identityTsv,
                           const std::filesystem::path& mosTsv,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics)
{
    return LoadOperatingPointTsv(identityTsv, mosTsv, {}, snapshot, diagnostics);
}

bool LoadOperatingPointTsv(const std::filesystem::path& directory,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics)
{
    std::error_code error;
    const auto resistorTsv = directory / "resistor.tsv";
    if (std::filesystem::exists(resistorTsv, error) || error) {
        return LoadOperatingPointTsv(directory / "identity.tsv", directory / "mos.tsv",
                                     resistorTsv, snapshot, diagnostics);
    }
    return LoadOperatingPointTsv(directory / "identity.tsv", directory / "mos.tsv",
                                 snapshot, diagnostics);
}

bool WriteOperatingPointTsv(const std::filesystem::path& identityTsv,
                            const std::filesystem::path& mosTsv,
                            const std::filesystem::path& resistorTsv,
                            const OperatingPointSnapshot& snapshot,
                            std::vector<Diagnostic>& diagnostics)
{
    if (!validSnapshot(snapshot, diagnostics, !resistorTsv.empty())) return false;
    std::error_code error;
    if (!identityTsv.parent_path().empty()) {
        std::filesystem::create_directories(identityTsv.parent_path(), error);
        if (error) return fail(diagnostics, "cannot create identity TSV directory: " +
            error.message());
    }
    error.clear();
    if (!mosTsv.parent_path().empty()) {
        std::filesystem::create_directories(mosTsv.parent_path(), error);
        if (error) return fail(diagnostics, "cannot create MOS TSV directory: " +
            error.message());
    }

    std::ofstream identityOutput(identityTsv, std::ios::trunc);
    identityOutput << "dut_hash\tbench_hash\tpdk_version\tcorner\t"
                      "topology_hash\tparameter_hash\tsolver_version\t"
                      "total_supply_current\n"
                   << snapshot.identity.dut_hash << '\t'
                   << snapshot.identity.bench_hash << '\t'
                   << snapshot.identity.pdk_version << '\t'
                   << snapshot.identity.corner << '\t'
                   << snapshot.identity.topology_hash << '\t'
                   << snapshot.identity.parameter_hash << '\t'
                   << snapshot.identity.solver_version << '\t'
                   << std::setprecision(17);
    if (snapshot.total_supply_current) identityOutput << *snapshot.total_supply_current;
    else identityOutput << "NA";
    identityOutput << '\n';
    if (!identityOutput) {
        return fail(diagnostics, "cannot write operating-point identity TSV");
    }

    std::ofstream mosOutput(mosTsv, std::ios::trunc);
    bool intrinsic = false;
    for (const auto& entry : snapshot.mos) intrinsic = intrinsic || entry.second.intrinsic_vds.has_value();
    mosOutput << "instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg";
    if (intrinsic) mosOutput << "\tintrinsic_vgs\tintrinsic_vds";
    mosOutput << '\n';
    mosOutput << std::setprecision(17);
    for (const auto& entry : snapshot.mos) {
        const auto& point = entry.second;
        mosOutput << entry.first << '\t' << point.vd << '\t' << point.vg << '\t'
                  << point.vs << '\t' << point.vb << '\t' << point.id << '\t'
                  << point.vgs << '\t' << point.vds << '\t' << point.vbs << '\t'
                  << point.vth << '\t' << point.vdsat << '\t' << point.cgg;
        if (intrinsic) {
            if (point.intrinsic_vds) mosOutput << '\t' << *point.intrinsic_vgs << '\t' << *point.intrinsic_vds;
            else mosOutput << "\tNA\tNA";
        }
        mosOutput << '\n';
    }
    if (!mosOutput) return fail(diagnostics, "cannot write MOS operating-point TSV");
    if (!resistorTsv.empty()) {
        error.clear();
        if (!resistorTsv.parent_path().empty()) {
            std::filesystem::create_directories(resistorTsv.parent_path(), error);
            if (error) return fail(diagnostics, "cannot create resistor TSV directory: " +
                error.message());
        }
        std::ofstream resistorOutput(resistorTsv, std::ios::trunc);
        resistorOutput << "instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\t"
                          "max_voltage\tmax_power\tmax_current\trating_source\n";
        resistorOutput << std::setprecision(17);
        for (const auto& entry : snapshot.resistors) {
            const auto& point = entry.second;
            resistorOutput << entry.first << '\t' << point.master << '\t'
                << point.geometry << '\t' << point.vpos << '\t' << point.vneg
                << '\t' << point.current << '\t' << point.max_voltage << '\t'
                << point.max_power << '\t' << point.max_current << '\t'
                << point.rating_source << '\n';
        }
        if (!resistorOutput) {
            return fail(diagnostics, "cannot write resistor operating-point TSV");
        }
    }
    return true;
}

bool WriteOperatingPointTsv(const std::filesystem::path& identityTsv,
                            const std::filesystem::path& mosTsv,
                            const OperatingPointSnapshot& snapshot,
                            std::vector<Diagnostic>& diagnostics)
{
    return WriteOperatingPointTsv(identityTsv, mosTsv, {}, snapshot, diagnostics);
}

} // namespace st
