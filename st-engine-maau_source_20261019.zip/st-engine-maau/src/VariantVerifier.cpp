#include "st/VariantVerifier.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

namespace st {

namespace {

std::vector<const Subckt*> sortedSubckts(const Netlist& netlist)
{
    std::vector<const Subckt*> result;
    for (const auto& subckt : netlist.subckts) result.push_back(&subckt);
    std::sort(result.begin(), result.end(), [](const Subckt* left, const Subckt* right) {
        return left->name < right->name;
    });
    return result;
}

std::vector<const Instance*> sortedInstances(const std::vector<Instance>& instances)
{
    std::vector<const Instance*> result;
    for (const auto& instance : instances) result.push_back(&instance);
    std::sort(result.begin(), result.end(), [](const Instance* left, const Instance* right) {
        return left->name < right->name;
    });
    return result;
}

void appendTopology(std::ostringstream& output, const std::string& scope,
                    const std::vector<std::string>& pins,
                    const std::vector<Instance>& instances)
{
    output << "scope=" << scope << ';';
    // Spectre subckt pins are positional. Their order is part of topology.
    for (const auto& pin : pins) output << "pin=" << pin << ';';
    for (const auto* instance : sortedInstances(instances)) {
        output << "inst=" << instance->name << ':' << instance->model << '(';
        for (const auto& net : instance->nets) output << net.size() << ':' << net << ',';
        output << ");";
    }
}

void appendParameters(std::ostringstream& output, const std::string& scope,
                      const std::map<std::string, std::string>& subcktParams,
                      const std::vector<Instance>& instances)
{
    output << "scope=" << scope << ';';
    for (const auto& parameter : subcktParams) {
        output << "subckt-param=" << parameter.first.size() << ':' << parameter.first
               << '=' << parameter.second.size() << ':' << parameter.second << ';';
    }
    for (const auto* instance : sortedInstances(instances)) {
        output << "inst=" << instance->name.size() << ':' << instance->name << '{';
        for (const auto& parameter : instance->params) {
            output << parameter.first.size() << ':' << parameter.first << '='
                   << parameter.second.size() << ':' << parameter.second << ',';
        }
        output << "};";
    }
}

std::string fnv1a(const std::string& canonical)
{
    std::uint64_t hash = UINT64_C(14695981039346656037);
    for (const unsigned char character : canonical) {
        hash ^= character;
        hash *= UINT64_C(1099511628211);
    }
    std::ostringstream output;
    output << std::hex << std::setw(16) << std::setfill('0') << hash;
    return output.str();
}

void addStructureMismatch(VariantVerificationReport& report, const std::string& message)
{
    report.mismatches.push_back(message);
    report.diags.push_back({DiagCode::VariantStructureMismatch, message});
}

void addParameterMismatch(VariantVerificationReport& report, const std::string& message)
{
    report.mismatches.push_back(message);
    report.diags.push_back({DiagCode::VariantParameterMismatch, message});
}

bool equivalentParameterValue(const std::string& expected, const std::string& actual)
{
    if (expected == actual) return true;
    bool expectedOk = false;
    bool actualOk = false;
    const double expectedValue = parseSuffixValue(expected, expectedOk);
    const double actualValue = parseSuffixValue(actual, actualOk);
    // CDF engineering suffixes can round the same value to adjacent doubles.
    // Use the existing parameter-range roundoff tolerance; no absolute floor,
    // which could hide an actual change to a nanometre-scale dimension.
    return expectedOk && actualOk && std::isfinite(expectedValue) &&
        std::isfinite(actualValue) &&
        std::fabs(expectedValue - actualValue) <=
            1e-12 * std::max(std::fabs(expectedValue), std::fabs(actualValue));
}

void compareInstances(const std::string& scope,
                      const std::vector<Instance>& expected,
                      const std::vector<Instance>& actual,
                      const VariantVerificationPolicy& policy,
                      VariantVerificationReport& report)
{
    std::map<std::string, const Instance*> expectedByName;
    std::map<std::string, const Instance*> actualByName;
    for (const auto& instance : expected) {
        if (!expectedByName.emplace(instance.name, &instance).second) {
            addStructureMismatch(report, scope + "/" + instance.name + " 在期望网表中重名");
        }
    }
    for (const auto& instance : actual) {
        if (!actualByName.emplace(instance.name, &instance).second) {
            addStructureMismatch(report, scope + "/" + instance.name + " 在round-trip网表中重名");
        }
    }

    for (const auto& item : expectedByName) {
        const auto found = actualByName.find(item.first);
        if (found == actualByName.end()) {
            addStructureMismatch(report, scope + "/" + item.first + " 缺失");
            continue;
        }
        const auto& expectedInstance = *item.second;
        const auto& actualInstance = *found->second;
        if (expectedInstance.model != actualInstance.model) {
            addStructureMismatch(report, scope + "/" + item.first + " master 不一致");
            continue;
        }
        if (expectedInstance.nets != actualInstance.nets) {
            addStructureMismatch(report, scope + "/" + item.first + " 端子连接不一致");
        }
        for (const auto& parameter : expectedInstance.params) {
            const auto actualParameter = actualInstance.params.find(parameter.first);
            if (actualParameter == actualInstance.params.end() ||
                !equivalentParameterValue(parameter.second, actualParameter->second)) {
                addParameterMismatch(report, scope + "/" + item.first + "." +
                    parameter.first + " 要求值=" + parameter.second + "，实读值=" +
                    (actualParameter == actualInstance.params.end() ? "<MISSING>" : actualParameter->second) +
                    "，round-trip 值缺失或不同");
            }
        }
        for (const auto& parameter : actualInstance.params) {
            const auto approved = policy.allowed_extra_parameters_by_instance.find({scope, item.first});
            if (expectedInstance.params.count(parameter.first) == 0 &&
                policy.allowed_extra_instance_parameters.count(parameter.first) == 0 &&
                (approved == policy.allowed_extra_parameters_by_instance.end() ||
                 approved->second.count(parameter.first) == 0)) {
                addParameterMismatch(report, scope + "/" + item.first + "." +
                    parameter.first + " 是未批准的额外round-trip参数");
            }
        }
    }
    for (const auto& item : actualByName) {
        if (expectedByName.count(item.first) == 0) {
            addStructureMismatch(report, scope + "/" + item.first + " 是计划外实例");
        }
    }
}

} // namespace

std::string ComputeNetlistTopologyHash(const Netlist& netlist)
{
    std::ostringstream canonical;
    appendTopology(canonical, "<top>", {}, netlist.topInstances);
    for (const auto* subckt : sortedSubckts(netlist)) {
        appendTopology(canonical, subckt->name, subckt->pins, subckt->instances);
    }
    return fnv1a(canonical.str());
}

std::string ComputeNetlistParameterHash(const Netlist& netlist)
{
    std::ostringstream canonical;
    appendParameters(canonical, "<top>", {}, netlist.topInstances);
    for (const auto* subckt : sortedSubckts(netlist)) {
        appendParameters(canonical, subckt->name, subckt->params,
                         subckt->instances);
    }
    return fnv1a(canonical.str());
}

VariantVerificationReport VerifyVariantRoundTrip(const Netlist& baseline,
                                                 const Netlist& expected,
                                                 const Netlist& actual,
                                                 const VariantVerificationPolicy& policy)
{
    VariantVerificationReport report;
    report.baseline_topology_hash = ComputeNetlistTopologyHash(baseline);
    report.expected_topology_hash = ComputeNetlistTopologyHash(expected);
    report.actual_topology_hash = ComputeNetlistTopologyHash(actual);

    std::map<std::string, const Subckt*> expectedSubckts;
    std::map<std::string, const Subckt*> actualSubckts;
    for (const auto& subckt : expected.subckts) {
        if (!expectedSubckts.emplace(subckt.name, &subckt).second) {
            addStructureMismatch(report, "期望网表存在重复 subckt " + subckt.name);
        }
    }
    for (const auto& subckt : actual.subckts) {
        if (!actualSubckts.emplace(subckt.name, &subckt).second) {
            addStructureMismatch(report, "round-trip网表存在重复 subckt " + subckt.name);
        }
    }

    if (expected.preamble != actual.preamble) {
        addStructureMismatch(report, "顶层model/include/分析前导语句不一致");
    }

    for (const auto& item : expectedSubckts) {
        const auto found = actualSubckts.find(item.first);
        if (found == actualSubckts.end()) {
            addStructureMismatch(report, "subckt " + item.first + " 缺失");
            continue;
        }
        if (item.second->pins != found->second->pins) {
            addStructureMismatch(report, "subckt " + item.first + " 位置端口顺序不一致");
        }
        if (item.second->params != found->second->params) {
            addParameterMismatch(report, "subckt " + item.first + " parameters 不一致");
        }
        if (item.second->bodyDirectives != found->second->bodyDirectives) {
            addStructureMismatch(report, "subckt " + item.first + " 局部指令不一致");
        }
        compareInstances(item.first, item.second->instances, found->second->instances,
                         policy, report);
    }
    for (const auto& item : actualSubckts) {
        if (expectedSubckts.count(item.first) == 0) {
            addStructureMismatch(report, "subckt " + item.first + " 是计划外层级");
        }
    }
    compareInstances("<top>", expected.topInstances, actual.topInstances, policy, report);

    report.ok = report.diags.empty();
    report.ready_for_sizing = report.ok;
    return report;
}

} // namespace st
