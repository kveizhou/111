#include "st/JsonWriter.h"

#include <cstdint>
#include <iomanip>
#include <sstream>

namespace st {

std::string EscapeJson(const std::string& input)
{
    std::ostringstream output;
    for (const unsigned char character : input) {
        switch (character) {
        case '"': output << "\\\""; break;
        case '\\': output << "\\\\"; break;
        case '\b': output << "\\b"; break;
        case '\f': output << "\\f"; break;
        case '\n': output << "\\n"; break;
        case '\r': output << "\\r"; break;
        case '\t': output << "\\t"; break;
        default:
            if (character < 0x20) {
                output << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                       << static_cast<int>(character) << std::dec;
            } else {
                output << static_cast<char>(character);
            }
        }
    }
    return output.str();
}

namespace {

void quote(std::ostringstream& output, const std::string& value)
{
    output << '"' << EscapeJson(value) << '"';
}

void writeCellView(std::ostringstream& output, const CellViewRef& ref)
{
    output << "{\"library\":";
    quote(output, ref.library);
    output << ",\"cell\":";
    quote(output, ref.cell);
    output << ",\"view\":";
    quote(output, ref.view);
    output << ",\"storage_path\":";
    quote(output, ref.storage_path);
    output << ",\"revision\":";
    quote(output, ref.revision);
    output << '}';
}

void writePoint(std::ostringstream& output, const OaPoint& point)
{
    output << '[' << std::setprecision(17) << point.x << ',' << point.y << ']';
}

void writeCreateInstance(std::ostringstream& output, const OaCreateInstance& instance)
{
    output << "{\"hierarchy_path\":";
    quote(output, instance.hierarchy_path);
    output << ",\"name\":";
    quote(output, instance.name);
    output << ",\"master\":";
    writeCellView(output, instance.master);
    output << ",\"location\":";
    writePoint(output, instance.location);
    output << ",\"orientation\":";
    quote(output, instance.orientation);
    output << ",\"expected_terminal_count\":" << instance.expected_terminal_count;
    output << ",\"connections\":[";
    for (std::size_t index = 0; index < instance.connections.size(); ++index) {
        if (index != 0) output << ',';
        const auto& connection = instance.connections[index];
        output << "{\"semantic_terminal\":";
        quote(output, connection.semantic_terminal);
        output << ",\"pdk_terminal\":";
        quote(output, connection.pdk_terminal);
        output << ",\"net\":";
        quote(output, connection.net);
        output << '}';
    }
    output << "],\"cdf_parameters\":{";
    bool first = true;
    for (const auto& parameter : instance.cdf_parameters) {
        if (!first) output << ',';
        first = false;
        quote(output, parameter.first);
        output << ':';
        quote(output, parameter.second);
    }
    output << "},\"cdf_parameter_list\":[";
    first = true;
    for (const auto& parameter : instance.cdf_parameters) {
        if (!first) output << ',';
        first = false;
        output << "{\"name\":";
        quote(output, parameter.first);
        output << ",\"value\":";
        quote(output, parameter.second);
        output << '}';
    }
    output << ']';
    if (!instance.property_source_instance.empty()) {
        output << ",\"copy_properties_from\":{\"cellview\":";
        writeCellView(output, instance.property_source);
        output << ",\"instance\":";
        quote(output, instance.property_source_instance);
        output << '}';
    }
    output << ",\"allowed_extra_cdf_parameters\":[";
    first = true;
    for (const auto& parameter : instance.allowed_extra_cdf_parameters) {
        if (!first) output << ',';
        first = false;
        quote(output, parameter);
    }
    output << "]}";
}

void writePort(std::ostringstream& output, const OaCreatePort& port)
{
    output << "{\"hierarchy_path\":";
    quote(output, port.hierarchy_path);
    output << ",\"name\":";
    quote(output, port.name);
    output << ",\"direction\":";
    quote(output, port.direction);
    output << ",\"net\":";
    quote(output, port.net);
    output << ",\"location\":";
    writePoint(output, port.location);
    output << '}';
}

void writeDirectWire(std::ostringstream& output, const OaDirectWire& wire)
{
    output << "{\"hierarchy_path\":";
    quote(output, wire.hierarchy_path);
    output << ",\"net\":";
    quote(output, wire.net);
    output << ",\"from_instance\":";
    quote(output, wire.from_instance);
    output << ",\"from_terminal\":";
    quote(output, wire.from_terminal);
    output << ",\"to_instance\":";
    quote(output, wire.to_instance);
    output << ",\"to_terminal\":";
    quote(output, wire.to_terminal);
    output << '}';
}

void writeWire(std::ostringstream& output, const OaWire& wire)
{
    output << "{\"hierarchy_path\":";
    quote(output, wire.hierarchy_path);
    output << ",\"net\":";
    quote(output, wire.net);
    output << ",\"points\":[";
    for (std::size_t index = 0; index < wire.points.size(); ++index) {
        if (index != 0) output << ',';
        writePoint(output, wire.points[index]);
    }
    output << "]}";
}

std::string writePayload(const OaMaterializationPlan& plan, bool includeHash,
                         const std::string& hash)
{
    std::ostringstream output;
    output << "{\"schema_version\":" << plan.schema_version << ",\"source\":";
    writeCellView(output, plan.source);
    output << ",\"target\":";
    writeCellView(output, plan.target);
    if (plan.parameters_only) output << ",\"parameters_only\":true";

    output << ",\"clone_on_write\":[";
    for (std::size_t index = 0; index < plan.clone_map.size(); ++index) {
        if (index != 0) output << ',';
        const auto& mapping = plan.clone_map[index];
        output << "{\"source\":";
        writeCellView(output, mapping.source);
        output << ",\"target\":";
        writeCellView(output, mapping.target);
        output << ",\"hierarchy_path\":";
        quote(output, mapping.hierarchy_path);
        output << ",\"parent_hierarchy_path\":";
        quote(output, mapping.parent_hierarchy_path);
        output << ",\"parent_instance_name\":";
        quote(output, mapping.parent_instance_name);
        output << '}';
    }
    output << ']';

    output << ",\"generated_cells\":[";
    for (std::size_t cellIndex = 0; cellIndex < plan.generated_cells.size(); ++cellIndex) {
        if (cellIndex != 0) output << ',';
        const auto& cell = plan.generated_cells[cellIndex];
        output << "{\"package_id\":";
        quote(output, cell.package_id);
        output << ",\"schematic\":";
        writeCellView(output, cell.schematic);
        output << ",\"symbol\":";
        writeCellView(output, cell.symbol);
        output << ",\"symbol_lower_left\":";
        writePoint(output, cell.symbol_lower_left);
        output << ",\"symbol_upper_right\":";
        writePoint(output, cell.symbol_upper_right);
        output << ",\"create_instances\":[";
        for (std::size_t index = 0; index < cell.create_instances.size(); ++index) {
            if (index != 0) output << ',';
            writeCreateInstance(output, cell.create_instances[index]);
        }
        output << "],\"create_ports\":[";
        for (std::size_t index = 0; index < cell.create_ports.size(); ++index) {
            if (index != 0) output << ',';
            writePort(output, cell.create_ports[index]);
        }
        output << "],\"direct_wires\":[";
        for (std::size_t index = 0; index < cell.direct_wires.size(); ++index) {
            if (index != 0) output << ',';
            writeDirectWire(output, cell.direct_wires[index]);
        }
        output << "],\"wires\":[";
        for (std::size_t index = 0; index < cell.wires.size(); ++index) {
            if (index != 0) output << ',';
            writeWire(output, cell.wires[index]);
        }
        output << "]}";
    }
    output << ']';

    output << ",\"delete_instances\":[";
    for (std::size_t index = 0; index < plan.delete_instances.size(); ++index) {
        if (index != 0) output << ',';
        const auto& deletion = plan.delete_instances[index];
        output << "{\"hierarchy_path\":";
        quote(output, deletion.hierarchy_path);
        output << ",\"name\":";
        quote(output, deletion.name);
        output << '}';
    }
    output << ']';

    output << ",\"create_instances\":[";
    for (std::size_t index = 0; index < plan.create_instances.size(); ++index) {
        if (index != 0) output << ',';
        writeCreateInstance(output, plan.create_instances[index]);
    }
    output << ']';

    output << ",\"create_ports\":[";
    for (std::size_t index = 0; index < plan.create_ports.size(); ++index) {
        if (index != 0) output << ',';
        writePort(output, plan.create_ports[index]);
    }
    output << ']';

    output << ",\"direct_wires\":[";
    for (std::size_t index = 0; index < plan.direct_wires.size(); ++index) {
        if (index != 0) output << ',';
        writeDirectWire(output, plan.direct_wires[index]);
    }
    output << ']';

    output << ",\"wires\":[";
    for (std::size_t index = 0; index < plan.wires.size(); ++index) {
        if (index != 0) output << ',';
        writeWire(output, plan.wires[index]);
    }
    output << "]";

    output << ",\"check_and_save\":" << (plan.check_and_save ? "true" : "false");
    output << ",\"preview\":{\"variant_id\":";
    quote(output, plan.preview.variant_id);
    output << ",\"parameter_set_id\":";
    quote(output, plan.preview.parameter_set_id);
    output << ",\"materializer_version\":";
    quote(output, plan.preview.materializer_version);
    output << '}';
    if (includeHash) {
        output << ",\"topology_hash\":";
        quote(output, hash);
    }
    output << '}';
    return output.str();
}

} // namespace

std::string ComputeTopologyHash(const OaMaterializationPlan& plan)
{
    const auto payload = writePayload(plan, false, {});
    std::uint64_t hash = UINT64_C(14695981039346656037);
    for (const unsigned char character : payload) {
        hash ^= character;
        hash *= UINT64_C(1099511628211);
    }
    std::ostringstream output;
    output << std::hex << std::setw(16) << std::setfill('0') << hash;
    return output.str();
}

std::string WritePlanJson(const OaMaterializationPlan& plan)
{
    return writePayload(plan, true, ComputeTopologyHash(plan));
}

} // namespace st
