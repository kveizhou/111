// =============================================================
// Solver.cpp — 参数求解纯函数（口径见 Solver.h 注释）
// =============================================================
#include "st/Solver.h"
#include <cmath>

namespace st {

CascodeBias solveCascodeBias(DeviceKind polarity, double vs,
                             double vdsat, double margin, double vgs2) {
    CascodeBias r;
    if (polarity == DeviceKind::MosP) {
        r.vx = vs - std::fabs(vdsat) - std::fabs(margin);
        r.vbias = r.vx - std::fabs(vgs2);
    } else {
        r.vx = vs + std::fabs(vdsat) + std::fabs(margin);
        r.vbias = r.vx + std::fabs(vgs2);
    }
    return r;
}

double solveRdc(double vdsAbs, double idAbs, bool& ok) {
    ok = false;
    if (idAbs <= 0.0) return 0.0;   // 截止/零电流不可做直流等效
    ok = true;
    return std::fabs(vdsAbs) / idAbs;
}

double snapToGrid(double r, double grid) {
    if (grid <= 0.0) return r;
    return std::round(r / grid) * grid;
}

} // namespace st
