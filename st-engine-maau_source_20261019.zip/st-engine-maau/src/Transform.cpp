// =============================================================
// Transform.cpp — 四类结构变换实现
// 前置校验（headroom / 天花板 / 极性 / bulk）不过则拒绝并返回诊断，
// 不做任何修改；通过才改写网表，保证"生成即合法"。
// =============================================================
#include "st/Transform.h"
#include "st/LegacyPrototype.h"
#include "st/Naming.h"
#include "st/PdkCatalog.h"
#include "st/Solver.h"
#include "st/Transaction.h"
#include "st/Validate.h"

#include <cmath>
#include <sstream>
#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <set>

namespace st {

namespace {

bool engineeringMos(const DeviceDescriptor* descriptor)
{
    return descriptor != nullptr &&
        isMosKind(descriptor->kind);
}

bool readMosNets(const Instance& instance, const DeviceCatalog& catalog,
                 std::string& drain, std::string& gate, std::string& source,
                 std::string& bulk, Diagnostic& diagnostic)
{
    return getTerminalNet(instance, catalog, TerminalRole::Drain, drain, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Gate, gate, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Source, source, diagnostic) &&
        getTerminalNet(instance, catalog, TerminalRole::Bulk, bulk, diagnostic);
}

bool writeMosNets(Instance& instance, const DeviceCatalog& catalog,
                  const std::string& drain, const std::string& gate,
                  const std::string& source, const std::string& bulk,
                  Diagnostic& diagnostic)
{
    return setTerminalNet(instance, catalog, TerminalRole::Drain, drain, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Gate, gate, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Source, source, diagnostic) &&
        setTerminalNet(instance, catalog, TerminalRole::Bulk, bulk, diagnostic);
}

bool supportsVoltageDomain(const DeviceDescriptor& descriptor,
                           const std::string& voltageDomain, bool experimentalDc = false)
{
    if (experimentalDc && (voltageDomain.empty() ||
        (descriptor.allowed_voltage_domains.empty() && descriptor.voltage_domain.empty()))) return true;
    if (voltageDomain.empty()) return false;
    if (!descriptor.allowed_voltage_domains.empty()) {
        return descriptor.allowed_voltage_domains.count(voltageDomain) != 0;
    }
    return descriptor.voltage_domain == voltageDomain;
}

bool parseEngineeringNumber(const std::string& text, double& value)
{
    if (text.empty()) return false;
    char* end = nullptr;
    errno = 0;
    const double base = std::strtod(text.c_str(), &end);
    if (errno != 0 || end == text.c_str()) return false;
    std::string suffix(end);
    double multiplier = 1.0;
    if (suffix.empty()) multiplier = 1.0;
    else if (suffix == "T" || suffix == "t") multiplier = 1e12;
    else if (suffix == "G" || suffix == "g") multiplier = 1e9;
    else if (suffix == "MEG" || suffix == "meg") multiplier = 1e6;
    else if (suffix == "K" || suffix == "k") multiplier = 1e3;
    else if (suffix == "M") multiplier = 1e6;
    else if (suffix == "m") multiplier = 1e-3;
    else if (suffix == "U" || suffix == "u") multiplier = 1e-6;
    else if (suffix == "N" || suffix == "n") multiplier = 1e-9;
    else if (suffix == "P" || suffix == "p") multiplier = 1e-12;
    else if (suffix == "F" || suffix == "f") multiplier = 1e-15;
    else return false;
    value = base * multiplier;
    return std::isfinite(value);
}

bool mapInheritedParameters(const Instance& original,
                            const DeviceDescriptor& originalDescriptor,
                            const DeviceDescriptor& targetDescriptor,
                            std::map<std::string, std::string>& mapped,
                            Diagnostic& diagnostic)
{
    if (originalDescriptor.master == targetDescriptor.master) {
        mapped = original.params;
        // Some PDKs expose fixed-geometry MOS cells whose W/L/NFIN are encoded
        // by the master name rather than editable CDF parameters.  Reusing the
        // exact same master preserves that geometry without inventing W/L.
        // Cross-master transformations remain strict below.
        if (targetDescriptor.normalized_to_cdf.empty()) return true;
    } else {
        // 有些PDK用master名本身固定L/NFIN/Flavor。目录仍须在候选筛选
        // 阶段证明它有可量化的 PDK 参数；这里仅避免伪造 W/L CDF 参数。
        if (targetDescriptor.normalized_to_cdf.empty()) {
            mapped.clear();
            return true;
        }
        const std::vector<std::string> required = { "width", "length" };
        for (const auto& semantic : required) {
            const auto sourceName = originalDescriptor.normalized_to_cdf.find(semantic);
            const auto targetName = targetDescriptor.normalized_to_cdf.find(semantic);
            if (sourceName == originalDescriptor.normalized_to_cdf.end() ||
                targetName == targetDescriptor.normalized_to_cdf.end()) {
                diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                    "跨 master 参数映射缺少 " + semantic + " 语义"};
                return false;
            }
            const auto value = original.params.find(sourceName->second);
            if (value == original.params.end()) {
                diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
                    "原器件缺少 " + sourceName->second + " 参数"};
                return false;
            }
            mapped[targetName->second] = value->second;
        }
        const auto sourceFingers = originalDescriptor.normalized_to_cdf.find("fingers");
        const auto targetFingers = targetDescriptor.normalized_to_cdf.find("fingers");
        if (sourceFingers != originalDescriptor.normalized_to_cdf.end() &&
            targetFingers != targetDescriptor.normalized_to_cdf.end()) {
            const auto value = original.params.find(sourceFingers->second);
            if (value != original.params.end()) mapped[targetFingers->second] = value->second;
        }
    }

    const auto widthName = targetDescriptor.normalized_to_cdf.find("width");
    const auto lengthName = targetDescriptor.normalized_to_cdf.find("length");
    if (widthName == targetDescriptor.normalized_to_cdf.end() ||
        lengthName == targetDescriptor.normalized_to_cdf.end()) {
        diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
            "目标 master 未声明 width/length CDF 参数"};
        return false;
    }
    const auto widthText = mapped.find(widthName->second);
    const auto lengthText = mapped.find(lengthName->second);
    double width = 0.0;
    double length = 0.0;
    if (widthText == mapped.end() || lengthText == mapped.end() ||
        !parseEngineeringNumber(widthText->second, width) ||
        !parseEngineeringNumber(lengthText->second, length)) {
        diagnostic = {DiagCode::DeviceParameterSemanticsUnknown,
            "无法解析继承的 width/length（表达式需先由宿主求值）"};
        return false;
    }
    if (width < targetDescriptor.limits.min_width ||
        width > targetDescriptor.limits.max_width ||
        length < targetDescriptor.limits.min_length ||
        length > targetDescriptor.limits.max_length) {
        diagnostic = {DiagCode::DeviceParameterOutOfRange,
            "继承的 W/L 超出目标 master 的 PDK 范围"};
        return false;
    }
    return true;
}

bool validateFixedBiasInputs(const CascodeTransformRequest& request,
                             Diagnostic& diagnostic)
{
    if (!request.solved_bias.has_value() ||
        (!request.solved_bias->ok && !(request.experimental_dc && request.solved_bias->best_effort)) ||
        (!request.experimental_dc && (request.solved_bias->electrical_check.experimental_dc ||
         request.solved_bias->electrical_check.native_parameter_trials)) ||
        !request.bias_template.has_value() || !request.bias_template->ok ||
        request.bias_template->ports.size() != 5 ||
        request.bias_template->elements.empty() ||
        request.vbias_vhigh_net.empty() || request.vbias_vlow_net.empty()) {
        diagnostic = {DiagCode::BiasUnavailable,
            "FixedBias 缺少成功的自动VBIAS求解结果、五端口模板或电源轨父层网"};
        return false;
    }
    diagnostic = {};
    return true;
}

} // namespace

TransformOutcome applyCascode(Netlist& nl, const CascodeTransformRequest& request,
                              const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(request.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " 不存在"});
        return out;
    }
    auto* original = subckt->find(request.target);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "实例 " + request.target + " 不存在"});
        return out;
    }

    const auto* originalDescriptor = catalog.Find(original->model);
    if (!engineeringMos(originalDescriptor)) {
        out.diags.push_back({originalDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "目标 " + request.target + " 不是已登记的 MOS"});
        return out;
    }

    const std::string newMaster = request.new_master.empty() ? original->model : request.new_master;
    const auto* newDescriptor = catalog.Find(newMaster);
    if (!engineeringMos(newDescriptor)) {
        out.diags.push_back({newDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "新增 master " + newMaster + " 不是已登记的 MOS"});
        return out;
    }
    if ((!request.experimental_dc && (originalDescriptor->native_parameter_trials ||
         newDescriptor->native_parameter_trials)) ||
        originalDescriptor->kind == DeviceKind::Mos || newDescriptor->kind == DeviceKind::Mos) {
        out.diags.push_back({DiagCode::DeviceIncompatible,
            "Cascode要求已证明极性，原生试点仅允许experimental_dc"});
        return out;
    }
    if (request.experimental_dc &&
        (!originalDescriptor->bulk_rule_complete || !newDescriptor->bulk_rule_complete)) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved, "实验Cascode仍要求已证明Bulk规则"});
        return out;
    }
    if (request.experimental_dc &&
        !HaveCompatibleVoltageDomains({originalDescriptor, newDescriptor})) {
        out.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
            "实验Cascode原器件与新增器件已知电压域不相容"});
        return out;
    }
    if (newDescriptor->kind != originalDescriptor->kind) {
        out.diags.push_back(checkPolarity(originalDescriptor->kind, newDescriptor->kind));
        return out;
    }
    if (newMaster != original->model) {
        const auto selection = SelectCrossFlavorCandidates(
            *originalDescriptor, catalog, request.voltage_domain, request.experimental_dc);
        const auto accepted = std::find_if(selection.accepted.begin(), selection.accepted.end(),
            [&newMaster](const DeviceDescriptor* descriptor) {
                return descriptor->master == newMaster;
            });
        if (accepted == selection.accepted.end()) {
            out.diags.push_back({DiagCode::DeviceIncompatible,
                "动态PDK目录未允许 " + original->model + " 与 " + newMaster + " 组合"});
            return out;
        }
    }
    if (!supportsVoltageDomain(*originalDescriptor, request.voltage_domain, request.experimental_dc) ||
        !supportsVoltageDomain(*newDescriptor, request.voltage_domain, request.experimental_dc)) {
        out.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
                            "原器件或新器件不支持电压域 " + request.voltage_domain});
        return out;
    }
    if (request.gate_policy != GatePolicy::SharedGate &&
        request.gate_policy != GatePolicy::FixedBias) {
        out.diags.push_back({DiagCode::BadParam, "Cascode gate policy 无效"});
        return out;
    }
    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string originalBulk;
    if (!readMosNets(*original, catalog, drain, gate, source, originalBulk, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    std::string cascodeBulk = originalBulk;
    if (newDescriptor->kind == DeviceKind::MosN) {
        if (request.nmos_bulk_net.empty()) {
            out.diags.push_back({DiagCode::BulkPolicyUnresolved,
                                "NMOS Cascode 未提供合法全局 Bulk 网络"});
            return out;
        }
        cascodeBulk = request.nmos_bulk_net;
    } else if (!(request.tie_isolated_pmos_to_source && newDescriptor->isolated_well) &&
               originalBulk.empty()) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved,
                            "PMOS Cascode 无法继承或建立合法 Bulk 连接"});
        return out;
    }

    std::map<std::string, std::string> inheritedParameters;
    const bool hasSolvedCascodeParameters =
        request.gate_policy == GatePolicy::FixedBias &&
        request.solved_bias.has_value() &&
        (request.solved_bias->ok || (request.experimental_dc && request.solved_bias->best_effort)) &&
        !request.solved_bias->sizing.cascode_parameters.empty();
    if (hasSolvedCascodeParameters) {
        // 自动 VBIAS 求解器已经按目标 master 的实际 CDF 约束
        // 生成并量化这些参数。这里直接使用求解结果，避免再用
        // width/length 假设覆盖 FinFET 的 nfin/l 参数域。
        if (!QuantizeAutoBiasParameters(*newDescriptor,
                request.solved_bias->sizing.cascode_parameters, "cascode",
                inheritedParameters, diagnostic, true, request.experimental_dc)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
    } else if (!mapInheritedParameters(*original, *originalDescriptor,
                                       *newDescriptor, inheritedParameters,
                                       diagnostic)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
    }

    NameAllocator names(working, request.subckt);
    const std::string cascodeName = names.Allocate(NameKind::Instance, request.target + "_CAS");
    const std::string middleNet = names.Allocate(NameKind::Net, request.target + "_MID");
    if (newDescriptor->kind == DeviceKind::MosP &&
        request.tie_isolated_pmos_to_source && newDescriptor->isolated_well) {
        cascodeBulk = middleNet; // 新管实际 Source；不改变原管 Bulk。
    }

    std::string biasOutputNet;
    std::string biasSubcktName;
    if (request.gate_policy == GatePolicy::FixedBias) {
        Diagnostic biasDiagnostic;
        if (!validateFixedBiasInputs(request, biasDiagnostic)) {
            out.diags.push_back(std::move(biasDiagnostic));
            return out;
        }
        biasOutputNet = request.bias_template->output_net + "_" + request.target;
        if (std::find(subckt->pins.begin(), subckt->pins.end(), biasOutputNet) !=
                subckt->pins.end() ||
            subckt->netRefCount(biasOutputNet) != 0) {
            out.diags.push_back({DiagCode::TargetConflict,
                "Bias输出网络已存在于原电路，自动求解结果必须使用隔离名称"});
            return out;
        }
        biasSubcktName = request.bias_template->template_id + "_" + request.target;
        if (working.find(biasSubcktName) != nullptr) {
            out.diags.push_back({DiagCode::TargetConflict,
                "VBIAS模板subckt名与现有层级冲突"});
            return out;
        }
    }

    const std::string cascodeGate = request.gate_policy == GatePolicy::SharedGate
        ? gate : biasOutputNet;

    Instance cascode;
    cascode.name = cascodeName;
    cascode.model = newMaster;
    cascode.params = std::move(inheritedParameters);
    cascode.nets.resize(newDescriptor->terminal_count);
    // 两种极性、同型和异型均只断开原 Drain：原D→MID，新S→MID，新D→原D网。
    if (!writeMosNets(cascode, catalog, drain, cascodeGate, middleNet,
                      cascodeBulk, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    if (std::any_of(cascode.nets.begin(), cascode.nets.end(),
                    [](const std::string& net) { return net.empty(); })) {
        out.diags.push_back({DiagCode::InvalidTerminalMap,
                            "新增 MOS 存在未绑定的必需端子"});
        return out;
    }
    if (!setTerminalNet(*original, catalog, TerminalRole::Drain, middleNet, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    subckt->insertAfter(request.target, cascode);
    out.modifiedInstances.push_back(request.target);
    out.addedInstances.push_back(cascodeName);
    out.addedNets.push_back(middleNet);
    out.parameter_groups[request.target + "_CASCODE_SIZE"] = {request.target, cascodeName};

    if (request.gate_policy == GatePolicy::FixedBias) {
        // 模板作为独立 subckt 存在（五角色、固定端口序、求解量化参数）；
        // 父层只放一个层级实例，不散落模板器件。VS_ORIG/VG_CTRL 接变换前
        // 原管的 Source/Gate 网（上面 readMosNets 读出后原管才被改写）。
        Subckt biasSubckt;
        biasSubckt.name = biasSubcktName;
        biasSubckt.pins = request.bias_template->ports;
        for (const auto& element : request.bias_template->elements) {
            Instance elementInstance;
            elementInstance.name = element.name;
            elementInstance.model = element.model;
            elementInstance.nets = element.nets;
            elementInstance.params = element.params;
            biasSubckt.instances.push_back(std::move(elementInstance));
        }
        Instance biasInstance;
        biasInstance.name = names.Allocate(NameKind::Instance, "I_" + biasOutputNet);
        biasInstance.model = biasSubcktName;
        biasInstance.nets = {request.vbias_vhigh_net, request.vbias_vlow_net,
                             source, gate, biasOutputNet};
        // 注意顺序：先改父层实例表，再 push 模板 subckt——push_back 可能让
        // working.subckts 重新分配，之后 subckt 指针就失效了。
        subckt->instances.push_back(biasInstance);
        working.subckts.push_back(std::move(biasSubckt));
        out.bias_instances.push_back(biasInstance.name);
        out.addedNets.push_back(biasOutputNet);
        out.iq_delta += request.solved_bias->sizing.iq_delta;
    } else {
        out.notes.push_back("共栅模式复用原 Gate，不新增 Bias");
    }

    transaction.Commit();
    return out;
}

TransformOutcome applyResistor(Netlist& nl, const ResistorTransformRequest& request,
                               const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(request.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " 不存在"});
        return out;
    }
    auto* original = subckt->find(request.target);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "实例 " + request.target + " 不存在"});
        return out;
    }
    const auto* originalDescriptor = catalog.Find(original->model);
    if (!engineeringMos(originalDescriptor)) {
        out.diags.push_back({originalDescriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "目标 " + request.target + " 不是已登记的 MOS"});
        return out;
    }
    const auto* resistorDescriptor = catalog.Find(request.resistor.master);
    if (resistorDescriptor == nullptr) {
        out.diags.push_back({DiagCode::UnknownModel,
                            "电阻 master " + request.resistor.master + " 未登记"});
        return out;
    }
    if (resistorDescriptor->kind != DeviceKind::Resistor) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "指定 master 不是 PDK 电阻"});
        return out;
    }
    if (!request.experimental_dc && (originalDescriptor->native_parameter_trials ||
        resistorDescriptor->native_parameter_trials)) {
        out.diags.push_back({DiagCode::DeviceIncompatible,
            "原生参数试点只允许experimental_dc"});
        return out;
    }
    if (request.experimental_dc &&
        (originalDescriptor->kind == DeviceKind::Mos || !originalDescriptor->bulk_rule_complete)) {
        out.diags.push_back({DiagCode::BulkPolicyUnresolved, "实验电阻变换仍要求MOS极性与Bulk规则"});
        return out;
    }
    if (request.resistor.resistance_parameter.empty()) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "PDK 电阻模板未声明阻值参数"});
        return out;
    }
    if (request.search_lower_factor <= 0.0 ||
        request.search_upper_factor < request.search_lower_factor) {
        out.diags.push_back({DiagCode::BadParam, "电阻 Sizing 搜索比例无效"});
        return out;
    }

    const double minimum = std::max(resistorDescriptor->limits.min_resistance,
                                    request.resistor.minimum_resistance);
    const double maximum = std::min(resistorDescriptor->limits.max_resistance,
                                    request.resistor.maximum_resistance);
    if (!std::isfinite(minimum) || minimum < 0.0 || maximum < minimum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "PDK 与电阻模板的合法阻值范围没有交集"});
        return out;
    }

    double seed = 0.0;
    std::string seedSource;
    if (request.requested_resistance.has_value()) {
        seed = request.requested_resistance.value();
        seedSource = "用户输入";
    } else if (request.case_default_resistance.has_value()) {
        seed = request.case_default_resistance.value();
        seedSource = "Case预置";
    } else {
        if (minimum <= 0.0 || !std::isfinite(maximum) || maximum <= 0.0) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                                "PDK阻值范围缺少有限正上下界，无法确定中间默认值"});
            return out;
        }
        seed = std::exp((std::log(minimum) + std::log(maximum)) / 2.0);
        seedSource = "PDK合法范围几何中点";
    }
    if (!std::isfinite(seed) || seed <= 0.0) {
        out.diags.push_back({DiagCode::ResistorEquivalenceUnsupported,
                            "用户或Case指定的阻值不是合法正实数"});
        return out;
    }
    double actual = snapToGrid(seed, request.resistor.grid);
    if (resistorDescriptor->native_parameter_trials) {
        const auto proposal = resistorDescriptor->parameter_constraints.find("resistance");
        if (proposal == resistorDescriptor->parameter_constraints.end() ||
            proposal->second.cdf_name != request.resistor.resistance_parameter ||
            proposal->second.discrete_values.empty() || !ValidateParameterConstraint(proposal->second)) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                "实验电阻缺少有限resistance试点集合"});
            return out;
        }
        actual = QuantizeParameter(seed, proposal->second);
        if (std::fabs(actual - seed) > 1e-12 * std::max(std::fabs(seed), std::fabs(actual))) {
            out.diags.push_back({DiagCode::ResistorMappingFailed,
                "请求阻值不属于已声明的有限原生试点"});
            return out;
        }
        out.notes.push_back("阻值来自有限原生试点，实际CDF与网表回读通过前仅为PROPOSED");
    }
    if (!std::isfinite(actual) || actual <= 0.0 || actual < minimum || actual > maximum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "等效阻值不能量化到 PDK 电阻的合法范围"});
        return out;
    }

    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) ||
        !getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) ||
        !getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) ||
        (originalDescriptor->terminal_count != 3 &&
         !getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic))) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    NameAllocator names(working, request.subckt);
    const std::string resistorName = names.Allocate(NameKind::Instance,
                                                     request.target + "_RS");
    const std::string sourceInternal = names.Allocate(NameKind::Net,
                                                       request.target + "_RS_INT");
    Instance resistor;
    resistor.name = resistorName;
    resistor.model = request.resistor.master;
    resistor.nets.resize(resistorDescriptor->terminal_count);
    if (!setTerminalNet(resistor, catalog, TerminalRole::Positive,
                        sourceInternal, diagnostic) ||
        !setTerminalNet(resistor, catalog, TerminalRole::Negative, source, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    for (const auto& binding : resistorDescriptor->terminal_index) {
        const auto role = binding.first;
        if (role == TerminalRole::Positive || role == TerminalRole::Negative) {
            continue;
        }
        const auto extra = request.resistor.extra_terminal_nets.find(role);
        if (extra == request.resistor.extra_terminal_nets.end() || extra->second.empty()) {
            out.diags.push_back({DiagCode::InvalidTerminalMap,
                                "多端电阻的附加端子没有在 ResistorTemplate 中绑定"});
            return out;
        }
        if (!setTerminalNet(resistor, catalog, role, extra->second, diagnostic)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
    }
    if (std::any_of(resistor.nets.begin(), resistor.nets.end(),
                    [](const std::string& net) { return net.empty(); })) {
        out.diags.push_back({DiagCode::InvalidTerminalMap,
                            "电阻存在未绑定的物理端子"});
        return out;
    }
    resistor.params[request.resistor.resistance_parameter] = resistorDescriptor->native_parameter_trials
        ? FormatAutoBiasParameter(actual) : formatEngineering(actual);
    if (resistorDescriptor->native_parameter_trials) {
        for (const auto& entry : resistorDescriptor->parameter_constraints) {
            const auto& constraint = entry.second;
            if (constraint.discrete_values.empty() || !ValidateParameterConstraint(constraint)) {
                out.diags.push_back({DiagCode::ResistorMappingFailed, "电阻原生几何试点不完整"});
                return out;
            }
            if (constraint.cdf_name == request.resistor.resistance_parameter) continue;
            resistor.params[constraint.cdf_name] = FormatAutoBiasParameter(constraint.discrete_values.front());
        }
        std::map<std::string, std::string> checked;
        if (!QuantizeAutoBiasParameters(*resistorDescriptor, resistor.params,
                "source_resistor", checked, diagnostic, true, true)) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
        resistor.params = std::move(checked);
    }
    if (!setTerminalNet(*original, catalog, TerminalRole::Source,
                        sourceInternal, diagnostic)) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }

    subckt->insertAfter(request.target, resistor);
    out.modifiedInstances.push_back(request.target);
    out.addedInstances.push_back(resistorName);
    out.addedNets.push_back(sourceInternal);
    out.numeric_outputs["R_seed"] = seed;
    out.numeric_outputs["R_actual"] = actual;

    const double sizingMinimum = std::max(minimum, request.search_lower_factor * seed);
    const double sizingMaximum = std::min(maximum, request.search_upper_factor * seed);
    if (sizingMaximum < sizingMinimum) {
        out.diags.push_back({DiagCode::ResistorMappingFailed,
                            "电阻 Sizing 范围与 PDK 合法范围没有交集"});
        return out;
    }
    out.parameter_ranges[resistorName + "." + request.resistor.resistance_parameter] = {
        actual, sizingMinimum, sizingMaximum, request.resistor.grid
    };

    out.notes.push_back("阻值初值来源：" + seedSource);
    out.notes.push_back(originalDescriptor->terminal_count == 3
        ? "保留三端MOS的Drain/Gate和器件参数，仅在Source路径串联电阻"
        : "保留原MOS的Drain/Gate/Bulk和器件参数，仅在Source路径串联电阻");

    transaction.Commit();
    return out;
}

StackPlan planStack(const Netlist& nl, const StackTransformRequest& request,
                    const DeviceCatalog& catalog)
{
    StackPlan plan;
    const auto* subckt = nl.find(request.subckt);
    if (subckt == nullptr) {
        plan.diags.push_back({DiagCode::NotFound, "subckt " + request.subckt + " 不存在"});
        return plan;
    }
    const auto* original = subckt->find(request.target);
    if (original == nullptr) {
        plan.diags.push_back({DiagCode::NotFound, "实例 " + request.target + " 不存在"});
        return plan;
    }
    const auto* descriptor = catalog.Find(original->model);
    if (!engineeringMos(descriptor)) {
        plan.diags.push_back({descriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                              "目标 " + request.target + " 不是已登记的 MOS"});
        return plan;
    }
    if ((descriptor->native_parameter_trials && (!request.experimental_dc || request.structure_only)) ||
        (request.experimental_dc && request.structure_only)) {
        plan.diags.push_back({DiagCode::DeviceIncompatible,
            "原生参数试点只允许独立experimental_dc模式"});
        return plan;
    }
    if (request.experimental_dc && !descriptor->bulk_rule_complete) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved, "实验Stack仍要求已证明Bulk规则"});
        return plan;
    }
    const int maximumStages = std::min(100, descriptor->limits.max_stack_level);
    if (request.stage_count < 2 || request.stage_count > maximumStages) {
        plan.diags.push_back({DiagCode::BadParam,
                              "Stack 级数必须在 2 到 PDK/产品上限之间"});
        return plan;
    }
    if (!request.structure_only && !supportsVoltageDomain(*descriptor, request.voltage_domain, request.experimental_dc)) {
        plan.diags.push_back({DiagCode::DeviceVoltageDomainMismatch,
                              "Stack器件不支持电压域 " + request.voltage_domain});
        return plan;
    }
    if (request.gate_policy != GatePolicy::SharedGate) {
        plan.diags.push_back({DiagCode::BadParam,
                              "当前Stack只支持所有级共用原Gate"});
        return plan;
    }
    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!(getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) &&
          (descriptor->terminal_count == 3 ||
           getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic)))) {
        plan.diags.push_back(std::move(diagnostic));
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::Mos) {
        plan.diags.push_back({DiagCode::MissingInput, "电气Stack要求已证明的MOS极性"});
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::MosN && request.nmos_bulk_net.empty()) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved,
                              "NMOS Stack 未提供合法全局 Bulk 网络"});
        return plan;
    }
    if (!request.structure_only && descriptor->kind == DeviceKind::MosP && bulk.empty() &&
        !(descriptor->isolated_well && request.tie_isolated_pmos_to_source)) {
        plan.diags.push_back({DiagCode::BulkPolicyUnresolved,
                              "PMOS Stack 无法继承或建立合法 Bulk 连接"});
        return plan;
    }

    auto& logical = plan.stack;
    logical.subckt = request.subckt;
    logical.original_instance = request.target;
    logical.master = original->model;
    logical.stage_count = request.stage_count;
    logical.intent = request.intent;
    logical.gate_policy = request.gate_policy;
    logical.drain_net = drain;
    logical.original_gate_net = gate;
    logical.source_net = source;
    logical.original_bulk_net = bulk;
    logical.original_params = original->params;

    NameAllocator names(nl, request.subckt);
    // The logical order is Drain -> Source.  Preserve the original instance
    // identity on the drain side so existing OP references keep their anchor;
    // only the additional source-side stages receive feature suffixes.
    logical.stage_instance_names.push_back(request.target);
    for (int stage = 1; stage < request.stage_count; ++stage) {
        logical.stage_instance_names.push_back(names.Allocate(
            NameKind::Instance, request.target + "_S" + std::to_string(stage)));
    }
    for (int boundary = 1; boundary < request.stage_count; ++boundary) {
        logical.middle_nets.push_back(names.Allocate(
            NameKind::Net, request.target + "_MID" + std::to_string(boundary)));
    }
    for (int stage = 0; stage < request.stage_count; ++stage) {
        logical.gate_nets.push_back(gate);
    }
    for (int stage = 0; stage < request.stage_count; ++stage) {
        const std::string stageSource = stage == request.stage_count - 1
            ? source : logical.middle_nets[static_cast<std::size_t>(stage)];
        if (request.structure_only || descriptor->terminal_count == 3) {
            logical.bulk_nets.push_back(bulk);
        } else if (descriptor->kind == DeviceKind::MosN) {
            logical.bulk_nets.push_back(request.nmos_bulk_net);
        } else if (descriptor->isolated_well && request.tie_isolated_pmos_to_source) {
            logical.bulk_nets.push_back(stageSource);
        } else {
            logical.bulk_nets.push_back(bulk);
        }
        logical.stage_params.push_back(original->params);
    }
    logical.sizing_groups[request.target + "_STACK_COMMON_SIZE"] =
        logical.stage_instance_names;
    return plan;
}

TransformOutcome materializeStack(Netlist& nl, const LogicalMosStack& stack,
                                  const DeviceCatalog& catalog)
{
    TransformOutcome out;
    NetlistTransaction transaction(nl);
    auto& working = transaction.Working();
    auto* subckt = working.find(stack.subckt);
    if (subckt == nullptr) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + stack.subckt + " 不存在"});
        return out;
    }
    auto* original = subckt->find(stack.original_instance);
    if (original == nullptr) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "Stack 计划对应的原 MOS 已不存在"});
        return out;
    }
    if (stack.stage_count < 2 ||
        stack.stage_instance_names.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.middle_nets.size() != static_cast<std::size_t>(stack.stage_count - 1) ||
        stack.gate_nets.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.bulk_nets.size() != static_cast<std::size_t>(stack.stage_count) ||
        stack.stage_params.size() != static_cast<std::size_t>(stack.stage_count)) {
        out.diags.push_back({DiagCode::BadParam, "LogicalMosStack 内容不完整"});
        return out;
    }
    if (stack.gate_policy != GatePolicy::SharedGate ||
        std::any_of(stack.gate_nets.begin(), stack.gate_nets.end(),
                    [&](const std::string& net) { return net != stack.original_gate_net; })) {
        out.diags.push_back({DiagCode::BadParam,
                            "当前Stack物化只允许所有级共用原Gate"});
        return out;
    }
    if (original->model != stack.master || original->params != stack.original_params) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "原 MOS 在计划生成后已发生变化，请重新规划 Stack"});
        return out;
    }
    const auto* descriptor = catalog.Find(stack.master);
    if (!engineeringMos(descriptor)) {
        out.diags.push_back({descriptor == nullptr ? DiagCode::UnknownModel : DiagCode::NotMos,
                            "Stack master 不是已登记的 MOS"});
        return out;
    }
    Diagnostic diagnostic;
    std::string drain;
    std::string gate;
    std::string source;
    std::string bulk;
    if (!(getTerminalNet(*original, catalog, TerminalRole::Drain, drain, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Gate, gate, diagnostic) &&
          getTerminalNet(*original, catalog, TerminalRole::Source, source, diagnostic) &&
          (descriptor->terminal_count == 3 ||
           getTerminalNet(*original, catalog, TerminalRole::Bulk, bulk, diagnostic)))) {
        out.diags.push_back(std::move(diagnostic));
        return out;
    }
    if (drain != stack.drain_net || gate != stack.original_gate_net ||
        source != stack.source_net || bulk != stack.original_bulk_net) {
        out.diags.push_back({DiagCode::TargetConflict,
                            "原 MOS 端口在计划生成后已发生变化，请重新规划 Stack"});
        return out;
    }
    for (std::size_t index = 1; index < stack.stage_instance_names.size(); ++index) {
        const auto& instanceName = stack.stage_instance_names[index];
        if (subckt->find(instanceName) != nullptr) {
            out.diags.push_back({DiagCode::TargetConflict,
                                "计划中的 Stack 实例名已被占用"});
            return out;
        }
    }
    for (const auto& middleNet : stack.middle_nets) {
        if (subckt->netRefCount(middleNet) != 0 ||
            std::find(subckt->pins.begin(), subckt->pins.end(), middleNet) != subckt->pins.end()) {
            out.diags.push_back({DiagCode::TargetConflict,
                                "计划中的 Stack 内部网络名已被占用"});
            return out;
        }
    }

    for (int stage = 0; stage < stack.stage_count; ++stage) {
        Instance instance;
        instance.name = stack.stage_instance_names[static_cast<std::size_t>(stage)];
        instance.model = stack.master;
        instance.params = stack.stage_params[static_cast<std::size_t>(stage)];
        instance.nets.resize(descriptor->terminal_count);
        const std::string stageDrain = stage == 0
            ? stack.drain_net : stack.middle_nets[static_cast<std::size_t>(stage - 1)];
        const std::string stageSource = stage == stack.stage_count - 1
            ? stack.source_net : stack.middle_nets[static_cast<std::size_t>(stage)];
        const bool bound = descriptor->terminal_count == 3
            ? (setTerminalNet(instance, catalog, TerminalRole::Drain, stageDrain, diagnostic) &&
               setTerminalNet(instance, catalog, TerminalRole::Gate, stack.gate_nets[static_cast<std::size_t>(stage)], diagnostic) &&
               setTerminalNet(instance, catalog, TerminalRole::Source, stageSource, diagnostic))
            : writeMosNets(instance, catalog, stageDrain,
                          stack.gate_nets[static_cast<std::size_t>(stage)], stageSource,
                          stack.bulk_nets[static_cast<std::size_t>(stage)], diagnostic);
        if (!bound) {
            out.diags.push_back(std::move(diagnostic));
            return out;
        }
        if (std::any_of(instance.nets.begin(), instance.nets.end(),
                        [](const std::string& net) { return net.empty(); })) {
            out.diags.push_back({DiagCode::InvalidTerminalMap,
                                "Stack MOS 存在未绑定的必需端子"});
            return out;
        }
        if (stage == 0) {
            *original = instance;
            out.modifiedInstances.push_back(instance.name);
        } else {
            subckt->instances.push_back(instance);
            out.addedInstances.push_back(instance.name);
        }
    }
    out.addedNets.insert(out.addedNets.end(), stack.middle_nets.begin(), stack.middle_nets.end());
    out.parameter_groups = stack.sizing_groups;

    out.notes.push_back("Stack 逻辑对象已为仿真/导出物化；Drain侧保留原实例，所有级共用原Gate");
    transaction.Commit();
    return out;
}

// ---------- 内部工具 ----------

// 取目标 MOS 实例并做公共检查（模型登记、是 MOS、4 端子）
static Instance* fetchMos(Subckt* s, const std::string& target,
                          const ModelDb& db, DeviceKind& pol,
                          TransformOutcome& out) {
    Instance* m = s->find(target);
    if (!m) {
        out.diags.push_back({DiagCode::NotFound, "实例 " + target + " 不存在"});
        return nullptr;
    }
    auto mi = db.find(m->model);
    if (mi == db.end()) {
        out.diags.push_back({DiagCode::MissingInput,
                             "模型 " + m->model + " 未在 ModelDb 登记"});
        return nullptr;
    }
    pol = mi->second.kind;
    if (pol != DeviceKind::MosN && pol != DeviceKind::MosP) {
        out.diags.push_back({DiagCode::NotMos,
                             target + " 不是 MOS（model=" + m->model + "）"});
        return nullptr;
    }
    if ((int)m->nets.size() != 4) {
        out.diags.push_back({DiagCode::MissingInput,
                             target + " 端子数不是 4（D G S B）"});
        return nullptr;
    }
    return m;
}

// ---------- 1) cascode（同型 / 异型）----------

TransformOutcome applyCascode(Netlist& nl, const std::string& subName,
                              const std::string& target,
                              const CascodeOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " 不存在"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) return out;

    // 异型：新 master 必须同极性
    std::string master = o.newMaster.empty() ? m->model : o.newMaster;
    if (!o.newMaster.empty()) {
        auto it = db.find(master);
        if (it == db.end()) {
            out.diags.push_back({DiagCode::MissingInput,
                                 "新 master " + master + " 未登记"});
            return out;
        }
        auto pc = checkPolarity(pol, it->second.kind);
        if (isError(pc.code)) { out.diags.push_back(pc); return out; }
    }

    // headroom 校验（提供了工作点才做；估算值由调用方标注）
    if (o.op.valid) {
        double vxMin = std::fabs(o.vdsat1) + std::fabs(o.margin);
        auto hc = checkCascodeHeadroom(std::fabs(o.op.vds),
                                       o.vdsat1, o.vdsat2, o.margin, vxMin);
        if (isError(hc.code)) { out.diags.push_back(hc); return out; }
    }

    // 新管 bulk
    bool tieSrc = false;
    std::string bulkNet;
    auto bd = resolveBulk(pol, o.sourceTiedBulk, o.nmosBulkNet, m->nets[3],
                          tieSrc, bulkNet);
    if (isError(bd.code)) { out.diags.push_back(bd); return out; }

    // 结构改写：两种极性都加在原 Drain 侧，原 G/S/B 不变。
    const std::string dnet = m->nets[0];
    const std::string x = target + "_MID";
    const std::string vbias = o.biasNet.empty() ? "VBIAS_1" : o.biasNet;

    Instance m2;
    m2.name = target + "_CAS";
    m2.model = master;
    m2.params = m->params;                       // 初值 1:1 继承原管
    m2.nets = {dnet, vbias, x, tieSrc ? x : bulkNet};
    m->nets[0] = x;
    out.modifiedInstances.push_back(m->name);
    s->insertAfter(m->name, m2);
    out.addedInstances.push_back(m2.name);
    out.addedNets.push_back(x);
    out.addedNets.push_back(vbias);

    out.notes.push_back("VBIAS 网络 " + vbias +
                        " 由已登记的固定有源Mirror+Replica模板接管");
    return out;
}

// ---------- 2) MOS Source 串联电阻（旧演示入口） ----------

TransformOutcome applyResistor(Netlist& nl, const std::string& subName,
                               const std::string& target,
                               const ResistorOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " 不存在"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) return out;

    auto ri = db.find(o.resModel);
    if (ri == db.end() || ri->second.kind != DeviceKind::Resistor ||
        ri->second.terminalCount != 2) {
        out.diags.push_back({DiagCode::MissingInput,
                             "电阻模型 " + o.resModel + " 未登记或不是 2 端电阻"});
        return out;
    }
    if (o.rTarget <= 0.0) {
        out.diags.push_back({DiagCode::MissingInput,
                             "R 初值未提供"});
        return out;
    }
    // 搜索带校验：0.5~2 × rSeed
    if (o.rSeed > 0.0 &&
        (o.rTarget < 0.5 * o.rSeed || o.rTarget > 2.0 * o.rSeed)) {
        out.diags.push_back({DiagCode::BadParam,
                             "R 超出 0.5~2×Rseed 搜索带"});
        return out;
    }

    const std::string snet = m->nets[2];
    const std::string internal = target + "_RS_INT";
    m->nets[2] = internal;
    out.modifiedInstances.push_back(target);

    Instance r;
    r.name = target + "_RS";
    r.nets = {internal, snet};
    r.model = o.resModel;
    r.params["r"] = formatEngineering(snapToGrid(o.rTarget, o.grid));
    s->insertAfter(target, r);
    out.addedInstances.push_back(r.name);
    out.addedNets.push_back(internal);
    out.notes.push_back("保留原MOS，仅在Source路径串联电阻；阻值不由DC工作点自动推导");
    return out;
}

// ---------- 3) stack 串联（分级偏置）----------

TransformOutcome applyStack(Netlist& nl, const std::string& subName,
                            const std::string& target,
                            const StackOptions& o, const ModelDb& db) {
    TransformOutcome out;
    Subckt* s = nl.find(subName);
    if (!s) {
        out.diags.push_back({DiagCode::NotFound, "subckt " + subName + " 不存在"});
        return out;
    }
    if (o.n < 2 || o.n > 100) {
        out.diags.push_back({DiagCode::BadParam, "级数 N 须在 2~100"});
        return out;
    }
    DeviceKind pol;
    Instance* m = fetchMos(s, target, db, pol, out);
    if (!m) return out;
    // bulk 策略
    bool tieSrc = false;
    std::string bulkNet;
    auto bd = resolveBulk(pol, o.sourceTiedBulk, o.nmosBulkNet, m->nets[3],
                          tieSrc, bulkNet);
    if (isError(bd.code)) { out.diags.push_back(bd); return out; }

    const std::string dnet = m->nets[0];
    const std::string gnet = m->nets[1];
    const std::string snet = m->nets[2];
    const std::string masterModel = m->model;
    const auto savedParams = m->params;

    // 串联链按 Drain -> Source 记录：Drain侧保留原实例名，
    // 后续依次为 M0_S1...M0_S(N-1)，且全部Gate短接原Gate。
    std::vector<std::string> mid(o.n + 1);
    for (int k = 1; k < o.n; ++k) {
        mid[k] = target + "_MID" + std::to_string(k);
        out.addedNets.push_back(mid[k]);
    }
    for (int k = 0; k < o.n; ++k) {
        Instance stg;
        stg.name = k == 0 ? target : target + "_S" + std::to_string(k);
        stg.model = masterModel;
        stg.params = savedParams;
        std::string d = (k == 0) ? dnet : mid[k];
        std::string ss = (k == o.n - 1) ? snet : mid[k + 1];
        std::string b = tieSrc ? ss : bulkNet;
        stg.nets = {d, gnet, ss, b};
        if (k == 0) {
            *m = stg;
            out.modifiedInstances.push_back(target);
        } else {
            s->instances.push_back(stg);
            out.addedInstances.push_back(stg.name);
        }
    }

    std::ostringstream os;
    os << "stack N=" << o.n << "：Drain侧保留 " << target
       << "，其余级向Source端命名为 " << target
       << "_S1... ，所有Gate共用原网络 " << gnet;
    out.notes.push_back(os.str());
    return out;
}

} // namespace st
