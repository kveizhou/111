#include "st/Bias.h"

namespace st {

bool VoltageWindow::Contains(double value) const
{
    return Valid() && value >= minimum && value <= maximum;
}

double VoltageWindow::Midpoint() const
{
    return (minimum + maximum) / 2.0;
}

bool VoltageWindow::Valid() const
{
    return minimum <= maximum;
}

} // namespace st
