#include "st/Naming.h"

#include <stdexcept>

namespace st {

namespace {

void collectSubcktNames(const Subckt& subckt,
                        std::set<std::string>& instanceNames,
                        std::set<std::string>& netNames)
{
    netNames.insert(subckt.pins.begin(), subckt.pins.end());
    for (const auto& instance : subckt.instances) {
        instanceNames.insert(instance.name);
        netNames.insert(instance.nets.begin(), instance.nets.end());
    }
}

} // namespace

NameAllocator::NameAllocator(const Netlist& netlist, const std::string& subcktScope)
{
    for (const auto& subckt : netlist.subckts) {
        subcktNames_.insert(subckt.name);
        if (subcktScope.empty() || subckt.name == subcktScope) {
            collectSubcktNames(subckt, instanceNames_, netNames_);
        }
    }
    if (subcktScope.empty()) {
        for (const auto& instance : netlist.topInstances) {
            instanceNames_.insert(instance.name);
            netNames_.insert(instance.nets.begin(), instance.nets.end());
        }
    }
}

std::set<std::string>& NameAllocator::Names(NameKind kind)
{
    switch (kind) {
    case NameKind::Instance:
        return instanceNames_;
    case NameKind::Net:
        return netNames_;
    case NameKind::Subckt:
        return subcktNames_;
    }
    throw std::logic_error("unknown NameKind");
}

std::string NameAllocator::Allocate(NameKind kind, const std::string& base)
{
    auto& names = Names(kind);
    if (names.insert(base).second) {
        return base;
    }
    for (std::size_t suffix = 2;; ++suffix) {
        const auto candidate = base + "_" + std::to_string(suffix);
        if (names.insert(candidate).second) {
            return candidate;
        }
    }
}

} // namespace st
