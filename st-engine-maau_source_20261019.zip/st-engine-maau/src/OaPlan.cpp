#include "st/OaPlan.h"

#include <set>
#include <algorithm>

namespace st {

namespace {

bool complete(const CellViewRef& ref)
{
    return !ref.library.empty() && !ref.cell.empty() && !ref.view.empty();
}

std::string physicalKey(const CellViewRef& ref)
{
    return ref.storage_path + "\n" + ref.library + "\n" + ref.cell + "\n" + ref.view;
}

std::string roleName(TerminalRole role)
{
    switch (role) {
    case TerminalRole::Drain: return "Drain";
    case TerminalRole::Gate: return "Gate";
    case TerminalRole::Source: return "Source";
    case TerminalRole::Bulk: return "Bulk";
    case TerminalRole::Positive: return "Positive";
    case TerminalRole::Negative: return "Negative";
    case TerminalRole::Substrate: return "Substrate";
    case TerminalRole::Well: return "Well";
    case TerminalRole::Other: return "Other";
    }
    return "Other";
}

bool sameInstance(const Instance& left, const Instance& right)
{
    return left.model == right.model && left.nets == right.nets && left.params == right.params;
}

bool sameSubcktForOa(const Subckt& left, const Subckt& right)
{
    if (left.pins != right.pins || left.instances.size() != right.instances.size()) return false;
    for (const auto& instance : left.instances) {
        const auto* other = right.find(instance.name);
        if (other == nullptr || !sameInstance(instance, *other)) return false;
    }
    return true;
}

} // namespace

std::vector<Diagnostic> ValidateOaPlan(const OaMaterializationPlan& plan)
{
    std::vector<Diagnostic> diagnostics;
    if (!complete(plan.source) || !complete(plan.target)) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "源或目标 library/cell/view 不完整"});
        return diagnostics;
    }
    if (SamePhysicalCellView(plan.source, plan.target)) {
        diagnostics.push_back({DiagCode::SourceDesignProtected,
                               "Topology Variant 必须写入隔离目标，禁止覆盖源 cellview"});
        return diagnostics;
    }
    std::map<std::string, const OaCloneMapping*> clonesByPath;
    std::set<std::string> cloneTargets;
    if (plan.clone_map.empty()) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "缺少 clone-on-write 层级映射"});
    } else {
        for (const auto& mapping : plan.clone_map) {
            if (mapping.hierarchy_path.empty() || !complete(mapping.source) ||
                !complete(mapping.target) || SamePhysicalCellView(mapping.source, mapping.target)) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "clone-on-write 映射不完整或目标覆盖源 cellview"});
                continue;
            }
            if (!clonesByPath.emplace(mapping.hierarchy_path, &mapping).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "同一 hierarchy_path 存在重复 clone 映射"});
            }
            if (!cloneTargets.insert(physicalKey(mapping.target)).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "不同层级分支不能共用同一clone目标cellview"});
            }
        }
        const auto root = clonesByPath.find("/");
        if (root == clonesByPath.end() || !(root->second->source == plan.source) ||
            !(root->second->target == plan.target)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "根层级 clone 映射与计划 source/target 不一致"});
        }
        for (const auto& [path, mapping] : clonesByPath) {
            if (path == "/") {
                if (!mapping->parent_hierarchy_path.empty() ||
                    !mapping->parent_instance_name.empty()) {
                    diagnostics.push_back({DiagCode::OaPlanInvalid,
                                           "根层级clone不应包含父实例重绑定"});
                }
                continue;
            }
            if (mapping->parent_hierarchy_path.empty() ||
                mapping->parent_instance_name.empty() ||
                clonesByPath.count(mapping->parent_hierarchy_path) == 0) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "非根层级clone缺少已克隆父层级和实例重绑定契约"});
            }
        }
    }
    if (plan.preview.variant_id.empty() || plan.preview.parameter_set_id.empty() ||
        plan.preview.materializer_version.empty()) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "预览身份 variant/parameter-set/materializer 不完整"});
    }

    std::set<std::string> generatedIds;
    std::set<std::string> generatedPhysicalCells;
    std::set<std::string> generatedSymbolsUsed;
    for (const auto& instance : plan.create_instances) {
        generatedSymbolsUsed.insert(physicalKey(instance.master));
    }
    for (const auto& generated : plan.generated_cells) {
        const std::string scope = "/@generated/" + generated.package_id;
        if (generated.package_id.empty() || !generatedIds.insert(generated.package_id).second ||
            !complete(generated.schematic) || !complete(generated.symbol) ||
            generated.schematic.library != generated.symbol.library ||
            generated.schematic.cell != generated.symbol.cell ||
            generated.schematic.view != "schematic" || generated.symbol.view != "symbol" ||
            SamePhysicalCellView(generated.schematic, plan.source) ||
            !(generated.symbol_upper_right.x > generated.symbol_lower_left.x) ||
            !(generated.symbol_upper_right.y > generated.symbol_lower_left.y)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "生成子Cell的package id、schematic/symbol或symbol边界无效"});
            continue;
        }
        const auto cellKey = generated.schematic.storage_path + "\n" +
            generated.schematic.library + "\n" + generated.schematic.cell;
        if (!generatedPhysicalCells.insert(cellKey).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "不同封装不能写入同一个生成子Cell"});
        }
        if (generatedSymbolsUsed.count(physicalKey(generated.symbol)) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "生成子Cell的symbol没有被父原理图wrapper引用"});
        }
        std::map<std::string, std::map<std::string, std::string>> terminalsByInstance;
        std::set<std::string> nestedNames;
        for (const auto& instance : generated.create_instances) {
            if ((!instance.property_source_instance.empty() &&
                 (!(instance.property_source == plan.target) ||
                  !instance.allowed_extra_cdf_parameters.empty())) ||
                (instance.property_source_instance.empty() && complete(instance.property_source))) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "原属性复制只能来自隔离根图且不能放宽该实例参数校验"});
            }
            if (instance.hierarchy_path != scope || instance.name.empty() ||
                !complete(instance.master) || instance.expected_terminal_count == 0 ||
                instance.connections.size() != instance.expected_terminal_count ||
                !nestedNames.insert(instance.name).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "生成子Cell实例缺少固定scope、master、端子或名称唯一性"});
                continue;
            }
            std::set<std::string> terminals;
            for (const auto& connection : instance.connections) {
                if (connection.pdk_terminal.empty() || connection.net.empty() ||
                    !terminals.insert(connection.pdk_terminal).second) {
                    diagnostics.push_back({DiagCode::OaPlanInvalid,
                        "生成子Cell实例端子映射不完整或重复"});
                    break;
                }
                terminalsByInstance[instance.name][connection.pdk_terminal] = connection.net;
            }
        }
        std::set<std::string> portNames;
        for (const auto& port : generated.create_ports) {
            if (port.hierarchy_path != scope || port.name.empty() || port.net != port.name ||
                port.direction.empty() || !portNames.insert(port.name).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "生成子Cell端口必须位于固定scope且name/net一致并保持唯一"});
            }
        }
        if (generated.create_ports.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "生成子Cell必须创建可见端口"});
        }
        for (const auto& wire : generated.direct_wires) {
            const auto from = terminalsByInstance.find(wire.from_instance);
            const auto to = terminalsByInstance.find(wire.to_instance);
            if (wire.hierarchy_path != scope || wire.net.empty() ||
                from == terminalsByInstance.end() || to == terminalsByInstance.end() ||
                from->second.count(wire.from_terminal) == 0 ||
                to->second.count(wire.to_terminal) == 0 ||
                from->second.at(wire.from_terminal) != wire.net ||
                to->second.at(wire.to_terminal) != wire.net) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "生成子Cell点到点导线端点与网络不一致"});
            }
        }
        for (const auto& wire : generated.wires) {
            if (wire.hierarchy_path != scope || wire.net.empty() || wire.points.size() < 2) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "生成子Cell标签导线不完整"});
            }
        }
    }

    std::set<std::string> createdNames;
    std::map<std::string, std::map<std::string, std::string>> createdTerminalNets;
    for (const auto& instance : plan.create_instances) {
        if (instance.hierarchy_path.empty() || instance.name.empty() || !complete(instance.master) ||
            instance.connections.empty() || instance.expected_terminal_count == 0 ||
            instance.connections.size() != instance.expected_terminal_count) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "创建实例缺少层级、名称、master 或连接"});
            continue;
        }
        if (clonesByPath.count(instance.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "创建实例的 hierarchy_path 没有隔离 clone 映射"});
        }
        const auto scopedName = instance.hierarchy_path + ":" + instance.name;
        if (!createdNames.insert(scopedName).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "同一层级存在重复创建实例名 " + instance.name});
        }
        std::set<std::string> terminals;
        for (const auto& connection : instance.connections) {
            if (connection.semantic_terminal.empty() || connection.pdk_terminal.empty() ||
                connection.net.empty() || !terminals.insert(connection.pdk_terminal).second) {
                diagnostics.push_back({DiagCode::OaPlanInvalid,
                                       "实例 " + instance.name + " 的 terminal 映射不完整或重复"});
                break;
            }
            createdTerminalNets[scopedName][connection.pdk_terminal] = connection.net;
        }
    }
    std::set<std::string> directWireKeys;
    for (const auto& wire : plan.direct_wires) {
        if (wire.hierarchy_path.empty() || wire.net.empty() || wire.from_instance.empty() ||
            wire.from_terminal.empty() || wire.to_instance.empty() || wire.to_terminal.empty() ||
            (wire.from_instance == wire.to_instance &&
             wire.from_terminal == wire.to_terminal)) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "点到点导线缺少层级、网络或两端引脚"});
            continue;
        }
        if (clonesByPath.count(wire.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "点到点导线的 hierarchy_path 没有隔离 clone 映射"});
            continue;
        }
        const auto fromKey = wire.hierarchy_path + ":" + wire.from_instance;
        const auto toKey = wire.hierarchy_path + ":" + wire.to_instance;
        const auto from = createdTerminalNets.find(fromKey);
        const auto to = createdTerminalNets.find(toKey);
        if (from == createdTerminalNets.end() || to == createdTerminalNets.end() ||
            from->second.count(wire.from_terminal) == 0 ||
            to->second.count(wire.to_terminal) == 0 ||
            from->second.at(wire.from_terminal) != wire.net ||
            to->second.at(wire.to_terminal) != wire.net) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                "点到点导线 " + wire.net + " 的端点不是该网络上的新建实例引脚"});
            continue;
        }
        const auto directKey = fromKey + "." + wire.from_terminal + "->" + toKey + "." +
            wire.to_terminal + ":" + wire.net;
        if (!directWireKeys.insert(directKey).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "存在重复的点到点导线 " + wire.net});
        }
    }
    for (const auto& port : plan.create_ports) {
        if (port.hierarchy_path.empty() || port.name.empty() || port.direction.empty() ||
            port.net.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "新增端口契约不完整"});
        }
        if (clonesByPath.count(port.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "新增端口的 hierarchy_path 没有隔离 clone 映射"});
        }
    }
    for (const auto& wire : plan.wires) {
        if (wire.hierarchy_path.empty() || wire.net.empty() || wire.points.size() < 2) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "导线必须有层级、网络和至少两个点"});
        }
        if (clonesByPath.count(wire.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "导线的 hierarchy_path 没有隔离 clone 映射"});
        }
    }
    std::set<std::string> deletedNames;
    for (const auto& deletion : plan.delete_instances) {
        if (deletion.hierarchy_path.empty() || deletion.name.empty()) {
            diagnostics.push_back({DiagCode::OaPlanInvalid, "删除实例契约不完整"});
        }
        if (clonesByPath.count(deletion.hierarchy_path) == 0) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "删除实例的 hierarchy_path 没有隔离 clone 映射"});
        }
        if (!deletedNames.insert(deletion.hierarchy_path + ":" + deletion.name).second) {
            diagnostics.push_back({DiagCode::OaPlanInvalid,
                                   "同一层级存在重复删除实例 " + deletion.name});
        }
    }
    if (!plan.check_and_save) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
                               "正式 OA 物化计划必须执行 check/save"});
    }
    return diagnostics;
}

OaPlanBuildResult BuildOaMaterializationPlan(const Netlist& baseline,
                                             const Netlist& variant,
                                             const DeviceCatalog& catalog,
                                             const OaPlanBuildContext& context)
{
    OaPlanBuildResult result;
    auto& plan = result.plan;
    plan.source = context.source;
    plan.target = context.target;
    plan.clone_map = context.clone_map;
    plan.preview = context.preview;
    plan.wires = context.wires;

    for (const auto& variantSubckt : variant.subckts) {
        const auto* baseSubckt = baseline.find(variantSubckt.name);
        if (baseSubckt != nullptr && sameSubcktForOa(*baseSubckt, variantSubckt)) continue;
        const auto pathIt = context.hierarchy_by_subckt.find(variantSubckt.name);
        if (pathIt == context.hierarchy_by_subckt.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "subckt " + variantSubckt.name + " 缺少 hierarchy_path 映射"});
            continue;
        }
        const std::string& hierarchy = pathIt->second;
        if (baseSubckt == nullptr) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "当前版本不支持在OA计划中新建整个subckt"});
            continue;
        }
        std::set<std::string> baselineNets(baseSubckt->pins.begin(), baseSubckt->pins.end());
        for (const auto& instance : baseSubckt->instances) {
            baselineNets.insert(instance.nets.begin(), instance.nets.end());
        }
        struct CreatedEndpoint {
            std::string instance;
            std::string terminal;
            std::string semantic;
        };
        std::map<std::string, std::vector<CreatedEndpoint>> createdEndpointsByNet;
        for (const auto& original : baseSubckt->instances) {
            const auto* changed = variantSubckt.find(original.name);
            if (changed == nullptr || !sameInstance(original, *changed)) {
                plan.delete_instances.push_back({ hierarchy, original.name });
            }
        }
        for (const auto& changed : variantSubckt.instances) {
            const auto* original = baseSubckt->find(changed.name);
            if (original != nullptr && sameInstance(*original, changed)) continue;
            const auto* descriptor = catalog.Find(changed.model);
            if (descriptor == nullptr || descriptor->oa_library.empty() ||
                descriptor->oa_cell.empty() || descriptor->oa_view.empty() ||
                descriptor->terminal_names_by_index.size() != changed.nets.size()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "器件 " + changed.model + " 缺少OA master或完整terminalOrder"});
                continue;
            }
            const std::string locationKey = hierarchy + ":" + changed.name;
            const auto location = context.locations.find(locationKey);
            if (location == context.locations.end()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "实例 " + locationKey + " 缺少明确放置坐标"});
                continue;
            }
            OaCreateInstance create;
            create.hierarchy_path = hierarchy;
            create.name = changed.name;
            create.master = { descriptor->oa_library, descriptor->oa_cell,
                              descriptor->oa_view };
            create.location = location->second;
            create.expected_terminal_count = descriptor->terminal_count;
            create.cdf_parameters = changed.params;

            std::vector<TerminalRole> roles(descriptor->terminal_count, TerminalRole::Other);
            if (descriptor->terminal_roles_by_index.size() == descriptor->terminal_count) {
                roles = descriptor->terminal_roles_by_index;
            } else {
                for (const auto& [role, index] : descriptor->terminal_index) roles[index] = role;
            }
            for (std::size_t index = 0; index < changed.nets.size(); ++index) {
                const auto semantic = roleName(roles[index]);
                const auto& terminal = descriptor->terminal_names_by_index[index];
                create.connections.push_back({ semantic, terminal, changed.nets[index] });
                createdEndpointsByNet[changed.nets[index]].push_back(
                    {changed.name, terminal, semantic});
            }
            for (const auto& connection : create.connections) {
                const bool hasVisibleWire = std::any_of(context.wires.begin(), context.wires.end(),
                    [&](const OaWire& wire) {
                        return wire.hierarchy_path == hierarchy &&
                            wire.net == connection.net && wire.points.size() >= 2;
                    });
                if (!hasVisibleWire) {
                    result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                        "实例 " + locationKey + " 的端子网络 " + connection.net +
                        " 缺少局部布局模板导线"});
                }
            }
            plan.create_instances.push_back(std::move(create));
        }

        for (const auto& [net, endpoints] : createdEndpointsByNet) {
            if (baselineNets.count(net) != 0 || endpoints.size() < 2) continue;
            const bool seriesNode = std::all_of(endpoints.begin(), endpoints.end(),
                [](const CreatedEndpoint& endpoint) {
                    return endpoint.semantic == "Drain" ||
                        endpoint.semantic == "Source" ||
                        endpoint.semantic == "Positive" ||
                        endpoint.semantic == "Negative";
                });
            if (!seriesNode) continue;
            for (std::size_t index = 1; index < endpoints.size(); ++index) {
                plan.direct_wires.push_back({
                    hierarchy, net,
                    endpoints[index - 1].instance, endpoints[index - 1].terminal,
                    endpoints[index].instance, endpoints[index].terminal
                });
            }
        }

        for (const auto& pin : variantSubckt.pins) {
            if (std::find(baseSubckt->pins.begin(), baseSubckt->pins.end(), pin) !=
                baseSubckt->pins.end()) continue;
            const std::string key = hierarchy + ":" + pin;
            const auto direction = context.port_directions.find(key);
            const auto location = context.locations.find(key);
            if (direction == context.port_directions.end() || location == context.locations.end()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "新增端口 " + key + " 缺少方向或放置坐标"});
                continue;
            }
            plan.create_ports.push_back({ hierarchy, pin, direction->second, pin,
                                          location->second });
        }
    }
    const auto validation = ValidateOaPlan(plan);
    result.diagnostics.insert(result.diagnostics.end(), validation.begin(), validation.end());
    return result;
}

} // namespace st
