#include "st/ResistorStress.h"

#include <cmath>

namespace st {
namespace {

bool endsWithToken(const std::string& text, const std::string& suffix)
{
    if (suffix.empty() || text.size() < suffix.size() ||
        text.compare(text.size() - suffix.size(), suffix.size(), suffix) != 0) {
        return false;
    }
    if (text.size() == suffix.size()) return true;
    const char separator = text[text.size() - suffix.size() - 1];
    return separator == '.' || separator == '/' || separator == ':';
}

bool matches(const std::string& name, const ExpectedResistor& expected)
{
    if (!endsWithToken(name, expected.leaf_name)) return false;
    if (expected.container_instance.empty()) return true;
    const auto leafStart = name.size() - expected.leaf_name.size();
    if (leafStart == 0) return false;
    const auto parent = name.substr(0, leafStart - 1);
    return endsWithToken(parent, expected.container_instance);
}

} // namespace

ResistorStressResult EvaluateResistorStress(
    const OperatingPointSnapshot& snapshot,
    const ExpectedResistor& expected)
{
    ResistorStressResult result;
    if (expected.leaf_name.empty() || expected.master.empty()) {
        result.failed_constraint = "resistor_role_incomplete";
        return result;
    }
    const ResistorOperatingPoint* matched = nullptr;
    for (const auto& [name, point] : snapshot.resistors) {
        if (!matches(name, expected)) continue;
        if (matched != nullptr) {
            result.failed_constraint = "resistor_op_ambiguous";
            return result;
        }
        matched = &point;
    }
    if (matched == nullptr) {
        result.failed_constraint = "resistor_op_missing";
        return result;
    }
    if (matched->master != expected.master) {
        result.failed_constraint = "resistor_master";
        return result;
    }
    result.voltage = std::fabs(matched->vpos - matched->vneg);
    result.power = std::fabs((matched->vpos - matched->vneg) * matched->current);
    result.current = std::fabs(matched->current);
    if (matched->geometry.empty() || !std::isfinite(matched->vpos) ||
        !std::isfinite(matched->vneg) || !std::isfinite(matched->current) ||
        !std::isfinite(result.voltage) || !std::isfinite(result.power) ||
        !std::isfinite(result.current)) {
        result.failed_constraint = "resistor_op_invalid";
        return result;
    }
    result.measurements_available = true;
    const double ratings[] = {matched->max_voltage, matched->max_power,
                              matched->max_current};
    const char* names[] = {"resistor_voltage", "resistor_power", "resistor_current"};
    bool anyKnown = false;
    for (std::size_t index = 0; index < 3; ++index) {
        if (!std::isfinite(ratings[index]) || ratings[index] < 0.0) {
            result.failed_constraint = "resistor_rating_invalid";
            return result;
        }
        if (ratings[index] == 0.0) result.unverified_constraints.push_back(names[index]);
        else anyKnown = true;
    }
    const bool complete = matched->max_voltage > 0.0 &&
        (matched->max_power > 0.0 || matched->max_current > 0.0);
    if ((anyKnown && (matched->rating_source.empty() || matched->rating_source == "-")) ||
        (!expected.experimental_dc && !complete)) {
        result.failed_constraint = "resistor_rating_missing";
        return result;
    }
    if (complete && !expected.experimental_dc) result.unverified_constraints.clear();
    if (matched->max_voltage > 0.0 && result.voltage > matched->max_voltage) {
        result.failed_constraint = "resistor_voltage";
    } else if (matched->max_power > 0.0 && result.power > matched->max_power) {
        result.failed_constraint = "resistor_power";
    } else if (matched->max_current > 0.0 && result.current > matched->max_current) {
        result.failed_constraint = "resistor_current";
    } else {
        result.ok = true;
        result.reliability_verified = complete && !expected.experimental_dc;
    }
    return result;
}

} // namespace st
