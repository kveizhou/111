#include "st/ChangeSet.h"
#include "st/Transaction.h"

#include <algorithm>
#include <utility>

namespace st {

std::string InstancePath::Canonical() const
{
    std::string result;
    if (!hierarchy.empty()) {
        result += hierarchy;
        if (result.back() != '/') {
            result.push_back('/');
        }
    }
    result += subckt;
    result.push_back('/');
    result += instance;
    return result;
}

namespace {

bool validateRequest(const TransformRequest& request, Diagnostic& diagnostic)
{
    if (request.operation_id.empty()) {
        diagnostic = {DiagCode::MissingInput, "operation_id 不能为空"};
        return false;
    }
    if (request.target.subckt.empty() || request.target.instance.empty()) {
        diagnostic = {DiagCode::MissingInput, "目标 subckt 和 instance 不能为空"};
        return false;
    }
    if (std::holds_alternative<std::monostate>(request.payload)) {
        diagnostic = {DiagCode::MissingInput, "确认变换必须保存完整工程 payload"};
        return false;
    }
    auto targetMatches = [&request](const auto& payload) {
        return payload.subckt == request.target.subckt &&
            payload.target == request.target.instance;
    };
    if (const auto* payload = std::get_if<CascodeTransformRequest>(&request.payload)) {
        if ((request.type != TransformType::SameTypeCascode &&
             request.type != TransformType::CrossFlavorCascode) || !targetMatches(*payload)) {
            diagnostic = {DiagCode::BadParam, "Cascode payload 与操作类型或目标不一致"};
            return false;
        }
        if (request.type == TransformType::SameTypeCascode && !payload->new_master.empty()) {
            diagnostic = {DiagCode::BadParam,
                          "同型 Cascode 不允许指定不同 master"};
            return false;
        }
        if (request.type == TransformType::CrossFlavorCascode && payload->new_master.empty()) {
            diagnostic = {DiagCode::BadParam, "跨 Flavor Cascode 必须保存目标 master"};
            return false;
        }
    } else if (const auto* payload = std::get_if<ResistorTransformRequest>(&request.payload)) {
        if (request.type != TransformType::AddSourceResistor || !targetMatches(*payload)) {
            diagnostic = {DiagCode::BadParam, "Source串联电阻 payload 与操作类型或目标不一致"};
            return false;
        }
    } else if (const auto* payload = std::get_if<StackTransformRequest>(&request.payload)) {
        if (request.type != TransformType::MosStack || !targetMatches(*payload) ||
            payload->stage_count < 2 || payload->stage_count > 100) {
            diagnostic = {DiagCode::BadParam, "Stack payload 与操作类型、目标或级数不一致"};
            return false;
        }
    }
    diagnostic = {};
    return true;
}

bool hasError(const std::vector<Diagnostic>& diagnostics)
{
    return std::any_of(diagnostics.begin(), diagnostics.end(),
        [](const Diagnostic& diagnostic) { return isError(diagnostic.code); });
}

} // namespace

bool ChangeSet::Confirm(const TransformRequest& request, Diagnostic& diagnostic)
{
    if (!validateRequest(request, diagnostic)) {
        return false;
    }
    for (const auto& existing : changes_) {
        if (existing.request.operation_id == request.operation_id) {
            diagnostic = {DiagCode::DuplicateOperation,
                          "operation id " + request.operation_id + " 已存在"};
            return false;
        }
        if (existing.request.target.Canonical() == request.target.Canonical()) {
            diagnostic = {DiagCode::TargetConflict,
                          "目标 " + request.target.Canonical() + " 已被操作 " +
                              existing.request.operation_id + " 使用"};
            return false;
        }
    }
    changes_.push_back({request, changes_.size()});
    diagnostic = {};
    return true;
}

bool ChangeSet::UndoLast()
{
    if (changes_.empty()) {
        return false;
    }
    changes_.pop_back();
    return true;
}

void ChangeSet::Fresh()
{
    changes_.clear();
}

bool ChangeSet::Empty() const
{
    return changes_.empty();
}

std::size_t ChangeSet::Size() const
{
    return changes_.size();
}

const std::vector<ConfirmedChange>& ChangeSet::Changes() const
{
    return changes_;
}

ReplayResult ChangeSet::Replay(const Netlist& base, Netlist& output,
                               const ChangeApplier& apply) const
{
    ReplayResult result;
    Netlist candidate = base;
    NetlistTransaction transaction(candidate);

    for (const auto& change : changes_) {
        auto diagnostics = apply(transaction.Working(), change.request);
        result.diagnostics.insert(result.diagnostics.end(), diagnostics.begin(), diagnostics.end());
        if (hasError(diagnostics)) {
            result.failed_operation_id = change.request.operation_id;
            return result;
        }
        result.applied_operation_ids.push_back(change.request.operation_id);
    }

    transaction.Commit();
    output = std::move(candidate);
    result.ok = true;
    return result;
}

ReplayResult ChangeSet::Generate(const Netlist& base, Netlist& output,
                                 const DeviceCatalog& catalog) const
{
    ReplayResult result;
    Netlist candidate = base;
    for (const auto& change : changes_) {
        TransformOutcome outcome;
        if (const auto* request = std::get_if<CascodeTransformRequest>(&change.request.payload)) {
            if (change.request.type == TransformType::CrossFlavorCascode) {
                const auto* owner = candidate.find(request->subckt);
                const auto* original = owner == nullptr ? nullptr : owner->find(request->target);
                if (original != nullptr && original->model == request->new_master) {
                    outcome.diags.push_back({DiagCode::DeviceIncompatible,
                        "跨 Flavor Cascode 的新增 master 必须与原 master 不同"});
                } else {
                    outcome = applyCascode(candidate, *request, catalog);
                }
            } else {
                outcome = applyCascode(candidate, *request, catalog);
            }
        } else if (const auto* request =
                       std::get_if<ResistorTransformRequest>(&change.request.payload)) {
            outcome = applyResistor(candidate, *request, catalog);
        } else if (const auto* request =
                       std::get_if<StackTransformRequest>(&change.request.payload)) {
            const auto stack = planStack(candidate, *request, catalog);
            if (!stack.ok()) {
                outcome.diags = stack.diags;
            } else {
                outcome = materializeStack(candidate, stack.stack, catalog);
            }
        } else {
            outcome.diags.push_back({DiagCode::MissingInput,
                                     "操作缺少完整工程 payload"});
        }
        result.diagnostics.insert(result.diagnostics.end(),
            outcome.diags.begin(), outcome.diags.end());
        result.outcomes.push_back(outcome);
        if (!outcome.ok()) {
            result.failed_operation_id = change.request.operation_id;
            return result;
        }
        result.iq_delta += outcome.iq_delta;
        result.bias_costs.insert(result.bias_costs.end(),
                                 outcome.bias_costs.begin(), outcome.bias_costs.end());
        for (const auto& [name, instances] : outcome.parameter_groups) {
            if (!result.parameter_groups.emplace(name, instances).second) {
                result.diagnostics.push_back({DiagCode::TargetConflict,
                    "不同操作产生了重复参数组 " + name});
                result.failed_operation_id = change.request.operation_id;
                return result;
            }
        }
        result.applied_operation_ids.push_back(change.request.operation_id);
    }
    output = std::move(candidate);
    result.ok = true;
    return result;
}

} // namespace st
