// =============================================================
// Netlist.cpp — spectre 网表子集的解析与发射
// =============================================================
#include "st/Netlist.h"

#include <sstream>
#include <cctype>
#include <cmath>
#include <algorithm>

namespace st {

namespace {

Diagnostic invalidTerminalMap(const std::string& master, const std::string& reason)
{
    return {DiagCode::InvalidTerminalMap,
            "器件 " + master + " 的端子映射无效：" + reason};
}

} // namespace

bool DeviceCatalog::Add(const DeviceDescriptor& descriptor, Diagnostic& diagnostic)
{
    diagnostic = {};
    if (descriptor.master.empty()) {
        diagnostic = invalidTerminalMap("<empty>", "master 为空");
        return false;
    }
    if (descriptor.terminal_count == 0) {
        diagnostic = invalidTerminalMap(descriptor.master, "terminal_count 为 0");
        return false;
    }
    if ((!descriptor.terminal_names_by_index.empty() &&
         descriptor.terminal_names_by_index.size() != descriptor.terminal_count) ||
        (!descriptor.terminal_roles_by_index.empty() &&
         descriptor.terminal_roles_by_index.size() != descriptor.terminal_count)) {
        diagnostic = invalidTerminalMap(descriptor.master,
                                        "OA terminal名称/语义数量与terminal_count不一致");
        return false;
    }
    if (!descriptor.terminal_names_by_index.empty()) {
        std::set<std::string> terminalNames;
        for (const auto& name : descriptor.terminal_names_by_index) {
            if (name.empty() || !terminalNames.insert(name).second) {
                diagnostic = invalidTerminalMap(descriptor.master,
                                                "OA terminal名称为空或重复");
                return false;
            }
        }
    }

    std::set<std::size_t> usedIndices;
    for (const auto& binding : descriptor.terminal_index) {
        const auto index = binding.second;
        if (index >= descriptor.terminal_count) {
            diagnostic = invalidTerminalMap(descriptor.master, "端子下标越界");
            return false;
        }
        if (!usedIndices.insert(index).second) {
            diagnostic = invalidTerminalMap(descriptor.master, "多个端子语义映射到同一下标");
            return false;
        }
        if (!descriptor.terminal_roles_by_index.empty() &&
            descriptor.terminal_roles_by_index[index] != binding.first) {
            diagnostic = invalidTerminalMap(descriptor.master,
                                            "terminal_index与物理顺序语义相互矛盾");
            return false;
        }
    }

    descriptors_[descriptor.master] = descriptor;
    return true;
}

const DeviceDescriptor* DeviceCatalog::Find(const std::string& master) const
{
    const auto found = descriptors_.find(master);
    return found == descriptors_.end() ? nullptr : &found->second;
}

const std::map<std::string, DeviceDescriptor>& DeviceCatalog::Descriptors() const
{
    return descriptors_;
}

bool DeviceCatalog::ResolveTerminal(const std::string& master, TerminalRole role,
                                    std::size_t actualTerminalCount, std::size_t& index,
                                    Diagnostic& diagnostic) const
{
    diagnostic = {};
    const auto* descriptor = Find(master);
    if (descriptor == nullptr) {
        diagnostic = {DiagCode::UnknownModel,
                      "器件 master " + master + " 未在 DeviceCatalog 登记"};
        return false;
    }
    if (descriptor->terminal_count != actualTerminalCount) {
        diagnostic = invalidTerminalMap(master, "实例端子数与 PDK 描述不一致");
        return false;
    }
    const auto found = descriptor->terminal_index.find(role);
    if (found == descriptor->terminal_index.end()) {
        diagnostic = invalidTerminalMap(master, "未提供所需端子语义");
        return false;
    }
    index = found->second;
    return true;
}

bool getTerminalNet(const Instance& instance, const DeviceCatalog& catalog,
                    TerminalRole role, std::string& net, Diagnostic& diagnostic)
{
    std::size_t index = 0;
    if (!catalog.ResolveTerminal(instance.model, role, instance.nets.size(), index, diagnostic)) {
        return false;
    }
    net = instance.nets[index];
    return true;
}

bool setTerminalNet(Instance& instance, const DeviceCatalog& catalog,
                    TerminalRole role, const std::string& net, Diagnostic& diagnostic)
{
    std::size_t index = 0;
    if (!catalog.ResolveTerminal(instance.model, role, instance.nets.size(), index, diagnostic)) {
        return false;
    }
    instance.nets[index] = net;
    return true;
}

// ---------- Subckt / Netlist 成员 ----------

Instance* Subckt::find(const std::string& instName) {
    for (auto& i : instances) if (i.name == instName) return &i;
    return nullptr;
}
const Instance* Subckt::find(const std::string& instName) const {
    for (const auto& i : instances) if (i.name == instName) return &i;
    return nullptr;
}
bool Subckt::remove(const std::string& instName) {
    auto it = std::find_if(instances.begin(), instances.end(),
        [&](const Instance& i) { return i.name == instName; });
    if (it == instances.end()) return false;
    instances.erase(it);
    return true;
}
int Subckt::netRefCount(const std::string& net) const {
    int n = 0;
    for (const auto& i : instances)
        for (const auto& t : i.nets)
            if (t == net) ++n;
    return n;
}
void Subckt::insertAfter(const std::string& refName, const Instance& inst) {
    auto it = std::find_if(instances.begin(), instances.end(),
        [&](const Instance& i) { return i.name == refName; });
    if (it == instances.end()) instances.push_back(inst);
    else instances.insert(it + 1, inst);
}
Subckt* Netlist::find(const std::string& subName) {
    for (auto& s : subckts) if (s.name == subName) return &s;
    return nullptr;
}
const Subckt* Netlist::find(const std::string& subName) const {
    for (const auto& s : subckts) if (s.name == subName) return &s;
    return nullptr;
}

// ---------- 解析 ----------

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static std::string stripComment(const std::string& line) {
    // spectre 行注释为 //（本网表子集不处理字符串内 // 的极端情形）
    auto p = line.find("//");
    return p == std::string::npos ? line : line.substr(0, p);
}

static std::string firstTokenLower(const std::string& line) {
    std::istringstream is(line);
    std::string t;
    is >> t;
    std::transform(t.begin(), t.end(), t.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    return t;
}

// 把物理行合成逻辑行：行首 + 或上一行尾 \ 表示续行
static std::vector<std::string> logicalLines(const std::string& text) {
    std::vector<std::string> out;
    std::istringstream is(text);
    std::string raw;
    while (std::getline(is, raw)) {
        if (!raw.empty() && raw.back() == '\r') raw.pop_back();
        std::string line = trim(stripComment(raw));
        if (line.empty()) continue;
        bool plusCont = (line[0] == '+');
        if (plusCont) line = trim(line.substr(1));
        if (line.empty()) continue;
        if (plusCont && !out.empty()) {
            out.back() += " " + line;               // 行首 + 续行
        } else if (!out.empty() && !out.back().empty() &&
                   out.back().back() == '\\') {
            out.back().pop_back();                  // 行尾 \ 续行
            out.back() += " " + line;
        } else {
            out.push_back(line);
        }
    }
    for (auto& l : out)
        if (!l.empty() && l.back() == '\\') l.pop_back();
    return out;
}

// 解析一行实例：name (n1 n2 ...) model k=v ...
static bool parseInstance(const std::string& line, Instance& inst) {
    auto lp = line.find('(');
    if (lp == std::string::npos) return false;
    auto rp = line.find(')', lp);
    if (rp == std::string::npos) return false;
    inst.name = trim(line.substr(0, lp));
    if (inst.name.empty()) return false;
    std::istringstream ns(line.substr(lp + 1, rp - lp - 1));
    std::string tok;
    while (ns >> tok) inst.nets.push_back(tok);
    std::string rest = trim(line.substr(rp + 1));
    std::istringstream rs(rest);
    if (!(rs >> inst.model)) return false;
    while (rs >> tok) {
        auto eq = tok.find('=');
        if (eq == std::string::npos) continue;
        std::string k = tok.substr(0, eq), v = tok.substr(eq + 1);
        // 参数值可能含带空格的括号表达式，拼到括号配平为止
        int bal = 0;
        for (char c : v) { if (c == '(') ++bal; if (c == ')') --bal; }
        while (bal > 0 && (rs >> tok)) {
            v += " " + tok;
            for (char c : tok) { if (c == '(') ++bal; if (c == ')') --bal; }
        }
        inst.params[k] = v;
    }
    return true;
}

// 关键字行（非实例）：按原文存进 preamble 或 subckt 参数
static bool isKeywordLine(const std::string& lowerTok) {
    static const char* kws[] = {
        "subckt", "ends", "parameters", "model", "include", "ahdl_include",
        "simulatoroptions", "lang", "global", "save", "options", "ic",
        "nodeset", "alter", "paramset", "inline"
    };
    for (auto* k : kws) if (lowerTok == k) return true;
    return false;
}

Netlist parseSpectre(const std::string& text, std::vector<Diagnostic>& diags) {
    Netlist nl;
    auto lines = logicalLines(text);
    Subckt* cur = nullptr;
    for (const auto& line : lines) {
        std::string kw = firstTokenLower(line);
        if (kw == "subckt") {
            std::istringstream is(line.substr(6));
            Subckt s;
            is >> s.name;
            std::string p;
            while (is >> p) s.pins.push_back(p);
            nl.subckts.push_back(std::move(s));
            cur = &nl.subckts.back();
            continue;
        }
        if (kw == "ends") { cur = nullptr; continue; }
        if (kw == "parameters" && cur) {
            // parameters a=1 b=2 ... 记入 subckt 参数
            std::istringstream is(line.substr(10));
            std::string tok;
            while (is >> tok) {
                auto eq = tok.find('=');
                if (eq != std::string::npos)
                    cur->params[tok.substr(0, eq)] = tok.substr(eq + 1);
            }
            continue;
        }
        if (isKeywordLine(kw)) {
            if (cur) cur->bodyDirectives.push_back(line);
            else nl.preamble.push_back(line);
            continue;
        }

        Instance inst;
        if (parseInstance(line, inst)) {
            if (cur) cur->instances.push_back(std::move(inst));
            else nl.topInstances.push_back(std::move(inst));
        } else {
            // 无法识别的行保留在原层级，不能把局部语句搬到全局。
            if (cur) cur->bodyDirectives.push_back(line);
            else nl.preamble.push_back(line);
        }
    }
    if (cur != nullptr)
        diags.push_back({DiagCode::BadParam, "subckt " + cur->name + " 缺少 ends 收尾"});
    return nl;
}

// ---------- 发射 ----------

static void emitInstance(std::ostringstream& os, const Instance& i) {
    os << "    " << i.name << " (";
    for (size_t k = 0; k < i.nets.size(); ++k) os << (k ? " " : "") << i.nets[k];
    os << ") " << i.model;
    std::string line;
    for (const auto& [k, v] : i.params) {
        std::string kv = " " + k + "=" + v;
        if (line.size() + kv.size() > 96 && !line.empty()) {
            os << line << "\n+ ";   // spectre 行首 + 续行
            line.clear();
        }
        line += kv;
    }
    os << line << "\n";
}

std::string emitSpectre(const Netlist& nl) {
    std::ostringstream os;
    for (const auto& p : nl.preamble) os << p << "\n";
    for (const auto& s : nl.subckts) {
        os << "subckt " << s.name;
        for (const auto& pin : s.pins) os << " " << pin;
        os << "\n";
        if (!s.params.empty()) {
            os << "    parameters";
            for (const auto& parameter : s.params) {
                os << " " << parameter.first << "=" << parameter.second;
            }
            os << "\n";
        }
        for (const auto& directive : s.bodyDirectives) {
            os << "    " << directive << "\n";
        }
        for (const auto& i : s.instances) emitInstance(os, i);
        os << "ends " << s.name << "\n";
    }
    for (const auto& i : nl.topInstances) emitInstance(os, i);
    return os.str();
}

// ---------- 数值工具 ----------

double parseSuffixValue(const std::string& s, bool& ok) {
    ok = false;
    if (s.empty()) return 0.0;
    char* end = nullptr;
    double v = std::strtod(s.c_str(), &end);
    if (end == s.c_str()) return 0.0;
    std::string suf(end);
    // Spectre/CDF distinguishes mega (M) from milli (m). Preserve that
    // distinction before normalizing the other supported suffix spellings.
    if (suf == "M") suf = "meg";
    std::transform(suf.begin(), suf.end(), suf.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    double mul = 1.0;
    if (suf.empty()) mul = 1.0;
    else if (suf == "meg") mul = 1e6;   // 必须先于 "m"
    else if (suf == "f") mul = 1e-15;
    else if (suf == "p") mul = 1e-12;
    else if (suf == "n") mul = 1e-9;
    else if (suf == "u") mul = 1e-6;
    else if (suf == "m") mul = 1e-3;
    else if (suf == "k") mul = 1e3;
    else if (suf == "g") mul = 1e9;
    else return 0.0;
    ok = true;
    return v * mul;
}

std::string formatEngineering(double v) {
    if (v == 0.0) return "0";
    struct { double mul; const char* suf; } tbl[] = {
        {1e9, "g"}, {1e6, "meg"}, {1e3, "k"}, {1.0, ""},
        {1e-3, "m"}, {1e-6, "u"}, {1e-9, "n"}, {1e-12, "p"},
    };
    double a = std::fabs(v);
    for (const auto& t : tbl) {
        if (a >= t.mul * 0.9995) {
            std::ostringstream os;
            os.precision(6);
            os << v / t.mul << t.suf;
            return os.str();
        }
    }
    std::ostringstream os;
    os.precision(6);
    os << v;
    return os.str();
}

} // namespace st
