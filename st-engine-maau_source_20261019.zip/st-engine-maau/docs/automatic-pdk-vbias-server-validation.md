# 自动 PDK VBIAS 求解 · 真实服务器验收

本文档是"调优支持器件串联和结构调整"中 **FixedBias Cascode 自动 VBIAS
求解**特性的真实服务器验收依据。逐条命令见
`docs/023-026结构变换独立测试命令.md`（下称"023-026 文档"）；本文档规定
验收口径：闭环顺序、产物清单、失败场景判定和最终成功标准。当前只安排已知真实 Capless 的首个目标实验；其余架构的示例命令不是已验证 Case。

## 一、验证边界（先读）

2026-10-07 默认入口已纠正为独立项目：输入本次原始 PDK 路径，解析实际 OA/CDF/模型，直接用 OCEAN/Spectre 执行工作点。部署与输入格式见 `docs/standalone-pdk-server-validation.md`。`integration/maau` 仅是可选历史接入，Maau 软件、Case Registry 和原生运行时不是验收前置条件。
用户报告旧 Capless 的 OA 读取、封装及回读命令已通过，继续复用该后端。
下述 `planned_not_run` 指本轮新增扫描/自动 VBIAS/DC/PVT 验收，不能否定旧路径的用户报告。

- 本地（开发机）已验证：C++ 编译、四类结构算法、自动求解器的候选扫描/
  排名/复验逻辑、名义 DC 检查编排、多操作封装隔离、CLI 工作流、回读比较
  ——全部基于 Fake 后端与 Fake 直流评估宿主。2026-10-06 本地 20 个测试程序全绿
  **不代表**真实 Virtuoso/Spectre/PDK 通过。
- 真实服务器上的一切项目（真实 PDK 扫描、真实 Spectre 工作点、真实
  schematic 物化与回读）在收到服务器证据前均为 `planned_not_run`。
- 任何一步不允许用"脚本已生成""原理图能打开"充当通过；必须返回命令、
  退出码、日志路径和下列产物文件。

## 二、generate 自动闭环顺序

一次 `generate` 必须按以下顺序自动完成，任何一步失败即停止且不发布：

```text
1. scan-pdk 重扫：重新扫描真实 PDK，与 inspect 时会话 Manifest 的
   pdk_version 和 catalog_hash 同时比对；任一漂移即拒绝。
2. 基线直流工作点：对 DUT 跑名义 Corner 的直流 OP，产物写入
   analysis/baseline_op/ 与 analysis/baseline_op.json；身份（DUT/Bench
   哈希、simulator、corner）一致才复用已有结果。
3. 自动 VBIAS 求解：对每个 gate_policy=fixed 的 Cascode 操作，从
   analysis/pdk_catalog.json 生成模板候选。每个候选都完整装配
   "原管改线 + 真实新增 Cascode + 独立 VBIAS 模板"，经
   clone → materialize 物化成唯一临时 OA CellView（每候选独立目录
   analysis/candidates/candidate_NNN/，留档审计网表 flat_candidate.scs、
   plan.json、封装期望网表、父图/子 Cell 回读、validation.txt、identity.tsv、
   mos.tsv、resistor.tsv），回读逐项核对通过后运行 run-op；run-op 只接受
   候选 OA DUT 的 L/C/V，不存在文本网表旁路。
   按工作点、MOS/电阻可靠性与 Case 电流门禁筛选排名；
   全部轨迹写入 analysis/solver_trace.jsonl，逐操作结果写入
   analysis/resolved_parameters.json。配置了 --pvt-corners 时，对最优
   候选逐 Corner 重建复验，任一 Corner 失败都阻塞发布。
4. 全部操作 solved 才进入封装物化：功能封装 + 每操作独立 VBIAS 封装。
5. NominalDcCheck（stage=nominal_dc_check）：对 staging 变体再做一次
   名义直流检查（analysis/variant_op/），含所有新增 Source/VBIAS 电阻的
   实际端电压、支路电流与当前 PDK 几何/Corner/温度额定值；配置 PVT 时
   每个 Corner 在 `analysis/variant_pvt/<corner>/resistor.tsv` 重验。
6. 源图未变校验（verify_source）→ 父图与全部封装子 Cell 回读
   （regenerate_netlist / verify_roundtrip）→ 发布（publish_target）
   → stage=complete。
```

任何 Cascode 操作无解：保留非空 solver_trace.jsonl 和逐项拒绝原因，
**不写最终 OA 计划、不物化最终变体、不发布**；保留已生成的候选 OA 与证据，validation.txt 为
`stage=solve`、`ready_for_sizing=false`。

## 三、会话产物清单

每个会话 work 目录在成功 generate 后必须包含：

```text
before/core_before.scs              源 schematic 基线网表
before/mos_inventory.tsv            当前层 MOS 清单
before/device_catalog.tsv           PDK/CDF 器件目录
analysis/device_policy.tsv          本次 PDK 扫描导出的 OA 端序/CDF 策略
analysis/pdk_scan/inspect/           首次扫描原始 catalog、identity 和日志
analysis/pdk_scan/run_NNNN/          generate 每次重扫原始产物与日志
analysis/pdk_catalog.json           扫描出的模板器件目录
analysis/cross_flavor_candidates.json  同极性不同 master 候选（内部旧文件名）
analysis/baseline_op.json           基线直流工作点（含身份哈希）
analysis/baseline_op/               基线 OP 原始产物
analysis/candidates/candidate_NNN/  每候选独立目录：审计网表 flat_candidate.scs、
                                    plan.json、expected/core_expected.scs、roundtrip/、
                                    validation.txt、identity.tsv、mos.tsv、resistor.tsv；
                                    候选 OA CellView 本体在候选库中（每候选唯一 L/C/V，
                                    重复 generate 分配新编号，保留旧候选证据）
analysis/solver_trace.jsonl         逐候选、逐约束的求解轨迹
analysis/resolved_parameters.json   逐操作求解结果（模板/器件/参数/pvt）
analysis/variant_op/                派生变体名义 DC 检查产物，含 resistor.tsv
expected/core_expected.scs          期望网表
materialization/plan.json           SKILL/OA 差异计划
after/source_roundtrip.scs          源图保护回读
after/core_roundtrip.scs            派生父图回读
after/package_XXXX_*.scs            每个封装子 Cell 独立回读
reports/validation.txt              最终状态报告
logs/                               各后端阶段日志
```

候选回读的 `validation.txt` 必须为 `ok=true` 才会启动该候选的 `run-op`。
父图连接、master、端口或参数不符，以及子 Cell 缺失、额外层级/指令均拒绝。
具体宿主失败原因写入求解轨迹的 `host_message`，避免将 OA 问题只记作不收敛。

## 四、真实 Capless 优先覆盖

| 会话 | 变换类型 | LDO 架构 | 目标极性 |
|------|----------|----------|----------|
| 023 | 同型 Cascode | Capless（已知真实 Case） | NMOS |
| 024 | 同型 Cascode | CAP | PMOS |
| 025 | 不同 master Cascode | FVF | NMOS |
| 026 | 不同 master Cascode | RES | PMOS |

当前先执行 023；024～026 只有在取得真实 Case、Bench 和目标 MOS 后才安排。每个实际会话依次执行：inspect → 确认候选和目标实例 → confirm → generate →
查看 validation.txt → 查看 resolved_parameters.json → 查看
solver_trace.jsonl → grep 回读网表 → 打开功能封装 CellView → 打开独立
VBIAS CellView。命令全文见 023-026 文档；CAP/FVF/RES 的真实 Case 名未
登记前，对应会话保持 `planned_not_run`，不得伪造实例名。

## 五、失败场景与判定

求解硬约束（固定检查顺序，轨迹 reason 取第一个失败项）：
`converged`、`complete`、`params_legal`、`reliability_vgs`、
`reliability_vds`、`reliability_vgb`、`saturation`、`vbias_range`、
`branch_continuity`、`case_limits_configured`、`branch_current_limit`、
`bias_current_limit`、`resistor_stress`。电阻失败原因细分为缺 OP/额定值、层级歧义、越压、越功耗或越流。旧字段 `iq_delta` 在当前实现仅表示 VBIAS 两支路的工作点电流和，不表示整机 IQ 增量。

以下八个场景必须单独演练或给出真实发生时的证据：

| 场景 | 预期现象 | 证据位置 | 判定 |
|------|----------|----------|------|
| 预算内无可行候选 | generate 停在求解阶段，不物化最终变体、不发布；候选 OA 与证据保留 | validation.txt `stage=solve`、`ready_for_sizing=false`；若有宿主评估，solver_trace.jsonl 非空且每候选带拒绝原因 | 不得把预算内未找到结果写成已证明全部合法参数无解 |
| Bench 缺失 | inspect 可只读建发现会话；generate 在重扫和仿真前拒绝 | stderr 指明缺真实 Bench L/C/V，validation 不能标记成功 | 不允许猜 Bench 或绕过仿真发布 |
| Provider/仿真启动失败 | 基线 OP 或候选复验失败，generate 停止 | logs/ 对应阶段日志；validation.txt `ready_for_sizing=false` | 不得静默跳过直流检查而放行 |
| Spectre 不收敛 | 该候选 `converged` 约束失败，不进入可行候选排名；全部不收敛则本轮未找到结果 | solver_trace.jsonl 中 reason=not_converged，host_message 保留宿主原因 | 不收敛候选绝不写入 resolved_parameters.json 的选中结果 |
| 可靠性超限 | 候选被 `reliability_vgs/vds/vgb` 拒绝 | solver_trace.jsonl 对应 reason | 超限候选不得中选 |
| CDF 参数回读不一致 | 候选不仿真或最终变体不发布 | 候选 `validation.txt` 为 `ok=false` 且 trace 带 host_message；最终回读失败时 reports/validation.txt 为 `stage=verify_roundtrip`、`structural_ready=false`、`ready_for_sizing=false` | PDK 量化通过不等于 CDF 实际回读一致 |
| 两个 Cascode 多 VBIAS 隔离 | 同会话 confirm 两个 fixed Cascode 后 generate：generated_cells=4（2 功能封装 + 2 VBIAS 封装），两 VBIAS Cell 各自独立、互不共享器件与输出网 | after/ 回读与 resolved_parameters.json 两条操作记录 | 任一共享即失败 |
| PVT 某 Corner 失败但名义通过 | 名义求解成功，但该 Corner 复验失败并停止发布 | 求解候选失败时 resolved_parameters.json 的 pvt 数组标出 Corner/约束；最终 staging 失败时 reports/validation.txt 为 `stage=pvt_check`；两种情况均为 `pvt_ready=false`、`ready_for_sizing=false` | 只要配置了 PVT，任一 Corner 失败都必须阻塞放行，并保留失败证据 |

## 六、真实服务器成功标准

每个真实成功会话必须同时出现：

```text
structural_ready=true
nominal_dc_ready=true
parameters_quantized=true
ready_for_sizing=true
```

并人工核对：

- NMOS Cascode 位于 Drain 侧；
- PMOS Cascode 位于 Source 侧；
- 原 Gate 功能网络未改变；
- `VG_CTRL`、`VS_ORIG` 连接正确；
- 每个操作有独立 VBIAS CellView；
- 没有 IREF 端口；
- 模板内部是当前真实 PDK 器件；
- CDF 参数与 `resolved_parameters.json` 一致；
- 回读网表端子顺序与 expected 一致；
- 原始源 CellView 未被修改。

`pvt_ready=true` 只在配置了 `--pvt-corners` 且全部 Corner 复验通过时
出现；它仍不表示 AC、瞬态、PSRR、噪声已签核。
