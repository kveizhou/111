# 服务器首轮测试：交互输入版

用户已选择逐步手工测试。当前首选交付为 [逐步命令与预期输出](服务器测试_逐步命令与预期输出_2026-10-08.md)，本页只保留为可选辅助入口说明。之前的交互版源码 ZIP 是历史快照，不能替代评审修正版。

## 明天只需做什么

上传本次测试包内完整的 st-engine-maau 源码到服务器，进入你原来的项目目录，在 csh/tcsh 中执行：

```csh
cd /tmpdata/maau_epc/users/k00981589/st-engine-maau
source server/setup_backend.csh /tmpdata/maau_epc/users/k00981589/st-engine-maau
python3 scripts/server_test_interactive.py
```

随后按终端提示输入。第一次建议选择 **2：编译回归 + 只读 PDK 扫描**；数据已经齐全时选择 **3：完整单项结构验证**。

若已经处于可用 Cadence 环境，可以直接运行最后一条。脚本继承 PATH/许可证环境，并在自己的子进程中固定本项目的后端/provider；不会修改你当前 shell 的环境。

setup_backend.csh 默认使用包内工具 init.il。向导从源 Core 的 technology 关联和真实注册路径发现 PDK，读取并打印工艺库和器件库路径。若工具不在 PATH，按你此前的服务器方法加载 Virtuoso/OCEAN/Spectre，再运行向导。

## 与之前 016 测试的关系

| 之前的步骤 | 本次对应 |
| --- | --- |
| cd / 确认上传版本 | 同一目录；脚本核对本次包的源码 SHA256，旧源码或漏传文件会停止 |
| source setup / which | 同样沿用服务器环境；向导核对所需工具，默认使用包内工具 init.il |
| build / test | 仍调用现有 build.sh / test.sh，保存完整日志和真实退出码 |
| 选新会话 / prepare_session | 自动提示新会话，已有目录拒绝复用；仍使用 prepare_session.sh |
| inspect | 完整模式用 standalone.py inspect，自动传本次 PDK/profile/rules/Bench |
| 从真实 PDK 选器件 | 实际 catalog 与当前层 MOS 清单；不会固定 I53 或 rhrpo master |
| 创建操作 / confirm / list | 向导可创建一项操作，也可输入已有操作文件；仍由引擎确认 |
| generate / validation / cmp | 同样执行；现在包括真实 OP、电阻额定值和相应 VBIAS/PVT 门禁 |
| open | 仅报告放行且源图逐字节一致时提供选项；默认不打开 GUI |

**旧电阻测试的电路预期已变化**：type=resistor 现在保留原 MOS，在 Source 串电阻。新的实例命名基于 *_RS / *_RS_INT，不能再把 I53_REQ 直接连接原 D/S、原 MOS 被移除的旧结果当成功标准。

r=1k 与 r=1K 的等价校验仍保留。旧操作里的 resistor.min=1、max=1e12、grid=1 不能当成本次 PDK 的实际参数范围；向导从实际 catalog 的 resistance CDF 合法域取得 min/max/grid，不硬填这些值。

## 运行范围和需要输入的内容

### 1：只编译回归

提示产物父目录及新会话名称。执行源码核对、构建、原回归及交互入口自身的测试。结束时会明确说明没有运行真实 PDK/仿真。

原回归预计汇总仍为：

```text
test programs passed: 19
demos passed: 2
cli help passed: 1
server backend contract passed: 1
shell syntax checks passed: 18
standalone PDK entry and signed OP tests passed: 20
source-bound PDK discovery tests passed: 5
```

交互入口另外执行 ServerTestInteractiveTest.py，当前为 8 项。测试数不同于旧的 14/12，是因为本轮增加了电阻门禁、独立 PDK/OP 等测试。计数通过不代表真实 Cadence 验收。

### 2：加只读 PDK 扫描，首次推荐

在范围 1 后询问：

- 源 Core 库名/Cell 名；默认是本次已确定的 Capless；
- 源工程 cds.lib 绝对路径；如果旧 Capless 路径确实存在，会显示它作为可修改的默认值；
- 本次派生库名。

使用隔离 cds.lib 运行真实 probe-pdk，并报告 master 数量、产物路径。扫描只涉及与源 Core 同工艺、具有实际 primitive/CDF 证据的已注册 OA 库。空扫描会停止并说明检查工艺关联/注册。

这一阶段不需要先准备完整 Bench/profile 或性能限值，可以先取得真实 OA/CDF 证据。它不进行结构生成或发布。

### 3：完整单项结构验证

在范围 2 后进一步询问：

- **实际 schematic testbench** 的库名/Cell 名，不用 Core 代填 Bench；
- 已有 simulation_profile.json 路径，或回车逐项输入生成；
- 可选有真实来源的 PDK rules JSON，没有文件可回车。

逐项生成 profile 时，需要输入：

1. 名义 Corner；可选 PVT Corner（逗号分隔，空白表示本次只测名义 DC）。
2. VBIAS 实际高/低轨网名。
3. 主支路最大相对误差，选填；暂无性能 Spec 直接回车。
4. 新增 VBIAS 最大电流，单位 A，选填；暂无性能 Spec 直接回车。两项上限须一起留空或一起提供实际有限正数。
5. Bench 中源 DUT 的子电路名。
6. 每个 Corner 的真实温度、一个或多个实际模型文件及 section。
7. 每个 Corner 的设计变量 JSON 对象；回车表示保留 Bench 原变量，不自动造供电/负载条件。
8. 实际 PSF 电源电流完整 signal 名及 sign=1/-1，可添加多个。

不能确定的必填项输入 **?**，脚本保留已经完成的阶段和证据并退出，返回码为 3，明确表示完整验证未完成。不要为继续向导而输入猜测值。

实际 PDK 的可靠性、Bulk/Well、CDF 缺失域、电阻 geometry/Corner/温度额定值可能需要有来源 rules 补充。向导只收集输入，不生成虚构额定值；缺失时引擎会输出 diagnostics 或拒绝候选/发布。

## 选择一项变换

inspect 成功后显示本次实际当前层 MOS 清单。数量以实际结果为准，不要求固定 59。

可以填写已有操作文件的绝对路径；或回车打开简易向导：

- 1：Source 串电阻，输入目标 MOS、实际扫描的电阻 master 和阻值（ohm）。简易向导支持二端、完整 resistance CDF 映射/合法域的电阻。多端电阻使用已有操作文件并声明附加端网。
- 2：同 master Cascode，输入目标 MOS、实际电压域和相应 Bulk 网。
- 3：同 N/P 不同 master Cascode，从该目标实际准入候选中选择新增管。
- 4：共栅 Stack，输入目标及级数（2–100，引擎还检查真实 PDK 上限）。
- 0：保留 inspect 结果，结束，不生成。

每次向导只生成一项操作，便于定位真实问题。默认操作 id=op_server_one，文件放在本次新会话根目录。VBIAS 内部 MOS 和电阻仍由现有引擎自动选择和求参，向导不要求用户手填 bias.* / op.*。

## 日志、成功标准和回传

产物默认位于项目同级的 st-engine-maau-runs 下，向导会提示修改。新会话名称默认带运行时日期时间；若名字存在，会要求新名字，旧证据保留。

每条命令都记录参数数组、工作目录、开始时间、耗时、真实退出码和日志路径。不会写出整个环境变量集或许可证变量。

主要文件：

```text
本次新会话/
  logs/commands.jsonl
  logs/01_build.log
  logs/02_tests.log
  logs/03_interactive_tests.log
  logs/04_prepare.log
  logs/05_probe.log
  logs/06_inspect.log          # 仅范围 3 继续到这里后才有
  logs/07_confirm.log
  logs/08_list.log
  logs/09_generate.log
  test_inputs.json
  pdk_probe.tsv
  simulation_profile.json     # 选择逐项生成时
  operation.conf              # 选择操作向导时
  cadence/cds.lib
  work/analysis/standalone_inputs/pdk_diagnostics.json
  work/analysis/candidates/
  work/analysis/solver_trace.jsonl
  work/after/
  work/reports/validation.txt
```

范围 3 的成功必须同时满足 generate 退出 0、validation 中 ok=true / ready_for_sizing=true / stage=complete、原始与 source_roundtrip 网表逐字节一致。返回 0 的范围 1/2 只表示该选择范围成功，不表示完整变换成功。

请回传实际运行到的目录、logs/commands.jsonl 和全部日志；若失败，连同 diagnostics、失败候选目录、solver trace 和 reports 一起保留。电阻验收要确认封装中仍有原 MOS、Source 中间网及真实电阻；VBIAS 要检查实际 OA 回读先于 DC、signed OP、电阻额定值及当前配置角的结果。

当前核心是已配置范围内的 DC/OP 验证。整机 IQ 的无载/扣负载口径、启动/关断、稳定性/瞬态等仍不由这一轮 DC 成功自动证明。

## 本次补充的文件和验证范围

此次只新增交互测试辅助脚本、上述说明、入口自身测试和源码 hash 清单，未改核心 C++、PDK parser、OP provider 或原 test.sh。

新增入口独立测试覆盖命令失败记录/停止、旧会话保留、真实 profile 字段与电流符号、最终报告与源图检查、未知输入停止、Source 操作的扫描 CDF 使用，以及整段交互进程的构建失败和源码漂移拒绝。它们是本地辅助脚本测试，不是真实 PDK 仿真结果。
