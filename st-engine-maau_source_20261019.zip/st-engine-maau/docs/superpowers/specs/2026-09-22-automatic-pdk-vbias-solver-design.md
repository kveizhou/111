# 动态 PDK 扫描与自生成 VBIAS 闭环求解设计

## 1. 状态与决策

本设计经确认用于 `st-engine-maau` 的 Cascode 结构变换。

本设计取代旧方案中“复用现有 VBIAS/IREF”或“由 Case 预先提供参考电流”的相关内容；`LDO_MOS四种结构变换设计方案.md` 中已经确认的 Source 串联电阻和 Stack MOS 规则不受影响。

核心决策：

- 不扫描、不复用原电路的 VBIAS；
- 不查找、不复用原电路的参考电流 IREF；
- 每增加一个 Cascode，生成一个独立的、自带参考电流的 VBIAS 子 CellView；
- 模板内部的 MOS 和电阻均从当前 PDK 动态扫描得到，不使用跨工艺固定 Cell 名；
- 器件参数由 DC 工作点闭环求解，不要求用户填写 VBIAS、IREF、Mirror 比例或 Replica 尺寸；
- 没有可用 DC 结果时，工具允许自动运行 DC 工作点仿真；
- 找不到满足 PDK 限制和电气约束的解时拒绝生成，不猜测器件或参数。

## 2. 范围

本轮包含：

1. 当前电路所用 PDK 的自动识别；
2. 真实 OA MOS/电阻与 CDF 约束的动态扫描；
3. 同型 Cascode 的自动参数求解；
4. 同极性异型 Cascode 的候选生成、用户选择与自动参数求解；
5. `VBIAS_N_CASCODE_AUTO` 和 `VBIAS_P_CASCODE_AUTO` 两套自给电模板；
6. 名义 DC 工作点闭环，以及 Case 已配置 Corner 时的 PVT 检查；
7. 生成结果的 OA 物化、回读网表与诊断证据。

本轮不包含：

- 对称管自动识别和联动修改；
- 以 AC/瞬态/噪声仿真代替原 Case 的最终性能签核；
- NMOS 与 PMOS 之间的交叉替换；
- 在 PDK 元数据缺失时根据 Cell 名猜测耐压或端子含义。

## 3. 用户操作

用户只需：

1. 选择要修改的 MOS；
2. 选择同型 Cascode 或异型 Cascode；
3. 异型 Cascode 时，从工具自动筛选的同极性 MOS 候选中选择一个型号；
4. 确认生成。

操作文件不再接受：

- `bias.reference_net`；
- `bias.reference_current`；
- `bias.voltage`；
- `bias.output_net`；
- `bias.element.*`；
- 模板内部 Mirror/Replica Master；
- 模板内部电阻值和 MOS 尺寸。

旧字段如仍出现，CLI 应明确报错“该字段已由自动求解器接管”，避免用户误以为手工值仍然生效。

## 4. PDK 扫描

### 4.1 数据来源

PDK 扫描接口参考 `KimiCode` 中的 `PdkCollector`、`Tech`、`GetDeviceInfoFromTech` 和 Virtuoso 电路分析流程，但 `st-engine-maau` 不依赖本机绝对路径。

扫描分两步：

1. 识别当前 DUT 实际使用的 PDK Library；
2. 通过工艺数据接口和 Virtuoso OA/CDF 导出器生成归一化器件目录。

### 4.2 归一化器件信息

每个 MOS 或电阻至少包含：

- PDK 名称和版本；
- OA Library/Cell/View 和网表 Model；
- NMOS、PMOS 或电阻类别；
- 物理端子顺序和语义端子映射；
- CDF 参数名和归一化 W/L/FIN/Finger/M 映射；
- 连续范围、离散取值和量化规则；
- W 与 FIN 的换算关系；
- 电压域、耐压等级和 `|VGS|/|VDS|/|VGB|` 限制；
- Bulk/Well 规则；
- Spectre Model/Section 和可用 Corner。

候选器件缺少极性、端子、CDF 映射或必要可靠性数据时，该候选不进入自动选择。

### 4.3 工艺适配范围

允许为不同 PDK 编写“元数据如何读取”的适配器，但不维护“MOS A 只能替换 MOS B”的人工器件对清单。

`device_policy.tsv` 仅保留为元数据字段名、特殊端子或安全例外的适配层，不再以 `compatible_masters` 作为异型 Cascode 的正常数据源。

## 5. Cascode 候选选择

异型候选必须同时满足：

1. 与原 MOS 同极性；
2. 物理端子可完整映射；
3. 支持目标电压域；
4. 在预估节点电压下不超出可靠性限制；
5. 存在可用的 W/L/FIN/Finger/M 参数组合；
6. 在真实 PDK Model 的 DC 仿真中有可行解。

候选排名依据：

- 可靠性余量；
- 与原支路电流的匹配程度；
- 所需电压余量；
- 新增静态电流；
- 器件面积估计。

用户选择异型 Master 后，具体尺寸仍由求解器决定。

Cascode 的串联位置固定为：

- NMOS 新管放在原管 Drain 侧，即原管与原 Drain 网络之间；
- PMOS 新管放在原管 Source 侧，即原管与原 Source 网络之间，原理图视觉上是原管上方；
- 原 MOS 的 Gate 功能连接保持不变，新增 Cascode Gate 由对应的自动 VBIAS 模板驱动。

## 6. DC 工作点获取

优先使用当前 Case/Bench 的有效 DC 工作点快照。快照不存在、已过期或与当前 DUT 哈希不匹配时，后端自动运行一次 Spectre DC 工作点仿真。

因 DUT Core 本身可能只有端口、没有激励，DC 运行必须使用当前 Case 选中的 Bench。Standalone CLI 因此需要增加 Bench/Simulator 上下文，不能对裸 Core 网表凭空计算工作点。

对目标 MOS 至少读取：

- Drain/Gate/Source/Bulk 节点电压；
- `Id`、`VGS`、`VDS`、`VBS`、`VTH`、`VDSAT`；
- 所属支路的电流方向；
- 当前温度、Model Section 和供电条件。

快照与 DUT 结构哈希、Bench 配置哈希、PDK 版本和 Corner 共同绑定。

## 7. 自给电 VBIAS 模板

### 7.1 NMOS Cascode

`VBIAS_N_CASCODE_AUTO` 只向外暴露 `VHIGH`、`VLOW`、`VS_ORIG`、`VG_CTRL` 和 `VBIAS_N`。`VS_ORIG` 接变换前原 NMOS 的 Source 网络；`VG_CTRL` 只连接到原 NMOS 的 Gate 网络以驱动 Replica Gate，不改变原 MOS Gate 的功能连接。

内部包含：

- `P_REF`：二极管连接 PMOS；
- `R_REF_N`：从 `PBIAS_REF` 到 `VLOW` 的真实 PDK 电阻，与 `P_REF` 一起产生模板内部参考电流；
- `P_OUT_N`：向 Replica 支路供流的 PMOS 镜像管；
- `N_CTRL_REP_N`：模拟原 NMOS；
- `N_CAS_REP_N`：二极管连接，模拟新增 NMOS Cascode；
- `VBIAS_N`：连接新增 NMOS Cascode Gate 的唯一输出。

固定连接为：

- `P_REF`: D=G=`PBIAS_REF`, S=`VHIGH`；
- `R_REF_N`: `PBIAS_REF` 到 `VLOW`；
- `P_OUT_N`: D=`VBIAS_N`, G=`PBIAS_REF`, S=`VHIGH`；
- `N_CAS_REP_N`: D=G=`VBIAS_N`, S=`X_REP_N`；
- `N_CTRL_REP_N`: D=`X_REP_N`, G=`VG_CTRL`, S=`VS_ORIG`。

### 7.2 PMOS Cascode

`VBIAS_P_CASCODE_AUTO` 只向外暴露 `VHIGH`、`VLOW`、`VS_ORIG`、`VG_CTRL` 和 `VBIAS_P`。`VS_ORIG` 接变换前原 PMOS 的 Source 网络；`VG_CTRL` 只连接到原 PMOS 的 Gate 网络以驱动 Replica Gate，不改变原 MOS Gate 的功能连接。

内部包含：

- `R_REF_P`：从 `VHIGH` 到 `NBIAS_REF` 的真实 PDK 电阻；
- `N_REF`：二极管连接 NMOS，与 `R_REF_P` 一起产生模板内部参考电流；
- `N_OUT_P`：从 Replica 支路吸流的 NMOS 镜像管；
- `P_CTRL_REP_P`：模拟原 PMOS；
- `P_CAS_REP_P`：二极管连接，模拟新增 PMOS Cascode；
- `VBIAS_P`：连接新增 PMOS Cascode Gate 的唯一输出。

固定连接为：

- `R_REF_P`: `VHIGH` 到 `NBIAS_REF`；
- `N_REF`: D=G=`NBIAS_REF`, S=`VLOW`；
- `P_CAS_REP_P`: D=G=`VBIAS_P`, S=`VS_ORIG`；
- `P_CTRL_REP_P`: D=`X_REP_P`, G=`VG_CTRL`, S=`VBIAS_P`；
- `N_OUT_P`: D=`X_REP_P`, G=`NBIAS_REF`, S=`VLOW`。

两套模板的 Bulk/Well 不靠默认位置推断，必须由 PDK 端子规则绑定到合法电位。`VS_ORIG` 与 `VHIGH` 或 `VLOW` 可以是同一网络，但接口仍保留二者的语义，不能在模板内擅自短接。

### 7.3 封装和命名

每个 Cascode 获得独立 VBIAS CellView，顶层只看到 Cascode 封装实例和必要端口。模板内部器件不散落在 LDO 顶层，不与其他 Cascode 共享 VBIAS。

`VG_CTRL` 增加的 Gate 电容必须记录在变换报告中。DC 求解只证明静态工作点可行；原 Gate 是快速或高阻节点时，仍需使用原 Case 的 AC/瞬态仿真检查负载影响。

## 8. 参数求解

### 8.1 求解变量

- 新增 Cascode MOS 的 W/L/FIN/Finger/M；
- `P_REF/P_OUT_N` 或 `N_REF/N_OUT_P` 的尺寸与镜像比；
- Control Replica 和 Cascode Replica 的尺寸；
- `R_REF_N` 或 `R_REF_P` 的电阻值与 PDK 物理参数；
- 模板内部电流和 VBIAS 工作点。

### 8.2 初值

- 同型 Cascode 以原 MOS 的等效尺寸为初值；
- 异型 Cascode 先按归一化有效宽度和原支路电流密度映射；
- 参考电阻以 PDK 有限正阻值范围的几何中点为搜索起点；
- 所有初值先量化到 CDF 允许的取值。

### 8.3 闭环

1. 生成隔离的候选变体；
2. 运行名义 DC 工作点；
3. 读取主支路和 VBIAS 模板工作点；
4. 检查硬约束；
5. 对参数做离散化的粗搜索和局部精搜索；
6. 选择满足约束且新增 IQ 最小的解；
7. Case 已配置 PVT 时，对全部指定 Corner 复验；
8. 通过后才物化到最终派生 CellView。

### 8.4 硬约束

- 极性、端子和 Bulk/Well 连接合法；
- 所有 CDF 参数在 PDK 允许范围并满足离散取值；
- 所有器件不超过 `|VGS|/|VDS|/|VGB|` 可靠性限制；
- 原 MOS、新增 Cascode 和模板 MOS 工作区正确；
- 主支路仍存在可用电压余量；
- VBIAS 输出不超过所属电压域；
- 回读网表的连接和参数与求解结果一致。

### 8.5 优化目标

在硬约束全部满足后，按以下顺序选择：

1. 主支路电流相对原电路的偏差最小；
2. 原 MOS 工作点偏差最小；
3. 新增 IQ 最小；
4. 可靠性和饱和余量最大；
5. 器件面积估计最小。

数值容差作为版本化的求解器策略，不要求用户在每个操作文件中填写。

## 9. 后端与数据产物

新增后端能力：

- `scan-pdk`：导出归一化 PDK 器件目录；
- `run-op`：对指定 DUT/Bench/变体运行 DC 工作点并返回结构化结果；
- 现有 Snapshot/Materialize/Round-trip 能力继续负责 OA 生成与回读。

每个会话保留：

- `analysis/pdk_catalog.json`；
- `analysis/baseline_op.json`；
- `analysis/cross_flavor_candidates.json`；
- `analysis/solver_trace.jsonl`；
- `analysis/resolved_parameters.json`；
- `reports/validation.txt`；
- 候选和最终回读网表。

所有结果都记录 PDK 版本、DUT 哈希、Bench 哈希、Corner 和求解器版本，防止使用过期工作点。

## 10. 结果状态

- `structural_ready`：OA 生成和回读结构一致；
- `nominal_dc_ready`：名义 DC 工作点和可靠性约束通过；
- `pvt_ready`：Case 配置的全部 PVT 点通过；
- `ready_for_sizing`：至少达到 `nominal_dc_ready`，且所有求解参数已量化到 PDK 合法值。

`ready_for_sizing=true` 不表示 LDO 的 AC、瞬态、PSRR、噪声或全 PVT 已最终签核。

## 11. 错误处理

以下情况拒绝生成并给出具体诊断：

- 缺少 Bench 或 Bench 无法建立 DC 工作点；
- PDK 扫描不到必要的 MOS 或电阻；
- 端子、CDF 或可靠性信息不完整；
- 异型候选无同极性可行器件；
- 求解过程中电路不收敛；
- 无法同时满足电流、饱和、余量和可靠性约束；
- PVT 配置存在但任一指定 Corner 失败；
- OA 物化后回读连接或 CDF 参数与求解结果不一致。

任何失败都保留扫描目录、求解轨迹、仿真日志和最后候选网表，便于复现。

## 12. 测试与验收

### 12.1 单元测试

- PDK 归一化与参数量化；
- NMOS/PMOS 同极性候选筛选；
- 缺少可靠性数据时拒绝候选；
- 两套自给电模板的固定端子关系；
- 求解器粗搜索、精搜索、量化和无解诊断；
- 旧手工 Bias 字段被拒绝。

### 12.2 伪后端集成测试

- 无快照时确实调用 `run-op`；
- 快照哈希一致时可安全复用；
- 异型只显示筛选后候选；
- 每个 Cascode 生成独立 VBIAS CellView；
- 多次结构变换时命名、放置和端口不冲突；
- 求解值能进入 OA Plan 并通过回读校验。

### 12.3 真实服务器验收

在 ICADVM18.1 和目标 PDK 上分别覆盖：

- NMOS 同型 Cascode；
- PMOS 同型 Cascode；
- NMOS 异型 Cascode；
- PMOS 异型 Cascode；
- PDK 无合法候选；
- 名义 DC 收敛与不收敛；
- 多个 Cascode 的独立 VBIAS 封装；
- 有 PVT 配置时的 Corner 通过和失败；
- 生成后回读网表的结构、端子、器件 Master 和 CDF 参数一致。

## 13. 与现有四种结构变换的关系

- 同型 Cascode：使用动态 PDK 目录中的原 Master，参数由 DC 求解；
- 异型 Cascode：从动态候选中选 Master，参数由 DC 求解；
- Source 串联电阻：保持已确认的 PDK 扫描和电阻中点默认规则，不调用 VBIAS 模板；
- Stack MOS：保持 Drain 侧原名、向 Source 侧使用 `_S1..._SN` 的命名和同 Gate 规则，不调用 VBIAS 模板。

## 14. 参考实现边界

`/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/传输的代码.md` 列出的 KimiCode 文件用于参考 PDK 收集、Tech 数据、CDF 映射、Virtuoso 分析和仿真调度方式。

实施时：

- 优先复用稳定的数据格式和已有执行入口；
- 不在 `st-engine-maau` 中写入 KimiCode 绝对路径；
- 不整体链接 KimiCode 的内部实现；
- 通过可替换的 PDK 扫描和仿真后端接口保持两个代码库解耦。
