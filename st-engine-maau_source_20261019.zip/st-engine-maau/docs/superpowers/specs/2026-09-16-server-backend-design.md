# 真实 Virtuoso 服务器后端设计

## 1. 目标

为 `st_circuit_tool` 已固定的六个后端动词提供独立、可部署的 Linux/Cadence 实现，使工具能够以 `cds.lib + library/cell/view` 为输入，对真实 OA schematic 完成读取、隔离复制、结构物化、双网表回读、发布和打开。

后端不链接 Maau C++。它只复用服务器已经部署的 Cadence、PDK 和 Maau SKILL 初始化文件，其中 `parse_json_file` 用于读取物化计划。所有电路修改均发生在 staging 或最终派生 cellview，源 cellview 只读。

## 2. 部署边界

- 目标服务器 shell 为 csh/tcsh，Cadence 版本为 ICADVM18.1，Spectre 版本为 18.1。
- `server/setup_backend.csh` 在用户已经能够调用 `ma` 的交互 shell 中加载 Cadence 模块，设置 `ST_ENGINE_ROOT`、`ST_SKILL_INIT` 和六个 Runner 环境变量。
- Runner 自身使用 Bash，只消费已经加载到环境中的 `virtuoso`，不尝试在 Bash 中执行 csh alias。
- `ST_SKILL_INIT` 默认指向当前有效发布中的 `package/circuit/script/skill/init.il`，但允许部署时覆盖。
- `cds.lib` 由每次命令显式传入。Runner 从该文件所在目录启动 Virtuoso，避免依赖调用者当前目录。

## 3. 组件

### 3.1 Dispatcher 和环境

- `server/st_virtuoso_backend.sh`：可直接作为 `--backend` 使用，按动词分派到六个 Runner。
- `server/setup_backend.csh`：设置环境变量并检查项目目录、SKILL 初始化文件和 Cadence 命令。
- `server/lib/backend_common.sh`：提供无 `eval` 的参数解析、路径校验、临时目录、Virtuoso batch 执行和完成标记检查。

### 3.2 六个 Runner

- `snapshot_runner.sh`：调用 OA 只读导出脚本，生成结构基线网表、器件目录和坐标。
- `clone_runner.sh`：拒绝 source=target，复制 source cellview 到 staging。
- `materialize_runner.sh`：加载 PDK 适配器和 `standalone_topology_variant.il`，执行 JSON 物化计划。
- `netlist_runner.sh`：使用与 snapshot 相同的确定性 OA 结构导出器生成回读网表。
- `publish_runner.sh`：只在 C++ 双回读验证通过后，把 staging 复制到最终派生 cellview。
- `open_runner.sh`：启动 GUI Virtuoso 并打开最终派生 schematic；它不参与结构正确性判定。

### 3.3 SKILL

- `server/skill/backend_common.il`：环境读取、结果标记、字符串转义、OA 打开和错误封装。
- `server/skill/export_snapshot.il`：当前层结构导出。
- `server/skill/copy_cellview.il`：clone/publish 共用的受保护复制。
- `server/skill/pdk_adapter.il`：实现 `StTopologyApplyCdfParameters`、`StTopologyCreatePort`、`StTopologyCheckAndSave`。
- `server/skill/materialize.il`：加载物化入口并写完成标记。
- `server/skill/open_cellview.il`：打开派生 schematic。

## 4. Snapshot 数据规则

### 4.1 当前层范围

只导出指定 schematic 当前层：顶层 terminals、当前层普通实例、实例端子连接、master 和实例坐标。`basic/ipin`、`basic/opin`、`basic/iopin`、`basic/noConn` 作为图形对象处理，不写成电路实例；子模块保持一个普通实例，不递归展开。

### 4.2 模型键和端子顺序

结构网表中的 master 键使用 `oa_<library>__<cell>`，避免不同库同名 cell 冲突。网表端子顺序与导出的 `device_catalog.tsv` 完全一致，目录同时记录 OA library/cell/view 和 D/G/S/B 或电阻正负端语义。

MOS 身份不根据实例名首字母判断。只有 master terminal 集合能够明确映射 D/G/S/B 时才登记为 MOS；极性必须来自明确策略或 master/CDF 证据。无法确定极性的四端器件不进入可修改 MOS 清单。

### 4.3 阵列

OA 阵列实例作为一个逻辑实例保留，例如 `I18<119:0>`。重复连接表达式 `<*120>VBP1` 在结构网表中归一化为实际网络 `VBP1`，阵列范围作为保留参数记录。物化时必须创建同范围数组并广播实际网络，禁止创建名字为 `<*120>VBP1` 的普通 net。

### 4.4 PDK 策略

自动目录采用保守默认值：同一 master 只兼容自身；跨 Flavor、可靠性限值、电压域、isolated-well 和可编辑参数映射由 `server/config/device_policy.tsv` 覆盖。没有明确登记的跨 Flavor 组合必须被 C++ 拒绝。

真实 PDK 电阻也由策略文件登记。不能仅凭两端器件形态把所有器件当成可替换电阻。

## 5. 物化规则

- clone/publish 的源和目标 library/cell/view 必须不同。
- 目标 library 必须已经由受控 `cds.lib` 定义且可写；后端不修改用户的 `cds.lib`。
- `StTopologyApplyCdfParameters` 只写计划明确给出的、目标 effective CDF 中存在的参数，然后调用当前 PDK 已加载的 CDF callback 入口；未知参数导致失败。
- `StTopologyCreatePort` 创建 terminal、pin 和可见 schematic pin 图形。
- `StTopologyCheckAndSave` 执行 schematic check，只有检查没有错误才保存。
- 每个 batch 操作必须生成独立完成标记。即使 Virtuoso 进程退出码为0，只要标记或预期产物缺失，Runner 仍返回非零。

## 6. 安全和失败语义

- 不使用 `eval`，不拼接未转义的 shell 命令。
- 所有必需参数、文件和可执行程序在启动 Virtuoso 前校验。
- snapshot/netlist 以只读方式打开源 cellview，且不调用 `dbSave`。
- materialize 只允许计划中的 target/staging；源目标相同立即失败。
- 失败时保留 Virtuoso 日志路径，Runner 输出第一处可操作错误。
- `ready_for_sizing=true` 仍只由 C++ 在 source round-trip、derived round-trip 和 publish 全部通过后输出。

## 7. 测试与真实验收

本地测试使用假的 `virtuoso` 可执行程序验证：参数无损传递、环境检查、完成标记、产物检查、source=target 拒绝以及六个 Runner 的分派。现有 C++ 13 个测试程序继续全部通过。

服务器真实验收顺序固定为：

1. `source server/setup_backend.csh` 后六个 Runner 环境变量存在；
2. `inspect` 生成四个非空 before 文件并列出真实当前层 MOS；
3. 对一个非阵列标量 MOS 确认一项同型结构变换；
4. `generate` 完成 clone、materialize、source netlist、staging netlist、publish；
5. 报告为 `ok=true`、`ready_for_sizing=true`、`stage=complete`；
6. `open` 能看到派生 schematic，源 schematic 的回读网表保持不变。

任何一步缺少命令、退出码、日志或产物，都不能宣称真实闭环成功。
