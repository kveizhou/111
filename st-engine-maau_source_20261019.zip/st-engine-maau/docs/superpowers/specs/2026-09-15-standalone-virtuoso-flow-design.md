# 独立结构变换工具与 Virtuoso 往返闭环设计

## 1. 目标

在现有 `st-engine-maau` 四类结构变换核心之上，增加一个可直接编译和运行的独立命令行工具。用户输入的是 Virtuoso 工程入口和核心电路 `library/cell/view`，不是手工准备的网表路径。工具调用服务器侧 Virtuoso 适配器生成基线网表和 PDK/CDF 元数据，只列出所选核心 cell 当前层级的 MOS，接受用户确认的变换，生成期望网表，再调用 SKILL 在源 schematic 的隔离副本中物化，最后重新网表化并做往返一致性检查。

本工具不依赖 Maau。Maau 源码只用于参考“从 L/C/V 生成网表”的调用顺序。

## 2. 固定范围

- 只处理用户明确选择的核心 `library/cell/schematic`。
- 只列出该 cell 当前层级直接放置的 MOS；不从 testbench 开始，不递归展开子模块。
- 如果要修改某个子模块内的 MOS，用户必须把该子模块重新指定为核心 cell。
- 支持同型 Cascode、同极性跨 Flavor Cascode、MOS 替换 PDK 电阻、2～100 级同型 MOS Stack。
- 同一个工作会话可连续确认多次修改，最终只生成一个派生电路。
- 源 schematic、源 config 和源网表均只读；所有写操作进入 staging 和最终派生 cellview。
- `ready_for_sizing` 只代表结构物化及回读一致，不代表性能提升，也不自动启动 Sizing 或仿真。

## 3. 权威数据流

```text
cds.lib + 核心 library/cell/view
  -> Virtuoso 适配器从源 schematic 生成 baseline 网表
  -> 适配器导出 PDK/CDF 端子语义、master、范围和当前层实例坐标
  -> 工具解析 baseline 为 Circuit IR
  -> 仅列出核心 subckt 的直接 MOS
  -> 用户 Confirm/Undo/Fresh 维护 Change Set
  -> 在 Circuit IR 上重放四类变换
  -> 写出 expected variant 网表
  -> baseline/expected diff 生成 OA/SKILL 物化计划
  -> 适配器克隆源 schematic 到 staging
  -> SKILL 在 staging 中删除、创建、连接器件并设置 CDF，check/save
  -> 分别重新生成 source round-trip 与 staging round-trip 网表
  -> 校验源图未变、expected 与 staging round-trip 等价
  -> 通过后把 staging 发布为最终派生 cellview
```

三份网表的用途必须区分：

1. `before/core_before.scs`：从源 schematic 生成，只读基线；
2. `expected/core_expected.scs`：结构变换引擎生成，表示想要的连接；
3. `after/core_roundtrip.scs`：从派生 schematic 重新生成，表示 Virtuoso 中真实保存的连接。

第 2、3 份必须在器件数量、master、端子连接、必需参数、Bias 端口和子电路端口上等价。

## 4. 独立命令行

可执行文件名为 `st_circuit_tool`，命令如下：

```text
st_circuit_tool inspect  ...  创建会话并列出当前层 MOS
st_circuit_tool list     ...  再次显示可修改 MOS 和已确认操作
st_circuit_tool confirm  ...  校验并保存一次变换，不写 Virtuoso
st_circuit_tool undo     ...  撤销最后一次已确认变换
st_circuit_tool fresh    ...  清空全部已确认变换，恢复基线逻辑结构
st_circuit_tool generate ...  生成 expected 网表并执行完整 Virtuoso 闭环
st_circuit_tool open     ...  请求适配器打开最终派生 cellview
```

`inspect` 的最小输入是：

```text
--backend /path/to/site_virtuoso_backend
--cds-lib /project/cds.lib
--lib LDO_LIB --cell capless_ldo --view schematic
--work-dir /project/result/ldo_structure_session
```

`--backend` 是服务器侧薄适配器。它不是 Maau 依赖，而是把本工具的稳定命令协议连接到服务器已有的 OCEAN、Virtuoso、PDK init 和 SKILL 启动方式。缺少适配器、许可证或 PDK 环境时必须明确失败，不能退化成“假装已生成 schematic”。

## 5. 会话与输入文件

`inspect` 创建以下目录：

```text
session/
  session.conf
  before/core_before.scs
  before/device_catalog.tsv
  before/geometry.tsv
  before/mos_inventory.tsv
  changes/
  expected/
  materialization/
  after/
  reports/
  logs/
```

`device_catalog.tsv` 由服务器适配器生成，至少提供 master、器件类别、真实 terminal order/role、OA master、CDF 参数映射、兼容 master、电压域、尺寸/阻值/可靠性限制。没有登记为 MOS 的实例不会靠名字猜成 MOS。

`geometry.tsv` 至少提供核心 cell 当前层级实例名和坐标。局部布局规划器以被替换实例坐标为锚点生成新增器件和标签位置。最终连通性由 OA terminal/net 连接决定，坐标只影响可读性。

每次 `confirm` 接收一个 `key=value` 操作文件。它必须包含 `id`、`type`、`instance` 以及所选变换需要的全部工程输入。固定 Bias Cascode 必须包含原 DC/OP 和绝对端口电压；MOS→R 必须包含带符号的端口电压和流入正端电流；分级 Stack 必须包含每级 Bias 与源端电压。核心不猜测缺失值。

## 6. 服务器适配器协议

工具以参数数组直接启动适配器，不拼接 shell 命令。适配器需要实现：

- `snapshot`：从输入 L/C/V 生成 `core_before.scs`、`device_catalog.tsv` 和 `geometry.tsv`；
- `clone`：把 source cellview 克隆到 staging，禁止 source=target；
- `materialize`：加载本项目 `skill/topology_variant.il` 和 `plan.json`，应用 PDK CDF/端口/check-save 适配；
- `netlist`：从给定 L/C/V 重新生成指定输出网表；
- `publish`：把验证通过的 staging 克隆为最终派生 cellview；
- `open`：在 Virtuoso 中打开最终派生 cellview。

每个命令返回退出码，并把日志写入工具指定路径。退出码非零、预期文件缺失或文件为空均视为失败。

## 7. 物化与电路规则

- 变换先发生在结构化 Circuit IR/期望网表中；SKILL 不是第二套变换算法，只负责把确定的差异写进派生 OA schematic。
- 物化从克隆原图开始，不从网表反向生成整张新图，因此未修改区域、原布局和子模块层次得到保留。
- PDK terminal order 和 CDF 属性来自适配器导出的目录，不能固定假设实例数组是 D/G/S/B。
- 同型/异型 Cascode 默认保留原控制管栅连接；新增 Cascode 管按请求连接共栅或已解析 VBIAS。
- 跨 Flavor 必须同极性且兼容矩阵允许。
- MOS→R 连接原 D/S 边界，`R=(Vp-Vn)/I_into_positive`，结果必须为正并落在 PDK 合法范围。
- Stack 每级继承原管完整尺寸，不使用 `W/N`；级数范围为 2～100，同时受 PDK 上限约束。
- Bulk、Well、Bias、外部端口和新增 Bias 电流必须进入请求、物化计划和回读校验。

## 8. 成功、失败与证据

成功必须同时满足：

- 后端实际从源 schematic 生成基线网表；
- 目标是核心当前层直接 MOS；
- Change Set 全部重放成功；
- OA 计划不指向源 cellview；
- SKILL、CDF、check/save 成功；
- source round-trip 与 baseline 等价；
- derived round-trip 与 expected 等价；
- 最终派生 L/C/V 和三份网表路径均存在于报告中。

本机没有 Virtuoso、目标 PDK 和许可证，因此本地只能用假后端验证编译、命令协议、目录、四类结构逻辑和失败传播。真实 schematic 是否能打开必须在服务器上用实际适配器运行后，以命令、退出码、日志、派生 L/C/V 和回读网表为证据。

## 9. 非目标

- 不自动识别“功率管”或替用户选择 MOS；
- 不递归修改所有层级；
- 不修改 testbench；
- 不从网表重建整张原理图的原始布局；
- 不实现 PDK 无关的通用 CDF 回调猜测；
- 不承诺结构变换后的性能提升；
- 不接入 PR/Layout 主链。
