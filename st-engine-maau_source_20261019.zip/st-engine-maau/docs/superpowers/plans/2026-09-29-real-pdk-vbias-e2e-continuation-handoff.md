# 真实 PDK / Maau / Spectre / 自动 VBIAS 端到端闭环：续接交接文档

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development`（推荐）或 `superpowers:executing-plans`，按本文第 14 节的复选项逐项实施、验证和收口；不得跳过真实服务器证据门禁。

**Goal:** 让真实 PDK 扫描、完整候选 OA CellView、真实 Maau/Spectre DC/PVT 仿真、自动 VBIAS 求解以及最终 Virtuoso 生成与回读形成可审计的端到端闭环。

**Architecture:** 公共仓库负责严格协议、候选生成、参数求解和校验；现场适配层只负责从当前 PDK 提供权威元数据，并通过真实 Maau Host 驱动 Case/Bench/Spectre。所有候选先生成隔离的 OA CellView，再仿真、筛选、物化、回读和发布，源 CellView 始终只读。

**Tech Stack:** C++17、CMake、Cadence SKILL/OA、ICADVM18.1、Maau Case/Bench API、Spectre、TSV/JSON 结构化产物、shell 服务器验收脚本。

**Spec:** `docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md`；端到端收口基准为 `docs/superpowers/plans/2026-09-28-real-pdk-vbias-end-to-end-closure.md`。

## Global Constraints

- 不得通过器件名猜测极性、Flavor、耐压、端子顺序、Bulk/Well 或参数范围。
- 不得用 Fake Host、本地模拟结果或裸 Spectre 文本网表替代真实 OA/Maau/Spectre 验收。
- 不得修改源 CellView；只允许 clone-on-write，验证通过后发布目标 CellView。
- 配置了 PVT 角时，任一必需角失败都必须阻止发布和 `ready_for_sizing=true`。
- 任何“端到端通过”结论必须同时提供命令、退出码、绝对日志路径和原始产物。

> 更新时间：2026-09-29（Asia/Shanghai）  
> 工作目录：`/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau`  
> 最终目标：打通“真实 PDK 扫描 → 完整 Cascode + VBIAS 候选 OA 变体 → 真实 Maau/Spectre DC/PVT 仿真 → 自动参数求解 → 最终 Virtuoso 生成、回读与发布”。  
> 本文档面向一个完全没有前序上下文的新会话。新 Agent 应先通读本文，再继续改代码。

---

## 1. 当前只需要做什么

不要重新设计四种结构变换，也不要重写已经通过本地测试的自动 VBIAS 求解器。

下一阶段只收口三件事：

1. 用现场真实 PDK 的权威数据实现 `ST_PDK_TECH_ADAPTER`，使 `scan-pdk` 真正导出可用于自动选择的 MOS、电阻、端子、CDF、参数范围、可靠性和 Bulk/Well 数据；
2. 用现场真实 Maau API 实现并链接 `OpSimulationHost`，使 `run-op` 真正完成 Bench 校验、临时 Case 重绑定、DC/opPoint 设置、Spectre 运行和工作点提取；
3. 在 ICADVM18.1/PDK/Maau/Spectre 服务器上跑一个全新的端到端会话，取得完整命令、退出码、日志和原始产物。只有这些证据全部通过，才能宣布端到端完成。

本地代码已把不真实的占位路径封死：没有现场 PDK 适配器时，真实扫描必须失败；没有现场 Maau Host 库时，生产 OP Provider 不能构建或被自动选择。不得为了“跑通”重新加入猜测值、固定器件名、假可靠性参数或 Fake Host。

---

## 2. 最终业务要求和已经确认的电路规则

### 2.1 四类结构变换

项目支持：

1. 同型 Cascode；
2. 同极性跨 Flavor Cascode；
3. MOS Source 串联电阻；
4. Shared-Gate 多级 MOS Stack。

### 2.2 Cascode 位置

- NMOS：新增 NMOS 放在原管 Drain 侧，即原管与原 Drain 网络之间；
- PMOS：新增 PMOS 放在原管 Source 侧，即原管与原 Source 网络之间；在常见原理图画法中是原管上方；
- 原 MOS Gate 的功能连接不修改；
- 新增 Cascode Gate 由独立自动 VBIAS 模板输出驱动；
- 同型为 N 上加 N、P 上加 P；
- 跨 Flavor 仍然是 N 上加 N、P 上加 P，只允许 Master/Flavor 不同，不允许 N/P 混串。

### 2.3 Stack 命名和连接

- Drain 侧保留原实例名，例如 `M0`；
- 从 Drain 向 Source 依次为 `M0`、`M0_S1`、`M0_S2`……；
- 全部级共用原 Gate；
- 业务层保持一个 `LogicalMosStack(N)`，临时仿真或 OA 物化时才展开真实 MOS；
- 默认公共尺寸组，不把 N 级错误地拆成 N 套独立 W/L。

### 2.4 Source 串联电阻

- 不是用电阻替换 MOS；
- 原 MOS 保留，只在原 MOS 的电气 Source 路径串入一只真实 PDK 电阻；
- 原 MOS 的 Drain/Gate/Bulk 和参数保持不变；
- 阻值优先级：用户值 > Case 预置值 > PDK 有限正合法区间的几何中点；
- 最低优先级默认值不从 DC 工作点反推；
- 最终值必须量化到 PDK 允许范围/网格；
- 多端电阻的 substrate/well 必须按电阻模板绑定，不能照抄 MOS Bulk。

### 2.5 自动 VBIAS 原则

- 不查找、不复用原电路已有 VBIAS；
- 不查找、不复用参考电流 IREF；
- 每个 Fixed-Bias Cascode 独立生成一个 VBIAS CellView；
- 模板无外部 IREF 端口；
- 模板 MOS、电阻从当前真实 PDK 动态目录自动选，用户不能手工指定模板内部 Master；
- 参数由真实 DC 候选仿真求解，不要求用户输入 VBIAS、参考电流、镜像比或 Replica 尺寸；
- 每个操作的模板、器件和输出网互不共享；
- 找不到合法解就拒绝生成，不能猜值放行。

### 2.6 两套模板固定拓扑

`VBIAS_N_CASCODE_AUTO`：

- 端口顺序固定：`VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_N`；
- 内部角色：`P_REF`、`R_REF_N`、`P_OUT_N`、`N_CTRL_REP_N`、`N_CAS_REP_N`；
- `P_REF` 二极管连接；
- `P_OUT_N` 提供镜像电流；
- `N_CTRL_REP_N` 模拟原 NMOS；
- `N_CAS_REP_N` 模拟新增 NMOS Cascode；
- 输出 `VBIAS_N` 只驱动新增 NMOS Cascode Gate。

`VBIAS_P_CASCODE_AUTO`：

- 端口顺序固定：`VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_P`；
- 内部角色：`R_REF_P`、`N_REF`、`N_OUT_P`、`P_CTRL_REP_P`、`P_CAS_REP_P`；
- `N_REF` 二极管连接；
- `N_OUT_P` 提供镜像吸流；
- `P_CTRL_REP_P` 模拟原 PMOS；
- `P_CAS_REP_P` 模拟新增 PMOS Cascode；
- 输出 `VBIAS_P` 只驱动新增 PMOS Cascode Gate。

模板的 Bulk/Well 不能按名字或端子位置猜测，必须来自现场 PDK 权威规则。

---

## 3. 不可违反的工程边界

1. 不根据 Cell 名、Model 名、工作电压或经验猜 MOS 极性、耐压、端子语义、Bulk/Well 规则；
2. 不把当前 DUT 已经实例化过的器件集合当成完整 PDK；必须扫描当前 PDK 登记的可用器件库；
3. 不把裸 Spectre 文本网表作为候选旁路；每个候选先物化成唯一临时 OA CellView，再从该 CellView 运行 `run-op`；
4. 不修改源 CellView；先 clone 到 staging，验证通过后才 publish；
5. Fake Host 只用于本地回归，不是现场通过证据；
6. 本地“19 个测试程序全绿”不等于真实 Virtuoso/Spectre 已经通过；
7. 未配置 PVT 时 `pvt_ready=false` 不阻塞名义放行；一旦配置 PVT，任一 Corner 失败都必须使 `ready_for_sizing=false` 并阻止发布；
8. `ready_for_sizing=true` 必须同时证明：结构回读正确、参数量化合法、最终 staging 名义 DC 通过、已配置 PVT 全通过；
9. 不初始化新的 Git 仓库。当前传输目录没有 `.git`，已有用户文件全部保留；
10. 任何完成声明都要附命令、退出码、日志和原始产物路径。

---

## 4. 端到端目标架构

```text
inspect
  -> snapshot 源 schematic
  -> scan-pdk（真实现场 PDK 元数据）
  -> 生成当前层 MOS 清单与跨 Flavor 候选
  -> 建立不可复用的新会话

confirm
  -> 只保存用户确认的结构操作
  -> 不保存手工 VBIAS、IREF、模板器件或工作点

generate
  -> 重新 scan-pdk 并校验 PDK identity/version
  -> 对源 DUT + 当前 Bench 跑 baseline DC OP
  -> 针对每个 Fixed-Bias Cascode：
       生成 PDK 合法参数候选
       -> 完整装配 Cascode + 独立 VBIAS 模板
       -> clone 到唯一 candidate OA CellView
       -> materialize
       -> 候选 OA CellView 重新网表化并留档
       -> Maau/Spectre run-op
       -> 九项硬约束检查与确定性排名
  -> 选中解固定参数逐 PVT Corner 复验
  -> 生成最终功能封装 + 独立 VBIAS 封装
  -> 最终 staging 名义 DC 硬约束复验
  -> 已配置 PVT 全 Corner 复验
  -> 源图未变验证
  -> 父图和每个生成子 Cell 独立回读
  -> expected / round-trip 结构与参数校验
  -> publish
  -> ready_for_sizing=true
```

分析身份固定包含七个字段：

```text
dut_hash
bench_hash
pdk_version
corner
topology_hash
parameter_hash
solver_version
```

任何字段不一致都不能复用旧 OP。

---

## 5. 已经完成的代码

### 5.1 Task 1：身份与 run-op 协议

状态：本地完成并测试通过。

主要结果：

- `AnalysisIdentity` 扩展为七字段；
- identity.tsv 的读写和复用检查覆盖全部字段；
- `run-op` 只接收 DUT/Bench L/C/V，不接受 `--candidate-netlist`；
- 候选仿真必须针对已物化的 OA DUT；
- 输出事务、旧文件恢复、符号链接/FIFO/目录拒绝、Corner 身份匹配均有测试。

主要文件：

- `include/st/OperatingPoint.h`
- `src/OperatingPoint.cpp`
- `include/st/VirtuosoBackend.h`
- `src/VirtuosoBackend.cpp`
- `server/bin/run_op_runner.sh`
- `integration/maau/op_simulation_provider.h`
- `integration/maau/op_simulation_provider.cc`
- `tests/OperatingPointTest.cpp`
- `tests/VirtuosoBackendTest.cpp`
- `tests/MaauContractTest.cpp`
- `tests/ServerBackendContractTest.sh`

### 5.2 Task 2：完整候选 OA 变体

状态：本地完成并测试通过。

主要结果：

- 求解候选包含真实原管改线、新 Cascode、串联内部网、VBIAS 模板和父层 wrapper；
- 每个候选具有确定的 candidate ID、topology hash、parameter hash 和 solver version；
- 每个候选使用唯一 OA CellView；
- 后端顺序被测试锁定为 clone → materialize → candidate netlist audit → run-op；
- 失败候选的 OA 计划、网表、日志、identity 和 MOS OP 可独立保留。

主要文件：

- `include/st/DcSolver.h`
- `src/DcSolver.cpp`
- `src/Cli.cpp`
- `include/st/OaPlan.h`
- `src/OaPlan.cpp`
- `tests/DcSolverTest.cpp`
- `tests/CliWorkflowTest.cpp`
- `tests/OaPlanTest.cpp`

### 5.3 Task 3：共享电气硬约束

状态：本地完成并测试通过。

主要结果：

- `EvaluateElectricalConstraints` 被求解候选和最终 staging 共用；
- 检查对象包含原控制管、真实新增 Cascode、Control Replica、Cascode Replica 和镜像器件；
- 检查收敛、快照完整、参数合法、VGS/VDS/VGB 可靠性、饱和、VBIAS 范围、支路连续性；
- 最终 staging 电气失败会停止发布，不能只凭候选成功放行。

主要文件：

- `include/st/DcSolver.h`
- `src/DcSolver.cpp`
- `include/st/Materialization.h`
- `src/Materialization.cpp`
- `src/Cli.cpp`

### 5.4 Task 4：动态参数语义与量化

状态：本地完成并测试通过。

主要结果：

- 支持 W/L、FIN、Finger、Multiplier 和无可调参数的定尺寸 Master；
- 不会给定尺寸器件伪造 W/L；
- 只写 PDK 实际登记的 CDF 参数名；
- 跨 Flavor 初值按归一化语义映射并量化；
- 电阻必须有明确 resistance 语义和可量化约束；
- 非法 NaN/Inf、非整数 integer-only、越界值均拒绝。

主要文件：

- `include/st/PdkCatalog.h`
- `src/PdkCatalog.cpp`
- `include/st/AutoBias.h`
- `src/AutoBias.cpp`
- `include/st/DcSolver.h`
- `src/DcSolver.cpp`

### 5.5 Task 5：严格 PDK 扫描框架

状态：公共框架完成，本地契约通过；现场权威适配器尚未实现。

已完成：

- `scan-pdk` 扫描当前 PDK 登记库而非只扫 DUT 已用器件；
- catalog 行包含来源证明字段；
- 缺可靠性、缺 Bulk、只靠名字推断、不能证明属于当前 PDK 的器件不会进入正式目录；
- catalog/identity 以临时文件事务发布；输出冲突、硬链接/符号链接冲突、空 identity、header-only 均拒绝；
- 增加 `ST_PDK_TECH_ADAPTER`；必须是绝对可读文件；
- `scan_pdk.il` 先加载稳定 wrapper，再加载 site adapter；
- 没有 `StSiteTechDescribeDevice` 时直接失败，不再让默认适配器猜可靠性或 Bulk；
- `server/setup_backend.csh` 会检查 site adapter 路径并 fail closed。

主要文件：

- `server/skill/scan_pdk.il`
- `server/skill/tech_adapter.il`
- `server/bin/scan_pdk_runner.sh`
- `server/setup_backend.csh`
- `integration/maau/tech_catalog_provider.h`
- `integration/maau/tech_catalog_provider.cc`
- `src/PdkCatalog.cpp`
- `tests/ServerBackendContractTest.sh`
- `tests/PdkCatalogTest.cpp`
- `tests/MaauContractTest.cpp`

尚未完成：现场 `StSiteTechDescribeDevice` 及相关身份/库枚举回调的真实实现。详见第 8 节。

### 5.6 Task 6：真实 Maau/Spectre Host 的公共链接边界

状态：公共 ABI、构建门禁和测试完成；现场 Host 库尚未实现/链接。

已完成：

- 新增 `CreateSiteOpSimulationHost()`；
- 生产 Provider 必须从现场库取得真实 `OpSimulationHost`；
- 现场库必须导出：

```cpp
extern "C" st::maau::OpSimulationHost*
st_maau_create_site_op_simulation_host();
```

- `ST_BUILD_MAAU_COMPAT=ON` 只编译契约和 Fake Host 测试，不再生成伪生产 Provider；
- 生产 Provider 只能通过 `ST_BUILD_MAAU_SITE_PROVIDER=ON` 构建；
- `ST_MAAU_SITE_HOST_LIBRARY` 必须是存在的绝对库路径；
- 链接成功后才创建 `st_maau_op_provider.site-linked`；
- `setup_backend.csh` 只自动选择带该标记的 Provider；
- 没有真实现场库时，构建/设置直接失败，不再用固定返回 70 的占位 Host 冒充生产实现。

主要文件：

- `integration/maau/site_op_simulation_host.h`
- `integration/maau/site_op_simulation_host.cc`
- `app/st_maau_op_provider.cpp`
- `CMakeLists.txt`
- `scripts/build.sh`
- `server/setup_backend.csh`
- `integration/maau/README.md`
- `tests/MaauContractTest.cpp`
- `tests/ServerBackendContractTest.sh`

尚未完成：现场库中六个 Host 操作的真实实现。详见第 9 节。

### 5.7 Task 7：PVT、日志和发布门禁

状态：本地完成并测试通过。

主要结果：

- 候选日志路径包含候选 ID、topology hash、parameter hash 和 Corner；
- 后端退出码、日志和产物路径进入诊断；
- 配置 PVT 时任一 Corner 失败阻止发布；
- 未请求 DC 的纯结构调用不会冒充 `nominal_dc_ready=true`；
- `ready_for_sizing` 条件为：

```text
structural_ready
&& nominal_dc_ready
&& parameters_quantized
&& (!pvt_configured || pvt_ready)
```

本轮还修正了两份验收文档中“PVT 失败不阻塞”的旧说法：

- `docs/automatic-pdk-vbias-server-validation.md`
- `integration/maau/SERVER_VALIDATION.md`

### 5.8 四种变换、自动模板、封装和回读

状态：本地算法和 Fake 后端工作流完成并测试通过。

已覆盖：

- 同型/异型 Cascode 的 N/P 位置和同极性规则；
- 原 Gate 不变；
- 两套自动 VBIAS 模板；
- 每操作独立 VBIAS Cell；
- PMOS Source 侧 Cascode；
- Source 串联电阻；
- 2～100 级 Shared-Gate Stack；
- 多操作合并同一功能封装、多个 Bias 封装隔离；
- OA 端子语义映射、引脚短线避碰、直接内部连线；
- 父图与子 Cell 独立回读；
- 源图不变校验；
- CDF 参数回读等价比较和计划外实例/端口检测。

---

## 6. 当前本地验证证据

2026-09-29 已重新执行：

```bash
./scripts/build.sh
```

结果：退出码 `0`，生成：

```text
build/bin/st_circuit_tool
build/tests/*
```

随后执行：

```bash
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

结果：退出码 `0`；摘要为：

```text
test programs passed: 19
demos passed: 2
cli help passed: 1
server backend contract passed: 1
shell syntax checks passed: 14
```

这证明公共 C++/Shell/SKILL 静态契约和 Fake Host 回归当前全绿，但不证明真实服务器端到端通过。

生产 Provider 的负向门禁也已验证：

```bash
ST_BUILD_MAAU_SITE_PROVIDER=ON \
ST_MAAU_SITE_HOST_LIBRARY= \
./scripts/build.sh
```

预期：退出码 `2`，明确提示：

```text
ST_MAAU_SITE_HOST_LIBRARY must be an existing absolute library path
```

兼容测试构建后不应留下：

```text
build/bin/st_maau_op_provider
build/bin/st_maau_op_provider.site-linked
```

---

## 7. 当前不能宣称完成的内容

以下三项仍然是 `planned_not_run` / 未完成：

1. 真实现场 PDK 适配器：目前只有严格回调契约，没有读取真实 PDK 可靠性和 Bulk/Well 的现场代码；
2. 真实 Maau/Spectre Host：目前只有链接边界，没有现场 Case/Bench/Simulator API 实现；
3. 真实 ICADVM18.1/PDK/Maau/Spectre 端到端会话：尚无新代码版本的服务器命令、退出码、日志和原始产物。

因此现在不能说：

- “真实 PDK 扫描已经通过”；
- “真实 Spectre 候选求解已经通过”；
- “最终 Virtuoso 生成已经端到端通过”；
- “ready_for_sizing=true 已由真实服务器证明”。

---

## 8. 下一步 A：实现真实 PDK Site Adapter

### 8.1 为什么必须有 Site Adapter

公开 `Tech` API 可以给出 MOS/电阻集合、CDF 映射和几何约束，但当前检查到的公开接口没有完整暴露每个器件的 `maxAbsVgs/maxAbsVds/maxAbsVgb` 和 Bulk/Well 规则。

`KimiCode` 中可参考：

- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/tech.h`
- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/tech_factory.h`
- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/details/tech_factory.cc`
- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/details/new_techdata_accessor.*`
- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/details/old_techdata_accessor.h`
- `/Users/zkw/Desktop/KimiCode/src/common/core/tech/tech.proto`

可见的线索包括 `LutInfo.max_vol`、旧数据结构中的 `vgs_lut/vds_lut/vsb_lut`，但它们没有通过当前公开 `Tech` 接口完整暴露。新 Agent 不得直接按 Cell 名或电压等级猜值。正确做法是：

1. 优先找到现场已有的 PDK 可靠性/器件注册表接口；
2. 如果字段存在但未公开，给 Maau `Tech` 增加一个最小只读 accessor，或在现场适配库中访问已经批准的内部接口；
3. 如果某 PDK 的元数据确实缺失，让该器件被拒绝并记录原因，不使用 `inf` 或固定 1.2/1.8V 冒充真实限制。

### 8.2 必须实现的核心回调

Site SKILL 文件由 `ST_PDK_TECH_ADAPTER` 指定，至少必须定义：

```lisp
StSiteTechDescribeDevice(library cell view)
```

建议同时按现场权威接口实现：

```lisp
StSiteTechLibraryIdentity(library)
StSiteTechSameProcessP(sourceLibrary candidateLibrary)
StSiteTechGeneratedLibraryP(library)
StSiteTechDeviceLibraryP(sourceLibrary candidateLibrary)
StSiteTechPdkDeviceCellP(sourceLibrary candidateLibrary cell view cdfData)
StSiteTechCandidateLibraries(sourceLibrary)
StSiteTechCurrentModelContext(sourceLibrary)
```

`StSiteTechDescribeDevice` 返回的 association list 至少要包含并有真实来源证明：

```text
kind
terminalNames
terminalRoles
normalizedToCdf
parameterConstraints
minWidth/maxWidth
minLength/maxLength
minResistance/maxResistance
maxAbsVgs/maxAbsVds/maxAbsVgb
voltageDomains
bulkRule
pdkName/pdkVersion/processIdentity
modelName/modelSections/corners
kindSource/terminalSource/cdfSource
reliabilitySource/bulkSource/domainSource/cornerSource/deviceProofSource
```

来源字段不能是空、`missing`、`unknown`，也不能含 `guess` 或 `inference`。

### 8.3 Site Adapter 的正确数据流

推荐数据流：

```text
当前 DUT L/C/V
  -> 当前 tech attachment / Maau Tech identity
  -> PDK 权威 device-library registry
  -> 每个 PDK primitive 的 OA symbol + CDF + Tech metadata
  -> 可靠性和 Bulk/Well 权威表
  -> StSiteTechDescribeDevice
  -> scan_pdk.il
  -> device_catalog.tsv + pdk_identity.tsv
```

如果现场更适合先由 C++/Maau 导出只读 TSV/JSON，再由 SKILL 回调读取，也可以；但文件必须带当前 PDK identity/version，且 `scan-pdk` 必须检查来源一致，不能接受用户库或生成库冒充 PDK primitive。

### 8.4 Site Adapter 验证

在服务器执行前设置：

```csh
setenv ST_PDK_TECH_ADAPTER /absolute/path/to/site_tech_adapter.il
```

路径必须是绝对、普通、可读文件。

先只跑 `scan-pdk`，预期：

- 退出码 `0`；
- `device_catalog.tsv` 不只是 header；
- `pdk_identity.tsv` 的 `context_complete=true`、`scan_complete=true`；
- `diagnostic` 为空；
- 至少存在当前操作所需的可用同极性 MOS、另一极性 Mirror MOS 和真实电阻；
- 每个可接受行 `reliability_complete=true`、`bulk_rule_complete=true`；
- 来源字段均为权威来源；
- 用户库、生成库、同 tech attachment 但非 PDK primitive 的 Cell 不得混入。

失败时应保留明确拒绝原因，而不是降低标准。

---

## 9. 下一步 B：实现真实 Maau/Spectre Host 库

### 9.1 Host 必须完成的六个动作

现场类实现 `st::maau::OpSimulationHost`：

```cpp
int ValidateBench(const CellViewRef&, std::string&);
HostStatus RebindDutInTemporaryCase(const CellViewRef&, const CellViewRef&,
                                    const std::filesystem::path&);
HostStatus PreserveBenchEnvironment(const CellViewRef&, const std::string&);
HostStatus RequestDcOpAndOppoint();
int RunSpectre(const std::filesystem::path&, std::string&);
HostStatus ExtractOperatingPoint(OperatingPointSnapshot&);
```

必须导出：

```cpp
extern "C" st::maau::OpSimulationHost*
st_maau_create_site_op_simulation_host();
```

返回对象的生命周期由 `std::unique_ptr<OpSimulationHost>` 接管，因此必须用兼容的 C++ 分配方式创建，并确保现场库和 Provider 使用兼容 ABI。

### 9.2 可参考的真实 Maau API

已经检查到的真实源码：

- `common/core/ops/simulator/spec_simulator.h/.cc`
- `common/core/ops/simulator/simulation_flow.h/.cc`
- `common/core/ops/simulator/simulation_adapter.h/.cc`
- `common/core/ops/simulator/simulator.h/.cc`
- `common/core/ops/binder/signal_binder.h/.cc`
- `common/core/tech/tech.h`
- `common/basic/project_config.h`
- `common/core/ops/operator_param.proto` 的 `CircuitDesignInfo`
- `modules/mapping/schematic/internal/circuitanalysis/circuit_analysis_with_virtuoso.*`

不要仅仅调用裸 `SpecSimulationTask` 就宣布完成。Host 还必须解决：

1. `ValidateBench` 确认用户传入的 Bench L/C/V 确实存在；
2. 创建临时 Case 或临时配置，不修改原 Case；
3. 把临时 Case 的 DUT 绑定到候选 OA CellView；
4. 保留原 Bench 激励、模型、温度、Corner 和环境；
5. 明确请求 DC 和 opPoint；
6. 运行 Spectre；
7. 从结果提取目标 MOS 及模板 MOS 的 `id/vgs/vds/vbs/vth/vdsat`；
8. 填写与请求完全一致的七字段 `AnalysisIdentity`；
9. 区分：Bench 不存在=64、启动失败=70、不收敛=71、结果提取失败=74；
10. 保留仿真目录和日志供审计。

### 9.3 构建生产 Provider

现场 Host 库构建完成后：

```bash
ST_BUILD_MAAU_SITE_PROVIDER=ON \
ST_MAAU_SITE_HOST_LIBRARY=/absolute/path/to/libst_maau_site_host.so \
./scripts/build.sh
```

预期：

```text
build/bin/st_maau_op_provider
build/bin/st_maau_op_provider.site-linked
```

然后：

```csh
setenv ST_OP_PROVIDER_BIN /absolute/path/to/st_maau_op_provider
source server/setup_backend.csh /tmpdata/maau_epc/users/k00981589/st-engine-maau
```

`ST_OP_PROVIDER_BIN` 必须是绝对可执行路径。不要手工伪造 `.site-linked` 标记。

### 9.4 先做不改电路的已知 Bench 对照

在跑自动 VBIAS 前，用一个当前 Case 已经有可信 DC OP 的原始 DUT：

1. 用 Provider 对未修改 DUT + 原 Bench 跑 `run-op`；
2. 比较输出 MOS 工作点与 Case 已有结果；
3. 确认实例路径、符号方向和单位一致；
4. 确认七字段身份一致；
5. 确认输出不是 Fake Host 固定值。

没有这一步，不要直接用自动求解结果判断 Host 正确。

---

## 10. 下一步 C：修正剩余文档/CLI 小问题

继续功能实现前或同时修复下列已发现问题：

1. `st_circuit_tool inspect --help` 当前显示 `[--pvt_corners ...]`，而实际解析的是 `--pvt-corners`；帮助文本应统一为连字符版本，并加测试；
2. `docs/automatic-pdk-vbias-server-validation.md` 的“generate 自动闭环顺序”和候选产物仍残留旧的 `--candidate-netlist` / `candidate_NNN.scs` 旁路说法，应改成“候选唯一 OA CellView + 该 CellView 回读网表 + run-op”；
3. `docs/023-026结构变换独立测试命令.md` 末尾仍写“PVT 失败不阻塞”，与现代码冲突，应改成配置 PVT 后失败阻塞；
4. `.superpowers/sdd/.../progress.md` 是历史实施账本，Task 8/9 中也残留旧 candidate-netlist 和旧 PVT 非阻塞描述。不要按它覆盖新代码；应追加勘误，不要改写历史证据；
5. `docs/023-026...` 的跨 Flavor 章节仍说依赖旧“兼容矩阵”。当前代码设计是动态 PDK 同极性/端子/电压域/可靠性/参数可解筛选，`compatible_masters` 只作历史诊断，文档需统一。

这些是文档和帮助一致性问题，不是理由去降低当前严格代码门禁。

---

## 11. 真实服务器端到端验收顺序

### 11.1 前置输入，禁止猜测

执行前必须从真实 Case/Registry 取得：

- source `cds.lib`；
- DUT lib/cell/view 和 core subckt；
- Bench lib/cell/view；
- 当前 PDK 名/version/Corner；
- VBIAS `VHIGH` / `VLOW` 父层真实网名；
- NMOS Bulk 网；
- 目标可修改 MOS 实例；
- PVT Corner 列表（如果本轮要做 PVT）；
- Site PDK adapter 绝对路径；
- Site OP Provider 绝对路径。

当前已知 Capless 核心示例：

```text
source lib: HiAplat730RV200_Maau_cal
source cell: ocldo18to12_200ma_core
view: schematic
已用过的 NMOS 示例: I52
此前读到的连接: D=VBN G=ENN S=AGND B=AGND
```

Bench 和高压轨仍必须从真实 Case 获取，不能根据截图或旧会话猜。

### 11.2 新建全新会话

建议使用新的编号，例如 `027`，不要复用 012～026 的 `work`、`analysis`、staging 或目标 CellView。

```csh
cd /tmpdata/maau_epc/users/k00981589/st-engine-maau
setenv ST_PDK_TECH_ADAPTER /absolute/path/to/site_tech_adapter.il
setenv ST_OP_PROVIDER_BIN /absolute/path/to/st_maau_op_provider
source server/setup_backend.csh /tmpdata/maau_epc/users/k00981589/st-engine-maau
echo $status
```

预期 setup 明确 ready，两个变量都没有被 unset。

准备新 `cds.lib`：

```csh
./server/prepare_session.sh \
  --source-cds-lib /absolute/source/cds.lib \
  --session-dir /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/cadence \
  --variant-lib HiAplat730RV200_Maau_cal_ST
echo $status
```

预期退出码 `0`，只生成本会话 `cds.lib` 和隔离的 variant/staging library 映射。

### 11.3 Inspect

```csh
./build/bin/st_circuit_tool inspect \
  --backend /tmpdata/maau_epc/users/k00981589/st-engine-maau/server/st_virtuoso_backend.sh \
  --cds-lib /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/cadence/cds.lib \
  --lib HiAplat730RV200_Maau_cal \
  --cell ocldo18to12_200ma_core \
  --view schematic \
  --core-subckt ocldo18to12_200ma_core \
  --bench-lib REAL_BENCH_LIB \
  --bench-cell REAL_BENCH_CELL \
  --bench-view REAL_BENCH_VIEW \
  --simulator spectre \
  --nominal-corner tt \
  --vbias-vhigh-net REAL_HIGH_RAIL \
  --vbias-vlow-net AGND \
  --work-dir /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/work \
  --variant-lib HiAplat730RV200_Maau_cal_ST \
  --variant-cell ocldo18to12_200ma_core_TV0027 \
  --variant-id TV0027 \
  --skill /tmpdata/maau_epc/users/k00981589/st-engine-maau/skill/standalone_topology_variant.il
echo $status
```

如需 PVT，追加：

```text
--pvt-corners ss,ff
```

预期：

- 退出码 `0`；
- 非空 `before/device_catalog.tsv`；
- 非空 `analysis/pdk_catalog.json`；
- 非空 `before/mos_inventory.tsv`；
- `analysis/cross_flavor_candidates.json` 带接受/拒绝理由；
- 日志没有猜测型已接受记录；
- catalog/identity 的 PDK 与 DUT 一致。

### 11.4 Confirm

同型 NMOS 示例操作文件恰好七行：

```csh
printf '%s\n' \
  'id=op_i52_same_cascode' \
  'type=same_type_cascode' \
  'instance=I52' \
  'gate_policy=fixed' \
  'voltage_domain=core' \
  'nmos_bulk_net=AGND' \
  'tie_isolated_pmos_to_source=true' \
  > /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/op_i52_same_cascode.conf

nl -ba /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/op_i52_same_cascode.conf
```

文件中不允许出现 `bias.*`、`op.*`、模板 Master、命令文本或空行混入。

```csh
./build/bin/st_circuit_tool confirm \
  --session /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/work \
  --operation /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/op_i52_same_cascode.conf
echo $status
```

预期退出码 `0`，当前操作数为 1。

### 11.5 Generate

```csh
./build/bin/st_circuit_tool generate \
  --session /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_027/work
echo $status
```

真实成功预期：退出码 `0` 且显示：

```text
structural_ready=true
nominal_dc_ready=true
parameters_quantized=true
ready_for_sizing=true
```

配置 PVT 时还必须：

```text
pvt_ready=true
```

任一阶段失败时，不要立刻改代码。先收集：

```csh
cat .../work/reports/validation.txt
grep -nE '\*Error\*|FAILED|EXCEPTION|PARSER (ERROR|WARNING)' .../work/logs/*.log
find .../work/analysis -maxdepth 4 -type f -print | sort
```

并定位失败阶段是 scan、baseline OP、candidate materialize、candidate run-op、solve、final nominal DC、PVT、round-trip 还是 publish。

### 11.6 成功后必须核对的产物

```text
before/core_before.scs
before/mos_inventory.tsv
before/device_catalog.tsv
analysis/pdk_catalog.json
analysis/cross_flavor_candidates.json
analysis/baseline_op.json
analysis/baseline_op/
analysis/candidates/<每候选独立目录及OA/plan/netlist/log/identity/mos>
analysis/solver_trace.jsonl
analysis/resolved_parameters.json
analysis/variant_op/
expected/core_expected.scs
materialization/plan.json
after/source_roundtrip.scs
after/core_roundtrip.scs
after/package_*.scs
reports/validation.txt
logs/
```

成功后还要：

1. 比较 `before/core_before.scs` 和 `after/source_roundtrip.scs`，证明源图不变；
2. 比较 `expected/core_expected.scs` 与 `after/core_roundtrip.scs`；
3. 单独检查每个 `after/package_*.scs`；
4. 检查 `resolved_parameters.json` 中模板 ID、Master、CDF 参数、VBIAS、IQ 和 PVT；
5. 检查 solver trace 中每候选的身份、约束、退出码、日志和保留/淘汰原因；
6. 用 `open` 打开最终父图；
7. 在 Virtuoso 中进入功能封装和 VBIAS 封装，人工核对器件、端子、Gate、Bulk 和层级；
8. 从最终父图和每个子 Cell 再生成网表进行独立审计。

---

## 12. 失败场景必须覆盖

真实验收不能只测成功。至少覆盖：

1. PDK 元数据缺失：`scan-pdk` fail closed；
2. Bench 不存在：退出 64；
3. Provider/Spectre 启动失败：退出 70；
4. Spectre 不收敛：退出 71，候选不中选；
5. OP 提取/身份不匹配：退出 74；
6. 全候选不合法：有非空 solver trace，不写最终 OA plan，不 publish；
7. 主支路或模板任一器件可靠性超限：给出具体 `reliability_vgs/vds/vgb`；
8. CDF 回读参数被 PDK callback 恢复或量化不一致：停在 round-trip；
9. PVT 任一 Corner 失败：`pvt_ready=false`、`ready_for_sizing=false`、不 publish；
10. 两个 Fixed-Bias Cascode：两个功能封装 + 两个独立 VBIAS 封装，互不共享输出网和内部器件。

---

## 13. 完成标准

只有以下九项全部满足，任务才能标为完成：

1. 本地 `./scripts/build.sh` 和 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0；
2. 生产 Provider 确实链接现场 Host 库，已知未修改 Bench OP 对照通过；
3. 真实 `scan-pdk` 证明当前 PDK identity，并输出有权威来源的 MOS/电阻/可靠性/Bulk 数据；
4. 至少一个求解候选是完整临时 OA Cascode + VBIAS DUT，而不是文本旁路；
5. 候选七字段身份完全匹配，实际控制管、实际 Cascode 和所有模板 MOS 都经过约束检查；
6. 选中参数全部量化到 PDK 合法范围；
7. 最终 staging 名义 DC 和全部已配置 PVT Corner 通过相同硬约束；
8. 源图不变，父图和全部子 Cell 回读一致并成功 publish；
9. 证据文档包含精确命令、退出码、绝对日志、PDK identity、源/目标 L/C/V、选中 Master/参数、solver trace、回读网表和 `ready_for_sizing=true`。

完成后新建：

```text
docs/validation/2026-09-29-real-pdk-vbias-evidence.md
```

禁止把 Fake Host 结果写入该文件冒充现场证据。

---

## 14. 新 Agent 的推荐工作顺序

- [ ] 阅读本文；
- [ ] 阅读 `docs/superpowers/plans/2026-09-28-real-pdk-vbias-end-to-end-closure.md`；
- [ ] 运行本地全量测试，确认接手基线；
- [ ] 修正第 10 节列出的帮助/文档矛盾并加最小测试；
- [ ] 在现场 Maau 仓库实现 PDK 元数据出口和 `ST_PDK_TECH_ADAPTER`；
- [ ] 先单独验证真实 `scan-pdk`；
- [ ] 在现场 Maau 仓库实现 `OpSimulationHost` 和 C factory；
- [ ] 先用未修改 DUT 做 OP 对照；
- [ ] 构建带 site host 的生产 Provider；
- [ ] 新建全新 027 会话执行同型 NMOS Cascode；
- [ ] 失败按阶段取证，不要回退严格门禁；
- [ ] 027 成功后再做 PMOS、跨 Flavor、PVT、双 Cascode 隔离和无解案例；
- [ ] 生成最终真实证据文档；
- [ ] 再次运行本地全量测试，确认现场改动没有破坏公共契约。

---

## 15. 重要文件索引

设计与计划：

- `docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md`
- `docs/superpowers/plans/2026-09-28-real-pdk-vbias-end-to-end-closure.md`
- 本文：`docs/superpowers/plans/2026-09-29-real-pdk-vbias-e2e-continuation-handoff.md`

测试与服务器验收：

- `docs/023-026结构变换独立测试命令.md`
- `docs/automatic-pdk-vbias-server-validation.md`
- `integration/maau/SERVER_VALIDATION.md`

核心自动求解：

- `include/st/AutoBias.h`
- `src/AutoBias.cpp`
- `include/st/DcSolver.h`
- `src/DcSolver.cpp`
- `include/st/OperatingPoint.h`
- `src/OperatingPoint.cpp`
- `src/Cli.cpp`
- `src/Materialization.cpp`

PDK 扫描：

- `server/skill/tech_adapter.il`
- `server/skill/scan_pdk.il`
- `server/bin/scan_pdk_runner.sh`
- `integration/maau/tech_catalog_provider.h`
- `integration/maau/tech_catalog_provider.cc`

真实 OP Provider 边界：

- `integration/maau/op_simulation_provider.h`
- `integration/maau/op_simulation_provider.cc`
- `integration/maau/site_op_simulation_host.h`
- `integration/maau/site_op_simulation_host.cc`
- `app/st_maau_op_provider.cpp`
- `integration/maau/README.md`

构建/设置：

- `CMakeLists.txt`
- `scripts/build.sh`
- `scripts/test.sh`
- `server/setup_backend.csh`
- `server/st_virtuoso_backend.sh`

关键测试：

- `tests/PdkCatalogTest.cpp`
- `tests/AutoBiasTest.cpp`
- `tests/DcSolverTest.cpp`
- `tests/CliWorkflowTest.cpp`
- `tests/VirtuosoBackendTest.cpp`
- `tests/MaauContractTest.cpp`
- `tests/ServerBackendContractTest.sh`

历史实施账本：

- `.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation/`

历史账本用于审计旧任务的改动和 RED/GREEN 证据；当历史描述与本文和当前代码冲突时，以当前代码、当前测试和本文列出的勘误为准。

---

## 16. 交接结论

当前公共代码已经把自动 VBIAS 的结构、候选生成、参数搜索、电气约束、PVT 门禁、封装、回读和发布编排建立起来，并完成本地全量回归。剩余工作不是再写一个 Fake 求解器，而是把两个现场事实源接上：

1. 真实 PDK 权威元数据；
2. 真实 Maau Case/Bench/Spectre 工作点。

在这两项接入并取得服务器原始证据以前，项目状态应表述为：

```text
本地逻辑与契约通过；真实 PDK/Maau/Spectre/Virtuoso 端到端待现场收口。
```
