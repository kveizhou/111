# Real PDK VBIAS End-to-End Closure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 修通“真实 PDK 扫描 → 完整 Cascode+VBIAS 候选 OA 变体 → Maau/Spectre DC/PVT 仿真 → 自动参数求解 → 最终 Virtuoso 物化、回读和发布”的端到端链路，只有真实服务器证据齐全才输出 `ready_for_sizing=true`。

**Architecture:** 求解器不再把候选 Spectre 文本网表作为绕过 OA 的旁路输入。每个量化候选先应用真实 Cascode 变换和 VBIAS 模板，生成唯一临时 OA CellView，从该 CellView 在当前 Bench/Corner 下跑 Maau/Spectre，并用候选拓扑哈希、参数哈希和求解器版本绑定返回结果。最终 staging 再执行同一套电气硬约束、结构回读和 PVT 门禁，禁止 Fake Host 成功代替真实验收。

**Tech Stack:** C++17、Cadence SKILL/OA、Bash 后端、Maau Case/Bench API、Spectre DC OP、现有无第三方依赖测试框架。

**Spec:** `docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md`

## Global Constraints

- 不复用原电路 VBIAS/IREF；N/P Cascode 均由当前 PDK 动态目录选择模板器件。
- NMOS Cascode 放在 Drain 侧，PMOS Cascode 放在 Source 侧；原 MOS Gate 不改写。
- 候选、最终 staging 和回读网表必须包含完整的原 MOS、新 Cascode 和 VBIAS 模板。
- 参数必须支持 `W/L/FIN/Finger/M` 和无可调参数的定尺寸 Master，禁止凭空添加 PDK 未登记的 CDF 参数。
- 不根据 Cell 名猜器件类型、端子、可靠性或 Bulk/Well 规则；元数据不完整的候选必须拒绝并记录原因。
- 每次候选仿真保留独立计划、网表、日志、identity.tsv 和 mos.tsv，不得覆盖。
- 候选必须用 `dut_hash + bench_hash + pdk_version + corner + topology_hash + parameter_hash + solver_version` 绑定。
- `ready_for_sizing=true` 必须同时表示：参数合法、名义 DC 硬约束通过、已配置的 PVT 全部通过、OA 结构回读通过。
- 本地 Fake Host 只作回归测试；完成声明需要真实 ICADVM18.1/PDK/Maau/Spectre 的命令、退出码、日志和原始产物。
- 当前传输目录没有 `.git`；不初始化新仓库，不伪造提交记录。

---

### Task 1: 修复候选身份和 run-op 协议

**Files:**
- Modify: `include/st/OperatingPoint.h`
- Modify: `src/OperatingPoint.cpp`
- Modify: `include/st/VirtuosoBackend.h`
- Modify: `src/VirtuosoBackend.cpp`
- Modify: `server/bin/run_op_runner.sh`
- Modify: `integration/maau/op_simulation_provider.h`
- Modify: `integration/maau/op_simulation_provider.cc`
- Modify: `tests/OperatingPointTest.cpp`
- Modify: `tests/VirtuosoBackendTest.cpp`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- Extend `AnalysisIdentity` with `topology_hash`, `parameter_hash`, `solver_version`.
- Replace the unsupported `--candidate-netlist` shortcut with an explicit candidate `--dut-lib/--dut-cell/--dut-view`; `run-op` always simulates the requested OA DUT.
- Identity TSV header becomes `dut_hash bench_hash pdk_version corner topology_hash parameter_hash solver_version total_supply_current`.

- [ ] Write failing identity round-trip tests that reject one-field mismatches for all seven identity fields.
- [ ] Run `./scripts/build.sh && ./build/tests/operatingpointtest`; expect the new tests to fail because fields are absent.
- [ ] Implement the extended TSV parser/writer and `IsReusable` comparison.
- [ ] Write a failing server contract test proving `run-op` rejects unknown `--candidate-netlist` but accepts a candidate OA L/C/V and forwards all identity fields to the provider.
- [ ] Update C++ backend/provider contracts and make the contract test pass.
- [ ] Run the four focused tests and then `./scripts/test.sh`; expect zero failures.

### Task 2: 构建完整可物化的求解候选

**Files:**
- Modify: `include/st/DcSolver.h`
- Modify: `src/DcSolver.cpp`
- Modify: `src/Cli.cpp`
- Modify: `include/st/OaPlan.h`
- Modify: `src/OaPlan.cpp`
- Modify: `tests/DcSolverTest.cpp`
- Modify: `tests/CliWorkflowTest.cpp`
- Modify: `tests/OaPlanTest.cpp`

**Interfaces:**
- `DcEvaluationRequest::candidate` is the full transformed DUT: original MOS rewired, real Cascode added, VBIAS child subckt added, and the VBIAS wrapper connected to the Cascode gate.
- The request also carries deterministic `candidate_id`, `topology_hash`, `parameter_hash`, `solver_version`, and the names of the actual control/Cascode/template MOS roles to check.
- `BackendDcEvaluationHost` builds a unique temporary CellView name, calls `BuildOaMaterializationPlan`, clones the source, writes the candidate plan, executes SKILL, regenerates the candidate netlist for audit, then runs OP on that candidate CellView.

- [ ] Add a failing solver test asserting every candidate contains the real target MOS, real `<target>_CAS`, their series node, Cascode gate connected to the template output, and all template roles.
- [ ] Add a failing CLI integration test asserting the backend sequence is `clone -> materialize -> netlist -> run-op` for every unique candidate and never sends `--candidate-netlist`.
- [ ] Refactor candidate assembly to reuse `applyCascode`/`BuildAutoBiasTemplate` rather than hand-building only the template.
- [ ] Make candidate CellView names and directories deterministic from operation, candidate number and identity hashes; preserve each artifact.
- [ ] Verify focused tests, then full local regression.

### Task 3: 对真实主通路和模板执行同一套电气硬约束

**Files:**
- Modify: `include/st/DcSolver.h`
- Modify: `src/DcSolver.cpp`
- Modify: `include/st/Materialization.h`
- Modify: `src/Materialization.cpp`
- Modify: `src/Cli.cpp`
- Modify: `tests/DcSolverTest.cpp`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `tests/CliWorkflowTest.cpp`

**Interfaces:**
- Introduce a reusable `EvaluateElectricalConstraints` result containing first failed constraint, reliability margin, saturation margin, branch-current error and control-OP error.
- Required MOS set includes original MOS, actual Cascode MOS, Control Replica, Cascode Replica and both mirror devices.
- Final staging OP must be checked with the same function before round-trip and publish.

- [ ] Write failing tests for actual Cascode missing, actual control MOS missing, actual Cascode unsaturated, original MOS over-voltage and template MOS over-voltage.
- [ ] Extract and implement the shared constraint evaluator; preserve exact failure diagnostics in solver trace.
- [ ] Wire the evaluator into final `NominalDcCheck` and reject publication on any hard-constraint failure.
- [ ] Run focused and full tests.

### Task 4: 支持 W/L/FIN/Finger/M 和定尺寸 PDK Master

**Files:**
- Modify: `include/st/PdkCatalog.h`
- Modify: `src/PdkCatalog.cpp`
- Modify: `include/st/AutoBias.h`
- Modify: `src/AutoBias.cpp`
- Modify: `include/st/DcSolver.h`
- Modify: `src/DcSolver.cpp`
- Modify: `tests/PdkCatalogTest.cpp`
- Modify: `tests/AutoBiasTest.cpp`
- Modify: `tests/DcSolverTest.cpp`

**Interfaces:**
- Add a geometry-plan builder that returns all registered adjustable dimensions for a device; an empty dimension list is legal for a fixed-size master.
- Mirror/Cascode search uses the intersection of registered semantics `width,length,fin,fingers,multiplier`; resistance remains mandatory only for the selected resistor.
- Unknown CDF keys are rejected, registered values are parsed, quantized and written using the catalog CDF name.

- [ ] Add failing tests for FIN-only MOS, finger/multiplier MOS, fixed-size MOS, mixed W/L to FIN cross-flavor mapping, and resistor lacking a resistance constraint.
- [ ] Tighten candidate and AutoBias device admission so a selected device is actually solvable; skip an unusable first candidate and choose the next usable candidate.
- [ ] Replace the hard-coded five-dimensional solver vector with role/semantic search parameters derived from the catalog.
- [ ] Preserve fixed-size masters without adding W/L and make all focused tests pass.
- [ ] Run full regression.

### Task 5: 严格扫描当前 PDK 并证明目录完整性

**Files:**
- Modify: `server/skill/scan_pdk.il`
- Modify: `server/skill/tech_adapter.il`
- Modify: `server/bin/scan_pdk_runner.sh`
- Modify: `integration/maau/tech_catalog_provider.h`
- Modify: `integration/maau/tech_catalog_provider.cc`
- Modify: `src/PdkCatalog.cpp`
- Modify: `tests/ServerBackendContractTest.sh`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `tests/PdkCatalogTest.cpp`

**Interfaces:**
- Scan roots come from the active technology/PDK identity and its registered device libraries, not only libraries already instantiated by the DUT.
- Every row records provenance for kind, terminals, CDF mapping, reliability, Bulk/Well, domains and corners; inferred names are diagnostics only and cannot produce an accepted candidate.
- `pdk_identity.tsv` records scanned and skipped libraries with reasons; an incomplete scan makes `scan-pdk` fail closed.

- [ ] Add failing fixtures for a same-PDK library not instantiated in the DUT, name-only MOS inference, missing reliability and missing Bulk rules.
- [ ] Implement technology-root library enumeration and strict provenance checks.
- [ ] Require a positive current-PDK identity proof and at least one usable N/P mirror plus resistor when the requested Cascode polarity needs them.
- [ ] Run shell contract, catalog and Maau contract tests.

### Task 6: 接入现场 Maau/Spectre Host，不再默认运行占位 Provider

**Files:**
- Create: `integration/maau/site_op_simulation_host.h`
- Create: `integration/maau/site_op_simulation_host.cc`
- Modify: `app/st_maau_op_provider.cpp`
- Modify: `CMakeLists.txt`
- Modify: `scripts/build.sh`
- Modify: `server/setup_backend.csh`
- Modify: `integration/maau/README.md`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- The production provider must construct a linked site host implementing Bench validation, temporary Case DUT rebinding, environment preservation, DC/opPoint request, Spectre execution and OP extraction.
- If private Maau headers/libraries are unavailable, the production target is not built and setup refuses to select it; `UnlinkedMaauOpHost` remains test-only.

- [ ] Add a failing build/contract test proving the installed provider cannot be the unlinked placeholder.
- [ ] Implement the site host against the actual Maau APIs present on the server; do not invent unavailable class or method names.
- [ ] Add compile-time feature detection and explicit link configuration for the site SDK.
- [ ] Run the provider against a known unchanged DUT/Bench and compare its TSV to the existing Case DC operating point.

### Task 7: 收紧日志、诊断、PVT 和发布门禁

**Files:**
- Modify: `src/DcSolver.cpp`
- Modify: `src/VirtuosoBackend.cpp`
- Modify: `include/st/Materialization.h`
- Modify: `src/Materialization.cpp`
- Modify: `src/Cli.cpp`
- Modify: `tests/DcSolverTest.cpp`
- Modify: `tests/VirtuosoBackendTest.cpp`
- Modify: `tests/CliWorkflowTest.cpp`

**Interfaces:**
- Candidate diagnostics retain backend exit code, log path and artifact path in `solver_trace.jsonl`.
- Log path includes candidate ID, topology hash prefix, parameter hash prefix and corner.
- Configured PVT is blocking: any configured corner failure keeps `ready_for_sizing=false` and prevents publish.
- `run_nominal_dc=false` cannot silently set `nominal_dc_ready=true`; callers outside the automatic path receive an explicit `not_requested` state rather than a false success.

- [ ] Add failing tests for unique logs, preserved exit diagnostics, PVT failure blocking publish and no-DC callers not claiming readiness.
- [ ] Implement the gates and update validation reports.
- [ ] Run the entire local test suite twice and compare solver trace bytes for determinism.

### Task 8: 真实 ICADVM18.1/PDK/Maau/Spectre 端到端验收

**Files:**
- Modify: `docs/automatic-pdk-vbias-server-validation.md`
- Modify: `integration/maau/SERVER_VALIDATION.md`
- Create after execution: `docs/validation/2026-09-28-real-pdk-vbias-evidence.md`

**Interfaces:**
- Use a fresh server session; never reuse an old `analysis/`, staging CellView or solver output.
- Validate one NMOS same-type Cascode, one PMOS same-type Cascode, one cross-flavor candidate and one no-solution/fail-closed case.

- [ ] Upload/sync the reviewed source to the real server and perform a clean build.
- [ ] Run `inspect`; require a non-empty strict PDK catalog with real provenance and no guessed accepted rows.
- [ ] Run baseline OP; require exit 0, matching seven-field identity and real MOS rows.
- [ ] Run `generate`; require at least one candidate OA plan/netlist/log/identity/MOS tuple and a non-empty deterministic solver trace.
- [ ] Require final staging nominal and configured PVT hard constraints to pass before publish.
- [ ] Regenerate source, final parent and every generated child netlist; require source unchanged and expected/round-trip topology plus parameters identical.
- [ ] Open the final Virtuoso CellView and verify the packaged Cascode/VBIAS hierarchy and connections.
- [ ] Record exact commands, exit codes, absolute logs, PDK identity, source/target L/C/V, selected masters/parameters and `ready_for_sizing=true` in the evidence document.
- [ ] Re-run the same session from a fresh work directory and require the same selected parameters and topology hash.

## Completion Gate

The work is complete only when all of the following are true in one fresh run:

1. `./scripts/build.sh && ./scripts/test.sh` exits 0 with no failed local program or shell contract.
2. The production provider is linked to the real site host and a known unchanged Bench OP exits 0.
3. Real `scan-pdk` proves the active PDK identity and exports usable, provenance-backed MOS/resistor metadata.
4. At least one solver candidate is a complete temporary OA Cascode+VBIAS DUT and its seven-field identity matches the request.
5. Solver checks the actual control MOS, actual Cascode and all template MOS, and selects only PDK-legal quantized parameters.
6. Final staging nominal DC and every configured PVT corner pass the same hard constraints.
7. Source remains unchanged; final parent and every generated child round-trip exactly.
8. Publish completes and the final validation report contains `ok=true`, `structural_ready=true`, `nominal_dc_ready=true`, `pvt_ready=true` when PVT is configured, `parameters_quantized=true`, and `ready_for_sizing=true`.
9. The evidence document contains commands, exit codes, logs and raw artifacts; a Fake Host result is not accepted as evidence.
