# 独立工程边界纠正

用户已确认：本目录独立编译；KimiCode 只作源码参考；不同电路由输入的原始 PDK 根目录识别本次 PDK。此前 Maau 原生运行时不得成为必需依赖。

## 实施和验收

1. [x] 默认环境使用项目内独立 Cadence/OCEAN/Spectre Provider；移除默认 Maau 安装路径及原生链接要求。
2. [x] 增加独立入口，接受原始 `--pdk-root` 和电路/Bench/仿真条件，归档并恢复会话配置；透传既有结构 CLI 命令。
3. [x] 只读枚举该根目录内已注册的 OA 库和真实 CDF；结合真实模型声明解析 N/P/电阻，不能按器件名猜测极性。无法从数据证明的约束/额定值明确报告缺失，支持 PDK 文档给出的补充规则。
4. [x] 独立 Runtime 用 Cadence 原生 netlisting 和 Spectre 运行；用 OCEAN 原始结果读取保持电流符号；实际 DUT 顶层导出转换为子电路时校验真实 OA 端口和 Bench 端口。
5. [x] 用失败用例约束新行为，独立编译与完整回归；修正文档中的 Maau 必需条件。真实 PDK/Cadence 结果仍以服务器验收为准。

普通 schematic Bench 是当前通用入口；已有 ADE 条件可以导出为独立 OCEAN 脚本声明。温度、模型 section、供电和性能限值是电路仿真条件，并不要求 Maau Case Registry。

## 本地证据与剩余工作

- 独立构建退出 0；完整回归退出 0：19 个 C++ 程序、2 个 demo、CLI help、server backend contract、17 项 shell 检查、20 项独立 Site/OP 测试。日志为 `docs/validation/2026-10-07/standalone-build.log` 与 `standalone-tests.log`。
- 复审发现的三项 Important 已修复，并补充 Corner 实际参数作用域、CDF 单位与域交集、未知 PDK master 拒绝及明确非目标模型放行的测试；复审重新运行 10 Site + 10 OP，确认关闭，未发现其他 Important/Critical。
- 已支持本次 profile 指定的目录外模型与字面 include；实际 CDF 缺范围/单位不会用模型范围冒充，未知 master 会留下诊断并阻断真实 OP。
- 待取得本次 PDK/模型和 Bench 条件，形成该 Capless 的具体数据配置并执行真实服务器验收；特殊 PDK 声明/CDF callback 与可靠性资料以实际文件为准。整机 IQ 的无载/负载扣除口径仍未确认。以上均未计入本地通过结果。
