# LDO 电阻应力放行门禁实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans inline. This transfer directory has no Git repository; do not initialize one.

**Goal:** 对 Source 串联电阻与自动 VBIAS 参考电阻，用当前 Corner 的真实工作点及 PDK 额定值决定候选和最终变体能否放行。

**Architecture:** `resistor.tsv` 为每只电阻记录两个端电位、支路电流，以及站点适配器按真实 master、几何、Corner/温度求出的额定电压、功耗或电流和证据来源。独立校验器逐只匹配新增电阻；任一记录、额定值或身份缺失即失败。现有无电阻的 OP 调用保持两文件格式。

**Tech Stack:** C++17、Bash、Cadence/Maau 宿主边界。

**Spec:** `../../../../LDO结构变换与自动VBIAS_统一需求设计与开发交接.md` 第 3.3、5.4 节。

## Global Constraints

- 只处理核心 Cell 当前层 MOS；Source 电阻保留 MOS 原器件。
- VBIAS 只有 N/P 互补的一套五角色模板，参考电阻需同样检查。
- 额定值必须来自当前 Case 所属真实 PDK 对当前器件几何与 Corner/温度的证明；不能硬编码或从 MOS 限值推断。
- 本地 Fake Host 通过不代表 ICADVM18.1/Maau/Spectre 服务端通过。

## 文件责任

| 文件 | 职责 |
|---|---|
| `include/st/OperatingPoint.h`, `src/OperatingPoint.cpp`, `tests/OperatingPointTest.cpp` | 严格读取/写入可选的电阻工作点与有效额定值 TSV |
| `include/st/ResistorStress.h`, `src/ResistorStress.cpp`, `tests/ResistorStressTest.cpp` | 匹配实例并执行电压、功耗、电流硬门禁 |
| `integration/maau/op_simulation_provider.*`, `include/st/VirtuosoBackend.h`, `src/VirtuosoBackend.cpp`, `server/bin/run_op_runner.sh` | 将第三份 OP 文件从宿主传到客户端并做事务性校验 |
| `include/st/DcSolver.h`, `src/DcSolver.cpp`, `src/Cli.cpp`, `src/Materialization.cpp` | 候选、名义 staging 和 PVT 逐 Corner 检查新增电阻 |
| `server/skill/scan_pdk.il` | 电阻目录准入按已证明的电阻身份和端子规则，不错误套用 MOS Bulk/VGS |

## Task 1：电阻工作点证据与数值校验

- [x] 在 `OperatingPointTest.cpp` 写失败用例：有效电阻行保真；NaN、缺额定电压、缺功耗/电流额定、重复实例、缺来源和缺文件均拒绝。
- [x] 运行 `OperatingPointTest` 确认新增用例失败。
- [x] 扩展 `OperatingPointSnapshot` 及 TSV 重载，要求 `vpos/vneg/current/max_voltage` 有限，额定值大于 0，`max_power` 或 `max_current` 至少一个为正，来源非空。
- [x] 重跑聚焦测试确认通过。

## Task 2：应力判断

- [x] 在 `ResistorStressTest.cpp` 写失败用例：边界通过、越压/越功耗/越流失败、层级实例不唯一失败、遗漏期望电阻失败。
- [x] 运行测试确认失败；实现独立校验器，使用 `abs(vpos-vneg)`、`abs((vpos-vneg)*current)`、`abs(current)`。
- [x] 重跑聚焦测试确认通过；不使用 `I*R` 估算终端压降。

## Task 3：候选及最终放行接线

- [x] 给宿主和 runner 增加可选 `--resistor-output`，第三文件与现有两文件一起验证、回滚、提交；添加失败注入测试。
- [x] 候选和最终 staging 对每只新增 Source/VBIAS 电阻要求 OP 与额定值；量化后的名义参数和每个配置的 PVT Corner 重跑。缺失即拒绝，且不发布 OA 目标。
- [x] 运行 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 与 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh`，两者退出码均为 0；本地 20 个测试程序、2 个 demo、CLI help、server backend contract、14 个 shell 语法检查通过。

本地验证只使用 Fake Maau/Spectre Host。`resistor.tsv` 中的额定值虽带有 master、几何和来源字段，真实站点实现还须证明它们确实来自当前 PDK 对本次几何、Corner/温度的规则；第 4 项完成前不能称真实放行。

## Task 4：真实站点取证

- [ ] 在有 Maau/Cadence 环境的服务器上核对站点 PDK 适配器取得的 master、实例几何、Corner/温度和额定值证据，核对 Spectre 电阻两端电位与电流提取符号。
- [ ] 在隔离派生 CellView 运行真实 Capless 候选、名义和 PVT，保存扫描、日志、网表、OP、校验报告、源电路不变的证明。
- [ ] 缺少站点访问或私有 API 时明确记录尚未验收，不修改为 `verified_server`。
