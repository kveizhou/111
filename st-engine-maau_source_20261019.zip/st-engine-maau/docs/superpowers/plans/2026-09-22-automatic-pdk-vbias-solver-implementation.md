# Automatic PDK VBIAS Solver Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 让 Cascode 结构变换自动扫描当前 PDK、自动取得或运行 DC 工作点、自动生成完整 VBIAS 子 CellView，并求解所有新增器件的 PDK 合法参数。

**Architecture:** 保留现有 `Netlist → ChangeSet → Packaging → OA Plan → Virtuoso round-trip` 主链路，在它前面增加三个明确边界：动态 PDK 目录、Case/Bench DC 工作点、离散参数求解器。C++ 核心只消费归一化目录和结构化工作点；Virtuoso/工艺差异由后端与 Maau 适配层负责读取，但候选筛选、VBIAS 拓扑、搜索目标和通过条件全部在本仓库内闭环。

**Tech Stack:** C++17、Cadence SKILL/OA、Bash 后端、Spectre DC OP、现有无第三方依赖测试框架。

**Spec:** `docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md`

## Global Constraints

- 不扫描、不复用原电路中的 VBIAS 或参考电流 IREF。
- 每个 Cascode 生成独立 VBIAS CellView，模板内部器件不散落在 LDO 顶层。
- 模板 MOS、电阻和参数必须来自当前 PDK 的动态目录，不使用跨工艺固定 Cell 名。
- 异型 Cascode 只能同极性：NMOS 上加 NMOS，PMOS 上加 PMOS；用户选 Master，工具求参数。
- NMOS Cascode 放在原管 Drain 侧；PMOS Cascode 放在原管 Source 侧。
- 原 MOS Gate 功能连接保持不变；`VG_CTRL` 只给 Replica Gate 增加只读负载。
- 没有可复用的有效 OP 快照时，必须用当前 Case/Bench 自动运行 Spectre DC OP。
- PDK 端子、CDF、可靠性或合法参数信息不完整时拒绝对应候选，不根据 Cell 名猜测。
- `ready_for_sizing=true` 必须同时表示结构回读通过、名义 DC 通过、所有参数已经量化到 PDK 合法值。
- 对称管自动识别和联动修改不在本计划范围内。
- 当前传输目录没有 `.git`；执行时每项仍列出正式仓库的提交命令，在本目录验证时跳过提交，不初始化新仓库。

---

## File Structure

- `include/st/PdkCatalog.h`, `src/PdkCatalog.cpp`: 动态 PDK 参数约束、候选筛选、量化和目录 JSON 报告。
- `include/st/OperatingPoint.h`, `src/OperatingPoint.cpp`: Bench 身份、OP 快照、哈希复用判断和 TSV 解析。
- `include/st/AutoBias.h`, `src/AutoBias.cpp`: 两套固定 VBIAS 器件拓扑及端子连接。
- `include/st/DcSolver.h`, `src/DcSolver.cpp`: 候选枚举、粗搜索、局部精搜索、约束检查和最优解选择。
- `include/st/VirtuosoBackend.h`, `src/VirtuosoBackend.cpp`: `scan-pdk` 与 `run-op` 后端调用。
- `src/Standalone.cpp`, `src/Cli.cpp`: 新操作文件契约、会话上下文、产物和状态编排。
- `src/Transform.cpp`, `src/Packaging.cpp`, `src/OaPlan.cpp`: 求解后 Cascode/VBIAS 子 CellView 的逻辑变换和 OA 封装。
- `server/bin/scan_pdk_runner.sh`, `server/skill/scan_pdk.il`: Virtuoso/Tech 目录导出。
- `server/bin/run_op_runner.sh`, `app/st_maau_op_provider.cpp`: 调用 Case/Bench 仿真适配器并规范化 OP 结果。
- `integration/maau/tech_catalog_provider.*`, `integration/maau/op_simulation_provider.*`: 对接 Maau/KimiCode 的 PDK 与仿真服务，主库不写绝对路径。
- `tests/PdkCatalogTest.cpp`, `tests/OperatingPointTest.cpp`, `tests/AutoBiasTest.cpp`, `tests/DcSolverTest.cpp`: 新模块单元测试。
- 现有 `tests/CascodeTransformTest.cpp`, `tests/PackagingTest.cpp`, `tests/VirtuosoBackendTest.cpp`, `tests/CliWorkflowTest.cpp`, `tests/MaauContractTest.cpp`: 主链路回归和端到端契约。

---

### Task 1: 删除旧 Bias 输入和未使用的电阻阶梯路径

**Files:**
- Modify: `include/st/Bias.h`
- Modify: `src/Bias.cpp`
- Modify: `include/st/Solver.h`
- Modify: `src/Solver.cpp`
- Modify: `src/Standalone.cpp:274-310`
- Modify: `tests/BiasTest.cpp`
- Modify: `tests/StandaloneTest.cpp`
- Modify: `tests/TestMain.cpp`

**Interfaces:**
- Consumes: 现有 `BiasResolution`、`ParseTransformRequest` 和 `solveLadderSections`。
- Produces: 不再接受 `bias.reference_net`、`bias.reference_current`、`bias.voltage`、`bias.output_net`、`bias.element.*`；删除没有产品调用者的 `solveLadderSections` 与 `solveStackGate`。

- [ ] **Step 1: 写旧字段拒绝测试**

在 `tests/StandaloneTest.cpp` 增加一个操作文件，其中包含 `bias.reference_current=2u`，并断言：

```cpp
const auto parsed = st::standalone::ParseTransformRequest(operationPath, "ldo_core");
CHECK(!parsed.ok && !parsed.diagnostics.empty() &&
      parsed.diagnostics.front().message.find("自动求解器接管") != std::string::npos,
      "旧的手工Bias字段必须被明确拒绝");
```

- [ ] **Step 2: 运行测试并确认先失败**

Run: `./scripts/build.sh && ./build/tests/standalonetest`

Expected: `FAIL: 旧的手工Bias字段必须被明确拒绝`。

- [ ] **Step 3: 收紧操作文件解析契约**

在 `ParseTransformRequest` 的 Cascode 分支扫描全部键；以下精确键或前缀立即返回 `MissingInput`：

```cpp
static const std::set<std::string> owned = {
    "bias.reference_net", "bias.reference_current", "bias.voltage",
    "bias.output_net"
};
if (owned.count(key) != 0 || key.rfind("bias.element.", 0) == 0) {
    return operationError("字段" + key + "已由自动求解器接管");
}
```

同一修改中移除 `parseAutomaticBias` 对目标电压、上下轨电压和参考电流的读取；操作文件只保留结构意图、目标实例、异型 Master、Voltage Domain 与 Bulk 策略。

- [ ] **Step 4: 删除死代码并更新调用者**

从 `Solver.h/.cpp` 删除：

```cpp
double solveStackGate(...);
std::vector<double> solveLadderSections(...);
```

从 `Bias.h/.cpp` 删除需要 `approved/reference_net/reference_current` 的 `GeneratedBiasTemplate` 和旧 `BiasResolver::Resolve` 路径；暂时保留 `BiasElementPlan`、`BiasResolution::Cost` 与 `VoltageWindow`，供后续自动模板和求解器复用。

- [ ] **Step 5: 运行全量本地测试**

Run: `./scripts/build.sh && ./scripts/test.sh`

Expected: 输出 `test programs passed`、`server backend contract passed: 1`，且不存在 `FAIL:`。

- [ ] **Step 6: 正式仓库提交**

```bash
git add include/st/Bias.h include/st/Solver.h src/Bias.cpp src/Solver.cpp src/Standalone.cpp tests/BiasTest.cpp tests/StandaloneTest.cpp tests/TestMain.cpp
git commit -m "refactor: remove manual bias and unused ladder paths"
```

---

### Task 2: 建立动态 PDK 目录、量化和异型候选筛选

**Files:**
- Create: `include/st/PdkCatalog.h`
- Create: `src/PdkCatalog.cpp`
- Create: `tests/PdkCatalogTest.cpp`
- Modify: `include/st/Types.h`
- Modify: `src/Standalone.cpp:331-456`
- Modify: `src/Standalone.cpp:459-501`
- Modify: `include/st/Standalone.h:14-26`
- Modify: `CMakeLists.txt`
- Modify: `scripts/build.sh`
- Modify: `scripts/test.sh`

**Interfaces:**
- Consumes: `DeviceDescriptor`, `DeviceCatalog`, `DirectMosDevice`。
- Produces:

```cpp
struct ParameterConstraint {
    std::string semantic_name;
    std::string cdf_name;
    double minimum = 0.0;
    double maximum = 0.0;
    double grid = 0.0;
    std::vector<double> discrete_values;
    bool integer_only = false;
};

struct CandidateSelection {
    std::vector<const DeviceDescriptor*> accepted;
    std::map<std::string, std::vector<std::string>> rejected_reasons;
};

double QuantizeParameter(double value, const ParameterConstraint& constraint);
CandidateSelection SelectCrossFlavorCandidates(
    const DeviceDescriptor& original,
    const DeviceCatalog& catalog,
    const std::string& voltage_domain);
std::string WritePdkCatalogJson(const DeviceCatalog& catalog);
```

- [ ] **Step 1: 写目录和候选筛选失败测试**

在 `tests/PdkCatalogTest.cpp` 构造四个 NMOS：合法 1.8 V 管、缺可靠性数据管、缺 Source 端子管、只允许 IO Domain 管，并断言只有第一个进入候选：

```cpp
const auto result = st::SelectCrossFlavorCandidates(original, catalog, "core");
CHECK(result.accepted.size() == 1 && result.accepted.front()->master == "n18_alt",
      "异型候选只保留同极性、完整端子、同电压域和完整可靠性数据器件");
CHECK(result.rejected_reasons.count("n_unknown_limits") == 1,
      "缺可靠性数据的候选保留明确拒绝原因");
```

再覆盖离散 FIN 与连续电阻量化：`3.2 → 3`、`1.4 kΩ` 按 `100 Ω` 网格变成 `1.4 kΩ`、越界值夹到合法边界。

- [ ] **Step 2: 运行新测试并确认缺少接口**

Run: `./scripts/build.sh`

Expected: 编译失败，指出 `st/PdkCatalog.h` 或 `SelectCrossFlavorCandidates` 不存在。

- [ ] **Step 3: 扩展 DeviceDescriptor**

在 `Types.h` 增加：

```cpp
std::string pdk_name;
std::string pdk_version;
std::string model_name;
std::string w_fin_formula;
std::map<std::string, ParameterConstraint> parameter_constraints;
std::set<std::string> model_sections;
std::set<std::string> corners;
bool reliability_complete = false;
bool bulk_rule_complete = false;
```

为避免循环依赖，把 `ParameterConstraint` 定义放在 `Types.h`，`PdkCatalog.h` 只声明算法。

- [ ] **Step 4: 实现量化和动态候选规则**

`SelectCrossFlavorCandidates` 必须逐项检查并记录原因：同极性、OA L/C/V 完整、四个 MOS 语义端子完整、`reliability_complete`、`bulk_rule_complete`、允许目标 Voltage Domain、至少一种可量化尺寸参数。排序键固定为：可靠性余量降序、同 PDK Library 优先、Master 名字典序。

不读取 `compatible_masters`；保留该字段只为读取旧快照时给出弃用诊断。

- [ ] **Step 5: 扩展目录 TSV 读取并输出 JSON 报告**

新增 TSV 列：

```text
pdk_name pdk_version model_name w_fin_formula parameter_constraints model_sections corners reliability_complete bulk_rule_complete
```

`parameter_constraints` 使用确定格式：

```text
width:w:1e-7:1e-4:1e-8:;length:l:8e-8:2.4e-7:0:8e-8,1.2e-7,2.4e-7;fingers:nf:1:64:1:
```

C++ 加载后把完整归一化目录写到 `analysis/pdk_catalog.json`，JSON 中所有 Map 按键排序，便于比较和复现。

- [ ] **Step 6: 改造 MOS 清单**

`ListDirectMos` 调用 `SelectCrossFlavorCandidates`，将 `accepted.master` 写入 `cross_flavor_candidates`；新增 `candidate_rejections` JSON 报告，不能再遍历 `descriptor.compatible_masters`。

- [ ] **Step 7: 构建并运行目录测试**

Run: `./scripts/build.sh && ./build/tests/pdkcatalogtest && ./build/tests/devicecatalogtest && ./build/tests/standalonetest`

Expected: 三个程序均输出 `passed`，且 `PdkCatalog tests passed`。

- [ ] **Step 8: 正式仓库提交**

```bash
git add include/st/Types.h include/st/PdkCatalog.h src/PdkCatalog.cpp src/Standalone.cpp include/st/Standalone.h tests/PdkCatalogTest.cpp CMakeLists.txt scripts/build.sh scripts/test.sh
git commit -m "feat: derive cross-flavor candidates from scanned PDK metadata"
```

---

### Task 3: 增加动态 PDK 扫描后端

**Files:**
- Create: `server/bin/scan_pdk_runner.sh`
- Create: `server/skill/scan_pdk.il`
- Create: `server/skill/tech_adapter.il`
- Create: `integration/maau/tech_catalog_provider.h`
- Create: `integration/maau/tech_catalog_provider.cc`
- Modify: `server/st_virtuoso_backend.sh`
- Modify: `include/st/VirtuosoBackend.h`
- Modify: `src/VirtuosoBackend.cpp`
- Modify: `tests/VirtuosoBackendTest.cpp`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `tests/ServerBackendContractTest.sh`
- Modify: `CMakeLists.txt`

**Interfaces:**
- Consumes: 当前源 `CellViewRef`、`cds.lib`、Maau 工艺对象或 Virtuoso OA/CDF。
- Produces:

```cpp
struct PdkScanOutputs {
    std::filesystem::path raw_catalog_tsv;
    std::filesystem::path pdk_identity_tsv;
};

HostStatus ProcessVirtuosoBackend::ScanPdk(
    const CellViewRef& source,
    const PdkScanOutputs& outputs);
```

- [ ] **Step 1: 写后端命令契约测试**

扩展 `RecordingRunner`，断言 `ScanPdk` 调用参数精确包含：

```text
scan-pdk --cds-lib ... --lib SRC --cell core --view schematic --catalog-output ... --identity-output ...
```

并测试后端返回 0 但缺少任一输出文件时返回 `HostStatus.ok=false`。

- [ ] **Step 2: 运行测试并确认先失败**

Run: `./scripts/build.sh && ./build/tests/virtuosobackendtest`

Expected: 编译失败，指出 `PdkScanOutputs` 或 `ScanPdk` 不存在。

- [ ] **Step 3: 实现 C++ 后端调用**

`ProcessVirtuosoBackend::ScanPdk` 复用现有 `Run`，日志固定为 `logs/scan_pdk.log`；成功后分别检查两个输出文件非空，并把主目录路径放到 `artifact_path`。

- [ ] **Step 4: 实现服务器路由和严格参数检查**

`server/st_virtuoso_backend.sh` 允许 `scan-pdk`；`scan_pdk_runner.sh` 只接受上述六个选项，清空旧输出，然后调用 `scan_pdk.il`。脚本结束前执行：

```bash
backend_require_output "$ST_REQ_PDK_CATALOG_OUTPUT" "dynamic PDK catalog"
backend_require_output "$ST_REQ_PDK_IDENTITY_OUTPUT" "PDK identity"
```

- [ ] **Step 5: 实现两级扫描提供者**

Maau 集成提供者直接消费当前 Maau 工艺对象，调用与 `PdkCollector`、`GetDeviceInfoFromTech` 等价的稳定公开接口，输出归一化 TSV；不得包含 `/Users/zkw/Desktop/KimiCode` 绝对路径。

Virtuoso `scan_pdk.il` 与 `tech_adapter.il` 负责：

1. 从源 CellView 当前层实例收集 PDK Library；
2. 对这些 Library 的 MOS/电阻 Symbol 读取物理端子与 Effective CDF；
3. 调用站点 Tech 适配函数读取范围、离散值、W/FIN 关系、可靠性和 Corner；
4. 缺少可靠性或 Bulk 规则时仍写出记录，但把完成标志写成 `false`；
5. 不生成任何 `compatible_masters` 配对。

站点适配函数签名固定为：

```lisp
StTechDescribeDevice(library cell view)
; 返回 association list，键包括 kind/pdkVersion/modelName/parameterConstraints/
; maxAbsVgs/maxAbsVds/maxAbsVgb/voltageDomains/bulkRule/modelSections/corners
```

`tech_adapter.il` 必须在本仓库内提供 `StTechDescribeDevice` 的默认实现：从 OA Master、Effective CDF、已加载 Tech Library 和当前 Model Section 组合出结果；Maau Tech Provider 可以用同一字段契约覆盖更完整的数据。默认实现读不到的可靠性或 Bulk 规则必须标记为不完整并拒绝该候选，不能把接口留空等用户手工补入。

- [ ] **Step 6: 测试无硬编码配对和缺数据拒绝**

`MaauContractTest` 使用 Fake Tech Provider 返回两种 PDK，验证每次扫描结果只来自当前 DUT PDK；`ServerBackendContractTest.sh` 检查新 verb、未知参数拒绝和空产物失败。

- [ ] **Step 7: 运行后端契约测试**

Run: `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh && ./build/tests/virtuosobackendtest && ./build/tests/maaucontracttest && ./tests/ServerBackendContractTest.sh`

Expected: 三个测试均退出 0；服务契约最后输出 `server backend contract tests passed`。

- [ ] **Step 8: 正式仓库提交**

```bash
git add server/st_virtuoso_backend.sh server/bin/scan_pdk_runner.sh server/skill/scan_pdk.il server/skill/tech_adapter.il include/st/VirtuosoBackend.h src/VirtuosoBackend.cpp integration/maau/tech_catalog_provider.h integration/maau/tech_catalog_provider.cc tests/VirtuosoBackendTest.cpp tests/MaauContractTest.cpp tests/ServerBackendContractTest.sh CMakeLists.txt
git commit -m "feat: scan current PDK devices through backend providers"
```

---

### Task 4: 建立 Case/Bench DC 工作点接口与快照复用

**Files:**
- Create: `include/st/OperatingPoint.h`
- Create: `src/OperatingPoint.cpp`
- Create: `tests/OperatingPointTest.cpp`
- Create: `integration/maau/op_simulation_provider.h`
- Create: `integration/maau/op_simulation_provider.cc`
- Create: `app/st_maau_op_provider.cpp`
- Create: `server/bin/run_op_runner.sh`
- Modify: `server/st_virtuoso_backend.sh`
- Modify: `server/setup_backend.csh`
- Modify: `include/st/VirtuosoBackend.h`
- Modify: `src/VirtuosoBackend.cpp`
- Modify: `tests/VirtuosoBackendTest.cpp`
- Modify: `tests/MaauContractTest.cpp`
- Modify: `CMakeLists.txt`
- Modify: `scripts/build.sh`
- Modify: `scripts/test.sh`

**Interfaces:**
- Consumes: DUT/Bench 身份、Corner、候选变体网表或派生 CellView。
- Produces:

```cpp
struct AnalysisIdentity {
    std::string dut_hash;
    std::string bench_hash;
    std::string pdk_version;
    std::string corner;
};

struct MosOperatingPoint {
    double vd = 0.0, vg = 0.0, vs = 0.0, vb = 0.0;
    double id = 0.0, vgs = 0.0, vds = 0.0, vbs = 0.0;
    double vth = 0.0, vdsat = 0.0, cgg = 0.0;
};

struct OperatingPointSnapshot {
    AnalysisIdentity identity;
    std::map<std::string, MosOperatingPoint> mos;
    double total_supply_current = 0.0;
};

bool IsReusable(const OperatingPointSnapshot&, const AnalysisIdentity&);
bool LoadOperatingPointTsv(const std::filesystem::path&,
                           OperatingPointSnapshot&, std::vector<Diagnostic>&);
```

- [ ] **Step 1: 写 OP 解析和哈希测试**

覆盖：完整 NMOS 记录、缺 `vdsat`、重复实例、DUT Hash 不同、Corner 不同。只有四个身份字段完全相等时 `IsReusable` 返回 true。

- [ ] **Step 2: 运行测试并确认新接口缺失**

Run: `./scripts/build.sh`

Expected: 编译失败，指出 `st/OperatingPoint.h` 不存在。

- [ ] **Step 3: 实现结构化 OP 解析**

TSV 首行固定为：

```text
instance vd vg vs vb id vgs vds vbs vth vdsat cgg
```

身份写在独立 `identity.tsv`：

```text
dut_hash bench_hash pdk_version corner total_supply_current
```

任一目标 MOS 字段缺失、非有限数或实例重复均返回 `MissingInput`，不把零当作缺省值。

- [ ] **Step 4: 增加 run-op 后端调用**

增加：

```cpp
struct OperatingPointOutputs {
    std::filesystem::path identity_tsv;
    std::filesystem::path mos_tsv;
};

HostStatus ProcessVirtuosoBackend::RunOperatingPoint(
    const CellViewRef& dut,
    const CellViewRef& bench,
    const std::string& corner,
    const OperatingPointOutputs& outputs);
```

后端 verb 为 `run-op`，日志固定 `logs/run_op_<corner>.log`。

- [ ] **Step 5: 对接 Maau Case/Bench 仿真提供者**

`MaauOpSimulationProvider::Run` 接收 DUT 变体和当前 Case 的 Bench 标识，完成以下固定动作：

1. 在临时 Case 中把 DUT 引用重绑定到候选派生 CellView；
2. 保留原 Bench 的电源、激励、Model Section 和温度；
3. 强制加入 `dcOp dc` 与目标实例 `oppoint` 保存；
4. 运行 Spectre；
5. 从 `dcOp.dc` 读取目标 MOS 的十项电压/电流数据、`cgg` 和总电源电流；
6. 写出标准 TSV，并记录原始仿真目录。

提供者参考 KimiCode 的 `CircuitAnalysisWithVirtuoso`、`SpecSimulator` 和 `SignalTable` 调用方式，但只通过项目内头文件/链接目标接入，不复制用户机器绝对路径。

`st_maau_op_provider` 是上述 Provider 的命令行入口：接收 DUT/Bench L/C/V、Corner 和输出路径，内部调用 `MaauOpSimulationProvider::Run`。`ST_BUILD_MAAU_COMPAT=ON` 时由 CMake 构建到 `build/bin/st_maau_op_provider`；`setup_backend.csh` 把 `ST_OP_PROVIDER_BIN` 默认设为该绝对路径。`run_op_runner.sh` 只通过这个环境变量调用 Provider，不依赖 PATH 或用户手工命令。

- [ ] **Step 6: 实现 runner 的失败语义**

`run_op_runner.sh` 先检查 `ST_OP_PROVIDER_BIN` 存在且可执行，然后必须区分并返回：Provider 缺失 69、Bench 缺失 64、仿真启动失败 70、Spectre 不收敛 71、结果缺失 74。任何失败均保留仿真目录并在日志输出其绝对路径。

- [ ] **Step 7: 运行 OP 与后端测试**

Run: `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh && ./build/tests/operatingpointtest && ./build/tests/virtuosobackendtest && ./build/tests/maaucontracttest`

Expected: 三个测试退出 0，且 Fake Provider 记录一次 `run-op` 调用。

- [ ] **Step 8: 正式仓库提交**

```bash
git add include/st/OperatingPoint.h src/OperatingPoint.cpp tests/OperatingPointTest.cpp integration/maau/op_simulation_provider.h integration/maau/op_simulation_provider.cc app/st_maau_op_provider.cpp server/bin/run_op_runner.sh server/st_virtuoso_backend.sh server/setup_backend.csh include/st/VirtuosoBackend.h src/VirtuosoBackend.cpp tests/VirtuosoBackendTest.cpp tests/MaauContractTest.cpp CMakeLists.txt scripts/build.sh scripts/test.sh
git commit -m "feat: obtain reusable DC operating points from the active bench"
```

---

### Task 5: 实现两套自给电 VBIAS 拓扑

**Files:**
- Create: `include/st/AutoBias.h`
- Create: `src/AutoBias.cpp`
- Create: `tests/AutoBiasTest.cpp`
- Modify: `include/st/Bias.h`
- Modify: `CMakeLists.txt`
- Modify: `scripts/build.sh`
- Modify: `scripts/test.sh`

**Interfaces:**
- Consumes: 已选 Control/Cascode Master、动态 PDK 目录、原 Source/Gate 网络、求解后参数。
- Produces:

```cpp
struct BiasSizing {
    std::map<std::string, std::string> cascode_parameters;
    std::map<std::string, std::map<std::string, std::string>> element_parameters;
    double nominal_voltage = 0.0;
    double iq_delta = 0.0;
};

struct AutoBiasTemplateRequest {
    std::string operation_id;
    DeviceKind polarity = DeviceKind::Other;
    std::string voltage_domain;
    std::string vhigh_net;
    std::string vlow_net;
    std::string original_source_net;
    std::string control_gate_net;
    std::string control_master;
    std::string cascode_master;
};

struct AutoBiasTemplateResult {
    bool ok = false;
    std::string template_id;
    std::string output_net;
    std::vector<std::string> ports;
    std::vector<BiasElementPlan> elements;
    std::vector<Diagnostic> diagnostics;
};

AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest&,
    const BiasSizing&,
    const DeviceCatalog&);
```

- [ ] **Step 1: 写 NMOS 模板精确连接测试**

断言端口为 `VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_N`，内部连接满足：

```text
P_REF       D=PBIAS_REF G=PBIAS_REF S=VHIGH
R_REF_N     P=PBIAS_REF N=VLOW
P_OUT_N     D=VBIAS_N   G=PBIAS_REF S=VHIGH
N_CAS_REP_N D=VBIAS_N   G=VBIAS_N   S=X_REP_N
N_CTRL_REP_N D=X_REP_N  G=VG_CTRL    S=VS_ORIG
```

- [ ] **Step 2: 写 PMOS 模板精确连接测试**

断言端口为 `VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_P`，内部连接满足：

```text
R_REF_P     P=VHIGH      N=NBIAS_REF
N_REF       D=NBIAS_REF G=NBIAS_REF S=VLOW
P_CAS_REP_P D=VBIAS_P   G=VBIAS_P   S=VS_ORIG
P_CTRL_REP_P D=X_REP_P  G=VG_CTRL    S=VBIAS_P
N_OUT_P     D=X_REP_P   G=NBIAS_REF  S=VLOW
```

- [ ] **Step 3: 运行测试并确认接口不存在**

Run: `./scripts/build.sh`

Expected: 编译失败，指出 `st/AutoBias.h` 不存在。

- [ ] **Step 4: 实现自动器件选择和拓扑构造**

Mirror MOS 按同电压域、可靠性完整、Bulk 规则完整、OA Master 可实例化筛选；电阻按真实 PDK 电阻类别筛选。排序固定为：与 Control 相同 PDK Library、可靠性余量、可调参数完整度、Master 名。

Bulk/Well 通过目录规则生成；目录没有明确规则时返回 `BulkPolicyUnresolved`，不得默认短接 Source。

- [ ] **Step 5: 验证无外部 IREF 和无固定 Cell 名**

测试中把 Library/Cell 名改为另一套 PDK 后仍生成同一角色拓扑；`elements` 中不得出现 `IREF` 网络或源码硬编码的 `n18/p18/rhrpo` 名称。

- [ ] **Step 6: 构建并运行模板测试**

Run: `./scripts/build.sh && ./build/tests/autobiastest && ./build/tests/biastest`

Expected: 输出 `Auto bias tests passed` 和 `Bias tests passed`。

- [ ] **Step 7: 正式仓库提交**

```bash
git add include/st/AutoBias.h src/AutoBias.cpp include/st/Bias.h tests/AutoBiasTest.cpp CMakeLists.txt scripts/build.sh scripts/test.sh
git commit -m "feat: build self-powered NMOS and PMOS cascode bias cells"
```

---

### Task 6: 实现 PDK 离散参数 DC 闭环求解器

**Files:**
- Create: `include/st/DcSolver.h`
- Create: `src/DcSolver.cpp`
- Create: `tests/DcSolverTest.cpp`
- Modify: `include/st/OperatingPoint.h`
- Modify: `include/st/AutoBias.h`
- Modify: `CMakeLists.txt`
- Modify: `scripts/build.sh`
- Modify: `scripts/test.sh`

**Interfaces:**
- Consumes: 原工作点、PDK 目录、Control/Cascode Master、AutoBias 拓扑、Corner 列表。
- Produces:

```cpp
struct DcCandidateMetrics {
    double branch_current_error = 0.0;
    double control_op_error = 0.0;
    double iq_delta = 0.0;
    double reliability_margin = 0.0;
    double saturation_margin = 0.0;
    double area_estimate = 0.0;
};

struct DcEvaluationRequest {
    Netlist candidate;
    std::string root_subckt;
    std::string target_instance;
    AnalysisIdentity identity;
};

class DcEvaluationHost {
public:
    virtual ~DcEvaluationHost() = default;
    virtual bool Evaluate(const DcEvaluationRequest&,
                          OperatingPointSnapshot&,
                          Diagnostic&) = 0;
};

struct AutoBiasSolveResult {
    bool ok = false;
    BiasSizing sizing;
    DcCandidateMetrics metrics;
    std::vector<std::string> trace_lines;
    std::vector<Diagnostic> diagnostics;
};

struct AutoBiasSolveRequest {
    Netlist baseline;
    std::string root_subckt;
    std::string target_instance;
    AutoBiasTemplateRequest template_request;
    OperatingPointSnapshot baseline_op;
    AnalysisIdentity nominal_identity;
    std::vector<std::string> pvt_corners;
};

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest&,
                                  const DeviceCatalog&,
                                  DcEvaluationHost&);
```

- [ ] **Step 1: 写初值与量化测试**

验证同型 Cascode 继承原等效尺寸；异型用有效宽度/电流密度映射；电阻初值为有限正范围的几何中点：`sqrt(min * max)`；每一个值都通过 `QuantizeParameter`。

- [ ] **Step 2: 写目标排序测试**

Fake Host 返回三组都满足硬约束的候选，断言选择顺序严格为：支路电流误差、Control 工作点误差、新增 IQ、可靠性余量、饱和余量、面积。

- [ ] **Step 3: 写硬约束和无解测试**

分别让 Fake Host 返回过压、线性区、VBIAS 越域、不收敛；断言候选被剔除，全部失败时返回最后候选参数和逐项原因。

- [ ] **Step 4: 运行测试并确认缺少求解器**

Run: `./scripts/build.sh`

Expected: 编译失败，指出 `st/DcSolver.h` 不存在。

- [ ] **Step 5: 实现有限搜索空间**

粗搜索只枚举每个参数的 `{min, geometric-mid, mapped-initial, max}` 去重集合；局部精搜索从当前最佳点对每个参数尝试相邻两个合法量化值。设置确定上限：粗搜索最多 256 次，局部精搜索最多 128 次；超过上限返回 `BadParam` 并保留轨迹。

每个候选点都先把当前 Cascode/Mirror/Replica/电阻的量化参数写入一个 `BiasSizing`，再调用 `BuildAutoBiasTemplate`生成该候选的完整网表，最后交给 `DcEvaluationHost::Evaluate`。不允许只在搜索结束后构造一次模板，否则 DC 结果与待选参数不对应。

- [ ] **Step 6: 实现硬约束和目标比较器**

检查目标 MOS、Cascode、Mirror、Replica 的 `|VGS|/|VDS|/|VGB|`、饱和余量、主支路电流、VBIAS 电压域和所有参数范围。比较器使用 tuple，可靠性/饱和余量取负值以实现“越大越优”：

```cpp
return std::tie(a.branch_current_error, a.control_op_error, a.iq_delta,
                neg_a_reliability, neg_a_saturation, a.area_estimate) <
       std::tie(b.branch_current_error, b.control_op_error, b.iq_delta,
                neg_b_reliability, neg_b_saturation, b.area_estimate);
```

- [ ] **Step 7: 写确定性轨迹**

每次评估写一行 JSONL，包含 candidate id、量化参数、Corner、收敛状态、每条硬约束、六项目标；相同输入两次运行的 `solver_trace.jsonl` 必须字节一致。

- [ ] **Step 8: 构建并运行求解器测试**

Run: `./scripts/build.sh && ./build/tests/dcsolvertest`

Expected: 输出 `DC solver tests passed`，Fake Host 调用次数不超过 384。

- [ ] **Step 9: 正式仓库提交**

```bash
git add include/st/DcSolver.h src/DcSolver.cpp include/st/OperatingPoint.h include/st/AutoBias.h tests/DcSolverTest.cpp CMakeLists.txt scripts/build.sh scripts/test.sh
git commit -m "feat: solve PDK-legal cascode and bias parameters with DC feedback"
```

---

### Task 7: 把求解结果接入 Cascode、封装和 OA Plan

**Files:**
- Modify: `include/st/Transform.h`
- Modify: `src/Transform.cpp:192-449`
- Modify: `include/st/Packaging.h`
- Modify: `src/Packaging.cpp:115-367`
- Modify: `include/st/OaPlan.h`
- Modify: `src/OaPlan.cpp`
- Modify: `src/JsonWriter.cpp`
- Modify: `tests/CascodeTransformTest.cpp`
- Modify: `tests/PackagingTest.cpp`
- Modify: `tests/OaPlanTest.cpp`
- Modify: `tests/VariantVerifierTest.cpp`

**Interfaces:**
- Consumes: `AutoBiasSolveResult` 和 `AutoBiasTemplateResult`。
- Produces: 一个 Cascode 功能封装 CellView、一个独立 VBIAS CellView，以及二者在父 Cell 中的连接。

- [ ] **Step 1: 写 NMOS/PMOS 串联位置测试**

NMOS 断言：原管 Drain 改为 `M0_MID`，新增管 D=原 Drain、S=`M0_MID`。

PMOS 断言：新增管 S=原 Source、D=`M0_MID`，原管 Source 改为 `M0_MID`；原管 Gate 网络完全不变。

- [ ] **Step 2: 写双 CellView 封装测试**

断言每个操作生成两个 `OaGeneratedCell`：

```text
<variant>__PKG0001          原MOS + Cascode
<variant>__VBIAS0001        完整自动VBIAS模板
```

父 Cell 只实例化功能封装和 VBIAS 封装；VBIAS 端口连接 `VHIGH/VLOW/VS_ORIG/VG_CTRL/VBIAS_*`，不能出现 `IREF`。

- [ ] **Step 3: 运行现有测试并确认新期望失败**

Run: `./scripts/build.sh && ./build/tests/cascodetransformtest && ./build/tests/packagingtest`

Expected: 新 PMOS Source 侧或双 CellView 断言至少一项失败。

- [ ] **Step 4: 改造 CascodeTransformRequest**

删除 `auto_bias`、手工 `bias`、手工 `op/vdsat/margin/target window` 字段，改为：

```cpp
std::optional<AutoBiasSolveResult> solved_bias;
std::optional<AutoBiasTemplateResult> bias_template;
```

`applyCascode` 在缺少成功求解结果时返回 `BiasUnavailable`，不再在变换函数中猜 VBIAS。

- [ ] **Step 5: 实现 PMOS Source 侧和命名规则**

功能封装内原管保留原实例名，新增 Cascode 命名 `<原名>_CAS`；PMOS 新管必须在 Source 侧。`VG_CTRL` 从原 Gate 引出，`VS_ORIG` 从变换前原 Source 引出。

- [ ] **Step 6: 生成独立 VBIAS OaGeneratedCell**

把 `BiasElementPlan` 转成 `OaCreateInstance`，参数来自 `BiasSizing.element_parameters`；端口按模板固定次序创建，内部串联节点必须用 `OaDirectWire`，普通外部网络用不会穿越其他 Pin 的端口导线。

- [ ] **Step 7: 扩展 JSON 与回读校验**

Plan schema 升级到 3；`JsonWriter` 确定性写出两个 generated cells。`VariantVerifier` 对 VBIAS 子电路逐实例比较 Master、端子连接和所有求解 CDF 参数；缺参数或值不同返回 `VariantParameterMismatch`。

- [ ] **Step 8: 运行结构与 OA 测试**

Run: `./scripts/build.sh && ./build/tests/cascodetransformtest && ./build/tests/packagingtest && ./build/tests/oaplantest && ./build/tests/variantverifiertest`

Expected: 四个程序均输出 `passed`。

- [ ] **Step 9: 正式仓库提交**

```bash
git add include/st/Transform.h src/Transform.cpp include/st/Packaging.h src/Packaging.cpp include/st/OaPlan.h src/OaPlan.cpp src/JsonWriter.cpp tests/CascodeTransformTest.cpp tests/PackagingTest.cpp tests/OaPlanTest.cpp tests/VariantVerifierTest.cpp
git commit -m "feat: package solved cascodes with independent auto-bias cells"
```

---

### Task 8: 串起 CLI 会话、自动仿真、求解产物和状态

**Files:**
- Modify: `src/Cli.cpp`
- Modify: `src/Standalone.cpp`
- Modify: `include/st/Standalone.h`
- Modify: `include/st/Materialization.h`
- Modify: `src/Materialization.cpp`
- Modify: `tests/CliWorkflowTest.cpp`
- Modify: `tests/StandaloneTest.cpp`
- Modify: `tests/VirtuosoBackendTest.cpp`
- Modify: `README.md`

**Interfaces:**
- Consumes: `ScanPdk`、`RunOperatingPoint`、`SolveAutoBias`、现有 Materializer。
- Produces: 可重复的会话目录和四个明确状态。

- [ ] **Step 1: 改写 CLI Workflow Fake Runner**

Fake Runner 必须支持 `scan-pdk` 与 `run-op`，并记录调用顺序。操作文件缩减为：

```text
id=op1
type=same_type_cascode
instance=M0
voltage_domain=core
nmos_bulk_net=VSS
tie_isolated_pmos_to_source=true
```

不再包含 Bias、OP、VBIAS 电压或器件尺寸。

- [ ] **Step 2: 写完整调用顺序和产物断言**

首次 `generate` 的 Fake 后端顺序固定为：

```text
scan-pdk, run-op, clone, materialize, run-op, netlist, netlist, netlist, netlist, publish
```

该测试的 Fake PDK 把每个可调参数都限制为唯一合法值，因此求解器只评估一个候选，才能断言上述精确顺序。多候选情况使用 `dcsolvertest` 断言每个候选均有独立评估，CLI 集成测试不硬编码候选数。

并断言存在：

```text
analysis/pdk_catalog.json
analysis/baseline_op.json
analysis/cross_flavor_candidates.json
analysis/solver_trace.jsonl
analysis/resolved_parameters.json
reports/validation.txt
```

- [ ] **Step 3: 运行 CLI 测试并确认旧流程失败**

Run: `./scripts/build.sh && ./build/tests/cliworkflowtest`

Expected: 调用顺序或新产物断言失败。

- [ ] **Step 4: 扩展 SessionManifest**

保存源 DUT、Bench L/C/V、Simulator、名义 Corner、PVT Corner 列表、PDK 版本、DUT Hash、Bench Hash。`inspect` 新增必填参数：

```text
--bench-lib LIB --bench-cell CELL --bench-view VIEW --simulator spectre
```

Maau 集成直接从当前 Case 填充；Standalone 用户只需要指定 Bench 身份，不填写 OP 数值。

- [ ] **Step 5: 实现 generate 编排**

顺序固定为：加载会话 → 扫描/加载 PDK 目录 → 取得或运行 Baseline OP → 对每个 Cascode 求解 → 重放最终 ChangeSet → 构造功能封装与 VBIAS 封装 → 最终 OA 回读 → 名义状态判定 → PVT → 发布。

其中“对每个 Cascode 求解”的每次 `DcEvaluationHost::Evaluate` 都必须内部执行：构造当前量化模板 → 应用到临时网表 → 构造临时 OA Plan → 克隆到唯一候选 CellView → 物化 → `run-op` → 读取 OP 与约束。最终封装的 Topology Hash、参数 Hash 和 Bench/PDK/Corner 身份与最优候选完全相同时，可复用该候选的名义 DC；任一字段不同就必须对最终 CellView 再跑一次 `run-op`。

任一步失败都停止后续发布，并保留此前产物。

- [ ] **Step 6: 写四种状态**

`GenerationResult` 增加：

```cpp
bool structural_ready = false;
bool nominal_dc_ready = false;
bool pvt_ready = false;
bool parameters_quantized = false;
```

`ready_for_sizing` 只在 `structural_ready && nominal_dc_ready && parameters_quantized` 时为 true；`pvt_ready` 单独报告，不把未配置 PVT 当成失败。

- [ ] **Step 7: 写 validation.txt**

报告按固定顺序写：四种状态、源/目标 LCV、PDK 版本、Bench、Corner、Plan、四类分析产物、Topology Hash、IQ Delta、Gate 附加电容估计、失败阶段和消息。

- [ ] **Step 8: 运行 CLI 与回读测试**

Run: `./scripts/build.sh && ./build/tests/cliworkflowtest && ./build/tests/virtuosobackendtest && ./build/tests/standalonetest`

Expected: 三个程序均输出 `passed`；CLI 成功输出同时包含 `structural_ready=true`、`nominal_dc_ready=true`、`ready_for_sizing=true`。

- [ ] **Step 9: 正式仓库提交**

```bash
git add src/Cli.cpp src/Standalone.cpp include/st/Standalone.h include/st/Materialization.h src/Materialization.cpp tests/CliWorkflowTest.cpp tests/StandaloneTest.cpp tests/VirtuosoBackendTest.cpp README.md
git commit -m "feat: close the CLI loop from PDK scan through DC-ready variant"
```

---

### Task 9: 增加 PVT 复验、无解证据和多操作隔离

**Files:**
- Modify: `src/DcSolver.cpp`
- Modify: `src/Cli.cpp`
- Modify: `src/Packaging.cpp`
- Modify: `tests/DcSolverTest.cpp`
- Modify: `tests/CliWorkflowTest.cpp`
- Modify: `tests/PackagingTest.cpp`

**Interfaces:**
- Consumes: Case 配置的 Corner 列表和多个已确认 Cascode 操作。
- Produces: Corner 逐点结果、失败证据、多 VBIAS CellView 不冲突保证。

- [ ] **Step 1: 写 PVT 一点失败测试**

Fake Host 让 nominal/ff 通过、ss 过压；断言 `nominal_dc_ready=true`、`pvt_ready=false`，报告明确为 `corner=ss constraint=max_abs_vgs`。

- [ ] **Step 2: 写多 Cascode 隔离测试**

对 M0、M1 连续确认两个 Cascode，断言生成：

```text
PKG0001, VBIAS0001, PKG0002, VBIAS0002
```

两套内部节点、输出网和参数 Map 不共享；父电路坐标与端口不冲突。

- [ ] **Step 3: 写无解证据测试**

Fake Host 令全部 384 个候选不收敛，断言：不发布、`ready_for_sizing=false`、`solver_trace.jsonl` 非空、`resolved_parameters.json` 包含 `status=no_solution` 和最后候选。

- [ ] **Step 4: 实现 Corner 循环和独立命名**

名义最优参数固定后逐 Corner 复验，不在不同 Corner 重新选择不同尺寸。命名器按操作序号分配 Bias Package，所有内部名字只在对应生成 CellView 作用域内唯一。

- [ ] **Step 5: 运行 PVT 和隔离测试**

Run: `./scripts/build.sh && ./build/tests/dcsolvertest && ./build/tests/packagingtest && ./build/tests/cliworkflowtest`

Expected: 三个程序均输出 `passed`。

- [ ] **Step 6: 正式仓库提交**

```bash
git add src/DcSolver.cpp src/Cli.cpp src/Packaging.cpp tests/DcSolverTest.cpp tests/CliWorkflowTest.cpp tests/PackagingTest.cpp
git commit -m "feat: verify PVT corners and isolate multiple generated bias cells"
```

---

### Task 10: 完成全量回归和真实服务器验收说明

**Files:**
- Create: `docs/automatic-pdk-vbias-server-validation.md`
- Modify: `docs/023-026结构变换独立测试命令.md`
- Modify: `integration/maau/SERVER_VALIDATION.md`
- Modify: `README.md`

**Interfaces:**
- Consumes: Tasks 1-9 的最终 CLI 和后端。
- Produces: 单会话、单命令的服务器验证步骤及每一步精确预期结果。

- [ ] **Step 1: 写 023-026 四个独立会话命令**

分别覆盖 NMOS 同型、PMOS 同型、NMOS 异型、PMOS 异型；每个会话单独写 `inspect → confirm → generate → validation → round-trip grep → open`，不把多个会话拼进同一个 Shell 命令。四个会话分别从 Maau Case Registry 选择 CAP、Capless、FVF、RES Case，使四类架构都至少完成一次真实 PDK 扫描和名义 DC 闭环；Case 不含对应极性可修改管时，Registry 选择下一条包含该极性的同架构 Case，而不是伪造实例名。

- [ ] **Step 2: 写失败场景命令**

单独覆盖：无合法 PDK 候选、Bench 缺失、DC 不收敛、可靠性超限、CDF 回读参数不同、两个 Cascode 的多 VBIAS 隔离。

- [ ] **Step 3: 本机全量编译测试**

Run: `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh && ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh`

Expected:

```text
test programs passed: 19
demos passed: 2
cli help passed: 1
server backend contract passed: 1
```

测试数按现有十四个程序、四个新增程序和启用的 `maaucontracttest` 计算，共十九个；脚本列表和输出数字必须一致。

- [ ] **Step 4: 静态检查不含旧链路**

Run:

```bash
rg -n 'reference_current|reference_net|solveLadderSections|compatible_masters' include src tests examples
```

Expected: 只允许出现在“拒绝旧字段”测试和兼容读取诊断中；生产求解路径没有匹配。

- [ ] **Step 5: 真实服务器逐项验收**

在 ICADVM18.1 服务器按文档逐个运行 023-026。每个成功会话必须同时出现：

```text
structural_ready=true
nominal_dc_ready=true
ready_for_sizing=true
```

并人工打开功能封装与 VBIAS CellView，核对 PMOS Source 侧、`VS_ORIG`、`VG_CTRL`、独立 Bias 包和无 IREF 端口。

- [ ] **Step 6: 正式仓库提交**

```bash
git add docs/automatic-pdk-vbias-server-validation.md docs/023-026结构变换独立测试命令.md integration/maau/SERVER_VALIDATION.md README.md
git commit -m "docs: add automatic PDK VBIAS server validation"
```

---

## Final Acceptance

实现完成必须同时满足：

1. 操作文件不再要求任何手工 Bias、IREF、OP 或新增器件参数；
2. 当前 PDK 改变后，目录和模板 Master 随扫描结果改变；
3. 异型列表由规则筛选，不依赖 `compatible_masters` 配对表；
4. 没有有效 OP 时自动调用当前 Bench 仿真；
5. NMOS 与 PMOS VBIAS 模板端子关系与设计规格完全一致；
6. PMOS Cascode 位于原管 Source 侧；
7. 每个 Cascode 拥有独立 VBIAS CellView；
8. 所有新增参数是 PDK 合法量化值；
9. OA 回读连接、Master 和 CDF 参数一致；
10. 名义 DC 未通过时绝不输出 `ready_for_sizing=true`。
