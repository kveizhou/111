# Standalone Virtuoso Structure Transformation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a directly runnable C++17 tool that accepts a Virtuoso project and core L/C/V, manages one Change Set, materializes it through a site adapter, and proves schematic/netlist round-trip equivalence.

**Architecture:** Keep the existing circuit transformation core authoritative. Add focused standalone modules for project sessions, current-level MOS inventory, operation-file parsing, a process-backed Virtuoso adapter, and a CLI; use the existing OA diff plan and verifier after moving the host-neutral materialization contract out of the Maau namespace.

**Tech Stack:** C++17 standard library, POSIX process spawning, existing Spectre subset parser, existing OA/SKILL plan writer, Cadence Virtuoso/OCEAN through an external site adapter.

**Spec:** `docs/superpowers/specs/2026-09-15-standalone-virtuoso-flow-design.md`

## Global Constraints

- `st-engine` remains untouched; all implementation is under `st-engine-maau`.
- The executable accepts `cds.lib + library/cell/view`, not a user-supplied baseline netlist.
- Only MOS instances directly present in the selected core subckt are selectable.
- Source OA data is read-only; final publication occurs only after source and target round-trip checks pass.
- No Maau headers, libraries, services, or private runtime types are required by the default build.
- Real Virtuoso and PDK execution remains evidence-gated on the server.

---

### Task 1: Current-level MOS inventory and PDK catalog loading

**Files:**
- Create: `include/st/Standalone.h`
- Create: `src/Standalone.cpp`
- Create: `tests/StandaloneTest.cpp`

**Interfaces:**
- Consumes: `Netlist`, `DeviceCatalog`, selected `core_subckt`.
- Produces: `LoadDeviceCatalogTsv(path)`, `ListDirectMos(netlist, subckt, catalog)`, `WriteMosInventoryTsv(...)`.

- [ ] Write a failing test with a core subckt containing one MOS and one child-subckt instance; assert only the direct MOS is listed and unknown masters are not guessed.
- [ ] Compile and run the test; expect a missing-header or missing-symbol failure.
- [ ] Implement the TSV catalog loader and direct inventory with diagnostics for missing core subckt or malformed catalog rows.
- [ ] Re-run the test and existing tests; expect all to pass.

### Task 2: Session manifest and four operation-file parsers

**Files:**
- Modify: `include/st/Standalone.h`
- Modify: `src/Standalone.cpp`
- Modify: `tests/StandaloneTest.cpp`

**Interfaces:**
- Consumes: `key=value` files and `DeviceCatalog`.
- Produces: `ProjectSelection`, `SessionManifest`, `ParseTransformRequest(path, default_subckt)`, `LoadConfirmedChanges(session)`.

- [ ] Add failing tests for same-type Cascode, cross-Flavor Cascode, resistor, shared-gate Stack, and rejection of missing engineering inputs.
- [ ] Run tests; expect parse symbols or required-field assertions to fail.
- [ ] Implement strict parsing, boolean/numeric/list conversion, resolved Bias parsing, and one immutable `TransformRequest` per file.
- [ ] Run tests; expect all operation cases to pass without relaxing existing electrical validation.

### Task 3: Host-neutral materialization and process adapter

**Files:**
- Create: `include/st/Materialization.h`
- Create: `src/Materialization.cpp`
- Modify: `integration/maau/topology_variant_materializer.h`
- Modify: `integration/maau/topology_variant_materializer.cc`
- Create: `include/st/VirtuosoBackend.h`
- Create: `src/VirtuosoBackend.cpp`
- Create: `tests/VirtuosoBackendTest.cpp`

**Interfaces:**
- Consumes: `GenerationRequest`, backend executable path, project/session paths.
- Produces: `TopologyVariantMaterializer`, `ProcessVirtuosoBackend`, exact backend subcommands and artifact checks.

- [ ] Add a failing fake-backend test asserting the exact sequence `clone -> materialize -> netlist(source) -> netlist(staging) -> publish` and failure on missing artifact.
- [ ] Run tests and confirm the failure is caused by the absent backend/materializer implementation.
- [ ] Move the reusable host contract into `namespace st`, keep thin `st::maau` aliases for compatibility, and implement safe POSIX argv spawning with exit-code/log propagation.
- [ ] Run new and compatibility tests; expect both to pass.

### Task 4: Deterministic local layout context

**Files:**
- Modify: `include/st/Standalone.h`
- Modify: `src/Standalone.cpp`
- Modify: `tests/StandaloneTest.cpp`

**Interfaces:**
- Consumes: baseline geometry TSV, baseline/expected netlists, root source/staging L/C/V.
- Produces: `BuildRootOaContext(...)` with clone mapping, deterministic locations, port positions, and visible net-label wire stubs.

- [ ] Add a failing test that transforms one MOS to a two-level Stack and asserts every changed/new terminal net receives a plan entry and no child hierarchy is cloned.
- [ ] Run the test; expect missing context builder failure.
- [ ] Implement root-only placement anchored at the original instance coordinate, deterministic offsets, and strict failure when the target anchor is absent.
- [ ] Run the OA plan and standalone tests; expect valid deterministic JSON.

### Task 5: Runnable CLI and Change Set workflow

**Files:**
- Create: `app/st_circuit_tool.cpp`
- Create: `tests/CliWorkflowTest.cpp`
- Modify: `CMakeLists.txt`

**Interfaces:**
- Consumes: CLI arguments and the modules from Tasks 1–4.
- Produces: `st_circuit_tool inspect|list|confirm|undo|fresh|generate|open` and documented exit codes.

- [ ] Add a failing workflow test using a fake external backend: `inspect` creates baseline/catalog/geometry/inventory; `confirm` saves one operation; `generate` writes expected/plan/round-trip reports.
- [ ] Compile and run; expect missing CLI workflow symbols/executable failure.
- [ ] Implement the commands, atomic file writes, numbered change files, staging/final names, report output, and refusal to generate an empty Change Set.
- [ ] Run the workflow test and all tests; expect zero failures.

### Task 6: Build/run packaging and server handoff

**Files:**
- Create: `scripts/build.sh`
- Create: `examples/standalone_backend_contract.sh`
- Create: `examples/operations/*.conf`
- Modify: `README.md`
- Modify: `CMakeLists.txt`

**Interfaces:**
- Consumes: a C++17 compiler and, for real execution, a site adapter implementing the six backend verbs.
- Produces: `build/bin/st_circuit_tool`, sample operation files, exact server invocation, success criteria, and an explicit `planned_not_run` boundary.

- [ ] Add a packaging smoke test that runs `scripts/build.sh`, prints CLI help, and runs the local fake-backend workflow.
- [ ] Run it and observe the expected failure before scripts/docs are complete.
- [ ] Add the portable clang++/g++ build script, sample adapter contract, sample operations, CMake targets, and concise README instructions.
- [ ] Run warning-clean compilation, every test, both existing demos, CLI help, and the fake end-to-end workflow; record exact counts and leave real Virtuoso status unclaimed.
