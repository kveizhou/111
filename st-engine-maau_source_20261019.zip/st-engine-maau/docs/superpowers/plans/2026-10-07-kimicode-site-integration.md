# 基于 KimiCode 的现场接入开发

> 历史可选接入计划。用户最新要求是独立编译、输入本次 PDK 路径；当前实施以 `2026-10-07-standalone-path-correction.md` 为准。本文的 Maau 原生构建/Case 不是产品必需条件。

**目标：** 复用已存在的真实 OA 后端操作，在本地完成可部署的 PDK 配置解析、导入 Case 上下文读取和 Maau/Spectre OP Host 接入代码。服务器用于真实编译/链接与电路验收，不作为停止编写接入代码的条件。

**参考源码（只读）：** `/Users/zkw/Desktop/KimiCode`。所有新增实现放在当前 `st-engine-maau` 内，保持其与 Maau 源码的接入边界。

## 已核实事实

- `common/core/ops/pdk_collector.*` 根据 DUT L/C/V 调用 `get_pdk_names`。
- `modules/mapping/schematic/internal/gettechs/get_techs.cc` 根据 OA 库路径匹配 `TECH_ROOT_PATH/*/tech_cfg_v2.0.json` 的 `pdk_path` / `base_pdk_path`。
- `common/core/tech/details/new_techdata_accessor.cc` 明确解析 `device_categories`、`device_type`、`sub_device_type`、`normalization`、`cdf_parameters`、`corners` 和 `temperatures`。
- CDF `constraint` 数组是实际允许值集合，不能擅自改成连续 min/max 区间。单位必须按字段转换；`lut_info.max_vol` 未证明是可靠性额定值，不能用它填 VGS/VDS/VGB 门禁。
- `CircuitDesignConfig::LoadFromFile` 与真实 getters 可取得源/目标 DUT、Bench、工艺、Corner 及仿真路径。新增结构生成限值仅从已声明的 Case 字段或显式配置读取，不按变量名猜。
- `OceanNetlistCreator` / `NetlistBuilder` 从真实 OA 导出 Spectre 网表；`maau::common::Simulator` 通过 `SpecSimulationTask` 执行 Spectre。
- `SignalTable` 的现有 `PsfParser` 调用 `std::abs`，不适合本工具的有符号 OP；应直接采用其底层 `DCHelper::ReadRawPsfData` 读取路径。
- KimiCode 中当前 `dchelper.h/.cc` 和 tech 配置测试 JSON 为零字节，占位文件不能当成真实接口编译/实际 PDK 数据的证据。可依据已存在的调用点写接入代码，最终以完整服务器 Maau 头文件/库编译验证。
- 用户报告旧服务器读取、封装和回读命令已经跑通；该后端继续复用。新增自动 VBIAS/OP/额定值链路仍须单独验收。

## 实施步骤

1. [x] 工艺配置解析器与动态 Site SKILL 回调已写出，本地配置/单位/离散值/路径/身份测试通过；实际 PDK 数值填充和 SKILL 执行待现场验证。
2. [x] 原生 Case 导出与 `maau_case.py` CLI 接线已写出；唯一 Bench、Case/显式输入冲突与按导入工艺自动选配置的测试通过。轨网、性能限值及 OP Corner 读取明确的 Case 数据，原生完整编译及实际文件映射待验。
3. [x] 具体 `maau_site_runtime.cc` / `maau_op.py` 已写出：实际 OA 导出、隔离 Bench 替换、模型/温度/变量保持、Spectre 与有符号 PSF 提取、电阻几何/Corner/温度额定值匹配；fixture 流程测试通过。原生 Maau 编译/链接和真实 PSF 仍待现场验证。
4. [x] 新增 `build_maau_runtime.sh` 与默认 runtime 选择入口；最新普通/兼容 build/test 均退出 0，20 个 C++ 测试程序及 18 项新增配置/OP 测试通过；日志 `docs/validation/2026-10-07/site-build.log` / `site-tests.log`，统一文档及部署说明已更新。
   - 独立审查的七项问题及两项复审残余已修复；最终独立重跑 18 项 Python 测试退出 0，限定范围内未发现其他 Important/Critical 问题。完整兼容回归再次退出 0，含 16 项 shell 语法检查。原生 Maau/Cadence 仍未验证。
5. [ ] 收到具体 PDK/Case 路径后生成该 Capless 的配置，提供一组完整服务器命令。实际服务器编译、PDK/OA、Spectre/DC/PVT 结果取得前保持未验收。

## 执行约束

- 沿用一套 N/P 互补 VBIAS 思路，当前层 MOS、同极性不同 master、Source 保留原 MOS 等已确认定义不变。
- 按 test-driven-development 逐步骤验证；代码依据真实声明和调用点，记录不可在本机编译的私有依赖。
- 没有 SSH 不阻止本地接入开发；只有所需数据值、API 声明或电气口径无法从材料确认时才向用户提问。
- 已向用户询问真实 Capless PDK 根目录及现有工艺/Case 配置路径，继续不依赖该回答的开发。
