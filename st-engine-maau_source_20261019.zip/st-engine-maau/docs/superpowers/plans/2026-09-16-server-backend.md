# Real Virtuoso Server Backend Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an independently deployable six-verb Cadence/Virtuoso backend that connects `st_circuit_tool` to a real OA schematic while protecting the source design.

**Architecture:** A Bash dispatcher and six focused Runner entrypoints share strict argument and batch-execution helpers. Small SKILL programs perform read-only structural export, protected cellview copy, PDK-aware materialization, and GUI open; a csh setup file binds these pieces to the server environment without linking Maau C++.

**Tech Stack:** Bash, csh/tcsh environment setup, Cadence SKILL/OA, existing C++17 CLI and tests.

**Spec:** `docs/superpowers/specs/2026-09-16-server-backend-design.md`

## Global Constraints

- Do not modify source OA cellviews or user `cds.lib` files.
- Do not use `eval` or construct shell commands from untrusted text.
- The default C++ build remains independent of Maau libraries and headers.
- Array instances remain logical groups and repeated-net expressions are never created as ordinary OA nets.
- Cross-Flavor compatibility and PDK limits require explicit policy data.
- Local fake-Virtuoso tests do not count as real server success.

---

### Task 1: Backend command contract and environment validation

**Files:**
- Create: `tests/ServerBackendContractTest.sh`
- Create: `server/lib/backend_common.sh`
- Create: `server/st_virtuoso_backend.sh`
- Create: `server/bin/snapshot_runner.sh`
- Create: `server/bin/clone_runner.sh`
- Create: `server/bin/materialize_runner.sh`
- Create: `server/bin/netlist_runner.sh`
- Create: `server/bin/publish_runner.sh`
- Create: `server/bin/open_runner.sh`
- Create: `server/setup_backend.csh`
- Modify: `scripts/test.sh`

**Interfaces:**
- Consumes: the exact argument arrays already emitted by `ProcessVirtuosoBackend`.
- Produces: executable Runner paths, strict required-option parsing, `run_skill_batch ACTION` and six environment variables.

- [x] Write `tests/ServerBackendContractTest.sh` to assert dispatcher rejection of unknown verbs, failure when Cadence is unavailable, exact option preservation through a fake Virtuoso, missing-marker failure, source=target rejection, and setup-file declarations.
- [x] Run the test and verify it fails because `server/st_virtuoso_backend.sh` does not exist.
- [x] Implement shared option parsing and the dispatcher, then add six thin Runner entrypoints and the csh setup file.
- [x] Run the test and verify the command-contract cases pass.

### Task 2: Read-only OA snapshot and deterministic structural netlist

**Files:**
- Create: `server/skill/backend_common.il`
- Create: `server/skill/export_snapshot.il`
- Create: `server/config/device_policy.tsv`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- Consumes: `ST_REQ_LIB`, `ST_REQ_CELL`, `ST_REQ_VIEW`, output paths and optional policy path.
- Produces: `core_before.scs`, `device_catalog.tsv`, `geometry.tsv`, and a completion marker.

- [x] Extend the fake Virtuoso fixture to inspect the selected SKILL action and produce the three requested artifacts only for snapshot; assert missing artifact fails.
- [x] Run the test and verify failure because snapshot does not yet require all three artifacts.
- [x] Implement the OA exporter with root-only scope, terminal-order catalog, `oa_<lib>__<cell>` master keys, pin filtering, repeated-net normalization, geometry output and conservative policy overlay hooks.
- [x] Run shell and existing C++ tests; verify snapshot contract and catalog shape pass.

### Task 3: Protected clone and publish

**Files:**
- Create: `server/skill/copy_cellview.il`
- Modify: `server/bin/clone_runner.sh`
- Modify: `server/bin/publish_runner.sh`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- Consumes: source and target L/C/V plus explicit `cds.lib`.
- Produces: an isolated copied cellview and completion marker.

- [x] Add tests for missing source/target fields, source=target, and action selection for clone versus publish.
- [x] Run the test and verify the new action assertions fail.
- [x] Implement one protected copy action shared by clone and publish; require an existing writable target library and refuse overwrite unless the target is the expected staging/final name supplied by the caller.
- [x] Run the contract test and verify both verbs pass their safety cases.

### Task 4: PDK-aware materialization adapters

**Files:**
- Create: `server/skill/pdk_adapter.il`
- Create: `server/skill/materialize.il`
- Modify: `server/bin/materialize_runner.sh`
- Modify: `skill/topology_variant.il`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- Consumes: `materialization/plan.json`, `standalone_topology_variant.il`, effective CDF and the staging cellview.
- Produces: checked and saved staging schematic plus completion marker.

- [x] Add a source-level test asserting materialize loads the site adapter before the standalone materializer and refuses absent plan/SKILL files.
- [x] Run the test and verify it fails before the materialize action exists.
- [x] Implement strict CDF parameter assignment/callback, visible port creation, schematic check/save and action result validation; update array creation to separate array name/range from electrical net names.
- [x] Run contract and C++ OA-plan tests; verify no existing materialization behavior regresses.

### Task 5: Round-trip netlist and GUI open

**Files:**
- Create: `server/skill/open_cellview.il`
- Modify: `server/bin/netlist_runner.sh`
- Modify: `server/bin/open_runner.sh`
- Modify: `tests/ServerBackendContractTest.sh`

**Interfaces:**
- Consumes: source or staging L/C/V and output `.scs` path.
- Produces: deterministic round-trip structural netlist or a launched GUI session.

- [x] Add tests asserting netlist reuses the structural exporter and open uses a GUI action without accepting missing L/C/V.
- [x] Run the tests and verify the missing implementations fail.
- [x] Implement netlist export with artifact checks and GUI open with a detached process plus launch log.
- [x] Run the full shell contract test.

### Task 6: Packaging, documentation, and verification

**Files:**
- Modify: `scripts/build.sh`
- Modify: `scripts/test.sh`
- Modify: `README.md`
- Create: `server/README.md`

**Interfaces:**
- Consumes: completed Runner and SKILL files.
- Produces: one documented server setup command, one real `inspect` command, and explicit expected evidence.

- [x] Add build-time executable-bit normalization and shell syntax checks to the test workflow.
- [x] Run the test workflow and verify any packaging omissions fail.
- [x] Document the confirmed LDO library/cell/view, environment setup, first scalar-MOS smoke test, evidence files and current `planned_not_run` boundary.
- [x] Run `./scripts/build.sh`, `./scripts/test.sh`, Bash syntax checks and csh parse checks; report exact results without claiming real Virtuoso materialization.
