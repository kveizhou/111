# 自动 PDK VBIAS 求解器：续作交接与完整执行说明

> 日期：2026-09-24  
> 适用目录：`/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau`  
> 当前阶段：Task 1–3 已关闭；Task 4 的修复代码与本地回归已通过，但独立复核和账本收口尚未完成；Task 5–10 尚未实施。  
> 本文用途：让一个没有本会话上下文的新 Agent 仅凭本文及其引用文件，就能从正确断点继续实施、复核和验证。

---

## 1. 新会话当前只需要做什么

新会话不要直接开始写 VBIAS 模板。正确顺序是：

1. 进入 `st-engine-maau`，读取本文、批准规格、实施计划和进度账本；
2. 核对当前代码仍能通过 Task 4 专项测试和全量回归；
3. 给 Task 4 创建修复后快照和只读复核 Diff；
4. 让一个独立只读 Reviewer 复核 Task 4 原先发现的六个问题；
5. Reviewer 返回 `Clean` 后，更新 Task 4 报告和进度账本，将 Task 4 正式关闭；
6. 然后按 Task 5 → Task 6 → Task 7 → Task 8 → Task 9 → Task 10 的顺序实施；
7. 每个 Task 都必须经过“测试先行 → 实施 → 本地验证 → 独立只读复核 → 修复循环 → 账本记录”；
8. 直到真实服务器验证完成前，不得宣称真实 PDK 扫描、Spectre OP 或 ICADVM18.1 端到端流程已经通过。

本文创建时没有继续修改功能代码。它只固化当前状态和后续做法。

---

## 2. 必读文件、权威顺序和冲突处理

### 2.1 必读文件

按以下顺序阅读：

1. 本文：`docs/superpowers/plans/2026-09-24-automatic-pdk-vbias-solver-continuation-handoff.md`
2. 已批准规格：`docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md`
3. 总实施计划：`docs/superpowers/plans/2026-09-22-automatic-pdk-vbias-solver-implementation.md`
4. 执行账本：`.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation/progress.md`
5. Task 1–4 报告：同一账本目录下的 `task-1-report.md` 至 `task-4-report.md`
6. 结构变换业务方案：`../LDO_MOS四种结构变换设计方案.md`
7. 旧 VBIAS 方案资料：`../LDO_VBIAS生成支路设计方案.md`、`../LDO四种架构Cascode_VBIAS设计方案.md`

### 2.2 权威顺序

发生冲突时，以如下优先级为准：

1. 用户已经明确确认的最新决定；
2. `2026-09-22-automatic-pdk-vbias-solver-design.md`；
3. `2026-09-22-automatic-pdk-vbias-solver-implementation.md`；
4. 本文对当前代码状态和续作断点的说明；
5. `LDO_MOS四种结构变换设计方案.md` 中与批准规格不冲突的 Stack MOS、Source 串联电阻规则；
6. 旧 VBIAS 文档仅作历史背景，不作为实现依据。

### 2.3 已失效的旧方案

旧文档中以下内容已被批准规格明确替代：

- 优先复用原电路已有 VBIAS；
- 搜索或复用原电路参考电流 IREF；
- 要求 Case 预先提供参考电流；
- 要求用户输入 `bias.output_net`、`bias.voltage`、`bias.element.*`；
- 用固定 PDK Cell 名拼装模板；
- 用 `compatible_masters` 维护异型器件两两配对；
- 给 Stack MOS 生成电阻阶梯或多抽头 Gate Bias。

新实现必须是：动态扫描当前 PDK、自动选择真实器件、自动进行 DC 闭环求参、每个 Cascode 生成独立自给电 VBIAS CellView。

---

## 3. 用户已经确认、不得擅自改变的设计决定

### 3.1 四类结构变换

产品需要支持四类 MOS 结构变换：

1. 同型 Cascode：在 NMOS 上加 NMOS，在 PMOS 上加 PMOS，新增管与原管使用同一 Master；
2. 异型 Cascode：仍然是 NMOS 上加 NMOS、PMOS 上加 PMOS，但新增管从当前 PDK 动态扫描出的同极性合法候选中选择；
3. Source 串联电阻：保留原 MOS，在原 MOS Source 一侧串联一个真实 PDK 电阻，不是用电阻替换 MOS；
4. Stack MOS：把单管改为 2–100 只同极性 MOS 串联，全部 Gate 继续接原 Gate 功能网络。

### 3.2 Cascode 串联位置

- NMOS：新增 Cascode 放在原管 Drain 侧，即原管与原 Drain 网络之间；
- PMOS：新增 Cascode 放在原管 Source 侧，即原管与原 Source 网络之间；在常见原理图方向下视觉上位于原管上方；
- 原 MOS Gate 的功能网络不改变；
- 新增 Cascode Gate 由自动生成的 `VBIAS_N` 或 `VBIAS_P` 驱动；
- 不允许 NMOS/PMOS 跨极性替换。

### 3.3 Stack MOS 命名

假设原实例为 `M0`：

- 最靠近原 Drain 一侧的器件继续命名为 `M0`；
- 沿着 Drain → Source 方向依次命名 `M0_S1`、`M0_S2`……；
- 2 管 Stack 为 `M0`、`M0_S1`；
- 所有 Gate 接原 Gate 网络；
- 不调用 VBIAS 模板；
- 不生成 Resistive Ladder；
- 对称管自动识别和联动修改暂不纳入本阶段。

### 3.4 Source 串联电阻参数优先级

电阻值按以下顺序确定：

1. 用户明确填写的合法值；
2. Case 已批准的预设值；
3. PDK 有限正电阻范围的几何中点 `sqrt(min * max)`；
4. 最终值必须经过 PDK 步进/枚举量化；
5. 若 PDK 没有可实例化电阻、没有有限正范围或无法量化，则拒绝变换，不猜值。

Source 串联电阻不需要通过小信号仿真来求默认初值。它只是结构变换的确定初始值，后续 Sizing 可以继续优化。

### 3.5 VBIAS 总体原则

- 不复用原电路 VBIAS；
- 不搜索原电路 IREF；
- 不要求用户指定参考电流；
- 每一个 Cascode 操作生成自己的独立 VBIAS CellView；
- VBIAS Cell 内部使用当前 PDK 扫描得到的真实 MOS 和电阻；
- 用户不选择模板内部 Mirror/Replica 器件，也不填写它们的尺寸；
- 工具使用 PDK 规则和 DC 工作点反馈自动确定 Master 与参数；
- 无合法器件或无满足约束的参数解时，明确失败并保留证据，不用经验值硬凑。

### 3.6 异型 Cascode 的含义

异型不是 NMOS 换 PMOS，也不是由固定策略表直接给出一个 Cell 名。正确流程是：

1. 扫描当前 DUT 实际绑定的 PDK；
2. 只保留与原管同极性的 MOS；
3. 检查 OA Master 可实例化、端子角色完整、Bulk/Well 规则完整、电压域允许、可靠性数据完整；
4. 把合法候选按稳定规则展示给用户；
5. 用户只选择 Master；
6. W/L/NF 等参数由工具结合原管工作点、PDK 合法范围和 DC 闭环自动求解。

`compatible_masters` 只能保留为兼容诊断信息，不能成为产品路径选择来源。

---

## 4. 两套自给电 VBIAS 模板的精确定义

### 4.1 NMOS Cascode 的 `VBIAS_N_CASCODE_AUTO`

固定外部端口顺序：

```text
VHIGH, VLOW, VS_ORIG, VG_CTRL, VBIAS_N
```

内部角色和连接：

```text
P_REF        D=PBIAS_REF  G=PBIAS_REF  S=VHIGH
R_REF_N      P=PBIAS_REF  N=VLOW
P_OUT_N      D=VBIAS_N    G=PBIAS_REF  S=VHIGH
N_CAS_REP_N  D=VBIAS_N    G=VBIAS_N    S=X_REP_N
N_CTRL_REP_N D=X_REP_N    G=VG_CTRL     S=VS_ORIG
```

含义：

- `P_REF + R_REF_N` 在模板内部产生参考支路，不使用外部 IREF；
- `P_OUT_N` 给 Replica 支路供流；
- `N_CTRL_REP_N` 模拟原 NMOS；
- `N_CAS_REP_N` 模拟新增 NMOS Cascode；
- `VBIAS_N` 只驱动真实新增 NMOS Cascode 的 Gate；
- `VG_CTRL` 只感知原 MOS Gate 网络，不能改写原 Gate 功能连接；
- `VS_ORIG` 接变换前原 NMOS 的 Source 网络。

### 4.2 PMOS Cascode 的 `VBIAS_P_CASCODE_AUTO`

固定外部端口顺序：

```text
VHIGH, VLOW, VS_ORIG, VG_CTRL, VBIAS_P
```

内部角色和连接：

```text
R_REF_P      P=VHIGH       N=NBIAS_REF
N_REF        D=NBIAS_REF   G=NBIAS_REF  S=VLOW
P_CAS_REP_P  D=VBIAS_P     G=VBIAS_P    S=VS_ORIG
P_CTRL_REP_P D=X_REP_P     G=VG_CTRL     S=VBIAS_P
N_OUT_P      D=X_REP_P     G=NBIAS_REF   S=VLOW
```

含义：

- `R_REF_P + N_REF` 在模板内部产生参考支路；
- `N_OUT_P` 从 PMOS Replica 支路吸流；
- `P_CTRL_REP_P` 模拟原 PMOS；
- `P_CAS_REP_P` 模拟新增 PMOS Cascode；
- `VBIAS_P` 只驱动真实新增 PMOS Cascode Gate；
- `VS_ORIG` 接变换前原 PMOS Source；
- 真实新增 PMOS Cascode 仍放在原管 Source 侧。

### 4.3 模板器件选择要求

模板内部器件不能硬编码 `n18`、`p18`、`rhrpo` 等名称。选择必须基于动态目录：

- 当前 DUT 的 PDK/工艺身份已证明；
- Library 明确属于同一工艺；
- 器件类别和极性正确；
- 端子名和语义角色完整；
- Bulk/Well 连接策略明确；
- `max_abs_vgs`、`max_abs_vds`、`max_abs_vgb` 等可靠性字段完整；
- CDF 可调参数的范围、步进或枚举值可量化；
- OA Master 可实例化。

候选稳定排序：

1. 与 Control MOS 同一 PDK Library；
2. 可靠性余量；
3. 可调参数元数据完整度；
4. Master 名字典序。

Bulk/Well 规则缺失时返回 `BulkPolicyUnresolved`，不得默认把 Bulk 短接 Source。

---

## 5. 目标端到端产品链路

最终 `generate` 必须形成如下闭环：

```text
当前 Case / DUT / Bench
  → inspect / snapshot
  → scan-pdk：扫描并规范化当前 PDK
  → baseline OP：身份完全一致则复用，否则自动 run-op
  → 为每个 Cascode 构造动态模板候选
  → 每个候选物化到唯一临时 CellView
  → 对候选运行 Spectre DC OP
  → 检查可靠性、饱和、电压域、支路电流和参数合法性
  → 按确定性目标函数选最优解
  → 生成功能封装 CellView + 独立 VBIAS CellView
  → OA 物化
  → 回读网表与 CDF 参数校验
  → 名义 DC 状态与 PVT 状态判定
  → 全部发布条件满足后才 publish
```

基线 OP 只能在以下四个身份字段全部非空且完全一致时复用：

```text
dut_hash
bench_hash
pdk_version
corner
```

任何一个不同都必须重新运行 OP。

---

## 6. 当前仓库状态和工作方式

### 6.1 仓库情况

当前 `st-engine-maau` 传输目录没有 `.git` 元数据，因此：

- 不创建 Git commit；
- 不使用 `git reset --hard`、`git checkout --` 等操作；
- 每个 Task 使用源文件快照；
- 使用 `git diff --no-index` 生成只读审查包；
- 正式仓库提交步骤在此传输目录跳过；
- 用户会自行压缩/传输，Agent 不另建压缩包。

### 6.2 快照目录

统一目录：

```text
.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation/
```

Task 1–3 的 base/after/fix 快照和 review diff 已存在。Task 4 已存在：

```text
task-4-base/
task-4-after/
task-4-brief.md
task-4-report.md
task-4-review.diff
```

尚缺：

```text
task-4-fix1-after/
task-4-fix1-review.diff
Task 4 修复后的独立复核结论
progress.md 中 Task 4 正式完成记录
```

### 6.3 源码编辑规则

- 使用 `apply_patch` 修改源文件；
- 不覆盖用户无关修改；
- 测试、实现、构建文件和文档同步维护；
- 每个 Task 独立完成，不提前实现下一 Task；
- 一个失败原因没有证据前，不靠猜测连续改多处；
- 真实服务器命令按单会话、单步骤书写，不把 023–026 拼进一个长命令。

---

## 7. 已完成的工作

### 7.1 Task 1：删除旧 Bias 输入和死代码

状态：**已完成并独立复核为 Clean**。

完成内容：

- 删除 Standalone 操作文件对 `bias.reference_net`、`bias.reference_current`、`bias.voltage`、`bias.output_net`、`bias.element.*` 的要求；
- 删除没有产品调用者的 `solveLadderSections` 和 `solveStackGate`；
- 保留不带手工参考电流契约的中性数据结构 `BiasElementPlan`、`BiasResolution`、`VoltageWindow`；
- 修正依赖旧 Bias 类型的 Transform、ChangeSet、测试和 demo；
- 修复空 VBIAS/reused VBIAS 和无效 Cascode 示例；
- 全量测试通过，修复后只读复核为 `Clean`。

不要恢复旧 Bias 字段，也不要重新引入电阻阶梯 Stack Bias。

### 7.2 Task 2：动态 PDK 目录、量化与异型候选

状态：**已完成并独立复核为 Clean**。

完成内容：

- 建立器件目录和参数约束模型；
- 统一 `ParameterConstraint` 的合法性检查；
- 实现严格量化；
- 异型候选改为按当前目录的同极性规则筛选；
- 生产执行路径不再依赖 `compatible_masters`；
- 缺可靠性数据、端子角色、Bulk 策略或电压域不匹配的器件被保守拒绝；
- 候选排序确定且可复现。

### 7.3 Task 3：动态 PDK 扫描后端

状态：**已完成并独立复核为 Clean**。

完成内容：

- 增加 `scan-pdk` 后端；
- 递归发现 DUT 关联 Technology；
- 证明候选 Library 与 DUT 属于同一工艺；
- 从有效 CDF 提取参数范围/步进/枚举；
- 输出规范化 catalog 与 identity；
- 增加 Maau `TechCatalogProvider` 边界；
- catalog、identity 及两个 `.tmp` 输出采用事务处理；
- 拒绝字符串路径、规范化路径、硬链接、符号链接和 inode 冲突；
- 只删除本次调用自己创建的临时/正式文件。

限制：本机没有 ICADVM18.1 和真实 PDK，因此真实扫描仍需服务器验证。

### 7.4 Task 4：Case/Bench DC OP 接口

状态：**代码与本地测试已通过，但尚未正式关闭**。

已实现：

- `AnalysisIdentity`、`MosOperatingPoint`、`OperatingPointSnapshot`；
- identity/MOS TSV 严格解析、写出和复用判定；
- `ProcessVirtuosoBackend::RunOperatingPoint`；
- `run-op` dispatcher 与 `run_op_runner.sh`；
- 64/69/70/71/74 失败语义；
- Maau `OpSimulationHost`/Provider 边界；
- `st_maau_op_provider` 参数解析入口；
- 四个输出路径的安全事务与回滚；
- 失败时保留仿真目录。

Task 4 初次复核发现六个问题，当前工作树已经修复：

1. 回滚会丢失原有 dangling symlink；
2. 目录、FIFO 或其他非普通输出可能被接受；
3. Provider 输出错误 Corner 仍可能被接受；
4. 部分 backup 清理失败可能同时丢失旧输出和新输出；
5. Shell 数字正则会接受溢出的 `1e9999`；
6. Bench 确实不存在与基础设施/配置启动失败不能准确区分返回码。

修复后的已观察行为：

- dangling symlink 能恢复；
- 目录/FIFO 被拒绝且不会销毁或卡住；
- 新建 symlink/FIFO/目录输出被拒绝；
- identity 中错误 Corner 被拒绝并恢复旧输出；
- commit 清理失败时保留新结果并报告 backup 路径；
- identity/MOS 中溢出浮点数被 shell runner 拒绝；
- Bench 真正缺失返回 64；基础设施/配置/启动失败返回 70；不收敛返回 71；结果缺失/格式错误/陈旧/Corner 不匹配返回 74。

修复后本机已经执行并返回 0：

```bash
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
./build/tests/operatingpointtest
./build/tests/virtuosobackendtest
./build/tests/maaucontracttest
./tests/ServerBackendContractTest.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

全量结果：

```text
test programs passed: 17
demos passed: 2
cli help passed: 1
server backend contract passed: 1
shell syntax checks passed: 14
```

仍未完成的 Task 4 收口：

- `task-4-report.md` 尚未把六项修复、修复后证据和独立复核结论完整固化；
- 尚未创建 `task-4-fix1-after`；
- 尚未创建 `task-4-fix1-review.diff`；
- 尚未安排独立 Reviewer 针对六项问题复核；
- `progress.md` 尚未记录 Task 4 正式完成。

公共 `st_maau_op_provider` 当前故意使用未链接站点私有 API 的 `UnlinkedMaauOpHost`。直接运行时应返回 70 和 `Maau host adapter is not linked`，且不得生成伪造 TSV。真实服务器使用前，必须链接正式站点 Host，或把绝对路径 `ST_OP_PROVIDER_BIN` 指向正式 Provider。这一点不是“已完成真实集成”。

---

## 8. 新会话的第一阶段：正式关闭 Task 4

### 8.1 重新验证当前工作树

在项目根目录执行：

```bash
cd '/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau'
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
./build/tests/operatingpointtest
./build/tests/virtuosobackendtest
./build/tests/maaucontracttest
./tests/ServerBackendContractTest.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：所有命令退出 0，最后仍报告 17 个测试程序、2 个 demo、1 个 CLI help、1 个 server contract 和 14 个 shell 语法检查通过。

如数字变化，先确认是不是后续源码已经新增合法测试；不能机械地把新数字改回 17。

### 8.2 更新 Task 4 报告

编辑：

```text
.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation/task-4-report.md
```

必须新增：

- 六个复核问题的原因；
- 每个修复修改了什么行为；
- 每个修复对应的回归测试；
- 最新专项和全量命令、退出码、汇总；
- 本机没有 CMake、真实 Maau Host、Spectre、ICADVM18.1 的限制；
- “公共入口返回 70”是安全行为，不是服务器集成成功。

### 8.3 创建修复后快照

不要把 `build/` 或 `.superpowers/` 递归复制进快照。执行：

```bash
state_dir='.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation'
mkdir -p "$state_dir/task-4-fix1-after"
rsync -a --delete --exclude build --exclude .superpowers ./ "$state_dir/task-4-fix1-after/"
```

预期：`task-4-fix1-after` 存在，包含当前源文件，不包含 `build` 和 `.superpowers`。

### 8.4 创建修复 Diff

```bash
state_dir='.superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation'
git diff --no-index -- "$state_dir/task-4-after" "$state_dir/task-4-fix1-after" > "$state_dir/task-4-fix1-review.diff"
test "$?" -eq 1
```

`git diff --no-index` 发现差异时返回 1，这是预期，不是失败。随后检查：

```bash
test -s "$state_dir/task-4-fix1-review.diff"
rg -n 'dangling|symlink|fifo|corner|backup|1e9999|Bench|bench' "$state_dir/task-4-fix1-review.diff"
```

预期：Diff 非空，并能看到六项修复相关改动或测试。

### 8.5 独立只读复核要求

Reviewer 只能读取当前源文件、Task 4 计划、初次报告和修复 Diff，不得直接改代码。复核问题固定为：

1. 原 dangling symlink 是否在失败后按原样恢复；
2. 预存/新建目录、FIFO、socket、设备或其他非普通文件是否安全拒绝；
3. identity Corner 是否必须等于请求 Corner；
4. commit/backup 清理部分失败时，是否至少保留一套完整可定位结果；
5. shell 层是否用有限数语义拒绝 `1e9999`、NaN、Inf；
6. Bench absent=64、provider/config/startup=70、nonconvergence=71、bad/missing/stale result=74 是否可证明区分；
7. 是否引入 Task 5/6 越界代码；
8. 是否存在静默伪造 OP TSV 的路径。

Reviewer 输出：

- 有问题时：按严重级别列出文件、行号、触发条件和最小修复建议；
- 无问题时：只返回 `Clean`，并注明已检查六项原问题及范围边界。

### 8.6 Task 4 正式关闭条件

只有同时满足以下条件才能在 `progress.md` 标记 Task 4 complete：

- 六项问题都有代码修复；
- 六项都有自动测试覆盖；
- Task 4 专项测试和全量回归通过；
- `task-4-fix1-after` 与 `task-4-fix1-review.diff` 已保存；
- 独立 Reviewer 返回 `Clean`；
- `task-4-report.md` 和 `progress.md` 已更新；
- 未把本地 Fake/Contract 结果冒充真实 Spectre 成功。

---

## 9. Task 5：实现两套自动 VBIAS 拓扑

### 9.1 文件范围

新增：

```text
include/st/AutoBias.h
src/AutoBias.cpp
tests/AutoBiasTest.cpp
```

修改：

```text
include/st/Bias.h
CMakeLists.txt
scripts/build.sh
scripts/test.sh
```

不要修改 CLI 编排、PVT 或发布流程；那是 Task 8/9。

### 9.2 接口

实现总计划中定义的：

```cpp
struct BiasSizing;
struct AutoBiasTemplateRequest;
struct AutoBiasTemplateResult;

AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest&,
    const BiasSizing&,
    const DeviceCatalog&);
```

`AutoBiasTemplateRequest` 只接收操作身份、极性、电压域、外部网络、Control Master 和 Cascode Master。它不能接收 IREF、手工 VBIAS 或固定模板 Cell 名。

### 9.3 测试先行

先写精确连接测试：

- NMOS 端口及五个内部角色逐端子一致；
- PMOS 端口及五个内部角色逐端子一致；
- 模板内不存在 `IREF`；
- 修改 Fake PDK 的 Library/Cell 名后，仍按角色选择合法器件；
- 源码和结果中没有硬编码 `n18/p18/rhrpo`；
- Bulk 策略缺失时返回 `BulkPolicyUnresolved`；
- 缺真实电阻、可靠性字段、端子角色或可量化参数时拒绝；
- 同一输入结果顺序确定。

预期 RED：新增测试编译失败，指出 `st/AutoBias.h` 或接口不存在。

### 9.4 实施约束

- 使用 Task 2/3 的动态目录；
- 每一个新增值经 `QuantizeParameter`；
- Mirror/Replica 选择只使用目录事实；
- 不通过器件名猜极性/耐压；
- 不默认 Bulk=Source；
- `BiasSizing.element_parameters` 必须按角色保存参数，不能按偶然实例顺序；
- 输出端口顺序固定；
- 内部网络命名稳定，以便 Task 6 轨迹和 Task 7 回读比较。

### 9.5 验证

```bash
./scripts/build.sh
./build/tests/autobiastest
./build/tests/biastest
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：`Auto bias tests passed`、`Bias tests passed`，全量回归全部通过。完成独立复核并更新账本后，才开始 Task 6。

---

## 10. Task 6：实现 PDK 离散参数 DC 闭环求解器

### 10.1 文件范围

新增：

```text
include/st/DcSolver.h
src/DcSolver.cpp
tests/DcSolverTest.cpp
```

修改：

```text
include/st/OperatingPoint.h
include/st/AutoBias.h
CMakeLists.txt
scripts/build.sh
scripts/test.sh
```

### 10.2 求解输入和输出

实现总计划中的：

```cpp
struct DcCandidateMetrics;
struct DcEvaluationRequest;
class DcEvaluationHost;
struct AutoBiasSolveResult;
struct AutoBiasSolveRequest;

AutoBiasSolveResult SolveAutoBias(
    const AutoBiasSolveRequest&,
    const DeviceCatalog&,
    DcEvaluationHost&);
```

### 10.3 初值和搜索空间

- 同型 Cascode：以原管等效尺寸为 mapped initial；
- 异型 Cascode：按有效宽度/电流密度映射初值；
- 电阻：有限正 PDK 范围几何中点；
- 所有初值、邻点和最终值必须量化；
- 粗搜索每参数只使用 `{min, geometric-mid, mapped-initial, max}` 去重集合；
- 粗搜索最多 256 次；
- 局部精搜索最多 128 次；
- 总评估不超过 384 次；
- 每一个候选必须重新 `BuildAutoBiasTemplate`，不能只在搜索结束后构造模板。

### 10.4 硬约束

每个候选至少检查：

- Control、Cascode、Mirror、Replica 的 `|VGS|`；
- `|VDS|`；
- `|VGB|`；
- PDK 电压域；
- 饱和余量；
- VBIAS 输出范围；
- 主支路电流连续性/误差；
- 参数范围、步进和枚举合法性；
- OP 收敛和目标实例完整性。

过压、未饱和、VBIAS 越域、不收敛或结果缺失的候选直接剔除。

### 10.5 排名顺序

满足硬约束的候选按以下顺序比较：

1. 支路电流误差最小；
2. Control 工作点误差最小；
3. 新增 IQ 最小；
4. 可靠性余量最大；
5. 饱和余量最大；
6. 估计面积最小。

排序必须是确定性 tuple 比较，后两个最大化项使用负值参与升序比较。

### 10.6 轨迹

每次评估写一行确定性 JSONL，至少包含：

- candidate id；
- 量化参数；
- Corner；
- 收敛状态；
- 每条硬约束结果；
- 六项目标值；
- 淘汰或入选原因。

相同输入运行两次，`solver_trace.jsonl` 必须字节一致。无解时仍要保留全部轨迹和最后候选证据。

### 10.7 验证

```bash
./scripts/build.sh
./build/tests/dcsolvertest
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：`DC solver tests passed`，Fake Host 调用不超过 384 次；过压、线性区、越域、不收敛和无解测试都通过。

---

## 11. Task 7：接入 Cascode、封装和 OA Plan

### 11.1 文件范围

修改：

```text
include/st/Transform.h
src/Transform.cpp
include/st/Packaging.h
src/Packaging.cpp
include/st/OaPlan.h
src/OaPlan.cpp
src/JsonWriter.cpp
tests/CascodeTransformTest.cpp
tests/PackagingTest.cpp
tests/OaPlanTest.cpp
tests/VariantVerifierTest.cpp
```

### 11.2 功能封装和 VBIAS 封装

每个 Cascode 操作生成两个独立 generated cells：

```text
<variant>__PKG0001
<variant>__VBIAS0001
```

功能封装包含原 MOS 和新增 Cascode；VBIAS 封装包含完整自给电模板。父 Cell 只实例化这两个封装并连接外部端口。

不得把模板内部器件散落在原顶层右侧，也不得出现外部 `IREF` 端口。

### 11.3 串联连接

NMOS：

```text
原管 D = M0_MID
新增管 S = M0_MID
新增管 D = 原 Drain
```

PMOS：

```text
新增管 S = 原 Source
新增管 D = M0_MID
原管 S = M0_MID
```

原管 Gate 网络完全不变。新增管命名 `<原名>_CAS`。

### 11.4 请求接口

`CascodeTransformRequest` 删除旧的 `auto_bias`、手工 bias、手工 OP/VDSAT/窗口字段，改为接收：

```cpp
std::optional<AutoBiasSolveResult> solved_bias;
std::optional<AutoBiasTemplateResult> bias_template;
```

缺少成功求解结果时返回 `BiasUnavailable`，不得在 Transform 内部临时猜 VBIAS。

### 11.5 OA 与回读

- Plan schema 升级到 3；
- VBIAS 内部关键串联使用 `OaDirectWire`；
- 普通外部网络走线不能穿越其他 Pin；
- `JsonWriter` 确定性写两个 generated cells；
- `VariantVerifier` 对每个 VBIAS 子电路实例比较 Master、端子连接和全部求解 CDF 参数；
- 缺参数或数值不同返回 `VariantParameterMismatch`。

### 11.6 验证

```bash
./scripts/build.sh
./build/tests/cascodetransformtest
./build/tests/packagingtest
./build/tests/oaplantest
./build/tests/variantverifiertest
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：四个专项程序和全量回归通过；PMOS Source 侧、双 CellView、无 IREF、CDF 参数回读均有测试锁定。

---

## 12. Task 8：串起 CLI 端到端闭环

### 12.1 文件范围

修改：

```text
src/Cli.cpp
src/Standalone.cpp
include/st/Standalone.h
include/st/Materialization.h
src/Materialization.cpp
tests/CliWorkflowTest.cpp
tests/StandaloneTest.cpp
tests/VirtuosoBackendTest.cpp
README.md
```

### 12.2 Standalone 操作文件

成功路径只需要类似：

```text
id=op1
type=same_type_cascode
instance=M0
voltage_domain=core
nmos_bulk_net=VSS
tie_isolated_pmos_to_source=true
```

不允许再要求 Bias、OP、VBIAS、电流镜比例、Replica 尺寸或手工新增器件参数。

### 12.3 Inspect/Manifest 新输入

`inspect` 增加 Bench 和 Simulator：

```text
--bench-lib LIB
--bench-cell CELL
--bench-view VIEW
--simulator spectre
```

Manifest 保存：源 DUT、Bench L/C/V、Simulator、名义 Corner、PVT Corner 列表、PDK 版本、DUT Hash、Bench Hash。

### 12.4 Generate 固定顺序

```text
加载会话
→ 扫描/加载 PDK 目录
→ 取得或运行 Baseline OP
→ 对每个 Cascode 求解
→ 重放最终 ChangeSet
→ 生成功能封装和独立 VBIAS 封装
→ OA 物化与网表回读
→ 名义 DC 状态判定
→ PVT 复验
→ 满足条件才发布
```

单点 Fake PDK 的精确后端顺序：

```text
scan-pdk, run-op, clone, materialize, run-op,
netlist, netlist, netlist, netlist, publish
```

多候选时，每个候选都必须 clone/materialize/run-op；不要让 CLI 集成测试硬编码多候选次数，次数上限由 `dcsolvertest` 验证。

### 12.5 分析产物

成功或失败时按阶段保留：

```text
analysis/pdk_catalog.json
analysis/baseline_op.json
analysis/cross_flavor_candidates.json
analysis/solver_trace.jsonl
analysis/resolved_parameters.json
reports/validation.txt
```

任一步失败都停止发布，但保留此前证据。

### 12.6 状态定义

```cpp
bool structural_ready;
bool nominal_dc_ready;
bool pvt_ready;
bool parameters_quantized;
```

只有：

```text
structural_ready && nominal_dc_ready && parameters_quantized
```

才允许 `ready_for_sizing=true`。

`pvt_ready` 单独报告。未配置 PVT 不等于名义失败。`ready_for_sizing=true` 也不代表 AC、TRAN、PSRR、噪声或全 PVT 已签核。

### 12.7 验证

```bash
./scripts/build.sh
./build/tests/cliworkflowtest
./build/tests/virtuosobackendtest
./build/tests/standalonetest
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：专项测试通过，成功输出包含：

```text
structural_ready=true
nominal_dc_ready=true
parameters_quantized=true
ready_for_sizing=true
```

---

## 13. Task 9：PVT、无解证据和多操作隔离

### 13.1 文件范围

修改：

```text
src/DcSolver.cpp
src/Cli.cpp
src/Packaging.cpp
tests/DcSolverTest.cpp
tests/CliWorkflowTest.cpp
tests/PackagingTest.cpp
```

### 13.2 PVT 规则

- 先在名义 Corner 求出一组最优参数；
- PVT 只固定参数逐 Corner 复验；
- 不允许不同 Corner 各选一套尺寸；
- nominal 通过而 ss 过压时：`nominal_dc_ready=true`、`pvt_ready=false`；
- 报告必须指出 `corner=ss` 和具体约束，例如 `max_abs_vgs`。

### 13.3 多操作隔离

两个 Cascode 操作生成：

```text
PKG0001, VBIAS0001, PKG0002, VBIAS0002
```

每套内部网络、输出网络、参数 Map、CellView 名和放置区域互不共享。

### 13.4 无解行为

若最多 384 个候选全部不收敛或违反约束：

- 不 publish；
- `ready_for_sizing=false`；
- `solver_trace.jsonl` 非空；
- `resolved_parameters.json` 写 `status=no_solution`；
- 保留最后候选及逐项失败原因。

### 13.5 验证

```bash
./scripts/build.sh
./build/tests/dcsolvertest
./build/tests/packagingtest
./build/tests/cliworkflowtest
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

预期：专项与全量测试通过，PVT 失败、多 VBIAS 隔离、384 候选无解均有自动测试。

---

## 14. Task 10：文档和真实服务器验收

### 14.1 文件范围

新增：

```text
docs/automatic-pdk-vbias-server-validation.md
```

修改：

```text
docs/023-026结构变换独立测试命令.md
integration/maau/SERVER_VALIDATION.md
README.md
```

### 14.2 023–026 会话覆盖

使用四个独立会话，不合并命令：

- 023：NMOS 同型 Cascode；
- 024：PMOS 同型 Cascode；
- 025：NMOS 异型 Cascode；
- 026：PMOS 异型 Cascode。

四个会话分别选择 CAP、Capless、FVF、RES Case，使四类架构至少各完成一次真实 PDK 扫描与名义 DC 闭环。如果当前 Case 没有对应极性的可修改 MOS，就从 Registry 选同架构另一个真实 Case，不伪造实例名。

每个会话分别列出：

```text
inspect
确认候选和目标实例
confirm
generate
查看 validation.txt
查看 resolved_parameters.json
查看 solver_trace.jsonl
grep 回读网表
打开功能封装 CellView
打开独立 VBIAS CellView
```

### 14.3 失败场景

文档必须单独覆盖：

- 无合法 PDK 候选；
- Bench 缺失；
- Provider/仿真启动失败；
- Spectre 不收敛；
- 可靠性超限；
- CDF 参数回读不一致；
- 两个 Cascode 的多 VBIAS 隔离；
- PVT 某 Corner 失败但名义通过。

### 14.4 本地最终回归

预期最终新增 `autobiastest` 和 `dcsolvertest` 后：

```bash
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

计划目标汇总：

```text
test programs passed: 19
demos passed: 2
cli help passed: 1
server backend contract passed: 1
```

若实际测试列表合法增加，汇总数字可以高于 19，但脚本列表和输出必须一致。

静态检查：

```bash
rg -n 'reference_current|reference_net|solveLadderSections|compatible_masters' include src tests examples
```

预期：只允许旧字段拒绝测试或兼容诊断匹配；生产求解路径不能依赖这些旧链路。

### 14.5 真实服务器成功标准

每个真实成功会话必须同时出现：

```text
structural_ready=true
nominal_dc_ready=true
parameters_quantized=true
ready_for_sizing=true
```

并人工核对：

- NMOS Cascode 位于 Drain 侧；
- PMOS Cascode 位于 Source 侧；
- 原 Gate 功能网络未改变；
- `VG_CTRL`、`VS_ORIG` 连接正确；
- 每个操作有独立 VBIAS CellView；
- 没有 IREF 端口；
- 模板内部是当前真实 PDK 器件；
- CDF 参数与 `resolved_parameters.json` 一致；
- 回读网表端子顺序与 expected 一致；
- 原始源 CellView 未被修改。

---

## 15. CMake、Maau 私有 Host 和真实服务器的未验证边界

### 15.1 CMake

本文创建时本机 `command -v cmake` 没有结果，因此当前仅验证了 `scripts/build.sh` 路径。到有 CMake 的环境后补跑：

```bash
cmake -S . -B build-cmake -DST_BUILD_MAAU_COMPAT=ON
cmake --build build-cmake --parallel
ctest --test-dir build-cmake --output-on-failure
```

预期：配置、构建和 CTest 全部退出 0，目标输出路径与手写构建一致。

### 15.2 Maau 私有 Host

当前公共仓库只定义接口，不包含站点私有 Maau API 实现。真实环境必须：

1. 提供 `OpSimulationHost` 的站点实现；
2. 正确完成临时 Case、DUT 重绑定、Bench/Corner 继承、Spectre 运行和 OP 提取；
3. 构建一个真实 Provider；
4. 用绝对可执行路径设置 `ST_OP_PROVIDER_BIN`；
5. 保证错误码和标准 TSV 契约不变。

如果站点集成缺失，`run-op` 返回 70 是正确行为。

### 15.3 真实 ICADVM18.1/PDK

Mac 本地通过的内容仅包括纯 C++、Shell 合约和 Fake Host 测试。以下只能在服务器确认：

- PDK libInit/CDF 可加载；
- 动态扫描得到真实器件；
- OA Master 可实例化；
- Spectre DC OP 收敛；
- VBIAS 模板真实工作；
- CDF 参数回读一致；
- Virtuoso 原理图连接和封装显示正确。

任何成功结论必须附：命令、退出码、日志路径和原始产物路径。

---

## 16. 每个 Task 的实施与复核模板

用户已经授权“分任务实施和复核”。新会话应按以下固定流程：

1. 从当前工作树创建该 Task 的 base 快照；
2. 写 Task brief，列清文件范围、禁止越界项、验收测试；
3. 先新增失败测试，记录 RED 证据；
4. 实现最小功能使专项测试通过；
5. 跑全量回归；
6. 创建 after 快照和 `git diff --no-index` review 包；
7. 交给未参与实现的只读 Reviewer；
8. Reviewer 有发现时，按最小修复循环处理，最多保留清晰的 fix1/fix2…证据；
9. Reviewer 返回 `Clean` 后更新 Task report 和 `progress.md`；
10. 只有当前 Task 正式关闭后才开始下一 Task。

Reviewer 不得只看测试绿灯，应检查规格语义、安全边界和是否提前实现后续任务。

---

## 17. 禁止的捷径

后续 Agent 不得：

- 重新要求用户输入 VBIAS、IREF、Mirror ratio 或 Replica 尺寸；
- 从原电路寻找可复用 VBIAS/IREF；
- 通过器件名字猜 PDK 类型、极性或耐压；
- 用固定 `n18/p18/rhrpo` Cell 名；
- 把 `compatible_masters` 当作正常产品候选来源；
- 在缺少 Bulk/Well 或可靠性数据时默认放行；
- 在 OP 不收敛时伪造 TSV；
- 在名义 DC 未通过时输出 `ready_for_sizing=true`；
- 把 PMOS Cascode 放到 Drain 侧；
- 改变原 MOS Gate 功能连接；
- 给 Stack MOS 重新引入电阻阶梯 Gate Bias；
- 把多个生成 VBIAS 共用内部网或参数 Map；
- 直接修改原始源 CellView；
- 仅凭本地 Fake 测试宣称真实 Virtuoso/Spectre 已通过；
- 把 023–026 多个会话写成一个难以定位错误的命令；
- 在此传输目录执行危险 Git 恢复操作；
- 未经用户要求创建压缩包。

---

## 18. 最终验收矩阵

| 验收项 | 自动测试 | 服务器/人工检查 | 完成阶段 |
|---|---|---|---|
| 旧 Bias/IREF 输入被拒绝 | Standalone/CLI | 操作文件无旧字段 | Task 1/8 |
| 当前 PDK 动态扫描 | PDK catalog/contract | 真实 catalog 与 DUT 工艺一致 | Task 2/3/10 |
| 异型只同极性 | PDK candidate test | UI 候选全为同极性 | Task 2/10 |
| 参数均可量化 | PDK/solver test | resolved 与 CDF 一致 | Task 2/6/10 |
| OP 身份安全复用 | operatingpointtest | identity 四字段匹配 | Task 4/10 |
| OP 输出事务安全 | backend/server contract | 失败不破坏旧结果 | Task 4 |
| NMOS VBIAS 拓扑正确 | autobiastest | 打开 VBIAS_N CellView | Task 5/10 |
| PMOS VBIAS 拓扑正确 | autobiastest | 打开 VBIAS_P CellView | Task 5/10 |
| 无 IREF 端口 | AutoBias/Packaging | CellView 端口检查 | Task 5/7/10 |
| DC 搜索确定且有界 | dcsolvertest | solver trace 可复现 | Task 6/10 |
| PMOS 位于 Source 侧 | Cascode test | Virtuoso 人工查看 | Task 7/10 |
| 功能包与 VBIAS 包独立 | Packaging/OA tests | 两个独立 CellView | Task 7/10 |
| 回读 Master/端子/CDF 一致 | VariantVerifier | round-trip 网表 | Task 7/10 |
| generate 闭环顺序正确 | cliworkflowtest | 日志阶段顺序 | Task 8/10 |
| readiness 状态严格 | CLI tests | validation.txt | Task 8/10 |
| PVT 固定参数复验 | solver/CLI tests | Corner 报告 | Task 9/10 |
| 多操作互不冲突 | Packaging/CLI tests | 两套包人工查看 | Task 9/10 |
| 无解保留证据且不发布 | solver/CLI tests | trace/JSON/无目标发布 | Task 9/10 |
| CAP/Capless/FVF/RES 覆盖 | 本地仅契约 | 023–026 真实会话 | Task 10 |

---

## 19. 新会话启动检查表

新 Agent 开始时逐项确认：

- [ ] 当前目录是 `st-engine-maau`；
- [ ] 已读本文；
- [ ] 已读批准规格；
- [ ] 已读总实施计划；
- [ ] 已读 `progress.md`；
- [ ] 已确认 Task 1–3 完成；
- [ ] 已确认 Task 4 代码绿但复核未收口；
- [ ] 未开始 Task 5；
- [ ] 已重新运行 Task 4 专项和全量测试；
- [ ] 已更新 Task 4 报告；
- [ ] 已创建 Task 4 fix1 快照和 Diff；
- [ ] 已得到独立 Reviewer 的 `Clean`；
- [ ] 已在账本关闭 Task 4；
- [ ] 才开始 Task 5 的 RED 测试。

---

## 20. 给新 Agent 的可直接使用提示词

```text
请在 /Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau 继续“自动 PDK VBIAS 求解器”工作。

先完整阅读：
1. docs/superpowers/plans/2026-09-24-automatic-pdk-vbias-solver-continuation-handoff.md
2. docs/superpowers/specs/2026-09-22-automatic-pdk-vbias-solver-design.md
3. docs/superpowers/plans/2026-09-22-automatic-pdk-vbias-solver-implementation.md
4. .superpowers/sdd/2026-09-22-automatic-pdk-vbias-solver-implementation/progress.md

不要立即写 Task 5。先按交接文档第 8 节关闭 Task 4：重新验证、更新报告、创建 task-4-fix1-after 和 task-4-fix1-review.diff、安排独立只读复核，只有复核 Clean 后才更新账本并开始 Task 5。

后续严格按 Task 5→10 顺序，使用测试先行、任务快照、独立复核和修复循环。不得复用原电路 VBIAS/IREF，不得硬编码 PDK Cell，不得恢复 compatible_masters 产品依赖，不得把本地 Fake 测试冒充真实 Virtuoso/Spectre 成功。
```

---

## 21. 本文创建时的准确结论

- 已完成并正式关闭：Task 1、Task 2、Task 3；
- 代码修复和本地回归通过但未正式关闭：Task 4；
- 尚未实施：Task 5、Task 6、Task 7、Task 8、Task 9、Task 10；
- 当前本地可靠证据：17 个测试程序、2 个 demo、CLI help、server contract、14 个 shell 语法检查通过；
- 当前没有可靠证据：真实 Maau 私有 Host、真实 Spectre OP、真实 ICADVM18.1/PDK 扫描、真实 023–026 端到端成功；
- 下一动作唯一正确入口：先完成 Task 4 的修复后独立复核与账本收口。
