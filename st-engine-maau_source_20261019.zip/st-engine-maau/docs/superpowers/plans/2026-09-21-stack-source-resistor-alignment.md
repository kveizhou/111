# Stack 命名与 Source 串联电阻语义对齐实施计划

> 工作区不是 Git checkout，因此本计划不伪造 commit；每个任务以可重复测试作为检查点。

**目标：** 将已评审的结构变换语义落到方案与工具：Stack 保留 Drain 侧原实例名，电阻变换改为在 MOS Source 串联一只电阻，Cascode 同型/异型统一为同极性规则。

**边界：** 不实现对称管自动识别；不重新设计 VBIAS 模板；不改原 MOS Gate；不生成压缩包。

**工程原则：** 先改测试并确认旧实现失败，再改最小生产代码；新增器件参数继续由 `DeviceCatalog`/PDK 范围约束。

---

## 任务 1：局部修订两份方案

**文件：**

- 修改：`../LDO_MOS四种结构变换设计方案.md`
- 修改：`../LDO四种架构Cascode_VBIAS设计方案.md`

1. 将电阻语义改为保留 MOS，在原 Source 路径串联一只 PDK 电阻。
2. 电阻初值优先级固定为：用户值 → Case 预置 → PDK 合法阻值区间中间值；连续正区间使用几何中点并量化到 PDK 网格。
3. Stack 从 Drain 到 Source 命名为 `M0`, `M0_S1`, …, `M0_S(N-1)`，原实例名保留给 Drain 侧级。
4. 同型 Cascode = 同极性同 master；异型 Cascode = 同极性不同 PDK Flavor/master，由兼容矩阵约束，不得将 NMOS/PMOS 互换。
5. NMOS Cascode 放在原管 Drain 侧；PMOS Cascode 按原理图“向上加管”的结构放在原管 Source 侧。
6. 写明对称管识别未纳入本轮。

## 任务 2：先固定失败的回归用例

**文件：**

- 修改：`tests/ResistorTransformTest.cpp`
- 修改：`tests/StackTransformTest.cpp`
- 修改：`tests/StandaloneTest.cpp`
- 修改：`tests/PackagingTest.cpp`
- 修改：`tests/ChangeSetTest.cpp`

1. 增加“MOS 保留且 D/G/B 不变，Source 改接内部节点”测试。
2. 增加“电阻串在内部节点和原 Source 之间”测试。
3. 增加“用户值、Case 值、PDK 几何中点”三级优先级测试。
4. 增加 Stack `M0/M0_S1/...` 的 Drain→Source 连接和冲突避让测试。
5. 更新封装/OA 计划预期，确保 Source 串联节点生成实体直连线。
6. 增加 PMOS Cascode 位于原 Source 侧、原 Gate 不变的回归测试。
7. 运行定向测试，确认旧实现按预期失败。

## 任务 3：实现 Source 串联电阻

**文件：**

- 修改：`include/st/ChangeSet.h`
- 修改：`include/st/Transform.h`
- 修改：`src/ChangeSet.cpp`
- 修改：`src/Standalone.cpp`
- 修改：`src/Transform.cpp`

1. 将内部操作类型从“Replace”改为“AddSourceResistor”，CLI 仍接受 `type=resistor`。
2. 移除 DC/小信号等效种子和关键 Gate 拒绝逻辑。
3. 交集 PDK 和模板阻值范围，按优先级决定种子，再量化并校验。
4. 修改原 MOS Source，新建内部节点和串联电阻；保留原 MOS 实例、master、D/G/B 和参数。

## 任务 3A：对齐 PMOS Cascode 的 Source 侧放置

**文件：**

- 修改：`src/Transform.cpp`
- 修改：`tests/CascodeTransformTest.cpp`

1. NMOS 保持在原 Drain 侧增加 Cascode。
2. PMOS 在原 Source 侧增加 Cascode，原 PMOS 的 Drain/Gate/Bulk 保持不变。
3. 两种极性均只把新增 Cascode Gate 连到 VBIAS。

## 任务 4：实现 Stack 原实例身份保留

**文件：**

- 修改：`include/st/Transform.h`
- 修改：`src/Transform.cpp`
- 修改：`src/Standalone.cpp`

1. 逻辑级按 Drain→Source 排序。
2. 第 0 级名称为原实例，其余级为 `_S1` 至 `_S(N-1)`。
3. 物化时就地修改原 MOS，只新增 N-1 只 MOS，不删除后重建原实例。
4. 所有级 Gate 继续共用原 Gate；保留 PDK bulk 约束和参数范围检查。

## 任务 5：对齐封装、示例和用户说明

**文件：**

- 修改：`src/Packaging.cpp`
- 修改：`examples/operations/replace_with_resistor.conf`
- 修改：`examples/DemoChangeSet.cpp`
- 修改：`README.md`

1. 封装的内部串联节点同时识别 MOS D/S 和电阻 P/N 端子。
2. 示例改为可选 `resistor.value`、可选 `resistor.case_default`，删除等效模式和 `critical_dynamic_gate`。
3. README 统一四类变换名称、初值优先级和 Stack 命名。

## 任务 6：验证

1. 运行 `./scripts/build.sh`。
2. 运行 `./scripts/test.sh`。
3. 检查方案和代码中不再出现旧的“整管替换电阻”、`M0_S1...M0_SN` 全改名以及默认 `1k` 语义。
4. 对实机 Virtuoso 的最终验收仍以服务器端 `ready_for_sizing=true` 和回读网表为准，本地测试不伪称已完成 PDK 实机验收。
