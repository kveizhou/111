# Packaged topology cells implementation plan

**Goal:** Materialize every confirmed MOS topology transform as a generated child cell with both `schematic` and `symbol` views. The selected core cell contains only one wrapper instance per independent transformed region.

**Architecture:** Keep the electrical transform engine flat and PDK-aware. After replay, a packaging pass groups every operation's changed instances, moves those instances into a generated subckt, and replaces the region in the core with one wrapper instance. The OA plan carries nested generated-cell plans. SKILL creates each child schematic and symbol before placing the wrapper in the staged core. Round-trip verification compares the generated hierarchical netlist against the same hierarchical expected netlist.

**Product rules included in this change:**

- Cascode keeps the original MOS gate unchanged and drives only the added MOS gate from a resolved VBIAS.
- Stack supports shared gate only; every stage gate uses the original gate net.
- Resistor value is user supplied; if omitted the deterministic default is `1k`. It is always clipped/validated against the PDK resistor limits and grid.
- All device masters, terminal orders, CDF parameters, dimensions, resistor values, voltage domains, bulk connections, and stack limits remain subject to the device catalog and existing transform validation.
- VBIAS reuse remains first choice. A generated resistive divider is accepted only as a resolved, approved PDK template and is placed inside the same generated child cell.

## Tasks

1. Add tests for product-policy parsing and deterministic resistor defaults.
2. Add packaging-model tests for all four transform types and for merging repeated changes in the same transformed region.
3. Add OA-plan/JSON tests proving that generated cells contain schematic instances, ports, direct wires, symbol metadata, and one parent wrapper.
4. Implement the packaging pass and packaged OA-plan builder.
5. Extend the materializer JSON and SKILL code to create/check/save generated schematics and symbols before the parent wrapper.
6. Update the CLI `generate` flow to emit hierarchical expected netlists and use packaged plans.
7. Update examples and README.
8. Run the complete build/test suite and static server contract checks.
9. Regenerate and compare the root netlist plus every generated child CellView
   before publish; retain each child round-trip netlist as a separate artifact.
