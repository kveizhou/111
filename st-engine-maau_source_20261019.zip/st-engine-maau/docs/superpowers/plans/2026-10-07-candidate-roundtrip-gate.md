# 自动 VBIAS 候选 OA 回读门禁

**目标：** 每个候选的 OA 父图及两个封装子 Cell 必须与封装后的期望网表一致，才允许调用直流仿真。

**设计：** 在每个 `analysis/candidates/candidate_NNN/` 中保存封装期望网表、父图及子 Cell 回读网表、校验报告。新增指定输出路径的后端回读入口，沿用当前会话扫描出的器件策略，不占用最终回读文件及调用序号。复用现有逐端连接、master、端口及参数比较器；任一差异都作为候选拒绝原因留档。

**执行方式：** 在当前目录内执行，不创建 Git 仓库或新工作树。采用 test-driven-development 与 executing-plans；现场 OA/PDK 验证仍需服务器入口。

- [x] 在 CLI 工作流测试中要求每候选先回读三个 Cell，再调用 run-op；注入父图连接漂移、子 Cell 参数漂移和缺子 Cell，要求无候选 run-op、无发布且保存具体原因。
- [x] 运行聚焦测试，确认因缺少候选回读门禁而失败。
- [x] 实现指定路径回读入口和候选校验，保留独立候选产物，并修正宿主契约中旧电阻说明。
- [x] 聚焦测试通过后构建并运行完整本地验证，更新交接文档的真实状态。

**边界：** 本地测试使用 Fake 后端，证明拒绝和编排行为；不能证明真实 Cadence 导出及 Maau/Spectre 仿真成功。真实站点适配器、Case 自动映射和整机 IQ 口径仍单独待完成。

**执行记录：** 初始新增的 6 项门禁断言在旧代码失败；补齐基本校验后聚焦测试通过。复查又发现重复 generate 覆盖旧候选、以及只拷贝指定子电路会丢弃回读中的计划外内容；已分别增加失败用例。

新增的证据保留及子 Cell 额外内容测试在修复前失败，修复后 `CliWorkflowTest` 全部通过（退出 0）。完整 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 和 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0：20 个测试程序、2 个 demo、CLI help、server backend contract、14 项 shell 语法检查通过。日志保存在 `docs/validation/2026-10-07/build.log` 与 `tests.log`。

复核本机后，`/tmpdata/maau_epc/users/k00981589/st-engine-maau` 未挂载，`~/.ssh/config` 不存在，未取得服务器主机或完整现场 API。真实 Site Adapter/Host 的实现、导入 Case 自动映射、整机 IQ 口径及真实 Capless 验收仍未完成；不得把本计划的本地完成解读成总需求完成。

**Ruling:** 候选目录使用原子目录预留分配递增编号，既有目录和 OA 名称不再复用；子 Cell 独立进行完整网表比较 — 保证旧证据可追溯，并拒绝回读中的额外层级或指令 — 代价是候选库和目录会增长，现场清理须另行执行。
