# LDO 结构变换简化规则与本地闭环实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking. This transfer directory has no Git repository; preserve the baseline archive and do not initialize Git.

**Goal:** 使当前层 MOS 的异型 Cascode 按同极性、不同真实 PDK master 筛选，并使通用 VBIAS 求解与权威 PDK 目录和 Case 电气门禁一致。

**Architecture:** 保留现有四类变换和一套 N/P 互补 Mirror + Replica VBIAS 连接。PDK Site Adapter 扫描真实 master 与 CDF；同一份扫描目录贯穿 inspect、confirm、generate 和候选求解。真实 Capless 首轮只验证可用的目标器件，不把 CAP/FVF/RES 的占位测试算作通过。

**Tech Stack:** C++17、Cadence SKILL/OA、Maau/Spectre、shell。

**Spec:** `../../../../LDO结构变换与自动VBIAS_统一需求设计与开发交接.md`。

## Global Constraints

- 只处理核心 Cell 当前层 MOS；所有 MOS 可选择，失败给具体原因。
- 异型 Cascode = 同极性、不同真实 PDK master；family/flavor 不作准入门槛。
- 电阻变换保留 MOS，只在电气 Source 串联真实 PDK 电阻。
- VBIAS 固定一套通用 N/P 互补模板；内部器件自动取自当前 PDK。
- 不覆盖源 L/C/V；服务器成功必须有命令、退出码、日志和原始产物。
- 本地目录没有 `.git`。基线归档为 `/tmp/ldo-structure-baseline-2026-09-30.tar.gz`，SHA-256 为 `d66e55123529151bcba0017e3bfda498e19e986df287f5f82b14e3bcc9435d24`。

## 文件责任

| 文件 | 本轮职责 |
|---|---|
| `src/PdkCatalog.cpp`, `tests/PdkCatalogTest.cpp` | 同极性不同 master 候选及拒绝原因 |
| `tests/StandaloneTest.cpp`, `tests/CascodeTransformTest.cpp` | 清单和用户选择的真实业务回归 |
| `src/Cli.cpp`, `tests/CliWorkflowTest.cpp` | PDK 目录重扫、会话身份和后续唯一数据源 |
| `include/st/DcSolver.h`, `src/DcSolver.cpp`, `tests/DcSolverTest.cpp` | Case 主支路电流偏差和 VBIAS 支路电流硬门禁 |
| `server/skill/scan_pdk.il`, `server/skill/tech_adapter.il` | 真实站点元数据边界；已证明 MOS 先入可选清单，操作门禁另判 |
| `docs/automatic-pdk-vbias-server-validation.md` | 真实 Capless 验收证据和未运行状态 |

## Task 1：同极性不同 master 候选

**Interfaces:** `SelectCrossFlavorCandidates(original, catalog, voltage_domain)` 保持当前函数名以兼容调用方；accepted 只含满足硬条件的不同 master，rejected 保留具体原因。

- [x] 在 `tests/PdkCatalogTest.cpp` 增加同极性、不同 master、family/flavor 空或相同仍被接受的断言，并增加不同极性与非 MOS 不带 MOS 特有原因的断言。
- [x] 单独编译并运行 `PdkCatalogTest`，新断言按旧规则失败 2 项。
- [x] 修改 `src/PdkCatalog.cpp`：同 master 跳过、不同极性直接拒绝，移除 family/flavor 门槛，保留 OA、端子、可靠性、Bulk、电压域与量化几何校验。
- [x] 更新 `tests/StandaloneTest.cpp` 的业务 JSON 期望；两个聚焦测试通过。

## Task 2：扫描目录贯穿会话

**Interfaces:** `SessionManifest` 增加 `catalog_hash`；inspect 用 `ScanPdk` 结果保存权威目录，generate 重扫后比较版本与内容 hash，并将扫描目录传给候选求解、模板、重放、封装及 OA plan。

- [x] 在 `tests/CliWorkflowTest.cpp` 增加两个失败用例：同版本不同目录内容拒绝生成；snapshot 与扫描目录不同则以扫描目录为准。
- [x] 聚焦测试在旧实现下失败 2 项。
- [x] 修改 `src/Cli.cpp` 的 inspect、manifest、generate；成功解析后对保留全部字段的 TSV 排序记录行并计算稳定 hash，漂移要求重新 inspect/confirm。
- [x] 聚焦测试通过；最终 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 与 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0。

## Task 3：Case 电气门禁保持简单

**Interfaces:** Case 提供正的主支路相对电流偏差上限和新增 VBIAS 两支路电流上限；缺任一上限时 `inspect` 可查看候选，Cascode 的 `generate` 在求解前拒绝。`total_supply_current` 含负载电流，不能当作完整 IQ。已有六只 MOS OP 身份和 PDK 电压应力检查保留。

- [x] 在 `tests/DcSolverTest.cpp` 写 RED 用例：支路电流偏差超限、VBIAS 支路电流超限、Case 限值缺失；旧实现失败 3 项。
- [x] 在 `include/st/DcSolver.h`、`src/DcSolver.cpp` 增加两项硬门禁；保留旧 `iq_delta` 字段作兼容，但其物理含义仅为 VBIAS 两支路电流之和。
- [x] 将 Case 限值从 `src/Cli.cpp` 会话入口传入求解和最终 staging 复验。缺限值时给清晰错误，不猜数值。
- [x] 聚焦测试通过，新增最终 staging 偏置电流超限不 publish 的 CLI 回归；最终全量脚本退出 0。

## Task 4：真实 Capless 取证

当前新增发现：MOS 清单不得因可靠性/Bulk/CDF 信息不完整而静默漏掉已证明的 MOS。用户进一步确认三端 D/G/S MOS 也在“全部 MOS”范围内；扫描器及当前层清单现按真实 PDK 归属、极性和 D/G/S 收录三端 MOS，四端及以上仍须证明 Bulk。Source 电阻路径保留三端原管并只改 Source；Cascode/Stack/VBIAS 的 Bulk 条件仍独立生效。真实电阻额定电压/功耗门禁与 Site Adapter 待实证，不能视为已收口。

2026-10-06 三端变更按测试先行完成：`StandaloneTest` 的目录/当前层清单用例、`ResistorTransformTest` 的三端 Source 连接用例和 `PdkCatalogTest` 的 Cascode 候选拒绝用例均先失败再通过；四端缺 Bulk 仍拒绝。随后 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 与 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0（19 个测试程序、2 个 demo、CLI help、server backend contract、14 个 shell 语法检查）。真实 Virtuoso 三端 master 扫描与 OA 回读仍为 `planned_not_run`。

导入多电路的本地接口已修正：`inspect` 先扫描，再由扫描目录生成会话器件策略，供 snapshot 与所有回读使用；旧固定 `device_policy.tsv` 只作直接后端测试默认值。`inspect` 可不带 Bench/轨网建立只读发现会话，缺 Bench 的 generate 在扫描/仿真前拒绝；Case 数据齐全后新建会话。下一步现场须用既有 Maau `PdkCollector`、`GetTechs`、`CircuitTestBenchConfig` 的实际配置来源实现 Site Adapter/Host，并验证两个不同 PDK 的导入 Case。当前 CLI 尚不能自动读出 Case 的 Bench/轨网，不能宣称自动 Case 发现已完成。

本轮动态策略测试先在旧实现下出现 2 项失败（扫描顺序与回读器件策略）；无 Bench 只读发现测试又出现 3 项失败，修正后 CLI Workflow 聚焦通过。完整回归见最终验证记录。

- [ ] 读取 `docs/023-026结构变换独立测试命令.md` 中已登记的源 L/C/V 与 `cds.lib`；核实服务器可访问性。文档里的 Bench 和 VBIAS 轨网仍是占位，必须从真实 Case/Bench 取得。
- [ ] 在真实服务器先运行只读 `scan-pdk` 与 `inspect`，保存命令、退出码、日志、原始 catalog、当前层 MOS 清单、Bench/轨网身份；失败即停。
- [ ] 从真实 OP 选择一只适合的 NMOS 或 PMOS 标量管，运行一次独立 OA 候选 + VBIAS + Spectre DC/OP；保存所选 master、参数、网表、OP、拒绝原因和 source hash。
- [ ] 只有实际运行且回读、Case 门禁通过，才把对应项目从 `planned_not_run` 改为 `verified_server`。本机不能访问服务器时保留未运行状态，并写明最小输入/访问缺口。

## 计划自检

- [x] 文档中无新的架构专属 VBIAS 模板、无 family/flavor 必填要求。
- [x] 本轮核心新行为先 RED 后 GREEN；最终 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 和 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0（19 个测试程序、2 个 demo、CLI help、server backend contract、14 个 shell 语法检查）。
- [x] 真实验收与 Fake Host 本地测试分开报告；真实服务器仍为 `planned_not_run`。
