unzip -o ../LDO_Cascode_BundleResume_20261013.zip -d ..
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "基线封存退出码=$status"
