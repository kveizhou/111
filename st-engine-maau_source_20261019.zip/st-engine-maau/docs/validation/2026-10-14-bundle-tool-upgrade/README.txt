R-058 / P-059 / C-062 — local verification only

Observed server failure (user log): candidate_003, baseline dependency changed or missing: server/skill/pdk_adapter.il, backend exit 70. No candidate Spectre result.

before.log: historical multi-tool hashes fail at production load_bundle (op_provider.py is the first differing fixture entry).
bundle-tests.log: 39 passed, including new upgrade tests.
experiment-tests.log: 62 passed, including repeated resume and pre-native model drift refusal.
provider-tests.log: 6 passed.
runtime-tests.log: 15 passed.
focused.log: 2 upgrade tests passed again after strengthening negative assertions.
Total distinct tests across the four suites: 122. No native Cadence execution. Native calls are substituted only at the EDA boundary; production provider/runtime/loaders remain active.

Python AST, release current hashes, ZIP CRC/source bytes passed. Legacy runtime unchanged. No C++ modifications/rebuild.

Server: upload ldo_bundle_upgrade_fix_20261014.zip to the parent of st-engine-maau; retain the current st_batch variable.
unzip -o ldo_bundle_upgrade_fix_20261014.zip && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs
echo "续跑退出码=$status"

Expected before native generation: BASELINE_BUNDLE_PREFLIGHT=PASS; BASELINE_HISTORY_UNCHANGED=true; BASELINE_TOOL_UPGRADE includes the known adapter. Followed by existing reuse flags and generate. Final experimental DC success is not guaranteed by this code-only patch. If a new failure occurs, preserve full logs and return STAGE_LOG/DETAIL/RESULT and exit status. Do not modify original manifests or weaken electrical checks.
