R-059/P-060/C-063. Production fix pending real candidate differences.
Server evidence: candidate_004, actual OA ports pass, physical OA master binding missing R1_2_res_gen, backend 76. Candidate Spectre not reached.
before.log: four expected failures because the new standalone script was absent.
after.log: four tests passed, including five failure modes in subtests.
sample.log: synthetic private-node renaming example through the production binder; NOT server evidence.
No production source, release manifest or native execution changed. Script writes only a fresh diagnostic report directory.

Server command after uploading standalone file beside st-engine-maau:
python3 inspect_cascode_candidate_bindings.py --engine st-engine-maau --candidate "$st_batch/candidate_I21_xbb892w0"

Expected: RESULT=CANDIDATE_BINDING_EVIDENCE_READ_OK, SIMULATION_DIR identifies candidate_004, BINDING_REPLAY=FAIL (the existing failure), GROUP and SEGMENT_DIFF show specific differences. Exit zero means evidence collected, never electrical success. Return those summary lines; all raw differences remain in DETAILS_FILE.
