# 原生 CDF 有限候选与隔离实验（2026-10-14）

## 当前步骤：Bulk衔接修复后续跑（R-055/P-056/C-058）

服务器已通过r2复用预检、基线DC及扫描缓存；无需再次下发r2或诊断分段。新的0/16在本地用同样三字段操作复现：Bulk绑定已取得，但操作未传值。当前补丁在有限实验同型NMOS场景继承原B端，保留构建失败的原始原因。

上传ldo_bulk_handoff_fix_20261014.zip到服务器用户目录，解压成功后执行编译和续跑。两者用&&连接，编译失败不会运行旧二进制：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -o ldo_bulk_handoff_fix_20261014.zip
bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs
set st_rc = $status
echo "编译并续跑退出码=$st_rc"
```

只编译主工具；不重做inspect/confirm。已有Python版本清单和复用凭据保持不变。generate日志会记录EXPERIMENT_BULK_INHERITED及从原B端读取的实际网名；若仍在构建阶段失败，报告candidate_construction_failed和原始原因，而不是笼统无解。实际候选会走原生CDF/连接回读和DC，不承诺一次通过。仍以RESULT=EXPERIMENT_DC_PASS、EXPERIMENTAL_DC_READY=true及退出0判定本轮实验DC完成；可靠性/完整功能/发布尚未完成。

## 2026-10-14 同输入复用与外围电阻保留续跑

当前版本r2（R-054/P-055/C-057）：修复R3_2__res_gen双下划线漏识别，两个检查点使用共同解析；9套101项本地回归通过。单/双下划线是可识别的候选组格式，不能把不同实际名字改成同一个实例。保留原网表不变条件和候选电气验证。

用户已批准R-053：原网表不变的外围电阻不再逐段反查OA；同输入验证结果不重复原生检查。本批只更新Python/shell，无需重编C++，不重做inspect/confirm，不再运行旧inspect_cascode_resistor_groups.py。下载ldo_reuse_patch_20261014_r2.zip至服务器用户目录，在已有保存$st_batch的csh/tcsh终端执行：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -o ldo_reuse_patch_20261014_r2.zip
python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs
set st_rc = $status
echo "续跑退出码=$st_rc"
```

解压失败时不要继续。包仅覆盖6个指定代码/版本文件，保留build和所有运行目录；没有rm步骤。默认选择$st_batch最新candidate_*的失败generate，脚本打印CANDIDATE_DIR/OUTPUT_DIR并保留每次续跑日志。

预检应出现REUSE_PREFLIGHT=PASS、PDK_SCAN_REUSE_READY=true、PORT_EVIDENCE_REUSED=true、DEVICE_BINDINGS_REUSED=true、PRESERVED_RESISTOR_GROUPS（实际数量）。完整原生网表和仿真控制相同才有BASELINE_DC_REUSE_READY=true；不同会给BASELINE_REUSE_REASON，旧DC不复用。REBUILD=false、INSPECT_REUSED=true、CONFIRM_REUSED=true保持。首次失败不自动重试，回传输出和退出码即可。

只有RESULT=EXPERIMENT_DC_PASS、EXPERIMENTAL_DC_READY=true且退出0才表示本轮实验DC通过。预检/缓存通过不表示候选通过。RELIABILITY_VERIFIED=false、READY_FOR_SIZING=false、PUBLISHED=false仍是当前实验范围的预期边界。新增VBIAS及受影响器件继续检查，新的未匹配分段电阻不在外围豁免内。

对应 R-042 / P-043。停止把 `res_calc.il`、可读回调源码、完整尺寸域、完整额定资料作为实验前置条件。

`experimental_dc` 只表示隔离实验。实际极性、端子、Bulk、供电及 OP 映射仍需确认；已知电气限制继续执行。单 Corner DC 不能证明启动、输出性能、稳定性、最终同参数 PVT 或可靠性通过。

## 当前服务器下一步：总线端口兼容修复后续跑

服务器已证实两组OA总线`IBIAS_SET<1:0>`、`OCP_SET<1:0>`在Spectre中按位展开/转义，旧代码直接比原始名字而误拒绝。22个terminal对象对应24根线；这不是端口数量真的少了。修复只改变OA端口元数据的比较，保持Bench端序及生成网表的节点文本；真实缺位/多位/重复/接线缺失仍失败。

上传小包`LDO_Cascode_BusPorts_20261014.zip`到工程父目录，执行：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_BusPorts_20261014.zip
python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --upgrade-port-reader
set st_rc = $status
echo "端口修复续跑退出码=$st_rc"
```

首先在保留的失败导出上做纯文件预检，不启动EDA。若原Bench也未使用两位IBIAS_SET，则`PORTS_UNUSED_IN_BOTH`会列出它们；如果原来已使用的端口在新导出中消失，停止并打印具体名称，不补接/补零。

预检通过后应见`PORT_PREFLIGHT=PASS`、`PORT_BINDING=BUS_BITS_VERIFIED OA=22 BITS=24`、`PORT_RUNTIME_UPGRADED=true`、`ORIGINAL_INPUT_MANIFEST_UNCHANGED=true`、`CHECKER=cascode-experiment-resume-v2`，然后`REBUILD=false`、`INSPECT_REUSED=true`、`CONFIRM_REUSED=true`并续跑generate。后半段会启动原生导出/仿真，不能将整条命令理解为零EDA。

这次仅允许发布记录中指定的cascode_runtime.py旧/新SHA256变化；其余封存文件仍验证。新Provider清单及升级回执单独写到resume目录，旧清单/确认操作/会话不改，不重新编译或inspect。新清单仍由正式Provider校验，复用standalone.environment和同一个C++ generate入口。后续失败如需再续跑，可复用最近回执；不自动接受更多源码或参数变化。首次升级若已有基线OP输出则拒绝，以免复用旧版本结果。

真实实验通过仍需`RESULT=EXPERIMENT_DC_PASS`、`EXPERIMENTAL_DC_READY=true`、退出0；仅端口预检通过不能证明DC或VBIAS通过。若失败，返回这次摘要和退出码，不反复重跑。尚无新候选完整电气验收证据。

## 历史：运行根修复后的 generate 续跑

首轮服务器 build（34.8秒）、prepare、inspect（38.4秒）及 confirm 已通过。generate 的实际阻挡为 `operating-point run root must be an absolute writable directory`，路径来自旧 ST_OP_RUN_ROOT；在调用 OP Provider 前即退出，不能据此判断电路是否收敛。实验模式现使用本次 identity.tsv 所在目录下的 raw_op，自动创建并打印 OP_RUN_ROOT；其它范围保留原行为。

上传 `LDO_Cascode_RunRoot_20261014.zip` 到工程父目录后：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_RunRoot_20261014.zip
python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch"
set st_rc = $status
echo "续跑退出码=$st_rc"
```

自动选择此 batch 最新 candidate；其最近状态必须是 generate 失败，已有 experimental_dc 会话、确认操作和输入指纹必须有效。也可用 `--candidate /实际candidate目录` 明确指定。本补丁不改 server/site/*.py、PDK/Profile 或原 session，所以无需更新已封存指纹、重新 inspect 或编译。

开头应显示 `CHECKER=cascode-experiment-resume-v1`、`RESUME_STAGE=generate`、`REBUILD=false`、`INSPECT_REUSED=true`、`CONFIRM_REUSED=true`。仍需执行 generate 内部的目录复核/原生工作，不能保证无任何基线 DC。每30秒输出阶段进度。

旧顶层 run_status.json、generate.log 和输入文件保留；在 candidate 下新建 resume_generate_*，保存原 work/logs 副本、本次日志、命令和结果。成功需 `RESULT=EXPERIMENT_DC_PASS`、`EXPERIMENTAL_DC_READY=true`、退出0，其它最终验收状态仍false。若失败，返回本次最后摘要和退出码，不反复重跑。当前服务器尚无新候选电气通过证据。

## 历史：首次 I21 同型 Cascode 隔离实验

用户已回传 binding-v3 / EXPERIMENT_INPUTS_BOUND / EXPERIMENT_INPUTS_READY=true / 退出 0。停止重复绑定、模型资料搜索和 JSON 转录。上传 `LDO_Cascode_FirstExperiment_20261014.zip` 到工程父目录后：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_FirstExperiment_20261014.zip
python3 st-engine-maau/server/site/run_cascode_experiment.py --session "$st_work" --batch "$st_batch"
set st_rc = $status
echo "I21实验退出码=$st_rc"
```

入口读取同基线最新绑定和精确文件标识，仅编译一次主工具；后续源码/二进制哈希匹配时复用编译。`--tool-only` 不编译全部测试程序，默认 `build.sh` 的完整行为仍保留。运行创建 `$st_batch/candidate_I21_*`，其下为独立 cds.lib、work 会话、操作文件、阶段日志和 run_status.json；原 `$st_work` 不覆盖。未选作变换的原生 primitive 仅保留其实际 master/model 绑定，不参与本轮选型或优化。

运行顺序为 build、prepare、inspect、confirm、generate，每 30 秒输出正在运行的阶段。阶段超时默认 1800 秒，是停止上限而非预计耗时；原生 Runtime 的单次超时仍有效。任何失败保留日志并停止，不自动重复运行。`generate` 会调用真正的 OA/CDF、Spectre 和回读，沿用已有 Bundle 的模型/Corner/求解设置；现有 Provider 仍可能为新会话运行一次基线一致性 DC，因此不能把此命令描述为零仿真。

先对 I21 用真实实例参数起点执行同型 Cascode；I105 暂不叠加，之后单独实验。当前有限试点 `trials={}`，不做大范围参数优化，起点不可行时保留电气原因供下一次小范围调整，不放宽电路条件。

如果全部实验门禁通过：`RESULT=EXPERIMENT_DC_PASS`、`EXPERIMENTAL_DC_READY=true`、退出 0；`READY_FOR_SIZING=false`、`RELIABILITY_VERIFIED=false`、`PUBLISHED=false` 必须仍为 false。这些表示隔离实验完成，不代表启动、稳定性、输出性能、完整 PVT 或可靠性已通过。

如果退出 2，返回脚本最后摘要（包括 STAGE_LOG、DETAIL_LOG、DETAIL、ISSUE、DETAILS_FILE）；不要重跑同一命令。`run_status.json` 保留实际失败阶段/原生退出码，work/reports/validation.txt 和 solver_trace.jsonl 保留生成阶段能取得的详细证据。输入错误发生于原生运行之前时也明确退出 2。

## 历史：Bulk 同网端口绑定（v3，已回传通过）

服务器 v2 的缓存复用已经成功，唯一 pending 是 I105 的局部 Bulk 名 PVDD。v3 按已验收网表映射检查：PVDD、模板 AVDD 和目标 B 必须解析为同一实际网。不会因为电压数值相等而放行不同网，也不修改电路接线。

上传 `LDO_Cascode_BulkAlias_20261014.zip` 到工程父目录后：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_BulkAlias_20261014.zip
python3 st-engine-maau/server/site/prepare_cascode_experiment.py --session "$st_work" --batch "$st_batch" --reuse-native
set st_rc = $status
echo "缓存绑定退出码=$st_rc"
```

预期 `CHECKER=cascode-experiment-binding-v3`、`RESULT=EXPERIMENT_INPUTS_BOUND`、`NATIVE_EXECUTIONS=0`、`NATIVE_EVIDENCE_REUSED=true`、`EXPERIMENT_INPUTS_READY=true`、退出 0；I105 显示 `kind=mos_p bulk=PVDD template_bulk=AVDD` 及实际解析网。

本步骤不启动 OCEAN/Spectre，不需编译，不覆盖旧证据；缓存失败不会自动重跑 EDA。若仍退出 2，保留全部 `PENDING` 行；仍未生成 VBIAS，不把输入成功当作电路验收。

## 历史：复用已读结果（绑定 v2，已回传）

用户已回传绑定 v1：原生读取 1 次，I21/I105 的 bsimcmg model TYPE 分别 1/0；在电阻种子连接比较处退出 2。本次只消费这次缓存，不再执行 OCEAN/Spectre、重读 PSF 或编译 C++。

上传 `LDO_Cascode_BindResume_20261014.zip` 到工程父目录，然后执行：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_BindResume_20261014.zip
python3 st-engine-maau/server/site/prepare_cascode_experiment.py --session "$st_work" --batch "$st_batch" --reuse-native
set st_rc = $status
echo "缓存绑定退出码=$st_rc"
```

预期 `CHECKER=cascode-experiment-binding-v2`、`RESULT=EXPERIMENT_INPUTS_BOUND`、`NATIVE_EXECUTIONS=0`、`NATIVE_EVIDENCE_REUSED=true`、`EXPERIMENT_INPUTS_READY=true`、退出 0。脚本自动选同基线最新绑定记录，不据转录拼目录。缓存不齐或漂移退出 2，返回摘要即可；不会偷偷启动 EDA。

电阻原来的两个网名保存在 `RESISTOR_SEED_CONTEXT`，`original_connections_match=false` 不阻止借用它的真实型号/参数；这不是对新候选接线的放宽。新增电阻仍由模板连接，并由已有候选原生 CDF、网表/连接回读和电气验证检查。实际实例/模型、端序、电流映射以及三端电阻 Bulk 条件仍检查，不推断网名如何改写。

[BSIM-CMG 手册 7.2](https://bsim.gitbooks.io/bsimcmg/content/Ch7.2.html) 定义 TYPE 为 NMOS=1、PMOS=0；仅在原生报告的 family/model 与该实例及已有 CMG 来源一致时使用。共享模型名含 I85 不用作实例归属判断，保留原生实例到模型对应关系。

旧 `ST_EXPERIMENT_BIND_NATIVE_FAILED` 为 prog 成功路径没有显式返回导致的假标记，已改为 return(t)；[Cadence 官方解释](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/45305/variable-by-itself-on-a-line-meaning/1368062) 说明 prog 默认返回 nil。旧缓存只在完成标记、TSV/JSON一致及原电阻比较异常吻合时迁移，不泛化忽略原生失败。未来重读的 SKILL 修复尚未在服务器执行。

输入成功后 `VBIAS_GENERATED=false`、`READY_FOR_SIZING=false`、`RELIABILITY_VERIFIED=false` 仍正常。尚未运行新候选；下一阶段是在新实验会话生成并验证候选。

## 历史：首次原生绑定（已读取，按上节复用）

用户已回传 v1 草稿准备退出 0。无需继续复制完整 CDF JSON；其中生成的 `cdf_l`/`length`、`cdf_m`/`multiplier` 重复别名和非数值项目由 v2 自动规范化。用户要求工具按模板决定合理接法，不把该授权写成已经证明 N/P 极性。

将 `LDO_Cascode_BindInputs_20261014.zip` 上传到工程父目录后：

```csh
cd /tmpdata/maau_epc/users/k00981589
unzip -oq LDO_Cascode_BindInputs_20261014.zip
python3 st-engine-maau/server/site/prepare_cascode_experiment.py --session "$st_work" --batch "$st_batch" --bind-native --native-timeout 180
set st_rc = $status
echo "实验绑定退出码=$st_rc"
```

预期 `RESULT=EXPERIMENT_INPUTS_BOUND`、`NATIVE_EXECUTIONS=1`、`EXPERIMENT_INPUTS_READY=true`、退出 0；分别列出轨网、两个 MOS 和一个真实电阻。只启动一次 OCEAN（含 OA 读取），不运行 Spectre、不保存源 OA、不生成新电路、不读模型内部源码。180 秒是原生读取进程超时上限，不是电路仿真预算。无需 C++ 重编。

`RESULT=BINDINGS_INCOMPLETE`/退出 2 时返回简短摘要和 `PENDING`，不重复运行。脚本保留已读结果、原生日志和未完成配置；不存在可确认的 N/P、合适电阻实例、直接端子电流映射或有来源的 CMG 数据时，不默认补齐。

成功输出 `simulation_profile.json`、`pdk_facts.json`、`experimental_metadata.preview.json` 及证据，尚未执行正式新会话 inspect 或生成，`READY_FOR_SIZING`、`RELIABILITY_VERIFIED`、`VBIAS_GENERATED` 仍为 false。额定值缺失不是本步骤前置阻挡。原有实际数值和有限候选从真实 CDF 读取；CDF文字与版图选项不当成几何变量，不以默认值替代实际值。

模型绑定使用 [Cadence 官方人员说明的实例到模型映射接口](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/55396/which-instance-model-parameters-does-spectre-save)，从已保存 model 结果读取 type；只识别明确 n/p 标签，不猜数值枚举或按型号名推极性。电阻电流使用 [CDF 的 termMapping 原生读取](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/22990/cdf-data-structure-flattened/1312722)，当前仅接受直接端子形式，表达式映射保留未完成。服务器本机具体返回形式仍待本轮确认。

## 历史：缓存草稿准备（已回传通过）

完整包解压到原工程位置后，先运行下面的缓存准备命令。这一步不要求重编、不启动 Virtuoso/OCEAN/Spectre、不搜索 PDK、不改变旧会话或基线。

```csh
set st_exp_stamp = `date +%Y%m%d_%H%M%S`
python3 /tmpdata/maau_epc/users/k00981589/st-engine-maau/server/site/prepare_cascode_experiment.py --session "$st_work" --batch "$st_batch" >& "$st_run/logs/experiment_${st_exp_stamp}.log"
set st_rc = $status
cat "$st_run/logs/experiment_${st_exp_stamp}.log"
echo "实验准备退出码=$st_rc"
```

预期：`RESULT=INPUT_DRAFT_PREPARED`、`NATIVE_EXECUTIONS=0`、退出 0。`PENDING_BINDINGS` 汇总真正仍缺的接线/映射/实例数据；耐压与完整尺寸域不会再列为实验前置任务。

`EXPERIMENT_INPUTS_READY=false`、`RELIABILITY_VERIFIED=false`、`VBIAS_GENERATED=false` 是明确的草稿状态，不是又一次仿真失败。准备脚本不假造缺少的 N/P 极性、Bulk 策略、电阻实际参数或 CMG 映射，因此不会自动把草稿当作可运行配置。退出 2 表示已有缓存身份不一致或必要缓存不可读，返回摘要即可，不反复跑同一命令。

输出新的 `experiment_inputs_*` 目录，包含：

- `simulation_profile.draft.json`：已有 native-site Bundle、Corner/温度/变量、实际参数记录引用及哈希；`trials` 默认为空，意味着先从实际值开始。
- `pdk_facts.draft.json`：已有器件/端子/映射，未知值保持缺失。
- `preparation.json`：尚缺的最少绑定、真实电阻候选、电源候选、缓存来源；不填 CDF 默认值充当实际尺寸。

根据现有用户回传，下一次需要确认的是目标实际 N/P/Bulk、fin/CDF/CMG 映射、VBIAS 轨网，以及一个真实电阻的实际实例参数和电流读取映射。已有测量值和回调线索可以复用，不再继续查找 `res_calc.il`。

## 正式实验入口及输入合同

在最少绑定补齐后，将草稿另存为可执行配置；创建新实验会话，保留旧 `$st_work`。C++ 改动需要服务器执行 `bash scripts/build.sh`。沿用 `standalone.py inspect` 的源 Cell、Bench、cds.lib、输出目标参数，增加：

```text
--validation-scope experimental_dc
--simulation-profile /实际路径/simulation_profile.json
--pdk-rules /实际路径/pdk_facts.json
--work-dir /新的实验会话路径
```

只在新会话中 confirm/generate/open。入口要求有来源且哈希一致的 `experimental_pdk_cache`，避免重新全库发现/探测。配置中的 `experimental_parameter_seeds` 以真实 `library/cell` 为键，每个条目包含：

- `instance`：原生记录中的真实实例名；`native_records`：现有采集 JSON 的绝对路径；`native_records_sha256`：文件哈希。
- `trials`：按已证明的语义/CDF 映射列有限试点，可省略；原生实际值始终排在第一位。每个参数最多 5 个值，每个 master 的试点乘积最多 16，总名义求解预算最多 16 次。找不到可行解如实失败，不放宽电气条件。

每个选中 master 的事实至少包含 `kind`、`normalized_to_cdf`、与实际 CDF 端子对应的 `terminalRoles`、MOS 的 `bulkRule` 及其来源。Bulk 只接受两种已经实现的策略：`rail`（NMOS→VLOW，PMOS→VHIGH）或 `isolated_well`（每管 Bulk→自身 Source）；不能把未知策略字符串当作合法接法。未知耐压字段省略，有依据的耐压和电阻额定值保留。CMG 内部电压映射及电阻电流映射仍必须来自实际证据。

尺寸试点明确标记 `native_parameter_trials=true` / `parameter_domain_verified=false`。CDF 完整域无需提前整理；已知 min/max/grid/allowed 继续校验。原生回调→保存→网表/OA 回读必须逐候选经过，包括复制原 MOS 属性的新增管；回调改变值导致回读不一致就拒绝该候选。

## 结果的含义

实验成功只能输出 `experimental_dc_ready=true`、`published=false`、`ready_for_sizing=false`、`reliability_verified=false`；留在 `__STAGING`。配置过的同参数 PVT 可记录为 `experimental_pvt_ready`，不提升正式 `pvt_ready`。`open` 只打开本会话已校验的 staging。

MOS 实际 VGS/VDS/VGB、电阻实际 V/I/P 写入报告。缺失额定值通过 `unverified_constraint` / JSON null / TSV NA 表示；已知越限、必要 OP 缺失、源电路改变、错极性/Bulk/端子、回读失败仍停止。正式模式和发布入口拒绝试点元数据与实验缓存。

本地测试及进程夹具不代表服务器 Cadence 已执行；现场尚无本轮新 VBIAS、启动/稳定性或完整 PVT 通过证据。
