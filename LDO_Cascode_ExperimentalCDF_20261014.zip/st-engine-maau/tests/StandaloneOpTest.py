import importlib.util
import csv
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('op_provider', Path(__file__).resolve().parents[1] / 'server/site/op_provider.py')
op = importlib.util.module_from_spec(spec)
spec.loader.exec_module(op)
from site_data import pin_site_inputs

BENCH = '''simulator lang=spectre
parameters VIN=1.8
include "/pdk/m.scs" section=tt
subckt core VDD OUT VSS
N0 (OUT OUT VSS VSS) ndev w=2u l=1u
ends core
X0 (VDD OUT 0) core
V0 (VDD 0) vsource dc=VIN
oldtran tran stop=1u
'''
DUT = '''simulator lang=spectre
subckt wrapper D G S B
MKEEP (D G NS B) ndev w=2u l=1u
RADD (NS S) rdev r=1k w=1u l=2u
ends wrapper
subckt candidate VDD OUT VSS
N0 (OUT OUT VSS VSS) wrapper
ends candidate
'''


class StandaloneOpTest(unittest.TestCase):
    def test_independent_process_pipeline_uses_oa_exports_and_signed_psf(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            model = base / 'model.scs'
            model.write_text('// fixture model\n')
            bench_text = BENCH.replace('/pdk/m.scs', str(model))
            runtime = base / 'native_contract.py'
            # This is a process contract fixture, not real Cadence/Spectre evidence.
            runtime.write_text('#!/usr/bin/env python3\n' +
                'import json,sys,pathlib\n' +
                'args=dict(zip(sys.argv[2::2],sys.argv[3::2]))\n' +
                'stage=sys.argv[1]\n' +
                'if stage=="bench-info":\n' +
                ' pathlib.Path(args["--output"]).write_text(json.dumps({"Tests":{"dc":{"enable":True}}}))\n' +
                'elif stage=="device-bindings":\n' +
                ' pathlib.Path(args["--output"]).write_text(' + repr(
                    'instance\toa_library\toa_cell\toa_view\tterminal_names\n'
                    'N0.MKEEP\tL\tN\tsymbol\tD,G,S,B\nN0.RADD\tL\tR\tsymbol\tP,N\n') + ')\n' +
                'elif stage=="netlist":\n' +
                ' text=' + repr(bench_text) + ' if args["--cell"]=="B" else ' + repr(DUT) + '\n' +
                ' pathlib.Path(args["--output"]).write_text(text)\n' +
                ' pathlib.Path(args["--output"]+".origin.json").write_text(json.dumps({"working_directory":str(pathlib.Path(args["--output"]).parent),"dc_test_name":"dc"}))\n' +
                'elif stage=="simulate":\n' +
                ' pathlib.Path(args["--psf-dir"]).mkdir()\n' +
                'elif stage=="read-psf":\n' +
                ' pathlib.Path(args["--output"]).write_text(' + repr(
                    'signal\tvalue\nOUT\t1.2\nX0.N0.NS\t0.2\nX0.N0.MKEEP:ids\t-1e-5\n'
                    'X0.N0.MKEEP:vth\t-0.4\nX0.N0.MKEEP:vdsat\t-0.15\n'
                    'X0.N0.MKEEP:cgg\t1e-12\nX0.N0.RADD:1\t0.0002\nV0:p\t-0.0001\n') + ')\n')
            runtime.chmod(0o755)
            (base / 'cds.lib').write_text('DEFINE original /actual/oa\n')
            context = {'source_dut': {'lib': 'L', 'cell': 'core', 'view': 'schematic'},
                       'source_benches': [{'lib': 'L', 'cell': 'B', 'view': 'schematic'}],
                       'source_cds_path': str(base)}
            rules = {'original_model_files': [str(model)],
                     'op_corners': {'tt': {'temperature': 27, 'models': [
                         {'model_file': str(model), 'section_name': 'tt'}]}},
                     'supply_current_signals': [{'signal': 'V0:p', 'sign': -1}]}
            resistor_rule = {'corner': 'tt', 'temperature_min': -40, 'temperature_max': 125,
                             'geometry': {'w': {'min': 1e-6, 'max': 2e-6}},
                             'max_voltage': 2, 'max_current': 1e-3, 'source': 'fixture manual'}
            config = [{'version': 'config-sha256:fixture', 'devices': [
                {'cell': 'N', 'kind': 'mos_n', 'signal_postfix': '', 'dc_signals': {'id': 'ids', 'vth': 'vth',
                    'vdsat': 'vdsat', 'cgg': 'cgg'}, 'electrical_rules': {}},
                {'cell': 'R', 'kind': 'resistor', 'signal_postfix': '', 'dc_signals': {},
                 'electrical_rules': {'dc_signals': {'current': '1'}, 'resistor_ratings': [resistor_rule]}}]}]
            for name, value in [('context', context), ('rules', rules), ('tech', config)]:
                (base / (name + '.json')).write_text(json.dumps(value))
            catalog = base / 'catalog.tsv'
            with catalog.open('w', newline='') as stream:
                writer = csv.writer(stream, delimiter='\t')
                writer.writerow(['model_name', 'pdk_version', 'oa_library', 'oa_cell', 'kind', 'terminal_names', 'terminal_roles', 'master'])
                writer.writerow(['ndev', 'config-sha256:fixture', 'L', 'N', 'mos_n', 'D,G,S,B', 'drain,gate,source,bulk', 'oa_L__N'])
                writer.writerow(['rdev', 'config-sha256:fixture', 'L', 'R', 'resistor', 'P,N', 'positive,negative', 'oa_L__R'])
            environment = {'ST_CIRCUIT_CONTEXT': str(base / 'context.json'),
                           'ST_SIMULATION_PROFILE': str(base / 'rules.json'),
                           'ST_PDK_METADATA': str(base / 'tech.json'), 'ST_CADENCE_RUNTIME_BIN': str(runtime),
                           'ST_PDK_TECH_ADAPTER': str(base / 'adapter.il'),
                           'ST_SITE_BINDINGS_BACKEND': str(runtime),
                           'ST_SITE_INPUTS_MANIFEST': str(base / 'provider_inputs.json')}
            adapter = base / 'adapter.il'
            adapter.write_text('; fixture')
            op.write_json(base / 'provider_inputs.json', pin_site_inputs({
                'context': str(base / 'context.json'), 'rules': str(base / 'rules.json'),
                'tech': str(base / 'tech.json'), 'runtime': str(runtime), 'adapter': str(adapter)}))
            from types import SimpleNamespace
            args = SimpleNamespace(simulation_dir=str(base / 'run'), pdk_version='config-sha256:fixture',
                bench_lib='L', bench_cell='B', bench_view='schematic', dut_lib='DERIVED', dut_cell='candidate',
                dut_view='schematic', cds_lib=str(base / 'cds.lib'), corner='tt', device_catalog=str(catalog),
                identity_output=str(base / 'identity.tsv'), mos_output=str(base / 'mos.tsv'),
                resistor_output=str(base / 'resistors.tsv'), dut_hash='d', bench_hash='b', topology_hash='t',
                parameter_hash='p', solver_version='s')
            with patch.dict(os.environ, environment):
                op.run(args)
            with (base / 'mos.tsv').open() as stream:
                mos = list(csv.reader(stream, delimiter='\t'))
            self.assertEqual(float(mos[1][5]), -1e-5)
            self.assertEqual(mos[1][0], 'N0.MKEEP')
            with (base / 'identity.tsv').open() as stream:
                identity = list(csv.reader(stream, delimiter='\t'))
            self.assertAlmostEqual(float(identity[1][-1]), 0.0001)
            # Re-run the real provider pipeline without an optional supply mapping.
            rules.pop('supply_current_signals')
            (base / 'rules.json').write_text(json.dumps(rules))
            op.write_json(base / 'provider_inputs.json', pin_site_inputs({
                'context': str(base / 'context.json'), 'rules': str(base / 'rules.json'),
                'tech': str(base / 'tech.json'), 'runtime': str(runtime), 'adapter': str(adapter)}))
            args.simulation_dir = str(base / 'optional-run')
            args.identity_output = str(base / 'optional-identity.tsv')
            args.mos_output = str(base / 'optional-mos.tsv')
            args.resistor_output = str(base / 'optional-resistors.tsv')
            with patch.dict(os.environ, environment):
                op.run(args)
            with (base / 'optional-identity.tsv').open() as stream:
                optional_identity = list(csv.reader(stream, delimiter='\t'))
            self.assertEqual(optional_identity[1][-1], 'NA')

            self.assertEqual(json.loads((base / 'run/extraction.json').read_text())['resistor_count'], 1)
            self.assertIn('physical_dut_sha256', json.loads((base / 'run/binding.json').read_text()))
            # A real provider extraction still produces measurements without ratings
            # only in explicitly experimental mode (process fixture, not Cadence).
            config[0]['devices'][1]['electrical_rules'].pop('resistor_ratings')
            (base/'tech.json').write_text(json.dumps(config))
            for scope, expected_count in [('dc_operating_point', 0), ('experimental_dc', 1)]:
                rules['validation_scope'] = scope
                (base/'rules.json').write_text(json.dumps(rules))
                op.write_json(base/'provider_inputs.json', pin_site_inputs({
                    'context': str(base/'context.json'), 'rules': str(base/'rules.json'),
                    'tech': str(base/'tech.json'), 'runtime': str(runtime), 'adapter': str(adapter)}))
                args.simulation_dir = str(base/scope)
                args.resistor_output = str(base/(scope+'.tsv'))
                args.identity_output = str(base/(scope+'-identity.tsv'))
                args.mos_output = str(base/(scope+'-mos.tsv'))
                with patch.dict(os.environ, environment):
                    op.run(args)
                extraction = json.loads((base/scope/'extraction.json').read_text())
                self.assertEqual(extraction['resistor_count'], expected_count)
                if expected_count:
                    with Path(args.resistor_output).open() as stream:
                        measured = list(csv.DictReader(stream, delimiter='\t'))[0]
                    self.assertEqual([measured[k] for k in ('max_voltage', 'max_power', 'max_current')], ['NA']*3)
                    self.assertEqual(measured['rating_source'], '-')
                    self.assertAlmostEqual(extraction['resistor_measurements'][0]['power'], 0.00004)
            with self.assertRaisesRegex(ValueError, 'Bench electrical context changed'):
                op.check_bench_binding(base / 'context.json', bench_text.replace('VIN=1.8', 'VIN=2.0'))

    def test_bind_physical_candidate_preserve_bench_and_reject_port_drift(self):
        deck, root = op.bind_dut(BENCH, DUT, 'core', 'candidate')
        self.assertEqual(root, 'X0')
        self.assertIn('X0 (VDD OUT 0) candidate', deck)
        self.assertIn('parameters VIN=1.8', deck)
        self.assertIn('V0 (VDD 0) vsource dc=VIN', deck)
        with self.assertRaisesRegex(ValueError, 'port'):
            op.bind_dut(BENCH, DUT.replace('candidate VDD OUT VSS', 'candidate OUT VDD VSS'), 'core', 'candidate')
        with self.assertRaisesRegex(ValueError, 'unique'):
            op.bind_dut(BENCH + 'X1 (VDD OUT 0) core\n', DUT, 'core', 'candidate')

    def test_exact_hierarchical_nodes_and_signed_op(self):
        deck, root = op.bind_dut(BENCH, DUT, 'core', 'candidate')
        devices = op.flatten_dut(deck, root, 'candidate')
        self.assertEqual(devices[0]['nodes'][2], 'X0.N0.NS')
        self.assertEqual(devices[1]['nodes'][1], '0')
        raw = {'OUT': 1.2, 'X0.N0.NS': 0.2, 'X0.N0.MKEEP:ids': -0.00001,
               'X0.N0.MKEEP:vth': -0.4, 'X0.N0.MKEEP:vdsat': -0.15,
               'X0.N0.MKEEP:cgg': 1e-12, 'X0.N0.MKEEP:vbs': -0.2}
        row = op.mos_row(devices[0], raw, {'terminal_roles': ['drain', 'gate', 'source', 'bulk']},
                         {'id': 'ids', 'vth': 'vth', 'vdsat': 'vdsat', 'cgg': 'cgg'})
        self.assertEqual(row[5], -0.00001)
        self.assertEqual(row[9], -0.4)
        self.assertEqual(row[10], -0.15)
        with self.assertRaisesRegex(ValueError, 'missing'):
            op.raw_value({'wrong.X0.N0.MKEEP:ids': 1}, 'X0.N0.MKEEP:ids')

    def test_resistor_rating_matches_actual_geometry_corner_temperature(self):
        rules = [{'corner': 'tt', 'temperature_min': -40, 'temperature_max': 125,
                  'geometry': {'w': {'min': 1e-6, 'max': 2e-6}},
                  'max_voltage': 2, 'max_power': 1e-3, 'source': 'manual table 7'}]
        self.assertEqual(op.resistor_rating(rules, {'w': 1e-6}, 'tt', 27)['max_power'], 1e-3)
        with self.assertRaisesRegex(ValueError, 'rating'):
            op.resistor_rating(rules, {'w': 3e-6}, 'tt', 27)
        with self.assertRaisesRegex(ValueError, 'rating'):
            op.resistor_rating(rules, {'w': 1e-6}, 'ss', 27)

    def test_experimental_resistor_unknown_and_partial_ratings_remain_measurable(self):
        self.assertEqual(op.resistor_rating([], {'w': 1e-6}, 'tt', 27, experimental_dc=True), {})
        rule = dict(corner='tt', temperature_min=-40, temperature_max=125,
                    geometry={'w': {'min': 1e-6, 'max': 2e-6}},
                    max_current=1e-3, source='actual rule')
        self.assertEqual(op.resistor_rating([rule], {'w': 1e-6}, 'tt', 27,
                                          experimental_dc=True)['max_current'], 1e-3)
        legacy = dict(rule, max_voltage=2, max_power=0)
        rated = op.resistor_rating([legacy], {'w': 1e-6}, 'tt', 27, experimental_dc=True)
        self.assertNotIn('max_power', rated)
        self.assertEqual(rated['max_voltage'], 2)
        with self.assertRaises(ValueError):
            op.resistor_rating([dict(legacy, max_power=-1)], {'w': 1e-6}, 'tt', 27, experimental_dc=True)
        with self.assertRaises(ValueError):
            op.resistor_rating([rule], {'w': 1e-6}, 'tt', 27)
        for invalid in (0, -1, float('nan')):
            with self.assertRaises(ValueError):
                op.resistor_rating([dict(rule, max_voltage=invalid)], {'w': 1e-6}, 'tt', 27,
                                   experimental_dc=True)
        with self.assertRaisesRegex(ValueError, 'ambiguous'):
            op.resistor_rating([rule, rule], {'w': 1e-6}, 'tt', 27, experimental_dc=True)

    def test_parameter_resolution_and_dc_request(self):
        self.assertAlmostEqual(op.parameter_value('RBASE*2', {'RBASE': '1k'}), 2000)
        with self.assertRaises(ValueError):
            op.parameter_value('__import__("os")', {})
        deck = op.request_dc(BENCH)
        self.assertNotIn('oldtran tran', deck)
        self.assertIn('dcOp dc', deck)
        self.assertIn('what=oppoint', deck)
        self.assertIn('subcktprobelvl', deck)
        self.assertEqual(op.bench_context_digest(BENCH), op.bench_context_digest('// timestamp changes\n' + BENCH))
        self.assertNotEqual(op.bench_context_digest(BENCH), op.bench_context_digest(BENCH.replace('VIN=1.8', 'VIN=2.0')))

    def test_root_and_wrapper_overrides_use_parent_scope(self):
        text = '''simulator lang=spectre
parameters WIDTH=1u
subckt candidate A B
parameters WIDTH=2u
R0 (A B) rdev w=WIDTH
ends candidate
subckt wrapper A B
parameters WIDTH=3u
X0 (A B) candidate WIDTH=WIDTH
ends wrapper
XW (A 0) wrapper WIDTH=WIDTH
'''
        devices = op.flatten_dut(text, 'XW.X0', 'candidate')
        self.assertAlmostEqual(op.parameter_value(devices[0]['params']['w'], devices[0]['parameters']), 1e-6)

    def test_corner_preserves_multiple_sections_and_effective_binding(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            model = root / 'm.scs'
            model.write_text('// fixture')
            bench = BENCH.replace('/pdk/m.scs', str(model))
            corner = {'sections': [{'model_file': str(model), 'section_name': 'mos_tt'},
                                   {'model_file': str(model), 'section_name': 'res_tt'}]}
            applied = op.apply_corner(bench, corner, 27, [str(model)], {})
            self.assertIn('section=mos_tt', applied)
            self.assertIn('section=res_tt', applied)
            self.assertLess(applied.index('section=mos_tt'), applied.index('section=res_tt'))
            context = root / 'context.json'
            op.check_bench_binding(context, applied, 'tt')
            op.check_bench_binding(context, applied, 'tt')
            hot = op.apply_corner(bench, corner, 125, [str(model)], {})
            op.check_bench_binding(context, hot, 'hot')
            with self.assertRaisesRegex(ValueError, 'changed'):
                op.check_bench_binding(context, hot, 'tt')

    def test_duplicate_models_resolve_only_by_used_physical_oa_identity(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'catalog.tsv'
            with path.open('w', newline='') as stream:
                writer = csv.writer(stream, delimiter='\t')
                writer.writerow(['model_name', 'pdk_version', 'oa_library', 'oa_cell', 'kind',
                                 'terminal_names', 'terminal_roles', 'master'])
                writer.writerow(['nmod', 'v', 'PDK', 'N4', 'mos_n', 'D,G,S,B',
                                 'drain,gate,source,bulk', 'oa_PDK__N4'])
                writer.writerow(['nmod', 'v', 'PDK', 'N3', 'mos_n', 'D,G,S',
                                 'drain,gate,source', 'oa_PDK__N3'])
            tech = {'devices': [{'cell': cell, 'kind': 'mos_n'} for cell in ('N3', 'N4')]}
            catalog = op.load_scanned_catalog(path, tech, 'v')
            self.assertEqual(len(catalog['nmod']), 2)
            device = {'master': 'nmod', 'nodes': ['D', 'G', 'S', 'B'], 'output_name': 'M0'}
            proof = {'M0': {'oa_library': 'PDK', 'oa_cell': 'N4', 'terminal_names': ['D', 'G', 'S', 'B']}}
            self.assertEqual(op.resolve_device(device, catalog, proof)[0]['oa_cell'], 'N4')
            with self.assertRaisesRegex(ValueError, 'physical OA'):
                op.resolve_device(device, catalog, {})
            proof['M0']['terminal_names'] = ['B', 'D', 'G', 'S']
            with self.assertRaisesRegex(ValueError, 'terminal'):
                op.resolve_device(device, catalog, proof)

    def test_all_physical_pdk_bindings_must_match_the_exported_model(self):
        deck, root = op.bind_dut(BENCH, DUT, 'core', 'candidate')
        catalogs = {'ndev': [({'oa_library': 'L', 'oa_cell': 'N', 'terminal_names': ['D', 'G', 'S', 'B'],
                               'terminal_roles': ['drain', 'gate', 'source', 'bulk']}, {})],
                    'rdev': [({'oa_library': 'L', 'oa_cell': 'R', 'terminal_names': ['P', 'N'],
                               'terminal_roles': ['positive', 'negative']}, {})]}
        bindings = {'N0.MKEEP': {'oa_library': 'L', 'oa_cell': 'N', 'terminal_names': ['D', 'G', 'S', 'B']},
                    'N0.RADD': {'oa_library': 'L', 'oa_cell': 'R', 'terminal_names': ['P', 'N']}}
        self.assertEqual(len(op.bind_physical_devices(deck, root, 'candidate', catalogs, bindings)), 2)
        with self.assertRaisesRegex(ValueError, 'physical PDK.*model'):
            op.bind_physical_devices(deck.replace(') ndev', ') wrong_model'), root, 'candidate', catalogs, bindings)
        bindings['N0.EXTRA'] = bindings['N0.MKEEP']
        with self.assertRaisesRegex(ValueError, 'not exported'):
            op.bind_physical_devices(deck, root, 'candidate', catalogs, bindings)

    def test_unknown_pdk_leaf_cannot_be_skipped_as_a_builtin_primitive(self):
        text = 'simulator lang=spectre\nsubckt C A B\nM0 (A A B B) ndev\nC0 (A B) cmodel\nends C\nX0 (A 0) C\n'
        catalog = {'ndev': [({'oa_library': 'PDK', 'oa_cell': 'N',
            'terminal_names': ['D', 'G', 'S', 'B'], 'terminal_roles': ['drain', 'gate', 'source', 'bulk']}, {})]}
        bindings = {'M0': {'oa_library': 'PDK', 'oa_cell': 'N', 'terminal_names': ['D', 'G', 'S', 'B']},
            'C0': {'oa_library': 'PDK', 'oa_cell': 'Unknown', 'terminal_names': ['P', 'N'],
                   'classification': 'unproven', 'model_name': ''}}
        with self.assertRaisesRegex(ValueError, 'unproven.*PDK'):
            op.bind_physical_devices(text, 'X0', 'C', catalog, bindings)
        bindings['C0'].update(classification='non_target', model_name='cmodel')
        self.assertEqual(len(op.bind_physical_devices(text, 'X0', 'C', catalog, bindings)), 1)
        with self.assertRaisesRegex(ValueError, 'non-target.*model'):
            op.bind_physical_devices(text.replace(') cmodel', ') different'), 'X0', 'C', catalog, bindings)


if __name__ == '__main__':
    unittest.main()
