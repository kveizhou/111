#include "st/DcSolver.h"

#include "st/Netlist.h"
#include "st/OperatingPoint.h"
#include "st/PdkCatalog.h"
#include "st/VariantVerifier.h"

#include <array>
#include <cmath>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

bool closeTo(double actual, double expected)
{
    return std::fabs(actual - expected) <= 1e-9 * std::max(1.0, std::fabs(expected));
}

// ---- Fake PDK 目录 ----------------------------------------------------------

st::ParameterConstraint makeConstraint(const std::string& semantic,
                                       const std::string& cdf, double minimum,
                                       double maximum, double grid,
                                       std::vector<double> discrete = {})
{
    st::ParameterConstraint constraint;
    constraint.semantic_name = semantic;
    constraint.cdf_name = cdf;
    constraint.minimum = minimum;
    constraint.maximum = maximum;
    constraint.grid = grid;
    constraint.discrete_values = std::move(discrete);
    return constraint;
}

st::DeviceDescriptor makeMos(const std::string& master, st::DeviceKind kind,
                             const std::string& library,
                             const std::vector<double>& discreteW = {},
                             const std::vector<double>& discreteL = {})
{
    st::DeviceDescriptor descriptor;
    descriptor.master = master;
    descriptor.kind = kind;
    descriptor.terminal_count = 4;
    descriptor.terminal_names_by_index = {"D", "G", "S", "B"};
    descriptor.terminal_roles_by_index = {st::TerminalRole::Drain,
                                          st::TerminalRole::Gate,
                                          st::TerminalRole::Source,
                                          st::TerminalRole::Bulk};
    descriptor.terminal_index[st::TerminalRole::Drain] = 0;
    descriptor.terminal_index[st::TerminalRole::Gate] = 1;
    descriptor.terminal_index[st::TerminalRole::Source] = 2;
    descriptor.terminal_index[st::TerminalRole::Bulk] = 3;
    descriptor.oa_library = library;
    descriptor.oa_cell = master + "_cell";
    descriptor.oa_view = "symbol";
    descriptor.pdk_name = "fake_pdk";
    descriptor.pdk_version = "v1";
    descriptor.device_family = kind == st::DeviceKind::MosN
        ? "fake_core_nmos" : "fake_core_pmos";
    descriptor.flavor_id = descriptor.master;
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains = {"core"};
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.limits.max_abs_vgs = 1.5;
    descriptor.limits.max_abs_vds = 1.5;
    descriptor.limits.max_abs_vgb = 1.5;
    descriptor.parameter_constraints["width"] =
        makeConstraint("width", "w", 2e-7, 1e-5, 5e-8, discreteW);
    descriptor.parameter_constraints["length"] =
        makeConstraint("length", "l", 1.8e-7, 2e-6, 1e-8, discreteL);
    return descriptor;
}

st::DeviceDescriptor makeResistor(const std::string& master,
                                  const std::string& library,
                                  const std::vector<double>& discreteR = {})
{
    st::DeviceDescriptor descriptor;
    descriptor.master = master;
    descriptor.kind = st::DeviceKind::Resistor;
    descriptor.terminal_count = 2;
    descriptor.terminal_names_by_index = {"PLUS", "MINUS"};
    descriptor.terminal_roles_by_index = {st::TerminalRole::Positive,
                                          st::TerminalRole::Negative};
    descriptor.terminal_index[st::TerminalRole::Positive] = 0;
    descriptor.terminal_index[st::TerminalRole::Negative] = 1;
    descriptor.oa_library = library;
    descriptor.oa_cell = master + "_cell";
    descriptor.oa_view = "symbol";
    descriptor.pdk_name = "fake_pdk";
    descriptor.pdk_version = "v1";
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains = {"core"};
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.parameter_constraints["resistance"] =
        makeConstraint("resistance", "r", 100.0, 1e6, 100.0, discreteR);
    return descriptor;
}

// 网格目录：几何中点 1.4u / 600n / 10k，初值点唯一最优
st::DeviceCatalog makeGridCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    catalog.Add(makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib"), diagnostic);
    catalog.Add(makeMos("cas_nmos", st::DeviceKind::MosN, "pdkA_lib"), diagnostic);
    catalog.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib"),
                diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib"), diagnostic);
    return catalog;
}

// 二点离散目录：每个参数只有 {min, max} 两个合法值，候选总数 = 32，搜索 6 次
st::DeviceCatalog makeDiscreteCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    catalog.Add(makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib",
                        {2e-7, 1e-5}, {1.8e-7, 2e-6}),
                diagnostic);
    catalog.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib",
                        {2e-7, 1e-5}, {1.8e-7, 2e-6}),
                diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib", {100.0, 1e6}),
                diagnostic);
    return catalog;
}

st::DeviceCatalog makePmosGridCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto ctlP = makeMos("ctl_pmos", st::DeviceKind::MosP, "pdkA_lib");
    ctlP.isolated_well = true;
    catalog.Add(ctlP, diagnostic);
    catalog.Add(makeMos("mir_nmos_a", st::DeviceKind::MosN, "pdkA_lib"),
                diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib"), diagnostic);
    return catalog;
}

st::DeviceCatalog makeFixedGeometryCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto control = makeMos("fixed_nmos", st::DeviceKind::MosN, "pdkA_lib");
    control.parameter_constraints.clear();
    auto mirror = makeMos("fixed_pmos", st::DeviceKind::MosP, "pdkA_lib");
    mirror.parameter_constraints.clear();
    catalog.Add(control, diagnostic);
    catalog.Add(mirror, diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib", {100.0, 1e4, 1e6}),
                diagnostic);
    return catalog;
}

st::DeviceCatalog makeFinfetCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto control = makeMos("fin_nmos", st::DeviceKind::MosN, "pdkA_lib");
    control.parameter_constraints.clear();
    control.parameter_constraints["fins"] =
        makeConstraint("fins", "nfin", 2.0, 8.0, 2.0, {2.0, 4.0, 8.0});
    control.parameter_constraints["fins"].integer_only = true;
    control.parameter_constraints["length"] =
        makeConstraint("length", "l", 1.2e-7, 2.4e-7, 6e-8,
                       {1.2e-7, 1.8e-7, 2.4e-7});
    control.normalized_to_cdf = {{"fins", "nfin"}, {"length", "l"}};
    auto mirror = makeMos("fin_pmos", st::DeviceKind::MosP, "pdkA_lib");
    mirror.parameter_constraints.clear();
    mirror.parameter_constraints["fins"] =
        makeConstraint("fins", "nfin", 2.0, 8.0, 2.0, {2.0, 4.0, 8.0});
    mirror.parameter_constraints["fins"].integer_only = true;
    mirror.parameter_constraints["length"] =
        makeConstraint("length", "l", 1.2e-7, 2.4e-7, 6e-8,
                       {1.2e-7, 1.8e-7, 2.4e-7});
    mirror.normalized_to_cdf = {{"fins", "nfin"}, {"length", "l"}};
    catalog.Add(control, diagnostic);
    catalog.Add(mirror, diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib", {100.0, 1e4, 1e6}),
                diagnostic);
    return catalog;
}

st::DeviceCatalog makeMultiplierCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto control = makeMos("multi_nmos", st::DeviceKind::MosN, "pdkA_lib");
    control.parameter_constraints.clear();
    control.parameter_constraints["multiplier"] =
        makeConstraint("multiplier", "m", 1.0, 4.0, 1.0,
                       {1.0, 2.0, 4.0});
    control.parameter_constraints["multiplier"].integer_only = true;
    auto mirror = makeMos("multi_pmos", st::DeviceKind::MosP, "pdkA_lib");
    mirror.parameter_constraints.clear();
    mirror.parameter_constraints["multiplier"] =
        makeConstraint("multiplier", "m", 1.0, 4.0, 1.0,
                       {1.0, 2.0, 4.0});
    mirror.parameter_constraints["multiplier"].integer_only = true;
    catalog.Add(control, diagnostic);
    catalog.Add(mirror, diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib", {1e4}), diagnostic);
    return catalog;
}

// ---- 基线网表与工作点 --------------------------------------------------------

st::Netlist makeBaselineNetlist(bool pmos)
{
    st::Netlist netlist;
    st::Subckt subckt;
    subckt.name = "ldo_core";
    subckt.pins = {"AVDD", "VSS", "OUT"};
    st::Instance target;
    if (pmos) {
        target.name = "MP0";
        target.model = "ctl_pmos";
        target.nets = {"OUT", "G0P", "VSRC_P", "AVDD"};
        target.params = {{"w", "4u"}, {"l", "0.5u"}};
    } else {
        target.name = "M0";
        target.model = "ctl_nmos";
        target.nets = {"OUT", "G0", "VSRC", "VSS"};
        target.params = {{"w", "2u"}, {"l", "0.24u"}};
    }
    subckt.instances.push_back(target);
    netlist.subckts.push_back(subckt);
    return netlist;
}

st::OperatingPointSnapshot makeBaselineOp(bool pmos)
{
    st::OperatingPointSnapshot snapshot;
    snapshot.identity = {"dut1", "bench1", "v1", "tt",
                         "topology-1", "parameters-1", "solver-1"};
    st::MosOperatingPoint op;
    if (pmos) {
        op.vd = 0.2; op.vg = 0.5; op.vs = 1.2; op.vb = 1.2;
        op.id = -60e-6; op.vgs = -0.7; op.vds = -1.0; op.vbs = 0.0;
        op.vth = -0.42; op.vdsat = -0.18;
        snapshot.mos["MP0"] = op;
        snapshot.total_supply_current = 120e-6;
    } else {
        op.vd = 1.2; op.vg = 0.9; op.vs = 0.3; op.vb = 0.0;
        op.id = 50e-6; op.vgs = 0.6; op.vds = 0.9; op.vbs = 0.0;
        op.vth = 0.45; op.vdsat = 0.15;
        snapshot.mos["M0"] = op;
        snapshot.total_supply_current = 100e-6;
    }
    return snapshot;
}

st::AutoBiasSolveRequest makeRequest(bool pmos)
{
    st::AutoBiasSolveRequest request;
    request.baseline = makeBaselineNetlist(pmos);
    request.root_subckt = "ldo_core";
    request.target_instance = pmos ? "MP0" : "M0";
    request.template_request.operation_id = "op1";
    request.template_request.polarity =
        pmos ? st::DeviceKind::MosP : st::DeviceKind::MosN;
    request.template_request.voltage_domain = "core";
    request.template_request.vhigh_net = "AVDD";
    request.template_request.vlow_net = "VSS";
    request.template_request.original_source_net = pmos ? "VSRC_P" : "VSRC";
    request.template_request.control_gate_net = pmos ? "G0P" : "G0";
    request.template_request.control_master = pmos ? "ctl_pmos" : "ctl_nmos";
    request.template_request.cascode_master = pmos ? "ctl_pmos" : "ctl_nmos";
    request.baseline_op = makeBaselineOp(pmos);
    request.nominal_identity = {"dut1", "bench1", "v1", "tt",
                                "topology-1", "parameters-1", "solver-1"};
    request.nmos_bulk_net = "VSS";
    request.max_branch_current_error = 0.2;
    request.max_vbias_current = 20e-6;
    return request;
}

st::AutoBiasSolveRequest makeDiscreteRequest(bool pmos = false)
{
    auto request = makeRequest(pmos);
    // 此目录的原管与Cascode均只有两个离散尺寸，基线也必须是合法实例。
    request.baseline.subckts.front().instances.front().params =
        {{"w", "200n"}, {"l", "180n"}};
    return request;
}

// ---- 候选网表观测 ------------------------------------------------------------

struct SeenCandidate {
    std::array<double, 5> values{0, 0, 0, 0, 0}; // w_cas,l_cas,w_mir,l_mir,r
    std::string template_id;
    std::string cas_rep_model;
    std::string ctrl_rep_model;
    std::map<std::string, std::string> ctrl_rep_params;
    bool has_transformed_target = false;
    bool has_cascode = false;
    bool has_bias_instance = false;
    bool has_no_top_level_bias = false;
    bool identity_matches_candidate = false;
};

double paramValue(const st::Instance* instance, const std::string& key)
{
    if (instance == nullptr) return 0.0;
    const auto found = instance->params.find(key);
    if (found == instance->params.end()) return 0.0;
    bool ok = false;
    const double value = st::parseSuffixValue(found->second, ok);
    return ok ? value : 0.0;
}

SeenCandidate extractCandidate(const st::DcEvaluationRequest& request, bool pmos)
{
    SeenCandidate seen;
    const std::string templateBase =
        pmos ? "VBIAS_P_CASCODE_AUTO" : "VBIAS_N_CASCODE_AUTO";
    const std::string targetName = pmos ? "MP0" : "M0";
    const std::string templateId = templateBase + "_" + targetName;
    const st::Subckt* subckt = request.candidate.find(templateId);
    if (subckt == nullptr) {
        seen.template_id = "<missing>";
        return seen;
    }

    seen.template_id = templateBase;
    const st::Instance* casRep =
        subckt->find(pmos ? "P_CAS_REP_P" : "N_CAS_REP_N");
    const st::Instance* ctrlRep =
        subckt->find(pmos ? "P_CTRL_REP_P" : "N_CTRL_REP_N");
    const st::Instance* mirror = subckt->find(pmos ? "N_REF" : "P_REF");
    const st::Instance* resistor = subckt->find(pmos ? "R_REF_P" : "R_REF_N");
    seen.values = {paramValue(casRep, "w"), paramValue(casRep, "l"),
                   paramValue(mirror, "w"), paramValue(mirror, "l"),
                   paramValue(resistor, "r")};
    seen.cas_rep_model = casRep != nullptr ? casRep->model : "";
    seen.ctrl_rep_model = ctrlRep != nullptr ? ctrlRep->model : "";
    if (ctrlRep != nullptr) seen.ctrl_rep_params = ctrlRep->params;
    const st::Subckt* root = request.candidate.find(request.root_subckt);
    const st::Instance* target = root == nullptr ? nullptr : root->find(targetName);
    const st::Instance* cascode =
        root == nullptr ? nullptr : root->find(targetName + "_CAS");
    seen.has_transformed_target = target != nullptr &&
        std::find(target->nets.begin(), target->nets.end(), targetName + "_MID") !=
            target->nets.end();
    seen.has_cascode = cascode != nullptr &&
        std::find(cascode->nets.begin(), cascode->nets.end(), targetName + "_MID") !=
            cascode->nets.end();
    if (root != nullptr) {
        for (const auto& instance : root->instances) {
            if (instance.model == templateId) {
                seen.has_bias_instance = true;
                break;
            }
        }
    }
    seen.has_no_top_level_bias = request.candidate.topInstances.empty();
    seen.identity_matches_candidate =
        request.identity.topology_hash ==
            st::ComputeNetlistTopologyHash(request.candidate) &&
        request.identity.parameter_hash ==
            st::ComputeNetlistParameterHash(request.candidate);
    return seen;
}

// ---- Fake 宿主 ----------------------------------------------------------

struct Knobs {
    bool converged = true;
    bool complete = true;
    double branch_err = 0.0;
    double ctrl_err = 0.0;
    double iq = 8e-6;
    double rel_margin = 0.5;
    double sat_margin = 0.3;
    double vbias = 1.2; // PMOS 时 0.6
    bool actual_overvoltage = false;
    bool control_linear = false;
};

st::OperatingPointSnapshot makeNmosOps(const Knobs& k, double iOrig)
{
    st::OperatingPointSnapshot snapshot;
    const double vhigh = 1.8;
    const double g = 1.5 - k.rel_margin; // Cascode Replica |VGS|=|VDS|=|VGB|
    st::MosOperatingPoint pRef;          // D=G=PBIAS_REF=1.0, S=B=VHIGH
    pRef.vd = pRef.vg = 1.0;
    pRef.vs = pRef.vb = vhigh;
    pRef.id = k.iq / 2;
    pRef.vgs = 1.0 - vhigh;
    pRef.vds = 1.0 - vhigh;
    pRef.vth = -0.4;
    pRef.vdsat = -0.05;
    snapshot.mos["P_REF"] = pRef;
    st::MosOperatingPoint pOut = pRef;   // D=VBIAS_N, G=PBIAS_REF, S=VHIGH
    pOut.vd = k.vbias;
    pOut.vds = k.vbias - vhigh;
    snapshot.mos["P_OUT_N"] = pOut;
    st::MosOperatingPoint casRep;        // D=G=VBIAS_N, S=B=vbias-g
    casRep.vd = casRep.vg = k.vbias;
    casRep.vs = casRep.vb = k.vbias - g;
    casRep.id = iOrig * (1.0 + k.branch_err);
    casRep.vgs = g;
    casRep.vds = g;
    casRep.vth = 0.45;
    casRep.vdsat = g - k.sat_margin;
    snapshot.mos["N_CAS_REP_N"] = casRep;
    st::MosOperatingPoint ctrlRep;       // G=VG_CTRL, S=VS_ORIG=0.3
    ctrlRep.vs = 0.3;
    ctrlRep.vb = 0.0;
    ctrlRep.vg = 0.9 + k.ctrl_err / 2;
    ctrlRep.vd = 1.2 + k.ctrl_err / 2;
    ctrlRep.id = iOrig * (1.0 + k.branch_err);
    ctrlRep.vgs = 0.6 + k.ctrl_err / 2;
    ctrlRep.vds = 0.9 + k.ctrl_err / 2;
    ctrlRep.vth = 0.45;
    ctrlRep.vdsat = k.control_linear ? 2.0 : 0.15;
    snapshot.mos["N_CTRL_REP_N"] = ctrlRep;
    st::MosOperatingPoint actualCas = casRep;
    actualCas.vd = 1.0;
    actualCas.vg = k.actual_overvoltage ? 1.9 : k.vbias;
    actualCas.vs = 0.3;
    actualCas.vb = 0.0;
    actualCas.vgs = actualCas.vg - actualCas.vs;
    actualCas.vds = actualCas.vd - actualCas.vs;
    actualCas.vdsat = 0.2;
    snapshot.mos["M0_CAS"] = actualCas;
    st::MosOperatingPoint actualControl = ctrlRep;
    snapshot.mos["M0"] = actualControl;
    snapshot.resistors["R_REF_N"] = {"res_two_term", "r=10k", 1.0, 0.0,
        5e-6, 1.5, 1e-4, 0.0, "fake-pdk/tt"};
    if (!k.complete) snapshot.mos.erase("N_CTRL_REP_N");
    return snapshot;
}

st::OperatingPointSnapshot makePmosOps(const Knobs& k, double iOrig)
{
    st::OperatingPointSnapshot snapshot;
    st::MosOperatingPoint nRef; // D=G=NBIAS_REF=0.8, S=B=VLOW
    nRef.vd = nRef.vg = 0.8;
    nRef.vs = nRef.vb = 0.0;
    nRef.id = k.iq / 2;
    nRef.vgs = 0.8;
    nRef.vds = 0.8;
    nRef.vth = 0.45;
    nRef.vdsat = 0.05;
    snapshot.mos["N_REF"] = nRef;
    st::MosOperatingPoint nOut = nRef; // D=X_REP_P=0.4, G=NBIAS_REF, S=VLOW
    nOut.vd = 0.4;
    nOut.vds = 0.4;
    snapshot.mos["N_OUT_P"] = nOut;
    st::MosOperatingPoint casRep; // D=G=VBIAS_P, S=B=VS_ORIG=1.2
    casRep.vd = casRep.vg = k.vbias;
    casRep.vs = casRep.vb = 1.2;
    casRep.id = iOrig * (1.0 + k.branch_err);
    casRep.vgs = k.vbias - 1.2;
    casRep.vds = k.vbias - 1.2;
    casRep.vth = -0.4;
    casRep.vdsat = -0.05;
    snapshot.mos["P_CAS_REP_P"] = casRep;
    st::MosOperatingPoint ctrlRep; // D=X_REP_P, G=VG_CTRL=0.5, S=B=VBIAS_P
    ctrlRep.vd = 0.4;
    ctrlRep.vg = 0.5;
    ctrlRep.vs = ctrlRep.vb = k.vbias;
    ctrlRep.id = iOrig * (1.0 + k.branch_err);
    ctrlRep.vgs = 0.5 - k.vbias;
    ctrlRep.vds = 0.4 - k.vbias;
    ctrlRep.vth = -0.4;
    ctrlRep.vdsat = -0.05;
    snapshot.mos["P_CTRL_REP_P"] = ctrlRep;
    st::MosOperatingPoint actualCas = casRep;
    actualCas.vd = 0.6;
    actualCas.vg = k.actual_overvoltage ? -0.5 : k.vbias;
    actualCas.vs = actualCas.vb = 1.2;
    actualCas.vgs = actualCas.vg - actualCas.vs;
    actualCas.vds = actualCas.vd - actualCas.vs;
    actualCas.vdsat = -0.1;
    snapshot.mos["MP0_CAS"] = actualCas;
    st::MosOperatingPoint actualControl = ctrlRep;
    actualControl.vd = 0.2;
    actualControl.vs = 0.6;
    actualControl.vb = 1.2;
    actualControl.vgs = -0.1;
    actualControl.vds = -0.4;
    actualControl.vdsat = -0.05;
    snapshot.mos["MP0"] = actualControl;
    snapshot.resistors["R_REF_P"] = {"res_two_term", "r=10k", 1.2, 0.2,
        5e-6, 1.5, 1e-4, 0.0, "fake-pdk/tt"};
    if (!k.complete) snapshot.mos.erase("P_CTRL_REP_P");
    return snapshot;
}

// 功能型宿主：初值点最优（branch 误差随参数对数距离增大），其余指标恒定
class FunctionalHost : public st::DcEvaluationHost {
public:
    int calls = 0;
    bool pmos = false;
    std::vector<SeenCandidate> seen;

    bool Evaluate(const st::DcEvaluationRequest& request,
                  st::OperatingPointSnapshot& snapshot,
                  st::Diagnostic&) override
    {
        ++calls;
        const SeenCandidate candidate = extractCandidate(request, pmos);
        seen.push_back(candidate);
        const std::array<double, 5> optimal = pmos
            ? std::array<double, 5>{4e-6, 5e-7, 1.4e-6, 6e-7, 1e4}
            : std::array<double, 5>{2e-6, 2.4e-7, 1.4e-6, 6e-7, 1e4};
        double error = 0.0;
        for (std::size_t index = 0; index < 5; ++index) {
            if (candidate.values[index] > 0.0) {
                error += std::fabs(
                    std::log(candidate.values[index] / optimal[index]));
            }
        }
        Knobs knobs;
        knobs.branch_err = error;
        knobs.vbias = pmos ? 0.6 : 1.2;
        snapshot = pmos ? makePmosOps(knobs, -60e-6) : makeNmosOps(knobs, 50e-6);
        return true;
    }
};

// 脚本型宿主：按候选参数位型（每个参数是否取 max）决定指标
class ScriptedHost : public st::DcEvaluationHost {
public:
    bool pmos = false;
    int calls = 0;
    std::vector<SeenCandidate> seen;
    // bits: w,l,mw,ml,r 是否取 max（离散目录 min/max 二点）
    std::function<Knobs(const std::array<bool, 5>&)> script;

    bool Evaluate(const st::DcEvaluationRequest& request,
                  st::OperatingPointSnapshot& snapshot,
                  st::Diagnostic&) override
    {
        ++calls;
        const SeenCandidate candidate = extractCandidate(request, pmos);
        seen.push_back(candidate);
        std::array<bool, 5> bits{};
        const std::array<double, 5> mins = {2e-7, 1.8e-7, 2e-7, 1.8e-7, 100.0};
        for (std::size_t index = 0; index < 5; ++index) {
            bits[index] = std::fabs(candidate.values[index] - mins[index]) >
                          0.01 * mins[index];
        }
        const Knobs knobs = script(bits);
        snapshot = pmos ? makePmosOps(knobs, -50e-6) : makeNmosOps(knobs, 50e-6);
        return knobs.converged;
    }
};

class PassingCaptureHost : public st::DcEvaluationHost {
public:
    int calls = 0;
    st::DcEvaluationRequest first;

    bool Evaluate(const st::DcEvaluationRequest& request,
                  st::OperatingPointSnapshot& snapshot,
                  st::Diagnostic&) override
    {
        if (calls == 0) first = request;
        ++calls;
        snapshot = makeNmosOps(Knobs{}, 50e-6);
        return true;
    }
};

// 真实求解器和模板组装仍运行；仅隔离需要外部 Spectre 的 DC 返回值。
class MasterSensitiveHost : public st::DcEvaluationHost {
public:
    bool pmos = false;
    std::string accepted_mirror;
    std::string accepted_resistor;
    int calls = 0;
    std::set<std::pair<std::string, std::string>> seen_masters;

    bool Evaluate(const st::DcEvaluationRequest& request,
                  st::OperatingPointSnapshot& snapshot,
                  st::Diagnostic& diagnostic) override
    {
        ++calls;
        const auto* subckt = request.candidate.find(
            pmos ? "VBIAS_P_CASCODE_AUTO_MP0" : "VBIAS_N_CASCODE_AUTO_M0");
        const auto* mirror = subckt == nullptr ? nullptr
            : subckt->find(pmos ? "N_REF" : "P_REF");
        const auto* resistor = subckt == nullptr ? nullptr
            : subckt->find(pmos ? "R_REF_P" : "R_REF_N");
        if (mirror == nullptr || resistor == nullptr) return false;
        seen_masters.insert({mirror->model, resistor->model});
        if (mirror->model != accepted_mirror ||
            resistor->model != accepted_resistor) {
            diagnostic = {st::DiagCode::BadParam, "this master pair has no DC solution"};
            return false;
        }
        Knobs knobs;
        knobs.vbias = pmos ? 0.6 : 1.2;
        snapshot = pmos ? makePmosOps(knobs, -60e-6)
                        : makeNmosOps(knobs, 50e-6);
        snapshot.resistors[pmos ? "R_REF_P" : "R_REF_N"].master =
            resistor->model;
        return true;
    }
};

std::size_t countTrace(const st::AutoBiasSolveResult& result,
                       const std::string& needle)
{
    std::size_t count = 0;
    for (const auto& line : result.trace_lines) {
        if (line.find(needle) != std::string::npos) ++count;
    }
    return count;
}

double sizingValue(const std::map<std::string, std::string>& params,
                   const std::string& key)
{
    const auto found = params.find(key);
    if (found == params.end()) return -1.0;
    bool ok = false;
    const double value = st::parseSuffixValue(found->second, ok);
    return ok ? value : -1.0;
}

bool hasDiag(const st::AutoBiasSolveResult& result, st::DiagCode code)
{
    for (const auto& diagnostic : result.diagnostics) {
        if (diagnostic.code == code) return true;
    }
    return false;
}

bool diagMentions(const st::AutoBiasSolveResult& result,
                  const std::string& needle)
{
    for (const auto& diagnostic : result.diagnostics) {
        if (diagnostic.message.find(needle) != std::string::npos) return true;
    }
    return false;
}

} // namespace

int main()
{
    // First feasible point must stop nominal search, but retain every PVT corner.
    {
        PassingCaptureHost host;
        auto request = makeRequest(false);
        request.pvt_corners = {"ss", "ff"};
        const auto solved = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(solved.ok && solved.pvt_ready && solved.nominal_evaluations == 1 &&
                  solved.pvt_evaluations == 2 && host.calls == 3,
              "First feasible sizing terminates nominal search and checks all PVT corners");
    }
    {
        ScriptedHost host;
        host.script = [](const std::array<bool, 5>& bits) {
            Knobs knobs;
            knobs.converged = bits[0] && bits[1];
            return knobs;
        };
        const auto solved = st::SolveAutoBias(makeDiscreteRequest(), makeDiscreteCatalog(), host);
        CHECK(solved.ok && host.calls > 1,
              "Failed initial sizing continues to coupled-parameter feasible search");
    }
    {
        class NeighborOnlyHost : public st::DcEvaluationHost {
        public:
            bool Evaluate(const st::DcEvaluationRequest& request,
                          st::OperatingPointSnapshot& snapshot,
                          st::Diagnostic&) override {
                const auto candidate = extractCandidate(request, false);
                Knobs knobs;
                knobs.converged = closeTo(candidate.values[0], 2.05e-6);
                snapshot = makeNmosOps(knobs, 50e-6);
                return knobs.converged;
            }
        } host;
        const auto solved = st::SolveAutoBias(makeRequest(false), makeGridCatalog(), host);
        CHECK(solved.ok && solved.nominal_evaluations > 1,
              "Coarse joint budget cannot suppress legal grid-neighbor feasibility search");
    }
    {
        auto request = makeRequest(false);
        request.baseline.subckts.front().instances.front().params["unknown_cdf"] = "1";
        PassingCaptureHost host;
        const auto solved = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!solved.ok && host.calls == 0 &&
                  diagMentions(solved, "unknown_cdf"),
              "Control Replica拒绝未登记原实例CDF参数，并在调用宿主前报告参数名");
    }
    {
        st::DeviceCatalog preciseCatalog;
        st::Diagnostic diagnostic;
        const auto originalCatalog = makeGridCatalog();
        for (const auto& [name, descriptor] : originalCatalog.Descriptors()) {
            auto copy = descriptor;
            if (copy.kind == st::DeviceKind::MosP) {
                copy.parameter_constraints["width"] =
                    makeConstraint("width", "w", 1.234567e-6, 1.2345678e-6, 1e-13);
            }
            preciseCatalog.Add(copy, diagnostic);
        }
        PassingCaptureHost host;
        const auto solved = st::SolveAutoBias(makeRequest(false), preciseCatalog, host);
        const auto* bias = host.first.candidate.find("VBIAS_N_CASCODE_AUTO_M0");
        const auto* mirror = bias == nullptr ? nullptr : bias->find("P_REF");
        const double written = paramValue(mirror, "w");
        CHECK(solved.ok && host.calls > 0 && written >= 1.234567e-6 &&
                  written <= 1.2345678e-6,
              "窄CDF参数域量化后序列化保留足够精度，不能因6位工程格式而越界");
    }
    {
        auto request = makeRequest(false);
        request.baseline.subckts.front().instances.front().params["w"] = "2.01u";
        PassingCaptureHost host;
        const auto solved = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!solved.ok && host.calls == 0 && diagMentions(solved, "w"),
              "原管尺寸不在CDF量化网格时拒绝，不能只改Replica导致与原管不一致");
    }
    {
        auto catalog = makeGridCatalog();
        st::Diagnostic diagnostic;
        for (int index = 1; index <= 256; ++index) {
            catalog.Add(makeMos("z_mirror_" + std::to_string(index),
                st::DeviceKind::MosP, "pdkB_lib"), diagnostic);
        }
        PassingCaptureHost host;
        const auto solved = st::SolveAutoBias(makeRequest(false), catalog, host);
        CHECK(solved.ok && solved.device_combinations == 1 &&
                  solved.nominal_evaluations == 1 && host.calls == 1,
              "Large PDK does not trigger whole-library master combinations or optimization");
        MasterSensitiveHost rejected;
        rejected.accepted_mirror = "z_mirror_256";
        rejected.accepted_resistor = "res_two_term";
        const auto failed = st::SolveAutoBias(makeRequest(false), catalog, rejected);
        CHECK(!failed.ok && rejected.seen_masters.size() == 1 &&
                  diagMentions(failed, "fixed_device_set") &&
                  !diagMentions(failed, "已搜索全部master组合"),
              "Fixed-master search failure does not claim whole-PDK infeasibility");
    }
    // Experimental evidence stays measurable but cannot become strict acceptance.
    {
        FunctionalHost host;
        const auto solved = st::SolveAutoBias(makeRequest(false), makeGridCatalog(), host);
        auto request = solved.electrical_check;
        auto snapshot = makeNmosOps(Knobs{}, 50e-6);
        request.experimental_dc = true;
        request.actual_control.limits.max_abs_vgs = std::numeric_limits<double>::infinity();
        snapshot.resistors.at("R_REF_N").max_voltage = 0.0;
        snapshot.resistors.at("R_REF_N").max_power = 0.0;
        snapshot.resistors.at("R_REF_N").max_current = 0.0;
        snapshot.resistors.at("R_REF_N").rating_source.clear();
        const auto experimental = st::EvaluateElectricalConstraints(snapshot, request);
        CHECK(experimental.ok && !experimental.reliability_verified &&
                  experimental.constraints.count("reliability_vgs") == 0 &&
                  experimental.constraints.count("resistor_stress") == 0 &&
                  !experimental.unverified_constraints.empty() &&
                  experimental.stress_measurements.count("R_REF_N.vgs") == 0 &&
                  experimental.stress_measurements.count("resistor.power") == 1,
              "实验未知MOS/电阻限值保留测量、未知状态及未验证清单");
        request.experimental_dc = false;
        CHECK(!st::EvaluateElectricalConstraints(snapshot, request).ok,
              "相同未知额定值正式门禁拒绝");
        request.experimental_dc = true;
        request.actual_cascode.limits.max_abs_vgs = 0.01;
        CHECK(!st::EvaluateElectricalConstraints(snapshot, request).ok &&
                  !st::EvaluateElectricalConstraints(snapshot, request).constraints.at("reliability_vgs"),
              "其它MOS额定未知不能遮蔽已知越限");
        request.actual_cascode.limits.max_abs_vgs = 1.5;
        snapshot.mos.at("P_REF").intrinsic_vgs = 0.7;
        CHECK(st::EvaluateElectricalConstraints(snapshot, request).first_failed_constraint == "incomplete_snapshot",
              "实验仍拒绝内部电压缺配对");
    }
    {
        const auto sourceCatalog = makeGridCatalog();
        st::DeviceCatalog trials;
        st::Diagnostic diagnostic;
        for (const auto& [master, original] : sourceCatalog.Descriptors()) {
            auto descriptor = original;
            descriptor.native_parameter_trials = true;
            descriptor.reliability_complete = false;
            descriptor.voltage_domain.clear();
            descriptor.allowed_voltage_domains.clear();
            descriptor.limits.max_abs_vgs = std::numeric_limits<double>::infinity();
            descriptor.limits.max_abs_vds = std::numeric_limits<double>::infinity();
            descriptor.limits.max_abs_vgb = std::numeric_limits<double>::infinity();
            for (auto& [name, constraint] : descriptor.parameter_constraints) {
                constraint.discrete_values = name == "width" ? std::vector<double>{2e-6, 4e-6, 8e-6}
                    : name == "length" ? std::vector<double>{2.4e-7, 5e-7, 1e-6}
                    : std::vector<double>{10000, 20000, 30000};
            }
            trials.Add(descriptor, diagnostic);
        }
        auto request = makeRequest(false);
        FunctionalHost strictHost;
        CHECK(!st::SolveAutoBias(request, trials, strictHost).ok && strictHost.calls == 0,
              "有限原生试点元数据不进入正式求解");
        request.template_request.experimental_dc = true;
        PassingCaptureHost experimentHost;
        const std::map<std::string, std::string> unchangedControl{{"w", "2u"}, {"l", "0.24u"}};
        const auto experiment = st::SolveAutoBias(request, trials, experimentHost);
        CHECK(experiment.ok && experiment.native_parameter_trials && !experiment.reliability_verified &&
                  experiment.nominal_evaluations <= 16 &&
                  countTrace(experiment, "\"reliability_vgs\":null") > 0 &&
                  countTrace(experiment, "\"nominal_budget\":16") > 0 &&
                  countTrace(experiment, "\"params_legal\":null") > 0 &&
                  countTrace(experiment, "\"trial_parameters_valid\":true") > 0 &&
                  experiment.sizing.element_parameters.at("N_CTRL_REP_N") ==
                      unchangedControl,
              "原生有限试点实验可求解、未知不为true且原管参数原文保持");
        ScriptedHost failedHost;
        failedHost.script = [](const std::array<bool, 5>&) {
            Knobs knobs;
            knobs.converged = false;
            return knobs;
        };
        const auto failed = st::SolveAutoBias(request, trials, failedHost);
        CHECK(!failed.ok && failedHost.calls == 16 && failed.trace_lines.size() == 16 &&
                  failed.parameter_search_truncated && countTrace(failed, "\"phase\":\"refine\"") == 0,
              "实验不可行时名义16次候选预算且无局部细搜");
    }
    // ================= 1. 同型初值与量化（网格目录） =================
    {
        FunctionalHost host;
        const auto request = makeRequest(false);
        const auto catalog = makeGridCatalog();
        const auto result = st::SolveAutoBias(request, catalog, host);
        CHECK(result.ok, "同型 Cascode 求解成功");
        auto withoutResistor = makeNmosOps(Knobs{}, 50e-6);
        withoutResistor.resistors.clear();
        CHECK(result.electrical_check.resistor.leaf_name == "R_REF_N" &&
              st::EvaluateElectricalConstraints(
                  withoutResistor, result.electrical_check).first_failed_constraint ==
                  "resistor_op_missing",
              "求解后的电气门禁绑定参考电阻，缺OP时拒绝");
        CHECK(closeTo(sizingValue(result.sizing.cascode_parameters, "w"), 2e-6) &&
                  closeTo(sizingValue(result.sizing.cascode_parameters, "l"),
                          2.4e-7),
              "同型初值继承原管等效尺寸且量化在网格上");
        const auto& elements = result.sizing.element_parameters;
        CHECK(closeTo(sizingValue(elements.at("P_REF"), "w"), 1.4e-6) &&
                  closeTo(sizingValue(elements.at("P_REF"), "l"), 6e-7) &&
                  closeTo(sizingValue(elements.at("R_REF_N"), "r"), 1e4),
              "Mirror 初值为几何中点、电阻初值为 sqrt(min*max)，均量化");
        const std::map<std::string, std::string> expectedCtrlParams{
            {"w", "2u"}, {"l", "0.24u"}};
        CHECK(elements.at("N_CTRL_REP_N") == expectedCtrlParams,
              "Control Replica 保留原管实例参数原文");
        CHECK(elements.at("N_CAS_REP_N") == result.sizing.cascode_parameters,
              "Cascode Replica 与新增 Cascode 管同参数");
        const std::array<double, 5> expectedInitial{2e-6, 2.4e-7, 1.4e-6, 6e-7,
                                                    1e4};
        bool firstIsInitial = host.calls > 0 && !host.seen.empty();
        for (std::size_t index = 0; index < 5 && firstIsInitial; ++index) {
            firstIsInitial =
                closeTo(host.seen.front().values[index], expectedInitial[index]);
        }
        CHECK(firstIsInitial, "第一个评估候选恰好是映射初值点");
        CHECK(host.seen.front().has_transformed_target &&
                  host.seen.front().has_cascode &&
                  host.seen.front().has_bias_instance &&
                  host.seen.front().has_no_top_level_bias,
              "DC候选包含真实Cascode改写和核心层VBIAS实例，不是只放顶层模板");
        CHECK(host.seen.front().identity_matches_candidate,
              "DC候选身份的拓扑/参数哈希来自完整候选网表");
        std::set<double> rSeen;
        for (const auto& candidate : host.seen) rSeen.insert(candidate.values[4]);
        CHECK(host.calls == 1 && rSeen.size() == 1 && rSeen.count(1e4),
              "初值满足硬条件时停止，不为更优尺寸继续搜索");
        CHECK(closeTo(result.metrics.branch_current_error, 0.0) &&
                  closeTo(result.sizing.nominal_voltage, 1.2) &&
                  closeTo(result.sizing.iq_delta, 8e-6),
              "最优候选指标：支路电流误差 0、VBIAS 1.2V、IQ 8uA");
        CHECK(host.calls <= 384 &&
                  result.trace_lines.size() == static_cast<std::size_t>(host.calls),
              "宿主评估次数有上界且每次评估都有一行轨迹");

        FunctionalHost hostAgain;
        const auto again = st::SolveAutoBias(request, catalog, hostAgain);
        std::string traceA, traceB;
        for (const auto& line : result.trace_lines) traceA += line + "\n";
        for (const auto& line : again.trace_lines) traceB += line + "\n";
        CHECK(traceA == traceB,
              "相同输入两次运行 solver_trace 字节一致");
    }

    // Case 数值必须进入硬门禁，不能仅用于候选排名。
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.max_vbias_current = 1e-6;
        const auto result = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!result.ok &&
                  countTrace(result, "\"reason\":\"bias_current_limit\"") > 0,
              "新增VBIAS支路电流超过Case限值时不得放行");
    }
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.max_branch_current_error.reset();
        request.max_vbias_current.reset();
        const auto result = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(result.ok && closeTo(result.sizing.nominal_voltage, 1.2) &&
                  closeTo(result.metrics.branch_current_error, 0.0),
              "没有性能Spec时可求出名义DC可行的器件和参数，不填虚构电流上限");
    }
    for (const bool pmos : {false, true}) {
        for (const double branchError : {-1.0, -2.0}) {
            ScriptedHost host;
            host.pmos = pmos;
            host.script = [branchError, pmos](const std::array<bool, 5>&) {
                Knobs knobs;
                knobs.branch_err = branchError;
                if (pmos) knobs.vbias = 0.6;
                return knobs;
            };
            auto request = makeDiscreteRequest(pmos);
            request.max_branch_current_error.reset();
            request.max_vbias_current.reset();
            const auto result = st::SolveAutoBias(request,
                pmos ? makePmosGridCatalog() : makeDiscreteCatalog(), host);
            CHECK(!result.ok &&
                      countTrace(result, "\"reason\":\"branch_direction\"") > 0,
                  "无Spec也拒绝原本导通支路变为零电流或反向电流的N/P候选");
        }
    }
    {
        ScriptedHost host;
        host.script = [](const std::array<bool, 5>&) {
            Knobs knobs;
            knobs.iq = 0.0;
            return knobs;
        };
        auto request = makeDiscreteRequest();
        request.max_branch_current_error.reset();
        request.max_vbias_current.reset();
        const auto result = st::SolveAutoBias(request, makeDiscreteCatalog(), host);
        CHECK(!result.ok &&
                  countTrace(result, "\"reason\":\"bias_conduction\"") > 0,
              "无Spec仍拒绝零电流的VBIAS镜像支路");
    }
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.max_vbias_current.reset();
        const auto result = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!result.ok &&
                  countTrace(result, "\"reason\":\"current_limits_invalid\"") > 0,
              "显式提供电流上限时必须成对提供，不能把残缺配置当无Spec");
    }
    {
        ScriptedHost host;
        host.script = [](const std::array<bool, 5>&) {
            Knobs knobs;
            knobs.branch_err = 0.1;
            return knobs;
        };
        auto request = makeDiscreteRequest();
        request.max_branch_current_error = 0.05;
        const auto result = st::SolveAutoBias(request, makeDiscreteCatalog(), host);
        CHECK(!result.ok &&
                  countTrace(result, "\"reason\":\"branch_current_limit\"") > 0,
              "主支路电流偏差超过Case上限时不得放行");
    }
    {
        ScriptedHost host;
        host.script = [](const std::array<bool, 5>&) {
            Knobs knobs;
            knobs.control_linear = true;
            return knobs;
        };
        auto request = makeDiscreteRequest();
        request.baseline_op.mos["M0"].vdsat = 2.0;
        const auto result = st::SolveAutoBias(request, makeDiscreteCatalog(), host);
        CHECK(result.ok,
              "原控制管基线在线性区时，不机械要求控制管和Replica饱和");
    }

    // ================= 2. 异型初值映射 =================
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.template_request.cascode_master = "cas_nmos";
        const auto catalog = makeGridCatalog();
        const auto result = st::SolveAutoBias(request, catalog, host);
        CHECK(result.ok && !host.seen.empty() &&
                  closeTo(host.seen.front().values[0], 2e-6) &&
                  closeTo(host.seen.front().values[1], 2.4e-7),
              "异型 Cascode 初值按 W/L 映射并量化到目标 master 约束");
        CHECK(host.seen.front().cas_rep_model == "cas_nmos" &&
                  host.seen.front().ctrl_rep_model == "ctl_nmos",
              "异型时 Cascode Replica 用新 master、Control Replica 用原 master");
    }

    // ================= 2A. 固定尺寸 PDK 器件 =================
    {
        PassingCaptureHost host;
        auto request = makeRequest(false);
        request.baseline.subckts.front().instances.front().model = "fixed_nmos";
        request.baseline.subckts.front().instances.front().params.clear();
        request.template_request.control_master = "fixed_nmos";
        request.template_request.cascode_master = "fixed_nmos";
        const auto result =
            st::SolveAutoBias(request, makeFixedGeometryCatalog(), host);
        CHECK(result.ok && host.calls > 0,
              "尺寸编码在 master 名中的固定 MOS 可进入 DC 闭环");
        const auto& elements = result.sizing.element_parameters;
        CHECK(result.ok && result.sizing.cascode_parameters.empty() &&
                  elements.count("P_REF") && elements.at("P_REF").empty() &&
                  elements.count("P_OUT_N") && elements.at("P_OUT_N").empty() &&
                  elements.count("N_CAS_REP_N") &&
                  elements.at("N_CAS_REP_N").empty() &&
                  elements.count("N_CTRL_REP_N") &&
                  elements.at("N_CTRL_REP_N").empty(),
              "固定几何 MOS 不伪造 W/L/NFIN CDF 参数");
        CHECK(result.ok && elements.count("R_REF_N") &&
                  closeTo(sizingValue(elements.at("R_REF_N"), "r"), 1e4),
              "固定 MOS 时仍使用 PDK 允许的参考电阻中值");
    }

    // ================= 2B. FinFET nfin/l 参数域 =================
    {
        PassingCaptureHost host;
        auto request = makeRequest(false);
        auto& target = request.baseline.subckts.front().instances.front();
        target.model = "fin_nmos";
        target.params = {{"nfin", "4"}, {"l", "180n"}};
        request.template_request.control_master = "fin_nmos";
        request.template_request.cascode_master = "fin_nmos";
        const auto result = st::SolveAutoBias(request, makeFinfetCatalog(), host);
        CHECK(result.ok && host.calls > 0,
              "FinFET 可按实际 nfin/l/r 参数域进入 DC 闭环");
        const st::Subckt* firstTemplate =
            host.first.candidate.find("VBIAS_N_CASCODE_AUTO_M0");
        const st::Instance* firstCascodeReplica = firstTemplate == nullptr
            ? nullptr : firstTemplate->find("N_CAS_REP_N");
        CHECK(result.ok && firstCascodeReplica != nullptr &&
                  closeTo(paramValue(firstCascodeReplica, "nfin"), 4.0) &&
                  closeTo(paramValue(firstCascodeReplica, "l"), 1.8e-7),
              "Cascode 初值按语义继承原 FinFET 的 nfin/l");
        CHECK(result.ok && result.sizing.cascode_parameters.count("w") == 0 &&
                  result.sizing.element_parameters.count("P_REF") &&
                  result.sizing.element_parameters.at("P_REF").count("w") == 0 &&
                  result.sizing.element_parameters.at("P_REF").count("nfin") == 1,
              "FinFET 候选只写 PDK 实际声明的 CDF 名，不伪造 w");
    }

    // ================= 2C. 显式 multiplier 参数域 =================
    {
        PassingCaptureHost host;
        auto request = makeRequest(false);
        auto& target = request.baseline.subckts.front().instances.front();
        target.model = "multi_nmos";
        target.params = {{"m", "2"}};
        request.template_request.control_master = "multi_nmos";
        request.template_request.cascode_master = "multi_nmos";
        const auto result =
            st::SolveAutoBias(request, makeMultiplierCatalog(), host);
        CHECK(result.ok && host.calls > 0 &&
                  result.sizing.cascode_parameters.count("m") == 1 &&
                  closeTo(sizingValue(result.sizing.cascode_parameters, "m"),
                          2.0),
              "PDK 显式声明的 multiplier 可从原管继承并写入 CDF m");
        CHECK(result.ok &&
                  result.sizing.cascode_parameters.count("w") == 0 &&
                  result.sizing.cascode_parameters.count("nf") == 0,
              "multiplier 不会被误当成 width 或 fingers");
    }

    // Feasible sizing is accepted even when later points could improve diagnostics.
    {
        ScriptedHost host;
        host.script = [](const std::array<bool, 5>& bits) {
            Knobs knobs;
            knobs.branch_err = bits[4] ? 0.0 : 0.1;
            knobs.iq = bits[4] ? 1e-6 : 8e-6;
            return knobs;
        };
        const auto result = st::SolveAutoBias(makeDiscreteRequest(), makeDiscreteCatalog(), host);
        CHECK(result.ok && host.calls == 1 &&
                  closeTo(result.metrics.branch_current_error, 0.1) &&
                  closeTo(sizingValue(result.sizing.element_parameters.at("R_REF_N"), "r"), 100.0),
              "First feasible point retained without power, area or parameter ranking");
    }

    {
        PassingCaptureHost host;
        const auto solved = st::SolveAutoBias(makeRequest(false), makeGridCatalog(), host);
        auto request = solved.electrical_check;
        auto snapshot = makeNmosOps(Knobs{}, 50e-6);
        auto& cas = snapshot.mos.at("M0_CAS");
        cas.intrinsic_vgs = cas.vgs;
        cas.intrinsic_vds = 0.01;
        CHECK(!st::EvaluateElectricalConstraints(snapshot, request).constraints.at("saturation"),
              "external headroom cannot hide intrinsic unsaturation");
        cas.intrinsic_vds = 0.5;
        cas.vgs = 2.0;
        CHECK(!st::EvaluateElectricalConstraints(snapshot, request).constraints.at("reliability_vgs"),
              "intrinsic voltage cannot hide terminal overvoltage");
        cas.vgs = *cas.intrinsic_vgs;
        cas.intrinsic_vgs.reset();
        CHECK(!st::EvaluateElectricalConstraints(snapshot, request).constraints.at("complete"),
              "partial intrinsic pair cannot fall back to terminal voltage");
        cas.intrinsic_vgs = cas.vgs;
        request.baseline_control.intrinsic_vgs = request.baseline_control.vgs;
        request.baseline_control.intrinsic_vds = 0.01;
        snapshot.mos.at("M0").vdsat = 2.0;
        snapshot.mos.at("N_CTRL_REP_N").vdsat = 2.0;
        CHECK(st::EvaluateElectricalConstraints(snapshot, request).constraints.at("saturation"),
              "baseline linear control classification uses intrinsic voltage too");
    }

    // ================= 4. 硬约束剔除与无解证据 =================
    struct RejectionCase {
        std::string name;
        Knobs knobs;
        std::string reason;
    };
    Knobs overvoltage; overvoltage.rel_margin = -0.1; // |VGS|=1.6 > 1.5
    Knobs linear; linear.sat_margin = -0.5;           // |VDS| < |VDSAT|
    Knobs outOfRange; outOfRange.vbias = -0.1;        // VBIAS < VS_ORIG=0.3
    Knobs notConverged; notConverged.converged = false;
    Knobs incomplete; incomplete.complete = false;
    Knobs actualOvervoltage; actualOvervoltage.actual_overvoltage = true;
    const std::vector<RejectionCase> rejections = {
        {"过压", overvoltage, "reliability_vgs"},
        {"线性区", linear, "saturation"},
        {"VBIAS 越域并导致镜像过压", outOfRange, "reliability_vds"},
        {"不收敛", notConverged, "not_converged"},
        {"快照不完整", incomplete, "incomplete_snapshot"},
        {"主支路Cascode过压", actualOvervoltage, "reliability_vgs"},
    };
    for (const auto& rejection : rejections) {
        ScriptedHost host;
        const Knobs knobs = rejection.knobs;
        host.script = [knobs](const std::array<bool, 5>&) { return knobs; };
        const auto result =
            st::SolveAutoBias(makeDiscreteRequest(), makeDiscreteCatalog(), host);
        CHECK(!result.ok, rejection.name + "：所有候选被剔除时求解失败");
        CHECK(host.calls == 32 && result.trace_lines.size() == 32 &&
                  countTrace(result, "\"kept\":false") == 32 &&
                  countTrace(result, "\"selected\":true") == 0,
              rejection.name + "：轨迹保留全部 32 个离散被拒候选且无入选");
        CHECK(closeTo(sizingValue(result.sizing.element_parameters.at("R_REF_N"),
                                  "r"),
                      1e6),
              rejection.name + "：无解时返回最后评估候选的参数");
        CHECK(diagMentions(result, rejection.reason),
              rejection.name + "：诊断逐项给出淘汰原因 " + rejection.reason);
    }

    // ================= 5. 输入缺失快速失败 =================
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.baseline_op.mos.clear();
        const auto result =
            st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!result.ok && host.calls == 0 &&
                  hasDiag(result, st::DiagCode::MissingInput),
              "基线快照缺目标实例时零评估拒绝（MissingInput）");
    }
    {
        FunctionalHost host;
        auto request = makeRequest(false);
        request.baseline.subckts.front().instances.clear();
        const auto result =
            st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(!result.ok && host.calls == 0 &&
                  hasDiag(result, st::DiagCode::NotFound),
              "基线网表缺目标实例时零评估拒绝（NotFound）");
    }

    // ================= 6. PMOS 模板冒烟与确定性 =================
    {
        FunctionalHost host;
        host.pmos = true;
        const auto result =
            st::SolveAutoBias(makeRequest(true), makePmosGridCatalog(), host);
        CHECK(result.ok, "PMOS 自给电模板求解成功");
        CHECK(!host.seen.empty() &&
                  host.seen.front().template_id == "VBIAS_P_CASCODE_AUTO" &&
                  host.seen.front().cas_rep_model == "ctl_pmos" &&
                  closeTo(host.seen.front().values[0], 4e-6) &&
                  closeTo(host.seen.front().values[1], 5e-7),
              "PMOS 模板身份正确且初值继承原管等效尺寸");
        CHECK(host.calls <= 384 &&
                  result.trace_lines.size() == static_cast<std::size_t>(host.calls),
              "PMOS 求解评估次数有界且轨迹完整");
        FunctionalHost hostAgain;
        hostAgain.pmos = true;
        const auto again =
            st::SolveAutoBias(makeRequest(true), makePmosGridCatalog(), hostAgain);
        std::string traceA, traceB;
        for (const auto& line : result.trace_lines) traceA += line + "\n";
        for (const auto& line : again.trace_lines) traceB += line + "\n";
        CHECK(traceA == traceB, "PMOS 两次运行轨迹字节一致");
    }

    // ================= 7. PVT 固定参数逐 Corner 复验 =================
    {
        // 名义 tt 通过、ss 过压：名义解仍有效，pvt_ready=false 并指明 corner 与约束
        class CornerSensitiveHost : public st::DcEvaluationHost {
        public:
            int calls = 0;
            bool ssFails = true;
            bool Evaluate(const st::DcEvaluationRequest& request,
                          st::OperatingPointSnapshot& snapshot,
                          st::Diagnostic&) override
            {
                ++calls;
                Knobs knobs;
                if (request.identity.corner == "ss" && ssFails) {
                    knobs.rel_margin = -0.1; // |VGS|=1.6 > 1.5 过压
                }
                snapshot = makeNmosOps(knobs, 50e-6);
                return true;
            }
        };
        CornerSensitiveHost host;
        auto request = makeRequest(false);
        request.pvt_corners = {"ss"};
        const auto result = st::SolveAutoBias(request, makeGridCatalog(), host);
        CHECK(result.ok, "PVT：名义Corner求解成功，不受ss复验失败影响");
        CHECK(!result.pvt_ready && result.pvt_results.size() == 1 &&
                  result.pvt_results.front().corner == "ss" &&
                  !result.pvt_results.front().ok &&
                  result.pvt_results.front().failed_constraint ==
                      "reliability_vgs",
              "PVT：ss过压时pvt_ready=false，报告指明corner=ss与失败约束");
        CHECK(countTrace(result, "\"corner\":\"ss\"") == 1 &&
                  countTrace(result, "\"selected\":true") == 1 &&
                  result.trace_lines.size() == static_cast<std::size_t>(host.calls),
              "PVT：复验追加轨迹行、每Corner恰好一次宿主评估、不重选尺寸");

        CornerSensitiveHost passHost;
        passHost.ssFails = false;
        const auto passResult =
            st::SolveAutoBias(request, makeGridCatalog(), passHost);
        CHECK(passResult.ok && passResult.pvt_ready &&
                  passResult.pvt_results.size() == 1 &&
                  passResult.pvt_results.front().ok &&
                  passResult.pvt_results.front().failed_constraint.empty(),
              "PVT：全部Corner通过时pvt_ready=true");

        FunctionalHost noPvtHost;
        const auto noPvtRequest = makeRequest(false);
        const auto noPvt =
            st::SolveAutoBias(noPvtRequest, makeGridCatalog(), noPvtHost);
        CHECK(noPvt.ok && !noPvt.pvt_ready && noPvt.pvt_results.empty(),
              "PVT：未配置pvt_corners时pvt_ready=false且无复验记录");
    }

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "DC solver tests passed\n";
    } else {
        std::cout << failures << " DC solver tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
