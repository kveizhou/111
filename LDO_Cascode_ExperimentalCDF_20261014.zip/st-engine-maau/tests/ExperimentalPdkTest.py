import copy
import csv
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'server/site'))
from standalone_pdk import build_metadata
from site_data import skill_metadata


class ExperimentalPdkTest(unittest.TestCase):
    def fixture(self, root):
        probe = root / 'probe.tsv'
        fields = ['oa_library', 'oa_cell', 'oa_view', 'model_name', 'terminal_names',
                  'parameter', 'units', 'min', 'max', 'default_value', 'has_schematic']
        with probe.open('w') as out:
            writer = csv.writer(out, delimiter='\t', lineterminator='\n')
            writer.writerow(fields)
            for parameter, unit, value in [('l', 'lengthMetric', '134n'), ('nfin', '', '4'), ('m', '', '1')]:
                writer.writerow(['PDK', 'opaque', 'symbol', 'actual_model', 'D,G,S,B', parameter,
                                 unit, '', '', value, 'false'])
        native = root / 'native_records.json'
        native.write_text(json.dumps([dict(kind='cdf_value', scope='M0', name=k, status='OK', raw_value=json.dumps(v))
                                     for k, v in dict(l='140n', nfin='6', m='2', model='actual_model').items()] +
                                    [dict(kind='source', scope='M0', name=k, status='OK', raw_value=json.dumps(v))
                                     for k, v in dict(oa_library='PDK', oa_cell='opaque').items()]))
        profile = dict(validation_scope='experimental_dc', experimental_parameter_seeds={
            'PDK/opaque': dict(instance='M0', native_records=str(native),
                              native_records_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),
                              trials={'fin': [5, 6, 7]})})
        rules = dict(source='PDK connectivity and model evidence', devices={'PDK/opaque': dict(
            kind='mos_n', normalized_to_cdf={'length': 'l', 'fin': 'nfin', 'multiplier': 'm'},
            terminalRoles={'D': 'drain', 'G': 'gate', 'S': 'source', 'B': 'bulk'}, bulkRule='isolated_well')})
        return probe, native, profile, rules

    def test_trial_metadata_uses_actual_seeds_and_never_scans_model_tree(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            with patch('standalone_pdk.model_paths', side_effect=AssertionError('full PDK scan')):
                data = build_metadata(root, probe, profile, rules)
            dev = data['devices'][0]
            self.assertTrue(dev['native_parameter_trials'])
            self.assertEqual(dev['constraints']['length']['allowed'], [140e-9])
            self.assertEqual(dev['constraints']['multiplier']['allowed'], [2.0])
            self.assertEqual(dev['constraints']['fin']['allowed'], [6.0, 5.0, 7.0])
            self.assertEqual(dev['constraints']['fin']['min'], 5)
            self.assertEqual(dev['constraints']['fin']['max'], 7)
            self.assertFalse(data['parameter_domain_verified'])
            self.assertEqual(skill_metadata(data)['devices']['PDK/opaque']['nativeParameterTrials'], True)
            self.assertIn(str(native.resolve()), data['source_file_sha256'])
            self.assertNotIn('maxAbsVgs', dev)

    def test_actual_seed_required_even_with_cdf_defaults(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            native.write_text('[]')
            profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
            with self.assertRaisesRegex(ValueError, 'actual.*seed'):
                build_metadata(root, probe, profile, rules)

    def test_known_explicit_and_one_sided_cdf_bound_reject_trials(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            rules['devices']['PDK/opaque']['constraints'] = {'fin': {'min': 4, 'max': 6}}
            with self.assertRaisesRegex(ValueError, 'known.*bound'):
                build_metadata(root, probe, profile, rules)
            rules['devices']['PDK/opaque'].pop('constraints')
            probe.write_text(probe.read_text().replace('nfin\t\t\t\t4', 'nfin\t\t\t6\t4'))
            with self.assertRaisesRegex(ValueError, 'known.*bound'):
                build_metadata(root, probe, profile, rules)

    def test_proven_polarity_pin_mapping_and_body_are_mandatory(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            for key in ('kind', 'terminalRoles', 'bulkRule'):
                invalid = copy.deepcopy(rules); invalid['devices']['PDK/opaque'].pop(key)
                with self.assertRaises(ValueError):
                    build_metadata(root, probe, profile, invalid)

    def test_bulk_strategy_only_accepts_supported_explicit_template_conventions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            rule = rules['devices']['PDK/opaque']
            for kind in ('mos_n', 'mos_p'):
                rule['kind'] = kind
                for strategy in ('ground', 'my_custom_body', 'tied_to_source', 'fixed_rail'):
                    rule['bulkRule'] = strategy
                    with self.assertRaisesRegex(ValueError, 'supported Bulk strategy'):
                        build_metadata(root, probe, profile, rules)
                for strategy in ('rail', 'isolated_well'):
                    rule['bulkRule'] = strategy
                    self.assertEqual(build_metadata(root, probe, profile, rules)['devices'][0]['bulkRule'], strategy)

    def test_strict_pipeline_rejects_trial_configuration_and_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            data = build_metadata(root, probe, profile, rules)
            data['validation_scope'] = 'dc_operating_point'
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                skill_metadata(data)
            profile['validation_scope'] = 'dc_operating_point'
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                build_metadata(root, probe, profile, rules)

    def test_seed_drift_duplicate_records_and_nonfinite_trial_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            original = native.read_text(); native.write_text(original + '\n')
            with self.assertRaisesRegex(ValueError, 'changed'):
                build_metadata(root, probe, profile, rules)
            native.write_text(original)
            profile['experimental_parameter_seeds']['PDK/opaque']['trials']['fin'] = [float('nan')]
            with self.assertRaises(ValueError):
                build_metadata(root, probe, profile, rules)

    def test_native_length_suffix_without_units_and_frozen_zero_property(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            probe.write_text(probe.read_text().replace('lengthMetric', '') +
                             'PDK\topaque\tsymbol\tactual_model\tD,G,S,B\tdiffColor\t\t\t\t1\tfalse\n')
            records = json.loads(native.read_text())
            records.append(dict(kind='cdf_value', scope='M0', name='diffColor', status='OK', raw_value='0'))
            native.write_text(json.dumps(records))
            profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
            dev = build_metadata(root, probe, profile, rules)['devices'][0]
            self.assertEqual(dev['constraints']['length']['allowed'], [140e-9])
            self.assertEqual(dev['constraints']['cdf_diffColor']['allowed'], [0])

    def test_cached_inspect_prepares_inputs_without_native_discovery_or_probe(self):
        import standalone
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            source = dict(lib='design', cell='core', view='schematic')
            profile.update(nominal_corner='tt', op_corners={'tt': {'temperature': 27, 'models': []}},
                           experimental_pdk_cache=dict(probe=str(probe), probe_sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),
                                                       pdk_roots=[str(root)], source_dut=source))
            profile_path = root/'profile.json'; profile_path.write_text(json.dumps(profile))
            rules_path = root/'rules.json'; rules_path.write_text(json.dumps(rules))
            args = ['standalone.py', 'inspect', '--validation-scope', 'experimental_dc', '--simulation-profile', str(profile_path),
                    '--pdk-rules', str(rules_path), '--work-dir', str(root/'new-session'), '--backend', '/must-not-run',
                    '--cds-lib', str(root/'cds.lib'), '--lib', 'design', '--cell', 'core',
                    '--bench-lib', 'design', '--bench-cell', 'bench']
            with patch.object(sys, 'argv', args), patch('standalone.subprocess.run', return_value=SimpleNamespace(returncode=0)) as run:
                self.assertEqual(standalone.main(), 0)
            self.assertEqual(run.call_count, 1)
            self.assertEqual(run.call_args.args[0][1], 'inspect')
            metadata = json.loads((root/'new-session/analysis/standalone_inputs/pdk_metadata.json').read_text())
            self.assertEqual(metadata[0]['validation_scope'], 'experimental_dc')

    def test_op_provider_rejects_trial_catalog_in_strict_profile(self):
        from op_provider import load_scanned_catalog
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            tech = build_metadata(root, probe, profile, rules)
            catalog = root/'catalog.tsv'
            catalog.write_text('model_name\tpdk_version\toa_library\toa_cell\tkind\tterminal_names\tterminal_roles\tmaster\tnative_parameter_trials\n'
                'actual_model\t'+tech['version']+'\tPDK\topaque\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\toa_PDK__opaque\ttrue\n')
            with self.assertRaisesRegex(ValueError, 'trial.*experimental_dc'):
                load_scanned_catalog(catalog, tech, tech['version'])
            self.assertIn('actual_model', load_scanned_catalog(catalog, tech, tech['version'], 'experimental_dc'))

    def test_native_master_binding_and_duplicate_values_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); probe, native, profile, rules = self.fixture(root)
            records = json.loads(native.read_text())
            for mutated in (records + [records[0]], [dict(r, raw_value='"wrong"') if r['name'] == 'oa_cell' else r for r in records]):
                native.write_text(json.dumps(mutated))
                profile['experimental_parameter_seeds']['PDK/opaque']['native_records_sha256'] = hashlib.sha256(native.read_bytes()).hexdigest()
                with self.assertRaisesRegex(ValueError, 'actual instance seed'):
                    build_metadata(root, probe, profile, rules)


if __name__ == '__main__':
    unittest.main()
