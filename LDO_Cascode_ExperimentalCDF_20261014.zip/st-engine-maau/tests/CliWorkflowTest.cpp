#include "st/Cli.h"
#include "st/Netlist.h"
#include "st/Standalone.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                          \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                          \
        }                                                                        \
    } while (false)

std::string option(const std::vector<std::string>& arguments, const std::string& name)
{
    for (std::size_t index = 0; index + 1 < arguments.size(); ++index) {
        if (arguments[index] == name) return arguments[index + 1];
    }
    return {};
}

std::string readText(const std::filesystem::path& path)
{
    std::ifstream input(path);
    return std::string((std::istreambuf_iterator<char>(input)),
                       std::istreambuf_iterator<char>());
}

std::size_t nonEmptyLines(const std::filesystem::path& path)
{
    std::ifstream input(path);
    std::size_t count = 0;
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty()) ++count;
    }
    return count;
}

const char* kCatalogTsv =
    "master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\tcompatible_masters\tnormalized_to_cdf\tmin_width\tmax_width\tmin_length\tmax_length\tmin_resistance\tmax_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\tpdk_name\tpdk_version\tmodel_name\tw_fin_formula\tparameter_constraints\tmodel_sections\tcorners\treliability_complete\tbulk_rule_complete\tprocess_identity\tkind_source\tterminal_source\tcdf_source\treliability_source\tbulk_source\tdomain_source\tcorner_source\tdevice_proof_source\n"
    "nsvt\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tnsvt\tsymbol\tcore\t\twidth:w,length:l\t1e-7\t1e-3\t1e-7\t1e-5\t0\tinf\t1.2\t1.2\t1.2\t100\tPDK\t1.0\tnsvt\t\twidth:w:1e-7:1e-3:1e-8:;length:l:1e-7:1e-5:1e-8:\ttt\tff\ttrue\ttrue\tPDK\tsite_pdk_metadata\toa_symbol\tcdf\tpdk_reliability\tpdk_bulk_rule\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n"
    "psvt\tmos_p\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tpsvt\tsymbol\tcore\t\twidth:w,length:l\t1e-7\t1e-3\t1e-7\t1e-5\t0\tinf\t1.2\t1.2\t1.2\t100\tPDK\t1.0\tpsvt\t\twidth:w:1e-7:1e-3:1e-8:;length:l:1e-7:1e-5:1e-8:\ttt\tff\ttrue\ttrue\tPDK\tsite_pdk_metadata\toa_symbol\tcdf\tpdk_reliability\tpdk_bulk_rule\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n"
    "r2\tresistor\tP,N\tpositive,negative\tPDK\tr2\tsymbol\tcore\t\tresistance:r\t0\tinf\t0\tinf\t1\t1e9\t1.2\t1.2\t1.2\t0\tPDK\t1.0\tr2\t\tresistance:r:1:1e9:1:\ttt\tff\ttrue\ttrue\tPDK\tsite_pdk_metadata\toa_symbol\tcdf\tpdk_reliability\tpdk_bulk_rule\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n";

class WorkflowRunner : public st::standalone::ProcessRunner {
public:
    std::vector<std::string> verbs;
    std::string snapshotPolicy;
    bool roundtripUsesPolicy = true;
    bool failSolve = false;
    bool failPvt = false;
    bool failFinalNominal = false;
    bool failFinalBiasCurrent = false;
    bool failFinalResistor = false;
    bool failPvtResistor = false;
    bool omitResistorOp = false;
    bool staleSnapshotCatalog = false;
    bool driftScanCatalog = false;
    std::string candidateRoundtripFault;
    std::filesystem::path lastCandidateDirectory;
    std::string scanCatalogOverride;
    std::string snapshotOverride;
    bool failStructureReadback = false;
    bool structureResistorDefaults = false;
    bool unknownResistorRatings = false;
    bool failSelectedMos = false;
    bool omitSelectedMos = false;
    std::string openedLibrary;
    std::string openedCell;
    bool scopeForwarded = true;

    st::standalone::ProcessResult Run(const std::vector<std::string>& arguments,
                                      const std::filesystem::path& logPath) override
    {
        const auto verb = arguments.size() > 1 ? arguments[1] : "";
        verbs.push_back(verb);
        if (unknownResistorRatings) scopeForwarded = scopeForwarded && option(arguments, "--validation-scope") == "experimental_dc";
        if (verb == "open") { openedLibrary = option(arguments, "--lib"); openedCell = option(arguments, "--cell"); }
        std::filesystem::create_directories(logPath.parent_path());
        std::ofstream(logPath) << "ok\n";
        if (verb == "snapshot") {
            snapshotPolicy = readText(option(arguments, "--device-policy"));
            const auto netlist = option(arguments, "--netlist-output");
            const auto catalog = option(arguments, "--catalog-output");
            const auto geometry = option(arguments, "--geometry-output");
            std::filesystem::create_directories(std::filesystem::path(netlist).parent_path());
            std::ofstream(netlist)
                << (snapshotOverride.empty() ? std::string("subckt ldo_core OUT CTRL AVDD VSS IREF_P\n"
                   "M0 (OUT CTRL VSS VSS) nsvt w=2u l=240n\n"
                   "ends ldo_core\n") : snapshotOverride);
            if (staleSnapshotCatalog) {
                std::string stale = kCatalogTsv;
                const auto marker = stale.find("1.2\t1.2\t1.2\t100\tPDK\t1.0");
                if (marker != std::string::npos) stale.replace(marker, 3, "1.1");
                std::ofstream(catalog) << stale;
            } else {
                std::ofstream(catalog) << kCatalogTsv;
            }
            std::ofstream(geometry) << "instance\tx\ty\nM0\t10\t20\n";
            if (!snapshotOverride.empty()) std::ofstream(geometry, std::ios::app) << "M1\t30\t20\n";
        } else if (verb == "scan-pdk") {
            const auto catalog = option(arguments, "--catalog-output");
            const auto identity = option(arguments, "--identity-output");
            std::filesystem::create_directories(std::filesystem::path(catalog).parent_path());
            std::filesystem::create_directories(std::filesystem::path(identity).parent_path());
            if (driftScanCatalog) {
                std::string drift = kCatalogTsv;
                const auto marker = drift.find("1.2\t1.2\t1.2\t100\tPDK\t1.0");
                if (marker != std::string::npos) drift.replace(marker, 3, "1.1");
                std::ofstream(catalog) << drift;
            } else {
                std::ofstream(catalog) <<
                    (scanCatalogOverride.empty() ? kCatalogTsv : scanCatalogOverride);
            }
            const bool otherPdk =
                !scanCatalogOverride.empty() &&
                scanCatalogOverride.find("\tALT\t") != std::string::npos;
            std::ofstream(identity)
                << "source_library\tprocess_identity\tidentity_source\tcontext_complete\t"
                   "model_context_complete\tpdk_name\tpdk_version\tscan_complete\t"
                   "diagnostic\tcandidate_libraries\n"
                << "SRC\t" << (otherPdk ? "ALT" : "PDK")
                << "\ttech_attachment\ttrue\ttrue\t"
                << (otherPdk ? "ALT" : "PDK")
                << "\t1.0\ttrue\t\t" << (otherPdk ? "ALT" : "PDK") << "\n";
        } else if (verb == "run-op") {
            const auto identity = option(arguments, "--identity-output");
            const auto mos = option(arguments, "--mos-output");
            std::filesystem::create_directories(std::filesystem::path(identity).parent_path());
            std::filesystem::create_directories(std::filesystem::path(mos).parent_path());
            const auto storage =
                std::filesystem::path(option(arguments, "--cds-lib")).parent_path().string();
            (void)storage;
            std::ofstream(identity)
                << "dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\t"
                   "parameter_hash\tsolver_version\ttotal_supply_current\n"
                << option(arguments, "--dut-hash") << '\t'
                << option(arguments, "--bench-hash") << '\t'
                << option(arguments, "--pdk-version") << '\t'
                << option(arguments, "--corner") << '\t'
                << option(arguments, "--topology-hash") << '\t'
                << option(arguments, "--parameter-hash") << '\t'
                << option(arguments, "--solver-version") << "\t1.1e-4\n";
            // 数值满足九项硬约束：可靠性限值1.2、|vds|>=|vdsat|、
            // Replica支路电流一致、VBIAS落在[VS_ORIG, VHIGH]区间。
            std::ofstream(mos)
                << "instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\n"
                << "M0\t1.0\t0.6\t0\t0\t1e-4\t0.6\t1.0\t0\t0.4\t0.2\t1e-15\n"
                << "P_REF\t0.8\t0.8\t1.8\t1.8\t-5e-6\t-1.0\t-1.0\t0\t-0.4\t-0.25\t1e-15\n"
                << "P_OUT_N\t0.81\t0.8\t1.8\t1.8\t-5e-6\t-1.0\t-0.99\t0\t-0.4\t-0.25\t1e-15\n";
            const bool finalStaging =
                option(arguments, "--dut-cell").find("__STAGING") !=
                std::string::npos;
            const bool violate = failSolve ||
                (failFinalNominal && finalStaging &&
                 option(arguments, "--corner") == "tt") ||
                (failPvt && option(arguments, "--corner") == "ss");
            if (violate) {
                std::ofstream(mos, std::ios::app)
                    << "N_CAS_REP_N\t0.81\t0.81\t0.3\t0\t1e-4\t5.0\t0.51\t0\t0.4\t0.2\t1e-15\n"
                    << "N_CTRL_REP_N\t0.3\t0.6\t0\t0\t1e-4\t5.0\t0.3\t0\t0.4\t0.2\t1e-15\n"
                    << "M0_CAS\t1.0\t1.9\t0.3\t0\t1e-4\t1.6\t0.7\t0\t0.4\t0.2\t1e-15\n";
            } else {
                std::ofstream(mos, std::ios::app)
                    << "N_CAS_REP_N\t0.81\t0.81\t0.3\t0\t1e-4\t0.51\t0.51\t0\t0.4\t0.2\t1e-15\n"
                    << "N_CTRL_REP_N\t0.3\t0.6\t0\t0\t1e-4\t0.6\t0.3\t0\t0.4\t0.2\t1e-15\n"
                    << "M0_CAS\t1.0\t0.81\t0.3\t0\t1e-4\t0.51\t0.7\t0\t0.4\t0.2\t1e-15\n";
            }
            if ((failSelectedMos || omitSelectedMos) && finalStaging) {
                auto text = readText(mos);
                const auto start = text.find("M0\t");
                const auto end = text.find('\n', start);
                text.replace(start, end - start + 1, omitSelectedMos ? "" :
                    "M0\t2.0\t0.6\t0\t0\t1e-4\t0.6\t2.0\t0\t0.4\t0.2\t1e-15\n");
                std::ofstream(mos) << text;
            }
            if (failFinalBiasCurrent && finalStaging) {
                std::string opText = readText(mos);
                std::size_t from = 0;
                for (int index = 0; index < 2; ++index) {
                    const auto found = opText.find("-5e-6", from);
                    if (found == std::string::npos) break;
                    opText.replace(found, 5, "-25e-6");
                    from = found + 6;
                }
                std::ofstream(mos, std::ios::trunc) << opText;
            }
            const auto resistor = option(arguments, "--resistor-output");
            if (!resistor.empty() && !omitResistorOp) {
                const bool resistorOverVoltage =
                    (failFinalResistor && finalStaging) ||
                    (failPvtResistor && option(arguments, "--corner") == "ss");
                if (unknownResistorRatings) {
                    std::ofstream(resistor) << "instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\tmax_voltage\tmax_power\tmax_current\trating_source\n"
                        << "I_VBIAS_N_M0.R_REF_N\tr2\tr=10k\t1.0\t0\t5e-6\tNA\tNA\tNA\t-\n"
                        << "M0.M0_RS\tr2\tr=1k\t1.0\t0\t1e-4\tNA\tNA\tNA\t-\n";
                } else std::ofstream(resistor)
                    << "instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\t"
                       "max_voltage\tmax_power\tmax_current\trating_source\n"
                    << "I_VBIAS_N_M0.R_REF_N\tr2\tr=10k\t1.0\t0\t5e-6\t"
                    << (resistorOverVoltage ? "0.5" : "1.5")
                    << "\t1e-4\t0\tfake-pdk/tt\n"
                    << "M0.M0_RS\tr2\tr=1k\t1.0\t0\t1e-4\t"
                    << (resistorOverVoltage ? "0.5" : "1.5")
                    << "\t2e-4\t0\tfake-pdk/tt\n";
            }
        } else if (verb == "netlist") {
            roundtripUsesPolicy = roundtripUsesPolicy &&
                !option(arguments, "--device-policy").empty() &&
                readText(option(arguments, "--device-policy")) == snapshotPolicy;
            const auto output = option(arguments, "--output");
            const auto root = std::filesystem::path(output).parent_path().parent_path();
            const bool candidate = output.find("/analysis/candidates/") !=
                std::string::npos;
            if (candidate) lastCandidateDirectory = root;
            std::filesystem::create_directories(std::filesystem::path(output).parent_path());
            if (option(arguments, "--lib") == "SRC") {
                std::ifstream input(root / "before/core_before.scs");
                std::ofstream(output) << input.rdbuf();
            } else {
                std::ifstream input(root / "expected/core_expected.scs");
                const std::string text((std::istreambuf_iterator<char>(input)),
                                       std::istreambuf_iterator<char>());
                std::vector<st::Diagnostic> diagnostics;
                auto expected = st::parseSpectre(text, diagnostics);
                const auto logicalSubckt = option(arguments, "--core-subckt");
                expected.subckts.erase(
                    std::remove_if(expected.subckts.begin(), expected.subckts.end(),
                        [&](const st::Subckt& subckt) {
                            return subckt.name != logicalSubckt;
                        }),
                    expected.subckts.end());
                const bool parent = logicalSubckt == "ldo_core";
                if (structureResistorDefaults && !parent) {
                    for (auto& subckt : expected.subckts) {
                        for (auto& instance : subckt.instances) {
                            if (instance.model == "r2") instance.params["segL"] = "2u";
                        }
                    }
                }
                if (failStructureReadback && parent && !expected.subckts.empty() &&
                    !expected.subckts.front().instances.empty()) {
                    expected.subckts.front().instances.front().nets.front() = "BROKEN_NET";
                }
                if (candidate && candidateRoundtripFault == "missing_child" &&
                    !parent) {
                    return {1, "injected missing candidate child"};
                }
                if (candidate && !expected.subckts.empty()) {
                    auto& subckt = expected.subckts.front();
                    if (candidateRoundtripFault == "parent_connection" &&
                        parent && !subckt.instances.empty()) {
                        subckt.instances.front().nets.front() = "BROKEN_NET";
                    } else if (candidateRoundtripFault == "child_parameter" &&
                               !parent && !subckt.instances.empty()) {
                        subckt.instances.front().params["w"] = "999u";
                    } else if (candidateRoundtripFault == "child_extra_subckt" &&
                               !parent) {
                        st::Subckt extra;
                        extra.name = "UNPLANNED_CHILD";
                        expected.subckts.push_back(extra);
                    } else if (candidateRoundtripFault == "child_directive" &&
                               !parent) {
                        expected.preamble.push_back("parameters UNPLANNED=1");
                    }
                }
                std::ofstream(output) << st::emitSpectre(expected);
            }
        }
        return {0, {}};
    }
};

void inspectArgs(std::vector<std::string>& arguments, const std::filesystem::path& root,
                 const std::filesystem::path& workDir)
{
    arguments = {"inspect", "--backend", "/opt/site/backend",
        "--cds-lib", (root / "cds.lib").string(),
        "--lib", "SRC", "--cell", "ldo_core", "--view", "schematic",
        "--core-subckt", "ldo_core",
        "--bench-lib", "BENCH", "--bench-cell", "ldo_bench", "--bench-view", "schematic",
        "--simulator", "spectre",
        "--vbias-vhigh-net", "AVDD", "--vbias-vlow-net", "VSS",
        "--max-branch-current-error", "0.2", "--max-vbias-current", "20u",
        "--work-dir", workDir.string(),
        "--variant-lib", "DERIVED", "--variant-cell", "ldo_core__TV0001",
        "--variant-id", "TV0001", "--skill", (root / "topology_variant.il").string()};
}

} // namespace

int main()
{
    const auto structureRoot = std::filesystem::temp_directory_path() / "st_cli_structure_only";
    std::filesystem::remove_all(structureRoot);
    std::filesystem::create_directories(structureRoot);
    std::ofstream(structureRoot / "cds.lib") << "DEFINE SRC " << structureRoot.string() << '\n';
    std::ofstream(structureRoot / "topology_variant.il") << "; fixture\n";
    WorkflowRunner structureRunner;
    structureRunner.scanCatalogOverride = kCatalogTsv;
    const auto resistorMapping = structureRunner.scanCatalogOverride.find("\tresistance:r\t0\tinf");
    structureRunner.scanCatalogOverride.replace(resistorMapping, std::string("\tresistance:r").size(),
        "\tresistance:r,cdf_segL:segL");
    structureRunner.structureResistorDefaults = true;
    for (std::size_t at = 0; (at = structureRunner.scanCatalogOverride.find("\tmos_n\t", at)) != std::string::npos;) {
        structureRunner.scanCatalogOverride.replace(at, 7, "\tmos\t");
        at += 5;
    }
    structureRunner.snapshotOverride = "subckt ldo_core OUT CTRL AVDD VSS IREF_P\n"
        "M0 (OUT CTRL VSS VSS) nsvt w=2u l=240n\n"
        "M1 (OUT CTRL VSS VSS) nsvt w=2u l=240n\nends ldo_core\n";
    std::vector<std::string> structureArgs;
    inspectArgs(structureArgs, structureRoot, structureRoot);
    for (std::size_t i = 1; i + 1 < structureArgs.size();) {
        if (structureArgs[i].rfind("--bench-", 0) == 0 ||
            structureArgs[i].rfind("--vbias-", 0) == 0 ||
            structureArgs[i].rfind("--max-", 0) == 0) {
            structureArgs.erase(structureArgs.begin() + i, structureArgs.begin() + i + 2);
        } else i += 2;
    }
    structureArgs.insert(structureArgs.end(), {"--validation-scope", "structure_only"});
    std::ostringstream structureOut, structureError;
    const auto structureCall = [&](const std::vector<std::string>& args) {
        structureOut.str({}); structureError.str({});
        return st::standalone::RunCli(args, structureOut, structureError, structureRunner);
    };
    CHECK(structureCall(structureArgs) == 0, "结构模式可无Bench建立会话");
    CHECK(readText(structureRoot / "before/mos_inventory.tsv").find("M0\tMOS\t") != std::string::npos,
          "只有D/G/S结构证据时不伪造NMOS或PMOS极性");
    const auto resistorFile = structureRoot / "res.conf";
    std::ofstream(resistorFile) << "id=sr\ntype=resistor\ninstance=M0\n"
        "resistor.master=r2\nresistor.parameter=r\nresistor.value=1k\n"
        "resistor.min=1\nresistor.max=1e9\nresistor.grid=1\n";
    CHECK(structureCall({"confirm", "--session", structureRoot.string(), "--operation", resistorFile.string()}) == 0,
          "结构模式确认Source电阻");
    const auto stackFile = structureRoot / "stack.conf";
    std::ofstream(stackFile) << "id=ss\ntype=stack\ninstance=M1\nstage_count=2\n"
        "gate_policy=shared\n";
    CHECK(structureCall({"confirm", "--session", structureRoot.string(), "--operation", stackFile.string()}) == 0,
          "结构模式确认两级Stack");
    CHECK(structureCall({"undo", "--session", structureRoot.string()}) == 0,
          "撤回最后一项Stack保留电阻");
    std::ofstream(stackFile) << "id=ss\ntype=stack\ninstance=M1\nstage_count=3\n"
        "gate_policy=shared\n";
    CHECK(structureCall({"confirm", "--session", structureRoot.string(), "--operation", stackFile.string()}) == 0,
          "撤回后重新确认三级Stack");
    CHECK(structureCall({"generate", "--session", structureRoot.string()}) == 0,
          "无Bench结构模式允许新电阻已声明默认CDF字段，完成封装回读和发布");
    const auto structureReport = readText(structureRoot / "reports/validation.txt");
    CHECK(structureReport.find("validation_scope=structure_only\n") != std::string::npos &&
          structureReport.find("structural_ready=true\n") != std::string::npos &&
          structureReport.find("nominal_dc_ready=false\n") != std::string::npos &&
          structureReport.find("ready_for_sizing=false\n") != std::string::npos &&
          std::find(structureRunner.verbs.begin(), structureRunner.verbs.end(), "run-op") == structureRunner.verbs.end(),
          "结构报告不冒充DC且从未调用OP");
    CHECK(readText(structureRoot / "expected/core_expected.scs").find("M1_S2") != std::string::npos,
          "生成结果使用最终三级Stack而不是撤回的两级版本");
    CHECK(structureCall({"open", "--session", structureRoot.string()}) == 0,
          "结构回读通过允许打开ready_for_sizing=false的原理图");
    CHECK(structureCall({"undo", "--session", structureRoot.string()}) == 0 &&
          structureCall({"open", "--session", structureRoot.string()}) != 0,
          "生成后撤回使旧验证失效，禁止打开过期结果");
    const auto cascodeFile = structureRoot / "cas.conf";
    std::ofstream(cascodeFile) << "id=sc\ntype=same_type_cascode\ninstance=M1\n"
        "gate_policy=fixed\nvoltage_domain=core\nnmos_bulk_net=VSS\n";
    CHECK(structureCall({"confirm", "--session", structureRoot.string(), "--operation", cascodeFile.string()}) != 0,
          "结构模式拒绝Cascode/VBIAS操作");
    structureRunner.failStructureReadback = true;
    const auto publishesBefore = std::count(structureRunner.verbs.begin(), structureRunner.verbs.end(), "publish");
    CHECK(structureCall({"generate", "--session", structureRoot.string()}) != 0 &&
          std::count(structureRunner.verbs.begin(), structureRunner.verbs.end(), "publish") == publishesBefore,
          "结构回读漂移仍阻止发布");

    std::ostringstream helpOutput;
    st::standalone::PrintCliHelp(helpOutput);
    CHECK(helpOutput.str().find("--pvt-corners") != std::string::npos &&
              helpOutput.str().find("--pvt_corners") == std::string::npos,
          "help文本使用与实际解析一致的--pvt-corners连字符形式");

    const auto root = std::filesystem::temp_directory_path() / "st_cli_workflow";
    std::filesystem::remove_all(root);
    std::filesystem::create_directories(root);
    std::ofstream(root / "cds.lib") << "DEFINE SRC " << root.string() << "\n";
    std::ofstream(root / "topology_variant.il") << "; fake path used by backend\n";
    const auto operation = root / "op1.conf";
    std::ofstream(operation)
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n"
           "tie_isolated_pmos_to_source=true\n";

    WorkflowRunner unsafeRunner;
    std::ostringstream unsafeOutput;
    std::ostringstream unsafeError;
    std::vector<std::string> arguments;
    inspectArgs(arguments, root, root / "unsafe");
    for (std::size_t index = 0; index + 1 < arguments.size(); ++index) {
        if (arguments[index] == "--variant-lib") arguments[index + 1] = "SRC";
    }
    int unsafeCode = st::standalone::RunCli(arguments, unsafeOutput, unsafeError, unsafeRunner);
    CHECK(unsafeCode != 0 && unsafeRunner.verbs.empty() &&
          unsafeError.str().find("派生library") != std::string::npos,
          "inspect在调用Virtuoso前拒绝把派生电路写入源library");

    WorkflowRunner badSimRunner;
    std::ostringstream badSimOutput;
    std::ostringstream badSimError;
    inspectArgs(arguments, root, root / "badsim");
    for (std::size_t index = 0; index + 1 < arguments.size(); ++index) {
        if (arguments[index] == "--simulator") arguments[index + 1] = "hspice";
    }
    const int badSimCode = st::standalone::RunCli(arguments, badSimOutput, badSimError,
                                                  badSimRunner);
    CHECK(badSimCode != 0 && badSimRunner.verbs.empty(),
          "inspect拒绝spectre以外的仿真器声明");

    WorkflowRunner runner;
    std::ostringstream output;
    std::ostringstream error;
    inspectArgs(arguments, root, root);
    int code = st::standalone::RunCli(arguments, output, error, runner);
    if (code != 0) std::cout << "inspect diagnostic: " << error.str();
    CHECK(code == 0 && std::filesystem::exists(root / "before/core_before.scs") &&
          std::filesystem::exists(root / "before/mos_inventory.tsv") &&
          std::filesystem::exists(root / "analysis/pdk_catalog.json") &&
          std::filesystem::exists(root / "analysis/cross_flavor_candidates.json"),
          "inspect从核心L/C/V调用后端并生成基线、动态PDK目录和当前层MOS候选清单");
    CHECK(runner.verbs.size() >= 2 && runner.verbs[0] == "scan-pdk" &&
          runner.verbs[1] == "snapshot" &&
          runner.snapshotPolicy.find("PDK\tnsvt\tmos_n") != std::string::npos &&
          runner.snapshotPolicy.find("smicnp1p") == std::string::npos,
          "先扫描当前电路真实PDK，再以扫描目录导出结构网表，不使用固定器件策略表");
    const auto manifest = readText(root / "session.conf");
    CHECK(manifest.find("schema=3\n") != std::string::npos &&
          manifest.find("bench_library=BENCH\n") != std::string::npos &&
          manifest.find("bench_cell=ldo_bench\n") != std::string::npos &&
          manifest.find("simulator=spectre\n") != std::string::npos &&
          manifest.find("nominal_corner=tt\n") != std::string::npos &&
          manifest.find("pdk_version=1.0\n") != std::string::npos &&
          manifest.find("catalog_hash=") != std::string::npos &&
          manifest.find("vbias_vhigh_net=AVDD\n") != std::string::npos &&
          manifest.find("vbias_vlow_net=VSS\n") != std::string::npos &&
          manifest.find("dut_hash=") != std::string::npos &&
          manifest.find("bench_hash=") != std::string::npos,
          "Manifest记录Bench、仿真器、名义Corner、PDK版本、双哈希和VBIAS轨网");

    const auto otherPdkRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_other_pdk";
    std::filesystem::remove_all(otherPdkRoot);
    std::filesystem::create_directories(otherPdkRoot);
    std::ofstream(otherPdkRoot / "cds.lib")
        << "DEFINE SRC " << otherPdkRoot.string() << "\n";
    std::ofstream(otherPdkRoot / "topology_variant.il") << "; fake\n";
    WorkflowRunner otherPdkRunner;
    otherPdkRunner.scanCatalogOverride = kCatalogTsv;
    for (std::size_t offset = 0;
         (offset = otherPdkRunner.scanCatalogOverride.find(
              "\tPDK\t", offset)) != std::string::npos;
         offset += 5) {
        otherPdkRunner.scanCatalogOverride.replace(offset, 5, "\tALT\t");
    }
    std::ostringstream otherPdkOutput;
    std::ostringstream otherPdkError;
    inspectArgs(arguments, otherPdkRoot, otherPdkRoot);
    code = st::standalone::RunCli(arguments, otherPdkOutput, otherPdkError,
                                  otherPdkRunner);
    CHECK(code == 0 &&
          readText(otherPdkRoot / "analysis/device_policy.tsv").find(
              "ALT\tnsvt\tmos_n") != std::string::npos &&
          readText(otherPdkRoot / "analysis/device_policy.tsv").find(
              "PDK\tnsvt\tmos_n") == std::string::npos &&
          readText(root / "analysis/device_policy.tsv").find(
              "PDK\tnsvt\tmos_n") != std::string::npos,
          "两份导入电路各自生成PDK策略，不复用首个Case的固定库与master映射");

    const auto catalogRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_catalog_identity";
    std::filesystem::remove_all(catalogRoot);
    std::filesystem::create_directories(catalogRoot);
    std::ofstream(catalogRoot / "cds.lib")
        << "DEFINE SRC " << catalogRoot.string() << "\n";
    std::ofstream(catalogRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(catalogRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner catalogRunner;
    catalogRunner.staleSnapshotCatalog = true;
    std::ostringstream catalogOutput;
    std::ostringstream catalogError;
    inspectArgs(arguments, catalogRoot, catalogRoot);
    code = st::standalone::RunCli(arguments, catalogOutput, catalogError,
                                  catalogRunner);
    if (code != 0) std::cout << "catalog inspect diagnostic: " << catalogError.str();
    CHECK(code == 0 && catalogRunner.verbs ==
              std::vector<std::string>({"scan-pdk", "snapshot"}) &&
          readText(catalogRoot / "before/device_catalog.tsv") == kCatalogTsv &&
          readText(catalogRoot / "session.conf").find("catalog_hash=") !=
              std::string::npos,
          "inspect以独立PDK扫描为目录来源并固定内容身份");
    code = st::standalone::RunCli({"confirm", "--session", catalogRoot.string(),
        "--operation", (catalogRoot / "op1.conf").string()}, catalogOutput,
        catalogError, catalogRunner);
    CHECK(code == 0, "目录身份用例的操作确认成功");
    catalogRunner.driftScanCatalog = true;
    catalogOutput.str({}); catalogError.str({});
    code = st::standalone::RunCli({"generate", "--session", catalogRoot.string()},
                                  catalogOutput, catalogError, catalogRunner);
    CHECK(code != 0 && catalogError.str().find("PDK目录内容") !=
              std::string::npos &&
          std::find(catalogRunner.verbs.begin(), catalogRunner.verbs.end(),
                    "run-op") == catalogRunner.verbs.end(),
          "同版本PDK目录内容漂移时须在求解前拒绝生成");
    catalogRunner.driftScanCatalog = false;
    catalogOutput.str({}); catalogError.str({});
    code = st::standalone::RunCli({"generate", "--session", catalogRoot.string()},
                                  catalogOutput, catalogError, catalogRunner);
    CHECK(code == 0 &&
          readText(catalogRoot / "analysis/pdk_scan/run_0001/raw_catalog.tsv") !=
              kCatalogTsv &&
          readText(catalogRoot / "analysis/pdk_scan/run_0002/raw_catalog.tsv") ==
              kCatalogTsv,
          "重新generate保留漂移扫描证据，并写入新的扫描归档");

    const auto noLimitRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_no_case_limits";
    std::filesystem::remove_all(noLimitRoot);
    std::filesystem::create_directories(noLimitRoot);
    std::ofstream(noLimitRoot / "cds.lib")
        << "DEFINE SRC " << noLimitRoot.string() << "\n";
    std::ofstream(noLimitRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(noLimitRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner noLimitRunner;
    std::ostringstream noLimitOutput;
    std::ostringstream noLimitError;
    inspectArgs(arguments, noLimitRoot, noLimitRoot);
    for (std::size_t index = 1; index + 1 < arguments.size();) {
        if (arguments[index] == "--max-branch-current-error" ||
            arguments[index] == "--max-vbias-current") {
            arguments.erase(arguments.begin() + static_cast<std::ptrdiff_t>(index),
                            arguments.begin() + static_cast<std::ptrdiff_t>(index + 2));
        } else {
            index += 2;
        }
    }
    code = st::standalone::RunCli(arguments, noLimitOutput, noLimitError,
                                  noLimitRunner);
    CHECK(code == 0, "未给Case电流限值时仍可inspect当前层MOS");
    code = st::standalone::RunCli({"confirm", "--session", noLimitRoot.string(),
        "--operation", (noLimitRoot / "op1.conf").string()}, noLimitOutput,
        noLimitError, noLimitRunner);
    CHECK(code == 0, "未给Case电流限值时仍可确认Cascode意图");
    noLimitError.str({});
    code = st::standalone::RunCli({"generate", "--session", noLimitRoot.string()},
                                  noLimitOutput, noLimitError, noLimitRunner);
    const auto noLimitValidation = readText(noLimitRoot / "reports/validation.txt");
    CHECK(code == 0 &&
          std::find(noLimitRunner.verbs.begin(), noLimitRunner.verbs.end(),
                    "run-op") != noLimitRunner.verbs.end() &&
          std::find(noLimitRunner.verbs.begin(), noLimitRunner.verbs.end(),
                    "publish") != noLimitRunner.verbs.end() &&
          noLimitValidation.find("validation_scope=dc_operating_point\n") != std::string::npos &&
          noLimitValidation.find("performance_verified=false\n") != std::string::npos &&
          noLimitValidation.find("current_limits_applied=false\n") != std::string::npos,
          "无Spec会话完成真实候选流程并明确标注仅直流验证、未验性能");

    const auto discoveryRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_discovery_only";
    std::filesystem::remove_all(discoveryRoot);
    std::filesystem::create_directories(discoveryRoot);
    std::ofstream(discoveryRoot / "cds.lib")
        << "DEFINE SRC " << discoveryRoot.string() << "\n";
    std::ofstream(discoveryRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(discoveryRoot / "op1.conf")
        << "id=op1\ntype=same_type_cascode\ninstance=M0\n"
           "gate_policy=fixed\nvoltage_domain=core\nnmos_bulk_net=VSS\n";
    WorkflowRunner discoveryRunner;
    std::ostringstream discoveryOutput;
    std::ostringstream discoveryError;
    inspectArgs(arguments, discoveryRoot, discoveryRoot);
    for (std::size_t index = 1; index + 1 < arguments.size();) {
        if (arguments[index] == "--bench-lib" ||
            arguments[index] == "--bench-cell" ||
            arguments[index] == "--bench-view" ||
            arguments[index] == "--vbias-vhigh-net" ||
            arguments[index] == "--vbias-vlow-net" ||
            arguments[index] == "--max-branch-current-error" ||
            arguments[index] == "--max-vbias-current") {
            arguments.erase(arguments.begin() + static_cast<std::ptrdiff_t>(index),
                            arguments.begin() + static_cast<std::ptrdiff_t>(index + 2));
        } else {
            index += 2;
        }
    }
    code = st::standalone::RunCli(arguments, discoveryOutput, discoveryError,
                                  discoveryRunner);
    CHECK(code == 0 && std::filesystem::exists(
              discoveryRoot / "before/mos_inventory.tsv"),
          "未取得Bench、轨网和Case电流限值时仍可只读inspect当前层MOS");
    code = st::standalone::RunCli({"confirm", "--session", discoveryRoot.string(),
        "--operation", (discoveryRoot / "op1.conf").string()},
        discoveryOutput, discoveryError, discoveryRunner);
    CHECK(code == 0, "发现会话仍可记录结构操作意图");
    discoveryError.str({});
    code = st::standalone::RunCli({"generate", "--session", discoveryRoot.string()},
                                  discoveryOutput, discoveryError, discoveryRunner);
    CHECK(code != 0 && discoveryError.str().find("Bench") != std::string::npos &&
          discoveryRunner.verbs ==
              std::vector<std::string>({"scan-pdk", "snapshot"}),
          "无Bench的发现会话不能进入仿真和发布");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"inspect", "--backend", "/opt/site/backend",
        "--cds-lib", (root / "cds.lib").string(), "--lib", "SRC", "--cell", "ldo_core",
        "--view", "schematic", "--work-dir", root.string(), "--variant-lib",
        "DERIVED", "--variant-cell", "ldo_core__TV0001", "--variant-id",
        "TV0001", "--skill", (root / "topology_variant.il").string(),
        "--bench-lib", "BENCH", "--bench-cell", "ldo_bench", "--bench-view", "schematic",
        "--simulator", "spectre", "--vbias-vhigh-net", "AVDD", "--vbias-vlow-net", "VSS",
        "--max-branch-current-error", "0.2", "--max-vbias-current", "20u"},
        output, error, runner);
    CHECK(code != 0 && runner.verbs ==
          std::vector<std::string>({"scan-pdk", "snapshot"}),
          "inspect拒绝复用已有会话目录，避免旧Change Set和网表混入新电路");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"open", "--session", root.string()},
                                  output, error, runner);
    CHECK(code != 0 && runner.verbs ==
          std::vector<std::string>({"scan-pdk", "snapshot"}),
          "回读校验成功前拒绝打开未验证派生电路");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"confirm", "--session", root.string(),
        "--operation", operation.string()}, output, error, runner);
    CHECK(code == 0 && std::filesystem::exists(root / "changes/0001.conf"),
          "confirm校验后保存一次不可变结构变换");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"list", "--session", root.string()},
                                  output, error, runner);
    CHECK(code == 0 && output.str().find("已确认操作: 1") != std::string::npos,
          "list显示当前派生逻辑结构和已确认操作数");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"generate", "--session", root.string()},
                                  output, error, runner);
    CHECK(code == 0, "generate完成自动VBIAS求解、封装、物化和回读验证");
    CHECK(runner.roundtripUsesPolicy,
          "源图、派生父图和子Cell回读沿用本会话扫描出的PDK器件策略");
    CHECK(readText(root / "analysis/pdk_scan/inspect/raw_catalog.tsv") ==
              kCatalogTsv &&
          readText(root / "analysis/pdk_scan/run_0001/raw_catalog.tsv") ==
              kCatalogTsv &&
          std::filesystem::exists(root / "analysis/pdk_scan/inspect/scan_pdk.log") &&
          std::filesystem::exists(root / "analysis/pdk_scan/run_0001/scan_pdk.log"),
          "inspect与generate的PDK原始目录和日志分别留档，不相互覆盖");
    CHECK(std::filesystem::exists(root / "expected/core_expected.scs") &&
          std::filesystem::exists(root / "materialization/plan.json") &&
          std::filesystem::exists(root / "after/core_roundtrip.scs") &&
          std::filesystem::exists(root / "reports/validation.txt"),
          "generate产生期望网表、SKILL计划、回读网表和验证报告");
    CHECK(std::filesystem::exists(root / "analysis/baseline_op.json") &&
          std::filesystem::exists(root / "analysis/solver_trace.jsonl") &&
          std::filesystem::exists(root / "analysis/resolved_parameters.json") &&
          nonEmptyLines(root / "analysis/solver_trace.jsonl") > 0,
          "分析产物包含基线OP、求解轨迹和已解析参数");
    CHECK(readText(root / "analysis/resolved_parameters.json")
              .find("\"status\":\"solved\"") != std::string::npos,
          "已解析参数记录solved状态");
    const auto planText = readText(root / "materialization/plan.json");
    const auto expectedText = readText(root / "expected/core_expected.scs");
    CHECK(planText.find("\"library\":\"DERIVED\"") == std::string::npos &&
          planText.find("\"library\":\"DERIVED__STAGING\"") != std::string::npos,
          "根图及全部功能/VBIAS子图只在STAGING物化");
    const auto publishText = readText(root / "logs/publish_plan.json");
    CHECK(publishText.find("__PKG0001") != std::string::npos &&
          publishText.find("__VBIAS0001") != std::string::npos &&
          publishText.find("\"view\":\"symbol\"") != std::string::npos,
          "一次发布事务包含根图及功能/VBIAS全部schematic/symbol");

    CHECK(planText.find("\"schema_version\":3") != std::string::npos &&
          planText.find("__VBIAS0001") != std::string::npos &&
          expectedText.find("__PKG0001") != std::string::npos &&
          expectedText.find("__VBIAS0001") != std::string::npos,
          "Cascode操作产生功能封装和独立VBIAS封装两个子Cell");
    const auto validation = readText(root / "reports/validation.txt");
    CHECK(validation.find("current_limits_applied=true\n") != std::string::npos &&
          validation.find("performance_verified=false\n") != std::string::npos,
          "已配置电流限值会话仍应用限值，但不冒充完整性能验收");
    CHECK(validation.find("structural_ready=true") != std::string::npos &&
          validation.find("nominal_dc_ready=true") != std::string::npos &&
          validation.find("parameters_quantized=true") != std::string::npos &&
          validation.find("ready_for_sizing=true") != std::string::npos &&
          validation.find("pvt_ready=false") != std::string::npos,
          "验证报告给出四状态，未配置PVT不阻塞ready_for_sizing");
    CHECK(output.str().find("structural_ready=true") != std::string::npos &&
          output.str().find("nominal_dc_ready=true") != std::string::npos &&
          output.str().find("parameters_quantized=true") != std::string::npos &&
          output.str().find("ready_for_sizing=true") != std::string::npos,
          "成功输出四状态和进入Sizing的结构状态");

    // 后端动词结构：scan-pdk/snapshot(inspect) + scan-pdk/run-op(基线) +
    // (clone/materialize/netlist×3/run-op)×N(求解候选，N=轨迹行数) +
    // clone/materialize/run-op/netlist×4/publish。
    const std::vector<std::string> tail = {"clone", "materialize", "run-op",
        "netlist", "netlist", "netlist", "netlist", "publish"};
    const auto verbs = runner.verbs;
    bool structure = verbs.size() >= 4 + tail.size() &&
        verbs[0] == "scan-pdk" && verbs[1] == "snapshot" &&
        verbs[2] == "scan-pdk" && verbs[3] == "run-op";
    std::size_t candidateRuns = 0;
    if (structure) {
        const std::size_t middleEnd = verbs.size() - tail.size();
        structure = structure && (middleEnd - 4) % 6 == 0;
        for (std::size_t index = 4; structure && index < middleEnd; index += 6) {
            structure = verbs[index] == "clone" &&
                verbs[index + 1] == "materialize" &&
                verbs[index + 2] == "netlist" &&
                verbs[index + 3] == "netlist" &&
                verbs[index + 4] == "netlist" &&
                verbs[index + 5] == "run-op";
            ++candidateRuns;
        }
        for (std::size_t index = 0; index < tail.size(); ++index) {
            structure = structure && verbs[verbs.size() - tail.size() + index] == tail[index];
        }
    }
    CHECK(structure, "generate后端顺序为scan-pdk、基线run-op、每候选"
                     "clone/materialize/完整回读/run-op、最终名义DC、回读与发布");
    CHECK(candidateRuns == nonEmptyLines(root / "analysis/solver_trace.jsonl") &&
          candidateRuns > 0,
          "每个求解候选都先物化唯一OA CellView再调用run-op，"
          "次数与轨迹行数一致");
    CHECK(std::filesystem::exists(root /
              "analysis/candidates/candidate_001/expected/core_expected.scs") &&
          std::filesystem::exists(root /
              "analysis/candidates/candidate_001/roundtrip/core.scs") &&
          readText(root / "analysis/candidates/candidate_001/validation.txt")
              .find("ok=true") != std::string::npos,
          "每个候选独立保存封装期望网表、OA回读和校验报告");

    output.str({}); error.str({});
    code = st::standalone::RunCli({"open", "--session", root.string()},
                                  output, error, runner);
    CHECK(code == 0 && runner.verbs.back() == "open" &&
          output.str().find("DERIVED/ldo_core__TV0001/schematic") != std::string::npos,
          "验证成功后后端可打开最终派生电路");

    for (const bool failResistor : {false, true}) {
        const auto sourceRoot = std::filesystem::temp_directory_path() /
            (failResistor ? "st_cli_source_resistor_fail"
                          : "st_cli_source_resistor_pass");
        std::filesystem::remove_all(sourceRoot);
        std::filesystem::create_directories(sourceRoot);
        std::ofstream(sourceRoot / "cds.lib")
            << "DEFINE SRC " << sourceRoot.string() << "\n";
        std::ofstream(sourceRoot / "topology_variant.il") << "; fake\n";
        std::ofstream(sourceRoot / "op1.conf")
            << "id=op_source\n"
               "type=resistor\n"
               "instance=M0\n"
               "resistor.master=r2\n"
               "resistor.parameter=r\n"
               "resistor.value=1k\n"
               "resistor.grid=1\n"
               "resistor.min=1\n"
               "resistor.max=1e9\n"
               "critical_dynamic_gate=false\n";
        WorkflowRunner sourceRunner;
        std::ostringstream sourceOutput;
        std::ostringstream sourceError;
        inspectArgs(arguments, sourceRoot, sourceRoot);
        code = st::standalone::RunCli(arguments, sourceOutput,
                                      sourceError, sourceRunner);
        CHECK(code == 0, "Source电阻用例inspect成功");
        code = st::standalone::RunCli({"confirm", "--session", sourceRoot.string(),
            "--operation", (sourceRoot / "op1.conf").string()},
            sourceOutput, sourceError, sourceRunner);
        CHECK(code == 0, "Source电阻用例confirm成功");
        sourceRunner.failFinalResistor = failResistor;
        sourceOutput.str({}); sourceError.str({});
        code = st::standalone::RunCli({"generate", "--session",
            sourceRoot.string()}, sourceOutput, sourceError, sourceRunner);
        const auto sourceValidation = readText(sourceRoot / "reports/validation.txt");
        CHECK((failResistor
              ? (code != 0 &&
                 sourceValidation.find("resistor_voltage") != std::string::npos &&
                 std::find(sourceRunner.verbs.begin(), sourceRunner.verbs.end(),
                           "publish") == sourceRunner.verbs.end())
              : (code == 0 &&
                 sourceValidation.find("ready_for_sizing=true") !=
                     std::string::npos &&
                 std::filesystem::exists(sourceRoot /
                     "analysis/variant_op/resistor.tsv"))),
              (failResistor ? "Source电阻过压阻止发布"
                            : "Source电阻额定值和实际OP通过后发布"));
    }

    // ---- 无解子用例：全部候选违反可靠性约束 ----
    const auto failRoot = std::filesystem::temp_directory_path() / "st_cli_workflow_nosolution";
    std::filesystem::remove_all(failRoot);
    std::filesystem::create_directories(failRoot);
    std::ofstream(failRoot / "cds.lib") << "DEFINE SRC " << failRoot.string() << "\n";
    std::ofstream(failRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(failRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner failRunner;
    std::ostringstream failOutput;
    std::ostringstream failError;
    inspectArgs(arguments, failRoot, failRoot);
    code = st::standalone::RunCli(arguments, failOutput, failError, failRunner);
    CHECK(code == 0, "无解用例的inspect成功建会话");
    code = st::standalone::RunCli({"confirm", "--session", failRoot.string(),
        "--operation", (failRoot / "op1.conf").string()}, failOutput, failError, failRunner);
    CHECK(code == 0, "无解用例的操作确认成功");
    failRunner.failSolve = true;
    failOutput.str({}); failError.str({});
    code = st::standalone::RunCli({"generate", "--session", failRoot.string()},
                                  failOutput, failError, failRunner);
    CHECK(code != 0, "所有候选违反约束时generate失败");
    CHECK(nonEmptyLines(failRoot / "analysis/solver_trace.jsonl") > 0 &&
          readText(failRoot / "analysis/resolved_parameters.json")
                  .find("\"status\":\"no_solution\"") != std::string::npos,
          "无解时保留非空求解轨迹并记录no_solution状态");
    CHECK(!std::filesystem::exists(failRoot / "materialization/plan.json") &&
          std::find(failRunner.verbs.begin(), failRunner.verbs.end(), "publish") ==
              failRunner.verbs.end(),
          "无解时只保留候选OA证据，不写最终OA计划且不发布");
    CHECK(readText(failRoot / "reports/validation.txt")
              .find("ready_for_sizing=false") != std::string::npos,
          "无解时验证报告明确ready_for_sizing=false");
    failRunner.failSolve = false;
    failRunner.omitResistorOp = true;
    failRunner.verbs.clear();
    failOutput.str({}); failError.str({});
    code = st::standalone::RunCli({"generate", "--session", failRoot.string()},
                                  failOutput, failError, failRunner);
    CHECK(code != 0 &&
          readText(failRoot / "analysis/resolved_parameters.json")
              .find("no_solution") != std::string::npos &&
          std::find(failRunner.verbs.begin(), failRunner.verbs.end(),
                    "publish") == failRunner.verbs.end(),
          "候选电阻OP文件缺失时不能复用旧文件或发布");

    failRunner.omitResistorOp = false;
    for (const auto& fault : {"parent_connection", "child_parameter", "missing_child",
                             "child_extra_subckt", "child_directive"}) {
        const auto oldCandidate = failRunner.lastCandidateDirectory;
        const auto oldReport = readText(oldCandidate / "validation.txt");
        failRunner.candidateRoundtripFault = fault;
        failRunner.verbs.clear();
        failOutput.str({}); failError.str({});
        code = st::standalone::RunCli({"generate", "--session", failRoot.string()},
                                      failOutput, failError, failRunner);
        const auto report = readText(failRunner.lastCandidateDirectory /
            "validation.txt");
        CHECK(code != 0 && report.find("ok=false") != std::string::npos &&
              report.find("DC候选") != std::string::npos &&
              readText(failRoot / "analysis/solver_trace.jsonl")
                  .find("DC候选") != std::string::npos &&
              std::find(failRunner.verbs.begin(), failRunner.verbs.end(),
                        "run-op") == failRunner.verbs.end() &&
              std::find(failRunner.verbs.begin(), failRunner.verbs.end(),
                        "publish") == failRunner.verbs.end(),
              std::string("候选OA回读不一致阻止仿真和发布，并留档：") + fault);
        CHECK(oldCandidate != failRunner.lastCandidateDirectory &&
              readText(oldCandidate / "validation.txt") == oldReport,
              "重复generate保留既有候选Cell身份和回读证据");
    }

    // ---- 最终staging子用例：候选全部通过，但最终名义OP的真实Cascode过压 ----
    const auto finalFailRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_final_electrical_failure";
    std::filesystem::remove_all(finalFailRoot);
    std::filesystem::create_directories(finalFailRoot);
    std::ofstream(finalFailRoot / "cds.lib")
        << "DEFINE SRC " << finalFailRoot.string() << "\n";
    std::ofstream(finalFailRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(finalFailRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner finalFailRunner;
    std::ostringstream finalFailOutput;
    std::ostringstream finalFailError;
    inspectArgs(arguments, finalFailRoot, finalFailRoot);
    code = st::standalone::RunCli(arguments, finalFailOutput, finalFailError,
                                  finalFailRunner);
    CHECK(code == 0, "最终电气门禁用例的inspect成功");
    code = st::standalone::RunCli({"confirm", "--session", finalFailRoot.string(),
        "--operation", (finalFailRoot / "op1.conf").string()}, finalFailOutput,
        finalFailError, finalFailRunner);
    CHECK(code == 0, "最终电气门禁用例的操作确认成功");
    finalFailRunner.failFinalNominal = true;
    finalFailOutput.str({});
    finalFailError.str({});
    code = st::standalone::RunCli({"generate", "--session",
        finalFailRoot.string()}, finalFailOutput, finalFailError, finalFailRunner);
    const auto finalFailValidation =
        readText(finalFailRoot / "reports/validation.txt");
    CHECK(code != 0 &&
              finalFailValidation.find("stage=nominal_dc_check") !=
                  std::string::npos &&
              finalFailValidation.find("reliability_vgs") !=
                  std::string::npos,
          "候选通过但最终staging真实Cascode过压时由共享硬约束拒绝");
    CHECK(std::find(finalFailRunner.verbs.begin(), finalFailRunner.verbs.end(),
                    "publish") == finalFailRunner.verbs.end(),
          "最终名义电气约束失败后不发布");

    finalFailRunner.failFinalNominal = false;
    finalFailRunner.failFinalResistor = true;
    finalFailRunner.verbs.clear();
    finalFailOutput.str({}); finalFailError.str({});
    code = st::standalone::RunCli({"generate", "--session",
        finalFailRoot.string()}, finalFailOutput, finalFailError, finalFailRunner);
    CHECK(code != 0 &&
          readText(finalFailRoot / "reports/validation.txt")
              .find("resistor_voltage") != std::string::npos &&
          std::find(finalFailRunner.verbs.begin(), finalFailRunner.verbs.end(),
                    "publish") == finalFailRunner.verbs.end(),
          "候选通过但最终VBIAS参考电阻过压时拒绝发布");

    const auto biasFailRoot = std::filesystem::temp_directory_path() /
        "st_cli_workflow_final_bias_current_failure";
    std::filesystem::remove_all(biasFailRoot);
    std::filesystem::create_directories(biasFailRoot);
    std::ofstream(biasFailRoot / "cds.lib")
        << "DEFINE SRC " << biasFailRoot.string() << "\n";
    std::ofstream(biasFailRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(biasFailRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner biasFailRunner;
    std::ostringstream biasFailOutput;
    std::ostringstream biasFailError;
    inspectArgs(arguments, biasFailRoot, biasFailRoot);
    code = st::standalone::RunCli(arguments, biasFailOutput, biasFailError,
                                  biasFailRunner);
    CHECK(code == 0, "最终偏置电流门禁用例的inspect成功");
    code = st::standalone::RunCli({"confirm", "--session", biasFailRoot.string(),
        "--operation", (biasFailRoot / "op1.conf").string()}, biasFailOutput,
        biasFailError, biasFailRunner);
    CHECK(code == 0, "最终偏置电流门禁用例的操作确认成功");
    biasFailRunner.failFinalBiasCurrent = true;
    biasFailOutput.str({}); biasFailError.str({});
    code = st::standalone::RunCli({"generate", "--session",
        biasFailRoot.string()}, biasFailOutput, biasFailError, biasFailRunner);
    CHECK(code != 0 &&
          readText(biasFailRoot / "reports/validation.txt")
              .find("bias_current_limit") != std::string::npos &&
          std::find(biasFailRunner.verbs.begin(), biasFailRunner.verbs.end(),
                    "publish") == biasFailRunner.verbs.end(),
          "最终staging偏置支路超Case电流上限时拒绝发布");

    // ---- PVT 子用例：名义 tt 通过、ss Corner 过压 ----
    const auto pvtRoot = std::filesystem::temp_directory_path() / "st_cli_workflow_pvt";
    std::filesystem::remove_all(pvtRoot);
    std::filesystem::create_directories(pvtRoot);
    std::ofstream(pvtRoot / "cds.lib") << "DEFINE SRC " << pvtRoot.string() << "\n";
    std::ofstream(pvtRoot / "topology_variant.il") << "; fake\n";
    std::ofstream(pvtRoot / "op1.conf")
        << "id=op1\n"
           "type=same_type_cascode\n"
           "instance=M0\n"
           "gate_policy=fixed\n"
           "voltage_domain=core\n"
           "nmos_bulk_net=VSS\n";
    WorkflowRunner pvtRunner;
    std::ostringstream pvtOutput;
    std::ostringstream pvtError;
    inspectArgs(arguments, pvtRoot, pvtRoot);
    arguments.push_back("--pvt-corners");
    arguments.push_back("tt,ss");
    code = st::standalone::RunCli(arguments, pvtOutput, pvtError, pvtRunner);
    CHECK(code == 0, "PVT用例的inspect成功建会话并记录PVT角");
    CHECK(readText(pvtRoot / "session.conf").find("pvt_corners=tt,ss\n") !=
              std::string::npos,
          "Manifest记录PVT Corner列表");
    code = st::standalone::RunCli({"confirm", "--session", pvtRoot.string(),
        "--operation", (pvtRoot / "op1.conf").string()}, pvtOutput, pvtError,
        pvtRunner);
    CHECK(code == 0, "PVT用例的操作确认成功");
    pvtRunner.failPvt = true; // ss Corner 下两 N 角色过压
    pvtOutput.str({}); pvtError.str({});
    code = st::standalone::RunCli({"generate", "--session", pvtRoot.string()},
                                  pvtOutput, pvtError, pvtRunner);
    CHECK(code != 0, "最终staging的PVT复验失败会阻塞generate");
    const auto pvtValidation = readText(pvtRoot / "reports/validation.txt");
    CHECK(pvtValidation.find("pvt_ready=false") != std::string::npos &&
              pvtValidation.find("nominal_dc_ready=true") != std::string::npos &&
              pvtValidation.find("ready_for_sizing=false") != std::string::npos &&
              pvtValidation.find("stage=pvt_check") != std::string::npos,
          "PVT失败时pvt_ready=false、ready_for_sizing=false且停在pvt_check");
    const auto pvtResolved = readText(pvtRoot / "analysis/resolved_parameters.json");
    CHECK(pvtResolved.find("\"pvt_ready\":false") != std::string::npos &&
              pvtResolved.find("\"corner\":\"ss\"") != std::string::npos &&
              pvtResolved.find("reliability_vgs") != std::string::npos,
          "已解析参数报告PVT失败的corner与具体约束");
    CHECK(readText(pvtRoot / "analysis/solver_trace.jsonl")
                  .find("\"corner\":\"ss\"") != std::string::npos &&
              std::find(pvtRunner.verbs.begin(), pvtRunner.verbs.end(),
                        "publish") == pvtRunner.verbs.end(),
          "PVT复验进轨迹，最终Corner失败后不发布");
    pvtRunner.failPvt = false;
    pvtRunner.failPvtResistor = true;
    pvtRunner.verbs.clear();
    pvtOutput.str({}); pvtError.str({});
    code = st::standalone::RunCli({"generate", "--session", pvtRoot.string()},
                                  pvtOutput, pvtError, pvtRunner);
    CHECK(code != 0 &&
          readText(pvtRoot / "reports/validation.txt")
              .find("resistor_voltage") != std::string::npos &&
          readText(pvtRoot / "analysis/resolved_parameters.json")
              .find("resistor_voltage") != std::string::npos &&
          std::find(pvtRunner.verbs.begin(), pvtRunner.verbs.end(),
                    "publish") == pvtRunner.verbs.end(),
          "PVT的ss角参考电阻过压时保留原因并阻止发布");

    const auto experimentalRoot = std::filesystem::temp_directory_path() / "st_cli_experimental_dc";
    std::filesystem::remove_all(experimentalRoot);
    std::filesystem::create_directories(experimentalRoot);
    std::ofstream(experimentalRoot / "cds.lib") << "DEFINE SRC " << experimentalRoot.string() << "\n";
    std::ofstream(experimentalRoot / "topology_variant.il") << "; fake backend\n";
    std::ofstream(experimentalRoot / "op.conf") << "id=exp1\ntype=resistor\ninstance=M0\nresistor.master=r2\nresistor.value=1k\nresistor.parameter=r\nresistor.grid=1\nresistor.min=1\nresistor.max=1e9\ncritical_dynamic_gate=false\n";
    WorkflowRunner experimentalRunner;
    experimentalRunner.unknownResistorRatings = true;
    std::ostringstream experimentalOut, experimentalError;
    const auto experimentalCall = [&](const std::vector<std::string>& args) {
        experimentalOut.str({}); experimentalError.str({});
        return st::standalone::RunCli(args, experimentalOut, experimentalError, experimentalRunner);
    };
    inspectArgs(arguments, experimentalRoot, experimentalRoot);
    arguments.insert(arguments.end(), {"--validation-scope", "experimental_dc", "--pvt-corners", "tt,ss"});
    CHECK(experimentalCall(arguments) == 0, "实验范围显式inspect并保存固定范围");
    CHECK(experimentalCall({"confirm", "--session", experimentalRoot.string(), "--operation", (experimentalRoot / "op.conf").string()}) == 0,
          "实验范围确认源电阻操作");
    const auto experimentalGenerate = experimentalCall({"generate", "--session", experimentalRoot.string()});
    if (experimentalGenerate != 0) std::cout << "experimental diagnostic: " << experimentalError.str();
    CHECK(experimentalGenerate == 0, "额定值未知的实验完成真实流程调度、名义DC与同参数PVT回读");
    const auto experimentalReport = readText(experimentalRoot / "reports/validation.txt");
    CHECK(experimentalReport.find("experimental_dc_ready=true\n") != std::string::npos &&
          experimentalReport.find("experimental_pvt_ready=true\n") != std::string::npos &&
          experimentalReport.find("ready_for_sizing=false\n") != std::string::npos &&
          experimentalReport.find("reliability_verified=false\n") != std::string::npos &&
          experimentalReport.find("published=false\n") != std::string::npos &&
          experimentalReport.find("unverified_constraint=") != std::string::npos &&
          experimentalReport.find("stress.tt/exp1/M0_RS/voltage=1") != std::string::npos &&
          std::find(experimentalRunner.verbs.begin(), experimentalRunner.verbs.end(), "publish") == experimentalRunner.verbs.end(),
          "实验结果记录测量及未知项并停留staging，不发布或提升Sizing/可靠性");
    CHECK(experimentalCall({"open", "--session", experimentalRoot.string()}) == 0 &&
          experimentalRunner.openedLibrary == "DERIVED__STAGING" &&
          experimentalRunner.openedCell == "ldo_core__TV0001__STAGING" && experimentalRunner.scopeForwarded,
          "显式实验会话只打开staging且所有后端调用带实验范围");
    experimentalRunner.failSelectedMos = true;
    CHECK(experimentalCall({"generate", "--session", experimentalRoot.string()}) != 0 &&
          readText(experimentalRoot / "reports/validation.txt").find("reliability_vds") != std::string::npos,
          "源电阻实验同样拒绝目标MOS已知VDS越限");
    experimentalRunner.failSelectedMos = false;
    experimentalRunner.omitSelectedMos = true;
    CHECK(experimentalCall({"generate", "--session", experimentalRoot.string()}) != 0 &&
          readText(experimentalRoot / "reports/validation.txt").find("实验MOS工作点缺失") != std::string::npos,
          "源电阻实验不得用其它MOS的非空OP掩盖目标MOS缺失");
    experimentalRunner.omitSelectedMos = false;
    const auto experimentalManifest = readText(experimentalRoot / "session.conf");
    auto promotedManifest = experimentalManifest;
    promotedManifest.replace(promotedManifest.find("validation_scope=experimental_dc"),
        std::string("validation_scope=experimental_dc").size(), "validation_scope=dc_operating_point");
    std::ofstream(experimentalRoot / "session.conf") << promotedManifest;
    CHECK(experimentalCall({"open", "--session", experimentalRoot.string()}) != 0 &&
          experimentalCall({"generate", "--session", experimentalRoot.string()}) != 0,
          "修改会话范围不能提升实验报告或缓存为正式结果");
    std::ofstream(experimentalRoot / "session.conf") << experimentalManifest;
    experimentalRunner.failStructureReadback = true;
    CHECK(experimentalCall({"generate", "--session", experimentalRoot.string()}) != 0 &&
          readText(experimentalRoot / "reports/validation.txt").find("experimental_dc_ready=false") != std::string::npos &&
          std::find(experimentalRunner.verbs.begin(), experimentalRunner.verbs.end(), "publish") == experimentalRunner.verbs.end(),
          "实验回读不一致仍失败且不发布");

    const auto experimentalBiasRoot = std::filesystem::temp_directory_path() / "st_cli_experimental_bias";
    std::filesystem::remove_all(experimentalBiasRoot);
    std::filesystem::create_directories(experimentalBiasRoot);
    std::ofstream(experimentalBiasRoot / "cds.lib") << "DEFINE SRC " << experimentalBiasRoot.string() << "\n";
    std::ofstream(experimentalBiasRoot / "topology_variant.il") << "; fake backend\n";
    std::filesystem::copy_file(operation, experimentalBiasRoot / "op.conf");
    WorkflowRunner experimentalBiasRunner;
    experimentalBiasRunner.unknownResistorRatings = true;
    auto proposedCatalog = std::string(kCatalogTsv);
    const auto replaceAll = [&](const std::string& before, const std::string& after) {
        std::size_t from = 0;
        while ((from = proposedCatalog.find(before, from)) != std::string::npos) {
            proposedCatalog.replace(from, before.size(), after);
            from += after.size();
        }
    };
    replaceAll("1.2\t1.2\t1.2\t100", "inf\tinf\tinf\t100");
    replaceAll("\ttrue\ttrue\tPDK", "\tfalse\ttrue\tPDK");
    replaceAll("symbol\tcore\t", "symbol\t\t");
    replaceAll("width:w:1e-7:1e-3:1e-8:;length:l:1e-7:1e-5:1e-8:",
               "width:w:2e-6:2e-6:0:2e-6;length:l:2.4e-7:2.4e-7:0:2.4e-7");
    replaceAll("resistance:r:1:1e9:1:", "resistance:r:10000:100000:0:10000,100000");
    std::istringstream proposedLines(proposedCatalog);
    std::string proposedLine;
    bool proposedHeader = true;
    while (std::getline(proposedLines, proposedLine)) {
        experimentalBiasRunner.scanCatalogOverride += proposedLine +
            (proposedHeader ? "\tnative_parameter_trials\n" : "\ttrue\n");
        proposedHeader = false;
    }
    std::ostringstream experimentalBiasOut, experimentalBiasError;
    const auto experimentalBiasCall = [&](const std::vector<std::string>& args) {
        experimentalBiasOut.str({}); experimentalBiasError.str({});
        return st::standalone::RunCli(args, experimentalBiasOut, experimentalBiasError, experimentalBiasRunner);
    };
    inspectArgs(arguments, experimentalBiasRoot, experimentalBiasRoot);
    arguments.insert(arguments.end(), {"--validation-scope", "experimental_dc"});
    CHECK(experimentalBiasCall(arguments) == 0 &&
          experimentalBiasCall({"confirm", "--session", experimentalBiasRoot.string(), "--operation", (experimentalBiasRoot / "op.conf").string()}) == 0,
          "Cascode实验可接收有限原生试点且不要求未知域/额定资料");
    const auto biasExperimentCode = experimentalBiasCall({"generate", "--session", experimentalBiasRoot.string()});
    if (biasExperimentCode != 0) std::cout << "experimental bias diagnostic: " << experimentalBiasError.str();
    const auto experimentalBiasReport = readText(experimentalBiasRoot / "reports/validation.txt");
    CHECK(biasExperimentCode == 0 && experimentalBiasReport.find("experimental_dc_ready=true") != std::string::npos &&
          experimentalBiasReport.find("parameter_domain") != std::string::npos &&
          experimentalBiasReport.find("reliability_vgs") != std::string::npos &&
          std::find(experimentalBiasRunner.verbs.begin(), experimentalBiasRunner.verbs.end(), "publish") == experimentalBiasRunner.verbs.end(),
          "有限试点Cascode/VBIAS通过逐候选回读和最终应力实验后仍不发布");
    CHECK(readText(experimentalBiasRoot / "analysis/resolved_parameters.json").find("\"reliability_margin\":null") != std::string::npos,
          "未知MOS额定值在JSON保留null，不写NaN/Inf或假合格余量");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "CLI workflow tests passed\n";
    } else {
        std::cout << failures << " CLI workflow tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
