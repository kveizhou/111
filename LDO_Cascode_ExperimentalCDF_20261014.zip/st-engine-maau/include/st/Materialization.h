#pragma once

#include "DcSolver.h"
#include "OaPlan.h"
#include "OperatingPoint.h"
#include "VariantVerifier.h"

#include <map>
#include <string>
#include <vector>

namespace st {

struct HostStatus {
    bool ok = false;
    std::string message;
    std::string log_path;
    std::string artifact_path;
};

enum class MaterializationStage {
    ValidatePlan,
    CopyCircuit,
    WritePlan,
    ExecuteSkill,
    NominalDcCheck,
    PvtCheck,
    VerifySource,
    RegenerateNetlist,
    VerifyRoundTrip,
    PublishTarget,
    Complete,
};

struct PvtOperatingPointRequest {
    std::string corner;
    AnalysisIdentity identity;
    std::string op_dir;
};

struct GenerationRequest {
    OaMaterializationPlan plan;
    Netlist baseline;
    Netlist expected_variant;
    // The source and derived root CellViews may have different cell names, but
    // their exported Spectre subckt must keep this stable logical name.
    std::string root_subckt;
    std::string work_dir;
    std::string plan_path;
    std::string skill_script_path;
    std::vector<OaCloneMapping> publish_clone_map;
    std::map<std::string, std::vector<std::string>> parameter_groups;
    double iq_delta = 0.0;
    // 名义直流工作点检查（ExecuteSkill 之后、回读之前对 staging 变体执行）。
    // 默认 false：不涉及求解器的旧调用方保持原行为。
    bool run_nominal_dc = false;
    bool structure_only = false;
    bool experimental_dc = false;
    CellViewRef bench;
    std::string nominal_corner;
    AnalysisIdentity nominal_identity;      // dut_hash 必须是 staging 根 CellView 的哈希
    std::string nominal_op_dir;             // identity.tsv/mos.tsv 输出目录
    // 求解器选中候选时固化的真实 PDK 限值与六个 MOS 角色。最终 staging
    // OP 必须逐项复用同一校验，不能只凭“有MOS行”就发布。
    std::vector<ElectricalConstraintRequest> electrical_checks;
    std::vector<ExpectedResistor> resistor_checks;
    // Experimental all-transform selected/new MOS stress checks, without
    // imposing Cascode saturation assumptions on a shared-gate Stack.
    std::vector<ElectricalMosRole> experimental_mos_checks;
    std::vector<std::string> unverified_constraints;
    // 最终 staging 的 PVT 复验。pvt_configured=true 时 nominal_corner 已由
    // 上述名义检查覆盖；其余 Corner 逐项放在 pvt_checks 中。任一失败不发布。
    bool pvt_configured = false;
    std::vector<PvtOperatingPointRequest> pvt_checks;
    // 所有待 Sizing 参数已量化到 PDK 合法取值。旧调用方没有求解器参数，
    // 默认 true 以保持原有 ready_for_sizing 语义。
    bool parameters_quantized = true;
};

struct GenerationResult {
    bool ok = false;
    bool ready_for_sizing = false;
    bool experimental_dc_ready = false;
    bool experimental_pvt_ready = false;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    // 正式结构/DC/PVT/参数状态；实验同参数PVT单独报告，不提升正式状态。
    bool structural_ready = false;
    bool nominal_dc_ready = false;
    bool pvt_ready = false;
    bool parameters_quantized = false;
    MaterializationStage stage = MaterializationStage::ValidatePlan;
    std::string message;
    std::string log_path;
    std::string plan_path;
    std::string netlist_path;
    std::string source_netlist_path;
    std::vector<std::string> generated_netlist_paths;
    CellViewRef target;
    std::string topology_hash;
    std::map<std::string, std::vector<std::string>> parameter_groups;
    double iq_delta = 0.0;
    VariantVerificationReport verification;
    VariantVerificationReport source_verification;
};

class MaterializationHost {
public:
    virtual ~MaterializationHost() = default;
    virtual HostStatus CopyCircuits(const std::vector<OaCloneMapping>& cloneMap) = 0;
    virtual HostStatus WritePlanFile(const std::string& path,
                                     const std::string& json) = 0;
    virtual HostStatus ExecuteSkill(const std::string& workDir,
                                    const std::string& skillScriptPath,
                                    const std::string& planPath) = 0;
    // 对 staging 变体跑名义直流工作点。默认实现拒绝：不支持 OP 的宿主
    // 只要把 run_nominal_dc 保持 false 就不会走到这里。
    virtual HostStatus RunVariantOperatingPoint(
        const CellViewRef& target,
        const CellViewRef& bench,
        const AnalysisIdentity& identity,
        const std::string& identityTsvPath,
        const std::string& mosTsvPath);
    virtual HostStatus RunVariantOperatingPoint(
        const CellViewRef& target,
        const CellViewRef& bench,
        const AnalysisIdentity& identity,
        const std::string& identityTsvPath,
        const std::string& mosTsvPath,
        const std::string& resistorTsvPath);
    virtual HostStatus RegenerateNetlist(const CellViewRef& target,
                                         const std::string& logicalSubckt,
                                         Netlist& netlist) = 0;
    virtual HostStatus PublishCircuits(const std::vector<OaCloneMapping>& publishMap) = 0;
};

class TopologyVariantMaterializer {
public:
    GenerationResult Generate(const GenerationRequest& request,
                              MaterializationHost& host) const;
};

} // namespace st
