#pragma once
// =============================================================
// Types.h — 引擎公共类型：诊断码、器件类别、模型库条目、工作点
// 仅声明与轻量内联；实现分散在各模块 .cpp
// =============================================================
#include <string>
#include <vector>
#include <map>
#include <cstddef>
#include <limits>
#include <set>

namespace st {

// 诊断码：所有模块共用；Ok 以外一律视为错误，拒绝继续生成
enum class DiagCode {
    Ok = 0,
    NotFound,              // 目标 subckt / 实例不存在
    NotMos,                // 目标不是 MOS 器件
    MissingInput,          // 缺少必要工程输入（模型未登记、参数缺失等）
    BadParam,              // 参数非法（如 N 越界、电阻出搜索带）
    HeadroomInsufficient,  // cascode headroom 校验不通过
    StackCeilingExceeded,  // stack 所需最高栅压超过电源轨
    PolarityMismatch,      // 异型 cascode 极性不兼容
    BulkPolicyUnresolved,  // 无法确定合法 bulk 连接
    UnknownModel,          // 器件 master 未在 PDK/Case 目录中登记
    InvalidTerminalMap,    // 端子语义缺失、重复或与实例端子数不一致
    DuplicateOperation,    // Change Set 中 operation id 重复
    TargetConflict,        // 同一原始目标被不兼容操作重复占用
    BiasUnavailable,       // 指定来源没有可用 Bias
    BiasVoltageOutOfRange, // Bias 电压不在目标窗口或参考轨范围内
    BiasDomainMismatch,    // Bias 与目标电压域不兼容
    BiasLoadExceeded,      // 共享后的 Bias 负载超过声明容量
    BiasCurrentReferenceNotVoltage, // IREF 不能直接作为 gate 电压
    BiasTemplateNotApproved,        // 生成模板未被 PDK/Case 批准
    DeviceIncompatible,              // PDK/Case 未批准器件组合
    ResistorMappingFailed,           // 目标阻值或附加端子无法映射到 PDK 电阻
    ResistorEquivalenceUnsupported,  // 当前端口条件不能得到合法正实数等效电阻
    CriticalControlCannotReplace,    // 关键开关/动态控制 MOS 不允许替换为线性电阻
    SourceDesignProtected,            // 物化目标指向源设计，违反派生设计不可覆盖原则
    OaPlanInvalid,                    // OA 物化计划字段或操作不完整
    VariantStructureMismatch,         // OA round-trip 网表的实例/端口/连接不符合计划
    VariantParameterMismatch,         // CDF/网表化后要求参数被改写或丢失
    DeviceParameterSemanticsUnknown,  // 跨 master 时无法把 W/L/NF 映射到目标 CDF
    DeviceParameterOutOfRange,        // 继承尺寸超出目标 master 的 PDK 合法范围
    DeviceVoltageDomainMismatch,      // 器件不允许用于当前电压域
    ReliabilityLimitExceeded,         // 器件端口电压超出已声明的可靠性限值
};

struct Diagnostic {
    DiagCode code = DiagCode::Ok;
    std::string message;
};

inline bool isError(DiagCode c) { return c != DiagCode::Ok; }

// 器件类别：由 ModelDb（宿主提供）登记，引擎不臆造
// Mos is a structural D/G/S device with unproven polarity. DC/VBIAS selectors
// must continue to require MosN/MosP; never interpret Mos as either polarity.
enum class DeviceKind { MosN, MosP, Mos, Resistor, Capacitor, Subckt, Source, Other };
inline bool isMosKind(DeviceKind kind) {
    return kind == DeviceKind::MosN || kind == DeviceKind::MosP || kind == DeviceKind::Mos;
}

// 模型库条目：端子数 + 类别；MOS 端子序固定约定为 (D, G, S, B)
struct ModelInfo {
    DeviceKind kind = DeviceKind::Other;
    int terminalCount = 0;
    bool bulkAllowedSourceTied = false; // PDK 是否允许该管源衬相连（独立阱）
};

// 直流工作点（取自 Case 的 DC OP 数据；valid=false 表示未提供）
struct OpPoint {
    double vgs = 0.0;
    double vds = 0.0;   // PMOS 传绝对值
    double id = 0.0;    // 绝对值
    double vdsat = 0.0;
    bool valid = false;
};

using ModelDb = std::map<std::string, ModelInfo>;

// 端子在电路中的电气含义。实际物理顺序由 PDK/CDF/termOrder 提供，
// 结构变换代码不得把数组下标直接解释为 D/G/S/B。
enum class TerminalRole {
    Drain,
    Gate,
    Source,
    Bulk,
    Positive,
    Negative,
    Substrate,
    Well,
    Other,
};

struct TerminalBinding {
    TerminalRole role = TerminalRole::Other;
    std::size_t index = 0;
};

struct DeviceLimits {
    double min_width = 0.0;
    double max_width = std::numeric_limits<double>::infinity();
    double min_length = 0.0;
    double max_length = std::numeric_limits<double>::infinity();
    double min_resistance = 0.0;
    double max_resistance = std::numeric_limits<double>::infinity();
    double max_abs_vgs = std::numeric_limits<double>::infinity();
    double max_abs_vds = std::numeric_limits<double>::infinity();
    double max_abs_vgb = std::numeric_limits<double>::infinity();
    int max_stack_level = 100;
};

// 当前 PDK/CDF 导出的一个可量化参数约束。语义名用于求解器，CDF 名用于 OA
// 物化；离散值存在时优先于连续网格。
struct ParameterConstraint {
    std::string semantic_name;
    std::string cdf_name;
    double minimum = 0.0;
    double maximum = 0.0;
    double grid = 0.0;
    std::vector<double> discrete_values;
    bool integer_only = false;
};

struct DeviceDescriptor {
    std::string master;
    DeviceKind kind = DeviceKind::Other;
    std::size_t terminal_count = 0;
    std::map<TerminalRole, std::size_t> terminal_index;
    // OA/CDF 实例化信息由 PDK 适配器填充。索引与网表物理端子顺序一致；
    // terminal_roles_by_index 可表达多个 Other/井/衬底端，避免 map 键唯一的限制。
    std::vector<std::string> terminal_names_by_index;
    std::vector<TerminalRole> terminal_roles_by_index;
    std::map<std::string, std::string> normalized_to_cdf;
    std::string oa_library;
    std::string oa_cell;
    std::string oa_view = "symbol";
    std::string pdk_name;
    std::string pdk_version;
    std::string model_name;
    // 站点 PDK 如有权威 family/flavor 元数据可保留作诊断；
    // 同极性、不同真实 master 的 Cascode 不依赖这两个可选字段。
    std::string device_family;
    std::string flavor_id;
    std::string w_fin_formula;
    std::map<std::string, ParameterConstraint> parameter_constraints;
    std::set<std::string> model_sections;
    std::set<std::string> corners;
    // Finite native-CDF proposals, not a complete PDK legal parameter domain.
    bool native_parameter_trials = false;
    bool reliability_complete = false;
    bool bulk_rule_complete = false;
    DeviceLimits limits;
    std::set<std::string> compatible_masters;
    std::string voltage_domain;
    std::set<std::string> allowed_voltage_domains;
    bool source_drain_interchangeable = false;
    bool isolated_well = false;
};

class DeviceCatalog {
public:
    bool Add(const DeviceDescriptor& descriptor, Diagnostic& diagnostic);
    const DeviceDescriptor* Find(const std::string& master) const;
    const std::map<std::string, DeviceDescriptor>& Descriptors() const;
    bool ResolveTerminal(const std::string& master, TerminalRole role,
                         std::size_t actualTerminalCount, std::size_t& index,
                         Diagnostic& diagnostic) const;

private:
    std::map<std::string, DeviceDescriptor> descriptors_;
};

} // namespace st
