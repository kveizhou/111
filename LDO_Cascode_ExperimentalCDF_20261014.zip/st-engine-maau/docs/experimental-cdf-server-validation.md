# 原生 CDF 有限候选与隔离实验（2026-10-14）

对应 R-042 / P-043。停止把 `res_calc.il`、可读回调源码、完整尺寸域、完整额定资料作为实验前置条件。

`experimental_dc` 只表示隔离实验。实际极性、端子、Bulk、供电及 OP 映射仍需确认；已知电气限制继续执行。单 Corner DC 不能证明启动、输出性能、稳定性、最终同参数 PVT 或可靠性通过。

## 当前服务器下一步

完整包解压到原工程位置后，先运行下面的缓存准备命令。这一步不要求重编、不启动 Virtuoso/OCEAN/Spectre、不搜索 PDK、不改变旧会话或基线。

```csh
set st_exp_stamp = `date +%Y%m%d_%H%M%S`
python3 /tmpdata/maau_epc/users/k00981589/st-engine-maau/server/site/prepare_cascode_experiment.py --session "$st_work" --batch "$st_batch" >& "$st_run/logs/experiment_${st_exp_stamp}.log"
set st_rc = $status
cat "$st_run/logs/experiment_${st_exp_stamp}.log"
echo "实验准备退出码=$st_rc"
```

预期：`RESULT=INPUT_DRAFT_PREPARED`、`NATIVE_EXECUTIONS=0`、退出 0。`PENDING_BINDINGS` 汇总真正仍缺的接线/映射/实例数据；耐压与完整尺寸域不会再列为实验前置任务。

`EXPERIMENT_INPUTS_READY=false`、`RELIABILITY_VERIFIED=false`、`VBIAS_GENERATED=false` 是明确的草稿状态，不是又一次仿真失败。准备脚本不假造缺少的 N/P 极性、Bulk 策略、电阻实际参数或 CMG 映射，因此不会自动把草稿当作可运行配置。退出 2 表示已有缓存身份不一致或必要缓存不可读，返回摘要即可，不反复跑同一命令。

输出新的 `experiment_inputs_*` 目录，包含：

- `simulation_profile.draft.json`：已有 native-site Bundle、Corner/温度/变量、实际参数记录引用及哈希；`trials` 默认为空，意味着先从实际值开始。
- `pdk_facts.draft.json`：已有器件/端子/映射，未知值保持缺失。
- `preparation.json`：尚缺的最少绑定、真实电阻候选、电源候选、缓存来源；不填 CDF 默认值充当实际尺寸。

根据现有用户回传，下一次需要确认的是目标实际 N/P/Bulk、fin/CDF/CMG 映射、VBIAS 轨网，以及一个真实电阻的实际实例参数和电流读取映射。已有测量值和回调线索可以复用，不再继续查找 `res_calc.il`。

## 正式实验入口及输入合同

在最少绑定补齐后，将草稿另存为可执行配置；创建新实验会话，保留旧 `$st_work`。C++ 改动需要服务器执行 `bash scripts/build.sh`。沿用 `standalone.py inspect` 的源 Cell、Bench、cds.lib、输出目标参数，增加：

```text
--validation-scope experimental_dc
--simulation-profile /实际路径/simulation_profile.json
--pdk-rules /实际路径/pdk_facts.json
--work-dir /新的实验会话路径
```

只在新会话中 confirm/generate/open。入口要求有来源且哈希一致的 `experimental_pdk_cache`，避免重新全库发现/探测。配置中的 `experimental_parameter_seeds` 以真实 `library/cell` 为键，每个条目包含：

- `instance`：原生记录中的真实实例名；`native_records`：现有采集 JSON 的绝对路径；`native_records_sha256`：文件哈希。
- `trials`：按已证明的语义/CDF 映射列有限试点，可省略；原生实际值始终排在第一位。每个参数最多 5 个值，每个 master 的试点乘积最多 16，总名义求解预算最多 16 次。找不到可行解如实失败，不放宽电气条件。

每个选中 master 的事实至少包含 `kind`、`normalized_to_cdf`、与实际 CDF 端子对应的 `terminalRoles`、MOS 的 `bulkRule` 及其来源。Bulk 只接受两种已经实现的策略：`rail`（NMOS→VLOW，PMOS→VHIGH）或 `isolated_well`（每管 Bulk→自身 Source）；不能把未知策略字符串当作合法接法。未知耐压字段省略，有依据的耐压和电阻额定值保留。CMG 内部电压映射及电阻电流映射仍必须来自实际证据。

尺寸试点明确标记 `native_parameter_trials=true` / `parameter_domain_verified=false`。CDF 完整域无需提前整理；已知 min/max/grid/allowed 继续校验。原生回调→保存→网表/OA 回读必须逐候选经过，包括复制原 MOS 属性的新增管；回调改变值导致回读不一致就拒绝该候选。

## 结果的含义

实验成功只能输出 `experimental_dc_ready=true`、`published=false`、`ready_for_sizing=false`、`reliability_verified=false`；留在 `__STAGING`。配置过的同参数 PVT 可记录为 `experimental_pvt_ready`，不提升正式 `pvt_ready`。`open` 只打开本会话已校验的 staging。

MOS 实际 VGS/VDS/VGB、电阻实际 V/I/P 写入报告。缺失额定值通过 `unverified_constraint` / JSON null / TSV NA 表示；已知越限、必要 OP 缺失、源电路改变、错极性/Bulk/端子、回读失败仍停止。正式模式和发布入口拒绝试点元数据与实验缓存。

本地测试及进程夹具不代表服务器 Cadence 已执行；现场尚无本轮新 VBIAS、启动/稳定性或完整 PVT 通过证据。
