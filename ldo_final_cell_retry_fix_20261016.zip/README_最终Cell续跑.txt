最终实验 Cell 重试修复（2026-10-16）

适用：已部署 ldo_fresh_dc_search_20261015.zip，最新日志已显示第15点通过，随后 copy_circuit 提示 Target cellview already exists。
本次只修改两份生产源码：src/Cli.cpp、scripts/resume_cascode_experiment.py。
最终父图和生成子图使用同一运行编号，避免旧固定名冲突。无需删除已有Cell。
默认续跑优先使用本次已经选中且再次通过PDK筛选的完整参数组，重新实测。

在服务器 /tmpdata/maau_epc/users/k00981589 下执行下面一整行（沿用当前 st_batch）：
unzip -o ldo_final_cell_retry_fix_20261016.zip && bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs

这次不要加 --fresh-search：刚完成的搜索已经使用当前拓扑，该选项会主动放弃刚找到的初值。
不要加旧 --reference-resistor-scales。无需重新inspect或prepare。

根据本次已选结果，预期先显示（数值尾数允许不同）：
PREVIOUS_SELECTION_SEED_REUSED=true
PREVIOUS_DC_VERDICT_REUSED=false
FIRST_TRIAL_RESISTANCE_OHMS=505763.1232

该参数实测仍合格时，搜索第1点就停止，随后生成最终图、回读并做最终DC。
最终通过才显示：
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
RESULT_CELL=...__STAGING/...__GEN_run_NNNN__STAGING/schematic

RESULT_CELL、RESULT_NETLIST和SELECTED_PARAMETERS_FILE为实际交付位置。
READY_FOR_SIZING=false、RELIABILITY_VERIFIED=false、PUBLISHED=false保留原含义，不代表本次DC失败。
本轮验收没有输出精度、启动、稳定性或完整可靠性结论。
如果实际参数不再通过则按原最多16点继续搜索；软件/许可错误仍明确停止，不伪造成功。

验证：本地126项CLI检查、27项Python测试、tool-only编译通过。
本机未执行Cadence/Spectre，服务器最终生成/DC待本次运行确认。
源码已同步 st-engine-maau，提交 f5b19e4；无Git远程，未推送。
