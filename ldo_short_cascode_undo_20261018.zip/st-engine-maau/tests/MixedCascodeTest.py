"""Native-reader fixtures exercise the admission path, not real PDK/DC proof."""
import contextlib
import copy
import csv
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/site'))
import mixed_cascode as m
from experimental_pdk import build_experimental_metadata
from op_provider import write_tsv

class AdmissionTest(unittest.TestCase):
    def undo_fixture(self, root):
        work=root/'work'
        for d in ('before','analysis/variant_op/roundtrip','test_operations/mixed_four'):
            (work/d).mkdir(parents=True)
        (work/'session.conf').write_text('core_subckt=core\n')
        ops=work/'test_operations/mixed_four'
        (ops/'01.conf').write_text('id=op_I21\ntype=same_type_cascode\ninstance=I21\n')
        (ops/'02.conf').write_text('id=op_I105\ntype=cross_flavor_cascode\ninstance=I105\nnew_master=P_ALT\n')
        (work/'before/mos_inventory.tsv').write_text(
            'instance\tpolarity\tmaster\tcross_flavor_candidates\nI21\tNMOS\tN\t\nI105\tPMOS\tP\tP_ALT\n')
        devices=[dict(master=k,kind='mos_n' if k=='N' else 'mos_p',oa_library='PDK',oa_cell=k,
                      bulk_rule_complete=True,terminal_roles=['gate','drain','bulk','source']) for k in ('N','P','P_ALT')]
        (work/'analysis/pdk_catalog.json').write_text(json.dumps(dict(devices=devices)))
        before='subckt core d g s b pd pg ps pb\nI21 (g d b s) N l=240n\nI105 (pg pd pb ps) P l=134n\nends core\n'
        (work/'before/core_before.scs').write_text(before)
        actual=('subckt core d g s b pd pg ps pb\nI21 (d g s b vb) WRAPPER\nI105 (pg pd pb ps) P l=134n\n'
                'I_VBIAS_N_I21 (vb b) BIAS\nends core\nsubckt WRAPPER D G S B VB\n'
                'I21 (G MID B S) N l=240n\nI21_CAS (VB D B MID) N l=240n\nends WRAPPER\n'
                'subckt BIAS OUT LOW\nR_REF_N (OUT LOW) R r=500K\nends BIAS\n')
        readback=work/'analysis/variant_op/roundtrip/complete.scs'
        readback.write_text(actual)
        return work,readback,actual

    def test_undo_verifies_actual_d_side_structure_and_restores_second_target(self):
        for mode in ('good','wrong_master','wrong_connection','source_side','changed_gate','different_cas',
                     'leftover_bias','leftover_cas','wrong_pair','same_target','unadmitted'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()) as output:
                work,path,text=self.undo_fixture(Path(d))
                if mode=='wrong_master':text=text.replace(') P l=',') P_ALT l=')
                if mode=='wrong_connection':text=text.replace('(pg pd pb ps)','(pg pd pb b)')
                if mode=='source_side':text=text.replace('I21 (G MID B S)','I21 (G D B MID)').replace('(VB D B MID)','(VB MID B S)')
                if mode=='changed_gate':text=text.replace('I21 (G MID B S)','I21 (VB MID B S)')
                if mode=='different_cas':text=text.replace('I21_CAS (VB D B MID) N','I21_CAS (VB D B MID) P')
                if mode=='leftover_bias':text=text.replace('ends core','_I_VBIAS_P_I105 (pg pb) BIAS\nends core')
                if mode=='leftover_cas':text=text.replace('ends core','I105_CAS (pg pd pb ps) P\nends core')
                op=work/'test_operations/mixed_four/02.conf'
                if mode=='wrong_pair':op.write_text(op.read_text().replace('cross_flavor','same_type'))
                if mode=='same_target':op.write_text(op.read_text().replace('instance=I105','instance=I21'))
                if mode=='unadmitted':op.write_text(op.read_text().replace('P_ALT','N'))
                path.write_text(text)
                if mode=='good':
                    m.verify_same_after_undo(work)
                    self.assertIn('SAME_CASCODE_D_SIDE=PASS',output.getvalue())
                    self.assertIn('UNDONE_TARGET_RESTORED=I105',output.getvalue())
                else:
                    with self.assertRaises(ValueError):m.verify_same_after_undo(work)

    def fixture(self,root):
        work=root/'work';(work/'before').mkdir(parents=True);(work/'analysis').mkdir();(work/'changes').mkdir()
        (work/'session.conf').write_text('validation_scope=experimental_dc\n')
        (work/'changes/old.conf').write_text('id=old\n')
        devices=[dict(master=k,kind='mos_n' if k=='N' else 'mos_p',oa_library='PDK',oa_cell=k,
                      model_name='nmod' if k=='N' else 'pmod',bulk_rule_complete=True,isolated_well=False)
                 for k in ('N','P')]
        (work/'analysis/pdk_catalog.json').write_text(json.dumps(dict(devices=devices)))
        (work/'before/mos_inventory.tsv').write_text('instance\tpolarity\tmaster\tdrain\tgate\tsource\tbulk\tcross_flavor_candidates\n'+
            ''.join(f'{n}\t{k}MOS\t{k}\tD\tG\tS\tB\t\n' for n,k in [('I21','N'),('I85','N'),('I105','P'),('I29','P')]))
        directory=root/'original';directory.mkdir()
        deck='simulator lang=spectre\nglobal 0\nsubckt core AVDD AGND D G S\n'+\
            ''.join(f'{n} (D G S {"AGND" if k=="N" else "AVDD"}) {"nmod" if k=="N" else "pmod"} l=100n\n'
            for n,k in [('I21','N'),('I85','N'),('I105','P'),('I29','P')])+\
            'I93\\<5\\>.M0 (D G S AGND) nmod l=100n\nI93\\<5\\>.M1 (D G S AVDD) pmod l=100n\nends core\nTOP (VDD 0 d g s) core\n'
        (directory/'simulation.scs').write_text(deck)
        (work/'before/core_before.scs').write_text(deck)
        header=['instance','oa_library','oa_cell','oa_view','terminal_names','classification','model_name']
        bindings=[[n,'PDK',k,'symbol','D,G,S,B','target','nmod' if k=='N' else 'pmod']
                  for n,k in [('I21','N'),('I85','N'),('I105','P'),('I29','P')]]
        bindings += [[f'I93<5:0>.M{i}','ALT',k,'symbol','D,G,S,B','non_target',model]
                     for i,k,model in [(0,'N2','nmod'),(1,'P2','pmod')]]
        write_tsv(directory/'oa_bindings.tsv',header,bindings)
        probe=root/'probe.tsv'
        fields=['oa_library','oa_cell','model_name','terminal_names','parameter','units','min','max','default_value','has_schematic']
        rows=[]
        for lib,cell,model in [('PDK','N','nmod'),('PDK','P','pmod'),('ALT','N2','nmod'),('ALT','P2','pmod')]:
            for p,u,v in [('l','lengthMetric','100n'),('nfin','','4'),('m','','1'),('fingers','','2')]:
                rows.append([lib,cell,model,'D,G,S,B',p,u,'','','999','false'])
        write_tsv(probe,fields,rows)
        bundle=dict(root_path='TOP',source=dict(lib='SOURCE',cell='core',view='schematic'))
        return work,directory,bundle,probe

    def native_outputs(self,entries,output):
        records=[];nodes={};ops=[]
        for e in entries:
            scope=e['scope'];kind=e.get('required_kind') or ('mos_n' if e['key'].endswith('N2') else 'mos_p')
            lib,cell=e['key'].split('/');model=e['path']+'.model.4'
            def add(k,n,v,raw=False):records.append(dict(kind=k,scope=scope,name=n,status='OK',raw_value=v if raw else json.dumps(v)))
            add('read_status','complete','OK')
            for k,v in [('oa_library',lib),('oa_cell',cell),('oa_view','symbol')]:add('source',k,v)
            for k,v in dict(l='100n',nfin='4',m='1',fingers='2',model=e['model']).items():add('cdf_value',k,v)
            add('cdf_mapping','termOrder','(D G S B)',True)
            add('model_binding','instance_model','('+json.dumps(e['path'])+' '+json.dumps(model)+')',True)
            add('model_type','type',1 if kind=='mos_n' else 0)
            (output/(scope+'_model_type.txt')).write_text('Type : bsimcmg\n'+model+'\ntype = '+('1' if kind=='mos_n' else '0')+'\n')
            for n in e['nodes']:
                if n!='0':nodes[n]=dict(kind='node',signal=n,value='1.1' if n=='VDD' else '.3',status='OK')
            ops.append(dict(kind='device',signal=e['path'],parameter='',value='bsimcmg',status='META'))
            ops += [dict(kind='op',signal=e['path'],parameter=k,value=str(v),status='OK') for k,v in
                    dict(id=1e-6,vth=.3,vdssat=.1,cgg=1e-15,vgs=.4,vds=.3).items()]
        (output/'native_records.json').write_text(json.dumps(records))
        return records,list(nodes.values()),ops

    def test_used_master_selection_keeps_oa_array_and_scalar_psf_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            work,d,b,probe=self.fixture(Path(tmp))
            targets,options,ports=m.select_used_masters(work,d,b,probe)
            self.assertEqual(len(targets),4);self.assertEqual(len(options),2)
            self.assertEqual(ports['AGND'],'0');self.assertEqual(options[0]['oa_path'],'I93<5:0>.M0')
            self.assertEqual(options[0]['path'],'TOP.I93<5>.M0')
            self.assertEqual({e['key'] for e in options},{'ALT/N2','ALT/P2'})
            self.assertEqual((work/'changes/old.conf').read_text(),'id=old\n')
            code=m.native_script(b,targets+options,Path(tmp)/'psf','/init.il',Path(tmp))
            self.assertIn('list("I93<5:0>" "M0")',code)
            self.assertIn('"TOP.I93<5>.M0"',code)
            self.assertNotIn('dbSave',code);self.assertNotIn('run()',code)
            # Balanced syntax outside strings/comments catches script assembly errors.
            clean=re.sub(r'"(?:\\.|[^"\\])*"|;[^\n]*','',code)
            depth=0
            for ch in clean:
                if ch=='(':depth+=1
                elif ch==')':depth-=1
                self.assertGreaterEqual(depth,0)
            self.assertEqual(depth,0)

    def test_native_proofs_and_actual_seed_feed_real_metadata_builder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);work,d,b,probe=self.fixture(root)
            targets,options,ports=m.select_used_masters(work,d,b,probe)
            records,nodes,ops=self.native_outputs(targets+options,root)
            profile=dict(validation_scope='experimental_dc',vbias_vhigh_net='AVDD',vbias_vlow_net='AGND',experimental_parameter_seeds={})
            rules=dict(source=str(root/'native_records.json'),devices={})
            for e in options:
                rule,seed,raw,sources=m.validate_entry(e,records,nodes,ops,ports,profile,root)
                profile['experimental_parameter_seeds'][e['key']]=seed;rules['devices'][e['key']]=rule
                self.assertEqual(sources[e['path']+':vdssat']['device_type'],'bsimcmg')
            data=build_experimental_metadata(root,probe,profile,rules)
            self.assertEqual({d['kind'] for d in data['devices']},{'mos_n','mos_p'})
            self.assertEqual(data['devices'][0]['actual_parameter_seed']['fin'],4)
            self.assertFalse(data['parameter_domain_verified'])
            for mode in ('wrong_polarity','wrong_bulk','wrong_model','wrong_terminal','wrong_report','missing_op'):
                entry=copy.deepcopy(options[0]);rs=copy.deepcopy(records);nr=copy.deepcopy(nodes);op=copy.deepcopy(ops)
                if mode=='wrong_polarity':entry['required_kind']='mos_p'
                if mode=='wrong_bulk':entry['nodes'][3]='VDD'
                if mode=='wrong_model':entry['model']='different'
                if mode=='wrong_terminal':entry['terminal_names']=['G','D','S','B']
                if mode=='wrong_report':
                    (root/(entry['scope']+'_model_type.txt')).write_text('Type : bsimcmg\nwrongmodel\ntype = 1\n')
                if mode=='missing_op':op=[r for r in op if r['parameter']!='vdssat']
                with self.subTest(mode=mode),self.assertRaises(ValueError):m.validate_entry(entry,rs,nr,op,ports,profile,root)
                self.native_outputs(targets+options,root)

    def test_preserved_original_tuples_do_not_create_a_new_parameter_search(self):
        from ExperimentalPdkTest import ExperimentalPdkTest
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);probe,native,profile,rules=ExperimentalPdkTest().fixture(root)
            records=json.loads(native.read_text())
            extra=[dict(r,scope='M1',raw_value='"240n"' if r['name']=='l' else '"12"' if r['name']=='nfin' else r['raw_value']) for r in records]
            path=root/'other.json';path.write_text(json.dumps(extra))
            profile['experimental_preserved_seeds']={'PDK/opaque':[dict(instance='M1',native_records=str(path),native_records_sha256=m.digest(path))]}
            data=build_experimental_metadata(root,probe,profile,rules);dev=data['devices'][0]
            self.assertEqual(len(dev['constraints']['length']['allowed']),2)
            self.assertAlmostEqual(dev['constraints']['length']['allowed'][1]/240e-9,1)
            self.assertEqual(dev['constraints']['fin']['allowed'],[6,5,7,12])
            self.assertEqual(dev['native_trial_combinations'],3)
            self.assertFalse(dev['parameter_domain_verified'])
            rules['devices']['PDK/opaque']['constraints']={'length':{'max':200e-9}}
            with self.assertRaises(ValueError):build_experimental_metadata(root,probe,profile,rules)

    def test_expanded_catalog_reuses_export_and_reads_extra_saved_targets(self):
        from ExperimentalReuseTest import ReuseIntegrationTest
        import experiment_reuse as reuse
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);parent,inputs,bundle=ReuseIntegrationTest().fixture(root,peripheral_mos=1)
            old=parent/'work';directory=next((old/'analysis/baseline_op/raw_op').iterdir())
            with (directory/'oa_bindings.tsv').open('a') as out:out.write('PERIPH0\tP\tN\tsymbol\tD,G,S,B\ttarget\tnmod\n')
            child=root/'mixed';work=child/'work';work.mkdir(parents=True)
            for folder in ('before','changes'):shutil.copytree(old/folder,work/folder)
            (work/'changes/002.conf').write_text('instance=PERIPH0\n')
            (work/'session.conf').write_text((old/'session.conf').read_text().replace('pdk_version=p','pdk_version=new'))
            scan=work/'analysis/pdk_scan/inspect';scan.mkdir(parents=True)
            source=old/'analysis/pdk_scan/run_0001'
            (scan/'raw_catalog.tsv').write_text((source/'raw_catalog.tsv').read_text().replace('\tp\t','\tnew\t'))
            shutil.copyfile(source/'pdk_identity.tsv',scan/'pdk_identity.tsv')
            profile=json.loads(Path(inputs['rules']).read_text());profile['experimental_source_export']=str(directory)
            bridge=Path(bundle['_bundle_path']).parent.parent
            rawfile=bridge/'raw_signed.tsv'
            from op_provider import read_raw
            raw=read_raw(rawfile)
            origins=json.loads((rawfile.parent/'raw_signed.tsv.sources.json').read_text())['sources']
            extra={k.replace('M0','PERIPH0'):v for k,v in raw.items() if 'M0:' in k}
            extra_origins={k.replace('M0','PERIPH0'):dict(v,signal=v['signal'].replace('M0','PERIPH0')) for k,v in origins.items() if 'M0:' in k}
            dc=child/'extra.json';dc.write_text(json.dumps(dict(source=bundle['source'],bundle=bundle['_bundle_path'],raw=extra,sources=extra_origins)))
            profile['experimental_source_dc']=str(dc)
            newinputs=dict(inputs,rules=str(child/'profile.json'),tech=str(child/'tech.json'))
            Path(newinputs['rules']).write_text(json.dumps(profile))
            tech=json.loads(Path(inputs['tech']).read_text());tech[0]['version']='new';Path(newinputs['tech']).write_text(json.dumps(tech))
            with patch('subprocess.run',side_effect=AssertionError('no baseline resimulation')):
                receipt=reuse.prepare_receipt(child,newinputs)
            self.assertEqual([r[0] for r in receipt['mos_rows']],['M0','PERIPH0'])
            self.assertEqual(receipt['pdk_version'],'new');self.assertEqual(receipt['catalog'],str((scan/'raw_catalog.tsv').resolve()))
            bad=json.loads(dc.read_text());bad['source']['cell']='different';dc.write_text(json.dumps(bad))
            with self.assertRaisesRegex(ValueError,'source/bundle'):reuse.prepare_receipt(child,newinputs)

    def test_prepare_automatically_connects_native_read_metadata_and_four_operations(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            root=Path(tmp).resolve();work,d,b,probe=self.fixture(root)
            retained=work/'analysis/baseline_op/raw_op/st-op-simulation.fixture'
            retained.parent.mkdir(parents=True);shutil.move(str(d),str(retained));d=retained
            targets,options,ports=m.select_used_masters(work,d,b,probe)
            original=root/'original_binding';original.mkdir()
            records,nodes,ops=self.native_outputs(targets+options,original)
            profile=dict(validation_scope='experimental_dc',nominal_corner='TT',pvt_corners=[],
                op_corners={'TT':dict(temperature=27,models=[],variables={})},
                vbias_vhigh_net='AVDD',vbias_vlow_net='AGND',experimental_parameter_seeds={},
                validated_baseline_bundle=str(root/'bridge/bundle/baseline_bundle.json'),
                experimental_pdk_cache=dict(probe=str(probe),probe_sha256=m.digest(probe),pdk_roots=[str(root)],source_dut=b['source']))
            rules=dict(source=str(original/'native_records.json'),devices={})
            for e in (targets[0],targets[2]):
                rule,seed,_,_=m.validate_entry(e,records,nodes,ops,ports,profile,original)
                rules['devices'][e['key']]=rule;profile['experimental_parameter_seeds'][e['key']]=seed
            tech=build_experimental_metadata(root,probe,profile,rules)
            archive=work/'analysis/standalone_inputs';archive.mkdir()
            inputs=dict(rules=str(archive/'profile.json'),tech=str(archive/'tech.json'),init='/init.il')
            (archive/'profile.json').write_text(json.dumps(profile));(archive/'tech.json').write_text(json.dumps([tech]));(archive/'provider_inputs.json').write_text(json.dumps(inputs))
            with (work/'session.conf').open('a') as f:
                for k,v in dict(source_library='SOURCE',source_cell='core',source_view='schematic',core_subckt='core',pdk_version=tech['version']).items():f.write(k+'='+v+'\n')
            b.update(_bundle_path=profile['validated_baseline_bundle'],corner='TT',temperature=27,models=[],variables={},
                     bench_netlist=str(d/'simulation.scs'),source_subckt='core',bench=dict(lib='TB',cell='tb',view='config'),cds_lib=str(root/'cds.lib'))
            (d/'binding.json').write_text(json.dumps(dict(dut=['SOURCE','core','schematic'],root_path='TOP')))
            psf=root/'baseline_results/psf';psf.mkdir(parents=True);(psf/'dcOpInfo.info').touch()
            calls=[]
            def native(argv,directory,env,timeout,log):
                self.assertEqual(argv[1:3],['-nograph','-restore']);self.assertNotIn('ST_PREPARED_JSON_FILE',env)
                rs,ns,ops=self.native_outputs(targets+options,directory)
                (directory/'native.tsv').write_text(''.join('ST_MAE_RECORD\t'+r['kind']+'\t'+json.dumps(r['scope'])+'\t'+json.dumps(r['name'])+'\tOK\t'+r['raw_value']+'\n' for r in rs)+'ST_MAESTRO_SETUP_READ_COMPLETE\n')
                for name,rows in [('nodes.tsv',ns),('ops.tsv',ops)]:
                    with (directory/name).open('w') as out:
                        writer=csv.DictWriter(out,fieldnames=list(rows[0]),delimiter='\t');writer.writeheader();writer.writerows(rows)
                (directory/'runtime.done').write_text('OK\n')
            def runner(stage,argv,output,timeout,env=None):
                calls.append(stage)
                if stage!='inspect':return
                new=output/'work';(new/'before').mkdir(parents=True);(new/'analysis/standalone_inputs').mkdir(parents=True)
                (new/'session.conf').write_text('validation_scope=experimental_dc\ncore_subckt=core\n')
                shutil.copyfile(work/'before/core_before.scs',new/'before/core_before.scs')
                profile_path=Path(argv[argv.index('--simulation-profile')+1]);facts=Path(argv[argv.index('--pdk-rules')+1])
                expanded=build_experimental_metadata(root,probe,json.loads(profile_path.read_text()),json.loads(facts.read_text()))
                self.assertEqual(len(expanded['devices']),4)
                devices=[]
                for dev in expanded['devices']:
                    devices.append(dict(master=dev['cell'],kind=dev['kind'],oa_library=dev['oa_library'],oa_cell=dev['cell'],bulk_rule_complete=True,isolated_well=False))
                (new/'analysis/pdk_catalog.json').write_text(json.dumps(dict(devices=devices)))
                inv=(work/'before/mos_inventory.tsv').read_text().replace('\tB\t\n','\tB\tPLACEHOLDER\n')
                (new/'before/mos_inventory.tsv').write_text('\n'.join(line.replace('PLACEHOLDER','N2' if '\tNMOS\t' in line else 'P2') for line in inv.splitlines())+'\n')
                (new/'analysis/standalone_inputs/provider_inputs.json').write_text(json.dumps(dict(rules=str(profile_path))))
            with patch('baseline_bundle.load_bundle',return_value=b),patch('standalone.environment',return_value={'ST_PREPARED_JSON_FILE':'old'}),\
                 patch('collect_cascode_batch.executable',return_value='/ocean'),patch('collect_cascode_batch.command',side_effect=native) as command,\
                 patch.object(m,'run_stage',side_effect=runner):
                destination=m.prepare(root)
                self.assertEqual(command.call_count,1)
                self.assertEqual(m.prepare(root),destination)
                self.assertEqual(command.call_count,1)
            self.assertEqual(calls,['prepare','inspect'])
            ops=destination/'work/test_operations/mixed_four'
            self.assertEqual([m.pairs(ops/('%02d.conf'%i))['instance'] for i in range(1,5)],['I21','I105','I29','I85'])
            self.assertEqual((work/'changes/old.conf').read_text(),'id=old\n')
            self.assertEqual(Path((work/'test_operations/mixed_four/candidate.txt').read_text().strip()),destination)
            changed=destination/'work/before/core_before.scs'
            changed.write_text(changed.read_text().replace('I21 (D G S AGND)','I21 (D S G AGND)'))
            with self.assertRaisesRegex(ValueError,'source target changed'):
                m.unchanged_targets(work,destination/'work',['I21'])

if __name__=='__main__':unittest.main()
