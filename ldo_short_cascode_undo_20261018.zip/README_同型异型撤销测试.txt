同型、异型、撤销异型、最终生成（2026-10-18）

本包适用于已安装累积Cascode版本、已有mixed_four会话的服务器。
只更新Python/Shell，st-engine-maau为同步后的当前源码，不需要重新编译C++。

上传压缩包到st-engine-maau所在目录，然后执行这一整行：
unzip -o ldo_short_cascode_undo_20261018.zip && bash st-engine-maau/scripts/test_mixed_cascode.sh same-cross-undo "$st_batch/candidate_I21_xbb892w0"

命令自动定位已有混合会话，重设该测试会话的活动操作：
1. 确认I21同型Cascode（只记操作，不搜索、不生成OA）。
2. 确认I105异型Cascode（只记操作，不搜索、不生成OA）。
3. 撤销最后一项I105，只保留I21。
4. 只调用一次最终generate：I21最多16次自动搜索，首个合格即停；保留最终OA回读及DC复验。
5. 读取实际生成网表，检查同型在D侧、原G/S/B保持、I105恢复原型号/连接、无I105 Cascode/VBIAS残留。
这里的I21/I105来自已准备的01/02.conf；如原测试选择不同目标，输出会显示实际目标。

前置与操作顺序预期：
TEST_SEQUENCE=same,cross,undo_cross,generate
SAME_TARGET=I21
CROSS_TARGET=I105
INTERMEDIATE_DC_SEARCHES=0
ACTIVE_GROUPS=1
ACTIVE_GROUPS=2
CROSS_OPERATION_UNDONE=true
ACTIVE_GROUPS=1

当前保存的I21已解完整元组仍被本次PDK接受时，预期：
INITIAL_SEED_FROM_OPERATION=op_I21
PREVIOUS_SELECTION_SEED_REUSED=true
PREVIOUS_DC_VERDICT_REUSED=false
FIRST_TRIAL_RESISTANCE_OHMS=505763.1232
以上初值只改变搜索顺序，不保证本次首点一定通过。

仅真实最终生成、回读和最低DC均成功时，末尾应有：
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
TEST_GROUPS=1
GENERATED_SUBCELLS=2
RESULT_CELL=实际生成的库/Cell/schematic
SAME_CASCODE_D_SIDE=PASS
ORIGINAL_GSB_PRESERVED=PASS
UNDONE_TARGET_RESTORED=I105
UNDONE_CASCODE_VBIAS_ABSENT=PASS
FINAL_RETAINED=same_type_cascode:I21
SAME_CROSS_UNDO_TEST=PASS

两个子Cell是同型Cascode封装和VBIAS。异型已撤销，不进行其16点搜索；因此本轮不验证异型电气可用性。待优化候选或执行/读取失败不能显示本测试PASS。许可证仍由服务器提供，本包不改变许可证要求。

成功后如需打开最终电路：
bash st-engine-maau/scripts/test_mixed_cascode.sh open "$st_batch/candidate_I21_xbb892w0"

本地验证：47项相关Python测试及Shell语法检查通过；未运行原生Cadence/Spectre。
