电阻回调上下文与错误处理修复

适用：已经解压 ldo_resistor_pdk_check_fix_20261015.zip 的现有 st-engine-maau。
只替换 server/site/experimental_pdk.py，无需重编译 C++。

在服务器 /tmpdata/maau_epc/users/k00981589 下，整行执行：
unzip -o ldo_resistor_callback_context_fix_20261015.zip && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs

本次改动：
1. 参数预筛使用现有源电路库、已选MOS库的正常初始化上下文，然后打开所选电阻。
2. 同一次Virtuoso先执行已有电阻种子参数；若失败，立刻显示原始回调错误，不再重复800次并笼统称参数不合法。
3. 调整点仍需通过参数回读和已有PDK规则，异常/越界/被改写的点不会进入DC。

筛选成功时预期：
RESISTOR_PDK_SEED=CALLBACK_OK
RESISTOR_PDK_ACCEPTED_POINTS=<实际数量，大于0>
RESISTOR_PDK_CHECK=PASS
随后自动进入原有最多16次DC搜索。
800是参数预筛候选数量，不是800次DC。

如果种子回调仍不能执行，预期：
RESISTOR_PDK_SEED=EXECUTION_FAILED
ISSUE original resistor seed callback failed; adjustment range not evaluated: <原生具体错误>
这个结果不表示800个阻值非法，也不表示电气验证失败。原命令会直接给出原因，无需另跑诊断脚本。

最终维持原有结果区别：满足最低DC条件，或输出明确标记的待优化候选；执行失败仍为INCOMPLETE，不能冒充电气通过。

本地86项相关Python测试、语法及差异检查通过。原生调用使用测试替身；本机无Cadence/Spectre，实际服务器上下文修复效果与电气结果尚待验证。旧日志未保留原始回调异常，不能宣称已经证实800点失败的具体原因。
本批不改模板、电气条件或16点预算，不增加用户配置/命令、备份或全PDK扫描。
