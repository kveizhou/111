#!/usr/bin/env python3
"""Continue generate in the existing failed experiment; no rebuild/re-inspect.

Kept outside server/site so old sessions' pinned Python modules stay unchanged.
The existing input verification and all experimental circuit gates still run.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/site'))
from run_cascode_experiment import StageFailure, pairs, run_stage, validate_result
from site_data import read_json, write_json, verify_site_inputs
from inspect_cascode_pdk_evidence import latest


def resume(candidate, timeout, runner=run_stage):
    candidate=Path(candidate).resolve();work=candidate/'work'
    status_path=candidate/'run_status.json'
    previous=list(candidate.glob('resume_generate_*/run_status.json'))
    if previous:status_path=latest(previous)
    previous_status=read_json(status_path)
    if previous_status.get('failed_stage')!='generate' or previous_status.get('result')!='INCOMPLETE':
        raise ValueError('latest attempt is not a failed generate; refusing to repeat other stages')
    if pairs(work/'session.conf').get('validation_scope')!='experimental_dc':
        raise ValueError('resume requires the existing experimental_dc session')
    if not list((work/'changes').glob('*.conf')):
        raise ValueError('confirmed operation missing; no automatic confirm')
    manifest=read_json(work/'analysis/standalone_inputs/provider_inputs.json')
    verify_site_inputs(manifest)
    inputs=read_json(candidate/'inputs.json')
    for name,digest in inputs.get('input_sha256',{}).items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:
            raise ValueError('bound experiment input changed: '+name)
    if not os.access(ROOT/'build/bin/st_circuit_tool',os.X_OK):
        raise ValueError('compiled tool missing; no automatic rebuild during resume')
    output=Path(tempfile.mkdtemp(prefix='resume_generate_',dir=str(candidate)))
    if (work/'logs').is_dir():shutil.copytree(work/'logs',output/'previous_work_logs')
    argv=[sys.executable,str(ROOT/'server/site/standalone.py'),'generate','--session',str(work)]
    write_json(output/'command.json',argv)
    status=dict(checker='cascode-experiment-resume-v1',result='INCOMPLETE',
                candidate=str(candidate),experimental_dc_ready=False,ready_for_sizing=False,
                reliability_verified=False,published=False)
    print('CHECKER='+status['checker']+'\nCANDIDATE_DIR='+str(candidate)+'\nOUTPUT_DIR='+str(output),flush=True)
    print('RESUME_STAGE=generate\nREBUILD=false\nINSPECT_REUSED=true\nCONFIRM_REUSED=true',flush=True)
    try:
        runner('generate',argv,output,timeout)
        report=pairs(work/'reports/validation.txt');validate_result(report)
        status.update(result='EXPERIMENT_DC_PASS',experimental_dc_ready=True,validation=report)
    except StageFailure as error:
        status.update(issue=str(error),failed_stage='generate',native_exit_code=error.code)
        if error.log.is_file():
            for line in error.log.read_text(errors='replace').splitlines()[-24:]:print('STAGE_LOG '+line[:900])
        logs=sorted(work.rglob('*.log'),key=lambda p:p.stat().st_mtime_ns,reverse=True)
        for log in logs[:3]:
            print('DETAIL_LOG='+str(log))
            for line in log.read_text(errors='replace').splitlines()[-10:]:print('DETAIL '+line[:700])
    except (OSError,ValueError,KeyError,TypeError) as error:
        status.update(issue=str(error),failed_stage='generate')
    except KeyboardInterrupt:
        status.update(issue='interrupted; no automatic retry',failed_stage='generate')
    write_json(output/'run_status.json',status)
    print('DETAILS_FILE='+str(output/'run_status.json')+'\nRESULT='+status['result'])
    if status.get('issue'):print('ISSUE '+status['issue'])
    print('EXPERIMENTAL_DC_READY='+str(status['experimental_dc_ready']).lower())
    print('READY_FOR_SIZING=false\nRELIABILITY_VERIFIED=false\nPUBLISHED=false')
    return 0 if status['experimental_dc_ready'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--batch',help='select the latest candidate from this batch')
    source.add_argument('--candidate',help='explicit candidate directory')
    parser.add_argument('--stage-timeout',type=int,default=1800)
    args=parser.parse_args()
    try:
        if args.stage_timeout<=0:raise ValueError('timeout must be positive')
        candidate=Path(args.candidate).resolve() if args.candidate else latest(Path(args.batch).resolve().glob('candidate_*/run_status.json')).parent
        return resume(candidate,args.stage_timeout)
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('CHECKER=cascode-experiment-resume-v1\nRESULT=INCOMPLETE\nISSUE '+str(error))
        print('EXPERIMENTAL_DC_READY=false\nPUBLISHED=false')
        return 2


if __name__=='__main__':raise SystemExit(main())
