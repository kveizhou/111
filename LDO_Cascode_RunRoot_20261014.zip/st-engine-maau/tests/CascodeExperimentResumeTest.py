"""Resume contracts with pinned file fixtures; no Cadence runs."""
import contextlib
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))


class ResumeTest(unittest.TestCase):
    def module(self):return importlib.import_module('resume_cascode_experiment')

    def fixture(self,root):
        candidate=root/'candidate_I21_test';work=candidate/'work'
        inputs=work/'analysis/standalone_inputs';inputs.mkdir(parents=True)
        (work/'changes').mkdir();(work/'changes/001.conf').write_text('id=one\ninstance=I21\n')
        (work/'logs').mkdir();(work/'logs/old.log').write_text('original failure')
        (work/'session.conf').write_text('validation_scope=experimental_dc\n')
        (candidate/'inputs.json').write_text(json.dumps(dict(target='I21',input_sha256={})))
        (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',failed_stage='generate')))
        manifest={}
        for key in ('context','rules','tech','adapter','runtime'):
            p=inputs/(key+'.json');p.write_text(json.dumps(dict(validation_scope='experimental_dc')))
            manifest[key]=str(p)
        manifest['file_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in manifest.values()}
        (inputs/'provider_inputs.json').write_text(json.dumps(manifest))
        return candidate,manifest

    def test_resumes_only_generate_keeps_existing_inputs_and_logs(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            root=Path(d).resolve();candidate,manifest=self.fixture(root);calls=[]
            protected={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
            def run(stage,argv,output,timeout):
                calls.append(argv)
                report=candidate/'work/reports/validation.txt';report.parent.mkdir()
                report.write_text('ok=true\nvalidation_scope=experimental_dc\nexperimental_dc_ready=true\nready_for_sizing=false\nreliability_verified=false\npublished=false\nstructural_ready=true\nparameters_quantized=true\nstage=complete\ntarget=X__STAGING/Y/schematic\n')
            result=m.resume(candidate,10,runner=run)
            self.assertEqual(result,0)
            self.assertEqual(len(calls),1)
            self.assertEqual(calls[0][2:],[ 'generate','--session',str(candidate/'work')])
            self.assertTrue(all(p.read_bytes()==data for p,data in protected.items()))
            attempt=next(candidate.glob('resume_generate_*'))
            self.assertEqual((attempt/'previous_work_logs/old.log').read_text(),'original failure')

    def test_drift_and_non_generate_failure_do_not_run_native(self):
        m=self.module()
        for mode in ('drift','not_generate','no_changes'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                candidate,manifest=self.fixture(Path(d).resolve())
                if mode=='drift':Path(manifest['rules']).write_text('{}')
                elif mode=='not_generate':(candidate/'run_status.json').write_text('{"failed_stage":"inspect"}')
                else:(candidate/'work/changes/001.conf').unlink()
                with self.assertRaises((ValueError,OSError)):
                    m.resume(candidate,10,runner=lambda *a: self.fail('must not run'))

    def test_failure_is_retained_without_success_promotion(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            candidate,_=self.fixture(Path(d).resolve())
            def failed(stage,argv,output,timeout):
                log=output/'generate.log';log.write_text('next actual failure')
                raise m.StageFailure(stage,3,log)
            self.assertEqual(m.resume(candidate,10,runner=failed),2)
            status=json.loads(next(candidate.glob('resume_generate_*/run_status.json')).read_text())
            self.assertEqual(status['native_exit_code'],3)
            self.assertFalse(status['experimental_dc_ready'])


if __name__=='__main__':unittest.main()
