# LDO 结构变换与自动 VBIAS：统一需求、设计与开发交接

## 2026-10-14 用户最新开发约束（R-061）

禁用Superpowers插件和技能，适用于当前、后续和其它对话。开发仅限明确功能和必要正确性检查；不得主动增加备份、容灾、安全加固、完整依赖封存、多层哈希/审计/复杂版本迁移等机制，也不得将它们作为功能前置门槛。不重复已成功步骤，不不断新增诊断工具替代修复主调用链。保留LDO实际器件/端口/连线/参数、真实候选仿真和用户要求的验收；不得伪造验证结果。本条覆盖旧文档中主动扩大的流程要求。

插件与手动副本已删除，全局规则已保存。R-061当时仅修改规则；随后R-065已按下述范围收缩实验执行代码。最新候选DC结果见下一节；完整功能仍待验证。

## 2026-10-15 最新状态：修复r属性没有驱动实际电阻几何（R-069/P-070/C-073）

服务器三个试点均收敛但saturation失败；candidate_010期望772.15744kΩ，OA回读r正确，但实际Spectre为lr=10u、wr=1u，实测V/I约5.88kΩ。不能把这次结果当作三个目标阻值均已评估，不能因此跳过饱和检查。上一节仅写r/m的方案已被本条替代。

现有resume使用已读25段、每段2.4u/800n的种子，按8/4/16倍联动r/segments/cktL（200/100/400段，480u/240u/960u总长度），其余MOS/模板接线不变。Cli和DcSolver按组选择；OA回读必须保留显式尺寸；op_provider在真实Spectre启动前检查该参考电阻实际lr/wr/mr、段数和串联连线。只有尺寸真正进入native网表才继续DC。不重扫PDK、不重复成功基线、不增加诊断脚本或版本门槛。

本地61项Python测试、三组C++测试和工具编译通过；这些是夹具/回放验证，真实CDF是否接受新段数、候选饱和和功能验收仍需服务器。交付ldo_resistor_geometry_fix_20261015.zip，重编后原resume命令续跑；每点新增短行TRIAL_RESULT，报告目标r、段数、实测V/I和原因。原来的启动/稳定性/PVT及完整可靠性仍未完成。

## 2026-10-15 历史状态：候选已收敛，参考电阻有限试参待服务器（R-068/P-069/C-072）

用户已通过现有--show-last-result读取candidate_007：converged=true，唯一失败项saturation，参考支路10.82uA、实际Cascode Vds约24mV，镜像输出Vds约-23mV；当前仅默认种子一次评估，不能判整个模板无解。器件额定值/完整合法域仍未验证，不能将DC收敛当作电路验收通过。此前封装路径与读取链已走通，下面较早“尚未运行候选DC”的内容是历史状态。

本轮保持MOS及模板连接，只接通参考电阻8/4/16倍三个有限试点（约386.08k/193.04k/772.16k欧姆）；方向依据是降低偏置电流改善余量，属于待真实仿真检验的方案。新电阻仅写r/m，由原生CDF生成分段几何并回读，实际r/m/连接仍须匹配。现有resume直接传入当次运行，不改原输入，不重扫PDK/重跑成功基线；失败仍报告实际条件。38项Python测试及三组C++测试通过，工具编译通过；没有在本地执行Cadence，不能保证三组之一可行。交付ldo_reference_resistor_trials_20261015.zip，编译工具后沿原续跑入口使用--reference-resistor-scales 8,4,16。启动、稳定性、PVT和完整功能验收仍未完成。

## 2026-10-14 当前阻塞修复：封装目标路径（R-066/P-067/C-070）

服务器candidate_006已通过当前代码续跑、启动选项预检及原生网表生成（1092组件，0错误/0警告），随后focused筛选报confirmed target missing from candidate: I21。生成器把原MOS放入同名Cascode封装，物理路径为I21.I21；上一版本仅检查扁平I21。现已在op_provider.py按实际封装路径识别目标，并处理后续删除误判，保持原生OA/PSF路径；没有恢复外围重复检查或旧软件版本门槛。

58项本地Python测试通过，包含复现该报错和完整封装层级/参考电阻/阵列/未改外围的provider组合测试。native调用由夹具替代，真实候选DC仍未通过。交付ldo_packaged_target_fix_20261014.zip单文件，覆盖上包后原resume直接续跑，无需编译。本条为当前状态，下述较早服务器状态仅供历史参考。

## 2026-10-14 当前实验范围：直接续跑、聚焦改动器件（R-065/P-066/C-069）

用户已授权取消软件版本与多层重复校验阻塞、未改外围的全面重复检查。本批已在experimental_dc现有主流程实现：使用当前代码续跑，入口一次确认实际电路配置/缓存数据/直接模型输入；内部不再要求工具版本白名单、历史封存完整性、重复PSF哈希或外围逐段OA对应。完整电路继续仿真；目标及实际新增/变化器件仍检查对应、连线、参数与真实工作点，新分段参考电阻仍正确聚合。保留可用VOUT/VFB/VREF和供电端口读数供功能判断，不自动推定功能达标。

56项本地Python测试通过，完整provider组合夹具验证100个未改MOS保留在活动网表、从逐个绑定/工作点查询中省去，同时新阵列MOS与25段电阻仍被正确读取；真实Cadence/SKILL执行尚待服务器。最新服务器证据仍停在candidate_005的启动设置报错，新增电路DC、启动、稳定性、PVT和最终功能验收未完成。本包包含上一批启动参数修复，交付ldo_focused_execution_20261014.zip七文件，原resume --reuse-verified-inputs直接续跑，不编译、不重复扫描或基线仿真。本条覆盖下文旧实验流程中的软件版本迁移与重复历史校验要求；不恢复模型内部检查等已取消范围。

## 2026-10-14 候选启动选项误阻塞修复（R-064/P-065/C-068）

最新服务器candidate_005通过绑定和参考电阻聚合，simulate仍在Spectre启动前因saved launch settings have unresolved mappings停止，尚无候选DC结果。旧代码把ADE界面等保存项未映射也作为阻塞条件。本批直接复用成功基线已有原生启动参数，候选网表/结果路径另设，保持实际数值设置；启动检查提前到原resume入口。31项本地测试通过，包括真实调用链的夹具执行和旧会话续跑；非原生Cadence验证。交付ldo_native_launch_fix_20261014.zip，解压后直接resume --reuse-verified-inputs，不编译、不重跑扫描/原基线、不新增诊断脚本。候选DC及后续功能验收仍待服务器。

## 2026-10-14 服务器绑定及查询已通过，补齐续跑漏项（R-063/P-064/C-067）

服务器最新结果确认6组外围保留、新增R_REF_N的25段聚合及1760器件查询生成成功。当前失败为旧会话固定的dc_results.py未纳入上一包的已有代码更新列表，尚未运行候选DC。现已同时补齐外层会话和内部baseline_bundle的条目；本地先复现两层错误，修复后19项相关测试通过，native为夹具，不能算服务器DC通过。交付ldo_reader_resume_fix_20261014.zip两文件，解压后沿原会话直接resume --reuse-verified-inputs，不再运行刚通过的器件回放，不编译或重跑基线。

## 2026-10-14 候选查询名称修复（R-062/P-063/C-066）

最新服务器回放已保留6组外围电阻，但build_dc_query拒绝器件名称；上一版在查询成功后才记录聚合，导致查询失败时仍误显示24段未绑定。代码已修复转义阵列名在producer/OCEAN匹配/consumer/取值间的不一致，原PSF调用使用真实信号名；回放v3区分绑定与查询失败。78项相关本地Python测试通过，包含六位阵列MOS和25段参考电阻的完整provider组合夹具。交付ldo_dc_query_name_fix_20261014.zip（5文件），无需编译或重跑基线。仍待服务器回放及真实候选DC，不宣称电路已通过。

## 2026-10-14 候选分段电阻回放已定位两种适配缺陷（R-060/P-061/C-064）

现场candidate_004回放显示：R1八段完整签名未变，仅公共VBN1新增复制管被误判私有节点；新增R_REF_N有实际parent OA身份及25个原生段，旧代码没有整体测量适配。这仍是仿真前的软件绑定失败，不能称VBIAS电路无解。

本批一起修复：保留原始外围分段并正确识别公共节点；新参考电阻从已通过的同候选OA回读获取父端点/参数，结合实际catalog及原生网表验证两端网络、查询全部段的真实电流，再汇总父电压/有符号电流/功耗并检查KCL。支持串/并联图，不把首段当整体，不虚构逐段OA身份。回放脚本v2调用同一路径并以--require-pass在失败时阻止后续EDA。原bundle/已验证输入不变，仅发布明确provider版本迁移。

120项相关本地Python回归通过，包含完整候选provider流程但native执行由夹具替代，不能算服务器验证。交付ldo_candidate_resistor_fix_20261014.zip（三文件，无C++编译）：先对保留候选只读回放，预期6组外围保留+1组25段聚合、无unbound，再续跑。真实候选DC、电路功能、启动/稳定性/PVT/可靠性仍待验证；不增加PDK内部资料收集。

## 2026-10-14 新候选的分段电阻保留未通过（R-059/P-060/C-063）

现场已证实bundle升级预检通过。candidate_004实际OA导出及端口检查之后，physical binding报R1_2_res_gen缺master，尚未进入候选Spectre。旧基线6组外围保留成功不证明新候选仍符合保留条件；当前代码对原始分段名/完整节点名/参数严格比较，拒绝时只报后续缺master，缺少具体字段。

本批未猜测现场根因或修改生产放行。只读inspect_cascode_candidate_bindings.py读取现成candidate_004及基线，重放实际binder并一次列出所有失败组、节点/参数/名称与内部外接差异。4项本地测试通过（含5类失败子用例），无EDA、无源文件改动；交付单文件，无需重编译/重跑生成。具体生产适配等待真实GROUP/SEGMENT_DIFF结果。本地私有网重命名反例仅证明潜在误拒绝，不是现场R1已确诊。

## 2026-10-14 候选工具升级被旧基线内部哈希拦截（R-058/P-059/C-062）

应用wrapper修复后，服务器candidate_003进入候选DC后端，报baseline dependency changed or missing: pdk_adapter.il，仍未进入候选Spectre。上一包只迁移外层provider清单，遗漏baseline_bundle内部历史工具哈希。该错误不代表电路无解；根据调用顺序可推断跨过materialize/回读，但尚未收到这次完整Check and Save日志。

现在baseline_bundle统一处理明确工具升级：仅experimental_dc、已校验当前provider及同一bundle/profile、固定工具白名单和精确发布旧/新SHA可通过。保留原bundle与历史哈希，另记升级差异；原电路、模型、PSF、Bench与其它输入仍验证。首次receipt准备和每次resume共用此加载，新增BASELINE_BUNDLE_PREFLIGHT在EDA启动前执行；未知变动不放行。

本地122项Python测试通过，含连续续跑、实际provider/runtime导出及仿真前后校验；native调用为测试边界，不能算原生DC通过。交付ldo_bundle_upgrade_fix_20261014.zip，解压后直接resume --reuse-verified-inputs，无需C++编译，不重做build/inspect/confirm或原生基线。新增电路的DC、启动、稳定性、PVT与可靠性仍未验证。

## 2026-10-14 原生候选已生成，修复父图短路与检查漏报（R-057/P-058/C-061）

长度补丁已跨过原错误，服务器进入 candidate_002 原生生成。materialize.log 明确检出 AVDD/VBN/VSL 与新 VBIAS 网短路，以及功能 wrapper/VBIAS wrapper 重叠；旧适配器未解读 schCheck 的返回错误，后续才报 OSSHNL-109/514。仍未获得候选 Spectre DC 结果。

本地已复现固定4格间距下的符号包络重叠，以及封装父图沿用多余固定位置标签线。Packaging.cpp 改为只用真实引脚标签短线，按生成符号包络加引脚/短线余量错开放置；不改模板、参数、端网映射和子图连接。pdk_adapter.il 解读检查错误数，并检查保存前后连接提取是否有效。resume 允许此次明确哈希升级，原输入和复用凭据保持校验。

本地 Packaging 61、CLI 103、Standalone 42 项断言及 Python 25 项通过，tool-only 编译通过。真实 SKILL/OA/Spectre 修复效果仍待服务器；本地几何夹具不是服务器原图回放。交付 ldo_wrapper_short_fix_20261014.zip，解压、tool-only 编译后沿原 --reuse-verified-inputs 续跑。新候选 DC、启动、稳定性、PVT、可靠性和发布均未验证。

## 2026-10-14 候选封装长度检查失败，修复数值边界比较（R-056/P-057/C-059）

服务器已确认Bulk继承生效，名义评估1/16；host_message明确为I21的PDK参数l超范围，发生在候选OA计划构建前，不能称为Spectre不收敛。Packaging对浮点直接比较可在本地复现240n与2.4e-7同值误拒绝；已改为微小相对舍入容差并保留尺寸原文、真实越界拒绝。后端原始原因及raw/parsed/min/max现在直接进入失败摘要。

三套C++251项断言及tool-only编译通过，含有限单点范围的完整CLI替身流程。现场随后回传I21=240n、min_length=max_length=2.4e-7，已确认本次与本地浮点误拒绝同因（C-060）；补丁尚待服务器续跑验证。两文件增量包ldo_length_range_fix_20261014.zip已校验，原封存Python/基线/资料不变。候选电气、启动、稳定性、PVT和可靠性仍未验证。

## 2026-10-14 复用已在服务器通过，修复Bulk传递遗漏（R-055/P-056/C-058）

服务器已回传r2复用成功、6组原电阻保留、基线DC/PDK扫描原生执行0，随后名义评估0/16。该计数意味着候选尚未调用DC评估。首次实验脚本未把nmos_bulk_net写入操作，后续组装要求该字段；本地按相同操作复现同一错误。此次仅experimental_dc的同型、同master、已证明Bulk规则且非独立井NMOS在缺省时继承原B端网，同时用于求解和最终变换。原图和操作文件不改，显式配置不覆盖。

求解器保留模板/变换原始构建原因，零评估改为candidate_construction_failed，不称电气无解。三套C++回归219断言及24项Python测试通过；CLI后端是替身，不能算服务器电气验证。交付ldo_bulk_handoff_fix_20261014.zip，先build.sh --tool-only编译，再原--reuse-verified-inputs续跑；Python封存文件、已有基线/扫描/端口缓存不变。新候选及最终功能仍待服务器验证。

## 2026-10-14 双下划线分段名兼容修复（R-054/P-055/C-057）

服务器v3在纯文件预检报R3_2__res_gen缺OA绑定；上一版两处只识别单下划线，尚未进入本轮仿真。r2使用同一解析识别单/双下划线候选组，实际标识不改名，原网表的模型/连接/有效参数及完整段集合仍须相同才保留外围豁免。

9套101项本地测试通过，覆盖按现场名称/数量构造的四组39附加段及prepare→resume→scan→基线Provider路径；连接和参数为合成数据，不称为真实服务器原文件回放。交付ldo_reuse_patch_20261014_r2.zip，沿用--reuse-verified-inputs，无需build/inspect/confirm。真实候选DC和后续验收仍待服务器，未宣称其通过。

## 2026-10-14 用户批准缩减重复核对（R-053/P-054/C-056）

当前有效口径覆盖此前R-052对未改动外围电阻的取证前置要求：原电阻网表/连接/有效参数保持时，保留原生模型仿真，取消逐段OA反查和OP资料补齐；新增或改变的器件仍严格核对。用户确认服务器变量为$st_batch，旧截图OCR的$sst_batch不是错误来源。

同会话已验证扫描目录、端口导出及器件资料按输入指纹复用。完整原生电路与接受Bench及控制一致时复用原目标的基线OP；新候选必须重新仿真，原图/候选回读、电气验证及不发布边界保持。使用resume_cascode_experiment.py --reuse-verified-inputs，既有build/inspect/confirm不重做，原清单/日志保留。无需再运行inspect_cascode_resistor_groups.py。

本地9套98项回归通过，原legacy运行时未变；本批新增候选电气结果仍待服务器。若新VBIAS电阻本身发生无法映射的多段展开，仍需正确处理整只电阻测量，不能把外围豁免套用给新器件。完整LDO功能/启动/稳定性/PVT/可靠性尚未完成。

> 版本：2026-10-14（三项实验阶段缩减已确认；代码已本地验证，现场电气验收未完成）  
> 状态：当前唯一入口（Single Source of Truth）  
> 适用工程：st-engine-maau  
> 使用要求：新 Agent 必须先完整阅读本文、先做方案与代码差距评审，再修改代码。

---

## 2026-10-14 剩余39项集中为四组电阻展开（R-052/P-053/C-055）

用户补回39个unresolved：R0第2–25段、R1/R3第2–8段、R4第2段，均为rhrpo_2t_ckt。现有名字支持netlister分段假设，尚缺原实际segments和每段节点，不能只凭res_gen后缀继承OA身份。

提供独立inspect_cascode_resistor_groups.py，只读同次导出的完整网表、原OA结构快照/目录/绑定，集中报告四组源参数、分段数、完整路径、内部节点外接和模型/端序差异。3项本地文件/连接图测试通过，原生执行0次。下一步正式适配必须同时覆盖整只电阻端到端测量，当前代码直接用第一段节点的行为不能照搬；生产分段修复/服务器Provider升级仍待证据，不提升电气/VBIAS/发布状态。

## 2026-10-14 实例数组格式根因已证实，39项仍待详情（R-051/P-052/C-054）

服务器只读审计：3334个叶子实例中145精确、3134数组名候选、16转义候选、39未解析，无歧义/身份冲突且无未消费OA展开位。OA I93<5:0>.I2.M0与网表I93\<5\>.I2.M0的差异已证明旧字符串查表缺少数组/转义适配，不能归咎于电路。其余39项完整数据已在服务器报告中；当前摘要截断遮住这些项也是诊断缺陷。

本地正式绑定现统一有限数组展开及比较用的转义，保留网表节点/PSF路径/OA来源；碰撞、漏位、层级、model/master/端序矛盾仍拒绝。诊断v2优先列出真正阻塞，重复提示限量；7套45项本地测试通过。尚未把新Provider下发到固定的服务器会话；待39项详情、完整文件预检与精确升级方案后再续跑。没有新增Spectre/VBIAS/可靠性/发布通过证据。

## 2026-10-14 端口修复现场通过，转入器件绑定取证（R-050/P-051/C-053）

服务器已通过端口预检和实际原生导出：22个OA对象对应24位，IBIAS_SET两位在原Bench与导出均未使用。随后在physical OA master binding missing: I93\<5\>.I2.M0停止；本次新基线Spectre尚未执行，不是DC不收敛或VBIAS不可行的证据。

独立inspect_cascode_bindings.py一次审计保留网表中的全部器件与原生OA记录，输出精确匹配、转义/数组提示、真正缺失及身份冲突，报告保留在服务器新目录。提示不作为正式绑定；不改生产代码/电路/清单，不运行EDA。4项本地测试通过，真实记录差异及生产修复尚待回传；电气、VBIAS、可靠性及发布状态不提升。

## 2026-10-14 总线端口兼容修复（R-049/P-050/C-052）

服务器原始取证已证实：OA的IBIAS_SET<1:0>、OCP_SET<1:0>在Bench中按位展开并转义，22个terminal对象实际对应24根线；旧代码直接比字符串造成误拒绝。正式cascode_runtime现按位核对，保持Bench端序和网表节点文本，真实缺项/重复/已连接端口消失仍拒绝；原来和导出均未使用的端口仅保留声明，不人为补接。

BusPorts更新包提供--upgrade-port-reader续跑：先在保留网表上预检，再使用单独记录的精确旧/新运行时代码清单生成，不改原始封存清单、不重编或重做inspect/confirm。8套54项本地相关测试通过，旧cadence_runtime.py保持不变。修复后的原生预检、基线DC及新VBIAS/电气验收仍待服务器；本次不进一步缩减电路合理性要求。

## 2026-10-14 续跑已到原生导出，待核对端口差异（R-048/P-049/C-051）

服务器已确认experimental_output_local生效；Cadence生成网表成功，随后actual OA DUT/Bench port mismatch，Provider退出70、续跑退出2。本次尚未进入Spectre。代码确认为OA原始terminal名称与Bench端口集合比较，但实际差集未回传，暂不能认定总线、转义或真实缺项。

提供独立inspect_cascode_ports.py复用保留的ports.txt、bench.scs及input.scs取证，纯内存重放原比较；不启动EDA、不改端口、不改现有会话或封存site代码。3项本地磁盘/进程测试通过，诊断退出0只代表读取完成；现场原始差异及后续修复仍待验证，不提升电气/可靠性/发布状态。

## 2026-10-14 实验 OP 目录修复与续跑（R-047/P-048/C-050）

服务器首个候选已完成编译、准备、inspect及confirm；generate尚未启动OP Provider就因旧ST_OP_RUN_ROOT指向20261008目录而退出73。这是运行位置配置遗漏，不构成DC不收敛或VBIAS不可行证据。experimental_dc后端现将raw_op放在当前OP输出目录下并检查可写；其余范围行为保持。

使用scripts/resume_cascode_experiment.py --batch续跑原实验的generate，无需重新编译或inspect/confirm。原输入指纹及server/site Python文件保持不变；原报告保留，续跑结果单独保存。26项相关Python测试与后端合同本地通过，真实服务器OP/候选电气结果仍待验证；不改变电气合理性、CDF/回读/可靠性边界。

## 2026-10-14 输入绑定通过，接续首个候选（R-046/P-047/C-049）

服务器已回传 binding-v3：EXPERIMENT_INPUTS_BOUND、EXPERIMENT_INPUTS_READY=true、退出0；I21/I105、实际Bulk、VBIAS供电与真实电阻种子绑定通过。下一步入口 run_cascode_experiment.py 读取原文件，自动仅编译主工具，创建新的I21同型Cascode实验会话，依次inspect/confirm/generate。采用实际参数起点，原生CDF、候选DC和回读门禁保留；未选作变换的其它原生primitive按已有扫描身份保留，不参与搜索，不要求额外整理其器件规则。

此轮确实会启动Cadence；已有Bundle复用环境与求解设置，新会话的基线一致性DC仍可能运行。成功仅为experimental_dc_ready=true，保持published/ready_for_sizing/reliability_verified=false。I105后续单独实验；暂无新VBIAS、启动/稳定性/输出性能/完整PVT通过证据。本地编译和夹具验证不能替代服务器结果。命令、日志和停止规则见工程docs/experimental-cdf-server-validation.md。

## 2026-10-14 Bulk 同网端口修复（R-045/P-046/C-048）

用户已回传缓存复用成功（原生执行 0 次），供电、I21 和电阻已绑定；唯一剩余为 I105.B=PVDD，v2 错误要求局部名字必须是 AVDD。v3 用已验收网表中的核心端口映射，要求局部 Bulk、模板电源及目标 B 均解析到同一实际网；仅电压相等不算同网，缺映射或异网仍拒绝。不改源接线、不硬编码 PVDD=AVDD，继续 --reuse-native。38 项本地回归通过，服务器 v3 尚待验证；新电路/VBIAS/电气验收未完成。

## 2026-10-14 原生记录复用修订（R-044/P-045/C-047）

服务器绑定 v1 已读出 bsimcmg TYPE：I21=1、I105=0；在电阻参数种子的原接线字符串比较处退出 2。此比较不属于新模板电路的连接验收，现改为保留上下文，不阻止借用真实型号/参数；实际模型/端序/电流/Bulk 及生成候选的 CDF、网表回读与电气门禁仍保留。

仅对有原生模型及 CMG 来源的 TYPE 使用文档定义的 1=N、0=P；共享模型名称不替代实例绑定。旧脚本 prog 返回值产生假失败日志，已修复。新增 --reuse-native，核对同基线指纹和原生完整记录后复用，无需再次启动 OCEAN/Spectre。已通过本地回归，真实服务器缓存接续待验证；未产生新 VBIAS 或电气验收结论。

## 2026-10-14 实验输入接续（R-043/P-044/C-046）

用户已回传缓存准备退出 0；完整草稿暴露重复 cdf_l/length、cdf_m/multiplier 与非数值 CDF 项混入。现已规范化唯一物理参数映射；原实例额外数值由实验 Provider 冻结保留，不把文字/版图选项当作调参量。

用户要求由模板自动决定合理接法，不要求用户手填 N/P 或电阻配置；该授权不等于极性证据。新增 --bind-native，一次 OCEAN 只读源 OA 与已有 PSF，取得实际模型类型、真实电阻实例/CDF/直接电流端子映射，并核对 Bulk/AVDD/AGND 与已验收数据。输入不齐则一次汇总，额定缺失仍按实验边界处理。无 Spectre 重跑、无源 OA 保存、无新增 VBIAS 验收；新原生接口返回形式待服务器验证。

## 2026-10-14 原生 CDF 有限候选与隔离实验（最新有效决定）

用户已确认以下三项缩减，修订前文／后文相冲突的资料前置要求：

1. 不再要求先找到 `res_calc.il` 或读懂不透明回调源码。候选参数交由 Virtuoso 原生 CDF 回调，保存后核对 OA 和生成网表；实际回调失败或回读不一致仍拒绝。
2. 不再要求先整理整个合法尺寸域和全部联动关系。以真实实例参数作起点，构造少量有限试点，逐点原生验证。试点集合明确不是完整 PDK 合法域；已知限制照常执行，不把默认值冒充实际参数。
3. MOS 耐压、电阻额定值未收集齐时，可先进行隔离实验仿真。记录实际电压、电流、功率；逐项执行已知限制，未知项标为“未验证”。实验不得标记可靠性通过，不发布到最终目标，不显示 ready_for_sizing=true。

本次新增 `experimental_dc`，原 `dc_operating_point` 正式门禁保留。实验仍需真实极性、端子／Bulk／供电连接、原生回调、回读及 DC 必需数据；四种结构和独立 N/P 自给电 VBIAS 模板不删改。启动、稳定性、输出性能和最终同参数 PVT 验收仍保留，实验阶段通过不替代这些结果。本地实现与验证见 R-042/P-043/C-045；现场现有成功证据仍仅为基线 DC、OP 和 native-site 接入。

历史“必须 RESISTOR_SOURCE_READ=true 才能继续”已由本节取代；旧取证结果保留，不再继续排查该脚本作为候选工作的前置步骤。

## 2026-10-13 电阻资料续读修订（历史路线，已由上节修订）

用户回传sources-v1退出0，但仅libInit.il明文、17个回调OPAQUE，未读到此前定位的res_calc.il。OPAQUE不证明具体加密方式；该回传不增加电气规则证据。脚本v2改为默认仅补读电阻文件，恢复同一上下文历史报告的确切路径并检查已有根目录下的这个文件名，不遍历PDK、不打开回调。必须RESISTOR_SOURCE_READ=true才表示资料阶段完成，失败保留具体选择报告。本地10项测试通过，现场v2待执行，器件耐压/bulk/电阻额定及真实VBIAS验收仍未完成。

## 2026-10-13 接续状态：完整回调与CMG消费

用户v2资料回传退出0，无EDA重跑。l回调限制70–242nm并按1nm取整，l<106nm还改变diffColor；nfin限制4–20并取整。m/fingers/fw仍委托PDK函数，默认值不是实际尺寸或额定规则。已定位res_calc.il及直接回调加载文件；下一步使用read_cascode_pdk_sources.py定向读取，不再遍历全库。真实耐压、bulk规则、几何映射和电阻额定仍缺，不能标为电气可用。

本地补齐CMG消费：MOS TSV保留12列兼容，新增14列显式内部vgs/vds，缺失成对NA；端口差继续用于耐压，内部vds用于与vdssat比较并决定基线饱和状态。正式Provider要求显式映射且逐器件核对native bsimcmg来源，缺值/错配拒绝；旧Maau读取路径不支持此来源合同，CMG需走正式Bundle路径。CLI求解器身份升级以防复用旧语义结果。此为本地实现，真实OA候选、电气、启动/稳定性及固定参数PVT仍未验收。

## 2026-10-13 最新范围修订（用户已确认，代码已本地验证）

仅缩减以下四项，后文历史描述冲突时以本节为准：

1. 不追求最低功耗、最小面积或最优参数；保留自动求出满足电气要求和约定验收条件的可行参数组。
2. 不从整个 PDK 搜索最优器件；在本电路真实 PDK 中使用已核实的器件或固定候选集合，仍核对极性、端子、CDF、合法尺寸及额定值。
3. 不计算整机精确 IQ，不补齐无关外围节点；仍检查目标与模板必需节点、实际供电轨、新增 VBIAS 支路电流和原电路变化。必要缺项不得补零，已有明确指标继续执行。
4. 不检查和完整封存所有模型文件的内部递归依赖；沿用现场仿真环境，保留模型路径/section、已有输入指纹及工具环境的基本核对，模型内部/标准头文件由 Spectre 加载。原生加载失败仍失败，不宣称内部依赖已完整封存或可跨机器复现。

其它原要求全部保留，包括真实 OA 候选和回读、四种结构及 N/P VBIAS、接线/工作区/器件额定值、约定的启动/稳定性及固定参数 PVT 验收。本修订未接受仅做单目标、用网表筛选替代每个真实 OA 候选、减少已约定 Corner 或取消必要封装布线的建议。当前 VBIAS 五角色模板不删器件。

实施与状态追踪：st-engine-maau/docs/01-需求与决策.md 的 R-037、docs/02-实施计划.md 的 P-038。四项缩减代码已实现并完成本地回归（C-040，19个C++测试程序及76项相关Python测试）。本批现场接入命令不重跑已有DC/OP，取消内部模型递归封存前置条件。用户已回传v3现场接入退出0、222项读数一致、Spectre身份确认；这只证明现场上下文接入通过。R-038/P-039已取得现场CDF回调线索；v1预览截断且通用函数误报，P-040修复完整输出及定向搜索。长度/fin预览边界尚不能作为完整合法域，耐压/电阻额定规则仍待确认。CMG端口/内部电压消费、真实PDK/Profile绑定、OA候选与约定启动/稳定性/PVT尚未完成，不能称LDO需求已完成。

---

## 0. 文档定位和权威性

过去的讨论混合了需求修改、电路方案、代码实施、服务器排错、测试命令和材料写作。目前没有任何一份旧文档能单独代表完整最终需求。

本文同时承担三项职责：

1. 给出四种结构变换和自动 VBIAS 的最终设计；
2. 作为评审现有代码是否符合需求的基准；
3. 说明当前做到哪一步、剩余任务及真实验收方法。

发生冲突时，按以下优先级处理：

1. 用户最新明确确认的决定；
2. 本文的“最终确定需求”；
3. 本次电路仿真条件、真实 PDK、Spectre 和 Virtuoso 返回的可审计事实；
4. 当前代码和测试所表达的实现现状；
5. 其他历史方案、任务账本和对话。

代码与本文冲突时，表示代码需要修改，不表示本文自动失效。

### 0.1 本轮用户确认的简化边界

- 本项目独立编译和运行；KimiCode 是 Maau 源码，只用于参考和复用。Maau 软件、原生链接库、工艺 Registry 和 Maau Case 文件均不是本需求的必需依赖。
- 不同电路从所选源 Cell 的工艺关联及当前 cds.lib 注册路径自动发现自己的 PDK，也可明确输入本次 PDK 根目录覆盖；读取本次工程的真实 OA/CDF 和模型文件；不复用 KimiCode 或其他测试电路的固定 PDK 地址。文中 Case 在产品路径中表示本次电路的仿真条件配置。
- 当前独立入口为 `st-engine-maau/server/site/standalone.py`，实际使用说明见 `st-engine-maau/docs/standalone-pdk-server-validation.md`；12.3.4 的 Maau 接入仅保留为历史可选方式，产品状态以 12.3.5 为准。

- 只选择核心 Cell **当前层**的 MOS，不进入层级子 Cell；当前层全部 MOS 均可选择，具体操作不满足 PDK 或电气条件时给出拒绝原因。
- 用户确认只有 D/G/S 三个外部端子的 MOS 也属于“全部 MOS”：真实 PDK 已证明极性和 D/G/S 端子语义时进入清单，可保留原管并在 Source 串电阻；Bulk 列留空，不虚构第四端。四端器件若缺少第四端语义仍拒绝。Cascode、Stack 和 VBIAS 继续按各自 Bulk/Well 规则筛选。
- “异型 Cascode”仅表示新增管与原管**同为 NMOS 或同为 PMOS，但使用不同的真实 PDK master**。`device_family`、`flavor_id` 不作为业务定义或必填过滤条件。
- 电阻变换始终保留 MOS，在其电气 Source 路径串联真实 PDK 电阻。
- VBIAS 使用一套通用 Mirror + Replica 思路，NMOS 与 PMOS 采用互补连接图。不按 CAP、Capless、FVF、RES 各自发明模板，也不预置多套备选拓扑。
- 第一份真实电路证据来自现有 Capless LDO。其他架构沿用同一生成规则，未取得真实 Case 前不宣称其电气适用性已验证。
- 用户于 2026-10-08 澄清“没有 Spectre”实际指尚无性能指标（Spec），并要求先确定真实器件 master 与参数，先做基础工作验证。Spectre 仿真器仍用于求名义 DC 工作点；主支路相对电流偏差上限和新增 VBIAS 电流上限改为选填，两项同时省略即可求直流可行参数，提供时须成对、有限且为正数并严格执行。
- 无性能 Spec 不省略真实 Bench、供电/负载/温度/模型、连接、CDF、可靠性、电阻额定值和 OA 回读；偏置镜像电流须非零且方向一致，基线已导通支路须继续导通且保持方向。保留原管有意在线性区或弱反型的用途，不增加任意最小电流/过驱动门槛。此阶段结果只能称“直流可行”，不能证明启动、稳定性或完整 LDO 功能及性能。报告记录 validation_scope=dc_operating_point、performance_verified=false、current_limits_applied=true/false。
- 用户于 2026-10-09 确认当前没有 Bench，先验收 Source 串电阻、同 master 共栅 Stack 的确认、撤回、重新确认、最终生成及 Virtuoso 显示。显式 `validation_scope=structure_only` 不要求 Bench、模型 Corner、供电轨或 OP，仅允许这两种操作；读取真实工艺/OA/CDF，继承原 MOS 参数、Gate 和外部 Bulk（真实三端 master 不虚构 Bulk），未知 N/P 不猜测。CDF 未公布范围时记录未知，具体参数仍经实际 CDF callback/check/save 和回读；保留源图未变、全部父子图回读及 staging 整组发布门禁。结果 `structural_ready=true` 后允许打开，同时 DC、PVT、Sizing 和性能状态均为 false。这是结构工具验收，不证明改后电路可正常工作；Cascode/VBIAS 继续执行上条 DC 流程。

### 0.2 历史文档的角色

| 文档 | 仍可使用的内容 | 不能继续采用的内容 |
|---|---|---|
| LDO_MOS四种结构变换设计方案.md | 四类结构的电路连接、参数维度和命名背景 | VBIAS 章节中的旧参考电流口径 |
| LDO_VBIAS生成支路设计方案.md | 早期模板研究和模拟背景 | 搜索或复用原电路 Bias |
| LDO四种架构Cascode_VBIAS设计方案.md | CAP、Capless、FVF、RES 的背景和验证维度 | 外部 IREF、复用参考电流、手工填写 Bias |
| 2026-09-24 Task4收口与Task5实施_工作交接.md | Task 1～10 的历史实施账本 | 不能代替产品需求 |
| 2026-09-29 真实PDK端到端_工作交接.md | 上一轮本地收口与服务器待办 | 不包含完整电路方案 |
| st-engine-maau/docs/superpowers/plans/2026-09-29-real-pdk-vbias-e2e-continuation-handoff.md | 低层接口、服务器实施和验收细节 | 与本文冲突的旧状态和旧输入口径 |

---

## 1. 最终目标

输入是一个真实 Virtuoso LDO 核心原理图、当前 PDK、真实 Case/Bench，以及用户确认的一个或多个结构变换。工具不覆盖原电路，只生成可审计的派生电路。

目标闭环：

~~~text
真实 source L/C/V + Case/Bench + 当前 PDK
  -> 扫描真实 PDK 器件、端子、CDF、可靠性和 Bulk/Well
  -> 读取核心电路当前层 MOS
  -> 用户确认结构变换
  -> Cascode 自动生成独立自给电 VBIAS 模板
  -> 每个参数候选物化成独立 OA CellView
  -> 独立 OCEAN/Spectre DC/OP 候选仿真
  -> 自动选择满足 PDK、可靠性、饱和、IQ 和电压域的参数
  -> 功能结构和 VBIAS 分别封装为子 CellView
  -> clone-on-write 到 staging，SKILL 生成真实原理图
  -> 回读 source、父图和全部子 Cell 网表
  -> 结构、参数、DC 和已配置 PVT 全部通过
  -> 发布最终派生 L/C/V
~~~

ready_for_sizing=true 只说明结构和规定的 DC/PVT 门禁通过，不代表 AC、TRAN、STB、PSRR、噪声或完整性能已经签核。

### 1.1 当前不做

- 不自动识别或联动修改对称管；
- 不从器件名称猜极性、端子顺序或参数范围；
- 不给共栅 Stack 自动做均压；
- 不使用电阻梯或多抽头 Bias 给 Stack 分级偏置；
- 不在“生成电路”阶段自动启动完整 Sizing；
- 不修改 source schematic、source config 或 source 网表。

---

## 2. 数据责任边界

| 数据 | 责任方 |
|---|---|
| source L/C/V、Bench L/C/V、VHIGH/VLOW 轨网、Corner | 用户或 Case |
| 器件身份、terminal order、CDF、合法范围、可靠性、Bulk/Well | 当前真实 PDK 的 Site Adapter |
| 目标 MOS、变换类型、Stack 级数、异型目标、可选电阻值 | 用户 |
| 中间网、实例名、模板内部器件、VBIAS、模板参数、参数量化 | 工具 |
| 候选 DC/OP、收敛、工作区和电流 | 项目内独立 OCEAN/Spectre Runtime 与 OP Provider |
| OA 创建、连线、check/save、重新网表化 | Virtuoso/SKILL 后端 |

参数来源优先级：

1. PDK 硬约束；
2. Case 限制；
3. 用户显式输入；
4. 工具自动求解。

任何最终参数都必须映射到真实 CDF 名，并经过范围、网格、整数性或离散值量化。

---

## 3. 四种结构变换的最终设计

## 3.1 同型 Cascode

“同型”表示新管与原管使用相同真实 PDK master。

### NMOS

新管位于原 Drain 侧：

~~~text
原 D0
  |
M0_CAS    G=VBIAS_N
  |
M0_MID
  |
M0        G=G0，不改
  |
原 S0
~~~

| 器件 | Drain | Gate | Source | Bulk |
|---|---|---|---|---|
| 原 M0 | M0_MID | G0 | S0 | 原 B0 |
| 新 M0_CAS | D0 | VBIAS_N | M0_MID | PDK/Case 规则 |

### PMOS

2026-10-15 修订：新管统一位于原 Drain 侧，原 G、S、Bulk 接线不变。

~~~text
原 S0／高电位侧
  |
M0        G=G0，不改
  |
M0_MID
  |
M0_CAS    G=VBIAS_P
  |
原 D0
~~~

| 器件 | Drain | Gate | Source | Bulk |
|---|---|---|---|---|
| 原 M0 | M0_MID | G0 | S0 | 原 B0 |
| 新 M0_CAS | D0 | VBIAS_P | M0_MID | PDK/Case 规则 |

实现按 PDK Source/Drain 端子角色连接，不按原理图坐标决定插入位置。新增隔离阱 PMOS 若采用源衬相连，Bulk 接新管实际 Source，即 M0_MID；原管 Bulk 不变。

### 参数规则

- 新 Cascode 的语义尺寸初值继承原管；
- 平面 MOS 可继承 W/L/nf/m，FinFET 继承实际 nfin/l 等已登记参数；
- 固定几何器件不伪造 W/L；
- 原 MOS Gate 始终保持原 G0；
- 只有新增 Cascode Gate 接自动 VBIAS；
- 产品路径默认不提供“两只 Cascode 管 Gate 直接短接”的选项。

## 3.2 异型（不同 master）Cascode

业务定义只有两条：新增管与原管同为 NMOS 或同为 PMOS，且真实 PDK master 不同。不同 master 不自动等于电气兼容；候选还须满足：

1. 目标 master 属于当前 DUT 的真实 PDK；
2. OA L/C/V、端子语义、CDF、可靠性、Bulk/Well、电压域和参数约束完整；
3. 目标 master 在当前 Case 中能被量化、连线、仿真并通过电气门禁。

`device_family` 和 `flavor_id` 可以作为 PDK 原始附加信息保留，但缺失、相同或不同均不单独决定候选去留，也不出现在用户必须理解的操作定义中。

用户和工具分工：

- 工具扫描 PDK，生成 accepted 和带具体原因的 rejected；
- 用户只能从 accepted 中选择目标 Cascode master；
- 用户不选择 VBIAS 模板内部器件；
- 工具把原管的等效尺寸映射到目标 master 的真实 CDF；
- 操作文件不能绕过候选过滤器填任意 master。

结构位置与同型 Cascode 相同：NMOS、PMOS 新管均在原 Drain 侧；原 Gate、Source、Bulk 不变。

## 3.3 MOS Source 串联电阻

该变换保留 MOS，只在电气 Source 路径增加一只真实 PDK 电阻，不是用电阻替换 MOS。

~~~text
D0
 |
M0         G=G0，B=B0
 |
M0_RS_INT
 |
M0_RS      真实 PDK 电阻
 |
S0
~~~

规则：

- 原 MOS Drain、Gate、Bulk 不变；
- 原 MOS Source 改接内部节点；
- 电阻连接内部节点和原 Source 网；
- NMOS/PMOS 都按 PDK Source 端子语义确定；
- 三端或多端电阻的 substrate/well 按电阻自身规则连接，不复制 MOS Bulk。

电阻值优先级：

1. 用户显式 resistor.value；
2. Case 预置值；
3. PDK 有限正合法区间的中间位置。

连续正区间用几何中点 R0=sqrt(Rmin*Rmax)，离散合法值用排序后的中位合法值，然后量化到真实 CDF。无法取得有限正合法区间时，必须由用户或 Case 提供，不能猜。

默认阻值不从 DC 工作点反推，不使用 R=V/I 作为默认规则。

## 3.4 共栅同型 MOS Stack

用户输入 N，业务范围为 2～100，还受 PDK 和 Case 更低上限限制。

靠近原 Drain 的第一级保留原实例名，然后向 Source 方向编号：

~~~text
D0
 |
M0          Drain 侧，保留原名
 |
X1
 |
M0_S1
 |
X2
 |
M0_S2
 |
S0
~~~

N 级实例为 M0、M0_S1……M0_S(N-1)。

规则：

- 所有 Gate 连接原 G0；
- 不新增 VBIAS，不使用电阻梯或 ResolveLadder；
- 每一级继承原 MOS 的完整语义参数，不做 W/N；
- 默认作为一个公共 Sizing 组；
- Bulk/Well 按 PDK 规则连接；
- 共栅 Stack 不承诺各级自动均压。

未来若要分级偏置 Stack，必须另立需求，不能恢复当前未使用的梯形 Bias 死代码。

---

## 4. 自给电 VBIAS 的最终设计

### 4.1 总原则

1. VBIAS 只用于同型和不同 master Cascode；
2. 不搜索、不复用原电路的 VBIAS 网络或 Bias 分支；
3. 不搜索、不复用原电路参考电流或 IREF；
4. 每个 Cascode 操作生成独立 VBIAS CellView、输出网和 IQ 记录；
5. 模板拓扑和角色固定，内部真实器件随当前 PDK 动态选择；
6. 用户不填 VBIAS、IREF、镜像比、Replica 尺寸或模板内部 master；
7. 参数由项目内独立 OCEAN/Spectre DC/OP 候选仿真求解。

这是一套通用方案的 N/P 互补实现，不建立按 LDO 架构区分的模板库。当前五角色连接是**待真实 Capless 验证的设计模板**，不是已经证明适用于所有 LDO 的电路结论。`VS_ORIG` 和 `VG_CTRL` 接入 Replica 后会给原网增加负载，真实候选仿真必须包含这一负载。模板参考电阻在供电存在时耗流；没有 enable 端口，不能据名义 DC 结果宣称关断/启动模式已通过。

### 4.2 VBIAS_N_CASCODE_AUTO

服务于 NMOS Cascode。固定端口顺序：

~~~text
VHIGH, VLOW, VS_ORIG, VG_CTRL, VBIAS_N
~~~

| 角色 | 类型 | D/正端 | G | S/负端 | 作用 |
|---|---|---|---|---|---|
| P_REF | PMOS | PBIAS_REF | PBIAS_REF | VHIGH | 二极管连接 PMOS 参考 |
| R_REF_N | 电阻 | PBIAS_REF | - | VLOW | 自给电参考支路 |
| P_OUT_N | PMOS | VBIAS_N | PBIAS_REF | VHIGH | 向 VBIAS 节点供流 |
| N_CAS_REP_N | 目标 NMOS | VBIAS_N | VBIAS_N | X_REP_N | 模拟新增 Cascode |
| N_CTRL_REP_N | 原 NMOS | X_REP_N | VG_CTRL | VS_ORIG | 模拟原控制管 |

Bulk/Well 由各真实 PDK 器件规则确定。

同型时两个 NMOS Replica 使用同 master。不同 master 时 N_CAS_REP_N 使用新 master，N_CTRL_REP_N 使用原 master。P_REF、P_OUT_N 和 R_REF_N 由工具自动选择。

### 4.3 VBIAS_P_CASCODE_AUTO

服务于 PMOS Cascode。固定端口顺序：

~~~text
VHIGH, VLOW, VS_ORIG, VG_CTRL, VBIAS_P
~~~

| 角色 | 类型 | D/正端 | G | S/负端 | 作用 |
|---|---|---|---|---|---|
| R_REF_P | 电阻 | VHIGH | - | NBIAS_REF | 自给电参考支路 |
| N_REF | NMOS | NBIAS_REF | NBIAS_REF | VLOW | 二极管连接 NMOS 参考 |
| P_CAS_REP_P | 目标 PMOS | VBIAS_P | VBIAS_P | X_REP_P | 模拟新增 Cascode |
| P_CTRL_REP_P | 原 PMOS | X_REP_P | VG_CTRL | VS_ORIG | 模拟原控制管 |
| N_OUT_P | NMOS | VBIAS_P | NBIAS_REF | VLOW | 镜像吸流 |

Bulk/Well 由各真实 PDK 器件规则确定。

同型时两个 PMOS Replica 使用同 master。不同 master 时 P_CAS_REP_P 使用新 master，P_CTRL_REP_P 使用原 master。N_REF、N_OUT_P 和 R_REF_P 由工具自动选择。

### 4.4 模板内部器件选择

每个候选必须正向证明：

- 属于当前 DUT 的真实 PDK primitive；
- 极性、端子语义、OA L/C/V 完整；
- 支持当前电压域；
- VGS/VDS/VGB 可靠性信息完整；
- Bulk/Well 规则完整；
- 所有使用参数都有可量化约束；
- 电阻有真实 resistance 语义和有限正合法值；
- 多端器件额外端子有确定连接方法。

2026-10-13 修订：不再从整个 PDK 搜索最优器件；使用本电路真实 PDK 中已核实的器件或固定候选集合，以上合法性和电气条件仍须满足，静态核对不能代替真实候选仿真。

### 4.5 自动求解

初值：

- 控制管 Replica 语义继承原管；
- Cascode Replica 和主支路新管映射原管等效尺寸到目标 master；
- 镜像 MOS 从合法区间或离散集合取可量化中间值；
- 参考电阻取合法正区间几何中点并量化。

每个候选必须完整构造：

~~~text
原管改线 + 新 Cascode + 独立 VBIAS 模板 + 父层轨网映射
~~~

随后必须经过：

~~~text
独立 OA CellView
  -> 重新网表化
  -> 身份核对
  -> 独立 OCEAN/Spectre DC/OP
~~~

不能只仿真一段脱离 OA 的临时文本并宣称真实候选通过。

生成候选的硬约束：

1. Spectre 收敛；
2. 工作点快照完整且身份一致；
3. 所有参数在 PDK 合法集合内；
4. 主支路和模板全部 MOS 的 VGS/VDS/VGB 不超限；
5. 新增 Cascode 与模板 Mirror、Cascode Replica 必须饱和；原控制管及其 Replica 若基线原管已饱和，也必须保持饱和。基线原管有意在线性区时不机械要求这两只管饱和；真实 Case 若有更严格的角色要求，应在实验前另行登记和实现；
6. VBIAS 在轨网和 PDK 允许窗口内；
7. 支路无开路、错接或异常反向导通；VBIAS 两只 Mirror 的直流电流必须有限、非零且方向一致；基线已导通时，原控制管、控制 Replica、新 Cascode、Cascode Replica 的电流均须非零且与基线同方向；
8. 原 Gate 保持原网，新 Gate 仅接本操作 VBIAS；
9. 如已提供主支路相对电流偏差上限，变换后的偏差不得超限；无性能 Spec 时仍记录该偏差并优先保持基线工作点，不添加虚构门槛；
10. 如已提供**新增偏置支路电流**上限，VBIAS 两条供电支路的直流电流之和不得超限；未提供时仍记录实际支路电流。当前 OP 的 `total_supply_current` 包含主通路及可能的负载电流，不能把其前后差值直接命名为整机 IQ 变化。整机 IQ 若要另行签核，Bench 必须给出无载条件或可核对的负载电流扣除方式；
11. 新增的 Source 电阻和 VBIAS 电阻必须在实际 PDK 额定电压、功耗及温度条件内。具体做法是由站点 PDK 适配器提供该电阻 master 在当前几何与 Corner/温度下的最大端电压及允许功耗或电流；候选 OP 中取得电阻两端电压与支路电流，验证 `abs(V+ - V-) <= Vmax` 且 `abs((V+ - V-) * I) <= Pmax(T)`（若 PDK 用电流额定值，则同时检查 `abs(I) <= Imax(T)`）。量化后参数和最终 staging/PVT 必须重复检查；额定值或 OP 不可得时拒绝放行。2026-10-06 本地代码已加入 `resistor.tsv` 与缺证据拒绝门禁，但真实 Site PDK Adapter/OP Host 尚未提供当前几何和 Corner/温度的额定值及实际 OP，仍不能因本地 Fake Host 通过而称真实放行。不能用 MOS 的 VGS/VDS/VGB 限值代替电阻额定值。

未给出 Bench 或轨网时，允许只读发现并查看目录与当前层 MOS；缺 Bench 的会话在 `generate` 前拒绝，Cascode 缺轨网时在求解前拒绝。两项性能电流上限可同时省略；如显式填写，只填一项或非法数值仍拒绝。暂无 Spec 时生成可供后续调参的直流可行电路，未验完整性能，不能称“正确工作”的完整签核。搜索预算内没有通过候选时报告“预算内未找到可行候选”，不声称已证明所有合法参数无解。

2026-10-13 修订：取消上述指标的最优排名目标，采用确定顺序寻找满足硬约束和本次约定验收条件的可行参数组。仍报告支路电流变化、控制管工作点、VBIAS 耗流及器件余量；有明确门槛则继续执行。首个 DC 可行候选仍需完成实际 OA 回读、已约定的启动/稳定性与 PVT 验收，通过后即可终止继续寻找更优解；验收失败不得当作完成。

当前允许的搜索上界为粗搜 256、精搜 128，总计不超过 384 个候选。修改上限必须同步修改性能预算和测试。

PVT：

- 名义 Corner 先选出唯一参数组；
- 已配置 PVT 时，同一参数组逐 Corner 复验，不允许每个 Corner 重选参数；
- 任一已配置 Corner 失败必须阻止发布；
- 未配置 PVT 时 pvt_ready=false 表示未执行，不表示名义 DC 失败。

---

## 5. 不区分 LDO 架构的通用策略

CAP、Capless、FVF、RES 使用同一套结构规则和 N/P 互补 VBIAS 连接。工具不因架构名称猜 Bias master、轨网、补偿节点或固定参数。只读发现只需源 DUT 与对应 `cds.lib`；正式 generate 需有可验证的 Bench 与名义工作条件，Cascode 还需真实供电轨网；主支路电流偏差上限与新增 VBIAS 支路电流上限选填且须成对；配置 PVT 时还提供 Corner 清单。第一轮只在现有真实 Capless 上取证，其他三类暂无通过结论。

---

## 6. PDK 扫描契约

下列是目录应能表达的字段；**进入当前层 MOS 清单**与**能用于某项结构生成**是两级资格，不能因后者缺资料就静默隐藏已经证明的 MOS：

~~~text
master, kind
oa_library, oa_cell, oa_view
pdk_name, pdk_version
terminal_count, terminal_names, terminal_roles
model_name, model_sections, corners
allowed_voltage_domains
reliability_complete, max_abs_vgs, max_abs_vds, max_abs_vgb
bulk_rule_complete, isolated_well, source_drain_interchangeable
normalized_to_cdf
parameter_constraints
max_stack_level
~~~

电阻还需要 resistance 语义和额外端子绑定规则。

扫描规则：

- 输入本次原始 PDK 根目录，从本次源 `cds.lib`、DUT L/C/V 和实际 OA/CDF/模型确认器件归属；示例中的 `smicnp1p`、`HiAplat...`、I52/I53 只用于既有 Capless 试验；
- 正向证明每条记录是 PDK primitive，不能混入用户同名 cell；
- Site Adapter 实现 StSiteTechDescribeDevice 等现场回调；
- 通用层不填假值，缺字段就在相关功能上安全拒绝；
- 目录必须有 pdk_version 和稳定 catalog hash；
- inspect **先 scan-pdk，后导出结构网表**；由本次扫描目录生成 `analysis/device_policy.tsv`，把 OA 端序与 CDF 参数映射传给 snapshot 和后续回读，不能靠仓库的 Capless 示例 `server/config/device_policy.tsv`；
- inspect、confirm、solver、OA plan 和 verify 使用同一份权威目录；扫描输出中的 CDF 映射不完整时，不得把漏参网表当成原电路的完整表示；
- generate 重扫后，版本或 catalog hash 变化时要求重新 inspect/confirm。

`传输的代码.md` 指向的既有 Maau 实现提供可复用线索：`PdkCollector` 按 DUT L/C/V 调用 `get_pdk_names`，`GetTechs` 从当前 `cds.lib`/工艺配置找 PDK 路径，`TechBase`/工艺配置提供器件分类、CDF 约束和 Corner，`CircuitTestBenchConfig` 保存 DUT 与 Bench L/C/V。它们是**站点接线依据**，并未自动链接到本独立工具；尤其不能把工艺目录名或 `tech_cfg_v2.0.json` 单独当作 PDK 归属、可靠性或电阻额定值的充分证明。真实 Site Adapter/Host 必须核对 OA、CDF、模型和 Case 身份。

不同 master 候选的拒绝原因至少包括：

~~~text
polarity_mismatch
oa_master_incomplete
mos_terminal_*_missing
reliability_incomplete
bulk_rule_incomplete
voltage_domain_unsupported
quantizable_geometry_missing
~~~

非 MOS 不应被附加一串 MOS 端子与几何特有原因。输出顺序必须稳定。不同 master 是准入前提；同 master 属于同型 Cascode，不作为异型候选。

---

## 7. 封装、命名和 Virtuoso 显示

### 7.1 封装

- 每个独立功能变换生成一个功能子 CellView；
- 每个 FixedBias Cascode 再生成一个独立 VBIAS 子 CellView；
- 核心父图只放功能 wrapper 和 VBIAS wrapper；
- 模板五个内部器件不能散落在父图右侧；
- 同一派生区域连续变换时合并到同一功能封装，避免 Cell 套娃和覆盖。

### 7.2 命名

- Cascode：M0、M0_CAS、M0_MID；
- Source 电阻：M0、M0_RS、M0_RS_INT；
- Stack：M0、M0_S1……M0_S(N-1)；
- VBIAS 子电路、wrapper、输出网和候选 CellView 名包含 operation/variant 唯一身份；
- 冲突时使用确定性后缀，不覆盖已有实例或网络。

### 7.3 放置和布线

- 使用 symbol 真实 pin 坐标和 orientation；
- 专用内部网使用真实 pin 到 pin 导线；
- 其他网可用短 stub + label，但不能穿过同 symbol 的其他 pin；
- 重叠、相交或端点接触可能被 Virtuoso 判定短接，必须有避障；
- 多个变换使用全局位置分配器，不能各自从同一坐标开始。

---

## 8. 用户流程

### 8.1 Inspect

只读发现时使用已导入电路的 source `cds.lib`、DUT L/C/V，以及独立派生 L/C/V 和 work directory。Bench、Corner、VHIGH/VLOW 在生成前核对，电流上限如已有 Spec 则一并核对；缺 Bench 的发现会话不能执行 `generate`。

工具必须：

1. 验证 source 身份；正式生成前另行验证 Bench 身份；
2. 扫描真实 PDK；
3. 生成 source 网表和根层几何；
4. 只列核心 cell 当前层直接 MOS；
5. 输出真实 D/G/S、可选的外部 Bulk、master、参数和同极性不同 master 候选/拒绝原因；三端 MOS 的 Bulk 留空；
6. 保存 PDK 版本和 catalog hash。

### 8.2 Confirm

操作文件只保存业务意图。FixedBias Cascode 不得接受以下手工字段：

~~~text
bias.output_net
bias.voltage
bias.reference_current
bias.element.*
~~~

这些字段必须被明确拒绝。Confirm 不写入假 VBIAS 或假工作点。

### 8.3 Generate

固定顺序：

~~~text
重扫 PDK 并核对版本+catalog hash
  -> 基线 DC/OP
  -> 逐 FixedBias Cascode 自动 VBIAS 求解
  -> 全部求解成功后重放 Change Set
  -> 封装功能 Cell 和 VBIAS Cell
  -> 生成 OA plan
  -> clone 到 staging
  -> SKILL 物化、check/save
  -> staging 名义 DC 和已配置 PVT
  -> source、父图、所有子 Cell 回读
  -> 全部通过后 publish
~~~

无解或失败时保留诊断，但不发布。

---

## 9. 会话产物

至少保留：

~~~text
before/core_before.scs
before/device_catalog.tsv
before/geometry.tsv
before/mos_inventory.tsv
analysis/device_policy.tsv
analysis/pdk_scan/inspect/raw_catalog.tsv
analysis/pdk_scan/inspect/pdk_identity.tsv
analysis/pdk_scan/inspect/scan_pdk.log
analysis/pdk_scan/run_NNNN/raw_catalog.tsv
analysis/pdk_scan/run_NNNN/pdk_identity.tsv
analysis/pdk_scan/run_NNNN/scan_pdk.log
analysis/pdk_catalog.json
analysis/cross_flavor_candidates.json
analysis/baseline_op/
analysis/baseline_op.json
analysis/candidates/candidate_NNN/
analysis/solver_trace.jsonl
analysis/resolved_parameters.json
analysis/variant_op/
analysis/variant_pvt/<corner>/
expected/core_expected.scs
materialization/plan.json
after/source_roundtrip.scs
after/core_roundtrip.scs
after/package_*.scs
reports/validation.txt
logs/
~~~

每个候选目录应包含唯一 OA 身份、plan、回读网表、仿真身份和原始 OP 数据。

2026-10-07 本地已补齐候选仿真前的 OA 回读门禁：父图及每个封装子 Cell 与封装期望网表逐项核对连接、master、端口和参数，子 Cell 中额外的层级或指令也拒绝；只有候选 `validation.txt` 为 `ok=true` 才调用 `run-op`。每次生成分配新的候选编号，保留已有 OA 身份和证据；具体宿主失败原因写入 `solver_trace.jsonl` 的 `host_message`。目前只完成本地 Fake 后端的异常阻断验证，真实 OA 导出及仿真仍需现场实现和验收。

---

## 10. 放行条件

结构门禁：

- source 网表或 hash 不变；
- staging 父图的实例、master、连接、端口和必要参数与期望一致；
- 每个子 Cell 独立回读一致；
- 无计划外实例、重复实例/subckt、端口丢失或 CDF 恢复默认；
- Virtuoso check/save 无错。

电气门禁：

- 基线和候选 DC/OP 身份完整；
- 最终 staging 名义 DC 通过；
- 可靠性、按角色要求的工作区、电压域及已声明的主支路电流偏差和新增 VBIAS 电流限值通过；无 Spec 时报告仅名义 DC 可行；整机 IQ 另按真实 Bench 定义核验；
- 配置 PVT 时所有 Corner 通过；
- 无缺实例、NaN、Inf 或假身份数据。

放行公式：

~~~text
ready_for_sizing =
    structural_ready
    && nominal_dc_ready
    && parameters_quantized
    && (!pvt_configured || pvt_ready)
~~~

---

## 11. 当前代码地图

| 职责 | 文件 |
|---|---|
| 数据结构 | include/st/Types.h |
| PDK 量化和不同 master 候选 | src/PdkCatalog.cpp |
| 四类变换 | src/Transform.cpp |
| Change Set | src/ChangeSet.cpp |
| 自动 VBIAS 模板 | src/AutoBias.cpp |
| DC 求解 | src/DcSolver.cpp |
| 功能/VBIAS 封装 | src/Packaging.cpp |
| OA plan | src/OaPlan.cpp |
| materialize/publish 门禁 | src/Materialization.cpp |
| round-trip | src/VariantVerifier.cpp |
| 命令行串联 | src/Cli.cpp、src/Standalone.cpp |
| Virtuoso 后端 | src/VirtuosoBackend.cpp、server/st_virtuoso_backend.sh |
| PDK 扫描 SKILL | server/skill/scan_pdk.il、tech_adapter.il |
| OA 物化 SKILL | server/skill/pdk_adapter.il、skill/topology_variant.il |
| Maau/Spectre Host 契约 | integration/maau/op_simulation_provider.* |
| Site Host 链接边界 | integration/maau/site_op_simulation_host.* |

---

## 12. 当前真实实施状态（2026-09-30）

本轮评审记录见 `st-engine-maau/docs/LDO结构变换_需求代码测试差距评审_2026-09-30.md`，实施记录见 `st-engine-maau/docs/superpowers/plans/2026-09-30-unified-ldo-closure.md`。下文 12.2～12.4 的 A/B 和测试失败是**修改前基线**；本轮已在本地修正 A/B，增加 Case 两项电流门禁，PdkCatalogTest、StandaloneTest、DcSolverTest 和 CliWorkflowTest 聚焦通过。真实 Site Adapter、Maau Host 与 Capless 服务器实验仍未完成。完整兼容回归以本轮最新执行日志为准。

### 12.1 已有本地能力

以下只表示代码和本地契约存在，不等于真实服务器通过：

- 四类结构化网表变换；
- Change Set、undo/fresh、多操作重放；
- 功能封装和独立 VBIAS 封装；
- 一套通用、无 IREF 的五角色模板及其 N/P 互补连接；
- PDK 参数量化；
- 候选搜索、硬约束、排名和 PVT 数据结构；
- OA plan、source 保护和 round-trip 框架；
- Maau/Spectre OpSimulationHost 公共六步契约。

### 12.2 修改前异型候选差距

工作区上一轮加入了 `device_family`、`flavor_id` 的 TSV/JSON 字段和“同 family、不同 flavor”筛选；这与本轮用户明确的“同极性、不同 master”定义冲突。二者不再是候选准入的必填信息。PDK 原始元数据若存在仍可保留，但产品路径不依赖它们。

涉及文件至少包括：

~~~text
include/st/Types.h
src/PdkCatalog.cpp
src/Standalone.cpp
server/skill/scan_pdk.il
server/skill/tech_adapter.il
server/skill/export_snapshot.il
tests/PdkCatalogTest.cpp
tests/DcSolverTest.cpp
tests/CascodeTransformTest.cpp
tests/StandaloneTest.cpp
~~~

### 12.3 修改前基线测试结果

实际执行：

~~~bash
cd "/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau"
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
~~~

结果：

- 编译成功；
- 在失败点之前的 15 个测试程序完成；
- StandaloneTest 有 2 个失败断言：
  1. 测试 TSV 没有 family/flavor，当前实现拒绝了不同 master；
  2. 候选 JSON 预期与当前实现的拒绝原因不一致；
- 脚本失败即停，本轮 VirtuosoBackendTest、CliWorkflowTest、MaauContractTest 未继续执行；
- 当前不能宣称全量回归全绿。

### 12.3.1 本轮修正后的本地回归（2026-09-30）

在上述改动之后重新执行相同两条命令，构建和测试均退出 0；测试脚本报告 19 个测试程序、2 个 demo、CLI help、server backend contract 和 14 个 shell 语法检查通过。该结果只覆盖本地代码、模拟宿主与脚本契约；真实 ICADVM18.1/PDK/Maau/Spectre 仍为 `planned_not_run`。新增的电阻额定电压/功耗门禁还未实现，不能据此称发布条件全部具备。

### 12.3.2 电阻门禁本地回归（2026-10-06）

新增电阻 OP/PDK 额定值 TSV、端电压/功耗/电流校验、候选与最终 staging/PVT 的缺证据拒绝、Source/VBIAS 封装实例绑定和服务器 runner 三文件事务回滚。本地 `ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh` 与 `ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh` 均退出 0：20 个测试程序、2 个 demo、CLI help、server backend contract、14 个 shell 语法检查通过。真实站点尚未提供从当前 PDK 取得实例几何及 Corner/温度额定值、从 Spectre 提取电阻两端电压与电流的 Host；所以此处仅为 `verified_local`，真实 Capless、其他 Case 和发布验收仍为 `planned_not_run`。

### 12.3.3 候选 OA 回读门禁本地回归（2026-10-07）

每个候选在 DC 前核对 OA 父图及所有封装子 Cell；指定路径回读不占用最终源图/派生图证据；重复 generate 原子分配新的候选编号，保留已有 OA 名称和证据。测试覆盖父图连接漂移、子 Cell 参数漂移、缺子 Cell、额外层级和额外指令，均阻止候选仿真及发布，具体原因进入 `host_message`。完整兼容构建及测试均退出 0：20 个测试程序、2 个 demo、CLI help、server backend contract、14 项 shell 语法检查通过。日志保存于 `st-engine-maau/docs/validation/2026-10-07/`。此结果为 `verified_local`；真实 Site PDK Adapter/Maau Host 的实现与链接、导入 Case 自动映射、整机 IQ 口径和真实 Capless 验收仍未完成。

### 12.3.4 基于 KimiCode 的具体站点接入开发（2026-10-07）

独立审查后修正真实 CDF Spectre 端序、Case/模型文件指纹与活动路径绑定、同文件多模型 sections、单指/总宽度区分、fast 网表原始 include 目录、同模型按实际 OA master 精确匹配以及 root/wrapper 参数作用域。新增只读 `device-bindings` 沿用既有 Virtuoso 批量入口；实际使用中的每个 PDK 实例都必须与网表模型匹配，失配或漏实例在仿真之前拒绝。用户可选 MOS 仍限定所选核心 Cell 当前层。

已新增 Maau v2 工艺解析器、真实 OA/CDF 的 Site SKILL 回调、Case 自动导入入口，以及调用现有 Maau API 的原生运行时和 OP Provider。Case 可按自身 tech name 与 TECH_ROOT_PATH 发现工艺配置，Bench 用唯一候选或用户明确选择；当前 generate 重扫通过的完整 catalog 路径已贯穿 baseline、候选及最终 OP。实际 OA DUT/Bench 导出后才组装隔离仿真环境，核对唯一 DUT、端口、模型/变量、工作点符号、DUT 相对实例名称、电阻实际几何和 Corner/温度额定值；Bench 电气条件变化阻止继续复用旧基线。

本地普通/兼容 C++ 构建退出 0；完整回归为 20 个 C++ 测试程序、2 个 demo、CLI help、server backend contract、16 项 shell 语法检查及 18 项新增配置/OP 测试。新增 OP 使用进程契约 fixture，不能当 Spectre 测量。具体实现和部署输入见 `st-engine-maau/integration/maau/KIMICODE_SITE_INTEGRATION.md`；日志见 `docs/validation/2026-10-07/site-build.log` 与 `site-tests.log`。完整 Maau 原生编译/链接、真实 PDK 资料填充、现场 SKILL/OA/PSF、整机 IQ 口径及实际 Capless 验收仍待完成。已有读取/封装/回读命令由用户报告通过，应复用其后端，不将缺少 SSH 当成停止开发的条件。

### 12.3.5 独立工程与原始 PDK 路径入口（2026-10-07，当前）

本轮用户纠正后，新增独立 `standalone.py`、`standalone_pdk.py`、`cadence_runtime.py`、`op_provider.py` 和共享数据处理，PDK 原始 probe 沿用现有 Virtuoso 批量入口。输入自己的 PDK 根目录与本次电路仿真条件，不读取 Maau Case/Registry；工作点直接调用 OCEAN/Spectre。默认 setup 移除固定 Maau 安装路径及 Maau 运行时链接要求；默认 C++ 构建不包含 Maau 集成。

自动解析只接受真实 OA/CDF 与模型声明证明的类型/参数。PDK 的加密模型、特有参数语义、范围、Bulk/Well、可靠性和电阻额定值仍需实际数据核对，缺失时报告并拒绝相应自动候选。不能以本地契约测试将“任意 PDK 仅给目录即可全部完成”写成已验收。

当前验证日志为 `st-engine-maau/docs/validation/2026-10-07/standalone-build.log` 和 `standalone-tests.log`；最终计数以这些命令的退出码和输出为准。真实 Cadence/PDK/DC/PVT 尚未执行，Maau 原生编译已经退出本需求必需步骤。

本轮独立构建与完整测试均退出 0：19 个 C++ 测试程序、2 个 demo、CLI help、server backend contract、17 项 shell 语法检查，以及 10 项 Site + 10 项 OP 测试。复审发现并修复 Profile 变量被 nominal DUT 局部参数遮蔽、CDF 后缀重复换算/lengthMetric 缺失，以及未知 PDK master 被漏检三项问题；增加失败用例后再次完整回归通过。当前模型输入支持本次 profile 指定的目录外模型与字面 include；实际 CDF/文档范围与模型域取交集，未知单位或缺 CDF 不使用模型范围冒充。每个选中 PDK master 的物理绑定必须可证明；明确的非目标模型单独核对，未知 master 拒绝继续仿真。

服务器验证前仍须用用户提供的真实 PDK/模型文件和 Bench 条件形成该 Capless 的配置；可靠性、Bulk/Well、电阻额定值缺资料时不能编造。整机 IQ 的负载扣除或无载定义仍待确认，当前只对已确认的主支路相对偏差及新增 VBIAS 电流门禁负责。真实 PDK 特有模型声明、CDF callback、OA/PSF 行为需实际数据和服务器验证，不能据本地测试宣称任意 PDK 均已适配。

### 12.4 已确认的高优先级问题及进展

最后收口时让 OCEAN netlisting 显式加载并固定本次 `ST_SKILL_INIT`，与初始 PDK probe/OA 后端使用同一绝对、可读初始化路径；保存 PDK 输入别名以便追溯；有来源的最大 Stack 级数从规则贯穿扫描目录，核心同时执行工具最多 100 级限制。相关聚焦测试与完整独立回归再次退出 0。

#### A. 不同 master 候选与用户定义冲突

**本地已修复。** `SelectCrossFlavorCandidates` 只按同极性、不同 master 和 PDK/CDF/电压域/可靠性/Bulk 证据筛选；非 MOS 不追加 MOS 专属拒绝原因。StandaloneTest 与 PdkCatalogTest 已更新业务预期并聚焦通过。

#### B. 重扫 PDK 没有成为后续唯一数据源

修改前 src/Cli.cpp 的行为：

- inspect 主要加载 snapshot 产生的 before/device_catalog.tsv；
- generate 调用 scan-pdk 得到 scanned，但主要只比较 pdk_version；
- 后续 BackendDcEvaluationHost、SolveAutoBias、BuildAutoBiasTemplate、Change Set replay 和 OA plan 仍使用旧 catalog。

**本地已修复。** inspect 现在先 `scan-pdk`，以该目录生成会话器件策略后再 snapshot；generate 重扫并比较版本和包含所有 TSV 字段的稳定内容 hash，重新生成器件策略，后续求解、重放、OA plan 与回读使用核对后的目录。CliWorkflowTest 的目录漂移、snapshot 不一致与扫描先行用例聚焦通过。真实站点仍待验证。

#### C. 真实 Site PDK Adapter 接入状态

当前默认实现是 12.3.5 的 `standalone_pdk.py` + 实际 OA/CDF probe + 生成的 `site_metadata_adapter.il`；下面 Maau 配置接入保留为历史可选来源，不是必需前置。

2026-10-07 已加入 `server/site/maau_config.py` 和 `server/skill/site_metadata_adapter.il`：按 Maau v2 工艺配置的准确器件类型、CDF 映射/离散允许值/单位、模型 Corner 解析元数据，并在现场核对真实 OA 库路径、tech attachment、symbol 和 CDF。具体 StSiteTechDescribeDevice 回调已有实现；实际 PDK 文件和可靠性、Bulk/Well、电阻几何/温度额定值仍需真实资料填充和服务器扫描验证。不能把配置中 LUT 普通电压当成可靠性额定值。

当前层 MOS 清单以真实 PDK 归属、已证明的 NMOS/PMOS 类型和 D/G/S 端子角色为最低收录条件：恰有三个外部端子的器件不要求 Bulk；四个及以上外部端子的器件必须证明 Bulk 角色。可靠性、Bulk 规则、CDF 不完整的已证明 MOS 仍应列出，具体 Cascode/VBIAS 操作再按自身要求拒绝。无法证明器件类型或端子角色的实例不得靠名称猜测，应在真实扫描报告里列为未识别对象供 Case 核对。2026-10-06 本地扫描器已将电阻准入改为已证明的电阻身份、Positive/Negative 端子和 CDF/域/Corner 证据；真实扫描和几何/温度额定值提取仍待站点验证。

#### D. 独立 OCEAN/Spectre Runtime 待真实验证

默认具体实现已经在 `server/site/cadence_runtime.py` 与 `op_provider.py` 中，直接调用 Cadence 工具，无 Maau 原生链接要求。下面公共六步契约与原生 Maau 代码是历史可选接法；产品后续工作是实际 PDK/Bench 数据配置和服务器 OCEAN/Spectre 验收。

公开 Host 契约包含：

1. ValidateBench；
2. RebindDutInTemporaryCase；
3. PreserveBenchEnvironment；
4. RequestDcOpAndOppoint；
5. RunSpectre；
6. ExtractOperatingPoint。

2026-10-07 新增具体进程接入：`maau_site_runtime.cc` 调用实际 `CircuitDesignConfig`、`TestBenchManager`、`OceanNetlistCreator` / `NetlistBuilder`、`Simulator` 和 `DCHelper::ReadRawPsfData`；`maau_case.py` 导入 Case，`maau_op.py` 从实际 OA 导出 DUT/Bench，保留条件并执行 OP/有符号 PSF 提取。用 `scripts/build_maau_runtime.sh` 构建后可直接接入既有 backend 的 run-op，不要求再另写外部 factory。原 factory 接法仍可兼容。完整 Maau 原生编译/链接及现场 PSF/OA 验证尚未完成；本地 KimiCode 私有头文件缺损，不能冒充真实链接证据。

#### E. 没有真实服务器端到端证据

尚不能宣称：

- ICADVM18.1 真实 PDK 全目录扫描通过；
- 本次真实 Bench + 独立 OCEAN/Spectre 候选 DC/OP 通过；
- 通用 VBIAS 的 N/P 连接在真实 Capless 中有解并通过 Case 门禁；
- 最终 OA 物化、check/save、回读和发布通过；
- PVT 失败真实阻止发布。

---

## 13. 新 Agent 必须先做的评审

本轮已完成“需求—代码—测试差距表”，文件为 `st-engine-maau/docs/LDO结构变换_需求代码测试差距评审_2026-09-30.md`。后续接手人先核对该表和最新测试结果，再继续真实站点任务。

至少逐项审查：

| 需求 | 必须给出的证据 |
|---|---|
| NMOS/PMOS Cascode 位置 | 实现函数、行号、网表测试 |
| 原 Gate 不变 | 同型和异型的结构测试 |
| Source 串联电阻 | D/G/B 保持、Source 改接、电阻端子 |
| Stack 命名和共栅 | M0、M0_S1…及公共 Gate |
| 不同 master Cascode | 同极性、不同 master、PDK 兼容性和拒绝原因 |
| 无 IREF 自给电模板 | 同一模板思想的 N/P 两种端口、角色和连接 |
| 真实 PDK 唯一数据源 | inspect 到 generate 的 catalog 数据流 |
| 真实 OA 候选仿真 | 候选 CellView、回读、身份和 OP |
| PVT 阻塞发布 | 最终 staging 的 Corner 门禁 |
| source 保护 | clone、source round-trip 和 publish 顺序 |

状态统一使用：

- verified_local；
- gap；
- conflict；
- planned_not_run；
- verified_server。

电路评审还必须回答：

1. 通用模板在 N/P 两种极性下的连接和反馈方向是否正确；
2. 真实 Capless 的轨网和低 headroom 下是否有解；
3. 硬约束是否足以防止错接、过压、线性区和异常 IQ；
4. 排名是否可能选择“程序合法但模拟电路不合理”的解；
5. 当前单套通用方案在 Capless 的适用边界是什么；其他架构暂无真实证据，不预设分叉拓扑。

如建议修改拓扑，必须提供反例、网表或仿真证据，不能只凭个人习惯。

---

## 14. 开发任务顺序

### Task 0：固化基线

交付：差距表、当前完整测试日志、计划内文件清单。

- 完整阅读本文和第 18 节；
- 保存当前文件快照；
- 执行全量测试；
- 评审差距表后再改代码。

### Task 1：收口不同 master 候选

文件：

~~~text
include/st/Types.h
src/PdkCatalog.cpp
src/Standalone.cpp
server/skill/scan_pdk.il
server/skill/tech_adapter.il
server/skill/export_snapshot.il
tests/PdkCatalogTest.cpp
tests/StandaloneTest.cpp
tests/CascodeTransformTest.cpp
tests/DcSolverTest.cpp
~~~

要求：

1. 先写/保留失败测试；
2. 明确同极性、不同真实 PDK master；
3. 不依赖 family/flavor 字段决定准入；
4. 修正 StandaloneTest 和 PdkCatalogTest 的业务预期；
5. 仅对同极性 MOS 附加 MOS 专属拒绝原因；
7. 聚焦测试后运行全量回归。

通过：独立 `./scripts/test.sh` 全绿，且仍严格要求真实 PDK/CDF/可靠性/Bulk 证据；旧 Maau 桥接仅在需要维护时额外启用兼容构建。

### Task 2：真正串起权威 PDK 目录

主文件：src/Cli.cpp、src/Standalone.cpp、src/VirtuosoBackend.cpp 和对应测试。

要求：

1. 先写测试证明当前 generate 重扫后仍消费旧 catalog；
2. inspect 显式使用 scan-pdk 权威结果；
2a. scan-pdk 必须先于 snapshot；由该目录生成当前会话的端序/CDF 策略并传给 snapshot、source/target/package 回读；
3. session 保存 pdk_version 和 catalog hash；
4. generate 重扫同时比较版本和 hash；
5. scanned 进入 solver、VBIAS、replay、packaging、OA plan、verify；
6. 目录漂移时要求重新建立会话；
7. 测试“同版本但内容变化”也会被拒绝。

### Task 3：真实 Site PDK Adapter

通用实现已写出；本次 PDK 的特殊规则由实际数据适配，不把具体绝对路径写进通用代码。

必须覆盖：

- DUT PDK 身份和 PDK 库枚举；
- StSiteTechDescribeDevice；
- OA master 和 terminal order；
- CDF 语义、范围、网格、离散值、整数性；
- 可靠性、Bulk/Well、电压域、最大 Stack；
- PDK primitive 正向归属证明；
- 电阻参数和多端绑定。

通过：真实 scan-pdk 退出码 0，非空目录中的记录可追溯到实际 PDK CellView，无名称猜测。

### Task 4：独立 OCEAN/Spectre Runtime 真实验证

复用项目内独立 Runtime 与 OP Provider，按真实 Bench、模型和 Corner 校对；不要求 Maau 私有库或 Host 原生链接。

通过：

- 先用未修改的已知 DUT/Bench 取得可对照 DC/OP；
- 再对一个物化候选 CellView 取得完整 OP；
- 七项身份字段一致，错 DUT/Bench/Corner 不复用；
- 启动失败、不收敛、数据提取失败有不同退出码和日志。

### Task 5：真实候选求解闭环

- 真实 PDK 选择模板器件；
- 每候选生成唯一 OA CellView；
- 从该 CellView 回读网表；
- 真实 Spectre 仿真；
- 保存候选参数、身份、网表、OP 和拒绝原因；
- 无解时不写最终 OA plan、不 clone、不 publish。

### Task 6：真实 Virtuoso 生成与回读

按独立新会话依次验证：

1. B0 无修改 round-trip；
2. B1 Source 串联电阻；
3. B2 二级共栅 Stack；
4. B3 NMOS/PMOS 同型 Cascode + 自动 VBIAS；
5. B4 NMOS/PMOS 不同 master Cascode + 自动 VBIAS；
6. B5 多操作封装、多 VBIAS 独立性、100 级 Stack；
7. PVT 失败确实阻止发布。

### Task 7：文档收口

- README 不得把“命令框架存在”写成“真实后端通过”；
- 历史方案开头增加被本文取代的说明；
- 服务器验证文档删除旧的复用 Bias/IREF 要求；
- 只有收到真实命令、退出码、日志和产物后，才把 planned_not_run 改为通过。

---

## 15. 开发和证据规则

- 每项修复先有稳定失败测试和 RED 证据；
- 再写最小修复；
- 先跑聚焦测试，再跑完整独立回归；需要维护可选历史桥接时另跑兼容回归；
- 本地 Fake Host 结果明确标为 local/fake；
- 真实通过必须附命令、退出码、日志、L/C/V、plan、回读网表、OP/PVT 和 validation.txt；
- 不把计划命令、历史输出或静态脚本检查写成“已执行”；
- 不为测试变绿而放宽 PDK 缺字段规则。

本地完整回归命令：

~~~bash
cd "/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau"
./scripts/build.sh
./scripts/test.sh
~~~

最终预期：退出码 0，独立产品的全部 C++、Python、后端契约与脚本检查通过。MaauContractTest 只属于显式启用的可选兼容构建。

服务器详细流程参考：

- st-engine-maau/docs/standalone-pdk-server-validation.md（当前入口与输入）；
- st-engine-maau/docs/automatic-pdk-vbias-server-validation.md；
- st-engine-maau/docs/superpowers/plans/2026-09-29-real-pdk-vbias-e2e-continuation-handoff.md 的 Site Adapter、Host 和验收章节。

执行前须先按本文修正其中旧 VBIAS/IREF 口径。

---

## 16. 最终完成定义

只有以下条件全部满足，才能宣称需求完成：

1. 本地独立全量回归全绿；
2. Site PDK Adapter 能扫描真实 master/CDF/可靠性/Bulk/Well；
3. 全链路使用同一权威 PDK 目录；
4. 项目内独立 OCEAN/Spectre Runtime 完成已知真实 Bench 对照；
5. 同一通用方案的 N/P 互补模板在可用的真实 Case 中各完成一次有解仿真；真实 Capless 不具备对应可改目标时记录无法覆盖的原因，不伪造成功；
6. 四类变换均完成真实 OA 生成和回读；
7. PMOS/NMOS Cascode 位置、Gate、Bulk、中间网和 VBIAS 有网表证据；
8. source 未改、失败不发布、成功才 publish 有现场证据；
9. 配置 PVT 时，失败 Corner 能阻止发布；
10. 所有成功结论可追溯到原始命令、退出码和产物。

---

## 17. 可直接交给另一个 Agent 的任务指令

~~~text
你接手的是 st-engine-maau。

先完整阅读本文、st-engine-maau/docs/LDO结构变换_需求代码测试差距评审_2026-09-30.md，以及 st-engine-maau/docs/superpowers/plans/2026-09-30-unified-ldo-closure.md。

本轮已将异型 Cascode 改为同极性、不同 master，完成本地 PDK 目录身份核对，并为 Cascode 增加 Case 主支路电流偏差和 VBIAS 支路电流上限。不要恢复 family/flavor 准入要求，也不要把现有 iq_delta 字段当整机 IQ。查看最新全量测试结果；未实际执行的测试一律标 planned_not_run。

本项目独立编译运行，KimiCode 仅用于参考。当前默认入口是 server/site/standalone.py，从源工艺关联自动发现 PDK（可选 --pdk-root 覆盖），接受独立电路仿真条件；不得恢复 Maau 软件、Registry、Case 或原生链接要求，也不得照抄参考工程的地址。先读 docs/standalone-pdk-server-validation.md 与 docs/superpowers/plans/2026-10-07-standalone-path-correction.md。

当前最重要的剩余工作是真实 Capless 的 PDK 数据适配和服务器验收：取得实际 PDK/模型路径，核对真实 Bench、轨网、Corner/温度、模型及 PDK 电气规则来源；暂无性能 Spec 时两项电流限值同时省略，现阶段只验直流可行性；用独立 Cadence Runtime 做只读扫描和未改 DUT 基线 OP，再做一个独立 OA 候选与最终回读。没有 SSH 不作为停止本地开发的条件。每步保留命令、退出码、日志、L/C/V、PDK TSV、plan、OP/PVT 和 validation.txt。

本地 Fake Host 通过仅算 verified_local，不算真实 ICADVM18.1/PDK/Maau/Spectre 验收。真实通过必须有原始证据，不能按计划文字改写状态。
~~~

---

## 18. 必读文件索引

需求和端到端边界：

1. 本文；
2. st-engine-maau/docs/superpowers/plans/2026-09-29-real-pdk-vbias-e2e-continuation-handoff.md；
3. st-engine-maau/docs/automatic-pdk-vbias-server-validation.md；
4. st-engine-maau/README.md（状态以本文为准）。

核心代码：

~~~text
include/st/Types.h
include/st/AutoBias.h
include/st/DcSolver.h
src/PdkCatalog.cpp
src/AutoBias.cpp
src/DcSolver.cpp
src/Transform.cpp
src/Packaging.cpp
src/OaPlan.cpp
src/Materialization.cpp
src/VariantVerifier.cpp
src/Standalone.cpp
src/Cli.cpp
src/VirtuosoBackend.cpp
~~~

服务器和 SKILL：

~~~text
server/st_virtuoso_backend.sh
server/setup_backend.csh
server/skill/scan_pdk.il
server/skill/tech_adapter.il
server/skill/export_snapshot.il
server/skill/pdk_adapter.il
skill/topology_variant.il
integration/maau/op_simulation_provider.h
integration/maau/op_simulation_provider.cc
integration/maau/site_op_simulation_host.h
integration/maau/site_op_simulation_host.cc
~~~

核心测试：

~~~text
tests/PdkCatalogTest.cpp
tests/AutoBiasTest.cpp
tests/DcSolverTest.cpp
tests/CascodeTransformTest.cpp
tests/ResistorTransformTest.cpp
tests/StackTransformTest.cpp
tests/PackagingTest.cpp
tests/OaPlanTest.cpp
tests/VariantVerifierTest.cpp
tests/StandaloneTest.cpp
tests/VirtuosoBackendTest.cpp
tests/CliWorkflowTest.cpp
tests/MaauContractTest.cpp
~~~

---

## 19. 一句话结论

本需求在不修改源电路的前提下，以本次输入的真实 PDK 为器件和参数来源，完成当前层 MOS 的四类结构变换；为每个 Cascode 按同一通用方案构造无外部 IREF 的独立 VBIAS；通过真实 OA 候选和项目内独立 OCEAN/Spectre 自动求参；最后用 Virtuoso 父子 Cell 回读和本次电路的电气门禁证明派生电路可以进入后续 Sizing。第一份真实电路验收先使用现有 Capless。
