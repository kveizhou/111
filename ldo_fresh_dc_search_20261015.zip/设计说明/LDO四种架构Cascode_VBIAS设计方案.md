# LDO 四种架构 Cascode VBIAS 设计方案

> 2026-10-15 接法修订：同型/异型、NMOS/PMOS 均在原管 D 侧加管，原 G/S/Bulk 接线不变；PMOS 复制支路同步更正。本轮软件验收范围以 st-engine-maau/docs/01-需求与决策.md 的当前要求为准，本文历史性能目标不增加本轮门槛。

## 1. 方案目标

本方案用于 CAP、Capless、FVF、RES 四种固定 LDO 架构中的 Cascode 结构变换，规定新增 NMOS Cascode 和新增 PMOS Cascode 所使用的 VBIAS 生成电路。

本方案重点确定：

- NMOS Cascode 使用的 `VBIAS_N` 生成结构；
- PMOS Cascode 使用的 `VBIAS_P` 生成结构；
- 四种 LDO 架构如何共用固定 Bias 拓扑；
- 每个 Case 只需要调整哪些参数；
- 不同目标偏置电压如何通过参数确定；
- PDK、CDF、电压域、启动、静态电流及稳定性约束；
- 每个 Cascode 如何自动新增独立 Bias 支路。

本方案采用以下最终方向：

1. 不针对 CAP、Capless、FVF、RES 分别重新设计四套 Bias 电路；
2. 固定一套 NMOS Cascode Bias 模板和一套互补的 PMOS Cascode Bias 模板；
3. 四种架构只配置参考电流、镜像比例、Replica 尺寸、电源域、Bulk、使能和负载上限；具体 PDK MOS 由工具从当前 PDK/Case 目录自动选择；
4. 每个 Case 在发布前完成 PVT、可靠性、启动、静态电流和稳定性验证；
5. 结构变换时只允许调用已经登记并验证通过的模板参数集，不允许临时自由拼接 Bias 电路；
6. 如果固定模板无法覆盖某个目标器件的 VBIAS 要求，则该 Cascode 变换不可生成。

本文作为 `LDO_MOS四种结构变换设计方案.md` 中 Cascode VBIAS 部分的详细设计约束。与原文第 8 节中的旧 VBIAS 生成方式发生冲突时，以本文确定的固定有源模板方案为准。

---

## 2. 总体设计原则

### 2.1 固定两套互补拓扑

当前只固化两套生产用 VBIAS 拓扑：

| 模板 | 服务对象 | 电流驱动方向 | Bias 生成器件 |
|---|---|---|---|
| `VBIAS_N_CASCODE` | 新增 NMOS Cascode | PMOS 电流镜从高电源轨向 Bias 支路供流 | NMOS Replica/Cascode Replica |
| `VBIAS_P_CASCODE` | 新增 PMOS Cascode | NMOS 电流镜从 Bias 支路向低电源轨吸流 | PMOS Replica/Cascode Replica |

两套模板互为极性镜像。四种 LDO 架构不改变模板内部连接关系，只使用不同的参数集。

### 2.2 原 MOS Gate 保持不变

以原 MOS `M0(D0,G0,S0,B0)` 为例，增加 Cascode 后：

- 原 MOS 的 Gate 仍然连接原网络 `G0`；
- 新增 Cascode MOS 的 Gate 才连接模板输出的 VBIAS；
- 不使用 VBIAS 替换原 MOS 的 Gate；
- 不把原 MOS Gate 与新增 Cascode Gate 短接；
- 原控制环路、使能网络和动态控制关系保持不变。

### 2.3 只允许参数变化

CAP、Capless、FVF、RES 四种架构使用同一模板电路时，只允许调整以下参数：

- MOS Flavor 和耐压等级；
- W、L、nf、m 或 PDK 定义的等效尺寸；
- 参考电流来源；
- 参考电流值和镜像比例；
- Replica 与主支路的尺寸比例；
- 高、低电源轨和电压域；
- Bulk/Well 网络；
- enable、power-down 和 startup 的控制网络；
- VBIAS 允许范围；
- 最大 Gate 电容。

不允许针对某个 Case 临时增加理想电压源、临时改成电阻分压、临时增加未经登记的 MOS 级数，或改变模板内部端子关系。

### 2.4 真实 PDK 约束

模板中的所有 MOS 必须来自目标 Case 实际使用的 PDK，并满足：

- Library、Cell、View 真实存在；
- 端子名称和端子顺序明确；
- CDF 参数名称、类型和单位正确；
- W、L、nf、m、鳍数等参数位于合法范围和合法栅格；
- 器件 Flavor 与目标电压域兼容；
- 最大 `|VGS|`、`|VDS|`、`|VGB|`、结电压均不越界；
- Bulk/Well 接法符合 PDK 规则；
- 不默认假设 Drain 和 Source 可以互换；
- 不使用理想 MOS、理想电流源或理想电压源替代生产模板。

模板内部不固定为某一家 PDK 的具体 Cell 名。工具先扫描当前 PDK/Case 已登记的真实 OA 器件目录，再按模板角色、极性、电压域、端子定义和 PDK/CDF 限制自动选择 MOS。用户不选择 Mirror、Control Replica 或 Cascode Replica 的内部 Master。找不到合法真实器件时，整个 Cascode 变换拒绝生成。

### 2.5 Cascode 类型与本轮边界

- 同型 Cascode：新增管与原管极性相同且使用相同 PDK Master/Flavor。
- 异型 Cascode：新增管与原管极性仍然相同，但使用另一种经 Case/PDK 兼容矩阵批准的 Flavor、耐压类型或 Master。
- NMOS 上只加 NMOS，PMOS 上只加 PMOS；“异型”不表示 NMOS/PMOS 互换。
- Source 串联电阻和同栅 Stack 不使用本 VBIAS 模板。
- 对称管自动识别及对称联动修改不在本轮范围内。

---

## 3. Cascode 主支路的电压关系

### 3.1 NMOS Cascode

原 NMOS 为：

```text
M0(D0, G0, S0, B0)
```

增加 NMOS Cascode 后：

```text
D0
 │
M0_CAS   Gate = VBIAS_N
 │
 X
 │
M0       Gate = G0
 │
S0
```

端子关系为：

| 器件 | Drain | Gate | Source | Bulk |
|---|---|---|---|---|
| 原 NMOS `M0` | X | G0 | S0 | 保持 B0 |
| 新增 NMOS `M0_CAS` | D0 | VBIAS_N | X | 按 PDK/Case 规则 |

为了使原 NMOS 保留要求的漏源余量，中间节点目标值近似为：

$$
V_{X,target}
\approx
V_{S0}+V_{DSAT,M0}+V_{margin}
$$

新增 NMOS Cascode 的 Gate Bias 目标值近似为：

$$
V_{BIAS,N,target}
\approx
V_{X,target}+V_{GS,M0\_CAS}
$$

因此：

$$
V_{BIAS,N,target}
\approx
V_{S0}+V_{DSAT,M0}+V_{GS,M0\_CAS}+V_{margin}
$$

`VBIAS_N` 不是简单等于一个固定阈值电压，也不默认等于原 Gate 电压。

### 3.2 PMOS Cascode

原 PMOS 为：

```text
M0(D0, G0, S0, B0)
```

新增 PMOS Cascode 与 NMOS 一样串在原管 Drain 一侧，原 Gate、Source、Bulk 网络保持不变：

```text
S0
 │
M0       Gate = G0
 │
 X
 │
M0_CAS   Gate = VBIAS_P
 │
D0
```

端子关系为：

| 器件 | Drain | Gate | Source | Bulk |
|---|---|---|---|---|
| 原 PMOS `M0` | X | G0 | S0 | 保持 B0 |
| 新增 PMOS `M0_CAS` | D0 | VBIAS_P | X | 按 PDK/Case 规则 |

原 PMOS 的 Source 保持在 `S0`。若原管需要保持饱和，中间节点的初始目标近似为：

$$
V_{X,target}
\approx
V_{S0}-|V_{DSAT,M0}|-V_{margin}
$$

其中 `|VDSAT|` 表示 PMOS 对应的饱和余量，具体字段名和符号以目标 PDK 的工作点定义为准。

新增 PMOS Cascode 的 Gate Bias 目标值近似为：

$$
V_{BIAS,P,target}
\approx
V_{X,target}-|V_{SG,M0\_CAS}|
$$

`VBIAS_P` 需要相对于高电源轨进行设计，不能直接使用 NMOS Bias 模板输出。

### 3.3 目标不是单点电压

每个 Case 不只登记一个 TT、常温下的标称 VBIAS，而是登记每个工作条件下允许的电压窗口：

$$
V_{BIAS,min}(corner,mode)
\leq
V_{BIAS}(corner,mode)
\leq
V_{BIAS,max}(corner,mode)
$$

模板只有在全部要求的 PVT、输入电压、负载和工作模式下均落在窗口内，才可以登记为该 Case 的可用模板。

---

## 4. NMOS Cascode 的 VBIAS_N 方案

### 4.1 固定结构

NMOS Cascode 使用 `VBIAS_N_CASCODE` 模板。

模板由两部分组成：

1. PMOS 参考及镜像输出支路；
2. NMOS 低压 Replica Bias 支路。

概念结构为：

```text
                         VHIGH
                           │
               ┌───────────┴───────────┐
               │                       │
            P_REF                  P_OUT_N
      D=G=PBIAS_REF          Gate=PBIAS_REF
               │                       │
          IREF_N_SINK               VBIAS_N ──────> 新增 NMOS Cascode Gate
                                       │
                                 N_CAS_REP_N
                                D=G=VBIAS_N
                                       │
                                    X_REP_N
                                       │
                                 N_CTRL_REP_N
                                Gate=VG_REP_N
                                       │
                                      VLOW
```

其中：

- `P_REF` 与 `P_OUT_N` 组成 PMOS 电流镜；
- `IREF_N_SINK` 为 Case 已批准的参考吸流支路；
- `P_OUT_N` 向 NMOS Replica Bias 支路提供电流；
- `N_CTRL_REP_N` 模拟原 NMOS 的工作条件；
- `N_CAS_REP_N` 模拟新增 NMOS Cascode；
- `N_CAS_REP_N` 采用 Gate 与 Drain 相连的 Replica 连接；
- `VBIAS_N` 作为模板输出，只连接新增 NMOS Cascode 的 Gate；
- `VG_REP_N` 来自 Case 登记的原支路参考 Gate 或等效稳定参考节点；
- `VLOW` 为该电压域批准的低电源轨；
- `VHIGH` 为 PMOS 电流镜使用的高电源轨。

### 4.2 端子关系

| 器件 | Drain | Gate | Source | Bulk |
|---|---|---|---|---|
| `P_REF` | PBIAS_REF | PBIAS_REF | VHIGH | 批准的高电位 Well |
| `P_OUT_N` | VBIAS_N | PBIAS_REF | VHIGH | 批准的高电位 Well |
| `N_CAS_REP_N` | VBIAS_N | VBIAS_N | X_REP_N | 批准的低电位 Bulk |
| `N_CTRL_REP_N` | X_REP_N | VG_REP_N | VLOW | 批准的低电位 Bulk |

如果目标 PDK 使用附加 Bulk、Well、Guard 或其他端子，应按照已登记的 PDK 端子映射补充，不能丢弃额外端子。

### 4.3 参数关系

PMOS 镜像输出电流为：

$$
I_{BIAS,N}
\approx
I_{REF,N}
\times
\frac{(W/L)_{P\_OUT\_N}}{(W/L)_{P\_REF}}
$$

实际关系还会受到有限输出阻抗、VDS 不一致、体效应、尺寸量化和 PDK 模型影响，因此镜像比例只是初始设计关系，最终值以真实模型仿真为准。

Replica 支路需要通过以下参数使 `X_REP_N` 接近主支路要求的中间节点余量：

- `N_CTRL_REP_N` 的 Master；
- `N_CTRL_REP_N` 的 W/L/nf/m；
- `N_CAS_REP_N` 的 Master；
- `N_CAS_REP_N` 的 W/L/nf/m；
- `I_BIAS_N`；
- `VG_REP_N`；
- `VHIGH`、`VLOW`；
- Mirror 与 Replica 的尺寸比例。

设计目标为：

$$
V_{X\_REP\_N}
\approx
V_{S0}+V_{DSAT,M0}+V_{margin}
$$

并满足：

$$
V_{BIAS,N}
\approx
V_{X\_REP\_N}+V_{GS,N\_CAS\_REP\_N}
$$

### 4.4 为什么不直接使用一只二极管 NMOS

只使用一只 Gate 与 Drain 相连的 NMOS 时：

$$
V_{BIAS,N}\approx V_{LOW}+V_{GS}
$$

该电压没有显式包含原 NMOS 需要保留的 `VDSAT` 余量，不能保证主支路中间节点 X 落在要求范围内。

因此，本方案不把“单只二极管连接 NMOS”作为四种 LDO 的统一生产模板。固定模板使用控制管 Replica 与 Cascode Replica 组成的低压 Bias 支路，通过尺寸比例和电流密度调节 `VGS+VDSAT` 关系。

### 4.5 输出使用方式

`VBIAS_N` 只用于：

- 同型 NMOS Cascode；
- 同极性异型 NMOS Cascode；
- Case 明确登记为兼容的 NMOS Cascode 组。

不得用于：

- PMOS Cascode；
- 原 MOS 的 Gate；
- 动态信号节点；
- 不同电压域中的器件；
- 未经验证的不同 Flavor；
- 需要独立 enable 或独立启动顺序的支路。

---

## 5. PMOS Cascode 的 VBIAS_P 方案

### 5.1 固定结构

PMOS Cascode 使用与 NMOS 方案互补的 `VBIAS_P_CASCODE` 模板。

模板由两部分组成：

1. NMOS 参考及镜像输出支路；
2. PMOS 低压 Replica Bias 支路。

当前自给电模板的主支路为：

```text
VS_ORIG（原管 S）
  |
P_CTRL_REP_P   G=VG_CTRL（原管 G）
  |
X_REP_P
  |
P_CAS_REP_P    D=G=VBIAS_P
  |
VBIAS_P ──> 新增 PMOS Cascode Gate
  |
N_OUT_P       G=NBIAS_REF
  |
VLOW
```

参考支路为 `VHIGH → R_REF_P → NBIAS_REF → N_REF → VLOW`，`N_REF` 的 D、G 同接 `NBIAS_REF`。它与 `N_OUT_P` 组成 NMOS 电流镜，无需外部 IREF。`VS_ORIG`、`VG_CTRL` 分别绑定变换前原管的 Source、Gate 网络；VHIGH/VLOW 沿用 Case 的已有电源轨。

### 5.2 端子关系

| 器件 | Drain/正端 | Gate | Source/负端 | Bulk |
|---|---|---|---|---|
| `P_CTRL_REP_P` | X_REP_P | VG_CTRL | VS_ORIG | 按 PDK 规则 |
| `P_CAS_REP_P` | VBIAS_P | VBIAS_P | X_REP_P | 按 PDK 规则 |
| `N_OUT_P` | VBIAS_P | NBIAS_REF | VLOW | 按 PDK 规则 |
| `N_REF` | NBIAS_REF | NBIAS_REF | VLOW | 按 PDK 规则 |
| `R_REF_P` | VHIGH | — | NBIAS_REF | 按所选真实电阻定义 |

隔离阱 PMOS 采用源衬相连时，复制 Cascode 的 Bulk 接 X_REP_P，控制复制管的 Bulk 接 VS_ORIG；非隔离阱按已有高电位轨规则连接。原电路目标 MOS 的 Bulk 不改变。

### 5.3 参数关系

NMOS 镜像吸取的电流为：

$$
I_{BIAS,P}
\approx
I_{REF,P}
\times
\frac{(W/L)_{N\_OUT\_P}}{(W/L)_{N\_REF}}
$$

Replica 支路需要通过以下参数使 `X_REP_P` 接近主支路要求的中间节点余量：

- `P_CTRL_REP_P` 的 Master；
- `P_CTRL_REP_P` 的 W/L/nf/m；
- `P_CAS_REP_P` 的 Master；
- `P_CAS_REP_P` 的 W/L/nf/m；
- `I_BIAS_P`；
- `VG_REP_P`；
- `VHIGH`、`VLOW`；
- Mirror 与 Replica 的尺寸比例。

设计目标为：

$$
V_{X\_REP\_P}
\approx
V_{S0}-|V_{DSAT,M0}|-V_{margin}
$$

并满足：

$$
V_{BIAS,P}
\approx
V_{X\_REP\_P}-|V_{SG,P\_CAS\_REP\_P}|
$$

### 5.4 为什么不能复用 NMOS Bias 模板

NMOS Cascode 的 Gate Bias 以低电源轨为参考向上建立；PMOS Cascode 的 Gate Bias 以高电源轨为参考向下建立。

两者在以下方面不同：

- 电流方向相反；
- Mirror 极性相反；
- Replica 极性相反；
- 目标电压参考轨不同；
- Bulk/Well 接法不同；
- enable 后的安全钳位方向不同；
- PVT 漂移方向和可用电压余量不同。

因此，给 NMOS Cascode 使用的 PMOS 供流模板不能直接给 PMOS Cascode 使用。PMOS Cascode 必须使用互补的 NMOS 吸流模板。

### 5.5 输出使用方式

`VBIAS_P` 只用于：

- 同型 PMOS Cascode；
- 同极性异型 PMOS Cascode；
- Case 明确登记为兼容的 PMOS Cascode 组。

不得用于：

- NMOS Cascode；
- 原 PMOS 的 Gate；
- 动态信号节点；
- 不同电压域中的器件；
- 未经验证的不同 Flavor；
- 需要独立 enable 或独立启动顺序的支路。

---

## 6. 参考电流、启动与使能

### 6.1 参考电流不是模板自动产生的

电流镜只能复制已有参考电流，不能凭空产生稳定电流。

每个参数集必须明确登记：

- `IREF_N_SINK` 从哪里来；
- `IREF_P_SOURCE` 从哪里来；
- 参考电流在哪些模式下有效；
- 上电后何时建立；
- enable 关闭后如何处理；
- 参考电流的 PVT 范围；
- 新增镜像负载是否会改变原参考支路；
- 参考支路增加的静态电流如何计入 LDO IQ。

### 6.2 固定四种架构的参考来源

对于 CAP、Capless、FVF、RES 四种固定 LDO：

1. 架构维护者在 Case 中预先指定可复用的参考电流支路；
2. Bias 模板通过新增 Mirror 输出管复制参考电流；
3. 不直接截断或分走原参考电流；
4. 如果现有架构没有合格参考电流，则该 Case 必须绑定一个经过批准的参考电流单元；
5. 如果没有合格参考源和 startup，不允许生成 VBIAS 模板。

### 6.3 Startup

如果参考电流来自自偏置环路，需要确认不存在零电流稳定状态。模板参数集必须说明：

- startup 器件或 startup 支路；
- startup 触发条件；
- startup 退出条件；
- startup 峰值电流；
- 最慢 PVT Corner 下的建立时间；
- startup 对 VBIAS 节点的过冲；
- startup 是否影响 LDO 输出过冲和软启动。

只登记 Mirror 和 Replica、但不登记参考源及 startup 的参数集，不视为完整模板。

### 6.4 Enable 与关断状态

Bias 模板的 enable 必须与其服务的 LDO 工作模式一致。

关断时需要满足：

- `VBIAS_N` 不悬空，并回到 NMOS Cascode 的安全关断电位；
- `VBIAS_P` 不悬空，并回到 PMOS Cascode 的安全关断电位；
- 不通过 Bias 支路形成额外漏电通路；
- 不在未供电电压域之间形成反向供电；
- 重新使能时，Bias 先于或按 Case 规定顺序建立。

安全钳位器件属于固定模板的一部分，其是否启用及尺寸属于参数集，不允许在结构变换时临时增加任意钳位结构。

---

## 7. 不同目标 VBIAS 的实现方式

### 7.1 不直接输入理想电压

用户不直接填写一个理想的 `VBIAS=某个电压` 并要求工具生成对应理想电源。

用户选择 Cascode 后，工具根据 Case 中已登记的目标器件、电压域和工作模式选择参数集。实际 VBIAS 是真实 Mirror 与 Replica 电路的输出结果。

### 7.2 通过参考电流调整

改变 `I_BIAS_N` 或 `I_BIAS_P` 会改变 Replica MOS 的电流密度和 VGS，从而调整 VBIAS。

初始关系为：

$$
I_{BIAS}
\approx
I_{REF}\times K_{mirror}
$$

其中：

$$
K_{mirror}
=
\frac{(W/L)_{OUT}}{(W/L)_{REF}}
$$

可以调整：

- 参考电流值；
- Mirror 输出管与参考管的尺寸比；
- nf、m 或 PDK 定义的并联倍数。

### 7.3 通过 Replica 尺寸调整

在相同 Bias 电流下，改变 Replica 的等效尺寸会改变电流密度，从而改变 VGS 和 VDSAT。

可以调整：

- 控制管 Replica 的 W/L 或等效鳍数；
- Cascode Replica 的 W/L 或等效鳍数；
- 两者之间的尺寸比例；
- 目标 Flavor；
- 合法沟道长度档位；
- nf、m 及 PDK 允许的离散参数。

所有参数都必须量化到 PDK 合法值，不能保留 PDK 无法表示的连续计算结果。

### 7.4 通过参考 Gate 调整

`VG_REP_N` 和 `VG_REP_P` 用于使 Replica 支路跟踪对应主支路的控制条件。

对于四种固定架构，参考 Gate 由 Case 预先登记，不由用户临时选择。它可以是：

- 与目标原 MOS 相同的稳定 Gate Bias；
- 同一匹配组的参考 Gate；
- 固定架构中专门提供的 Replica 控制节点；
- 经过批准的等效稳定参考节点。

动态误差放大器输出、快速变化节点或无法证明稳定性的信号，不能直接作为 Replica Gate 参考。

### 7.5 通过 PDK Flavor 调整

如果同一 PDK 中存在不同阈值、耐压或 IO/Core Flavor，可以为不同参数集选择不同的 Mirror 或 Replica Master，但必须满足：

- 目标极性不变；
- 电压域兼容；
- 可靠性满足；
- Case 明确允许；
- 已完成该组合的 PVT 和稳定性验证。

这仍然属于固定模板的参数映射，不表示用户可以在运行时任意选择 PDK 器件。

### 7.6 参数无法覆盖时的处理

如果通过参考电流、镜像比例、Replica 尺寸、参考 Gate 和批准的 Flavor，仍无法在全部 Corner 下满足目标 VBIAS，则：

- 不自动退化为电阻分压；
- 不自动增加二极管 MOS 级数；
- 不自动增加理想电压源；
- 不自动跨电压域取 Bias；
- 不生成该 Cascode 变体；
- 提示“当前 PDK/Case 无已批准 VBIAS 参数集”。

后续若要增加新的 Bias 拓扑，应作为新的模板版本单独评审，而不是把已有模板临时改形。

---

## 8. CAP LDO 参数方案

### 8.1 架构特点

CAP LDO 通常具有明确的输出电容和补偿条件。固定 VBIAS 模板仍会影响：

- 静态电流；
- Bias 噪声；
- PSRR；
- 上电建立时间；
- 新增内部节点极点；
- Cascode 带来的压差和输出摆幅。

CAP LDO 不需要改变 NMOS/PMOS Bias 模板拓扑，只需要绑定 CAP Case 参数集。

### 8.2 CAP 中的 NMOS Cascode Bias

使用 `VBIAS_N_CASCODE`，需要配置：

| 参数 | CAP Case 设计 |
|---|---|
| VHIGH/VLOW | 使用目标 NMOS 所属电压域的批准电源轨 |
| Mirror Master | 工具自动选择该电压域允许的真实 PMOS |
| Replica Master | 工具按目标原 NMOS 及新增 NMOS Cascode 自动绑定 |
| IREF 来源 | 复用 CAP 架构已登记参考电流或批准参考单元 |
| IBIAS_N | 按 VBIAS 窗口、IQ 和启动时间确定 |
| VG_REP_N | 使用 Case 登记的稳定参考 Gate |
| 模板实例 | 每个 Cascode 独立新增一路 |
| 验证重点 | PSRR、噪声、启动、压差、负载瞬态 |

### 8.3 CAP 中的 PMOS Cascode Bias

使用 `VBIAS_P_CASCODE`，需要配置：

| 参数 | CAP Case 设计 |
|---|---|
| VHIGH/VLOW | 使用目标 PMOS 所属电压域的批准电源轨 |
| Mirror Master | 工具自动选择该电压域允许的真实 NMOS |
| Replica Master | 工具按目标原 PMOS 及新增 PMOS Cascode 自动绑定 |
| IREF 来源 | 复用 CAP 架构已登记参考电流或批准参考单元 |
| IBIAS_P | 按 VBIAS 窗口、IQ 和启动时间确定 |
| VG_REP_P | 使用 Case 登记的稳定参考 Gate |
| 模板实例 | 每个 Cascode 独立新增一路 |
| 验证重点 | PSRR、噪声、启动、压差、输出摆幅 |

### 8.4 CAP 参数倾向

CAP Case 可以在满足启动时间和 PSRR 的前提下采用较低 Bias 电流，但不能仅因为存在输出电容就忽略 VBIAS 节点自身的高阻抗极点。

---

## 9. Capless LDO 参数方案

### 9.1 架构特点

Capless LDO 没有依赖大外部输出电容，其稳定性和负载瞬态通常更容易受到内部节点、寄生电容及新增极点影响。

因此，Capless 不改变模板拓扑，但参数约束比 CAP 更严格。

### 9.2 Capless 中的 NMOS Cascode Bias

使用 `VBIAS_N_CASCODE`，需要配置：

| 参数 | Capless Case 设计 |
|---|---|
| Mirror/Replica Master | 使用当前 PDK 电压域允许的器件 |
| IBIAS_N | 同时满足 VBIAS、建立时间和动态负载要求 |
| Mirror 尺寸 | 兼顾输出阻抗、寄生电容和匹配 |
| Replica 尺寸 | 使 VBIAS_N 在 PVT 下落入目标窗口 |
| 模板实例 | 每个 Cascode 独立新增一路，并限制单管 Gate 电容 |
| VG_REP_N | 只使用稳定 Bias 或专用 Replica 参考 |
| 验证重点 | 环路稳定性、无载/轻载、负载瞬态、Bias 极点、PSRR |

### 9.3 Capless 中的 PMOS Cascode Bias

使用 `VBIAS_P_CASCODE`，需要配置：

| 参数 | Capless Case 设计 |
|---|---|
| Mirror/Replica Master | 使用当前 PDK 电压域允许的器件 |
| IBIAS_P | 同时满足 VBIAS、建立时间和动态负载要求 |
| Mirror 尺寸 | 限制 VBIAS_P 节点寄生并保证吸流能力 |
| Replica 尺寸 | 使 VBIAS_P 在 PVT 下落入目标窗口 |
| 模板实例 | 每个 Cascode 独立新增一路，并限制单管 Gate 电容 |
| VG_REP_P | 只使用稳定 Bias 或专用 Replica 参考 |
| 验证重点 | 环路稳定性、轻载、负载瞬态、Bias 极点、PSRR |

### 9.4 Capless 参数倾向

Capless 参数集应优先保证：

- VBIAS 节点建立速度；
- 有限 Gate 电容下的动态响应；
- 新增 Mirror/Replica 寄生不进入关键环路带宽；
- 每个独立 Bias 模板都满足相位裕度和瞬态要求。

如果增加 Bias 后环路稳定性不满足要求，应调整 Bias 电流和器件尺寸，不能修改固定模板的电气连接来绕过问题。

---

## 10. FVF LDO 参数方案

### 10.1 架构特点

FVF LDO 包含快速局部反馈，通常对电压余量、内部高阻节点、寄生电容和 Bias 跟踪关系更敏感。

FVF 仍使用同一 NMOS/PMOS 低压 Replica 模板，但默认不使用简单 `1×VGS` 或 `2×VGS` 二极管阶梯。

### 10.2 FVF 中的 NMOS Cascode Bias

使用 `VBIAS_N_CASCODE`，需要配置：

| 参数 | FVF Case 设计 |
|---|---|
| Replica Master | 优先与目标 FVF 支路器件同 Flavor |
| VG_REP_N | 使用与目标支路工作条件相关的批准 Replica 参考 |
| IBIAS_N | 满足低压余量和局部环路动态要求 |
| Replica 比例 | 重点调整 `VGS+VDSAT`，避免浪费阈值电压余量 |
| 模板实例 | 每个 Cascode 独立新增一路，不跨快速环路共用 |
| 验证重点 | Dropout、局部环路稳定性、slew、恢复时间、PVT 跟踪 |

### 10.3 FVF 中的 PMOS Cascode Bias

使用 `VBIAS_P_CASCODE`，需要配置：

| 参数 | FVF Case 设计 |
|---|---|
| Replica Master | 优先与目标 FVF 支路器件同 Flavor |
| VG_REP_P | 使用与目标支路工作条件相关的批准 Replica 参考 |
| IBIAS_P | 满足低压余量和局部环路动态要求 |
| Replica 比例 | 重点调整 `|VSG|+|VDSAT|`，避免浪费高端余量 |
| 模板实例 | 每个 Cascode 独立新增一路，不跨不同动态条件共用 |
| 验证重点 | Dropout、局部环路稳定性、slew、恢复时间、PVT 跟踪 |

### 10.4 FVF 参数倾向

FVF 参数集优先保证低压余量和跟踪，不以最低 IQ 为唯一目标。

如果固定模板经过参数调整后仍无法同时满足 Dropout 和局部环路稳定性，应将该目标 MOS 的 Cascode 类型标记为不可用，而不是增加额外理想 Bias 或临时改变局部反馈结构。

---

## 11. RES LDO 参数方案

### 11.1 架构特点

RES LDO 中的电阻网络可能参与反馈、偏置、限流或静态工作点建立。新增 VBIAS 支路时，需要避免改变原电阻网络的负载和分压关系。

RES 不改变 NMOS/PMOS Bias 模板拓扑，只配置独立参数集。

### 11.2 RES 中的 NMOS Cascode Bias

使用 `VBIAS_N_CASCODE`，需要配置：

| 参数 | RES Case 设计 |
|---|---|
| IREF 来源 | 优先使用独立批准参考，不直接从敏感分压节点抽流 |
| VG_REP_N | 使用 Case 登记的稳定参考节点 |
| IBIAS_N | 在满足 VBIAS 的前提下控制新增 IQ |
| Mirror/Replica 尺寸 | 兼顾低电流匹配、泄漏和 PVT 漂移 |
| 模板实例 | 每个 Cascode 独立新增一路，校验单管 Gate 电容和建立时间 |
| 验证重点 | 电阻分压误差、IQ、噪声、温漂、启动、轻载工作点 |

### 11.3 RES 中的 PMOS Cascode Bias

使用 `VBIAS_P_CASCODE`，需要配置：

| 参数 | RES Case 设计 |
|---|---|
| IREF 来源 | 优先使用独立批准参考，不向敏感分压节点注入电流 |
| VG_REP_P | 使用 Case 登记的稳定参考节点 |
| IBIAS_P | 在满足 VBIAS 的前提下控制新增 IQ |
| Mirror/Replica 尺寸 | 兼顾低电流匹配、泄漏和 PVT 漂移 |
| 模板实例 | 每个 Cascode 独立新增一路，校验单管 Gate 电容和建立时间 |
| 验证重点 | 电阻网络加载、IQ、噪声、温漂、启动、轻载工作点 |

### 11.4 RES 参数倾向

RES 参数集可以优先控制 Bias 静态电流，但必须确认低电流下：

- Mirror 仍具有足够匹配精度；
- 漏电没有接近或超过 Bias 电流；
- VBIAS 建立时间满足要求；
- 电阻网络没有因为参考支路发生额外压降；
- 温度变化时 VBIAS 仍落在允许窗口。

---

## 12. 四种架构参数差异汇总

四种架构共用两套模板，区别只体现在参数集和验证上。

| 架构 | NMOS Cascode 模板 | PMOS Cascode 模板 | 主要参数倾向 | 主要验证重点 |
|---|---|---|---|---|
| CAP | `VBIAS_N_CASCODE` | `VBIAS_P_CASCODE` | 可在启动和 PSRR 满足时使用较低 Bias 电流 | PSRR、噪声、启动、压差、瞬态 |
| Capless | `VBIAS_N_CASCODE` | `VBIAS_P_CASCODE` | 每个 Cascode 独立模板，控制 Gate 电容和 Bias 极点 | 环路稳定性、轻载、负载瞬态、PSRR |
| FVF | `VBIAS_N_CASCODE` | `VBIAS_P_CASCODE` | 强调低压余量、Replica 跟踪和局部动态 | Dropout、局部环路、slew、PVT 跟踪 |
| RES | `VBIAS_N_CASCODE` | `VBIAS_P_CASCODE` | 控制 IQ，避免加载电阻网络 | 温漂、泄漏、噪声、启动、分压误差 |

如果某个固定架构只允许 NMOS Cascode 或只允许 PMOS Cascode，则只登记实际允许极性的参数集，不生成无用的另一套模板实例。

---

## 13. PDK 参数集设计

### 13.1 参数集标识

每个通过验证的参数集使用唯一标识，例如：

```text
<PDK>_<PDK版本>_<Case>_<电压域>_<N或P>_<Flavor>_<等级>
```

示例形式：

```text
PDK_A_R1_CAP_CORE_N_STANDARD
PDK_A_R1_CAP_CORE_P_STANDARD
PDK_A_R1_CAPLESS_CORE_N_FAST
PDK_A_R1_FVF_CORE_P_LOW_HEADROOM
PDK_A_R1_RES_CORE_N_LOW_IQ
```

名称只表示参数集用途，不能代替真实的 PDK 约束和验证记录。

### 13.2 NMOS Cascode 参数集字段

| 字段 | 含义 |
|---|---|
| `template_id` | 固定为 `VBIAS_N_CASCODE` |
| `pdk_id` | PDK 名称和版本 |
| `case_id` | CAP、Capless、FVF 或 RES 的具体 Case |
| `voltage_domain` | 电压域 |
| `vhigh_net` / `vlow_net` | 高、低电源轨 |
| `p_ref_master` / `p_out_master` | PMOS 镜像器件 |
| `n_ctrl_rep_master` | 原 NMOS Replica 器件 |
| `n_cas_rep_master` | 新增 NMOS Cascode Replica 器件 |
| `iref_source` | 参考吸流支路 |
| `iref_range` | 参考电流 PVT 范围 |
| `mirror_ratio` | PMOS 镜像比例 |
| `replica_parameters` | Replica 的合法 CDF 参数 |
| `vg_rep_net` | Replica Gate 参考网络 |
| `vbias_range` | 各 Corner 允许输出范围 |
| `max_gate_count` | 固定为 1，每个 Cascode 独立模板 |
| `max_gate_cap` | 单个 Cascode 的最大 Gate 电容 |
| `enable_net` | 使能网络 |
| `startup_policy` | 启动来源和时序 |
| `off_clamp_policy` | 关断安全电位 |
| `iq_budget` | 新增静态电流预算 |
| `reliability_limits` | 电压和结可靠性限制 |

### 13.3 PMOS Cascode 参数集字段

| 字段 | 含义 |
|---|---|
| `template_id` | 固定为 `VBIAS_P_CASCODE` |
| `pdk_id` | PDK 名称和版本 |
| `case_id` | CAP、Capless、FVF 或 RES 的具体 Case |
| `voltage_domain` | 电压域 |
| `vhigh_net` / `vlow_net` | 高、低电源轨 |
| `n_ref_master` / `n_out_master` | NMOS 镜像器件 |
| `p_ctrl_rep_master` | 原 PMOS Replica 器件 |
| `p_cas_rep_master` | 新增 PMOS Cascode Replica 器件 |
| `iref_source` | 参考供流支路 |
| `iref_range` | 参考电流 PVT 范围 |
| `mirror_ratio` | NMOS 镜像比例 |
| `replica_parameters` | Replica 的合法 CDF 参数 |
| `vg_rep_net` | Replica Gate 参考网络 |
| `vbias_range` | 各 Corner 允许输出范围 |
| `max_gate_count` | 固定为 1，每个 Cascode 独立模板 |
| `max_gate_cap` | 单个 Cascode 的最大 Gate 电容 |
| `enable_net` | 使能网络 |
| `startup_policy` | 启动来源和时序 |
| `off_clamp_policy` | 关断安全电位 |
| `iq_budget` | 新增静态电流预算 |
| `reliability_limits` | 电压和结可靠性限制 |

### 13.4 参数确定顺序

每个 Case 的参数按以下顺序确定：

```text
固定模板拓扑
    ↓
目标 MOS 极性及目标 Flavor
    ↓
目标电压域和电源轨
    ↓
参考电流来源
    ↓
主支路要求的 VBIAS Corner 窗口
    ↓
Mirror 比例与 Replica 尺寸求解
    ↓
量化到 PDK/CDF 合法参数
    ↓
PVT、启动、可靠性、IQ、噪声和稳定性验证
    ↓
登记为 Case 可使用参数集
```

---

## 14. 多个 Cascode 的 Bias 自动新增规则

### 14.1 独立模板原则

工具不扫描原电路中已有的 VBIAS，也不共用另一个 Cascode 的 VBIAS 输出。每个 Cascode 都实例化一个独立的 `VBIAS_N_CASCODE` 或 `VBIAS_P_CASCODE` 模板，独立管理 Mirror、Replica、输出网络和 IQ。

### 14.2 自动新增一路的定义

“有 Cascode 应用就自动添加一路”定义为：

1. 每个 Cascode 出现时，根据其极性、电压域和目标 Flavor 选择已批准参数集；
2. 工具从当前 PDK/Case 器件目录自动选择模板内部真实 MOS；
3. 新增一个完整 Bias 模板实例，不连接原电路已有 VBIAS；
4. 新增 Cascode Gate 只连接该模板的独立输出；
5. 该模板的参考支路、输出支路和 IQ 单独记录；
6. 无合法 PDK MOS、参数集、参考电流或电压余量时拒绝生成。

这里的“一路”是一个完整、可仿真、可计入 IQ 的 Bias 支路，不是只增加一根标有 VBIAS 的悬空网络。

### 14.3 参考电流接入

如果 Case 已有经过批准的参考电流核心：

- 可以把已批准的参考电流作为模板输入；
- 每个 Cascode 仍单独生成 Mirror 输出管和 Replica Bias 支路；
- 检查新增 Mirror Gate、电流和寄生是否超过参考核心负载预算。

如果 Case 没有参考核心：

- 使用 Case 绑定的批准参考电流单元；
- 参考单元和 startup 一起计入结构变体；
- 不允许只创建 Mirror 输出管而缺少参考支路。

---

## 15. 结构封装与接口

### 15.1 封装方式

每个生成的 VBIAS 支路封装成独立 CellView，避免 Mirror、Replica 和 startup 器件散落在 LDO 顶层。

NMOS Cascode Bias CellView 对外接口至少包括：

```text
VHIGH
VLOW
VG_REP_N
ENABLE
VBIAS_N
必要的参考电流接口
必要的 Bulk/Well 接口
```

PMOS Cascode Bias CellView 对外接口至少包括：

```text
VHIGH
VLOW
VG_REP_P
ENABLE
VBIAS_P
必要的参考电流接口
必要的 Bulk/Well 接口
```

### 15.2 顶层显示

顶层只显示：

- Cascode 结构块；
- 对应 VBIAS 模板块；
- VBIAS_N 或 VBIAS_P 网络；
- 电源、参考、使能及必要的 Bulk/Well 接口。

模板内部 MOS、Mirror 和 Replica 连接在子 CellView 中显示。

### 15.3 命名

推荐命名：

```text
原 MOS：M0
新增 Cascode：M0_CAS
中间节点：M0_MID
NMOS Bias 实例：VBN_<组号>
NMOS Bias 输出：VBIAS_N_<组号>
PMOS Bias 实例：VBP_<组号>
PMOS Bias 输出：VBIAS_P_<组号>
```

Bias 模板内部器件使用有角色含义的名称，例如：

```text
P_REF
P_OUT_N
N_CTRL_REP_N
N_CAS_REP_N
N_REF
N_OUT_P
P_CTRL_REP_P
P_CAS_REP_P
```

---

## 16. 电气验证要求

### 16.1 DC 工作点

需要验证：

- VBIAS 是否落在每个 Corner 的允许窗口；
- 原 MOS 是否保持目标工作区；
- 新增 Cascode 是否保持目标工作区；
- Replica 是否处于模板定义的工作状态；
- Mirror 是否具有足够 Compliance；
- 主支路和 Bias 支路电流是否符合预算；
- 中间节点 X 是否满足主支路电压余量。

### 16.2 PVT 与工作模式

至少覆盖 Case 规定的：

- Process Corner；
- 温度范围；
- 输入电压范围；
- 输出电压模式；
- 空载、轻载和重载；
- enable、disable、startup 和 mode 切换；
- 需要支持的 dropout 条件。

### 16.3 可靠性

需要逐器件检查：

- `|VGS|`；
- `|VDS|`；
- `|VGB|`；
- Drain/Bulk、Source/Bulk 结电压；
- Well 电位；
- startup 和瞬态过冲；
- 不同电源域上电顺序下的反向供电。

### 16.4 稳定性与瞬态

需要验证：

- LDO 主环路稳定性；
- FVF 或其他局部环路稳定性；
- Bias 输出阻抗形成的极点；
- 新增 Gate 电容及布线寄生；
- 负载瞬态；
- 输入瞬态；
- startup 建立时间；
- enable 切换时的 VBIAS 过冲和欠冲。

Capless 和 FVF 参数集不得只凭 DC 工作点通过就登记为可用。

### 16.5 噪声、PSRR 和 IQ

需要验证：

- PMOS Mirror 从 VHIGH 向 VBIAS_N 的电源噪声耦合；
- NMOS Mirror 从 VLOW 向 VBIAS_P 的地噪声耦合；
- Replica 器件的热噪声和闪烁噪声；
- VBIAS 噪声向主 Cascode 支路的传递；
- LDO PSRR；
- 新增参考、Mirror、Replica、startup 的总 IQ；
- 多个 Bias 组同时存在时的总功耗。

---

## 17. 不允许的处理方式

以下方式不属于当前确定方案：

1. 使用一个 NMOS Bias 模板同时驱动 PMOS Cascode；
2. 使用一个 PMOS Bias 模板同时驱动 NMOS Cascode；
3. 把原 MOS Gate 改接 VBIAS；
4. 把原 MOS Gate 与新增 Cascode Gate 短接；
5. 仅使用一个任意二极管连接 MOS 就认为 Cascode Bias 已满足；
6. 没有参考电流来源，只放置一对 Mirror MOS；
7. 没有 startup 证明，就认为自偏置支路一定能启动；
8. 在生产结构中增加理想电压源或理想电流源；
9. 参数无法覆盖时自动改用电阻分压；
10. 多个 Cascode 共用同一 VBIAS 输出；
11. 单个 Cascode 的 Gate 电容超过已批准模板负载后仍继续挂载；
12. 只验证 TT/常温/单负载点就登记参数集；
13. 未检查 PDK/CDF 合法范围就写入 MOS 参数；
14. 默认把非对称器件的 Drain 和 Source 交换；
15. 只看原理图连线，不进行回读网表和电气仿真验证。

---

## 18. 参数汇总

### 18.1 用户参数

用户只需要选择：

| 参数 | 说明 |
|---|---|
| 目标 MOS | 需要增加 Cascode 的器件 |
| Cascode 类型 | 同型或批准的同极性异型 Cascode |
| 目标 Flavor | 仅异型 Cascode 且 Case 允许时选择 |

用户不直接编辑：

- Bias 拓扑；
- VBIAS 理想电压；
- IREF 来源；
- Mirror 比例；
- Replica 尺寸；
- startup 电路；
- 电源域；
- Bulk/Well 网络。

### 18.2 Case/PDK 参数

架构维护者为 CAP、Capless、FVF、RES 分别维护：

| 参数类别 | 主要内容 |
|---|---|
| PDK 映射 | Mirror、Replica 的真实 Master、View、端子和 CDF |
| 电压域 | VHIGH、VLOW、Bulk、Well、可靠性限制 |
| 电流 | IREF 来源、IREF 范围、镜像比例、IBIAS |
| Replica | Master、W/L/nf/m、VG_REP |
| 输出 | VBIAS Corner 窗口、最大负载数、最大 Gate 电容 |
| 控制 | enable、startup、off clamp、上电顺序 |
| 预算 | IQ、面积、噪声、PSRR |
| 验证 | PVT、工作模式、稳定性、瞬态、可靠性结果 |

### 18.3 工具自动参数

工具自动确定：

- 使用 `VBIAS_N_CASCODE` 还是 `VBIAS_P_CASCODE`；
- 匹配的 Case/PDK 参数集；
- 模板内部对应当前 PDK 的真实 MOS Master；
- 为当前 Cascode 新增一个独立 Bias 实例；
- VBIAS 网络名称；
- Bias CellView 实例名称；
- 新增 IQ 汇总；
- 超载、无参数集和电压域不兼容等错误。

---

## 19. 当前方案的最终约定

1. CAP、Capless、FVF、RES 共用固定的 NMOS Cascode Bias 与 PMOS Cascode Bias 两套互补拓扑。
2. 四种架构只调整参考电流、镜像比例、Replica 尺寸、电源域、Bulk、使能、负载和验证参数；模板内部 PDK MOS 由工具自动选择，不重新设计 Bias 连接结构。
3. NMOS Cascode 使用 PMOS 电流镜供流的 `VBIAS_N_CASCODE` 模板。
4. PMOS Cascode 使用 NMOS 电流镜吸流的 `VBIAS_P_CASCODE` 模板。
5. 原 MOS Gate 始终保持原网络，只有新增 Cascode Gate 接 VBIAS。
6. 固定模板使用控制管 Replica 与 Cascode Replica 建立低压偏置关系，不把单只二极管 MOS 当作统一 Cascode Bias。
7. 每个 Case 必须明确 IREF 来源、startup、enable 和关断安全状态。
8. 不同目标电压通过参考电流、Mirror 比例、Replica 尺寸、参考 Gate 和批准的 Flavor 调整。
9. 用户不直接输入理想 VBIAS；实际 VBIAS 是真实 PDK 电路在对应工作条件下的输出。
10. 每个 Cascode 都新增一个独立 Bias 模板实例，不搜索、复用或共用原电路中的 VBIAS 网络。
11. 参数无法覆盖目标 VBIAS 时，禁止生成结构变体，不自动切换成电阻分压或理想电源。
12. 所有参数集必须完成 PVT、工作模式、启动、可靠性、稳定性、瞬态、噪声、PSRR 和 IQ 验证后才能发布。
13. 所有新增器件必须来自目标 PDK，且参数位于 PDK/CDF 合法范围内。
14. VBIAS 支路统一封装为独立 CellView，顶层不散放 Mirror 和 Replica 器件。
15. 如果后续需要第三种 Bias 拓扑，应新增模板版本并重新评审，不能修改已发布模板的电气语义。
16. 同型与异型都只在同极性内选管；NMOS、PMOS Cascode 均放在原 Drain 侧，原 G、S、Bulk 接线不变。
17. 本轮不实现对称管自动识别和对称联动修改。

---

## 20. 设计依据

本方案采用低压 Cascode Bias 的基本关系，即通过 Replica 和尺寸比例，使主控制管工作在接近要求的饱和边界，并使 Cascode Gate Bias 包含 `VGS` 与所需 `VDSAT` 余量。

相关基础原理可参考：

- [Texas A&M University：Lecture 6 — Current Mirrors](https://people.engr.tamu.edu/spalermo/ecen474/lecture06_ee474_current_mirrors.pdf)，其中包含 Cascode Current Mirror、Compliance Voltage 和 Low-Voltage Cascode Current Mirror；
- [MIT OpenCourseWare：The marvelous CASCODE](https://ocw.mit.edu/courses/6-012-microelectronic-devices-and-circuits-fall-2009/resources/mit6_012f09_lec21_cascode/)，用于 Cascode 工作关系和电压余量的基础说明。

具体器件尺寸、Bias 电流和电压窗口仍必须由目标 PDK 模型及四个真实 LDO Case 的仿真结果确定，不能由通用公式直接替代。
