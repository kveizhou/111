"""Native resistor expansions: public boundary and whole-device measurements."""
import copy
import csv
import json
import os
import shutil
import subprocess
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'server/site'))
import op_provider as op
import ExperimentalReuseTest as reuse_fixture


class CandidateResistorTest(unittest.TestCase):
    def test_packaged_target_uses_exact_parent_and_member_path(self):
        baseline='subckt core D G S B\nI21 (D G S B) n l=240n\nP0 (D G S B) n l=100n\nends core\nTOP (d g 0 0) core\n'
        candidate=baseline.replace('I21 (D G S B) n l=240n','I21 (D G S B) pkg')
        candidate+='subckt pkg D G S B\nI21 (mid G S B) n l=240n\nI21_CAS (D G mid B) n l=240n\nends pkg\n'
        focus,skipped,_=op.candidate_focus(candidate,'TOP','core',baseline,'core',['I21'])
        self.assertEqual(focus,{'I21.I21','I21.I21_CAS'})
        self.assertEqual(skipped,1)
        for broken in (candidate.replace('I21 (mid','Other (mid'),
                       candidate.replace('n l=240n','p l=240n'),
                       candidate.replace('P0 (D G S B) n l=100n\n','')):
            with self.subTest(broken=broken),self.assertRaises(ValueError):
                op.candidate_focus(broken,'TOP','core',baseline,'core',['I21'])
        # An unrelated subtree with the same leaf name cannot stand in for I21.
        with self.assertRaises(ValueError):
            op.candidate_focus(candidate.replace('I21 (D G S B) pkg','Other (D G S B) pkg'),
                               'TOP','core',baseline,'core',['I21'])

    def test_focus_omits_unchanged_peripheral_bindings_but_never_removes_their_circuit(self):
        baseline,native,logical,cats,bindings,parents=self.fixture(3)
        peripheral=''.join('P'+str(i)+' (D G S B) n l=100n\n' for i in range(100))
        baseline=baseline.replace('ends core',peripheral+'ends core')
        native=native.replace('ends core',peripheral+'ends core')
        original=native
        focus,skipped,_=op.candidate_focus(native,'TOP','core',baseline,'core',['M'])
        self.assertEqual(focus,{'M','RNEW','RNEW_2__res_gen','RNEW_3__res_gen'})
        self.assertEqual(skipped,102) # 100 MOS + two original resistor segments
        focused_bindings={k:v for k,v in bindings.items() if k in ('M','RNEW')}
        devices=op.bind_physical_devices(native,'TOP','core',cats,focused_bindings,
            logical_devices=parents,focus=focus)
        self.assertEqual({d['output_name'] for d,_,_ in devices},{'M','RNEW'})
        self.assertEqual(native,original)
        for missing in ('M','RNEW'):
            with self.subTest(missing=missing),self.assertRaisesRegex(ValueError,'binding missing'):
                op.bind_physical_devices(native,'TOP','core',cats,
                    {k:v for k,v in focused_bindings.items() if k!=missing},logical_devices=parents,focus=focus)
        changed=native.replace('P0 (D G S B) n l=100n','P0 (D G S B) n l=120n')
        selected,_,_=op.candidate_focus(changed,'TOP','core',baseline,'core',['M'])
        self.assertIn('P0',selected)
        with self.assertRaisesRegex(ValueError,'binding missing'):
            op.bind_physical_devices(changed,'TOP','core',cats,focused_bindings,logical_devices=parents,focus=selected)

    def test_focus_keeps_function_ports_and_rejects_removed_target(self):
        baseline,_,_=reuse_fixture.PreservedResistorsTest().fixture()
        baseline=baseline.replace('core D G S B','core VOUT VFB AGND AVDD')
        baseline=baseline.replace('(D G S B) n','(VOUT VFB AGND AVDD) n')
        focus,_,ports=op.candidate_focus(baseline,'TOP','core',baseline,'core',['M'])
        self.assertEqual(focus,{'M'})
        self.assertEqual(ports,{'VOUT':'d','VFB':'g','AGND':'0','AVDD':'0'})
        with self.assertRaisesRegex(ValueError,'target missing'):
            op.candidate_focus(baseline.replace('M (VOUT','removed (VOUT'),'TOP','core',baseline,'core',['M'])

    def test_shared_public_node_may_gain_replica_but_private_node_may_not(self):
        text, cats, bindings = reuse_fixture.PreservedResistorsTest().fixture()
        # Public G repeats across segments (parallel network); M already uses G.
        baseline = text.replace('(G mid)', '(G S)').replace('(mid S)', '(G S)')
        changed = baseline.replace('ends core', 'Cnew (G S) capacitor c=1p\nends core')
        reports = []
        devices = op.bind_physical_devices(changed, 'TOP', 'core', cats, bindings,
            baseline_text=baseline, baseline_master='core', preserved_report=reports)
        self.assertEqual([d['output_name'] for d,_,_ in devices], ['M'])
        self.assertEqual(len(reports), 1)
        with self.assertRaises(ValueError):
            op.bind_physical_devices(text.replace('ends core', 'Cnew (mid S) capacitor c=1p\nends core'),
                'TOP', 'core', cats, bindings, baseline_text=text, baseline_master='core')

    def fixture(self, count=25, parallel=False):
        text, cats, bindings = reuse_fixture.PreservedResistorsTest().fixture()
        catalog, dev = cats['r'][0]
        catalog['master']='oa_P__R'
        dev.update(signal_postfix='', dc_signals={'current':'1'}, electrical_rules={},
            normalized_to_cdf={'resistance':'r','segments':'segments'})
        root = 'TOP'
        segments=[]
        for index in range(count):
            name='RNEW' if index == 0 else 'RNEW_'+str(index+1)+'__res_gen'
            a = 'G' if parallel or index == 0 else 'new'+str(index)
            b = 'S' if parallel or index == count-1 else 'new'+str(index+1)
            segments.append(name+' ('+a+' '+b+') r r=2k')
        native=text.replace('ends core','\n'.join(segments)+'\nends core')
        logical=text.replace('ends core', 'RNEW (G S) oa_P__R r=50k segments='+str(count)+'\nends core')
        proof=copy.deepcopy(bindings['R0']);bindings=dict(bindings,RNEW=proof)
        parents={d['path'][len(root)+1:]:d for d in op.flatten_dut(logical,root,'core')}
        return text,native,logical,cats,bindings,parents

    def bind(self, fixture):
        baseline,native,logical,cats,bindings,parents=fixture
        return op.bind_physical_devices(native,'TOP','core',cats,bindings,
            baseline_text=baseline,baseline_master='core',logical_devices=parents)

    def geometry_fixture(self,count=200,parallel=False):
        baseline,native,logical,cats,bindings,_=self.fixture(count,parallel)
        cats['rhrpo_2t_ckt']=copy.deepcopy(cats['r'])
        row,dev=cats['rhrpo_2t_ckt'][0]
        row['model_name']='rhrpo_2t_ckt';dev['model']='rhrpo_2t_ckt'
        bindings['RNEW']['model_name']='rhrpo_2t_ckt'
        native='\n'.join(line.replace(') r r=2k',') rhrpo_2t_ckt lr=2.4u wr=800n mr=1')
                         if line.startswith('RNEW') else line for line in native.splitlines())
        logical=logical.replace('r=50k segments='+str(count),
            'r='+str(48259.84*count/25)+' segments='+str(count)+
            ' cktL='+str(count*2.4e-6)+' cktW=800n segL=2.4u segW=800n m=1')
        parents={d['path'][4:]:d for d in op.flatten_dut(logical,'TOP','core')}
        return baseline,native,logical,cats,bindings,parents

    def test_cpp_emitted_long_parameters_reach_native_geometry_check(self):
        compiler = shutil.which('c++')
        self.assertIsNotNone(compiler, 'C++ compiler required for the real emitter/reader contract test')
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            source=folder/'emit.cpp';exe=folder/'emit'
            source.write_text('''#include "st/Netlist.h"
#include <iostream>
#include <iterator>
int main() {
    std::string text(std::istreambuf_iterator<char>(std::cin), {});
    std::vector<st::Diagnostic> diagnostics;
    const auto deck = st::parseSpectre(text, diagnostics);
    if (!diagnostics.empty()) return 1;
    std::cout << st::emitSpectre(deck);
}
''')
            subprocess.run([compiler,'-std=c++17','-I'+str(ROOT/'include'),
                            str(source),str(ROOT/'src/Netlist.cpp'),'-o',str(exe)],
                           check=True,capture_output=True,text=True)
            for count in (200,100,400):
                with self.subTest(count=count):
                    baseline,native,logical,cats,bindings,_=self.geometry_fixture(count)
                    logical=logical.replace(' m=1',' m=1 leff=2.4u nfin=16 mismod_usrIpt=1 rctmod_usrIpt=1 rsh=624.3351')
                    emitted=subprocess.run([str(exe)],input=logical,check=True,
                                           capture_output=True,text=True).stdout
                    self.assertIn('\n+ ',emitted)
                    parents={d['path'][4:]:d for d in op.flatten_dut(emitted,'TOP','core')}
                    self.assertEqual(parents['RNEW']['params'],
                        next(d['params'] for d in op.flatten_dut(logical,'TOP','core') if d['name']=='RNEW'))
                    devices=self.bind((baseline,native,emitted,cats,bindings,parents))
                    resistor=next(d for d,c,_ in devices if c['kind']=='resistor')
                    self.assertEqual(resistor['verified_series_geometry']['segments'],count)
                    with self.assertRaisesRegex(ValueError,'native geometry differs'):
                        self.bind((baseline,native.replace('lr=2.4u','lr=10u',1),emitted,cats,bindings,parents))

    def test_mixed_continuations_preserve_comments_and_all_parameters(self):
        deck='R (a b) r r=1k \\\n// native export comment\n m=1\n\n// C++ readback comment\n + segL=2.4u \\\n segW=800n\n+ segments=200\n'
        parsed=op.parse_deck(deck)
        self.assertEqual(parsed['top'][0]['params'],
            dict(r='1k',m='1',segL='2.4u',segW='800n',segments='200'))
        self.assertIn('// native export comment',parsed['lines'])
        with self.assertRaisesRegex(ValueError,'preceding statement'):op.lines('+ r=1k')
        with self.assertRaisesRegex(ValueError,'unterminated'):op.lines('R (a b) r \\')

    def test_series_trials_verify_actual_native_lengths_widths_and_counts(self):
        for count in (200,100,400):
            with self.subTest(count=count):
                devices=self.bind(self.geometry_fixture(count))
                resistor=next(d for d,c,_ in devices if c['kind']=='resistor')
                geometry=resistor['verified_series_geometry']
                self.assertEqual(geometry['segments'],count)
                for key,value in dict(lr=2.4e-6,wr=800e-9,mr=1.).items():
                    self.assertAlmostEqual(geometry[key],value,places=16)
        fixture=list(self.geometry_fixture())
        for field,bad in (('lr=2.4u','lr=10u'),('wr=800n','wr=1u'),('mr=1','mr=2')):
            broken=list(fixture);broken[1]=fixture[1].replace(field,bad,1)
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'native geometry differs'):
                self.bind(broken)
        with self.assertRaisesRegex(ValueError,'series chain'):
            self.bind(self.geometry_fixture(parallel=True))

    def test_r_label_updated_but_single_default_native_resistor_rejected_before_simulation(self):
        baseline,native,logical,cats,bindings,_=self.geometry_fixture(400)
        # Reproduce the server result: r=772k in readback, native only 10u/1u.
        native='\n'.join(line for line in native.splitlines() if not line.startswith('RNEW_'))
        native=native.replace('RNEW (G new1) rhrpo_2t_ckt lr=2.4u wr=800n mr=1',
                              'RNEW (G S) rhrpo_2t_ckt lr=10u wr=1u mr=1')
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            for name in ('expected/core_expected.scs','roundtrip/complete.scs'):
                path=folder/name;path.parent.mkdir();path.write_text(logical)
            (folder/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            focus,_,_=op.candidate_focus(native,'TOP','core',baseline,'core',['M'])
            with patch.object(op,'command',side_effect=AssertionError('no simulator call')), \
                 self.assertRaisesRegex(ValueError,'native segment count differs'):
                op.bind_candidate_devices(native,'TOP','core',cats,bindings,baseline,'core',folder,[],{},focus=focus)

    def test_25_series_and_parallel_segments_bind_one_actual_parent_and_query_all(self):
        for parallel in (False,True):
            with self.subTest(parallel=parallel):
                devices=self.bind(self.fixture(parallel=parallel))
                resistor=next(d for d,c,_ in devices if c['kind']=='resistor')
                self.assertEqual(resistor['output_name'],'RNEW')
                self.assertEqual(resistor['nodes'],['g','0'])
                self.assertEqual(resistor['params']['r'],'50k')
                self.assertEqual(len(resistor['segments']),25)
                physical=[row for row in devices if row[1]['kind']=='resistor']
                query=op.build_dc_query(physical,[])
                self.assertEqual(len(query['currents']),25)
                self.assertIn('TOP.RNEW_25__res_gen:1',query['currents'])
                raw={n:0. for n in query['nodes']};raw['g']=1.
                for i in range(1,25):
                    if not parallel:raw['TOP.new'+str(i)]=1.-i/25.
                raw.update({signal:1e-6 for signal in query['currents']})
                result=op.resistor_measurement(resistor,raw,physical[0][1],physical[0][2])
                self.assertAlmostEqual(result['current'],25e-6 if parallel else 1e-6)
                self.assertAlmostEqual(result['power'],result['current'])
                self.assertEqual(len(result['segments']),25)
                reverse={k:-v for k,v in raw.items()}
                reverse_result=op.resistor_measurement(resistor,reverse,physical[0][1],physical[0][2])
                self.assertAlmostEqual(reverse_result['current'],-result['current'])
                self.assertAlmostEqual(reverse_result['power'],result['power'])
                raw['TOP.RNEW_25__res_gen:1']=-1e-6
                with self.assertRaises(ValueError):op.resistor_measurement(resistor,raw,physical[0][1],physical[0][2])

    def test_new_expansion_requires_readback_and_consistent_two_terminal_network(self):
        baseline,native,logical,cats,bindings,parents=self.fixture(3)
        with self.assertRaises(ValueError):
            op.bind_physical_devices(native,'TOP','core',cats,bindings,baseline_text=baseline,baseline_master='core')
        variants=[native.replace('RNEW_3__res_gen','RNEW_4__res_gen'),
            native.replace('(new2 S) r','(new2 D) r'),
            native.replace('(new2 S) r','(new2 S) n'),
            native.replace('ends core','C (new1 S) capacitor c=1p\nends core'),
            native.replace('RNEW_3__res_gen (new2 S) r r=2k','RNEW_3__res_gen (x y) r r=2k')]
        for changed in variants:
            with self.subTest(changed=changed),self.assertRaises(ValueError):
                op.bind_physical_devices(changed,'TOP','core',cats,bindings,
                    baseline_text=baseline,baseline_master='core',logical_devices=parents)

    def test_verified_readback_maps_hierarchy_ports_and_refuses_changed_expected(self):
        _,native,logical,_,_,_=self.fixture(3)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);(folder/'roundtrip').mkdir();(folder/'expected').mkdir()
            # Real readback contains subckt definitions only.
            logical=logical[:logical.rfind('TOP (')]
            for name in ('roundtrip/complete.scs','expected/core_expected.scs'):(folder/name).write_text(logical)
            (folder/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            parents,evidence=op.load_resistor_readback(folder,native,'TOP','core','core')
            self.assertEqual(parents['RNEW']['nodes'],['g','0'])
            self.assertEqual(len(evidence),3)
            (folder/'roundtrip/complete.scs').write_text(logical.replace('r=50k','r=60k'))
            with self.assertRaisesRegex(ValueError,'readback'):op.load_resistor_readback(folder,native,'TOP','core','core')

    def test_195_segment_engineering_readback_reaches_real_aggregation(self):
        baseline,native,logical,cats,bindings,_=self.geometry_fixture(195)
        requested=format(48259.84*195/25,'.17g')
        logical=logical.replace('r='+str(48259.84*195/25),'r='+requested)
        logical=logical[:logical.rfind('TOP (')]
        actual=logical.replace('r='+requested,'r=376.426752K')
        self.assertNotEqual(op.parameter_value(requested,{}),op.parameter_value('376.426752K',{}))
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            for name,text in [('expected/core_expected.scs',logical),('roundtrip/complete.scs',actual)]:
                path=folder/name;path.parent.mkdir();path.write_text(text)
            (folder/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            parents,_=op.load_resistor_readback(folder,native,'TOP','core','core')
            devices=op.bind_physical_devices(native,'TOP','core',cats,bindings,
                baseline_text=baseline,baseline_master='core',logical_devices=parents)
            resistor=next(d for d,c,_ in devices if c['kind']=='resistor')
            self.assertEqual(resistor['verified_series_geometry']['segments'],195)
            for changed in ('r=376.426753K','r=376K',''):
                (folder/'roundtrip/complete.scs').write_text(actual.replace('r=376.426752K',changed))
                with self.subTest(changed=changed),self.assertRaisesRegex(ValueError,'r expected=.*actual='):
                    op.load_resistor_readback(folder,native,'TOP','core','core')

    def test_final_variant_uses_its_own_checked_readback_not_search_candidate(self):
        baseline,native,logical,cats,bindings,_=self.geometry_fixture(262)
        logical=logical[:logical.rfind('TOP (')]
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)/'work/analysis/variant_op'
            for name in ('expected/core_expected.scs','roundtrip/complete.scs'):
                path=folder/name;path.parent.mkdir(parents=True);path.write_text(logical)
            report=folder/'validation.txt'
            report.write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            evidence={}
            devices=op.bind_candidate_devices(native,'TOP','core',cats,bindings,
                baseline,'core',folder,[],evidence)
            resistor=next(d for d,c,_ in devices if c['kind']=='resistor')
            self.assertEqual(resistor['verified_series_geometry']['segments'],262)
            self.assertTrue(all(str(folder) in path for path in evidence))
            report.write_text('ok=false\n')
            with self.assertRaisesRegex(ValueError,'roundtrip validation'):
                op.bind_candidate_devices(native,'TOP','core',cats,bindings,
                    baseline,'core',folder,[],{})

    def test_physical_parameter_comparison_preserves_small_geometry_changes(self):
        for n in range(1,801):
            requested=48259.84*n/25
            self.assertTrue(op.same_parameter_value(requested,op.parameter_value(format(requested/1000,'.15g')+'K',{})))
        self.assertTrue(op.same_parameter_value(2.400000000000003e-7,240e-9))
        self.assertFalse(op.same_parameter_value(240e-9,241e-9))
        self.assertFalse(op.same_parameter_value(0,1e-30))
        self.assertFalse(op.same_parameter_value(float('nan'),float('nan')))
        self.assertFalse(op.same_parameter_value(('r',{'r':2}),('r',{'r':3})))

    def test_nested_bias_parent_and_bus_port_spelling_use_native_paths(self):
        baseline,native,logical,cats,bindings,_=self.fixture(3)
        native_body='\n'.join(line for line in native.splitlines() if line.startswith('RNEW'))
        logical_body='\n'.join(line for line in logical.splitlines() if line.startswith('RNEW'))
        native=native.replace(native_body,'I_VBIAS (G S) bias_native')
        native='subckt bias_native G S\n'+native_body+'\nends bias_native\n'+native
        logical=logical.replace(logical_body,'I_VBIAS (G S) oa_P__bias')
        logical='subckt oa_P__bias G S\n'+logical_body+'\nends oa_P__bias\n'+logical
        bindings['I_VBIAS.RNEW']=bindings.pop('RNEW')
        native=native.replace('core D G S B','core D G S B BUS\\<1\\> BUS\\<0\\>').replace('TOP (d g 0 0)','TOP (d g 0 0 b1 b0)')
        logical=logical.replace('core D G S B','core B S G D BUS<1:0>')
        logical=logical[:logical.rfind('TOP (')]
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            for name in ('expected/core_expected.scs','roundtrip/complete.scs'):
                p=folder/name;p.parent.mkdir();p.write_text(logical)
            (folder/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            parents,_=op.load_resistor_readback(folder,native,'TOP','core','core')
            self.assertEqual(parents['I_VBIAS.RNEW']['nodes'],['g','0'])
            bound=op.bind_physical_devices(native,'TOP','core',cats,bindings,baseline_text=baseline,
                baseline_master='core',logical_devices=parents)
            resistor=next(d for d,c,_ in bound if c['kind']=='resistor')
            self.assertEqual(resistor['output_name'],'I_VBIAS.RNEW')
            self.assertEqual(resistor['segments'][1]['path'],'TOP.I_VBIAS.RNEW_2__res_gen')

    def test_whole_provider_candidate_path_queries_and_writes_parent_with_25_segments(self):
        self.run_provider_candidate(packaged=False)

    def test_whole_provider_packaged_target_cascode_and_bias_paths(self):
        self.run_provider_candidate(packaged=True)

    def run_provider_candidate(self, packaged):
        # Native subprocesses alone are substituted. Bundle, readback, binder,
        # query, measurement, output tables and their identities are production.
        from standalone import environment
        from site_data import pin_site_inputs
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve()
            candidate,inputs,bundle=reuse_fixture.ReuseIntegrationTest().fixture(root,segmented=True,peripheral_mos=100)
            profile=json.loads(Path(inputs['rules']).read_text())
            context=dict(source_dut=bundle['source'],source_benches=[bundle['bench']],source_cds_path=str(root))
            Path(inputs['context']).write_text(json.dumps(context))
            tech=json.loads(Path(inputs['tech']).read_text())
            tech[0]['devices'][1]['normalized_to_cdf']={'resistance':'r','segments':'segments'}
            tech[0]['devices'][0]['dc_signals'].update(vdsat='vdssat',intrinsic_vgs='vgs',intrinsic_vds='vds')
            Path(inputs['tech']).write_text(json.dumps(tech))
            inputs.update(adapter=str(ROOT/'server/skill/pdk_adapter.il'),runtime=str(ROOT/'server/site/cascode_runtime.py'))
            manifest=candidate/'provider.json';manifest.write_text(json.dumps(pin_site_inputs(inputs)))
            env=environment(inputs,manifest)
            # Isolate just the DUT definition from the accepted full Bench.
            original=Path(bundle['bench_netlist']).read_text();deck=op.parse_deck(original)
            core=deck['definitions']['core']
            body='\n'.join(deck['lines'][core['start']:core['end']+1])+'\n'
            # The native array path and the OA ranged path must converge through
            # binding, query, reader consumption and final MOS extraction.
            array_instances='\n'.join(r'I93\<'+str(i)+r'\> (D G S B) nested' for i in range(6))
            body=body.replace('ends core',array_instances+'\nends core')
            body+='subckt nested D G S B\nI2 (D G S B) leaf\nends nested\n'
            body+='subckt leaf D G S B\nM0 (D G S B) nmod l=20n nfin=2\nends leaf\n'
            if packaged:
                target=core['instances'][0]
                self.assertEqual(target['name'],'M0')
                # Same hierarchy contract as PackageSingleCandidateVariant:
                # parent M0 becomes a wrapper; original M0 remains inside it.
                target_line=next(line for line in body.splitlines() if line.startswith('M0 '))
                body=body.replace(target_line,'M0 (D G S B) cascode_pkg',1)
                body+='subckt cascode_pkg D G S B\nM0 (mid G S B) nmod l=20n nfin=2\nM0_CAS (D G mid B) nmod l=20n nfin=2\nends cascode_pkg\n'
            rows=[]
            for i in range(25):
                name='NEW' if i==0 else 'NEW_'+str(i+1)+'__res_gen'
                rows.append(name+' ('+('G' if i==0 else 'new'+str(i))+' '+
                    ('S' if i==24 else 'new'+str(i+1))+') rmod r=2k')
            dut=body.replace('ends core','\n'.join(rows)+'\nends core').replace('subckt core ','subckt changed ').replace('ends core','ends changed')
            logical=body.replace('ends core','NEW (G S) P/R r=50k segments=25\nends core')
            if packaged:
                bias='subckt bias_pkg G S\nN_REP (G G S S) nmod l=20n nfin=2\n'
                dut=body.replace('ends core','I_VBIAS_N_M0 (G S) bias_pkg\nends core').replace('subckt core ','subckt changed ').replace('ends core','ends changed')
                dut+=bias+'\n'.join(rows)+'\nends bias_pkg\n'
                logical=body.replace('ends core','I_VBIAS_N_M0 (G S) bias_pkg\nends core')
                logical+=bias+'NEW (G S) P/R r=50k segments=25\nends bias_pkg\n'
            evaluation=candidate/'work/analysis/candidates/candidate_004';evaluation.mkdir(parents=True)
            for folder in ('expected','roundtrip'):(evaluation/folder).mkdir()
            (evaluation/'expected/core_expected.scs').write_text(logical)
            (evaluation/'roundtrip/complete.scs').write_text(logical)
            (evaluation/'validation.txt').write_text('ok=true\nexpected_topology_hash=abc\nactual_topology_hash=abc\n')
            source=candidate/'work/analysis/baseline_op/raw_op/st-op-simulation.test'
            bindings=(source/'oa_bindings.tsv').read_text()+'NEW\tP\tR\tsymbol\tPLUS,MINUS\ttarget\trmod\n'
            bindings+='I93<5:0>.I2.M0\tP\tN\tsymbol\tD,G,S,B\ttarget\tnmod\n'
            if packaged:
                bindings=bindings.replace('M0\tP\tN','M0.M0\tP\tN',1).replace('\nNEW\t','\nI_VBIAS_N_M0.NEW\t')
                bindings+='M0.M0_CAS\tP\tN\tsymbol\tD,G,S,B\ttarget\tnmod\n'
                bindings+='I_VBIAS_N_M0.N_REP\tP\tN\tsymbol\tD,G,S,B\ttarget\tnmod\n'
            args=SimpleNamespace(simulation_dir=str(evaluation/'raw_op/st-op-simulation.new'),pdk_version='p',
                dut_lib='DERIVED',dut_cell='changed',dut_view='schematic',
                bench_lib=bundle['bench']['lib'],bench_cell=bundle['bench']['cell'],bench_view=bundle['bench']['view'],
                cds_lib=str(root/'cds.lib'),corner=bundle['corner'],
                device_catalog=str(candidate/'work/analysis/pdk_scan/run_0001/raw_catalog.tsv'),
                identity_output=str(evaluation/'identity.tsv'),mos_output=str(evaluation/'mos.tsv'),
                resistor_output=str(evaluation/'resistor.tsv'),dut_hash='d',bench_hash='b',topology_hash='t',
                parameter_hash='p',solver_version='s')
            calls=[]
            def native(exe,argv,directory,label):
                calls.append(label);options=dict(zip(argv[1::2],argv[2::2]))
                if label=='export_dut':
                    p=Path(options['--output']);p.write_text(dut)
                    Path(str(p)+'.origin.json').write_text(json.dumps(dict(working_directory=str(p.parent))))
                elif label=='physical_oa_bindings':
                    expected_roots=({'M0','I93','I_VBIAS_N_M0'} if packaged else
                                    {'M0','I93','NEW'}|{'NEW_'+str(i)+'__res_gen' for i in range(2,26)})
                    self.assertEqual(set(os.environ['ST_BINDING_ROOTS'].splitlines()),expected_roots)
                    Path(options['--output']).write_text(bindings)
                elif label=='simulate':
                    query=json.loads((directory/'psf_query.json').read_text())
                    self.assertEqual(len(query['currents']),25)
                    self.assertFalse(any('PERIPH' in n for n in query['device_parameters']))
                    self.assertEqual(sum('PERIPH' in d['path'] for d in op.flatten_dut(
                        (directory/'simulation.scs').read_text(),'TOP.DUT','changed')),100)
                    self.assertIn('TOP.DUT.I93<5>.I2.M0',query['device_parameters'])
                    if packaged:
                        for path in ('M0.M0','M0.M0_CAS','I_VBIAS_N_M0.N_REP'):
                            self.assertIn('TOP.DUT.'+path,query['device_parameters'])
                        self.assertNotIn('TOP.DUT.M0',query['device_parameters'])
                elif label=='read_psf':
                    from dc_results import consume_query,query_script
                    query=json.loads(Path(options['--request']).read_text())
                    script=query_script(directory/'psf',query,Path('/init'),directory)
                    self.assertIn('TOP.DUT.I93<5>.I2.M0',script)
                    raw={n:0. for n in query['nodes']};raw.update(VIN=1.14,G=.5)
                    prefix='TOP.DUT.'+('I_VBIAS_N_M0.' if packaged else '')
                    for i in range(1,25):raw[prefix+'new'+str(i)]=.5*(25-i)/25.
                    ops=[]
                    for signal,parameters in query['device_parameters'].items():
                        signal=signal.replace('<',r'\<').replace('>',r'\>')
                        ops.append(dict(kind='device',signal=signal,parameter='',value='bsimcmg',status='META'))
                        for p in parameters:
                            value=dict(id=1e-6,vth=.3,vdssat=.2,cgg=2e-15,vgs=.5,vds=1.14)[p]
                            ops.append(dict(kind='op',signal=signal,parameter=p,value=str(value),status='OK'))
                    raw.update({s:1e-6 for s in query['currents']})
                    nodes=[dict(kind='current' if n in query['currents'] else 'node',signal=n,value=str(v),status='OK')
                           for n,v in raw.items() if n!='0']
                    raw,sources=consume_query(query,nodes,ops)
                    op.write_tsv(options['--output'],['signal','value'],list(raw.items()))
                    Path(options['--output']+'.sources.json').write_text(json.dumps(dict(sources=sources)))
                else:self.fail('unexpected native stage '+label)
            with patch.dict(os.environ,env,clear=True),patch.object(op,'command',native):op.run(args)
            self.assertEqual(calls,['export_dut','physical_oa_bindings','simulate','read_psf'])
            with Path(args.resistor_output).open() as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
            self.assertEqual(len(rows),1);self.assertEqual(rows[0]['instance'],'I_VBIAS_N_M0.NEW' if packaged else 'NEW')
            self.assertAlmostEqual(float(rows[0]['current']),1e-6)
            self.assertEqual(json.loads(rows[0]['geometry']),dict(r=50000.,segments=25.))
            self.assertEqual(rows[0]['max_voltage'],'NA')
            with Path(args.mos_output).open() as stream:mos=list(csv.DictReader(stream,delimiter='\t'))
            if packaged:
                self.assertEqual({r['instance'] for r in mos if 'I93' not in r['instance']},
                                 {'M0.M0','M0.M0_CAS','I_VBIAS_N_M0.N_REP'})
            array=next(row for row in mos if row['instance']==r'I93\<5\>.I2.M0')
            self.assertEqual(float(array['id']),1e-6)
            self.assertEqual(float(array['intrinsic_vgs']),.5)
            report=json.loads((Path(args.simulation_dir)/'extraction.json').read_text())
            self.assertEqual(report['resistor_count'],1)
            self.assertGreaterEqual(report['unchanged_peripheral_devices_skipped'],100)
            self.assertEqual(len(report['resistor_measurements'][0]['segments']),25)
            self.assertFalse(report['reliability_verified'])


if __name__=='__main__':unittest.main()
