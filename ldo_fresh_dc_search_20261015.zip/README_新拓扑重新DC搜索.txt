新Drain侧拓扑重新自动DC搜索（源码883c4de）

本包累计包含：NMOS/PMOS同型异型都接原D侧、PMOS VBIAS模板、最终DC前实际OA回读、新增--fresh-search。
在st-engine-maau父目录执行这一整行：
unzip -o ldo_fresh_dc_search_20261015.zip && bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs --fresh-search

--reuse-verified-inputs复用未改原电路基线和器件资料；--fresh-search禁止旧选中阻值作优先初值，候选由当前代码生成并重新真实DC。
预期标记：
AUTO_VBIAS_SEARCH=true
AUTO_VBIAS_MAX_DC_EVALUATIONS=16
FRESH_VBIAS_SEARCH=true
PREVIOUS_SELECTION_SEED_REUSED=false
PREVIOUS_DC_VERDICT_REUSED=false

成功时：VBIAS_SELECTION ... result=solved ... evaluations=本轮实际点数
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
退出码0。

不要求跑满16点，首个满足最低DC条件便停止，随后最终OA回读和DC复验。
16点都不满足时，有有效收敛候选则自动交付OPTIMIZATION_CANDIDATE_READY；这不代表DC合格。
软件执行/读取失败仍报告INCOMPLETE，不能当作通过。旧0.915812V不作为新版结果。
本次27项Python入口测试通过；前序C++及最终回读修复测试结果见源码docs/03-变更记录.md。
真实服务器新拓扑结果待本轮运行。
