// =============================================================
// DcSolver.cpp — PDK 离散参数 DC 闭环求解器
// 固定流程见 Task 6 brief：初值量化 → 粗搜索（每参数 {min,中点,初值,max}）→
// 局部精搜索（相邻量化值）→ 硬约束过滤 → 首个可行解 → 固定参数 PVT。
// 本文件不出现任何固定 PDK Cell 名；所有取值经 QuantizeParameter。
// =============================================================
#include "st/DcSolver.h"

#include "st/PdkCatalog.h"
#include "st/Transform.h"
#include "st/VariantVerifier.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <functional>
#include <utility>
#include <tuple>

namespace st {
namespace {

constexpr double kContinuityTolerance = 1e-3;
constexpr std::size_t kMaxCoarseEvaluations = 256;
constexpr std::size_t kMaxRefineEvaluations = 128;
constexpr std::size_t kMaxTotalEvaluations = 384;
constexpr std::size_t kMaxExperimentalEvaluations = 16;

// 固定检查顺序；轨迹 reason 取第一个失败项。
const std::vector<std::string> kConstraintOrder = {
    "converged", "complete", "params_legal",
    "reliability_vgs", "reliability_vds", "reliability_vgb",
    "saturation", "vbias_range", "bias_conduction", "branch_direction",
    "branch_continuity", "current_limits_valid", "branch_current_limit", "bias_current_limit",
    "resistor_stress",
};

struct RoleLayout {
    std::string mirror_ref;
    std::string mirror_out;
    std::string resistor;
    std::string cas_rep;
    std::string ctrl_rep;
};

RoleLayout layoutFor(DeviceKind polarity)
{
    if (polarity == DeviceKind::MosN) {
        return {"P_REF", "P_OUT_N", "R_REF_N", "N_CAS_REP_N", "N_CTRL_REP_N"};
    }
    return {"N_REF", "N_OUT_P", "R_REF_P", "P_CAS_REP_P", "P_CTRL_REP_P"};
}

std::string formatNumber(double value)
{
    if (!std::isfinite(value)) return "null";
    char buffer[64];
    std::snprintf(buffer, sizeof buffer, "%.6g", value);
    return buffer;
}

std::string jsonEscape(const std::string& text)
{
    std::string escaped;
    for (const char ch : text) {
        switch (ch) {
        case '"': escaped += "\\\""; break;
        case '\\': escaped += "\\\\"; break;
        default:
            if (static_cast<unsigned char>(ch) < 0x20) {
                escaped += '?';
            } else {
                escaped += ch;
            }
        }
    }
    return escaped;
}

bool quantize(double value, const ParameterConstraint& constraint,
              double& quantized)
{
    try {
        quantized = QuantizeParameter(value, constraint);
        return true;
    } catch (const std::exception&) {
        return false;
    }
}

double geometricMidpoint(const ParameterConstraint& constraint)
{
    if (constraint.minimum > 0.0 && std::isfinite(constraint.maximum)) {
        return std::sqrt(constraint.minimum * constraint.maximum);
    }
    return (constraint.minimum + constraint.maximum) / 2.0;
}

struct SearchParam {
    int slot = 0; // 0=新增 Cascode，1=Mirror（两管共享），2=参考电阻
    std::string semantic;
    const DeviceDescriptor* device = nullptr;
    ParameterConstraint constraint;
};

const ParameterConstraint* findConstraint(const DeviceDescriptor& descriptor,
                                          const std::string& semantic)
{
    for (const auto& [key, constraint] : descriptor.parameter_constraints) {
        const std::string& declared = constraint.semantic_name.empty()
            ? key : constraint.semantic_name;
        if (declared == semantic) return &constraint;
    }
    return nullptr;
}

void appendSearchParams(int slot, const DeviceDescriptor& descriptor,
                        std::vector<SearchParam>& params, bool experimental)
{
    static const std::vector<std::string> mosOrder = {
        "width", "length", "fins", "fin", "fingers", "finger",
        "multiplier"};
    static const std::vector<std::string> resistorOrder = {"resistance"};
    const auto& order = descriptor.kind == DeviceKind::Resistor
        ? resistorOrder : mosOrder;
    std::set<std::string> usedCdf;
    for (const auto& wanted : order) {
        for (const auto& [key, constraint] : descriptor.parameter_constraints) {
            const std::string semantic = constraint.semantic_name.empty()
                ? key : constraint.semantic_name;
            if (semantic != wanted || constraint.cdf_name.empty() ||
                usedCdf.count(constraint.cdf_name) != 0) {
                continue;
            }
            params.push_back({slot, semantic, &descriptor, constraint});
            usedCdf.insert(constraint.cdf_name);
        }
    }
    // Native trial metadata also carries fixed numeric CDF seeds outside the search semantics.
    if (experimental) {
        for (const auto& [key, constraint] : descriptor.parameter_constraints) {
            const auto resistance = descriptor.parameter_constraints.find("resistance");
            if (descriptor.kind == DeviceKind::Resistor && descriptor.native_parameter_trials &&
                resistance != descriptor.parameter_constraints.end() &&
                resistance->second.discrete_values.size() > 1 && key != "multiplier") continue;
            if (!usedCdf.insert(constraint.cdf_name).second) continue;
            params.push_back({slot, constraint.semantic_name.empty() ? key : constraint.semantic_name,
                              &descriptor, constraint});
        }
    }
}

double parameterValue(const std::map<std::string, std::string>& values,
                      const DeviceDescriptor& descriptor,
                      const std::string& semantic, double fallback)
{
    const ParameterConstraint* constraint = findConstraint(descriptor, semantic);
    if (constraint == nullptr) return fallback;
    const auto found = values.find(constraint->cdf_name);
    if (found == values.end()) return fallback;
    bool ok = false;
    const double value = parseSuffixValue(found->second, ok);
    return ok ? value : fallback;
}

double estimateMosArea(const std::map<std::string, std::string>& values,
                       const DeviceDescriptor& descriptor)
{
    const double multiplier = parameterValue(
        values, descriptor, "multiplier", 1.0);
    const double width = parameterValue(values, descriptor, "width", 0.0);
    const double length = parameterValue(values, descriptor, "length", 0.0);
    if (width > 0.0 && length > 0.0) {
        const double fingers = parameterValue(
            values, descriptor, "fingers",
            parameterValue(values, descriptor, "finger", 1.0));
        return width * length * std::max(1.0, fingers) *
               std::max(1.0, multiplier);
    }
    const double fins = parameterValue(
        values, descriptor, "fins",
        parameterValue(values, descriptor, "fin", 0.0));
    if (fins > 0.0 && length > 0.0) {
        return fins * length * std::max(1.0, multiplier);
    }
    return 0.0;
}

// 候选点签名：量化值精确拼接，用于评估缓存（重复组合不重复调用宿主）。
std::string pointSignature(const std::vector<double>& point)
{
    std::string signature;
    char buffer[32];
    for (const double value : point) {
        std::snprintf(buffer, sizeof buffer, "%.17g", value);
        signature += buffer;
        signature += ',';
    }
    return signature;
}

struct EvaluationRecord {
    std::vector<double> point;
    BiasSizing sizing;
    std::map<std::string, bool> constraints;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    DcCandidateMetrics metrics;
    double vbias_voltage = 0.0;
    bool converged = false;
    bool kept = false;
    bool host_called = false;
    bool evaluation_failed = false;
    std::string reason = "ok";
    std::string host_message;
    std::string construction_stage;
    std::string construction_message;
    std::string corner; // 空=名义Corner；PVT复验记录填各自Corner
    std::string cascode_instance;
    ElectricalConstraintRequest electrical_check;
    std::size_t combination_id = 0;
    std::size_t coarse_budget = 0;
    std::size_t refine_budget = 0;
    bool parameter_search_truncated = false;
    std::string phase;
};

// 轨迹 reason 与约束键的固定映射（键保持布尔语义，reason 给可读名）。
std::string reasonName(const std::string& constraint)
{
    if (constraint == "converged") return "not_converged";
    if (constraint == "complete") return "incomplete_snapshot";
    if (constraint == "current_limits_valid") return "current_limits_invalid";
    return constraint;
}

bool endsWithRole(const std::string& candidate, const std::string& leaf)
{
    if (candidate.size() <= leaf.size() ||
        candidate.compare(candidate.size() - leaf.size(), leaf.size(), leaf) != 0) {
        return false;
    }
    const char delimiter = candidate[candidate.size() - leaf.size() - 1];
    return delimiter == '.' || delimiter == '/' || delimiter == ':';
}

const MosOperatingPoint* resolveRole(const OperatingPointSnapshot& snapshot,
                                     const ElectricalMosRole& role)
{
    if (role.leaf_name.empty()) return nullptr;
    const auto exact = snapshot.mos.find(role.leaf_name);
    if (exact != snapshot.mos.end()) return &exact->second;
    if (!role.container_instance.empty()) {
        for (const char delimiter : {'.', '/', ':'}) {
            const auto scoped = snapshot.mos.find(
                role.container_instance + delimiter + role.leaf_name);
            if (scoped != snapshot.mos.end()) return &scoped->second;
        }
    }
    const MosOperatingPoint* unique = nullptr;
    for (const auto& [name, op] : snapshot.mos) {
        if (!endsWithRole(name, role.leaf_name)) continue;
        if (!role.container_instance.empty() &&
            name.find(role.container_instance) == std::string::npos) {
            continue;
        }
        if (unique != nullptr) return nullptr;
        unique = &op;
    }
    return unique;
}

std::string traceLine(std::size_t candidateId, const std::string& corner,
                      const EvaluationRecord& record, const RoleLayout& layout,
                      bool selected)
{
    std::ostringstream line;
    line << "{\"candidate\":" << candidateId
         << ",\"experimental_dc\":" << (record.electrical_check.experimental_dc ? "true" : "false")
         << ",\"native_parameter_trials\":" << (record.electrical_check.native_parameter_trials ? "true" : "false")
         << ",\"combination\":" << record.combination_id
         << ",\"masters\":{\"mirror\":\"" << jsonEscape(record.sizing.mirror_master)
         << "\",\"resistor\":\"" << jsonEscape(record.sizing.resistor_master)
         << "\"},\"search\":{\"nominal_budget\":" << (record.electrical_check.experimental_dc ? kMaxExperimentalEvaluations : kMaxTotalEvaluations)
         << ",\"coarse_budget\":" << record.coarse_budget
         << ",\"refine_budget\":" << record.refine_budget
         << ",\"parameter_search_truncated\":"
         << (record.parameter_search_truncated ? "true" : "false")
         << ",\"phase\":\"" << record.phase << "\"},\"converged\":"
         << (record.evaluation_failed ? "null" : record.converged ? "true" : "false")
         << ",\"host_called\":" << (record.host_called ? "true" : "false")
         << ",\"dc_evaluated\":" << (record.evaluation_failed ? "null" : record.host_called ? "true" : "false")
         << ",\"construction_stage\":\"" << jsonEscape(record.construction_stage)
         << "\",\"construction_message\":\"" << jsonEscape(record.construction_message)
         << "\",\"constraints\":{";
    bool first = true;
    for (const auto& name : kConstraintOrder) {
        const auto found = record.constraints.find(name);
        if (!first) line << ',';
        first = false;
        const bool unverifiedTrialDomain = name == "params_legal" &&
            record.electrical_check.native_parameter_trials && found != record.constraints.end() && found->second;
        line << '\"' << name << "\":" <<
            (found == record.constraints.end() || unverifiedTrialDomain ? "null" : found->second ? "true" : "false");
    }
    if (record.electrical_check.native_parameter_trials) {
        const auto parameters = record.constraints.find("params_legal");
        line << ",\"trial_parameters_valid\":" <<
            (parameters != record.constraints.end() && parameters->second ? "true" : "false");
    }
    line << "},\"reliability_verified\":" << (record.reliability_verified ? "true" : "false")
         << ",\"unverified_constraints\":[";
    for (std::size_t index = 0; index < record.unverified_constraints.size(); ++index) {
        if (index != 0) line << ',';
        line << '"' << jsonEscape(record.unverified_constraints[index]) << '"';
    }
    line << "],\"stress_measurements\":{";
    first = true;
    for (const auto& [name, value] : record.stress_measurements) {
        if (!first) line << ',';
        first = false;
        line << '"' << jsonEscape(name) << "\":" << formatNumber(value);
    }
    line << "},\"corner\":\"" << jsonEscape(corner) << "\",\"kept\":"
         << (record.kept ? "true" : "false") << ",\"metrics\":";
    if (record.evaluation_failed) {
        line << "null";
    } else {
        line << '{'
         << "\"area_estimate\":" << formatNumber(record.metrics.area_estimate)
         << ",\"branch_current_error\":"
         << formatNumber(record.metrics.branch_current_error)
         << ",\"control_op_error\":"
         << formatNumber(record.metrics.control_op_error)
         << ",\"iq_delta\":" << formatNumber(record.metrics.iq_delta)
         << ",\"reliability_margin\":"
         << formatNumber(record.metrics.reliability_margin)
         << ",\"saturation_margin\":"
         << formatNumber(record.metrics.saturation_margin)
         << ",\"saturation_deficit\":"
         << formatNumber(record.metrics.saturation_deficit)
         << '}';
    }
    line << ",\"params\":{";
    const auto& elements = record.sizing.element_parameters;
    const auto ctrl = elements.find(layout.ctrl_rep);
    const auto mirror = elements.find(layout.mirror_ref);
    const auto resistor = elements.find(layout.resistor);
    const std::pair<const char*, const std::map<std::string, std::string>*>
        groups[] = {
            {"cascode", &record.sizing.cascode_parameters},
            {"control_replica",
             ctrl == elements.end() ? nullptr : &ctrl->second},
            {"mirror", mirror == elements.end() ? nullptr : &mirror->second},
            {"resistor",
             resistor == elements.end() ? nullptr : &resistor->second},
        };
    first = true;
    for (const auto& [group, params] : groups) {
        if (!first) line << ',';
        first = false;
        line << '\"' << group << "\":{";
        bool firstParam = true;
        if (params != nullptr) {
            for (const auto& [cdf, value] : *params) {
                if (!firstParam) line << ',';
                firstParam = false;
                line << '\"' << jsonEscape(cdf) << "\":\"" << jsonEscape(value)
                     << '\"';
            }
        }
        line << '}';
    }
    line << "},\"reason\":\"" << record.reason << "\",\"host_message\":\""
         << jsonEscape(record.host_message) << "\",\"selected\":"
         << (selected ? "true" : "false") << '}';
    return line.str();
}

} // namespace

ElectricalConstraintResult EvaluateElectricalConstraints(
    const OperatingPointSnapshot& snapshot,
    const ElectricalConstraintRequest& request,
    bool converged)
{
    ElectricalConstraintResult result;
    result.unverified_constraints = request.unverified_constraints;
    for (const auto& name : kConstraintOrder) result.constraints[name] = true;
    result.constraints["converged"] = converged;
    const bool limitsConfigured = request.max_branch_current_error.has_value() &&
        request.max_vbias_current.has_value() &&
        std::isfinite(*request.max_branch_current_error) &&
        std::isfinite(*request.max_vbias_current) &&
        *request.max_branch_current_error > 0.0 &&
        *request.max_vbias_current > 0.0;
    const bool anyCurrentLimit = request.max_branch_current_error.has_value() ||
        request.max_vbias_current.has_value();
    // 无性能 Spec 时仍执行 DC 硬门禁；显式提供的限值须成对且合法。
    result.constraints["current_limits_valid"] = !anyCurrentLimit || limitsConfigured;
    ResistorStressResult resistorStress;
    if (!request.resistor.leaf_name.empty()) {
        auto resistor = request.resistor;
        resistor.experimental_dc = request.experimental_dc;
        resistorStress = EvaluateResistorStress(snapshot, resistor);
        result.constraints["resistor_stress"] = converged && resistorStress.ok;
        if (resistorStress.measurements_available) {
            result.stress_measurements["resistor.voltage"] = resistorStress.voltage;
            result.stress_measurements["resistor.current"] = resistorStress.current;
            result.stress_measurements["resistor.power"] = resistorStress.power;
        }
        result.unverified_constraints.insert(result.unverified_constraints.end(),
            resistorStress.unverified_constraints.begin(), resistorStress.unverified_constraints.end());
        if (request.experimental_dc && converged && resistorStress.ok &&
            !resistorStress.unverified_constraints.empty()) result.constraints.erase("resistor_stress");
    }

    const MosOperatingPoint* mirrorRef = nullptr;
    const MosOperatingPoint* mirrorOut = nullptr;
    const MosOperatingPoint* casRep = nullptr;
    const MosOperatingPoint* ctrlRep = nullptr;
    const MosOperatingPoint* actualControl = nullptr;
    const MosOperatingPoint* actualCascode = nullptr;
    if (converged) {
        mirrorRef = resolveRole(snapshot, request.mirror_ref);
        mirrorOut = resolveRole(snapshot, request.mirror_out);
        casRep = resolveRole(snapshot, request.cascode_replica);
        ctrlRep = resolveRole(snapshot, request.control_replica);
        actualControl = resolveRole(snapshot, request.actual_control);
        actualCascode = resolveRole(snapshot, request.actual_cascode);
    }
    result.constraints["complete"] = converged && mirrorRef != nullptr &&
        mirrorOut != nullptr && casRep != nullptr && ctrlRep != nullptr &&
        actualControl != nullptr && actualCascode != nullptr;
    if (request.experimental_dc && !request.resistor.leaf_name.empty()) {
        result.constraints["complete"] = result.constraints["complete"] &&
            resistorStress.measurements_available &&
            resistorStress.failed_constraint != "resistor_rating_invalid" &&
            resistorStress.failed_constraint != "resistor_rating_missing";
    }

    if (result.constraints["complete"]) {
        for (const auto* point : {mirrorRef, mirrorOut, casRep, ctrlRep, actualControl,
                                  actualCascode, &request.baseline_control}) {
            result.constraints["complete"] = result.constraints["complete"] &&
                HasValidIntrinsicVoltages(*point) && std::isfinite(point->vg - point->vb);
            for (const double value : {point->vd, point->vg, point->vs, point->vb,
                    point->id, point->vgs, point->vds, point->vbs, point->vth,
                    point->vdsat, point->cgg}) {
                result.constraints["complete"] = result.constraints["complete"] && std::isfinite(value);
            }
        }
    }
    if (result.constraints["complete"]) {
        const std::pair<const MosOperatingPoint*, const ElectricalMosRole*>
            roles[] = {
                {mirrorRef, &request.mirror_ref},
                {mirrorOut, &request.mirror_out},
                {casRep, &request.cascode_replica},
                {ctrlRep, &request.control_replica},
                {actualControl, &request.actual_control},
                {actualCascode, &request.actual_cascode},
            };
        double reliabilityMargin = std::numeric_limits<double>::infinity();
        double saturationMargin = std::numeric_limits<double>::infinity();
        std::set<std::string> unknownReliability;
        const bool controlWasSaturated =
            std::fabs(request.baseline_control.intrinsic_vds.value_or(request.baseline_control.vds)) >=
            std::fabs(request.baseline_control.vdsat);
        for (const auto& [op, role] : roles) {
            const double voltages[] = {op->vgs, op->vds, op->vg - op->vb};
            const double limits[] = {role->limits.max_abs_vgs, role->limits.max_abs_vds,
                                     role->limits.max_abs_vgb};
            const char* names[] = {"reliability_vgs", "reliability_vds", "reliability_vgb"};
            const char* quantities[] = {"vgs", "vds", "vgb"};
            if (!role->reliability_complete) {
                result.unverified_constraints.push_back(role->leaf_name + ".reliability_metadata");
                if (!request.experimental_dc) result.constraints["reliability_vgs"] = false;
            }
            for (std::size_t index = 0; index < 3; ++index) {
                result.stress_measurements[role->leaf_name + "." + quantities[index]] = voltages[index];
                if (!std::isfinite(limits[index])) {
                    result.unverified_constraints.push_back(role->leaf_name + "." + names[index]);
                    unknownReliability.insert(names[index]);
                    if (!request.experimental_dc || std::isnan(limits[index]) || limits[index] < 0.0)
                        result.constraints[names[index]] = false;
                    continue;
                }
                const double margin = limits[index] - std::fabs(voltages[index]);
                result.constraints[names[index]] = result.constraints[names[index]] &&
                    limits[index] > 0.0 && margin >= 0.0;
                reliabilityMargin = std::min(reliabilityMargin, margin);
            }
            const double saturation = std::fabs(op->intrinsic_vds.value_or(op->vds)) - std::fabs(op->vdsat);
            result.stress_measurements[role->leaf_name + ".intrinsic_vds"] = op->intrinsic_vds.value_or(op->vds);
            result.stress_measurements[role->leaf_name + ".vdsat"] = op->vdsat;
            result.stress_measurements[role->leaf_name + ".saturation_margin"] = saturation;
            // 镜像和 Cascode 角色必须饱和；原控制管及其 Replica 仅在
            // 基线原管已饱和时要求保持饱和，避免拒绝有意在线性区的原管。
            const bool requireSaturation = controlWasSaturated ||
                (role != &request.control_replica &&
                 role != &request.actual_control);
            if (requireSaturation) {
                result.constraints["saturation"] =
                    result.constraints["saturation"] && saturation >= 0.0;
                saturationMargin = std::min(saturationMargin, saturation);
                result.metrics.saturation_deficit = std::max(
                    result.metrics.saturation_deficit,
                    std::max(0.0, -saturation) / std::max(std::fabs(op->vdsat), 1e-6));
            }
        }

        const double vbias = casRep->vd;
        const double vbiasLow = request.polarity == DeviceKind::MosN
            ? ctrlRep->vs : mirrorOut->vs;
        const double vbiasHigh = request.polarity == DeviceKind::MosN
            ? mirrorOut->vs : casRep->vs;
        result.vbias_voltage = vbias;
        result.stress_measurements["vbias"] = vbias;
        result.constraints["vbias_range"] =
            vbiasLow <= vbias && vbias <= vbiasHigh;

        const auto sameNonzeroDirection = [](double current, double reference) {
            return std::isfinite(current) && std::isfinite(reference) &&
                current != 0.0 && reference != 0.0 &&
                std::signbit(current) == std::signbit(reference);
        };
        result.constraints["bias_conduction"] =
            sameNonzeroDirection(mirrorOut->id, mirrorRef->id);
        // 不添加任意最小电流或过驱动门槛，保留原管的弱反型/线性区用途。
        // 基线已导通的支路必须继续导通且方向一致；有意关断的原管不强制开启。
        result.constraints["branch_direction"] =
            request.baseline_control.id == 0.0 ||
            (sameNonzeroDirection(ctrlRep->id, request.baseline_control.id) &&
             sameNonzeroDirection(casRep->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualControl->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualCascode->id, request.baseline_control.id));

        const double replicaContinuityError =
            std::fabs(std::fabs(ctrlRep->id) - std::fabs(casRep->id)) /
            std::max(std::fabs(ctrlRep->id), 1e-30);
        const double actualContinuityError =
            std::fabs(std::fabs(actualControl->id) -
                      std::fabs(actualCascode->id)) /
            std::max(std::fabs(actualControl->id), 1e-30);
        result.constraints["branch_continuity"] =
            replicaContinuityError <= kContinuityTolerance &&
            actualContinuityError <= kContinuityTolerance;

        const double originalCurrent = std::fabs(request.baseline_control.id);
        result.metrics.branch_current_error =
            std::max(std::fabs(std::fabs(ctrlRep->id) - originalCurrent),
                     std::fabs(std::fabs(actualControl->id) - originalCurrent)) /
            std::max(originalCurrent, 1e-30);
        result.metrics.control_op_error =
            std::fabs(actualControl->vgs - request.baseline_control.vgs) +
            std::fabs(actualControl->vds - request.baseline_control.vds);
        result.metrics.iq_delta =
            std::fabs(mirrorRef->id) + std::fabs(mirrorOut->id);
        result.constraints["branch_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.branch_current_error <=
                *request.max_branch_current_error);
        result.constraints["bias_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.iq_delta <= *request.max_vbias_current);
        if (request.experimental_dc) {
            for (const auto& name : unknownReliability) {
                if (result.constraints[name]) result.constraints.erase(name);
            }
        }
        result.metrics.reliability_margin = std::isfinite(reliabilityMargin)
            ? reliabilityMargin : std::numeric_limits<double>::quiet_NaN();
        result.metrics.saturation_margin = saturationMargin;
    } else {
        for (const auto& name : kConstraintOrder) {
            if (name != "converged" && name != "complete" &&
                name != "params_legal") {
                result.constraints[name] = false;
            }
        }
    }

    for (const auto& name : kConstraintOrder) {
        const auto constraint = result.constraints.find(name);
        if (constraint != result.constraints.end() && !constraint->second) {
            result.first_failed_constraint = name == "resistor_stress" &&
                !resistorStress.failed_constraint.empty()
                ? resistorStress.failed_constraint : reasonName(name);
            return result;
        }
    }
    result.ok = true;
    result.reliability_verified = !request.experimental_dc && result.unverified_constraints.empty();
    return result;
}

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest& request,
                                  const DeviceCatalog& catalog,
                                  DcEvaluationHost& host)
{
    AutoBiasSolveResult result;
    const DeviceKind polarity = request.template_request.polarity;
    const bool experimental = request.template_request.experimental_dc;
    const std::size_t maxCoarse = experimental ? kMaxExperimentalEvaluations : kMaxCoarseEvaluations;
    const std::size_t maxRefine = experimental ? 0 : kMaxRefineEvaluations;
    const std::size_t maxTotal = experimental ? kMaxExperimentalEvaluations : kMaxTotalEvaluations;
    const RoleLayout layout = layoutFor(polarity);

    // ---- 快速失败：选型、基线完整性、可求解约束 ----
    std::vector<AutoBiasDevicePlan> plans;
    Diagnostic diagnostic;
    if (!SelectAutoBiasDeviceCandidates(request.template_request, catalog, plans,
                                        diagnostic)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    const Subckt* root = request.baseline.find(request.root_subckt);
    const Instance* target =
        root != nullptr ? root->find(request.target_instance) : nullptr;
    if (target == nullptr) {
        result.diagnostics.push_back(
            {DiagCode::NotFound,
             "基线网表中找不到目标实例：" + request.root_subckt + "/" +
                 request.target_instance});
        return result;
    }
    const MosOperatingPoint* baselineTarget =
        FindMosOp(request.baseline_op, request.target_instance);
    if (baselineTarget == nullptr) {
        result.diagnostics.push_back(
            {DiagCode::MissingInput,
             "基线 DC 快照缺少目标实例的工作点：" + request.target_instance});
        return result;
    }

    result.device_combinations = plans.size();
    if (plans.size() > maxCoarse) {
        result.diagnostics.push_back({DiagCode::BadParam,
            "search_budget_exhausted: " + std::to_string(plans.size()) +
            "个Mirror×Resistor组合超过名义粗搜索预算256，无法保证每组至少一次评估"});
        return result;
    }
    if (target->model != request.template_request.control_master) {
        result.diagnostics.push_back({DiagCode::BadParam,
            "基线目标master与Control Replica master不一致"});
        return result;
    }
    std::map<std::string, std::string> controlReplicaParams;
    if (!QuantizeAutoBiasParameters(*plans.front().control, target->params,
                                    layout.ctrl_rep, controlReplicaParams,
                                    diagnostic, true, experimental)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    std::vector<EvaluationRecord> records;
    std::optional<std::size_t> best;

    // 候选网表 = 基线 + 真实 Cascode 改写 + 核心层 VBIAS 层级实例。
    // 这里与最终 ChangeSet 重放共用 applyCascode，避免候选仿真只测
    // 脱离主电路的模板。名义候选与 PVT 复验共用同一组装。
    auto assembleCandidate = [&](const BiasSizing& sizing, Netlist& candidate,
                                 std::string& cascodeInstance, EvaluationRecord& record) {
        const auto constructionFailed = [&](const std::string& stage,
                                            const std::vector<Diagnostic>& diagnostics) {
            record.construction_stage = stage;
            for (const auto& item : diagnostics) {
                if (!record.construction_message.empty()) record.construction_message += " | ";
                record.construction_message += item.message;
            }
            if (record.construction_message.empty())
                record.construction_message = "构建未返回候选或具体诊断";
            return false;
        };
        const AutoBiasTemplateResult built = BuildAutoBiasTemplate(
            request.template_request, sizing, catalog);
        if (!built.ok) return constructionFailed("template_build", built.diagnostics);

        candidate = request.baseline;
        AutoBiasSolveResult resolved;
        resolved.ok = true;
        resolved.sizing = sizing;

        CascodeTransformRequest transform;
        transform.subckt = request.root_subckt;
        transform.target = request.target_instance;
        transform.new_master = request.template_request.cascode_master;
        transform.gate_policy = GatePolicy::FixedBias;
        transform.experimental_dc = experimental;
        transform.solved_bias = std::move(resolved);
        transform.bias_template = built;
        transform.vbias_vhigh_net = request.template_request.vhigh_net;
        transform.vbias_vlow_net = request.template_request.vlow_net;
        transform.voltage_domain = request.template_request.voltage_domain;
        transform.nmos_bulk_net = request.nmos_bulk_net;
        transform.tie_isolated_pmos_to_source =
            request.tie_isolated_pmos_to_source;
        const TransformOutcome outcome = applyCascode(candidate, transform, catalog);
        if (!outcome.ok() || outcome.addedInstances.empty())
            return constructionFailed("cascode_transform", outcome.diags);
        cascodeInstance = outcome.addedInstances.front();
        return true;
    };

    bool evaluationAborted = false;
    auto evaluationFailed = [&](EvaluationRecord& record, const Diagnostic& diagnostic) {
        if (record.converged || diagnostic.message.empty()) return false;
        record.evaluation_failed = true;
        record.host_message = diagnostic.message;
        record.reason = "evaluation_failed";
        record.kept = false;
        const bool paramsLegal = record.constraints.at("params_legal");
        record.constraints.clear();
        record.constraints["params_legal"] = paramsLegal;
        for (const auto& name : kConstraintOrder)
            if (name != "params_legal") record.unverified_constraints.push_back(name);
        evaluationAborted = true;
        return true;
    };

    // 名义候选和固定参数 PVT 使用同一硬约束；指标仅供诊断。
    auto assess = [&](EvaluationRecord& stored,
                      const OperatingPointSnapshot& snapshot) {
        auto check = stored.electrical_check;
        check.actual_cascode.leaf_name = stored.cascode_instance;
        const auto assessed = EvaluateElectricalConstraints(
            snapshot, check, stored.converged);
        if (experimental && stored.converged && (!assessed.constraints.at("complete") ||
            !assessed.stress_measurements.count("resistor.current") ||
            !assessed.stress_measurements.count("resistor.voltage"))) {
            stored.converged = false;
            evaluationFailed(stored, {DiagCode::MissingInput,
                "DC结果缺少完整目标器件/电阻测量或含无效数值；停止剩余试点"});
            return;
        }
        const bool paramsLegal = stored.constraints["params_legal"];
        stored.constraints = assessed.constraints;
        stored.constraints["params_legal"] = paramsLegal;
        stored.reliability_verified = assessed.reliability_verified;
        stored.unverified_constraints = assessed.unverified_constraints;
        stored.stress_measurements = assessed.stress_measurements;
        stored.vbias_voltage = assessed.vbias_voltage;
        stored.metrics = assessed.metrics;

        if (assessed.ok) {
            double area = 0.0;
            const std::pair<const std::map<std::string, std::string>*,
                            const DeviceDescriptor*>
                areaTerms[] = {
                    {&stored.sizing.cascode_parameters, plans.front().cascode},
                    {&stored.sizing.cascode_parameters, plans.front().cascode},
                    {&stored.sizing.element_parameters[layout.mirror_ref],
                     catalog.Find(stored.sizing.mirror_master)},
                    {&stored.sizing.element_parameters[layout.mirror_out],
                     catalog.Find(stored.sizing.mirror_master)},
                    {&stored.sizing.element_parameters[layout.ctrl_rep],
                     plans.front().control},
                };
            for (const auto& [elementParams, descriptor] : areaTerms) {
                area += estimateMosArea(*elementParams, *descriptor);
            }
            stored.metrics.area_estimate = area;
        }

        stored.kept = true;
        for (const auto& name : kConstraintOrder) {
            const auto constraint = stored.constraints.find(name);
            if (constraint != stored.constraints.end() && !constraint->second) {
                stored.kept = false;
                stored.reason = name == "resistor_stress" &&
                    !assessed.first_failed_constraint.empty()
                    ? assessed.first_failed_constraint : reasonName(name);
                break;
            }
        }
    };

    // 对每一对真实master独立搜索参数，分摊预算保证后续组合有评估机会。
    for (std::size_t combinationIndex = 0; combinationIndex < plans.size();
         ++combinationIndex) {
        const auto& plan = plans[combinationIndex];
        std::vector<SearchParam> params;
        appendSearchParams(0, *plan.cascode, params, experimental);
        appendSearchParams(1, *plan.mirror, params, experimental);
        appendSearchParams(2, *plan.resistor, params, experimental);
        for (const auto& param : params) {
            std::string reason;
            if (!ValidateParameterConstraint(param.constraint, &reason)) {
                result.diagnostics.push_back(
                    {DiagCode::BadParam,
                     "master " + param.device->master + " 的参数约束 " +
                         param.semantic + " 无效：" + reason});
                return result;
            }
        }

        // ---- 初值：Cascode 按语义继承原管；其余取 PDK 参数域几何中点 ----
        std::vector<double> initial(params.size(), 0.0);
        for (std::size_t index = 0; index < params.size(); ++index) {
            double seed = experimental && !params[index].constraint.discrete_values.empty()
                ? params[index].constraint.discrete_values.front() : geometricMidpoint(params[index].constraint);
            if (params[index].slot == 0) {
                // 原管实例参数（按原管 CDF 名读取）映射到新增管约束
                const ParameterConstraint* controlConstraint =
                    findConstraint(*plan.control, params[index].semantic);
                if (controlConstraint != nullptr) {
                    const auto text =
                        target->params.find(controlConstraint->cdf_name);
                    if (text != target->params.end()) {
                        bool parsed = false;
                        const double original = parseSuffixValue(text->second, parsed);
                        if (parsed) seed = original;
                    }
                }
            }
            if (!quantize(seed, params[index].constraint, initial[index])) {
                result.diagnostics.push_back(
                    {DiagCode::BadParam,
                     "初值无法量化到 PDK 合法取值：" + params[index].semantic});
                return result;
            }
        }

        // ---- 每个参数的粗搜索值集合：{min, 几何中点, 映射初值, max} 量化去重 ----
        std::vector<std::vector<double>> coarseValues(params.size());
        for (std::size_t index = 0; index < params.size(); ++index) {
            const ParameterConstraint& constraint = params[index].constraint;
            std::vector<double> seeds = experimental && !constraint.discrete_values.empty()
                ? constraint.discrete_values
                : std::vector<double>{constraint.minimum, geometricMidpoint(constraint), initial[index], constraint.maximum};
            for (const double seed : seeds) {
                double value = 0.0;
                if (!quantize(seed, constraint, value)) {
                    result.diagnostics.push_back(
                        {DiagCode::BadParam,
                         "粗搜索取值无法量化：" + params[index].semantic});
                    return result;
                }
                auto& values = coarseValues[index];
                if (std::find(values.begin(), values.end(), value) == values.end()) {
                    values.push_back(value);
                }
            }
        }

        std::map<std::string, std::size_t> cache;
        std::optional<std::size_t> localBest;
        std::size_t coarseEvaluations = 0;
        std::size_t refineEvaluations = 0;
        bool capExceeded = false;
        const std::size_t recordStart = records.size();
        const std::size_t coarseBudget = maxCoarse / plans.size() +
            (combinationIndex < maxCoarse % plans.size() ? 1 : 0);
        const std::size_t refineBudget = maxRefine / plans.size() +
            (combinationIndex < maxRefine % plans.size() ? 1 : 0);

        ElectricalConstraintRequest electricalRequest;
        electricalRequest.experimental_dc = experimental;
        for (const auto* device : {plan.control, plan.cascode, plan.mirror, plan.resistor}) {
            if (device->native_parameter_trials) {
                electricalRequest.native_parameter_trials = true;
                electricalRequest.unverified_constraints.push_back(device->master + ".complete_parameter_domain");
            }
            if (device->voltage_domain.empty() && device->allowed_voltage_domains.empty())
                electricalRequest.unverified_constraints.push_back(device->master + ".voltage_domain");
        }
        electricalRequest.operation_id = request.template_request.operation_id;
        electricalRequest.polarity = polarity;
        electricalRequest.mirror_ref = {{}, layout.mirror_ref, plan.mirror->limits, plan.mirror->reliability_complete};
        electricalRequest.mirror_out = {{}, layout.mirror_out, plan.mirror->limits, plan.mirror->reliability_complete};
        electricalRequest.cascode_replica = {{}, layout.cas_rep, plan.cascode->limits, plan.cascode->reliability_complete};
        electricalRequest.control_replica = {{}, layout.ctrl_rep, plan.control->limits, plan.control->reliability_complete};
        electricalRequest.actual_control =
            {{}, request.target_instance, plan.control->limits, plan.control->reliability_complete};
        electricalRequest.actual_cascode = {{}, {}, plan.cascode->limits, plan.cascode->reliability_complete};
        electricalRequest.resistor = {request.template_request.operation_id,
                                      {}, layout.resistor, plan.resistor->master, experimental};
        electricalRequest.baseline_control = *baselineTarget;
        // Minimum-DC experiments do not impose optional performance targets.
        if (!experimental) {
            electricalRequest.max_branch_current_error = request.max_branch_current_error;
            electricalRequest.max_vbias_current = request.max_vbias_current;
        }

        auto evaluate = [&](const std::vector<double>& point, bool refine) {
            const std::string signature = pointSignature(point);
            const auto cached = cache.find(signature);
            if (cached != cache.end()) return cached->second;

            EvaluationRecord record;
            record.point = point;
            // 量化参数写入 BiasSizing：Cascode/Mirror/电阻为当前搜索值，
            // Cascode Replica 复刻新增管，Control Replica 复刻原管。
            BiasSizing sizing;
            sizing.mirror_master = plan.mirror->master;
            sizing.resistor_master = plan.resistor->master;
            record.combination_id = combinationIndex + 1;
            record.coarse_budget = coarseBudget;
            record.refine_budget = refineBudget;
            record.phase = refine ? "refine" : "coarse";
            record.electrical_check = electricalRequest;
            sizing.element_parameters[layout.mirror_ref] = {};
            sizing.element_parameters[layout.mirror_out] = {};
            sizing.element_parameters[layout.resistor] = {};
            sizing.element_parameters[layout.cas_rep] = {};
            sizing.element_parameters[layout.ctrl_rep] = {};
            for (std::size_t index = 0; index < params.size(); ++index) {
                const std::string& cdf = params[index].constraint.cdf_name;
                const std::string text = FormatAutoBiasParameter(point[index]);
                if (params[index].slot == 0) {
                    sizing.cascode_parameters[cdf] = text;
                } else if (params[index].slot == 1) {
                    sizing.element_parameters[layout.mirror_ref][cdf] = text;
                    sizing.element_parameters[layout.mirror_out][cdf] = text;
                } else {
                    sizing.element_parameters[layout.resistor][cdf] = text;
                }
            }
            if (!plan.resistor->native_resistor_trial_parameters.empty()) {
                const auto& rc = plan.resistor->parameter_constraints.at("resistance");
                for (std::size_t i = 0; i < params.size(); ++i) {
                    if (params[i].slot != 2 || params[i].constraint.cdf_name != rc.cdf_name) continue;
                    const auto trial = plan.resistor->native_resistor_trial_parameters.find(point[i]);
                    if (trial != plan.resistor->native_resistor_trial_parameters.end())
                        sizing.element_parameters[layout.resistor] = trial->second;
                }
            }
            sizing.element_parameters[layout.cas_rep] = sizing.cascode_parameters;
            sizing.element_parameters[layout.ctrl_rep] = controlReplicaParams;
            record.sizing = sizing;
            for (const auto& name : kConstraintOrder) record.constraints[name] = true;

            Netlist candidate;
            std::string cascodeInstance;
            if (!assembleCandidate(sizing, candidate, cascodeInstance, record)) {
                record.constraints["params_legal"] = false;
                record.reason = "candidate_construction_failed";
                records.push_back(std::move(record));
                cache.emplace(signature, records.size() - 1);
                return records.size() - 1;
            }

            DcEvaluationRequest evaluationRequest;
            evaluationRequest.candidate = std::move(candidate);
            evaluationRequest.root_subckt = request.root_subckt;
            evaluationRequest.target_instance = request.target_instance;
            evaluationRequest.cascode_instance = cascodeInstance;
            evaluationRequest.identity = request.nominal_identity;
            evaluationRequest.identity.topology_hash =
                ComputeNetlistTopologyHash(evaluationRequest.candidate);
            evaluationRequest.identity.parameter_hash =
                ComputeNetlistParameterHash(evaluationRequest.candidate);

            EvaluationRecord& stored = records.emplace_back(std::move(record));
            stored.cascode_instance = cascodeInstance;
            cache.emplace(signature, records.size() - 1);
            if (refine) {
                ++refineEvaluations;
            } else {
                ++coarseEvaluations;
            }
            stored.host_called = true;

            OperatingPointSnapshot snapshot;
            Diagnostic hostDiagnostic;
            stored.converged =
                host.Evaluate(evaluationRequest, snapshot, hostDiagnostic);
            if (evaluationFailed(stored, hostDiagnostic)) return records.size() - 1;
            assess(stored, snapshot);

            if (stored.kept && !best.has_value()) {
                localBest = records.size() - 1;
                best = records.size() - 1;
            }
            return records.size() - 1;
        };

        const auto resistorParam = std::find_if(params.begin(), params.end(), [](const auto& param) {
            return param.slot == 2 && param.semantic == "resistance";
        });
        const bool automatic = experimental && plan.resistor->native_resistor_auto_search &&
            resistorParam != params.end();
        const std::size_t resistanceIndex = static_cast<std::size_t>(resistorParam - params.begin());
        // Select from actual coupled CDF proposals. This schedules <=16 native
        // evaluations; it does not simulate the entire table or relax acceptance.
        auto nextResistance = [&]() -> std::optional<double> {
            const auto& values = coarseValues[resistanceIndex];
            const auto bounds = std::minmax_element(values.begin(), values.end());
            auto untestedNear = [&](double wanted, double low, double high) -> std::optional<double> {
                std::optional<double> selected;
                double distance = std::numeric_limits<double>::infinity();
                for (double value : values) {
                    if (value < low || value > high) continue;
                    auto point = initial;
                    point[resistanceIndex] = value;
                    if (cache.count(pointSignature(point))) continue;
                    const double delta = std::fabs(std::log(value/wanted));
                    if (delta < distance) { selected = value; distance = delta; }
                }
                return selected;
            };
            struct Probe { double r; double balance; double margin; };
            std::vector<Probe> probes;
            const bool keepControlSaturated = std::fabs(baselineTarget->intrinsic_vds.value_or(baselineTarget->vds)) >=
                std::fabs(baselineTarget->vdsat);
            for (std::size_t i = recordStart; i < records.size(); ++i) {
                const auto& row = records[i];
                if (!row.converged || !keepControlSaturated) continue;
                const auto margin = [&](const std::string& name) {
                    auto found = row.stress_measurements.find(name + ".saturation_margin");
                    return found == row.stress_measurements.end()
                        ? std::numeric_limits<double>::quiet_NaN() : found->second;
                };
                const double control = std::min(margin(request.target_instance), margin(layout.ctrl_rep));
                const double upper = std::min({margin(row.cascode_instance), margin(layout.cas_rep),
                                               margin(layout.mirror_ref), margin(layout.mirror_out)});
                if (std::isfinite(control) && std::isfinite(upper))
                    probes.push_back({row.point[resistanceIndex], control-upper, std::min(control,upper)});
            }
            std::sort(probes.begin(),probes.end(),[](const auto& a,const auto& b){return a.r<b.r;});
            // Bracket only observed opposing failure margins; no assumed N/P
            // direction or global monotonicity. Prefer the most promising bracket.
            std::optional<double> bracketPoint;
            double bracketScore = -std::numeric_limits<double>::infinity();
            for (std::size_t i=1; i<probes.size(); ++i) {
                const auto& a=probes[i-1]; const auto& b=probes[i];
                if ((a.balance<0)==(b.balance<0)) continue;
                auto point=untestedNear(std::sqrt(a.r*b.r),a.r,b.r);
                const double score=std::max(a.margin,b.margin);
                if (point && score>bracketScore) { bracketPoint=point; bracketScore=score; }
            }
            if (bracketPoint) return bracketPoint;
            // First estimate matches reference current to the original branch.
            // This is a proposal only; live node loading still requires full DC.
            if (records.size()==recordStart+1) {
                const auto& row=records.back();
                const auto current=row.stress_measurements.find("resistor.current");
                if (row.converged && current!=row.stress_measurements.end() &&
                    std::fabs(baselineTarget->id)>0 && std::fabs(current->second)>0) {
                    const double wanted=std::clamp(row.point[resistanceIndex] *
                        std::fabs(current->second/baselineTarget->id),*bounds.first,*bounds.second);
                    if (auto point=untestedNear(wanted,*bounds.first,*bounds.second)) return point;
                }
            }
            // Explore uncovered logarithmic intervals if no useful bracket exists.
            std::vector<double> samples{*bounds.first,*bounds.second};
            for (std::size_t i=recordStart;i<records.size();++i)
                samples.push_back(records[i].point[resistanceIndex]);
            std::sort(samples.begin(),samples.end());
            std::optional<double> next;
            double widest=-1;
            for (std::size_t i=1;i<samples.size();++i) {
                const double width=std::log(samples[i]/samples[i-1]);
                auto point=untestedNear(std::sqrt(samples[i]*samples[i-1]),samples[i-1],samples[i]);
                if (point && width>widest) { widest=width;next=point; }
            }
            return next;
        };

        // ---- 粗搜索：初值点 + 逐参数枚举值集合，首个硬约束通过即停止 ----
        std::vector<double> center = initial;
        evaluate(center, false);
        if (automatic) {
            records.back().phase = "automatic";
            while (!best.has_value() && !evaluationAborted && !capExceeded) {
                const auto next = nextResistance();
                if (!next) break;
                if (records.size()-recordStart >= coarseBudget || coarseEvaluations >= coarseBudget) {
                    capExceeded = true;
                    break;
                }
                auto point = initial;
                point[resistanceIndex] = *next;
                evaluate(std::move(point),false);
                records.back().phase = "automatic";
            }
        }
        for (std::size_t index = 0; index < params.size() && !automatic && !evaluationAborted && !capExceeded && !best.has_value(); ++index) {
            for (const double value : coarseValues[index]) {
                if (best.has_value() || evaluationAborted) break;
                if (localBest.has_value()) center = records[*localBest].point;
                if (value == center[index]) continue;
                if ((experimental && records.size() - recordStart >= coarseBudget) ||
                    coarseEvaluations >= coarseBudget ||
                    coarseEvaluations + refineEvaluations >= maxTotal) {
                    capExceeded = true;
                    break;
                }
                std::vector<double> point = center;
                point[index] = value;
                evaluate(std::move(point), false);
            }
        }

        // If axis probes failed, search joint coarse values: feasibility may require
        // changing multiple parameters together. Bound all host calls by the same budget.
        std::vector<double> joint = initial;
        std::function<void(std::size_t)> searchJoint = [&](std::size_t index) {
            if (best.has_value() || capExceeded || evaluationAborted) return;
            if (index == params.size()) {
                if (cache.count(pointSignature(joint)) != 0) return;
                if ((experimental && records.size() - recordStart >= coarseBudget) ||
                    coarseEvaluations >= coarseBudget) {
                    capExceeded = true;
                    return;
                }
                evaluate(joint, false);
                return;
            }
            for (const double value : coarseValues[index]) {
                joint[index] = value;
                searchJoint(index + 1);
                if (best.has_value() || capExceeded || evaluationAborted) break;
            }
        };
        if (!automatic && !best.has_value()) searchJoint(0);

        // The joint coarse budget is independent from the retained neighbor budget.
        const bool coarseTruncated = capExceeded;
        capExceeded = false;
        // ---- 局部精搜索：逐参数尝试相邻两个合法量化值 ----
        auto neighbor = [&](std::size_t index, double current, int direction,
                            double& value) {
            const ParameterConstraint& constraint = params[index].constraint;
            double seed = current;
            if (!constraint.discrete_values.empty()) {
                std::vector<double> sorted = constraint.discrete_values;
                std::sort(sorted.begin(), sorted.end());
                const auto found =
                    std::find(sorted.begin(), sorted.end(), current);
                if (found == sorted.end()) return false;
                if (direction > 0) {
                    if (found + 1 == sorted.end()) return false;
                    seed = *(found + 1);
                } else {
                    if (found == sorted.begin()) return false;
                    seed = *(found - 1);
                }
            } else if (constraint.grid > 0.0) {
                seed = current + direction * constraint.grid;
            } else if (constraint.integer_only) {
                seed = current + direction;
            } else {
                return false;
            }
            if (!quantize(seed, constraint, value) || value == current) return false;
            return true;
        };

        bool improved = true;
        while (!experimental && improved && !evaluationAborted && !capExceeded && !best.has_value()) {
            improved = false;
            for (std::size_t index = 0; index < params.size() && !evaluationAborted && !capExceeded && !best.has_value();
                 ++index) {
                for (const int direction : {1, -1}) {
                    if (best.has_value() || evaluationAborted) break;
                    if (localBest.has_value()) center = records[*localBest].point;
                    const std::string bestBefore = localBest.has_value()
                        ? pointSignature(records[*localBest].point)
                        : std::string{};
                    double value = 0.0;
                    if (!neighbor(index, center[index], direction, value)) continue;
                    if (refineEvaluations >= refineBudget ||
                        coarseEvaluations + refineEvaluations >=
                            maxTotal) {
                        capExceeded = true;
                        break;
                    }
                    std::vector<double> point = center;
                    point[index] = value;
                    evaluate(std::move(point), true);
                    const std::string bestAfter = localBest.has_value()
                        ? pointSignature(records[*localBest].point)
                        : std::string{};
                    if (bestAfter != bestBefore) improved = true;
                }
            }
        }

        result.nominal_evaluations += coarseEvaluations + refineEvaluations;
        ++result.searched_device_combinations;
        result.parameter_search_truncated = result.parameter_search_truncated ||
            coarseTruncated || capExceeded;
        for (std::size_t index = recordStart; index < records.size(); ++index) {
            records[index].parameter_search_truncated = coarseTruncated || capExceeded;
        }
        if (evaluationAborted) break;
    }

    // ---- PVT复验：首个可行参数固定，逐Corner只查硬约束，不重选尺寸 ----
    if (best.has_value() && !request.pvt_corners.empty()) {
        const std::size_t chosenIndex = *best;
        result.pvt_ready = true;
        for (const auto& corner : request.pvt_corners) {
            EvaluationRecord record;
            record.point = records[chosenIndex].point;
            record.sizing = records[chosenIndex].sizing;
            record.cascode_instance = records[chosenIndex].cascode_instance;
            record.corner = corner;
            record.electrical_check = records[chosenIndex].electrical_check;
            record.combination_id = records[chosenIndex].combination_id;
            record.coarse_budget = records[chosenIndex].coarse_budget;
            record.refine_budget = records[chosenIndex].refine_budget;
            record.parameter_search_truncated = records[chosenIndex].parameter_search_truncated;
            record.phase = "pvt";
            for (const auto& name : kConstraintOrder) {
                record.constraints[name] = true;
            }
            Netlist candidate;
            std::string cascodeInstance;
            if (!assembleCandidate(record.sizing, candidate, cascodeInstance, record)) {
                record.constraints["params_legal"] = false;
                record.kept = false;
                record.reason = "candidate_construction_failed";
            } else {
                DcEvaluationRequest evaluationRequest;
                evaluationRequest.candidate = std::move(candidate);
                evaluationRequest.root_subckt = request.root_subckt;
                evaluationRequest.target_instance = request.target_instance;
                evaluationRequest.cascode_instance = cascodeInstance;
                evaluationRequest.identity = request.nominal_identity;
                evaluationRequest.identity.corner = corner;
                evaluationRequest.identity.topology_hash =
                    ComputeNetlistTopologyHash(evaluationRequest.candidate);
                evaluationRequest.identity.parameter_hash =
                    ComputeNetlistParameterHash(evaluationRequest.candidate);
                record.host_called = true;
                ++result.pvt_evaluations;
                OperatingPointSnapshot snapshot;
                Diagnostic hostDiagnostic;
                record.converged =
                    host.Evaluate(evaluationRequest, snapshot, hostDiagnostic);
                if (!evaluationFailed(record, hostDiagnostic)) assess(record, snapshot);
            }
            result.pvt_results.push_back(
                {corner, record.kept,
                 record.kept ? std::string{} : record.reason});
            result.pvt_ready = result.pvt_ready && record.kept;
            records.push_back(std::move(record));
            if (evaluationAborted) break;
        }
    }

    if (experimental) result.pvt_ready = false;

    // A failed electrical search still yields the closest measured candidate.
    // Never rank a construction failure, unreadable result, or unconverged DC.
    std::optional<std::size_t> selected = best;
    const auto rank = [](const EvaluationRecord& record) {
        std::size_t otherFailures = 0, allFailures = 0;
        for (const auto& [name, passed] : record.constraints) {
            if (passed) continue;
            ++allFailures;
            if (name != "saturation") ++otherFailures;
        }
        return std::make_tuple(otherFailures, record.metrics.saturation_deficit,
                               allFailures, record.metrics.branch_current_error);
    };
    if (experimental && !selected && !evaluationAborted) {
        for (std::size_t index = 0; index < records.size(); ++index) {
            const auto& record = records[index];
            const auto complete = record.constraints.find("complete");
            const auto legal = record.constraints.find("params_legal");
            if (!record.corner.empty() || !record.host_called || !record.converged ||
                record.evaluation_failed || !record.construction_stage.empty() ||
                complete == record.constraints.end() || !complete->second ||
                legal == record.constraints.end() || !legal->second ||
                !record.stress_measurements.count("resistor.current") ||
                !record.stress_measurements.count("resistor.voltage") ||
                !std::isfinite(record.vbias_voltage) ||
                !std::isfinite(record.metrics.saturation_deficit) ||
                !std::isfinite(record.metrics.branch_current_error)) continue;
            if (!selected || rank(record) < rank(records[*selected])) selected = index;
        }
    }
    result.evaluation_failed = evaluationAborted;
    // ---- 结果与确定性轨迹 ----
    for (std::size_t index = 0; index < records.size(); ++index) {
        const auto& record = records[index];
        result.trace_lines.push_back(traceLine(
            index + 1,
            record.corner.empty() ? request.nominal_identity.corner
                                  : record.corner,
            record, layout, selected.has_value() && !evaluationAborted && index == *selected));
    }

    if (selected.has_value() && !evaluationAborted) {
        const EvaluationRecord& chosen = records[*selected];
        result.ok = best.has_value();
        result.best_effort = !result.ok;
        result.selected_candidate = *selected + 1;
        for (const auto& [name, passed] : chosen.constraints)
            if (!passed) result.failed_constraints.push_back(name);
        result.sizing = chosen.sizing;
        result.sizing.nominal_voltage = chosen.vbias_voltage;
        result.sizing.iq_delta = chosen.metrics.iq_delta;
        result.metrics = chosen.metrics;
        result.native_parameter_trials = chosen.electrical_check.native_parameter_trials;
        result.reliability_verified = chosen.reliability_verified;
        result.unverified_constraints = chosen.unverified_constraints;
        for (const auto& record : records) {
            if (record.corner.empty()) continue;
            result.reliability_verified = result.reliability_verified && record.reliability_verified;
            for (const auto& unknown : record.unverified_constraints)
                result.unverified_constraints.push_back(record.corner + "." + unknown);
        }
        result.stress_measurements = chosen.stress_measurements;
        result.electrical_check = chosen.electrical_check;
        result.electrical_check.actual_cascode.leaf_name =
            chosen.cascode_instance;
        return result;
    }

    result.ok = false;
    if (!records.empty()) result.sizing = records.back().sizing;
    result.diagnostics.push_back(
        {DiagCode::BadParam,
         std::string(evaluationAborted
             ? "evaluation_failed: 后端执行或读取失败，已停止剩余试点；尚不能判定该点电气可行性"
             : result.nominal_evaluations == 0
             ? "candidate_construction_failed: 候选组装失败，尚未进入DC评估"
             : result.parameter_search_truncated
             ? "search_budget_exhausted: fixed_device_set 预算内未找到满足硬约束的候选"
             : "no_feasible_evaluated_candidate: fixed_device_set 已评估参数未找到满足硬约束的候选，不代表整个PDK无解") +
             "（组合 " + std::to_string(result.searched_device_combinations) + "/" +
             std::to_string(result.device_combinations) + "，名义评估 " +
             std::to_string(result.nominal_evaluations) +
             "/" + std::to_string(maxTotal) + "），返回最后候选参数与逐项原因"});
    std::set<std::string> constructionErrors;
    for (const auto& record : records) {
        if (record.construction_stage.empty()) continue;
        const auto detail = record.construction_stage + ": " + record.construction_message;
        if (constructionErrors.insert(detail).second)
            result.diagnostics.push_back({DiagCode::BadParam, detail});
    }
    if (result.nominal_evaluations == 0 && !constructionErrors.empty())
        result.diagnostics.front().message += "; " + *constructionErrors.begin();
    std::set<std::string> hostErrors;
    for (const auto& record : records) {
        if (record.host_message.empty() || !hostErrors.insert(record.host_message).second) continue;
        // The CLI prints the first diagnostic. Do not bury an OA/materialization
        // failure behind a generic not_converged constraint and old baseline logs.
        if (hostErrors.size() == 1)
            result.diagnostics.front().message += "; host_error=" + record.host_message;
        result.diagnostics.push_back({DiagCode::BadParam, "host_error=" + record.host_message});
    }
    std::map<std::string, std::size_t> reasonCounts;
    for (const auto& record : records) ++reasonCounts[record.reason];
    for (const auto& name : kConstraintOrder) {
        const auto found = reasonCounts.find(reasonName(name));
        if (found != reasonCounts.end()) {
            result.diagnostics.push_back(
                {DiagCode::BadParam,
                 "constraint " + found->first + ": " +
                     std::to_string(found->second) + " candidate(s) rejected"});
        }
    }
    return result;
}

} // namespace st
