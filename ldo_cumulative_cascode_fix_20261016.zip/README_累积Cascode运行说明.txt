累积Cascode更新（2026-10-16）

执行位置：服务器 /tmpdata/maau_epc/users/k00981589，st_batch沿用现有批次。
将ldo_cumulative_cascode_fix_20261016.zip上传至此目录，再粘贴下面一整行：

unzip -o ldo_cumulative_cascode_fix_20261016.zip && bash st-engine-maau/scripts/build.sh --tool-only && bash st-engine-maau/scripts/test_mixed_cascode.sh retry-four "$st_batch/candidate_I21_xbb892w0"

此命令沿用已确认的I21同型、I105异型、I29同型、I85异型四组，不重新confirm或撤销。
按顺序：选定I21参数→保留I21并处理I105→保留前两组处理I29→保留前三组处理I85。
每组最多16次候选DC，首个本组及前组最低条件同时满足的点停止。前组参数固定，工作点随完整电路重新求解。
旧选中参数仅作为合法初值，本轮重新仿真。无需--fresh-search，也无需指定阻值倍率。
同一组内继续复用已建OA更新参数，新增组时物化包含前组的完整候选；最终组合另外做实际回读/DC。

预期进度示例（具体试点数量和VBIAS由真实结果决定）：
VBIAS_CUMULATIVE=true
VBIAS_OPERATION=START operation=op_I21 target=I21 retained_groups=0
VBIAS_OPERATION=START operation=op_I105 target=I105 retained_groups=1
VBIAS_CUMULATIVE_CHECK operation=op_I105 previous_groups=1 result=PASS
VBIAS_OPERATION=START operation=op_I29 target=I29 retained_groups=2
VBIAS_OPERATION=START operation=op_I85 target=I85 retained_groups=3
VBIAS_CUMULATIVE_CHECK operation=op_I85 previous_groups=3 result=PASS

只有四组和最终组合真实通过，才应看到：
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
TEST_GROUPS=4
GENERATED_SUBCELLS=8
MIXED_CASCODE_TEST=PASS

16点无完全合格解：可以选当前组真实有效的best_effort，但必须保持前组最低条件通过。
如果所有候选都会破坏前组，则停止后续组，报告INCOMPLETE及skipped_cumulative_failure；不会自动退回独立求解或宣布电气通过。
最终仅为待优化候选时，脚本仍报告MIXED_CASCODE_TEST=NOT_PASSED；这不等于四组验收通过。
许可证/原生读取失败仍报告evaluation_failed并停止，未修改许可证机制。
本地：工具已编译，353项C++检查与58项Python测试通过；本机没有Cadence，不代表服务器四组已通过。
