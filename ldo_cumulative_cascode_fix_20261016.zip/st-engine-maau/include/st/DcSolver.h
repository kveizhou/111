#pragma once
// =============================================================
// DcSolver.h — PDK 离散参数 DC 闭环求解器（Task 6）
// 对每个候选：写入量化参数 → BuildAutoBiasTemplate 重建模板 →
// 组装候选网表 → DcEvaluationHost 评估 DC 工作点 → 硬约束过滤 →
// 首个可行解。固定已核实器件组合共用≤384次名义DC评估预算；
// 入选组合另按每个PVT Corner一次复验；实验仅≤16个有限候选，不做细搜。
// =============================================================
#include "AutoBias.h"
#include "Netlist.h"
#include "OperatingPoint.h"
#include "ResistorStress.h"
#include "Types.h"

#include <string>
#include <map>
#include <optional>
#include <vector>

namespace st {

// 诊断指标；实验失败时仅按必要约束不足程度选择待优化候选。
struct DcCandidateMetrics {
    double branch_current_error = 0.0;
    double control_op_error = 0.0;
    double iq_delta = 0.0;
    double reliability_margin = 0.0;
    double saturation_margin = 0.0;
    double area_estimate = 0.0;
    double saturation_deficit = 0.0; // 必须饱和的角色中最大相对不足
};

// 一个待校验 MOS 的逻辑角色。leaf_name 是器件在未封装候选中的实例名；
// container_instance 非空时表示最终 Virtuoso 封装实例。OP 提取器可以输出
// leaf_name，也可以输出 container.leaf/container/leaf/container:leaf，校验器
// 只在唯一匹配时接受，避免多套 VBIAS 角色同名时串读工作点。
struct ElectricalMosRole {
    std::string container_instance;
    std::string leaf_name;
    DeviceLimits limits;
    bool reliability_complete = true;
};

// 候选和最终 staging 共用的电气硬约束输入。所有字段均为值对象，便于把
// 求解时选中的真实 PDK 限值原样带到最终物化门禁。
struct ElectricalConstraintRequest {
    std::string operation_id;
    DeviceKind polarity = DeviceKind::Other;
    ElectricalMosRole mirror_ref;
    ElectricalMosRole mirror_out;
    ElectricalMosRole cascode_replica;
    ElectricalMosRole control_replica;
    ElectricalMosRole actual_control;
    ElectricalMosRole actual_cascode;
    ExpectedResistor resistor;
    MosOperatingPoint baseline_control;
    // 两项上限可同时省略做 DC 可行性求参；提供时须成对、有限且为正数。
    std::optional<double> max_branch_current_error; // 相对基线电流的无量纲偏差
    std::optional<double> max_vbias_current; // VBIAS 两条支路的电流和，单位 A
    bool experimental_dc = false;
    bool native_parameter_trials = false;
    std::vector<std::string> unverified_constraints;
};

struct ElectricalConstraintResult {
    bool ok = false;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    std::string first_failed_constraint;
    // Missing keys are unverified, not a true/false verdict; trace serializes them as null.
    std::map<std::string, bool> constraints;
    DcCandidateMetrics metrics;
    double vbias_voltage = 0.0;
};

// 对真实主通路和模板六只 MOS 执行同一套硬约束。converged=false 时直接
// 返回 not_converged；缺少或不唯一的层级实例返回 incomplete_snapshot。
ElectricalConstraintResult EvaluateElectricalConstraints(
    const OperatingPointSnapshot& snapshot,
    const ElectricalConstraintRequest& request,
    bool converged = true);

// 交给宿主的单次 DC 评估请求。candidate = 基线网表 + VBIAS 模板子电路
// （含当前量化参数）+ 顶层模板实例；identity 为名义 Corner 身份。
struct DcEvaluationRequest {
    Netlist candidate;
    std::string root_subckt;
    std::string target_instance;
    std::string cascode_instance;
    AnalysisIdentity identity;
    std::string operation_id;
};

// 宿主契约：对候选网表运行（或伪造）名义 DC 工作点。
// 返回 false 且 diagnostic 非空表示执行/读取失败，停止搜索，不判电气无解。
// 已确认不收敛时返回 false、diagnostic 留空；允许继续其它参数点。
// 返回快照的 mos 必须以模板角色名为键（如 "P_REF"、"N_CAS_REP_N"）；
// 模板参考电阻必须出现在 snapshot.resistors 中，包含实际端电位、电流及
// 当前 master/几何/Corner 的 PDK 额定值。真实宿主先核对 OA 回读再仿真。
class DcEvaluationHost {
public:
    virtual ~DcEvaluationHost() = default;
    virtual bool Evaluate(const DcEvaluationRequest&,
                          OperatingPointSnapshot&,
                          Diagnostic&) = 0;
};

// 单个 PVT Corner 的复验结论：固定名义可行参数，复用全部硬约束。
// ok=false 时 failed_constraint 给出第一个失败的约束名
// （如 reliability_vgs，对应规格举例的 max_abs_vgs 类约束）。
struct PvtCornerResult {
    std::string corner;
    bool ok = false;
    std::string failed_constraint;
};

struct AutoBiasSolveResult {
    bool ok = false;
    bool best_effort = false; // 有完整收敛点，但未通过最低DC条件
    bool evaluation_failed = false;
    std::size_t selected_candidate = 0; // 与trace的candidate一致，0表示未选中
    std::vector<std::string> failed_constraints;
    bool native_parameter_trials = false;
    bool reliability_verified = false;
    std::vector<std::string> unverified_constraints;
    std::map<std::string, double> stress_measurements;
    BiasSizing sizing;                 // 首个可行或自动选出的待优化候选参数
    DcCandidateMetrics metrics;        // 可行候选的诊断指标
    std::vector<std::string> trace_lines; // 确定性 JSONL，两次运行字节一致
    std::vector<Diagnostic> diagnostics;
    // pvt_corners 非空时逐 Corner 复验（不换参数、不重排名）；
    // 配置了 PVT 且全部 Corner 通过时 pvt_ready=true，未配置恒 false。
    std::vector<PvtCornerResult> pvt_results;
    bool pvt_ready = false;
    // 求解成功时给最终 staging 复用；容器实例名由封装阶段补齐。
    ElectricalConstraintRequest electrical_check;
    std::size_t device_combinations = 0;
    std::size_t searched_device_combinations = 0;
    std::size_t nominal_evaluations = 0;
    std::size_t pvt_evaluations = 0;
    bool parameter_search_truncated = false;
};

struct AutoBiasSolveRequest {
    Netlist baseline;                  // 基线网表（提供原管实例参数）
    std::string root_subckt;
    std::string target_instance;       // 原 MOS 实例名
    AutoBiasTemplateRequest template_request;
    OperatingPointSnapshot baseline_op; // 基线 DC 工作点（含目标实例）
    AnalysisIdentity nominal_identity;
    // 候选电路必须按与最终生成相同的 Bulk 策略实际执行
    // Cascode 变换，不允许只仿真一个脱离主电路的 VBIAS 模板。
    std::string nmos_bulk_net;
    bool tie_isolated_pmos_to_source = true;
    std::vector<std::string> pvt_corners; // Task 9 使用；Task 6 只求名义 Corner
    // 两项上限可同时省略做 DC 可行性求参；提供时须成对、有限且为正数。
    std::optional<double> max_branch_current_error;
    std::optional<double> max_vbias_current;
    // These groups retain their selected parameters in baseline. Check them
    // using the same full-circuit DC snapshot as the current trial.
    std::vector<ElectricalConstraintRequest> preceding_checks;
};

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest&,
                                  const DeviceCatalog&,
                                  DcEvaluationHost&);

} // namespace st
