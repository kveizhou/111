Source电阻初值精度修复（2026-10-18）

本包接在ldo_combined_features_test_20261018.zip之后使用。
错误发生在第一项电阻confirm，尚未开始DC搜索。
程序指定48259.84Ω，却被六位工程格式写成48.2598k，即48259.8Ω。
真实离散取值检查因0.04Ω差异拒绝。现在保留原值，不放宽检查、不换电阻。

默认值说明：当前通用代码依次采用显式指定值、Case预置值、合法正区间的几何中点sqrt(Rmin*Rmax)，并非最大值的一半。本组合测试显式采用已经绑定的真实种子，所以没有进入默认中点分支。本修复不改变默认选择策略。

上传到st-engine-maau所在目录，整行执行（C++已改，必须重编）：
unzip -o ldo_source_resistor_precision_fix_20261018.zip && bash st-engine-maau/scripts/build.sh --tool-only && bash st-engine-maau/scripts/test_mixed_cascode.sh combo "$st_batch/candidate_I21_xbb892w0"

修复后前段应顺利经过：
已确认操作: test_resistor_I29，当前操作数=1
ACTIVE_GROUPS=1
已撤销最后一次修改，剩余操作数=0
ACTIVE_GROUPS=0
RESISTOR_OPERATION_UNDONE=true
（随后确认I21同型、I105异型、I85 Stack，活动组数依次1、2、3，最后开始生成。）

最终仍以真实生成与DC结果为准：
COMBINED_STRUCTURE_TEST=PASS表示电阻撤销及三项变换的结构检查通过。
COMBINED_DC_TEST=PASS且COMBINED_FEATURES_TEST=PASS才是本测试全部通过。
若I105等仍有saturation未满足，可生成待优化结果，但不会声称电气通过。

本地复现已修复；23项电阻变换检查、183项CLI检查及工具编译通过。
本包未执行服务器Cadence或Spectre，不代表最终三项组合已通过。
