电阻PDK筛选与回读修复（2026-10-15）

适用：已安装 ldo_numeric_readback_fix_20261015.zip 并编译的当前现场。
仅替换两份Python文件，不需要重编C++，不需要新建会话或重跑成功基线。

本次修改：
1. 补齐Python侧同值小数/工程后缀比较，真实数值不同会直接打印字段和实读值。
2. 自动调用所选真实电阻的CDF参数设置/回调，读取限制、剔除拒绝或被修改的参数，只把可确认的离散点送入VBIAS搜索。
   min/max空白不当成无限制；找不到相关调整规则时不伪称合法。
3. 筛选使用一次Virtuoso会话，不运行Spectre；随后沿用最多16个不同DC点的自动搜索和最终选中点复验。

在 /tmpdata/maau_epc/users/k00981589 下执行以下整行：
unzip -o ldo_resistor_pdk_check_fix_20261015.zip && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs

运行中先显示：
RESISTOR_PDK_CHECK=START
RESISTOR_PDK_ACCEPTED_POINTS=<实际接受数量>
RESISTOR_PDK_REJECTED_POINTS=<实际剔除数量>
RESISTOR_PDK_CHECK=PASS
RESISTOR_SEARCH_SET=PDK_ACCEPTED_DISCRETE_POINTS
RESISTOR_ACCEPTED_RANGE_OHMS=<已检查点的最小值>,<最大值>
AUTO_VBIAS_MAX_DC_EVALUATIONS=16

接受数量由服务器PDK决定，不固定为800；范围表示已检查离散点的覆盖范围，不表示区间内任意值均合法。
如果没有可确认的点，自动停止并给出原因，不要求手选阻值，也不会把未知范围当合法。

后续最终结果：
RESULT=EXPERIMENT_DC_PASS：所选点通过当前最低DC条件。
RESULT=OPTIMIZATION_CANDIDATE_READY：已生成可交后续优化的收敛候选，但仍有未满足项，不等于电气通过。
RESULT=INCOMPLETE：没有可确认参数/有效仿真，或执行、回读失败，不能假报成功。

本地84项相关测试通过；测试中的原生Cadence调用是替身。真实PDK筛选与候选DC尚待这次服务器运行确认，未承诺完整工艺/可靠性签核。
