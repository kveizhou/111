"""Source-bound finite native CDF trials, never a claimed PDK legal domain.

Input: profile.experimental_parameter_seeds["library/cell"] contains instance,
native_records (absolute collect_cascode_batch JSON), its SHA256, and optional
trials keyed by normalized parameter name. Trial literals use the parameter's
CDF units, as do actual cdf_value records. No defValue is used as an instance.
"""
import csv
import hashlib
import json
import math
from pathlib import Path

from site_data import finite, read_json
from standalone_pdk import cdf_numeric

MAX_TRIAL_COMBINATIONS = 16
MAX_TRIAL_VALUES = 5
MAX_MASTERS = 12


def _source(value, label):
    if (not isinstance(value, str) or not value.strip() or value.lower() in ('unknown', 'missing') or
            'guess' in value.lower() or 'inference' in value.lower()):
        raise ValueError('proven ' + label + ' source is required')
    return value


def load_actual_seed(seed, model, parameters, master=None):
    """Read only a fingerprinted native instance-value cache, not base CDF."""
    instance = _source(seed.get('instance'), 'actual instance seed')
    path = Path(seed.get('native_records', ''))
    if not path.is_absolute() or not path.is_file():
        raise ValueError('actual instance seed native_records must be an existing absolute file')
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if seed.get('native_records_sha256') != digest:
        raise ValueError('actual instance seed native_records changed or SHA256 missing: ' + str(path))
    values, binding = {}, {}
    for record in read_json(path):
        if record.get('scope') != instance or record.get('kind') not in ('cdf_value', 'source'):
            continue
        target = binding if record['kind'] == 'source' else values
        name = record.get('name')
        if name in target or record.get('status') != 'OK':
            raise ValueError('actual instance seed duplicate or failed value: ' + instance + '/' + str(name))
        text = record.get('raw_value', '')
        try:
            value = json.loads(text)
        except (ValueError, TypeError):
            value = text
        target[name] = value
    if not values:
        raise ValueError('actual instance seed cdf_value records missing: ' + instance)
    if values.get('model', values.get('modelName')) != model:
        raise ValueError('actual instance seed model binding missing/conflicting: ' + instance)
    if master and binding.get('oa_library', '') + '/' + binding.get('oa_cell', '') != master:
        raise ValueError('actual instance seed OA master binding missing/conflicting: ' + instance)
    missing = set(parameters) - values.keys()
    if missing:
        raise ValueError('actual instance seed parameters missing: ' + ','.join(sorted(missing)))
    return values, str(path.resolve()), digest


def _unit_semantic(row, semantic):
    unit = row.get('units', '')
    if semantic.startswith('cdf_'):
        if unit in ('m', 'meter', 'metre', 'meters', 'um', 'µm', 'nm', 'mm', 'lengthMetric'):
            return 'length'
        if unit in ('ohm', 'Ohm', 'ohms', 'Ohms', 'Ω', 'resistance'):
            return 'resistance'
    return semantic


def _numeric(value, row, semantic):
    if isinstance(value, bool):
        raise ValueError('boolean is not a numeric CDF trial')
    passthrough = semantic.startswith('cdf_')
    unit = row.get('units', '')
    result = cdf_numeric(value, unit, _unit_semantic(row, semantic))
    finite(result, not passthrough)
    if (semantic in ('fin', 'fins', 'fingers', 'multiplier') or row.get('cdf_type') == 'int') and result != int(result):
        raise ValueError('count trial must be integral: ' + semantic)
    return result


def _known_bounds(values, row, semantic, declared):
    """Reject every contradicted known fact, even when the other bound is absent."""
    bounds = []
    for field in ('min', 'max'):
        text = row.get(field)
        if text not in (None, ''):
            try:
                value = cdf_numeric(text, row.get('units', ''), _unit_semantic(row, semantic))
            except ValueError:
                # Expressions are not understood; the native callback still gates them.
                continue
            finite(value)
            bounds.append((field, value, 'actual CDF'))
        if field in declared:
            bounds.append((field, finite(declared[field]), 'documented rule'))
    for field, limit, source in bounds:
        if any((v < limit and not math.isclose(v, limit, rel_tol=1e-12)) if field == 'min'
               else (v > limit and not math.isclose(v, limit, rel_tol=1e-12)) for v in values):
            raise ValueError('trial violates known ' + source + ' bound: ' + semantic + '/' + field)
    allowed = declared.get('allowed', [])
    if allowed:
        allowed = [finite(v) for v in allowed]
        if any(not any(math.isclose(v, x, rel_tol=1e-12) for x in allowed) for v in values):
            raise ValueError('trial violates known allowed bound: ' + semantic)
    grid = finite(declared.get('grid', 0))
    if grid < 0:
        raise ValueError('known parameter grid must be nonnegative')
    if grid:
        origin = finite(declared.get('min', 0))
        if any(not math.isclose((v-origin)/grid, round((v-origin)/grid), abs_tol=1e-7) for v in values):
            raise ValueError('trial violates known grid bound: ' + semantic)
    if row.get('choices'):
        try:
            choices = [_numeric(text, row, semantic) for text in row['choices'].split(',')]
        except ValueError:
            choices = []
        if choices and any(not any(math.isclose(v, x, rel_tol=1e-12) for x in choices) for v in values):
            raise ValueError('trial violates known CDF choice bound: ' + semantic)
    return [{'field': field, 'value': value, 'source': source} for field, value, source in bounds]


def preserved_primitives(groups, selected, source):
    """Keep proven, unselected primitive identities; no type/rating inference.

    These never enter the transform catalog or its parameter search. The
    existing physical binding reader still checks their model and terminal
    count, while source/variant netlist verification protects the circuit.
    """
    result = []
    for key, rows in sorted(groups.items()):
        if key in selected:
            continue
        first = rows[0]
        names = first['terminal_names'].split(',')
        if (not first['model_name'] or not all(names) or len(set(names)) != len(names) or
                any(row.get('has_schematic') != 'false' or
                    row['model_name'] != first['model_name'] or
                    row['terminal_names'] != first['terminal_names'] for row in rows)):
            continue
        result.append(dict(oa_library=first['oa_library'],cell=first['oa_cell'],
                           model=first['model_name'],source=source))
    return result


def build_experimental_metadata(root, probe_path, profile, rules, pdk_name=None):
    if profile.get('validation_scope') != 'experimental_dc':
        raise ValueError('native parameter trials require experimental_dc')
    source = _source(rules.get('source'), 'device facts')
    requested = root if isinstance(root, (list, tuple)) else [root]
    aliases = list(dict.fromkeys(str(Path(p).absolute()) for p in requested))
    roots = list(dict.fromkeys(str(Path(p).resolve()) for p in aliases))
    if not roots or any(not Path(p).is_dir() for p in roots):
        raise ValueError('PDK root must be an existing directory')
    seeds = profile.get('experimental_parameter_seeds', {})
    if not isinstance(seeds, dict) or not seeds or len(seeds) > MAX_MASTERS:
        raise ValueError('actual instance seed selection required (at most 12 masters)')
    groups = {}
    with Path(probe_path).open(newline='') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        required = {'oa_library', 'oa_cell', 'model_name', 'terminal_names', 'parameter', 'units', 'has_schematic'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('experimental trials require extended actual OA/CDF probe')
        for row in reader:
            key = row['oa_library'] + '/' + row['oa_cell']
            if None in row:
                raise ValueError('malformed actual OA/CDF probe')
            groups.setdefault(key, []).append(row)
    devices, fingerprints = [], {str(Path(probe_path).resolve()): hashlib.sha256(Path(probe_path).read_bytes()).hexdigest()}
    for key, seed in sorted(seeds.items()):
        rows = groups.get(key)
        if not rows:
            raise ValueError('selected master missing from actual OA/CDF probe: ' + key)
        identity = rows[0]
        if any(r['terminal_names'] != identity['terminal_names'] or r['model_name'] != identity['model_name'] for r in rows):
            raise ValueError('conflicting actual OA/CDF identity: ' + key)
        if identity.get('has_schematic') != 'false':
            raise ValueError('selected trial master is not a proven primitive: ' + key)
        rule = rules.get('devices', {}).get(key, {})
        kind = rule.get('kind')
        if kind not in ('mos_n', 'mos_p', 'resistor'):
            raise ValueError('proven device type/polarity required: ' + key)
        names = identity['terminal_names'].split(',')
        roles = rule.get('terminalRoles', {})
        required_roles = ('positive', 'negative') if kind == 'resistor' else ('drain', 'gate', 'source', 'bulk')
        if (not names or '' in names or len(names) != len(set(names)) or set(roles) != set(names)
                or any(list(roles.values()).count(role) != 1 for role in required_roles)
                or (kind != 'resistor' and len(names) != 4)
                or (kind == 'resistor' and len(names) not in (2, 3))
                or any(role not in required_roles + ('substrate',) for role in roles.values())):
            raise ValueError('proven actual terminal mapping required: ' + key)
        if kind != 'resistor':
            _source(rule.get('bulkRule'), 'Bulk strategy for ' + key)
            # These are the only body conventions implemented by AutoBias:
            # isolated_well follows the template's source connection; rail
            # binds NMOS to VLOW and PMOS to VHIGH. Do not turn arbitrary
            # documentation text (e.g. "ground") into a proven rail policy.
            if rule['bulkRule'] not in ('isolated_well', 'rail'):
                raise ValueError('supported Bulk strategy must be isolated_well or rail: ' + key)
        model = rule.get('model', identity['model_name'])
        if not model or (identity['model_name'] and model != identity['model_name']):
            raise ValueError('actual model identity missing/conflicting: ' + key)
        mapping = dict(rule.get('normalized_to_cdf', {}))
        if not mapping or len(set(mapping.values())) != len(mapping):
            raise ValueError('explicit unique normalized_to_cdf mapping required: ' + key)
        by_parameter = {r['parameter']: r for r in rows if r['parameter']}
        if not set(mapping.values()).issubset(by_parameter):
            raise ValueError('mapped parameter absent from actual CDF: ' + key)
        values, native_path, digest = load_actual_seed(seed, model, mapping.values(), key)
        fingerprints[native_path] = digest
        # Preserve additional measured numeric CDF properties at their actual
        # value by default. cdf_* conveys no guessed geometry meaning.
        for parameter in sorted(set(values) & set(by_parameter) - set(mapping.values())):
            semantic = 'cdf_' + parameter
            try:
                _numeric(values[parameter], by_parameter[parameter], semantic)
            except ValueError:
                continue
            mapping[semantic] = parameter
        trial_input = seed.get('trials', {})
        if not isinstance(trial_input, dict) or set(trial_input) - mapping.keys():
            raise ValueError('trial parameter has no explicit CDF mapping: ' + key)
        constraints, actual, known, combinations = {}, {}, {}, 1
        for semantic, parameter in mapping.items():
            row = by_parameter[parameter]
            actual[semantic] = _numeric(values[parameter], row, semantic)
            proposed = trial_input.get(semantic, [])
            if not isinstance(proposed, list) or len(proposed) > MAX_TRIAL_VALUES:
                raise ValueError('finite trial list must contain at most 5 values: ' + semantic)
            # Seed first is part of the native-trial contract: existing C++
            # initializers use discrete_values.front(). Bounds remain sorted.
            trials = [actual[semantic]] + sorted(set(_numeric(v, row, semantic) for v in proposed) - {actual[semantic]})
            if len(trials) > MAX_TRIAL_VALUES:
                raise ValueError('finite trial list including actual seed exceeds 5 values: ' + semantic)
            known[semantic] = _known_bounds(trials, row, semantic, rule.get('constraints', {}).get(semantic, {}))
            combinations *= len(trials)
            if combinations > MAX_TRIAL_COMBINATIONS:
                raise ValueError('finite trial combinations exceed 16 per master: ' + key)
            constraints[semantic] = dict(min=min(trials), max=max(trials), grid=0, allowed=trials)
        if kind == 'resistor':
            adequate = 'resistance' in constraints
        else:
            adequate = 'length' in constraints and bool({'width', 'total_width', 'fin', 'fins'} & constraints.keys())
        if not adequate:
            raise ValueError('actual mapped geometry seed incomplete: ' + key)
        missing = ['parameter_domain_unverified']
        dev = dict(cell=identity['oa_cell'], oa_library=identity['oa_library'], model=model, kind=kind,
            normalized_to_cdf=mapping, constraints=constraints, native_parameter_trials=True,
            parameter_domain_verified=False, native_trial_combinations=combinations,
            actual_parameter_seed=actual, actual_seed_instance=seed['instance'], actual_seed_source=native_path,
            known_parameter_bounds=known, source=source, rules_source=source,
            cdf_source=str(Path(probe_path).resolve()) + '; actual seed: ' + native_path + '; finite trials, not proven legal domain',
            electrical_rules=rule, sim_cdf=rule.get('sim_cdf', {}),
            dc_signals=rule.get('dc_signals', {'id': 'id', 'vth': 'vth', 'vdsat': 'vdsat', 'cgg': 'cgg', 'vbs': 'vbs'}),
            signal_postfix=rule.get('signal_postfix', ''), missing=missing)
        for name in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'bulkRule', 'voltageDomains', 'terminalRoles',
                     'wFinFormula', 'maxStackLevel', 'sourceDrainInterchangeable'):
            if name in rule:
                dev[name] = finite(rule[name], True) if name.startswith('maxAbs') else rule[name]
        if 'maxStackLevel' in dev:
            maximum = finite(dev['maxStackLevel'], True)
            if maximum != int(maximum) or maximum > 2147483647:
                raise ValueError('PDK maxStackLevel must be a positive integer: ' + key)
            dev['maxStackLevel'] = int(maximum)
        if 'sourceDrainInterchangeable' in dev and not isinstance(dev['sourceDrainInterchangeable'], bool):
            raise ValueError('PDK sourceDrainInterchangeable must be boolean: ' + key)
        if kind != 'resistor' and not all(k in dev for k in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb')):
            missing.append('reliability')
        if not dev.get('voltageDomains'):
            missing.append('voltage_domain')
        devices.append(dev)
    payload = dict(roots=roots, sources=fingerprints, rules=rules, profile=profile)
    version = hashlib.sha256(json.dumps(payload, sort_keys=True, allow_nan=False).encode()).hexdigest()
    return dict(tech_name=pdk_name or Path(roots[0]).name, pdk_name=pdk_name or Path(roots[0]).name,
        pdk_paths=roots, pdk_alias_paths=aliases, version='experimental-sha256:' + version,
        source=str(Path(probe_path).resolve()), validation_scope='experimental_dc', native_parameter_trials=True,
        parameter_domain_verified=False, reliability_verified=False,
        corners=[dict(name=n, sections=c['models']) for n, c in profile.get('op_corners', {}).items()],
        temperatures=[], devices=devices, model_file_sha256={}, source_file_sha256=fingerprints,
        rejected_devices=[], unreadable_model_files=[],
        non_target_devices=preserved_primitives(groups, set(seeds), str(Path(probe_path).resolve())),
        model_internal_scan_performed=False)


def native_trial_text(value):
    """Match C++ FormatAutoBiasParameter so callbacks see production literals."""
    if value == 0: return '0'
    number=format(value,'.6g'); suffix=''; scale=1
    for multiplier,suffix in ((1e9,'g'),(1e6,'meg'),(1e3,'k'),(1,''),
                              (1e-3,'m'),(1e-6,'u'),(1e-9,'n'),(1e-12,'p')):
        if abs(value) >= multiplier*0.9995:
            number=format(value/multiplier,'.6g')
            scale=multiplier
            break
    else: suffix=''
    if float(number)*scale == value: return number+suffix
    return format(value,'.17g')


def native_resistor_trials(work, manifest, output, device, columns):
    """One native session, the production CDF adapter, no Spectre or source save."""
    from collect_cascode_batch import command, executable
    from read_maestro_setup import read_records, MARKER
    from standalone import environment
    config = dict(line.split('=', 1) for line in (Path(work)/'session.conf').read_text().splitlines()
                  if '=' in line and not line.startswith('#'))
    cds = Path(config['cds_lib']).resolve()
    if not cds.is_file():
        raise ValueError('resistor PDK check requires the existing session cds.lib')
    folder = Path(output)/'resistor_pdk_check'
    folder.mkdir()
    env = environment(manifest, Path(work)/'analysis/standalone_inputs/provider_inputs.json')
    env.setdefault('ST_SKILL_INIT', str(Path(__file__).resolve().parents[1]/'skill/init.il'))
    env.pop('ST_PREPARED_JSON_FILE', None)
    q = json.dumps
    params = []
    for i in range(len(next(iter(columns.values())))):
        # C++ emits std::map order. Probe the same order, with fresh defaults.
        values = ' '.join('list(list("name" '+q(name)+') list("value" '+
                          q(native_trial_text(columns[name][i]))+'))' for name in sorted(columns))
        params.append('list('+q(str(i+1))+' list('+values+'))')
    script = r'''load(getShellEnvVar("ST_SKILL_INIT"))
load(strcat(getShellEnvVar("ST_ENGINE_ROOT") "/server/skill/backend_common.il"))
load(strcat(getShellEnvVar("ST_ENGINE_ROOT") "/server/skill/pdk_adapter.il"))
load(strcat(getShellEnvVar("ST_ENGINE_ROOT") "/skill/standalone_topology_variant.il"))
procedure(stResRecord(port kind scope name value)
  when(numberp(value) value=sprintf(nil "%.17g" value*1.0))
  fprintf(port "ST_MAE_RECORD\t%s\t%L\t%L\tOK\t%L\n" kind scope name value)
)
let((port cv master inst point scope values result allResult cdf param item name choice idx)
  allResult=errset(prog( ()
    port=outfile(__REPORT__)
    unless(port error("Cannot write resistor PDK result"))
    master=dbOpenCellViewByType(__LIB__ __CELL__ "symbol" "" "r")
    unless(master error("Selected resistor symbol unavailable"))
    cv=dbOpenCellViewByType(__STAGING__ __SCRATCH__ "schematic" "schematic" "w")
    unless(cv error("Cannot open resistor parameter check cell"))
    foreach(point list(__POINTS__)
      scope=car(point) values=cadr(point)
      inst=dbCreateInst(cv master "R_CHECK" 0:0 "R0" 1)
      unless(inst error("Cannot create selected resistor"))
      result=errset(maauTvSetCdf(inst values) t)
      stResRecord(port "r_status" scope "apply" if(result then "OK" else "REJECTED"))
      when(result
        cdf=cdfGetInstCDF(inst)
        foreach(item values
          name=cadr(assoc("name" item))
          param=get(cdf concat(name))
          stResRecord(port "r_value" scope name if(param then param->value else nil))
          when(param
            stResRecord(port "r_min" scope name param~>minVal)
            stResRecord(port "r_max" scope name param~>maxVal)
            stResRecord(port "r_callback" scope name param~>callback)
            idx=0
            when(listp(param~>choices)
              foreach(choice param~>choices
                stResRecord(port "r_choice" scope strcat(name ":" sprintf(nil "%d" idx)) choice)
                idx=idx+1))
          )
        )
      )
      dbDeleteObject(inst)
    )
    fprintf(port "__MARKER__\n")
    close(port) port=nil
    dbClose(cv) cv=nil
    dbClose(master) master=nil
    return(t)
  ) t)
  when(port close(port))
  when(cv dbClose(cv))
  when(master dbClose(master))
  if(and(allResult car(allResult)) then exit(0) else exit(70))
)
'''
    replacements = dict(REPORT=str(folder/'native.tsv'), LIB=device['oa_library'], CELL=device['cell'],
                        STAGING=config['variant_library']+'__STAGING',
                        SCRATCH='resistor_check_'+Path(output).name)
    for key, value in replacements.items(): script=script.replace('__'+key+'__', q(value))
    script=script.replace('__POINTS__', '\n'.join(params)).replace('__MARKER__', MARKER)
    action=folder/'check.il';action.write_text(script)
    print('RESISTOR_PDK_CHECK=START\nRESISTOR_PDK_PROPOSED_POINTS='+str(len(params)),flush=True)
    print('RESISTOR_PDK_LOG='+str(folder/'virtuoso.log'),flush=True)
    # Match materialize_runner: same executable, project cwd and site startup.
    try:
        command([executable(env,'ST_VIRTUOSO_BIN','virtuoso'),'-nograph','-replay',str(action),
                 '-log',str(folder/'virtuoso.log')],cds.parent,env,600,folder/'process.log')
    except ValueError as error:
        detail=[]
        for path in (folder/'virtuoso.log',folder/'process.log'):
            if path.is_file():
                detail.extend(line for line in path.read_text(errors='replace').splitlines()
                              if '*Error*' in line or 'ERROR' in line or 'not loaded' in line)
        raise ValueError('resistor native PDK check failed: '+str(error)+' '+
                         ' | '.join(detail[-3:])[:1200]) from error
    return read_records((folder/'native.tsv').read_text())


def accepted_resistor_trials(device, columns, bounds, records):
    """Admit only individually checked points, not an inferred continuous range."""
    def decode(text):
        if text == 'nil': return None
        try: return json.loads(text)
        except ValueError: return text
    data = {}
    for row in records:
        key=(row['kind'],row['name'])
        point=data.setdefault(row['scope'],{})
        if row['status'] != 'OK' or key in point:
            raise ValueError('resistor PDK report duplicate/failed record: '+str(key))
        point[key]=decode(row['raw_value'])
    accepted, rejected = [], []
    seed={name:device['actual_parameter_seed'][key]
          for key,name in device['normalized_to_cdf'].items() if key in device['actual_parameter_seed']}
    for i in range(len(next(iter(columns.values())))):
        scope=str(i+1)
        point=data.get(scope,{})
        def field(kind, name):
            key=(kind,name)
            if key not in point: raise ValueError('resistor PDK report incomplete: '+scope+'/'+str(key))
            return point[key]
        status=field('r_status','apply')
        if status not in ('OK','REJECTED'): raise ValueError('unknown native resistor check status')
        if status == 'REJECTED':
            rejected.append(dict(point=i+1,reason='PDK callback rejected parameters'));continue
        reasons=[]
        changed=[]; covered=set(); callbacks=set()
        for name, values in columns.items():
            row,semantic,declared=bounds[name]
            actual=field('r_value',name)
            minimum=field('r_min',name);maximum=field('r_max',name)
            callback=field('r_callback',name)
            if isinstance(callback,str) and callback.strip():callbacks.add(name)
            choices=[v for (kind,key),v in point.items()
                     if kind=='r_choice' and key.startswith(name+':')]
            current=dict(row,min=minimum,max=maximum,choices=','.join(str(v) for v in choices))
            try:
                number=_numeric(actual,row,semantic)
                if not math.isclose(number,values[i],rel_tol=1e-12,abs_tol=0):
                    reasons.append(name+' requested='+format(values[i],'.17g')+' actual='+str(actual))
                # Do not let an unreadable enum count as a proven numeric set.
                for choice in choices: _numeric(choice,row,semantic)
                explicit=_known_bounds([number],row,semantic,declared)
                explicit+=_known_bounds([number],current,semantic,declared)
                if choices or declared.get('allowed') or {b['field'] for b in explicit}=={'min','max'}:
                    covered.add(name)
            except (ValueError,TypeError) as error:
                reasons.append(name+': '+str(error))
            if name not in seed or not math.isclose(values[i],seed[name],rel_tol=1e-12,abs_tol=0):
                changed.append(name)
        # For the proven fixed-shape series recipe, segment count is the one
        # independent control; r and total L are coupled outputs, all checked
        # above. An unrelated m/presentation callback is NOT a count rule.
        if device.get('model') == 'rhrpo_2t_ckt' or device.get('cell') == 'rhrpo_2t_ckt':
            required={n for n in changed if n.lower() not in ('r','cktl')}
            required.update(n for n in columns if n.lower()=='segments')
        else:
            required=set(changed) or {device['normalized_to_cdf']['resistance']}
        unknown=required-covered-callbacks
        if unknown:
            reasons.append('no native PDK adjustment rule for '+','.join(sorted(unknown)))
        if reasons:rejected.append(dict(point=i+1,reason='; '.join(reasons)))
        else:accepted.append(i)
    return accepted,rejected


def resistor_trial_file(work, manifest, output, scales):
    """Finite resistance targets from the measured seed, not new PDK ratings."""
    automatic = scales is None
    scales = [1.0] if automatic else [finite(float(v), True) for v in scales]
    if not 1 <= len(scales) <= 5 or len(set(scales)) != len(scales):
        raise ValueError('reference resistor scales require 1 to 5 distinct positive values')
    profile = read_json(manifest['rules'])
    if profile.get('validation_scope') != 'experimental_dc':
        raise ValueError('reference resistor trials require experimental_dc')
    devices = [d for tech in read_json(manifest['tech']) for d in tech['devices']
               if d.get('kind') == 'resistor' and d.get('native_parameter_trials')]
    if len(devices) != 1:
        raise ValueError('reference resistor trials require one selected native resistor master')
    dev = devices[0]
    cdf = dev['normalized_to_cdf']['resistance']
    seed = finite(dev['actual_parameter_seed']['resistance'], True)
    if automatic:
        # Finite search proposals, not an inferred PDK legal range.
        scales = [1.0] + [2**(i/16) for i in range(-80,81) if i != 0]
    values = [finite(seed*s, True) for s in scales]
    mapping = dev['normalized_to_cdf']
    seeds = dev['actual_parameter_seed']
    # This native resistor is netlisted by geometry (lr/wr), not its r label.
    # Keep the already-used segment shape and scale the series segment count.
    columns = {cdf: values}
    geometry = None
    if dev.get('model') == 'rhrpo_2t_ckt' or dev['cell'] == 'rhrpo_2t_ckt':
        names = {name.lower(): (key, name) for key, name in mapping.items() if key in seeds}
        required = ('segments', 'cktl', 'cktw', 'segl', 'segw', 'm')
        if any(k not in names for k in required):
            raise ValueError('reference resistor actual segment geometry missing: '+
                             ','.join(k for k in required if k not in names))
        shape = {k:finite(seeds[names[k][0]], True) for k in required}
        if (shape['segments'] != round(shape['segments']) or
                not math.isclose(shape['cktl'],shape['segments']*shape['segl'],rel_tol=1e-8) or
                not math.isclose(shape['cktw'],shape['segw'],rel_tol=1e-8)):
            raise ValueError('reference resistor seed is not the supported equal-width series geometry')
        if automatic:
            count = int(shape['segments'])
            counts = [count] + [n for n in range(max(1, math.ceil(count/32)),
                       min(4096, count*32)+1) if n != count]
            scales = [n/count for n in counts]
            columns[cdf] = [finite(seed*s, True) for s in scales]
        counts = [shape['segments']*v for v in scales]
        if any(not math.isclose(n,round(n),rel_tol=0,abs_tol=1e-8) for n in counts):
            raise ValueError('reference resistor scales must yield whole series segment counts')
        counts = [int(round(n)) for n in counts]
        for key, name in mapping.items():
            if key in seeds and name != cdf:
                columns[name] = [finite(seeds[key])]*len(scales)
        columns[names['segments'][1]] = counts
        columns[names['cktl'][1]] = [shape['segl']*n for n in counts]
        geometry = dict(segment_counts=counts,segment_length=shape['segl'],segment_width=shape['segw'])
    with Path(profile['experimental_pdk_cache']['probe']).open() as stream:
        rows = [r for r in csv.DictReader(stream,delimiter='\t')
                if r['oa_library']==dev['oa_library'] and r['oa_cell']==dev['cell']]
    bounds = {}
    for name, proposed in columns.items():
        matched = [r for r in rows if r['parameter']==name]
        semantic = next(k for k,v in mapping.items() if v==name)
        if len(matched) != 1:
            raise ValueError('selected resistor CDF declaration missing/ambiguous: '+name)
        declared = dev.get('electrical_rules',{}).get('constraints',{}).get(semantic,{})
        bounds[name] = (matched[0],semantic,declared)
        if not automatic:
            _known_bounds(proposed, *bounds[name])
    if automatic:
        accepted = []
        for i in range(len(columns[cdf])):
            try:
                for name, proposed in columns.items():
                    _known_bounds([proposed[i]], *bounds[name])
            except ValueError:
                continue
            accepted.append(i)
        if not accepted:
            raise ValueError('no reference resistor proposals within known CDF bounds')
        columns = {name:[vals[i] for i in accepted] for name,vals in columns.items()}
    with (Path(work)/'before/device_catalog.tsv').open() as stream:
        masters = [r for r in csv.DictReader(stream,delimiter='\t')
                   if r['oa_library']==dev['oa_library'] and r['oa_cell']==dev['cell'] and r['kind']=='resistor']
    if len(masters)!=1 or masters[0]['native_parameter_trials']!='true':
        raise ValueError('selected resistor differs from confirmed native catalog')
    master = masters[0]['master']
    records = native_resistor_trials(work,manifest,output,dev,columns)
    admitted,rejected = accepted_resistor_trials(dev,columns,bounds,records)
    report = dict(scope='selected_resistor_cdf_parameters', method='explicit_bounds_and_native_callbacks',
                  proposed_count=len(next(iter(columns.values()))), accepted_count=len(admitted),
                  rejected=rejected, complete_pdk_domain_proven=False,
                  accepted_points=[{k:v[i] for k,v in columns.items()} for i in admitted])
    (Path(output)/'resistor_pdk_check.json').write_text(json.dumps(report,indent=2)+'\n')
    print('RESISTOR_PDK_ACCEPTED_POINTS='+str(len(admitted))+
          '\nRESISTOR_PDK_REJECTED_POINTS='+str(len(rejected)),flush=True)
    if not admitted:
        raise ValueError('selected resistor has no PDK-accepted adjustment points; '+
                         (rejected[0]['reason'] if rejected else 'native report empty'))
    columns = {name:[values[i] for i in admitted] for name,values in columns.items()}
    print('RESISTOR_PDK_CHECK=PASS\nRESISTOR_SEARCH_SET=PDK_ACCEPTED_DISCRETE_POINTS',flush=True)
    print('RESISTOR_ACCEPTED_RANGE_OHMS='+str(min(columns[cdf]))+','+str(max(columns[cdf])),flush=True)
    if automatic:
        print('AUTO_VBIAS_SEARCH=true\nAUTO_VBIAS_MAX_DC_EVALUATIONS=16',flush=True)
        print('AUTO_RESISTOR_CANDIDATES='+str(len(admitted))+
              '\nAUTO_RESISTOR_RANGE_OHMS='+str(min(columns[cdf]))+','+str(max(columns[cdf])),flush=True)
    if geometry:
        geometry['segment_counts']=[int(n) for n in columns[names['segments'][1]]]
    path = Path(output)/'reference_resistor_trials.tsv'
    path.write_text(''.join(master+'\t'+name+'\t'+','.join(format(v,'.17g') for v in vals)+'\n'
                            for name,vals in columns.items()))
    if not automatic: print('REFERENCE_RESISTOR_TRIALS='+json.dumps(dict(master=master,cdf=cdf,seed_ohms=seed,
          values_ohms=columns[cdf],geometry=geometry,known_bounds_checked=True,native_pdk_checked=True),sort_keys=True),flush=True)
    return path
