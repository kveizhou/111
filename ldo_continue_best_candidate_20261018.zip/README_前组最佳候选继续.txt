前序最佳候选继续执行（2026-10-18）

适用：已安装ldo_combined_alternate_targets_20261018.zip的当前服务器版本。
本包修改C++，需要重新编译。上传到st-engine-maau同级目录后整行执行：

unzip -o ldo_continue_best_candidate_20261018.zip && bash st-engine-maau/scripts/build.sh --tool-only && bash st-engine-maau/scripts/test_mixed_cascode.sh combo-alt "$st_batch/candidate_I21_xbb892w0"

顺序仍是I105电阻后撤销、I29同型、I85异型、I21两级Stack，最后生成并核对。
每组Cascode最多16次：本组满足就停止，否则选择已有规则排名最好的有效收敛点。
前组所选电路和参数保留，后组不再因前组未达标而停止；前组电气检查延后到最终整图。
不用手填阻值。本命令会重新执行搜索，不是从上次第32点恢复。

关键预期（当两组仍未达标但有有效候选时）：
VBIAS_OPERATION=END operation=op_I29 result=best_effort evaluations=16
VBIAS_OPERATION=START operation=op_I85 target=I85 retained_groups=1
VBIAS_CUMULATIVE_CHECK operation=op_I85 previous_groups=1 result=DEFERRED_TO_FINAL
VBIAS_OPERATION=END operation=op_I85 result=best_effort evaluations=16
STAGE=generate COMPLETE ...
RESULT=OPTIMIZATION_CANDIDATE_READY
OPTIMIZATION_CANDIDATE_READY=true
RESULT_CELL=实际生成的库/Cell/schematic
UNMET_REQUIREMENTS=最终实测未满足项
COMBINED_STRUCTURE_TEST=PASS
COMBINED_DC_TEST=NOT_PASSED

DEFERRED_TO_FINAL表示不作为后组搜索门槛，不表示前组电气通过。首组没有前组，显示NOT_APPLICABLE。
如果最终全部电气条件通过，结果为EXPERIMENT_DC_PASS，COMBINED_DC_TEST=PASS。
最终仍未满足电气条件时，组合测试可以返回2/INCOMPLETE，但若RESULT=OPTIMIZATION_CANDIDATE_READY且有RESULT_CELL，表示待优化电路已生成，不是生成中断。
执行/读取/实际回读错误，以及无有效收敛候选仍会停止，不用缺失或不合法数据制造可用结果。

只复查最近结果（不重跑DC）：
bash st-engine-maau/scripts/test_mixed_cascode.sh combo-check "$st_batch/candidate_I21_xbb892w0"

本地DcSolver 120项、CliWorkflow 186项及43项Python测试通过，工具编译通过；含后端替身，不代表服务器电气已经通过。
只需回传末尾RESULT、RESULT_CELL、COMBINED_*、UNMET_REQUIREMENTS；提前中断则回传首条实际错误。
