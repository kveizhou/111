#include "CliGenerate.h"
#include "st/JsonWriter.h"
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace st::standalone::detail {

namespace {

std::string stageName(MaterializationStage stage)
{
    switch (stage) {
    case MaterializationStage::ValidatePlan: return "validate_plan";
    case MaterializationStage::CopyCircuit: return "copy_circuit";
    case MaterializationStage::WritePlan: return "write_plan";
    case MaterializationStage::ExecuteSkill: return "execute_skill";
    case MaterializationStage::NominalDcCheck: return "nominal_dc_check";
    case MaterializationStage::PvtCheck: return "pvt_check";
    case MaterializationStage::VerifySource: return "verify_source";
    case MaterializationStage::RegenerateNetlist: return "regenerate_netlist";
    case MaterializationStage::VerifyRoundTrip: return "verify_roundtrip";
    case MaterializationStage::PublishTarget: return "publish_target";
    case MaterializationStage::Complete: return "complete";
    }
    return "unknown";
}

} // namespace

int GenerateContext::GenerateLoadAndValidate()
{
    if (!loadManifest(root, manifest, message)) { error << message << '\n'; return 2; }
    if (!loadNetlist(root / "before/core_before.scs", baseline, message) ||
        !loadCatalog(root, catalog, message, manifest.validation_scope == "experimental_dc")) {
        error << message << '\n'; return 4;
    }
    ChangeSet validated;
    if (!loadChangeRequests(root, manifest, requests, validated, message)) {
        error << message << '\n'; return 4;
    }
    if (requests.empty()) { error << "Change Set为空，不能生成派生电路\n"; return 4; }
    structureOnly = manifest.validation_scope == "structure_only";
    experimentalDc = manifest.validation_scope == "experimental_dc";
    if (!structureOnly && (manifest.bench_library.empty() || manifest.bench_cell.empty() ||
        manifest.bench_view.empty() || manifest.bench_hash.empty())) {
        error << "generate缺少真实Bench L/C/V：发现会话只能查看MOS清单，"
                 "请取得Case映射后重新inspect\n";
        return 4;
    }
    if (std::any_of(requests.begin(), requests.end(), needsBiasSolve) &&
        (manifest.vbias_vhigh_net.empty() || manifest.vbias_vlow_net.empty())) {
        error << "Cascode求解缺少VBIAS高低轨网：请取得Case轨网后重新inspect\n";
        return 4;
    }
    hasBiasOperation =
        std::any_of(requests.begin(), requests.end(), needsBiasSolve);
    if (manifest.validation_scope != "experimental_dc" && (!manifest.max_branch_current_error.empty() ||
        !manifest.max_vbias_current.empty())) {
        double branch = 0.0;
        double bias = 0.0;
        if (!positiveLimit(manifest.max_branch_current_error, false, branch) ||
            !positiveLimit(manifest.max_vbias_current, true, bias)) {
            error << "电流上限选填；填写时 --max-branch-current-error 与"
                     " --max-vbias-current 必须成对提供且为正数\n";
            return 4;
        }
        maxBranchCurrentError = branch;
        maxVbiasCurrent = bias;
    }
    currentLimitsApplied = !experimentalDc && hasBiasOperation &&
        maxBranchCurrentError.has_value() && maxVbiasCurrent.has_value();

    paths = BackendPaths{manifest.cds_lib, root / "after/source_roundtrip.scs",
                       root / "after/core_roundtrip.scs", root / "logs",
                       manifest.core_subckt};
    paths.device_policy = root / "analysis/device_policy.tsv";
    paths.structure_only = structureOnly;
    paths.experimental_dc = experimentalDc;
    backend = std::make_unique<ProcessVirtuosoBackend>(manifest.backend, paths, runner);
    source = CellViewRef{manifest.source_library, manifest.source_cell,
                             manifest.source_view, manifest.source_storage, {}};
    bench = CellViewRef{manifest.bench_library, manifest.bench_cell,
                            manifest.bench_view, manifest.source_storage, {}};
    return 0;
}

int GenerateContext::GenerateRescanPdk()
{
    // ---- 1) PDK重扫：版本和内容身份均一致后才允许求解 ----
    for (unsigned number = 1; number <= 9999; ++number) {
        std::ostringstream name;
        name << "run_" << std::setw(4) << std::setfill('0') << number;
        const auto candidate = root / "analysis/pdk_scan" / name.str();
        std::error_code directoryError;
        if (std::filesystem::create_directory(candidate, directoryError)) {
            scanDirectory = candidate;
            break;
        }
        if (directoryError &&
            directoryError != std::errc::file_exists) {
            error << "无法创建PDK扫描归档目录：" << directoryError.message() << '\n';
            return 2;
        }
    }
    if (scanDirectory.empty()) {
        error << "PDK扫描归档目录编号已用尽\n";
        return 2;
    }
    const PdkScanOutputs scanOutputs{scanDirectory / "raw_catalog.tsv",
                                     scanDirectory / "pdk_identity.tsv"};
    auto status = backend->ScanPdk(source, scanOutputs);
    if (!status.ok) {
        std::error_code logError;
        if (!status.log_path.empty() &&
            std::filesystem::exists(status.log_path, logError) && !logError) {
            std::string archiveMessage;
            archiveScanLog(status, scanDirectory, archiveMessage);
        }
        error << "PDK重扫失败：" << status.message << "\n日志：" << status.log_path << '\n';
        return 3;
    }
    if (!archiveScanLog(status, scanDirectory, message)) {
        error << message << '\n'; return 3;
    }
    DeviceCatalog scanned;
    {
        std::vector<Diagnostic> diagnostics;
        if (!LoadDeviceCatalogTsv(scanOutputs.raw_catalog_tsv, scanned, diagnostics)) {
            error << "PDK重扫目录读取失败：" <<
                (diagnostics.empty() ? std::string("unknown") : diagnostics.front().message)
                  << '\n';
            return 4;
        }
    }
    if (scanned.Descriptors().empty() ||
        scanned.Descriptors().begin()->second.pdk_version != manifest.pdk_version) {
        error << "PDK版本与建会话时不一致（期望 " << manifest.pdk_version
              << "），拒绝继续生成\n";
        return 4;
    }
    std::string beforeHash;
    std::string scannedHash;
    if (!catalogHash(root / "before/device_catalog.tsv", beforeHash, message) ||
        !catalogHash(scanOutputs.raw_catalog_tsv, scannedHash, message)) {
        error << message << '\n'; return 4;
    }
    if (beforeHash != manifest.catalog_hash || scannedHash != manifest.catalog_hash) {
        error << "PDK目录内容与建会话时不一致，请重新inspect和confirm\n";
        return 4;
    }
    catalog = std::move(scanned);
    const auto resistorTrials = optional(options, "experimental-resistor-trials");
    if (!resistorTrials.empty() && (!experimentalDc || !hasBiasOperation ||
        !applyResistorTrials(resistorTrials, catalog, output, message,
            optional(options,"experimental-resistor-auto") == "true"))) {
        error << "参考电阻试点仅适用于experimental_dc Cascode：" << message << '\n';
        return 4;
    }
    nativeParameterTrials = std::any_of(catalog.Descriptors().begin(),
        catalog.Descriptors().end(), [](const auto& entry) { return entry.second.native_parameter_trials; });
    backend->UseOperatingPointCatalog(scanOutputs.raw_catalog_tsv);
    if (!writeScannedDevicePolicy(catalog, paths.device_policy, message)) {
        error << message << '\n'; return 4;
    }
    return 0;
}

int GenerateContext::GenerateBaselineOp()
{
    // ---- 2) 基线直流工作点：身份一致才复用，否则重跑 ----
    HostStatus status;
    nominalIdentity = AnalysisIdentity{manifest.dut_hash, manifest.bench_hash,
        manifest.pdk_version, manifest.nominal_corner,
        ComputeNetlistTopologyHash(baseline), ComputeNetlistParameterHash(baseline),
        experimentalDc ? "st-dc-solver-v3-experimental_dc" : "st-dc-solver-v2-intrinsic"};
    if (!structureOnly) {
    const auto baselineDir = root / "analysis/baseline_op";
    bool baselineReused = false;
    {
        std::vector<Diagnostic> diagnostics;
        if (LoadOperatingPointTsv(baselineDir, baselineOp, diagnostics) &&
            IsReusable(baselineOp, nominalIdentity) &&
            std::all_of(requests.begin(), requests.end(), [&](const auto& request) {
                return !needsBiasSolve(request) ||
                    baselineOp.mos.count(request.target.instance) != 0;
            })) {
            baselineReused = true;
        }
    }
    if (!baselineReused) {
        const OperatingPointOutputs outputs{baselineDir / "identity.tsv",
                                            baselineDir / "mos.tsv"};
        status = backend->RunOperatingPoint(source, bench, nominalIdentity, outputs);
        if (!status.ok) {
            error << "基线直流工作点失败：" << status.message
                  << "\n日志：" << status.log_path << '\n';
            return 3;
        }
        std::vector<Diagnostic> diagnostics;
        if (!LoadOperatingPointTsv(baselineDir, baselineOp, diagnostics) ||
            !IsReusable(baselineOp, nominalIdentity)) {
            error << "基线直流工作点身份与声明不一致\n";
            return 4;
        }
    }
    {
        std::string json = std::string("{\"validation_scope\":\"") + manifest.validation_scope +
            "\",\"dut_hash\":\"" + manifest.dut_hash +
            "\",\"bench_hash\":\"" + manifest.bench_hash + "\",\"pdk_version\":\"" +
            jsonEscape(manifest.pdk_version) + "\",\"corner\":\"" +
            jsonEscape(manifest.nominal_corner) + "\",\"total_supply_current\":" +
            (baselineOp.total_supply_current ? formatNumber(*baselineOp.total_supply_current) : "null") + ",\"reused\":" +
            (baselineReused ? "true" : "false") + "}\n";
        if (!writeAtomic(root / "analysis/baseline_op.json", json, message)) {
            error << message << '\n'; return 2;
        }
    }

    }
    return 0;
}

int GenerateContext::GeneratePlan()
{
    // ---- 4) 全部求解成功后重放、封装、出OA计划 ----
    ChangeSet solvedChanges;
    for (const auto& request : solvedRequests) {
        Diagnostic diagnostic;
        if (!solvedChanges.Confirm(request, diagnostic)) {
            error << diagnostic.message << '\n'; return 4;
        }
    }
    Netlist expected;
    ReplayResult replay = solvedChanges.Generate(baseline, expected, catalog);
    if (!replay.ok) {
        error << (replay.diagnostics.empty() ? "求解后重放失败" :
                  replay.diagnostics.front().message) << '\n';
        return 4;
    }
    // The existing per-generate scan directory already supplies a unique run
    // number. Use it for the final experimental parent AND generated children,
    // so a previous failed materialization cannot occupy this attempt's names.
    generationRun = experimentalDc ? scanDirectory.filename().string() : "";
    const std::string generationCell = manifest.variant_cell +
        (experimentalDc ? "__GEN_" + generationRun : "");
    packaged = PackageTopologyVariant(
        baseline, expected, manifest.core_subckt, solvedChanges, replay,
        generationCell, manifest.variant_library + "__STAGING");
    if (!packaged.ok()) {
        error << packaged.diagnostics.front().message << '\n'; return 4;
    }
    // 最终电路已封装成父层 wrapper + 功能/VBIAS 子 Cell。把求解阶段的
    // 叶实例角色绑定到对应 wrapper，供最终 Spectre OP 层级名精确解析。
    for (auto& check : electricalChecks) {
        bool actualContainerFound = false;
        bool biasContainerFound = false;
        for (const auto& package : packaged.packages) {
            if (std::find(package.operation_ids.begin(), package.operation_ids.end(),
                          check.operation_id) == package.operation_ids.end()) {
                continue;
            }
            const auto hasMember = [&](const std::string& name) {
                return std::find(package.member_instances.begin(),
                                 package.member_instances.end(), name) !=
                    package.member_instances.end();
            };
            if (hasMember(check.actual_control.leaf_name) &&
                hasMember(check.actual_cascode.leaf_name)) {
                check.actual_control.container_instance =
                    package.parent_instance_name;
                check.actual_cascode.container_instance =
                    package.parent_instance_name;
                actualContainerFound = true;
            }
            if (hasMember(check.mirror_ref.leaf_name) &&
                hasMember(check.mirror_out.leaf_name) &&
                hasMember(check.cascode_replica.leaf_name) &&
                hasMember(check.control_replica.leaf_name) &&
                hasMember(check.resistor.leaf_name)) {
                check.mirror_ref.container_instance = package.parent_instance_name;
                check.mirror_out.container_instance = package.parent_instance_name;
                check.cascode_replica.container_instance =
                    package.parent_instance_name;
                check.control_replica.container_instance =
                    package.parent_instance_name;
                check.resistor.container_instance = package.parent_instance_name;
                biasContainerFound = true;
            }
        }
        if (!actualContainerFound || !biasContainerFound) {
            error << "操作 " << check.operation_id
                  << " 无法把最终电气校验角色绑定到功能/VBIAS封装实例\n";
            return 4;
        }
    }
    std::vector<ExpectedResistor> sourceResistorChecks;
    const Subckt* flatRoot = expected.find(manifest.core_subckt);
    for (std::size_t index = 0; index < solvedRequests.size(); ++index) {
        if (structureOnly || solvedRequests[index].type != TransformType::AddSourceResistor) continue;
        bool found = false;
        for (const auto& name : replay.outcomes[index].addedInstances) {
            const Instance* instance = flatRoot == nullptr ? nullptr : flatRoot->find(name);
            const DeviceDescriptor* descriptor = instance == nullptr
                ? nullptr : catalog.Find(instance->model);
            if (descriptor == nullptr || descriptor->kind != DeviceKind::Resistor) continue;
            for (const auto& package : packaged.packages) {
                if (std::find(package.operation_ids.begin(), package.operation_ids.end(),
                              solvedRequests[index].operation_id) ==
                        package.operation_ids.end() ||
                    std::find(package.member_instances.begin(),
                              package.member_instances.end(), name) ==
                        package.member_instances.end()) continue;
                sourceResistorChecks.push_back({solvedRequests[index].operation_id,
                    package.parent_instance_name, name, instance->model, experimentalDc});
                found = true;
                break;
            }
        }
        if (!found) {
            error << "操作 " << solvedRequests[index].operation_id
                  << " 无法绑定最终Source电阻实例的应力门禁\n";
            return 4;
        }
    }
    expected = packaged.netlist;
    if (!writeAtomic(root / "expected/core_expected.scs", emitSpectre(expected), message)) {
        error << message << '\n'; return 2;
    }

    staging = CellViewRef{manifest.variant_library + "__STAGING",
        generationCell + "__STAGING", "schematic", manifest.source_storage, {}};
    const CellViewRef target{manifest.variant_library, manifest.variant_cell,
                             "schematic", manifest.source_storage, {}};
    const PreviewIdentity preview{manifest.variant_id, "initial", "standalone-v2-packaged"};
    auto context = BuildRootOaContext(
        baseline, expected, manifest.core_subckt, source, staging, geometry, preview);
    if (!context.ok) { error << context.diagnostics.front().message << '\n'; return 4; }
    context.context.structure_only = structureOnly;
    const auto builtPlan = BuildPackagedOaMaterializationPlan(
        baseline, packaged, catalog, context.context, staging.library);
    if (!builtPlan.ok()) {
        error << builtPlan.diagnostics.front().message << '\n'; return 4;
    }

    ConfigureGenerationRequest(builtPlan.plan, replay, expected, sourceResistorChecks, target);
    return 0;
}

void GenerateContext::ConfigureGenerationRequest(const OaMaterializationPlan& plan,
        const ReplayResult& replay, const Netlist& expected,
        const std::vector<ExpectedResistor>& sourceResistorChecks, const CellViewRef& target)
{
    auto& request = generationRequest;
    request.plan = plan;
    request.baseline = baseline;
    request.expected_variant = expected;
    request.root_subckt = manifest.core_subckt;
    request.work_dir = root.string();
    request.plan_path = (root / "materialization/plan.json").string();
    request.skill_script_path = manifest.skill_script.string();
    request.publish_clone_map.push_back({staging, target, "/"});
    for (const auto& cell : request.plan.generated_cells) {
        auto finalSchematic = cell.schematic;
        auto finalSymbol = cell.symbol;
        finalSchematic.library = target.library;
        finalSymbol.library = target.library;
        request.publish_clone_map.push_back({cell.schematic, finalSchematic,
                                            "@" + cell.package_id + "/schematic"});
        request.publish_clone_map.push_back({cell.symbol, finalSymbol,
                                            "@" + cell.package_id + "/symbol"});
    }
    request.parameter_groups = replay.parameter_groups;
    request.iq_delta = replay.iq_delta;
    // 名义DC检查：对staging变体验明工作点身份，dut_hash必须是staging的哈希。
    request.run_nominal_dc = !structureOnly;
    request.structure_only = structureOnly;
    request.experimental_dc = experimentalDc;
    request.bench = bench;
    request.nominal_corner = manifest.nominal_corner;
    request.nominal_identity = AnalysisIdentity{
        CellViewIdentityHash(staging.library, staging.cell, staging.view,
                             staging.storage_path),
        manifest.bench_hash, manifest.pdk_version, manifest.nominal_corner,
        ComputeNetlistTopologyHash(expected), ComputeNetlistParameterHash(expected),
        experimentalDc ? "st-dc-solver-v3-experimental_dc" : "st-dc-solver-v2-intrinsic"};
    request.nominal_op_dir = (root / "analysis/variant_op").string();
    request.electrical_checks = electricalChecks;
    request.retain_electrical_candidate = experimentalDc && !electricalChecks.empty();
    request.resistor_checks = sourceResistorChecks;
    if (experimentalDc) {
        for (const auto& package : packaged.packages) {
            for (const auto& instance : package.circuit.instances) {
                const auto* descriptor = catalog.Find(instance.model);
                if (descriptor == nullptr) continue;
                const auto prefix = package.parent_instance_name + "/" + instance.name + "/";
                if (descriptor->native_parameter_trials)
                    request.unverified_constraints.push_back(prefix + "parameter_domain");
                if (descriptor->voltage_domain.empty() && descriptor->allowed_voltage_domains.empty())
                    request.unverified_constraints.push_back(prefix + "voltage_domain");
                if (!isMosKind(descriptor->kind)) continue;
                request.experimental_mos_checks.push_back({package.parent_instance_name,
                    instance.name, descriptor->limits, descriptor->reliability_complete});
            }
        }
    }
    request.parameters_quantized = !structureOnly && !experimentalDc;
    // 候选阶段的PVT用于提前淘汰/诊断，但最终门禁必须重新仿真同一个
    // staging CellView；不能把候选结论直接当作最终电路结论。
    request.pvt_configured = pvtConfigured;
    for (const auto& corner : (pvtConfigured ? splitCommaList(manifest.pvt_corners) : std::vector<std::string>{})) {
        if (corner == manifest.nominal_corner) continue;
        auto identity = request.nominal_identity;
        identity.corner = corner;
        request.pvt_checks.push_back({
            corner, identity,
            (root / "analysis/variant_pvt" / corner).string()});
    }
}

int GenerateContext::GenerateMaterializeAndReport()
{
    auto& request = generationRequest;
    TopologyVariantMaterializer materializer;
    if (experimentalDc) {
        output << "FINAL_OA_GENERATION=" << generationRun << '\n'
               << "FINAL_OA_CELL=" << staging.library << '/' << staging.cell << '/' << staging.view << '\n';
    }
    const auto generated = materializer.Generate(request, *backend);

    std::ostringstream report;
    report << "ok=" << (generated.ok ? "true" : "false") << '\n'
           << "structural_ready=" << (generated.structural_ready ? "true" : "false") << '\n'
           << "nominal_dc_ready=" << (generated.nominal_dc_ready ? "true" : "false") << '\n'
           << "pvt_ready=" << (generated.pvt_ready ? "true" : "false") << '\n'
           << "parameters_quantized=" << (generated.parameters_quantized ? "true" : "false")
           << '\n'
           << "ready_for_sizing=" << (generated.ready_for_sizing ? "true" : "false") << '\n'
           << "stage=" << stageName(generated.stage) << '\n'
           << "generation_run=" << generationRun << '\n'
           << "message=" << generated.message << '\n'
           << "source=" << manifest.source_library << '/' << manifest.source_cell << '/'
           << manifest.source_view << '\n'
           << "target=" << generated.target.library << '/' << generated.target.cell << '/' << generated.target.view << '\n'
           << "baseline_netlist=" << (root / "before/core_before.scs").string() << '\n'
           << "expected_netlist=" << (root / "expected/core_expected.scs").string() << '\n'
           << "roundtrip_netlist=" << (root / "after/core_roundtrip.scs").string() << '\n'
           << "source_roundtrip_netlist=" << (root / "after/source_roundtrip.scs").string() << '\n'
           << "plan=" << request.plan_path << '\n'
           << "generated_cells=" << packaged.packages.size() << '\n'
           << "topology_hash=" << generated.topology_hash << '\n'
           << "vbias_branch_current=" << generated.iq_delta << '\n'
           << "validation_scope=" << manifest.validation_scope << '\n'
           << "experimental_dc_ready=" << (generated.experimental_dc_ready ? "true" : "false") << '\n'
           << "optimization_candidate_ready=" << (generated.optimization_candidate_ready ? "true" : "false") << '\n'
           << "experimental_pvt_ready=" << (generated.experimental_pvt_ready ? "true" : "false") << '\n'
           << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
           << "reliability_verified=false\n"
           << "published=" << (generated.ok && !experimentalDc ? "true" : "false") << '\n'
           << "performance_verified=false\n"
           << "current_limits_applied=" << (currentLimitsApplied ? "true" : "false") << '\n'
           << "max_branch_current_error=" << manifest.max_branch_current_error << '\n'
           << "max_vbias_current=" << manifest.max_vbias_current << '\n'
           << "solver_trace=" << (root / "analysis/solver_trace.jsonl").string() << '\n'
           << "resolved_parameters="
           << (root / "analysis/resolved_parameters.json").string() << '\n';
    std::string failedConstraints;
    for (const auto& failed : generated.failed_constraints) {
        if (!failedConstraints.empty()) failedConstraints += ',';
        failedConstraints += failed;
    }
    report << "failed_constraints=" << failedConstraints << '\n';
    for (const auto& unknown : generated.unverified_constraints)
        report << "unverified_constraint=" << unknown << '\n';
    for (const auto& measurement : generated.stress_measurements)
        report << "stress." << measurement.first << '=' << std::setprecision(17) << measurement.second << '\n';
    for (std::size_t index = 0; index < generated.generated_netlist_paths.size(); ++index) {
        report << "generated_roundtrip_netlist_" << index + 1 << '='
               << generated.generated_netlist_paths[index] << '\n';
    }
    if (!writeValidationReport(root, report.str(), message)) {
        error << message << '\n'; return 2;
    }
    if (!generated.ok) {
        error << "生成失败，阶段=" << stageName(generated.stage)
              << "：" << generated.message << "\n日志：" << generated.log_path << '\n';
        return 4;
    }
    output << "validation_scope=" << manifest.validation_scope << '\n'
           << "experimental_dc_ready=" << (generated.experimental_dc_ready ? "true" : "false") << '\n'
           << "optimization_candidate_ready=" << (generated.optimization_candidate_ready ? "true" : "false") << '\n'
           << "experimental_pvt_ready=" << (generated.experimental_pvt_ready ? "true" : "false") << '\n'
           << "native_parameter_trials=" << (nativeParameterTrials ? "true" : "false") << '\n'
           << "reliability_verified=false\n"
           << "published=" << (generated.ok && !experimentalDc ? "true" : "false") << '\n'
           << "performance_verified=false\n"
           << "current_limits_applied=" << (currentLimitsApplied ? "true" : "false") << '\n'
           << "structural_ready=" << (generated.structural_ready ? "true" : "false") << '\n'
           << "nominal_dc_ready=" << (generated.nominal_dc_ready ? "true" : "false") << '\n'
           << "pvt_ready=" << (generated.pvt_ready ? "true" : "false") << '\n'
           << "parameters_quantized="
           << (generated.parameters_quantized ? "true" : "false") << '\n'
           << "ready_for_sizing=" << (generated.ready_for_sizing ? "true" : "false") << '\n'
           << "派生电路=" << generated.target.library << '/' << generated.target.cell << '/' << generated.target.view << '\n'
           << "原始网表=" << (root / "before/core_before.scs").string() << '\n'
           << "期望网表=" << (root / "expected/core_expected.scs").string() << '\n'
           << "回读网表=" << (root / "after/core_roundtrip.scs").string() << '\n'
           << "封装子Cell数=" << packaged.packages.size() << '\n'
           << "验证报告=" << (root / "reports/validation.txt").string() << '\n';
    return 0;
}

int generateCommand(const std::filesystem::path& root, const Options& options, std::ostream& output,
                    std::ostream& error, ProcessRunner& runner)
{
    GenerateContext ctx(root, options, output, error, runner);
    int code = ctx.GenerateLoadAndValidate();
    if (code != 0) return code;
    code = ctx.GenerateRescanPdk();
    if (code != 0) return code;
    code = ctx.GenerateBaselineOp();
    if (code != 0) return code;
    code = ctx.GenerateSolveOperations();
    if (code != 0) return code;
    code = ctx.GeneratePlan();
    if (code != 0) return code;
    code = ctx.GenerateMaterializeAndReport();
    if (code != 0) return code;
    return 0;
}

} // namespace st::standalone::detail
