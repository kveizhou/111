#include "st/Cli.h"

#include "CliInternal.h"

#include <ostream>

namespace st::standalone {
namespace {

bool parseOptions(const std::vector<std::string>& arguments,
                  std::string& command, detail::Options& options, std::string& message)
{
    if (arguments.empty()) {
        message = "缺少命令";
        return false;
    }
    command = arguments.front();
    if (command == "help" || command == "--help" || command == "-h") return true;
    if ((arguments.size() - 1) % 2 != 0) {
        message = "参数必须使用--name value成对提供";
        return false;
    }
    for (std::size_t index = 1; index < arguments.size(); index += 2) {
        const auto& key = arguments[index];
        if (key.size() < 3 || key[0] != '-' || key[1] != '-' ||
            !options.emplace(key.substr(2), arguments[index + 1]).second) {
            message = "无效或重复参数：" + key;
            return false;
        }
    }
    return true;
}

} // namespace

void PrintCliHelp(std::ostream& output)
{
    output <<
        "st_circuit_tool - 独立MOS结构变换与Virtuoso往返工具\n\n"
        "命令:\n"
        "  inspect  --backend PATH --cds-lib PATH --lib LIB --cell CELL --view schematic\n"
        "           --work-dir DIR --variant-lib LIB --variant-cell CELL --variant-id ID\n"
        "           --skill topology_variant.il\n"
        "           [--validation-scope dc_operating_point|structure_only|experimental_dc]\n"
        "           [--bench-lib LIB --bench-cell CELL --bench-view schematic]\n"
        "           [--vbias-vhigh-net NET --vbias-vlow-net NET]\n"
        "           [--core-subckt NAME] [--simulator spectre] [--nominal-corner tt]\n"
        "           [--pvt-corners tt,ss,ff]\n"
        "           [--max-branch-current-error FRACTION --max-vbias-current AMPERE]\n"
        "  list     --session DIR\n"
        "  confirm  --session DIR --operation FILE.conf\n"
        "  undo     --session DIR\n"
        "  fresh    --session DIR\n"
        "  generate --session DIR [--experimental-resistor-trials FILE.tsv] [--experimental-resistor-auto true]\n"
        "  open     --session DIR\n\n"
        "输入是Virtuoso工程cds.lib和核心L/C/V；baseline网表由后端自动生成。\n"
        "generate自动完成PDK重扫、基线工作点、VBIAS求解、封装、物化、\n"
        "名义DC检查与回读验证，全部通过后输出四状态与ready_for_sizing。\n"
        "电流上限选填且须成对提供；无Spec时求解名义DC可行参数，未验完整性能。\n";
}

int RunCli(const std::vector<std::string>& arguments,
           std::ostream& output,
           std::ostream& error,
           ProcessRunner& runner)
{
    using namespace detail;
    std::string command;
    Options options;
    std::string message;
    if (!parseOptions(arguments, command, options, message)) {
        error << message << '\n';
        PrintCliHelp(error);
        return 2;
    }
    if (command == "help" || command == "--help" || command == "-h") {
        PrintCliHelp(output);
        return 0;
    }
    if (command == "inspect") return inspectCommand(options, output, error, runner);

    std::string session;
    if (!required(options, "session", session, message)) {
        error << message << '\n';
        return 2;
    }
    const std::filesystem::path root(session);
    if (command == "list") return listCommand(root, output, error);
    if (command == "confirm") return confirmCommand(root, options, output, error);
    if (command == "undo") return undoCommand(root, output, error);
    if (command == "fresh") return freshCommand(root, output, error);
    if (command == "generate") return generateCommand(root, options, output, error, runner);
    if (command == "open") return openCommand(root, output, error, runner);
    error << "未知命令：" << command << '\n';
    PrintCliHelp(error);
    return 2;
}

} // namespace st::standalone
