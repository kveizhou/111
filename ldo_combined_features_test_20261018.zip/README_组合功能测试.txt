电阻撤销、同型Cascode、异型Cascode、Stack组合测试（2026-10-18）

适用：当前已完成same-cross-undo测试、已有mixed_four会话的服务器。
本包只修改Python/Shell生产代码，包含测试和说明，无需重编C++。

上传至st-engine-maau所在目录，整行执行：
unzip -o ldo_combined_features_test_20261018.zip && bash st-engine-maau/scripts/test_mixed_cascode.sh combo "$st_batch/candidate_I21_xbb892w0"

自动定位原混合测试会话，并重新设置该会话的活动操作：
1. I29的Source侧串入已绑定PDK电阻，使用真实种子参数。
2. 撤销这项电阻操作，活动操作数回到0。
3. I21同型Cascode，原D侧加管，原G/S/B保持。
4. I105异型Cascode，同极性不同已准入Master，原D侧加管，原G/S/B保持。
5. I85两级共栅Stack：原管加一只同型号同参数MOS串联，栅极共用，Bulk保持原网。
6. 最后统一生成三项变换。每个Cascode最多16次自动DC搜索；满足就停止。I105在保留I21的累积电路上搜索；Stack不另建VBIAS搜索。最终整体回读和DC包含全部三项。
7. 命令自动读取最终实际回读网表，核对所有保留变换和电阻撤销结果。

本例目标来自已有mixed_four的01/02/03/04.conf；若此前选择不同目标，以运行打印为准。
电阻仅确认并撤销，没有生成中间电阻电路，不单独仿真它。不会重跑原始已接受基线。
当前合法的I21已解参数可作为首点，但本轮重新做实际DC，不沿用旧结论。

开头预期：
TEST_SEQUENCE=resistor,undo_resistor,same,cross,stack,generate
RESISTOR_UNDO_TARGET=I29
SAME_TARGET=I21
CROSS_TARGET=I105
STACK_TARGET=I85
STACK_STAGES=2
INTERMEDIATE_DC_SEARCHES=0
ACTIVE_GROUPS=1
ACTIVE_GROUPS=0
RESISTOR_OPERATION_UNDONE=true
（随后活动组数依次为1、2、3）

实际最终生成完成且结构正确时：
TEST_GROUPS=3
GENERATED_SUBCELLS=5
RESULT_CELL=实际库/Cell/schematic
RESISTOR_UNDO_RESTORED=PASS TARGET=I29
SAME_CASCODE_D_SIDE=PASS TARGET=I21
CROSS_CASCODE_D_SIDE=PASS TARGET=I105
ORIGINAL_GSB_PRESERVED=PASS
VBIAS_CONNECTIONS=PASS
STACK_SERIES_SHARED_GATE=PASS TARGET=I85 STAGES=2
COMBINED_STRUCTURE_TEST=PASS

只有最终最低DC条件也满足时：
COMBINED_DC_TEST=PASS
COMBINED_FEATURES_TEST=PASS
退出码0。

此前I105异型曾为saturation未满足的best_effort，不能保证本次通过。
若本轮真实DC收敛并生成了待优化候选，但还有电气未满足项：
COMBINED_STRUCTURE_TEST=PASS
COMBINED_DC_TEST=NOT_PASSED
UNMET_REQUIREMENTS=实际未满足项
OPTIMIZATION_CANDIDATE_READY=true
COMBINED_FEATURES_TEST=INCOMPLETE
退出码2。这时可以查看已生成结构，但不能宣称电气合格。
执行/读取失败则在主流程报错处停止，不用结构通过覆盖错误。

只复查上次生成及其保存的回读结果（不生成、不启动Cadence或DC）：
bash st-engine-maau/scripts/test_mixed_cascode.sh combo-check "$st_batch/candidate_I21_xbb892w0"

打开已生成的结果：
bash st-engine-maau/scripts/test_mixed_cascode.sh open "$st_batch/candidate_I21_xbb892w0"

每组16次是上限，不是必须跑满；若I105用满16次，本次会明显长于上一轮只有I21首点的测试。
无需传所有心跳日志，只传最终TEST_GROUPS、RESULT_CELL、COMBINED_*和UNMET_REQUIREMENTS；若提前失败，传首条实际错误及对应DETAIL即可。
本地已验证脚本、读取器及带后端替身的组合主调用链，真实服务器组合电气结果待本次运行。
