#!/usr/bin/env bash
# Server tests reuse the existing mixed session and generate only the final set.
set -euo pipefail
if [[ $# != 2 || ! "$1" =~ ^(four|retry-four|three|two|same-cross-undo|combo|combo-check|open)$ ]]; then
    echo "usage: bash $0 {four|retry-four|three|two|same-cross-undo|combo|combo-check|open} CANDIDATE_DIR" >&2
    exit 2
fi
stage=$1
candidate=$2
engine=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
site="$engine/server/site"
resume_mode=--generate-current
if [[ "$stage" == four ]]; then
    python3 "$site/mixed_cascode.py" "$candidate"
fi
pointer="$candidate/work/test_operations/mixed_four/candidate.txt"
if [[ -f "$pointer" ]]; then candidate=$(cat "$pointer"); fi
work="$candidate/work"
ops="$work/test_operations/mixed_four"
if [[ "$stage" == open ]]; then
    exec python3 "$site/standalone.py" open --session "$work"
fi

check_operations() {
    python3 - "$site" "$work" "$1" "$ops" "${2:-}" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from run_cascode_experiment import pairs
work=pathlib.Path(sys.argv[2]);count=int(sys.argv[3])
files=sorted((work/'changes').glob('*.conf'))
expected=([pairs(sys.argv[5])] if sys.argv[5] else
          [pairs(pathlib.Path(sys.argv[4])/('%02d.conf'%i)) for i in range(1,count+1)])
actual=[pairs(p) for p in files]
fields=('id','type','instance','new_master','stage_count','gate_policy','nmos_bulk_net',
        'resistor.master','resistor.parameter','resistor.value')
if len(actual)!=count or any(any(a.get(k)!=b.get(k) for k in fields) for a,b in zip(actual,expected)):
    print('RESULT=TEST_SEQUENCE_MISMATCH; expected active prefix of %d prepared operations; stopping before further edits/generation'%count)
    sys.exit(2)
print('ACTIVE_GROUPS='+str(count))
for index,op in enumerate(actual,1):
    print('ACTIVE_GROUP=%d TARGET=%s TYPE=%s'%(index,op['instance'],op['type']))
PY
}

if [[ "$stage" == combo || "$stage" == combo-check ]]; then
    ops="$work/test_operations/combined_features"
    count=3
    if [[ "$stage" == combo ]]; then
        python3 - "$site" "$work" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from mixed_cascode import prepare_combo
try:
    prepare_combo(pathlib.Path(sys.argv[2]))
except (OSError,ValueError,KeyError,TypeError) as error:
    print('COMBINED_FEATURES_TEST=NOT_PREPARED\nISSUE='+str(error))
    sys.exit(2)
PY
        python3 "$site/standalone.py" fresh --session "$work"
        python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/resistor.conf"
        check_operations 1 "$ops/resistor.conf"
        python3 "$site/standalone.py" undo --session "$work"
        check_operations 0
        echo 'RESISTOR_OPERATION_UNDONE=true'
        for index in 01 02 03; do
            python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/$index.conf"
            check_operations "$((10#$index))"
        done
    else
        echo 'NATIVE_EXECUTIONS=0'
        echo 'SPECTRE_RERUN=false'
    fi
elif [[ "$stage" == same-cross-undo ]]; then
    # Use the pair already admitted for the mixed test; no PDK/native discovery.
    python3 - "$site" "$work" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from run_cascode_experiment import pairs
from mixed_cascode import check_undo_pair
work=pathlib.Path(sys.argv[2])
try:
    same,cross=check_undo_pair(work)
except (OSError,ValueError,KeyError,TypeError) as error:
    print('SAME_CROSS_UNDO_TEST=NOT_PREPARED\nISSUE='+str(error))
    sys.exit(2)
print('TEST_SEQUENCE=same,cross,undo_cross,generate')
print('SAME_TARGET='+same['instance']+'\nCROSS_TARGET='+cross['instance'])
print('INTERMEDIATE_DC_SEARCHES=0')
PY
    python3 "$site/standalone.py" fresh --session "$work"
    python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/01.conf"
    check_operations 1
    python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/02.conf"
    check_operations 2
    python3 "$site/standalone.py" undo --session "$work"
    count=1
    echo 'CROSS_OPERATION_UNDONE=true'
elif [[ "$stage" == four ]]; then
    # Prepare all four first: unavailable cross-flavor devices leave the
    # user's current operations and successful result untouched.
    python3 "$site/standalone.py" fresh --session "$work"
    for index in 01 02 03 04; do
        python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/$index.conf"
    done
    count=4
elif [[ "$stage" == retry-four ]]; then
    count=4
    resume_mode=--reuse-verified-inputs
    echo 'MIXED_RETRY_FOUR=true'
else
    if [[ "$stage" == three ]]; then count=3; else count=2; fi
    check_operations "$((count+1))"
    python3 "$site/standalone.py" undo --session "$work"
fi
check_operations "$count"
if [[ "$stage" != combo-check ]]; then
    python3 "$engine/scripts/resume_cascode_experiment.py" --candidate "$candidate" "$resume_mode" --stage-timeout 14400
fi
python3 - "$site" "$work" "$count" "$stage" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from run_cascode_experiment import pairs
work=pathlib.Path(sys.argv[2]);count=int(sys.argv[3])
r=pairs(work/'reports/validation.txt')
print('TEST_GROUPS='+str(count))
print('GENERATED_SUBCELLS='+r.get('generated_cells','unknown'))
print('RESULT_CELL='+r.get('target','unknown'))
if sys.argv[4] in ('combo','combo-check'):
    from mixed_cascode import verify_combo
    try:
        if not (r.get('ok')=='true' and r.get('stage')=='complete' and
                r.get('structural_ready')=='true' and r.get('generated_cells')=='5'):
            raise ValueError('final generation/readback is incomplete or not five subcells')
        verify_combo(work)
    except (OSError,ValueError,KeyError,TypeError,StopIteration) as error:
        print('COMBINED_STRUCTURE_TEST=NOT_PASSED\nISSUE='+str(error))
        sys.exit(2)
    print('COMBINED_STRUCTURE_TEST=PASS')
    if r.get('experimental_dc_ready')!='true' or r.get('failed_constraints'):
        print('COMBINED_DC_TEST=NOT_PASSED')
        print('UNMET_REQUIREMENTS='+r.get('failed_constraints','unknown'))
        print('OPTIMIZATION_CANDIDATE_READY='+r.get('optimization_candidate_ready','false'))
        print('COMBINED_FEATURES_TEST=INCOMPLETE')
        sys.exit(2)
    print('COMBINED_DC_TEST=PASS\nCOMBINED_FEATURES_TEST=PASS')
    sys.exit(0)
if not (r.get('ok')=='true' and r.get('stage')=='complete' and
        r.get('structural_ready')=='true' and r.get('experimental_dc_ready')=='true' and
        not r.get('failed_constraints') and r.get('generated_cells')==str(count*2)):
    print('MIXED_CASCODE_TEST=NOT_PASSED; see the actual generation result above')
    sys.exit(2)
if count!=1: print('MIXED_CASCODE_TEST=PASS')
if count==2: print('FINAL_RETAINED=same_type_NMOS,cross_flavor_PMOS')
if count==1:
    from mixed_cascode import verify_same_after_undo
    try:
        verify_same_after_undo(work)
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('SAME_CROSS_UNDO_TEST=NOT_PASSED\nISSUE='+str(error))
        sys.exit(2)
    print('SAME_CROSS_UNDO_TEST=PASS')
PY
