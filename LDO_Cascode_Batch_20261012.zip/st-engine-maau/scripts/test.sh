#!/usr/bin/env bash
set -euo pipefail

project_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
build_dir=${ST_BUILD_DIR:-"$project_dir/build"}

if [[ ! -x "$build_dir/bin/st_circuit_tool" ]]; then
    "$project_dir/scripts/build.sh"
fi

tests=(
    testmain
    devicecatalogtest
    pdkcatalogtest
    operatingpointtest
    resistorstresstest
    transactiontest
    changesettest
    biastest
    autobiastest
    dcsolvertest
    cascodetransformtest
    resistortransformtest
    stacktransformtest
    oaplantest
    packagingtest
    variantverifiertest
    standalonetest
    virtuosobackendtest
    cliworkflowtest
)

if [[ "${ST_BUILD_MAAU_COMPAT:-OFF}" == "ON" ]]; then
    tests+=(maaucontracttest)
fi

for test_name in "${tests[@]}"; do
    test_program="$build_dir/tests/$test_name"
    if [[ ! -x "$test_program" ]]; then
        echo "missing test program: $test_program" >&2
        exit 2
    fi
    "$test_program"
done

"$build_dir/bin/democascode" >/dev/null
"$build_dir/bin/demochangeset" >/dev/null
"$build_dir/bin/st_circuit_tool" help >/dev/null

shell_files=(
    "$project_dir"/scripts/*.sh
    "$project_dir"/server/*.sh
    "$project_dir"/server/bin/*.sh
    "$project_dir"/server/lib/*.sh
    "$project_dir"/tests/ServerBackendContractTest.sh
)
for shell_file in "${shell_files[@]}"; do
    bash -n "$shell_file"
done

if command -v csh >/dev/null 2>&1; then
    csh -n "$project_dir/server/setup_backend.csh" </dev/null
fi

"$project_dir/tests/ServerBackendContractTest.sh" >/dev/null

if [[ "${ST_BUILD_MAAU_COMPAT:-OFF}" == "ON" ]]; then
    python3 "$project_dir/tests/SiteConfigTest.py"
    python3 "$project_dir/tests/SiteOpTest.py"
fi
python3 "$project_dir/tests/StandaloneSiteTest.py"
python3 "$project_dir/tests/StandaloneOpTest.py"
python3 "$project_dir/tests/PdkDiscoveryTest.py"
python3 "$project_dir/tests/StructureOnlyTest.py"
python3 "$project_dir/tests/TerminalDiagnosticsTest.py"
python3 "$project_dir/tests/CdfTerminalNamesTest.py"
python3 "$project_dir/tests/PdkCandidatePolicyTest.py"
python3 "$project_dir/tests/CdfRoundtripDiagnosticsTest.py"
python3 "$project_dir/tests/CoreReferenceTest.py"
python3 "$project_dir/tests/StructureResultCheckTest.py"
python3 "$project_dir/tests/MaestroSetupReadTest.py"
python3 "$project_dir/tests/CascodeBenchPreflightTest.py"
python3 "$project_dir/tests/CascodeBatchTest.py"

echo "test programs passed: ${#tests[@]}"
echo "demos passed: 2"
echo "cli help passed: 1"
echo "server backend contract passed: 1"
echo "shell syntax checks passed: ${#shell_files[@]}"
echo "standalone PDK entry and signed OP tests passed: 20"
echo "source-bound PDK discovery tests passed: 11"
echo "structure-only entry and fixed workflow tests passed: 9"
echo "read-only terminal diagnostic dispatch tests passed: 6"
echo "CDF terminal native check preparation and dispatch tests passed: 3"
echo "PDK candidate policy preparation, dispatch and logging tests passed: 5"
echo "CDF round-trip diagnostic selection and dispatch tests passed: 6"
echo "actual core reference inspection tests passed: 7"
echo "server-local structural result summary tests passed: 18"
echo "read-only Maestro setup dispatch and summary tests passed: 11"
echo "Cascode Bench config preflight tests passed: 13"
echo "Cascode batch context and DC probe tests passed: 12"
if [[ "${ST_BUILD_MAAU_COMPAT:-OFF}" == "ON" ]]; then
    echo "optional Maau configuration and OP contract tests passed: 18"
fi
