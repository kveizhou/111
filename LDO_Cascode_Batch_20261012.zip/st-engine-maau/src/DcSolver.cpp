// =============================================================
// DcSolver.cpp — PDK 离散参数 DC 闭环求解器
// 固定流程见 Task 6 brief：初值量化 → 粗搜索（每参数 {min,中点,初值,max}）→
// 局部精搜索（相邻量化值）→ 硬约束过滤 → 六项目标 tuple 排名 → 确定性轨迹。
// 本文件不出现任何固定 PDK Cell 名；所有取值经 QuantizeParameter。
// =============================================================
#include "st/DcSolver.h"

#include "st/PdkCatalog.h"
#include "st/Transform.h"
#include "st/VariantVerifier.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <tuple>
#include <utility>

namespace st {
namespace {

constexpr double kContinuityTolerance = 1e-3;
constexpr std::size_t kMaxCoarseEvaluations = 256;
constexpr std::size_t kMaxRefineEvaluations = 128;
constexpr std::size_t kMaxTotalEvaluations = 384;

// 固定检查顺序；轨迹 reason 取第一个失败项。
const std::vector<std::string> kConstraintOrder = {
    "converged", "complete", "params_legal",
    "reliability_vgs", "reliability_vds", "reliability_vgb",
    "saturation", "vbias_range", "bias_conduction", "branch_direction",
    "branch_continuity", "current_limits_valid", "branch_current_limit", "bias_current_limit",
    "resistor_stress",
};

struct RoleLayout {
    std::string mirror_ref;
    std::string mirror_out;
    std::string resistor;
    std::string cas_rep;
    std::string ctrl_rep;
};

RoleLayout layoutFor(DeviceKind polarity)
{
    if (polarity == DeviceKind::MosN) {
        return {"P_REF", "P_OUT_N", "R_REF_N", "N_CAS_REP_N", "N_CTRL_REP_N"};
    }
    return {"N_REF", "N_OUT_P", "R_REF_P", "P_CAS_REP_P", "P_CTRL_REP_P"};
}

std::string formatNumber(double value)
{
    if (!std::isfinite(value)) return std::signbit(value) ? "-1e30" : "1e30";
    char buffer[64];
    std::snprintf(buffer, sizeof buffer, "%.6g", value);
    return buffer;
}

std::string jsonEscape(const std::string& text)
{
    std::string escaped;
    for (const char ch : text) {
        switch (ch) {
        case '"': escaped += "\\\""; break;
        case '\\': escaped += "\\\\"; break;
        default:
            if (static_cast<unsigned char>(ch) < 0x20) {
                escaped += '?';
            } else {
                escaped += ch;
            }
        }
    }
    return escaped;
}

bool quantize(double value, const ParameterConstraint& constraint,
              double& quantized)
{
    try {
        quantized = QuantizeParameter(value, constraint);
        return true;
    } catch (const std::exception&) {
        return false;
    }
}

double geometricMidpoint(const ParameterConstraint& constraint)
{
    if (constraint.minimum > 0.0 && std::isfinite(constraint.maximum)) {
        return std::sqrt(constraint.minimum * constraint.maximum);
    }
    return (constraint.minimum + constraint.maximum) / 2.0;
}

struct SearchParam {
    int slot = 0; // 0=新增 Cascode，1=Mirror（两管共享），2=参考电阻
    std::string semantic;
    const DeviceDescriptor* device = nullptr;
    ParameterConstraint constraint;
};

const ParameterConstraint* findConstraint(const DeviceDescriptor& descriptor,
                                          const std::string& semantic)
{
    for (const auto& [key, constraint] : descriptor.parameter_constraints) {
        const std::string& declared = constraint.semantic_name.empty()
            ? key : constraint.semantic_name;
        if (declared == semantic) return &constraint;
    }
    return nullptr;
}

void appendSearchParams(int slot, const DeviceDescriptor& descriptor,
                        std::vector<SearchParam>& params)
{
    static const std::vector<std::string> mosOrder = {
        "width", "length", "fins", "fin", "fingers", "finger",
        "multiplier"};
    static const std::vector<std::string> resistorOrder = {"resistance"};
    const auto& order = descriptor.kind == DeviceKind::Resistor
        ? resistorOrder : mosOrder;
    std::set<std::string> usedCdf;
    for (const auto& wanted : order) {
        for (const auto& [key, constraint] : descriptor.parameter_constraints) {
            const std::string semantic = constraint.semantic_name.empty()
                ? key : constraint.semantic_name;
            if (semantic != wanted || constraint.cdf_name.empty() ||
                usedCdf.count(constraint.cdf_name) != 0) {
                continue;
            }
            params.push_back({slot, semantic, &descriptor, constraint});
            usedCdf.insert(constraint.cdf_name);
        }
    }
}

double parameterValue(const std::map<std::string, std::string>& values,
                      const DeviceDescriptor& descriptor,
                      const std::string& semantic, double fallback)
{
    const ParameterConstraint* constraint = findConstraint(descriptor, semantic);
    if (constraint == nullptr) return fallback;
    const auto found = values.find(constraint->cdf_name);
    if (found == values.end()) return fallback;
    bool ok = false;
    const double value = parseSuffixValue(found->second, ok);
    return ok ? value : fallback;
}

double estimateMosArea(const std::map<std::string, std::string>& values,
                       const DeviceDescriptor& descriptor)
{
    const double multiplier = parameterValue(
        values, descriptor, "multiplier", 1.0);
    const double width = parameterValue(values, descriptor, "width", 0.0);
    const double length = parameterValue(values, descriptor, "length", 0.0);
    if (width > 0.0 && length > 0.0) {
        const double fingers = parameterValue(
            values, descriptor, "fingers",
            parameterValue(values, descriptor, "finger", 1.0));
        return width * length * std::max(1.0, fingers) *
               std::max(1.0, multiplier);
    }
    const double fins = parameterValue(
        values, descriptor, "fins",
        parameterValue(values, descriptor, "fin", 0.0));
    if (fins > 0.0 && length > 0.0) {
        return fins * length * std::max(1.0, multiplier);
    }
    return 0.0;
}

// 候选点签名：量化值精确拼接，用于评估缓存（重复组合不重复调用宿主）。
std::string pointSignature(const std::vector<double>& point)
{
    std::string signature;
    char buffer[32];
    for (const double value : point) {
        std::snprintf(buffer, sizeof buffer, "%.17g", value);
        signature += buffer;
        signature += ',';
    }
    return signature;
}

struct EvaluationRecord {
    std::vector<double> point;
    BiasSizing sizing;
    std::map<std::string, bool> constraints;
    DcCandidateMetrics metrics;
    double vbias_voltage = 0.0;
    bool converged = false;
    bool kept = false;
    bool host_called = false;
    std::string reason = "ok";
    std::string host_message;
    std::string corner; // 空=名义Corner；PVT复验记录填各自Corner
    std::string cascode_instance;
    ElectricalConstraintRequest electrical_check;
    std::size_t combination_id = 0;
    std::size_t coarse_budget = 0;
    std::size_t refine_budget = 0;
    bool parameter_search_truncated = false;
    std::string phase;
};

// 排名：确定性 tuple 升序；可靠性/饱和余量取负实现“越大越优”；
// 完全相等时返回 false（先评估者保持最优）。
bool metricsBetter(const DcCandidateMetrics& left, const DcCandidateMetrics& right)
{
    return std::tuple<double, double, double, double, double, double>(
               left.branch_current_error, left.control_op_error, left.iq_delta,
               -left.reliability_margin, -left.saturation_margin,
               left.area_estimate) <
           std::tuple<double, double, double, double, double, double>(
               right.branch_current_error, right.control_op_error,
               right.iq_delta, -right.reliability_margin,
               -right.saturation_margin, right.area_estimate);
}

// 轨迹 reason 与约束键的固定映射（键保持布尔语义，reason 给可读名）。
std::string reasonName(const std::string& constraint)
{
    if (constraint == "converged") return "not_converged";
    if (constraint == "complete") return "incomplete_snapshot";
    if (constraint == "current_limits_valid") return "current_limits_invalid";
    return constraint;
}

bool endsWithRole(const std::string& candidate, const std::string& leaf)
{
    if (candidate.size() <= leaf.size() ||
        candidate.compare(candidate.size() - leaf.size(), leaf.size(), leaf) != 0) {
        return false;
    }
    const char delimiter = candidate[candidate.size() - leaf.size() - 1];
    return delimiter == '.' || delimiter == '/' || delimiter == ':';
}

const MosOperatingPoint* resolveRole(const OperatingPointSnapshot& snapshot,
                                     const ElectricalMosRole& role)
{
    if (role.leaf_name.empty()) return nullptr;
    const auto exact = snapshot.mos.find(role.leaf_name);
    if (exact != snapshot.mos.end()) return &exact->second;
    if (!role.container_instance.empty()) {
        for (const char delimiter : {'.', '/', ':'}) {
            const auto scoped = snapshot.mos.find(
                role.container_instance + delimiter + role.leaf_name);
            if (scoped != snapshot.mos.end()) return &scoped->second;
        }
    }
    const MosOperatingPoint* unique = nullptr;
    for (const auto& [name, op] : snapshot.mos) {
        if (!endsWithRole(name, role.leaf_name)) continue;
        if (!role.container_instance.empty() &&
            name.find(role.container_instance) == std::string::npos) {
            continue;
        }
        if (unique != nullptr) return nullptr;
        unique = &op;
    }
    return unique;
}

std::string traceLine(std::size_t candidateId, const std::string& corner,
                      const EvaluationRecord& record, const RoleLayout& layout,
                      bool selected)
{
    std::ostringstream line;
    line << "{\"candidate\":" << candidateId
         << ",\"combination\":" << record.combination_id
         << ",\"masters\":{\"mirror\":\"" << jsonEscape(record.sizing.mirror_master)
         << "\",\"resistor\":\"" << jsonEscape(record.sizing.resistor_master)
         << "\"},\"search\":{\"nominal_budget\":" << kMaxTotalEvaluations
         << ",\"coarse_budget\":" << record.coarse_budget
         << ",\"refine_budget\":" << record.refine_budget
         << ",\"parameter_search_truncated\":"
         << (record.parameter_search_truncated ? "true" : "false")
         << ",\"phase\":\"" << record.phase << "\"},\"converged\":"
         << (record.converged ? "true" : "false") << ",\"constraints\":{";
    bool first = true;
    for (const auto& name : kConstraintOrder) {
        const auto found = record.constraints.find(name);
        if (found == record.constraints.end()) continue;
        if (!first) line << ',';
        first = false;
        line << '\"' << name << "\":" << (found->second ? "true" : "false");
    }
    line << "},\"corner\":\"" << jsonEscape(corner) << "\",\"kept\":"
         << (record.kept ? "true" : "false") << ",\"metrics\":{"
         << "\"area_estimate\":" << formatNumber(record.metrics.area_estimate)
         << ",\"branch_current_error\":"
         << formatNumber(record.metrics.branch_current_error)
         << ",\"control_op_error\":"
         << formatNumber(record.metrics.control_op_error)
         << ",\"iq_delta\":" << formatNumber(record.metrics.iq_delta)
         << ",\"reliability_margin\":"
         << formatNumber(record.metrics.reliability_margin)
         << ",\"saturation_margin\":"
         << formatNumber(record.metrics.saturation_margin)
         << "},\"params\":{";
    const auto& elements = record.sizing.element_parameters;
    const auto ctrl = elements.find(layout.ctrl_rep);
    const auto mirror = elements.find(layout.mirror_ref);
    const auto resistor = elements.find(layout.resistor);
    const std::pair<const char*, const std::map<std::string, std::string>*>
        groups[] = {
            {"cascode", &record.sizing.cascode_parameters},
            {"control_replica",
             ctrl == elements.end() ? nullptr : &ctrl->second},
            {"mirror", mirror == elements.end() ? nullptr : &mirror->second},
            {"resistor",
             resistor == elements.end() ? nullptr : &resistor->second},
        };
    first = true;
    for (const auto& [group, params] : groups) {
        if (!first) line << ',';
        first = false;
        line << '\"' << group << "\":{";
        bool firstParam = true;
        if (params != nullptr) {
            for (const auto& [cdf, value] : *params) {
                if (!firstParam) line << ',';
                firstParam = false;
                line << '\"' << jsonEscape(cdf) << "\":\"" << jsonEscape(value)
                     << '\"';
            }
        }
        line << '}';
    }
    line << "},\"reason\":\"" << record.reason << "\",\"host_message\":\""
         << jsonEscape(record.host_message) << "\",\"selected\":"
         << (selected ? "true" : "false") << '}';
    return line.str();
}

} // namespace

ElectricalConstraintResult EvaluateElectricalConstraints(
    const OperatingPointSnapshot& snapshot,
    const ElectricalConstraintRequest& request,
    bool converged)
{
    ElectricalConstraintResult result;
    for (const auto& name : kConstraintOrder) result.constraints[name] = true;
    result.constraints["converged"] = converged;
    const bool limitsConfigured = request.max_branch_current_error.has_value() &&
        request.max_vbias_current.has_value() &&
        std::isfinite(*request.max_branch_current_error) &&
        std::isfinite(*request.max_vbias_current) &&
        *request.max_branch_current_error > 0.0 &&
        *request.max_vbias_current > 0.0;
    const bool anyCurrentLimit = request.max_branch_current_error.has_value() ||
        request.max_vbias_current.has_value();
    // 无性能 Spec 时仍执行 DC 硬门禁；显式提供的限值须成对且合法。
    result.constraints["current_limits_valid"] = !anyCurrentLimit || limitsConfigured;
    ResistorStressResult resistorStress;
    if (!request.resistor.leaf_name.empty()) {
        resistorStress = EvaluateResistorStress(snapshot, request.resistor);
        result.constraints["resistor_stress"] = converged && resistorStress.ok;
    }

    const MosOperatingPoint* mirrorRef = nullptr;
    const MosOperatingPoint* mirrorOut = nullptr;
    const MosOperatingPoint* casRep = nullptr;
    const MosOperatingPoint* ctrlRep = nullptr;
    const MosOperatingPoint* actualControl = nullptr;
    const MosOperatingPoint* actualCascode = nullptr;
    if (converged) {
        mirrorRef = resolveRole(snapshot, request.mirror_ref);
        mirrorOut = resolveRole(snapshot, request.mirror_out);
        casRep = resolveRole(snapshot, request.cascode_replica);
        ctrlRep = resolveRole(snapshot, request.control_replica);
        actualControl = resolveRole(snapshot, request.actual_control);
        actualCascode = resolveRole(snapshot, request.actual_cascode);
    }
    result.constraints["complete"] = converged && mirrorRef != nullptr &&
        mirrorOut != nullptr && casRep != nullptr && ctrlRep != nullptr &&
        actualControl != nullptr && actualCascode != nullptr;

    if (result.constraints["complete"]) {
        const std::pair<const MosOperatingPoint*, const ElectricalMosRole*>
            roles[] = {
                {mirrorRef, &request.mirror_ref},
                {mirrorOut, &request.mirror_out},
                {casRep, &request.cascode_replica},
                {ctrlRep, &request.control_replica},
                {actualControl, &request.actual_control},
                {actualCascode, &request.actual_cascode},
            };
        double reliabilityMargin = std::numeric_limits<double>::infinity();
        double saturationMargin = std::numeric_limits<double>::infinity();
        const bool controlWasSaturated =
            std::fabs(request.baseline_control.vds) >=
            std::fabs(request.baseline_control.vdsat);
        for (const auto& [op, role] : roles) {
            const double vgb = std::fabs(op->vg - op->vb);
            const double margins[] = {
                role->limits.max_abs_vgs - std::fabs(op->vgs),
                role->limits.max_abs_vds - std::fabs(op->vds),
                role->limits.max_abs_vgb - vgb,
            };
            result.constraints["reliability_vgs"] =
                result.constraints["reliability_vgs"] && margins[0] >= 0.0;
            result.constraints["reliability_vds"] =
                result.constraints["reliability_vds"] && margins[1] >= 0.0;
            result.constraints["reliability_vgb"] =
                result.constraints["reliability_vgb"] && margins[2] >= 0.0;
            for (const double margin : margins) {
                reliabilityMargin = std::min(reliabilityMargin, margin);
            }
            const double saturation = std::fabs(op->vds) - std::fabs(op->vdsat);
            // 镜像和 Cascode 角色必须饱和；原控制管及其 Replica 仅在
            // 基线原管已饱和时要求保持饱和，避免拒绝有意在线性区的原管。
            const bool requireSaturation = controlWasSaturated ||
                (role != &request.control_replica &&
                 role != &request.actual_control);
            if (requireSaturation) {
                result.constraints["saturation"] =
                    result.constraints["saturation"] && saturation >= 0.0;
                saturationMargin = std::min(saturationMargin, saturation);
            }
        }

        const double vbias = casRep->vd;
        const double vbiasLow = request.polarity == DeviceKind::MosN
            ? ctrlRep->vs : mirrorOut->vs;
        const double vbiasHigh = request.polarity == DeviceKind::MosN
            ? mirrorOut->vs : casRep->vs;
        result.vbias_voltage = vbias;
        result.constraints["vbias_range"] =
            vbiasLow <= vbias && vbias <= vbiasHigh;

        const auto sameNonzeroDirection = [](double current, double reference) {
            return std::isfinite(current) && std::isfinite(reference) &&
                current != 0.0 && reference != 0.0 &&
                std::signbit(current) == std::signbit(reference);
        };
        result.constraints["bias_conduction"] =
            sameNonzeroDirection(mirrorOut->id, mirrorRef->id);
        // 不添加任意最小电流或过驱动门槛，保留原管的弱反型/线性区用途。
        // 基线已导通的支路必须继续导通且方向一致；有意关断的原管不强制开启。
        result.constraints["branch_direction"] =
            request.baseline_control.id == 0.0 ||
            (sameNonzeroDirection(ctrlRep->id, request.baseline_control.id) &&
             sameNonzeroDirection(casRep->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualControl->id, request.baseline_control.id) &&
             sameNonzeroDirection(actualCascode->id, request.baseline_control.id));

        const double replicaContinuityError =
            std::fabs(std::fabs(ctrlRep->id) - std::fabs(casRep->id)) /
            std::max(std::fabs(ctrlRep->id), 1e-30);
        const double actualContinuityError =
            std::fabs(std::fabs(actualControl->id) -
                      std::fabs(actualCascode->id)) /
            std::max(std::fabs(actualControl->id), 1e-30);
        result.constraints["branch_continuity"] =
            replicaContinuityError <= kContinuityTolerance &&
            actualContinuityError <= kContinuityTolerance;

        const double originalCurrent = std::fabs(request.baseline_control.id);
        result.metrics.branch_current_error =
            std::max(std::fabs(std::fabs(ctrlRep->id) - originalCurrent),
                     std::fabs(std::fabs(actualControl->id) - originalCurrent)) /
            std::max(originalCurrent, 1e-30);
        result.metrics.control_op_error =
            std::fabs(actualControl->vgs - request.baseline_control.vgs) +
            std::fabs(actualControl->vds - request.baseline_control.vds);
        result.metrics.iq_delta =
            std::fabs(mirrorRef->id) + std::fabs(mirrorOut->id);
        result.constraints["branch_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.branch_current_error <=
                *request.max_branch_current_error);
        result.constraints["bias_current_limit"] = !anyCurrentLimit ||
            (limitsConfigured && result.metrics.iq_delta <= *request.max_vbias_current);
        result.metrics.reliability_margin = reliabilityMargin;
        result.metrics.saturation_margin = saturationMargin;
    } else {
        for (const auto& name : kConstraintOrder) {
            if (name != "converged" && name != "complete" &&
                name != "params_legal") {
                result.constraints[name] = false;
            }
        }
    }

    for (const auto& name : kConstraintOrder) {
        if (!result.constraints[name]) {
            result.first_failed_constraint = name == "resistor_stress" &&
                !resistorStress.failed_constraint.empty()
                ? resistorStress.failed_constraint : reasonName(name);
            return result;
        }
    }
    result.ok = true;
    return result;
}

AutoBiasSolveResult SolveAutoBias(const AutoBiasSolveRequest& request,
                                  const DeviceCatalog& catalog,
                                  DcEvaluationHost& host)
{
    AutoBiasSolveResult result;
    const DeviceKind polarity = request.template_request.polarity;
    const RoleLayout layout = layoutFor(polarity);

    // ---- 快速失败：选型、基线完整性、可求解约束 ----
    std::vector<AutoBiasDevicePlan> plans;
    Diagnostic diagnostic;
    if (!SelectAutoBiasDeviceCandidates(request.template_request, catalog, plans,
                                        diagnostic)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    const Subckt* root = request.baseline.find(request.root_subckt);
    const Instance* target =
        root != nullptr ? root->find(request.target_instance) : nullptr;
    if (target == nullptr) {
        result.diagnostics.push_back(
            {DiagCode::NotFound,
             "基线网表中找不到目标实例：" + request.root_subckt + "/" +
                 request.target_instance});
        return result;
    }
    const MosOperatingPoint* baselineTarget =
        FindMosOp(request.baseline_op, request.target_instance);
    if (baselineTarget == nullptr) {
        result.diagnostics.push_back(
            {DiagCode::MissingInput,
             "基线 DC 快照缺少目标实例的工作点：" + request.target_instance});
        return result;
    }

    result.device_combinations = plans.size();
    if (plans.size() > kMaxCoarseEvaluations) {
        result.diagnostics.push_back({DiagCode::BadParam,
            "search_budget_exhausted: " + std::to_string(plans.size()) +
            "个Mirror×Resistor组合超过名义粗搜索预算256，无法保证每组至少一次评估"});
        return result;
    }
    if (target->model != request.template_request.control_master) {
        result.diagnostics.push_back({DiagCode::BadParam,
            "基线目标master与Control Replica master不一致"});
        return result;
    }
    std::map<std::string, std::string> controlReplicaParams;
    if (!QuantizeAutoBiasParameters(*plans.front().control, target->params,
                                    layout.ctrl_rep, controlReplicaParams,
                                    diagnostic, true)) {
        result.diagnostics.push_back(std::move(diagnostic));
        return result;
    }
    std::vector<EvaluationRecord> records;
    std::optional<std::size_t> best;

    // 候选网表 = 基线 + 真实 Cascode 改写 + 核心层 VBIAS 层级实例。
    // 这里与最终 ChangeSet 重放共用 applyCascode，避免候选仿真只测
    // 脱离主电路的模板。名义候选与 PVT 复验共用同一组装。
    auto assembleCandidate = [&](const BiasSizing& sizing, Netlist& candidate,
                                 std::string& cascodeInstance) {
        const AutoBiasTemplateResult built = BuildAutoBiasTemplate(
            request.template_request, sizing, catalog);
        if (!built.ok) return false;

        candidate = request.baseline;
        AutoBiasSolveResult resolved;
        resolved.ok = true;
        resolved.sizing = sizing;

        CascodeTransformRequest transform;
        transform.subckt = request.root_subckt;
        transform.target = request.target_instance;
        transform.new_master = request.template_request.cascode_master;
        transform.gate_policy = GatePolicy::FixedBias;
        transform.solved_bias = std::move(resolved);
        transform.bias_template = built;
        transform.vbias_vhigh_net = request.template_request.vhigh_net;
        transform.vbias_vlow_net = request.template_request.vlow_net;
        transform.voltage_domain = request.template_request.voltage_domain;
        transform.nmos_bulk_net = request.nmos_bulk_net;
        transform.tie_isolated_pmos_to_source =
            request.tie_isolated_pmos_to_source;
        const TransformOutcome outcome = applyCascode(candidate, transform, catalog);
        if (!outcome.ok() || outcome.addedInstances.empty()) return false;
        cascodeInstance = outcome.addedInstances.front();
        return true;
    };

    // 硬约束 + 六项目标：名义候选与 PVT 复验共用同一判定，
    // PVT 只换 Corner 不换参数，排名仍只在名义 Corner 进行。
    auto assess = [&](EvaluationRecord& stored,
                      const OperatingPointSnapshot& snapshot) {
        auto check = stored.electrical_check;
        check.actual_cascode.leaf_name = stored.cascode_instance;
        const auto assessed = EvaluateElectricalConstraints(
            snapshot, check, stored.converged);
        for (const auto& [name, passed] : assessed.constraints) {
            if (name != "params_legal") stored.constraints[name] = passed;
        }
        stored.vbias_voltage = assessed.vbias_voltage;
        stored.metrics = assessed.metrics;

        if (assessed.ok) {
            double area = 0.0;
            const std::pair<const std::map<std::string, std::string>*,
                            const DeviceDescriptor*>
                areaTerms[] = {
                    {&stored.sizing.cascode_parameters, plans.front().cascode},
                    {&stored.sizing.cascode_parameters, plans.front().cascode},
                    {&stored.sizing.element_parameters[layout.mirror_ref],
                     catalog.Find(stored.sizing.mirror_master)},
                    {&stored.sizing.element_parameters[layout.mirror_out],
                     catalog.Find(stored.sizing.mirror_master)},
                    {&stored.sizing.element_parameters[layout.ctrl_rep],
                     plans.front().control},
                };
            for (const auto& [elementParams, descriptor] : areaTerms) {
                area += estimateMosArea(*elementParams, *descriptor);
            }
            stored.metrics.area_estimate = area;
        }

        stored.kept = true;
        for (const auto& name : kConstraintOrder) {
            if (!stored.constraints[name]) {
                stored.kept = false;
                stored.reason = name == "resistor_stress" &&
                    !assessed.first_failed_constraint.empty()
                    ? assessed.first_failed_constraint : reasonName(name);
                break;
            }
        }
    };

    // 对每一对真实master独立搜索参数，分摊预算保证后续组合有评估机会。
    for (std::size_t combinationIndex = 0; combinationIndex < plans.size();
         ++combinationIndex) {
        const auto& plan = plans[combinationIndex];
        std::vector<SearchParam> params;
        appendSearchParams(0, *plan.cascode, params);
        appendSearchParams(1, *plan.mirror, params);
        appendSearchParams(2, *plan.resistor, params);
        for (const auto& param : params) {
            std::string reason;
            if (!ValidateParameterConstraint(param.constraint, &reason)) {
                result.diagnostics.push_back(
                    {DiagCode::BadParam,
                     "master " + param.device->master + " 的参数约束 " +
                         param.semantic + " 无效：" + reason});
                return result;
            }
        }

        // ---- 初值：Cascode 按语义继承原管；其余取 PDK 参数域几何中点 ----
        std::vector<double> initial(params.size(), 0.0);
        for (std::size_t index = 0; index < params.size(); ++index) {
            double seed = geometricMidpoint(params[index].constraint);
            if (params[index].slot == 0) {
                // 原管实例参数（按原管 CDF 名读取）映射到新增管约束
                const ParameterConstraint* controlConstraint =
                    findConstraint(*plan.control, params[index].semantic);
                if (controlConstraint != nullptr) {
                    const auto text =
                        target->params.find(controlConstraint->cdf_name);
                    if (text != target->params.end()) {
                        bool parsed = false;
                        const double original = parseSuffixValue(text->second, parsed);
                        if (parsed) seed = original;
                    }
                }
            }
            if (!quantize(seed, params[index].constraint, initial[index])) {
                result.diagnostics.push_back(
                    {DiagCode::BadParam,
                     "初值无法量化到 PDK 合法取值：" + params[index].semantic});
                return result;
            }
        }

        // ---- 每个参数的粗搜索值集合：{min, 几何中点, 映射初值, max} 量化去重 ----
        std::vector<std::vector<double>> coarseValues(params.size());
        for (std::size_t index = 0; index < params.size(); ++index) {
            const ParameterConstraint& constraint = params[index].constraint;
            const double seeds[] = {constraint.minimum,
                                    geometricMidpoint(constraint), initial[index],
                                    constraint.maximum};
            for (const double seed : seeds) {
                double value = 0.0;
                if (!quantize(seed, constraint, value)) {
                    result.diagnostics.push_back(
                        {DiagCode::BadParam,
                         "粗搜索取值无法量化：" + params[index].semantic});
                    return result;
                }
                auto& values = coarseValues[index];
                if (std::find(values.begin(), values.end(), value) == values.end()) {
                    values.push_back(value);
                }
            }
        }

        std::map<std::string, std::size_t> cache;
        std::optional<std::size_t> localBest;
        std::size_t coarseEvaluations = 0;
        std::size_t refineEvaluations = 0;
        bool capExceeded = false;
        const std::size_t recordStart = records.size();
        const std::size_t coarseBudget = kMaxCoarseEvaluations / plans.size() +
            (combinationIndex < kMaxCoarseEvaluations % plans.size() ? 1 : 0);
        const std::size_t refineBudget = kMaxRefineEvaluations / plans.size() +
            (combinationIndex < kMaxRefineEvaluations % plans.size() ? 1 : 0);

        ElectricalConstraintRequest electricalRequest;
        electricalRequest.operation_id = request.template_request.operation_id;
        electricalRequest.polarity = polarity;
        electricalRequest.mirror_ref = {{}, layout.mirror_ref, plan.mirror->limits};
        electricalRequest.mirror_out = {{}, layout.mirror_out, plan.mirror->limits};
        electricalRequest.cascode_replica = {{}, layout.cas_rep, plan.cascode->limits};
        electricalRequest.control_replica = {{}, layout.ctrl_rep, plan.control->limits};
        electricalRequest.actual_control =
            {{}, request.target_instance, plan.control->limits};
        electricalRequest.actual_cascode = {{}, {}, plan.cascode->limits};
        electricalRequest.resistor = {request.template_request.operation_id,
                                      {}, layout.resistor, plan.resistor->master};
        electricalRequest.baseline_control = *baselineTarget;
        electricalRequest.max_branch_current_error = request.max_branch_current_error;
        electricalRequest.max_vbias_current = request.max_vbias_current;

        auto evaluate = [&](const std::vector<double>& point, bool refine) {
            const std::string signature = pointSignature(point);
            const auto cached = cache.find(signature);
            if (cached != cache.end()) return cached->second;

            EvaluationRecord record;
            record.point = point;
            // 量化参数写入 BiasSizing：Cascode/Mirror/电阻为当前搜索值，
            // Cascode Replica 复刻新增管，Control Replica 复刻原管。
            BiasSizing sizing;
            sizing.mirror_master = plan.mirror->master;
            sizing.resistor_master = plan.resistor->master;
            record.combination_id = combinationIndex + 1;
            record.coarse_budget = coarseBudget;
            record.refine_budget = refineBudget;
            record.phase = refine ? "refine" : "coarse";
            record.electrical_check = electricalRequest;
            sizing.element_parameters[layout.mirror_ref] = {};
            sizing.element_parameters[layout.mirror_out] = {};
            sizing.element_parameters[layout.resistor] = {};
            sizing.element_parameters[layout.cas_rep] = {};
            sizing.element_parameters[layout.ctrl_rep] = {};
            for (std::size_t index = 0; index < params.size(); ++index) {
                const std::string& cdf = params[index].constraint.cdf_name;
                const std::string text = FormatAutoBiasParameter(point[index]);
                if (params[index].slot == 0) {
                    sizing.cascode_parameters[cdf] = text;
                } else if (params[index].slot == 1) {
                    sizing.element_parameters[layout.mirror_ref][cdf] = text;
                    sizing.element_parameters[layout.mirror_out][cdf] = text;
                } else {
                    sizing.element_parameters[layout.resistor][cdf] = text;
                }
            }
            sizing.element_parameters[layout.cas_rep] = sizing.cascode_parameters;
            sizing.element_parameters[layout.ctrl_rep] = controlReplicaParams;
            record.sizing = sizing;
            for (const auto& name : kConstraintOrder) record.constraints[name] = true;

            Netlist candidate;
            std::string cascodeInstance;
            if (!assembleCandidate(sizing, candidate, cascodeInstance)) {
                record.constraints["params_legal"] = false;
                record.reason = "params_legal";
                records.push_back(std::move(record));
                cache.emplace(signature, records.size() - 1);
                return records.size() - 1;
            }

            DcEvaluationRequest evaluationRequest;
            evaluationRequest.candidate = std::move(candidate);
            evaluationRequest.root_subckt = request.root_subckt;
            evaluationRequest.target_instance = request.target_instance;
            evaluationRequest.cascode_instance = cascodeInstance;
            evaluationRequest.identity = request.nominal_identity;
            evaluationRequest.identity.topology_hash =
                ComputeNetlistTopologyHash(evaluationRequest.candidate);
            evaluationRequest.identity.parameter_hash =
                ComputeNetlistParameterHash(evaluationRequest.candidate);

            EvaluationRecord& stored = records.emplace_back(std::move(record));
            stored.cascode_instance = cascodeInstance;
            cache.emplace(signature, records.size() - 1);
            if (refine) {
                ++refineEvaluations;
            } else {
                ++coarseEvaluations;
            }
            stored.host_called = true;

            OperatingPointSnapshot snapshot;
            Diagnostic hostDiagnostic;
            stored.converged =
                host.Evaluate(evaluationRequest, snapshot, hostDiagnostic);
            if (!stored.converged) stored.host_message = hostDiagnostic.message;
            assess(stored, snapshot);

            if (stored.kept) {
                if (!localBest.has_value() ||
                    metricsBetter(stored.metrics, records[*localBest].metrics)) {
                    localBest = records.size() - 1;
                }
                if (!best.has_value() ||
                    metricsBetter(stored.metrics, records[*best].metrics)) {
                    best = records.size() - 1;
                }
            }
            return records.size() - 1;
        };

        // ---- 粗搜索：初值点 + 逐参数枚举值集合（中心随最优点移动） ----
        std::vector<double> center = initial;
        evaluate(center, false);
        for (std::size_t index = 0; index < params.size() && !capExceeded; ++index) {
            for (const double value : coarseValues[index]) {
                if (localBest.has_value()) center = records[*localBest].point;
                if (value == center[index]) continue;
                if (coarseEvaluations >= coarseBudget ||
                    coarseEvaluations + refineEvaluations >= kMaxTotalEvaluations) {
                    capExceeded = true;
                    break;
                }
                std::vector<double> point = center;
                point[index] = value;
                evaluate(std::move(point), false);
            }
        }

        // ---- 局部精搜索：逐参数尝试相邻两个合法量化值 ----
        auto neighbor = [&](std::size_t index, double current, int direction,
                            double& value) {
            const ParameterConstraint& constraint = params[index].constraint;
            double seed = current;
            if (!constraint.discrete_values.empty()) {
                std::vector<double> sorted = constraint.discrete_values;
                std::sort(sorted.begin(), sorted.end());
                const auto found =
                    std::find(sorted.begin(), sorted.end(), current);
                if (found == sorted.end()) return false;
                if (direction > 0) {
                    if (found + 1 == sorted.end()) return false;
                    seed = *(found + 1);
                } else {
                    if (found == sorted.begin()) return false;
                    seed = *(found - 1);
                }
            } else if (constraint.grid > 0.0) {
                seed = current + direction * constraint.grid;
            } else if (constraint.integer_only) {
                seed = current + direction;
            } else {
                return false;
            }
            if (!quantize(seed, constraint, value) || value == current) return false;
            return true;
        };

        bool improved = true;
        while (improved && !capExceeded) {
            improved = false;
            for (std::size_t index = 0; index < params.size() && !capExceeded;
                 ++index) {
                for (const int direction : {1, -1}) {
                    if (localBest.has_value()) center = records[*localBest].point;
                    const std::string bestBefore = localBest.has_value()
                        ? pointSignature(records[*localBest].point)
                        : std::string{};
                    double value = 0.0;
                    if (!neighbor(index, center[index], direction, value)) continue;
                    if (refineEvaluations >= refineBudget ||
                        coarseEvaluations + refineEvaluations >=
                            kMaxTotalEvaluations) {
                        capExceeded = true;
                        break;
                    }
                    std::vector<double> point = center;
                    point[index] = value;
                    evaluate(std::move(point), true);
                    const std::string bestAfter = localBest.has_value()
                        ? pointSignature(records[*localBest].point)
                        : std::string{};
                    if (bestAfter != bestBefore) improved = true;
                }
            }
        }

        result.nominal_evaluations += coarseEvaluations + refineEvaluations;
        ++result.searched_device_combinations;
        result.parameter_search_truncated = result.parameter_search_truncated || capExceeded;
        for (std::size_t index = recordStart; index < records.size(); ++index) {
            records[index].parameter_search_truncated = capExceeded;
        }
    }

    // ---- PVT复验：最优参数固定，逐Corner只查硬约束，不重选尺寸 ----
    if (best.has_value() && !request.pvt_corners.empty()) {
        const std::size_t chosenIndex = *best;
        result.pvt_ready = true;
        for (const auto& corner : request.pvt_corners) {
            EvaluationRecord record;
            record.point = records[chosenIndex].point;
            record.sizing = records[chosenIndex].sizing;
            record.cascode_instance = records[chosenIndex].cascode_instance;
            record.corner = corner;
            record.electrical_check = records[chosenIndex].electrical_check;
            record.combination_id = records[chosenIndex].combination_id;
            record.coarse_budget = records[chosenIndex].coarse_budget;
            record.refine_budget = records[chosenIndex].refine_budget;
            record.parameter_search_truncated = records[chosenIndex].parameter_search_truncated;
            record.phase = "pvt";
            for (const auto& name : kConstraintOrder) {
                record.constraints[name] = true;
            }
            Netlist candidate;
            std::string cascodeInstance;
            if (!assembleCandidate(record.sizing, candidate, cascodeInstance)) {
                record.constraints["params_legal"] = false;
                record.kept = false;
                record.reason = "params_legal";
            } else {
                DcEvaluationRequest evaluationRequest;
                evaluationRequest.candidate = std::move(candidate);
                evaluationRequest.root_subckt = request.root_subckt;
                evaluationRequest.target_instance = request.target_instance;
                evaluationRequest.cascode_instance = cascodeInstance;
                evaluationRequest.identity = request.nominal_identity;
                evaluationRequest.identity.corner = corner;
                evaluationRequest.identity.topology_hash =
                    ComputeNetlistTopologyHash(evaluationRequest.candidate);
                evaluationRequest.identity.parameter_hash =
                    ComputeNetlistParameterHash(evaluationRequest.candidate);
                record.host_called = true;
                ++result.pvt_evaluations;
                OperatingPointSnapshot snapshot;
                Diagnostic hostDiagnostic;
                record.converged =
                    host.Evaluate(evaluationRequest, snapshot, hostDiagnostic);
                if (!record.converged) record.host_message = hostDiagnostic.message;
                assess(record, snapshot);
            }
            result.pvt_results.push_back(
                {corner, record.kept,
                 record.kept ? std::string{} : record.reason});
            result.pvt_ready = result.pvt_ready && record.kept;
            records.push_back(std::move(record));
        }
    }

    // ---- 结果与确定性轨迹 ----
    for (std::size_t index = 0; index < records.size(); ++index) {
        const auto& record = records[index];
        result.trace_lines.push_back(traceLine(
            index + 1,
            record.corner.empty() ? request.nominal_identity.corner
                                  : record.corner,
            record, layout, best.has_value() && index == *best));
    }

    if (best.has_value()) {
        const EvaluationRecord& chosen = records[*best];
        result.ok = true;
        result.sizing = chosen.sizing;
        result.sizing.nominal_voltage = chosen.vbias_voltage;
        result.sizing.iq_delta = chosen.metrics.iq_delta;
        result.metrics = chosen.metrics;
        result.electrical_check = chosen.electrical_check;
        result.electrical_check.actual_cascode.leaf_name =
            chosen.cascode_instance;
        return result;
    }

    result.ok = false;
    if (!records.empty()) result.sizing = records.back().sizing;
    result.diagnostics.push_back(
        {DiagCode::BadParam,
         std::string(result.parameter_search_truncated
             ? "search_budget_exhausted: 预算内未找到满足硬约束的候选"
             : "no_feasible_evaluated_candidate: 已搜索全部master组合，未找到满足硬约束的候选") +
             "（组合 " + std::to_string(result.searched_device_combinations) + "/" +
             std::to_string(result.device_combinations) + "，名义评估 " +
             std::to_string(result.nominal_evaluations) +
             "/384），返回最后候选参数与逐项原因"});
    std::map<std::string, std::size_t> reasonCounts;
    for (const auto& record : records) ++reasonCounts[record.reason];
    for (const auto& name : kConstraintOrder) {
        const auto found = reasonCounts.find(reasonName(name));
        if (found != reasonCounts.end()) {
            result.diagnostics.push_back(
                {DiagCode::BadParam,
                 "constraint " + found->first + ": " +
                     std::to_string(found->second) + " candidate(s) rejected"});
        }
    }
    return result;
}

} // namespace st
