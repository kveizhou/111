#pragma once

#include "Types.h"

#include <filesystem>
#include <map>
#include <string>
#include <vector>

namespace st {

struct AnalysisIdentity {
    std::string dut_hash;
    std::string bench_hash;
    std::string pdk_version;
    std::string corner;
    std::string topology_hash;
    std::string parameter_hash;
    std::string solver_version;
};

struct MosOperatingPoint {
    double vd = 0.0;
    double vg = 0.0;
    double vs = 0.0;
    double vb = 0.0;
    double id = 0.0;
    double vgs = 0.0;
    double vds = 0.0;
    double vbs = 0.0;
    double vth = 0.0;
    double vdsat = 0.0;
    double cgg = 0.0;
};

// OP and PDK rating for the same actual resistor geometry and Corner.
// The site host must obtain ratings from the active PDK, not infer them from R.
struct ResistorOperatingPoint {
    std::string master;
    std::string geometry;
    double vpos = 0.0;
    double vneg = 0.0;
    double current = 0.0;
    double max_voltage = 0.0;
    double max_power = 0.0;   // 0 means PDK did not provide a power rating.
    double max_current = 0.0; // 0 means PDK did not provide a current rating.
    std::string rating_source;
};

struct OperatingPointSnapshot {
    AnalysisIdentity identity;
    std::map<std::string, MosOperatingPoint> mos;
    std::map<std::string, ResistorOperatingPoint> resistors;
    double total_supply_current = 0.0;
};

bool IsReusable(const OperatingPointSnapshot& snapshot,
                const AnalysisIdentity& requested);

// 按实例名取 MOS 工作点；不存在返回 nullptr。DC 求解器据此读取模板角色。
const MosOperatingPoint* FindMosOp(const OperatingPointSnapshot& snapshot,
                                   const std::string& name);

bool LoadOperatingPointTsv(const std::filesystem::path& identityTsv,
                           const std::filesystem::path& mosTsv,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics);

bool LoadOperatingPointTsv(const std::filesystem::path& identityTsv,
                           const std::filesystem::path& mosTsv,
                           const std::filesystem::path& resistorTsv,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics);

// Convenience overload for the standard identity.tsv + mos.tsv directory.
bool LoadOperatingPointTsv(const std::filesystem::path& directory,
                           OperatingPointSnapshot& snapshot,
                           std::vector<Diagnostic>& diagnostics);

bool WriteOperatingPointTsv(const std::filesystem::path& identityTsv,
                            const std::filesystem::path& mosTsv,
                            const OperatingPointSnapshot& snapshot,
                            std::vector<Diagnostic>& diagnostics);

bool WriteOperatingPointTsv(const std::filesystem::path& identityTsv,
                            const std::filesystem::path& mosTsv,
                            const std::filesystem::path& resistorTsv,
                            const OperatingPointSnapshot& snapshot,
                            std::vector<Diagnostic>& diagnostics);

} // namespace st
