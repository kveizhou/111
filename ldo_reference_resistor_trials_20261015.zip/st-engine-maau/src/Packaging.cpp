#include "st/Packaging.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

namespace st {
namespace {

std::string sanitizeName(const std::string& value)
{
    std::string result;
    result.reserve(value.size());
    for (const unsigned char character : value) {
        result.push_back(std::isalnum(character) || character == '_'
            ? static_cast<char>(character) : '_');
    }
    if (result.empty()) result = "TOPOLOGY";
    return result;
}

bool intersects(const std::set<std::string>& left, const std::set<std::string>& right)
{
    for (const auto& value : left) if (right.count(value) != 0) return true;
    return false;
}

bool sameInstance(const Instance& left, const Instance& right)
{
    return left.name == right.name && left.model == right.model &&
        left.nets == right.nets && left.params == right.params;
}

void appendUnique(std::vector<std::string>& values, std::set<std::string>& seen,
                  const std::string& value)
{
    if (!value.empty() && seen.insert(value).second) values.push_back(value);
}

struct Group {
    std::set<std::string> touched;
    std::vector<std::size_t> operation_indices;
};

std::string roleName(TerminalRole role)
{
    switch (role) {
    case TerminalRole::Drain: return "Drain";
    case TerminalRole::Gate: return "Gate";
    case TerminalRole::Source: return "Source";
    case TerminalRole::Bulk: return "Bulk";
    case TerminalRole::Positive: return "Positive";
    case TerminalRole::Negative: return "Negative";
    case TerminalRole::Substrate: return "Substrate";
    case TerminalRole::Well: return "Well";
    case TerminalRole::Other: return "Other";
    }
    return "Other";
}

std::vector<TerminalRole> terminalRoles(const DeviceDescriptor& descriptor)
{
    if (descriptor.terminal_roles_by_index.size() == descriptor.terminal_count) {
        return descriptor.terminal_roles_by_index;
    }
    std::vector<TerminalRole> roles(descriptor.terminal_count, TerminalRole::Other);
    for (const auto& [role, index] : descriptor.terminal_index) {
        if (index < roles.size()) roles[index] = role;
    }
    return roles;
}

bool validateMappedRange(const Instance& instance, const DeviceDescriptor& descriptor,
                         const std::string& normalized, double minimum, double maximum,
                         std::vector<Diagnostic>& diagnostics)
{
    const auto mapped = descriptor.normalized_to_cdf.find(normalized);
    if (mapped == descriptor.normalized_to_cdf.end()) return true;
    const auto value = instance.params.find(mapped->second);
    if (value == instance.params.end()) return true;
    bool parsed = false;
    const double number = parseSuffixValue(value->second, parsed);
    // CDF numeric bounds and engineering suffixes can round to adjacent doubles.
    // Match AutoBias's relative roundoff tolerance, without an absolute floor
    // (an absolute tolerance in metres could admit a real geometry change).
    const auto sameValue = [](double left, double right) {
        return std::isfinite(left) && std::isfinite(right) &&
            std::fabs(left - right) <= 1e-12 * std::max(std::fabs(left), std::fabs(right));
    };
    if (!parsed || !std::isfinite(number) ||
        (number < minimum && !sameValue(number, minimum)) ||
        (number > maximum && !sameValue(number, maximum))) {
        std::ostringstream detail;
        detail << std::setprecision(17) << " raw=" << value->second
               << " parsed=" << (parsed ? std::string{} : "INVALID:") << number
               << " min=" << minimum << " max=" << maximum;
        diagnostics.push_back({DiagCode::DeviceParameterOutOfRange,
            "封装内器件 " + instance.name + " 的PDK参数 " + mapped->second +
            " 超出允许范围或数值无效;" + detail.str()});
        return false;
    }
    return true;
}

bool validateInstanceForOa(const Instance& instance, const DeviceDescriptor*& descriptor,
                           const DeviceCatalog& catalog,
                           std::vector<Diagnostic>& diagnostics)
{
    descriptor = catalog.Find(instance.model);
    if (descriptor == nullptr || descriptor->oa_library.empty() ||
        descriptor->oa_cell.empty() || descriptor->oa_view.empty() ||
        descriptor->terminal_count == 0 ||
        descriptor->terminal_names_by_index.size() != descriptor->terminal_count ||
        instance.nets.size() != descriptor->terminal_count) {
        diagnostics.push_back({DiagCode::OaPlanInvalid,
            "封装内器件 " + instance.name + " 缺少PDK OA master或完整terminalOrder"});
        return false;
    }
    bool ok = true;
    ok = validateMappedRange(instance, *descriptor, "width",
        descriptor->limits.min_width, descriptor->limits.max_width, diagnostics) && ok;
    ok = validateMappedRange(instance, *descriptor, "length",
        descriptor->limits.min_length, descriptor->limits.max_length, diagnostics) && ok;
    ok = validateMappedRange(instance, *descriptor, "resistance",
        descriptor->limits.min_resistance, descriptor->limits.max_resistance, diagnostics) && ok;
    return ok;
}

} // namespace

PackageTopologyResult PackageTopologyVariant(
    const Netlist& baseline,
    const Netlist& flatVariant,
    const std::string& coreSubckt,
    const ChangeSet& changes,
    const ReplayResult& replay,
    const std::string& generatedCellPrefix,
    const std::string& generatedLibrary)
{
    PackageTopologyResult result;
    result.netlist = flatVariant;
    const auto* baseCore = baseline.find(coreSubckt);
    const auto* flatCore = flatVariant.find(coreSubckt);
    auto* packagedCore = result.netlist.find(coreSubckt);
    if (baseCore == nullptr || flatCore == nullptr || packagedCore == nullptr) {
        result.diagnostics.push_back({DiagCode::NotFound,
            "封装阶段找不到核心subckt " + coreSubckt});
        return result;
    }
    if (!replay.ok || changes.Changes().size() != replay.outcomes.size()) {
        result.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "封装阶段的Change Set与变换结果数量不一致"});
        return result;
    }
    if (generatedCellPrefix.empty() || generatedLibrary.empty()) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "生成子Cell的library和前缀不能为空"});
        return result;
    }

    std::map<std::string, std::string> originalByMember;
    for (const auto& instance : baseCore->instances) {
        originalByMember[instance.name] = instance.name;
    }
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        const auto& request = changes.Changes()[index].request;
        const auto origin = originalByMember.find(request.target.instance);
        if (request.type == TransformType::MosStack && origin != originalByMember.end()) {
            const auto originalName = origin->second;
            for (const auto& added : replay.outcomes[index].addedInstances) {
                originalByMember[added] = originalName;
            }
        }
    }

    std::vector<Group> groups;
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        Group incoming;
        incoming.operation_indices.push_back(index);
        incoming.touched.insert(changes.Changes()[index].request.target.instance);
        const auto& outcome = replay.outcomes[index];
        incoming.touched.insert(outcome.addedInstances.begin(), outcome.addedInstances.end());
        incoming.touched.insert(outcome.removedInstances.begin(), outcome.removedInstances.end());
        incoming.touched.insert(outcome.modifiedInstances.begin(), outcome.modifiedInstances.end());

        for (auto iterator = groups.begin(); iterator != groups.end();) {
            if (!intersects(iterator->touched, incoming.touched)) {
                ++iterator;
                continue;
            }
            incoming.touched.insert(iterator->touched.begin(), iterator->touched.end());
            incoming.operation_indices.insert(incoming.operation_indices.end(),
                iterator->operation_indices.begin(), iterator->operation_indices.end());
            iterator = groups.erase(iterator);
        }
        std::sort(incoming.operation_indices.begin(), incoming.operation_indices.end());
        groups.push_back(std::move(incoming));
    }
    std::sort(groups.begin(), groups.end(), [](const Group& left, const Group& right) {
        return left.operation_indices.front() < right.operation_indices.front();
    });

    std::set<std::string> packageCellNames;
    for (const auto& subckt : flatVariant.subckts) packageCellNames.insert(subckt.name);
    std::set<std::string> membersAcrossPackages;
    std::vector<Instance> wrappers;
    std::set<std::string> namesToRemove;

    for (std::size_t groupIndex = 0; groupIndex < groups.size(); ++groupIndex) {
        const auto& group = groups[groupIndex];
        GeneratedTopologyPackage package;
        std::ostringstream number;
        number << std::setw(4) << std::setfill('0') << groupIndex + 1;
        package.package_id = "PKG" + number.str();
        package.cell_name = sanitizeName(generatedCellPrefix) + "__" + package.package_id;
        while (!packageCellNames.insert(package.cell_name).second) package.cell_name += "_2";
        package.circuit.name = "oa_" + generatedLibrary + "__" + package.cell_name;

        for (const auto operationIndex : group.operation_indices) {
            package.operation_ids.push_back(
                changes.Changes()[operationIndex].request.operation_id);
        }

        for (const auto& instance : flatCore->instances) {
            if (group.touched.count(instance.name) == 0) continue;
            if (!membersAcrossPackages.insert(instance.name).second) {
                result.diagnostics.push_back({DiagCode::TargetConflict,
                    "实例 " + instance.name + " 被多个封装重复占用"});
                return result;
            }
            package.member_instances.push_back(instance.name);
            package.circuit.instances.push_back(instance);
            const auto origin = originalByMember.find(instance.name);
            if (origin != originalByMember.end()) {
                package.original_instance_by_member[instance.name] = origin->second;
            }
            namesToRemove.insert(instance.name);
        }
        if (package.circuit.instances.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "封装 " + package.package_id + " 没有可物化实例"});
            return result;
        }

        for (const auto operationIndex : group.operation_indices) {
            const auto& target = changes.Changes()[operationIndex].request.target.instance;
            if (baseCore->find(target) != nullptr) {
                if (std::find(package.replaced_parent_instances.begin(),
                              package.replaced_parent_instances.end(), target) ==
                    package.replaced_parent_instances.end()) {
                    package.replaced_parent_instances.push_back(target);
                }
                package.parent_instance_name = target;
            }
        }
        if (package.parent_instance_name.empty()) {
            for (const auto& instance : baseCore->instances) {
                if (group.touched.count(instance.name) != 0) {
                    package.parent_instance_name = instance.name;
                    package.replaced_parent_instances.push_back(instance.name);
                    break;
                }
            }
        }
        if (package.parent_instance_name.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "封装没有可替换的基线父实例"});
            return result;
        }

        std::set<std::string> boundary;
        boundary.insert(flatCore->pins.begin(), flatCore->pins.end());
        for (const auto& instance : baseCore->instances) {
            if (group.touched.count(instance.name) == 0) continue;
            boundary.insert(instance.nets.begin(), instance.nets.end());
        }
        for (const auto& instance : flatCore->instances) {
            if (group.touched.count(instance.name) != 0) continue;
            boundary.insert(instance.nets.begin(), instance.nets.end());
        }
        for (const auto operationIndex : group.operation_indices) {
            const auto& ports = replay.outcomes[operationIndex].external_ports;
            boundary.insert(ports.begin(), ports.end());
        }

        std::set<std::string> seenPins;
        for (const auto& original : baseCore->instances) {
            if (group.touched.count(original.name) == 0) continue;
            for (const auto& net : original.nets) {
                bool usedInside = false;
                for (const auto& instance : package.circuit.instances) {
                    usedInside = usedInside ||
                        std::find(instance.nets.begin(), instance.nets.end(), net) !=
                            instance.nets.end();
                }
                if (usedInside && boundary.count(net) != 0) {
                    appendUnique(package.circuit.pins, seenPins, net);
                }
            }
        }
        for (const auto& instance : package.circuit.instances) {
            for (const auto& net : instance.nets) {
                if (boundary.count(net) != 0) {
                    appendUnique(package.circuit.pins, seenPins, net);
                }
            }
        }
        if (package.circuit.pins.empty()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "封装 " + package.package_id + " 没有外部端口"});
            return result;
        }

        wrappers.push_back({package.parent_instance_name, package.circuit.pins,
                            package.circuit.name, {}});
        result.packages.push_back(std::move(package));
    }

    // 每个 FixedBias Cascode 操作的 bias 层级实例单独封装成 VBIAS 子Cell：
    // 独立 VBIAS%04d 计数器，不并入功能分组，也不替换任何基线实例。
    std::set<std::string> templateSubcktNames;
    std::size_t vbiasCounter = 0;
    for (std::size_t index = 0; index < changes.Changes().size(); ++index) {
        for (const auto& biasName : replay.outcomes[index].bias_instances) {
            const auto* flatInstance = flatCore->find(biasName);
            if (flatInstance == nullptr) {
                result.diagnostics.push_back({DiagCode::NotFound,
                    "封装阶段找不到bias实例 " + biasName});
                return result;
            }
            const auto* templateSubckt = flatVariant.find(flatInstance->model);
            if (templateSubckt == nullptr || templateSubckt->instances.empty()) {
                result.diagnostics.push_back({DiagCode::NotFound,
                    "封装阶段找不到VBIAS模板subckt " + flatInstance->model});
                return result;
            }
            GeneratedTopologyPackage package;
            ++vbiasCounter;
            std::ostringstream number;
            number << std::setw(4) << std::setfill('0') << vbiasCounter;
            package.package_id = "VBIAS" + number.str();
            package.cell_name = sanitizeName(generatedCellPrefix) + "__" + package.package_id;
            while (!packageCellNames.insert(package.cell_name).second) {
                package.cell_name += "_2";
            }
            package.circuit.name = "oa_" + generatedLibrary + "__" + package.cell_name;
            package.circuit.pins = templateSubckt->pins;
            package.circuit.instances = templateSubckt->instances;
            for (const auto& instance : templateSubckt->instances) {
                package.member_instances.push_back(instance.name);
            }
            package.parent_instance_name = biasName;
            package.operation_ids.push_back(changes.Changes()[index].request.operation_id);
            // wrapper 保持真实父层网（VHIGH/VLOW/VS_ORIG/VG_CTRL/输出网），
            // 与模板端口按位置对应，不假设 pin 名等于 net 名。
            wrappers.push_back({biasName, flatInstance->nets, package.circuit.name, {}});
            namesToRemove.insert(biasName);
            templateSubcktNames.insert(flatInstance->model);
            result.packages.push_back(std::move(package));
        }
    }

    // 模板定义载具已变成封装 circuit，从扁平结果里删掉，避免重复定义。
    auto& resultSubckts = result.netlist.subckts;
    resultSubckts.erase(
        std::remove_if(resultSubckts.begin(), resultSubckts.end(),
            [&](const Subckt& subckt) {
                return templateSubcktNames.count(subckt.name) != 0;
            }),
        resultSubckts.end());

    packagedCore->instances.erase(
        std::remove_if(packagedCore->instances.begin(), packagedCore->instances.end(),
            [&](const Instance& instance) { return namesToRemove.count(instance.name) != 0; }),
        packagedCore->instances.end());
    packagedCore->instances.insert(packagedCore->instances.end(), wrappers.begin(), wrappers.end());
    for (const auto& package : result.packages) result.netlist.subckts.push_back(package.circuit);
    return result;
}

PackageTopologyResult PackageSingleCandidateVariant(
    const Netlist& baseline,
    const Netlist& flatCandidate,
    const std::string& coreSubckt,
    const std::string& targetInstance,
    const std::string& generatedCellPrefix,
    const std::string& generatedLibrary)
{
    PackageTopologyResult failed;
    failed.netlist = flatCandidate;
    const auto* baseCore = baseline.find(coreSubckt);
    const auto* candidateCore = flatCandidate.find(coreSubckt);
    if (baseCore == nullptr || candidateCore == nullptr ||
        baseCore->find(targetInstance) == nullptr) {
        failed.diagnostics.push_back({DiagCode::NotFound,
            "DC候选封装找不到核心subckt或目标实例"});
        return failed;
    }

    TransformRequest request;
    request.operation_id = "dc_candidate";
    request.target = {"/", coreSubckt, targetInstance};
    request.type = TransformType::SameTypeCascode;
    CascodeTransformRequest payload;
    payload.subckt = coreSubckt;
    payload.target = targetInstance;
    request.payload = payload;
    ChangeSet changes;
    Diagnostic diagnostic;
    if (!changes.Confirm(request, diagnostic)) {
        failed.diagnostics.push_back(std::move(diagnostic));
        return failed;
    }

    TransformOutcome outcome;
    for (const auto& original : baseCore->instances) {
        const auto* candidate = candidateCore->find(original.name);
        if (candidate == nullptr) {
            outcome.removedInstances.push_back(original.name);
        } else if (!sameInstance(original, *candidate)) {
            outcome.modifiedInstances.push_back(original.name);
        }
    }
    for (const auto& candidate : candidateCore->instances) {
        if (baseCore->find(candidate.name) != nullptr) continue;
        // 新增实例的 model 若是候选网表内部 subckt，它是 VBIAS
        // 层级载具；其余才是功能封装内的物理器件。
        if (flatCandidate.find(candidate.model) != nullptr) {
            outcome.bias_instances.push_back(candidate.name);
        } else {
            outcome.addedInstances.push_back(candidate.name);
        }
    }
    if (outcome.modifiedInstances.empty() && outcome.addedInstances.empty()) {
        failed.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "DC候选与基线之间没有可封装的功能变化"});
        return failed;
    }

    ReplayResult replay;
    replay.ok = true;
    replay.applied_operation_ids.push_back(request.operation_id);
    replay.outcomes.push_back(std::move(outcome));
    return PackageTopologyVariant(baseline, flatCandidate, coreSubckt, changes,
                                  replay, generatedCellPrefix,
                                  generatedLibrary);
}

OaPlanBuildResult BuildPackagedOaMaterializationPlan(
    const Netlist& baseline,
    const PackageTopologyResult& packaged,
    const DeviceCatalog& catalog,
    const OaPlanBuildContext& context,
    const std::string& generatedLibrary)
{
    OaPlanBuildResult result;
    auto& plan = result.plan;
    plan.schema_version = 3;
    plan.source = context.source;
    plan.target = context.target;
    plan.clone_map = context.clone_map;
    plan.preview = context.preview;
    // Each wrapper terminal is connected by a labeled stub at its actual
    // symbol pin. The context's guessed, free-standing label wires can cross
    // those pins and short unrelated nets; they do not belong in this plan.
    if (!packaged.ok()) {
        result.diagnostics = packaged.diagnostics;
        return result;
    }
    if (generatedLibrary.empty()) {
        result.diagnostics.push_back({DiagCode::MissingInput,
            "生成封装子Cell的library不能为空"});
        return result;
    }

    std::string coreName;
    for (const auto& [subckt, hierarchy] : context.hierarchy_by_subckt) {
        if (hierarchy == "/" && baseline.find(subckt) != nullptr &&
            packaged.netlist.find(subckt) != nullptr) {
            coreName = subckt;
            break;
        }
    }
    if (coreName.empty()) {
        result.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "封装OA计划找不到根层核心subckt"});
        return result;
    }

    std::set<std::string> deleted;
    for (const auto& package : packaged.packages) {
        for (const auto& original : package.replaced_parent_instances) {
            if (deleted.insert(original).second) {
                plan.delete_instances.push_back({"/", original});
            }
        }
        const auto location = context.locations.find("/:" + package.parent_instance_name);
        if (location == context.locations.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "wrapper " + package.parent_instance_name + " 缺少根层放置坐标"});
            continue;
        }

        OaGeneratedCell generated;
        generated.package_id = package.package_id;
        generated.schematic = {generatedLibrary, package.cell_name, "schematic",
                               context.target.storage_path, {}};
        generated.symbol = {generatedLibrary, package.cell_name, "symbol",
                            context.target.storage_path, {}};
        const double halfHeight = std::max(1.0,
            0.5 * static_cast<double>(package.circuit.pins.size()));
        generated.symbol_lower_left = {-1.5, -halfHeight};
        generated.symbol_upper_right = {1.5, halfHeight};
        const std::string scope = "/@generated/" + package.package_id;

        OaCreateInstance wrapper;
        wrapper.hierarchy_path = "/";
        wrapper.name = package.parent_instance_name;
        wrapper.master = generated.symbol;
        wrapper.location = location->second;
        wrapper.expected_terminal_count = package.circuit.pins.size();
        // wrapper 连接按封装网表里的真实父层网映射：功能封装 nets==pins，
        // VBIAS 封装则是 VHIGH/VLOW/VS_ORIG/VG_CTRL 对应的真实轨网。
        const auto* packagedCore = packaged.netlist.find(coreName);
        const Instance* wrapperInstance = packagedCore == nullptr
            ? nullptr : packagedCore->find(package.parent_instance_name);
        if (wrapperInstance == nullptr ||
            wrapperInstance->model != package.circuit.name ||
            wrapperInstance->nets.size() != package.circuit.pins.size()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "wrapper " + package.parent_instance_name +
                " 在封装网表中缺失或端网数量与封装端口不一致"});
            continue;
        }
        for (std::size_t pinIndex = 0; pinIndex < package.circuit.pins.size(); ++pinIndex) {
            wrapper.connections.push_back({"Other", package.circuit.pins[pinIndex],
                                           wrapperInstance->nets[pinIndex]});
        }
        plan.create_instances.push_back(std::move(wrapper));

        struct Endpoint {
            std::string instance;
            std::string terminal;
            TerminalRole role = TerminalRole::Other;
        };
        std::map<std::string, std::vector<Endpoint>> endpointsByNet;
        constexpr std::size_t kRowsPerColumn = 20;
        constexpr double kColumnPitch = 6.0;
        constexpr double kRowPitch = 3.0;
        for (std::size_t index = 0; index < package.circuit.instances.size(); ++index) {
            const auto& instance = package.circuit.instances[index];
            const DeviceDescriptor* descriptor = nullptr;
            if (!validateInstanceForOa(instance, descriptor, catalog, result.diagnostics)) {
                continue;
            }
            OaCreateInstance create;
            create.hierarchy_path = scope;
            create.name = instance.name;
            create.master = {descriptor->oa_library, descriptor->oa_cell,
                             descriptor->oa_view};
            create.location = {
                kColumnPitch * static_cast<double>(index / kRowsPerColumn),
                -kRowPitch * static_cast<double>(index % kRowsPerColumn)};
            create.expected_terminal_count = descriptor->terminal_count;
            create.cdf_parameters = instance.params;
            const auto origin = package.original_instance_by_member.find(instance.name);
            const auto* original = origin == package.original_instance_by_member.end()
                ? nullptr : baseline.find(coreName)->find(origin->second);
            if (original && isMosKind(descriptor->kind) &&
                original->model == instance.model && original->params == instance.params) {
                create.property_source = context.target;
                create.property_source_instance = original->name;
            }
            const auto resistance = descriptor->parameter_constraints.find("resistance");
            const bool nativeResistanceTrials = descriptor->native_parameter_trials &&
                resistance != descriptor->parameter_constraints.end() &&
                resistance->second.discrete_values.size() > 1;
            if ((context.structure_only || nativeResistanceTrials) && descriptor->kind == DeviceKind::Resistor && !original) {
                for (const auto& mapping : descriptor->normalized_to_cdf) {
                    if (instance.params.count(mapping.second) == 0) {
                        create.allowed_extra_cdf_parameters.insert(mapping.second);
                    }
                }
            }
            const auto roles = terminalRoles(*descriptor);
            for (std::size_t terminal = 0; terminal < instance.nets.size(); ++terminal) {
                const auto& terminalName = descriptor->terminal_names_by_index[terminal];
                const auto& net = instance.nets[terminal];
                create.connections.push_back({roleName(roles[terminal]), terminalName, net});
                endpointsByNet[net].push_back({instance.name, terminalName, roles[terminal]});
            }
            generated.create_instances.push_back(std::move(create));
        }

        std::set<std::string> externalPins(package.circuit.pins.begin(),
                                           package.circuit.pins.end());
        for (const auto& [net, endpoints] : endpointsByNet) {
            if (externalPins.count(net) != 0 || endpoints.size() < 2) continue;
            const bool seriesNode = std::all_of(endpoints.begin(), endpoints.end(),
                [](const Endpoint& endpoint) {
                    return endpoint.role == TerminalRole::Drain ||
                           endpoint.role == TerminalRole::Source ||
                           endpoint.role == TerminalRole::Positive ||
                           endpoint.role == TerminalRole::Negative;
                });
            if (!seriesNode) continue;
            for (std::size_t index = 1; index < endpoints.size(); ++index) {
                generated.direct_wires.push_back({scope, net,
                    endpoints[index - 1].instance, endpoints[index - 1].terminal,
                    endpoints[index].instance, endpoints[index].terminal});
            }
        }

        for (std::size_t index = 0; index < package.circuit.pins.size(); ++index) {
            const bool left = index % 2 == 0;
            const double y = halfHeight - 0.5 -
                static_cast<double>(index / 2);
            generated.create_ports.push_back({scope, package.circuit.pins[index],
                "inputOutput", package.circuit.pins[index],
                {left ? -8.0 : 8.0, y}});
        }
        plan.generated_cells.push_back(std::move(generated));
    }

    // Context locations use a primitive-sized grid. Generated symbols grow
    // with their port count; include the pin and stub reach when separating
    // wrappers. Keep X in the isolated area beyond the source schematic.
    constexpr double kPinAndStubMargin = 1.0;
    constexpr double kClearGap = 0.25;
    for (std::size_t i = 0; i < plan.create_instances.size(); ++i) {
        auto& current = plan.create_instances[i];
        const auto& symbol = plan.generated_cells[i];
        for (std::size_t pass = 0; pass < i; ++pass) {
            bool moved = false;
            for (std::size_t j = 0; j < i; ++j) {
                const auto& prior = plan.create_instances[j];
                const auto& priorSymbol = plan.generated_cells[j];
                const bool separateX =
                    current.location.x + symbol.symbol_upper_right.x + kPinAndStubMargin <
                        prior.location.x + priorSymbol.symbol_lower_left.x - kPinAndStubMargin ||
                    prior.location.x + priorSymbol.symbol_upper_right.x + kPinAndStubMargin <
                        current.location.x + symbol.symbol_lower_left.x - kPinAndStubMargin;
                const bool separateY =
                    current.location.y + symbol.symbol_upper_right.y + kPinAndStubMargin <
                        prior.location.y + priorSymbol.symbol_lower_left.y - kPinAndStubMargin ||
                    prior.location.y + priorSymbol.symbol_upper_right.y + kPinAndStubMargin <
                        current.location.y + symbol.symbol_lower_left.y - kPinAndStubMargin;
                if (separateX || separateY) continue;
                current.location.y = prior.location.y + priorSymbol.symbol_lower_left.y -
                    symbol.symbol_upper_right.y - 2.0 * kPinAndStubMargin - kClearGap;
                moved = true;
            }
            if (!moved) break;
        }
    }
    const auto validation = ValidateOaPlan(plan);
    result.diagnostics.insert(result.diagnostics.end(), validation.begin(), validation.end());
    return result;
}

} // namespace st
