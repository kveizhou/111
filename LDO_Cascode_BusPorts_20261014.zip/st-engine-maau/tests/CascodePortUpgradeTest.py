"""Known runtime update with preserved source manifest and real file checks."""
import contextlib
import copy
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import CascodeExperimentResumeTest as resume_fixture


class PortUpgradeTest(unittest.TestCase):
    def fixture(self,root):
        root=root.resolve()
        candidate,manifest=resume_fixture.ResumeTest().fixture(root)
        release=json.loads((ROOT/'scripts/cascode_bus_ports_update.json').read_text())
        runtime=str(ROOT/'server/site/cascode_runtime.py')
        manifest['runtime']=runtime
        manifest['file_sha256'][runtime]=release['before_sha256']
        raw=candidate/'work/analysis/baseline_op/raw_op/st-op-simulation.test'
        dut=raw/'dut_oa';(dut/'generated').mkdir(parents=True)
        body='M (A\\<0\\> A\\<1\\> VDD VDD) n\n'
        bench=root/'bench.scs';bench.write_text('simulator lang=spectre\nsubckt core A\\<1\\> A\\<0\\> VDD\n'+body+'ends core\n')
        (raw/'bench.scs').write_text(bench.read_text())
        (dut/'generated/input.scs').write_text('simulator lang=spectre\n'+body)
        (dut/'runtime.ocn').write_text('design("L" "core" "schematic")\n')
        (dut/'ports.txt').write_text('A<1:0>\nVDD\n')
        (dut/'runtime.done').write_text('OK\n')
        (raw/'export_dut.log').write_text('actual OA DUT/Bench port mismatch')
        bundle=root/'bundle.json';bundle.write_text(json.dumps(dict(source_subckt='core',source=dict(lib='L',cell='core',view='schematic'),bench_netlist=str(bench),variables={})))
        profile=Path(manifest['rules']);profile.write_text(json.dumps(dict(validation_scope='experimental_dc',validated_baseline_bundle=str(bundle))))
        for p in (profile,bench,bundle):manifest['file_sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
        original=candidate/'work/analysis/standalone_inputs/provider_inputs.json'
        original.write_text(json.dumps(manifest))
        return candidate,manifest,original

    def test_upgrade_preflight_then_generate_keeps_original_manifest_and_frozen_inputs(self):
        m=importlib.import_module('resume_cascode_experiment')
        self.assertTrue(hasattr(m,'port_updated_inputs'),'specific port runtime upgrade missing')
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            candidate,manifest,original=self.fixture(Path(tmp));calls=[]
            protected={str(p):p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
            def fail_after_launch(stage,argv,output,timeout,env=None):
                calls.append((argv,env))
                active=json.loads(Path(env['ST_SITE_INPUTS_MANIFEST']).read_text())
                expected=copy.deepcopy(manifest)
                runtime=manifest['runtime'];expected['file_sha256'][runtime]=hashlib.sha256(Path(runtime).read_bytes()).hexdigest()
                self.assertEqual(active,expected)
                self.assertEqual(argv,[str(ROOT/'build/bin/st_circuit_tool'),'generate','--session',str(candidate/'work')])
                log=output/'generate.log';log.write_text('next native stage')
                raise m.StageFailure(stage,3,log)
            self.assertEqual(m.resume(candidate,10,runner=fail_after_launch,upgrade_port_reader=True),2)
            self.assertEqual(m.resume(candidate,10,runner=fail_after_launch),2)
            self.assertEqual(len(calls),2)
            self.assertTrue(all(Path(p).read_bytes()==v for p,v in protected.items()))
            statuses=[json.loads(p.read_text()) for p in candidate.glob('resume_generate_*/run_status.json')]
            self.assertTrue(all(s['provider_manifest'] for s in statuses))

    def test_unrelated_drift_unknown_predecessor_and_existing_old_op_stop_before_launch(self):
        m=importlib.import_module('resume_cascode_experiment')
        self.assertTrue(hasattr(m,'port_updated_inputs'),'specific port runtime upgrade missing')
        for bad in ('unrelated_drift','unknown_before','old_op','lost_port','different_bench'):
            with self.subTest(bad=bad),tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
                candidate,manifest,original=self.fixture(Path(tmp))
                raw=next(candidate.glob('work/analysis/baseline_op/raw_op/st-op-simulation.*'))
                if bad=='unrelated_drift':Path(manifest['tech']).write_text('changed')
                elif bad=='unknown_before':
                    manifest['file_sha256'][manifest['runtime']]='0'*64;original.write_text(json.dumps(manifest))
                elif bad=='old_op':(candidate/'work/analysis/baseline_op/identity.tsv').write_text('old')
                elif bad=='lost_port':(raw/'dut_oa/generated/input.scs').write_text('M (A\\<0\\> VDD VDD VDD) n\n')
                else:(raw/'bench.scs').write_text('changed')
                with self.assertRaises((ValueError,OSError)):
                    m.resume(candidate,10,runner=lambda *a,**kw:self.fail('must not launch'),upgrade_port_reader=True)
                self.assertFalse(list(candidate.glob('resume_generate_*')))


if __name__=='__main__':unittest.main()
