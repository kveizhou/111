#!/usr/bin/env python3
"""Versioned formal Cadence adapter; old sessions retain cadence_runtime.py."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from cadence_runtime import executable
from dc_results import validate_query, query_script, consume_query
from site_data import read_json, write_json


def fingerprint(directory):
    return {str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(Path(directory).rglob('*')) if p.is_file()}


def native(argv, directory, log, timeout):
    # Same process-group timeout handling as the proven saved-DC path.
    from collect_cascode_batch import command
    if timeout<=0:raise ValueError('native timeout must be positive')
    command(argv,Path(directory),dict(os.environ),timeout,Path(log))


def require_dc_psf(psf):
    if not (psf/'dcOpInfo.info').is_file() or not (psf/'dcOpInfo.info').stat().st_size or not any(
        (psf/name).is_file() and (psf/name).stat().st_size for name in ('dcOp.dc','dc.dc')):
        raise ValueError('required DC PSF files missing or empty')


def port_key(name):
    # Compare only bit-name escaping, never arbitrary identifier escapes.
    bit = re.fullmatch(r'([^<>\\\s]+)\\<(-?\d+)\\>', name)
    return bit[1] + '<' + bit[2] + '>' if bit else name


def expand_oa_ports(ports):
    expanded = []
    for name in ports:
        bus = re.fullmatch(r'([^<>\\\s]+)<(-?\d+):(-?\d+)>', name)
        if not bus:
            expanded.append(name)
            continue
        first, last = int(bus[2]), int(bus[3])
        if abs(last - first) > 4095:
            raise ValueError('OA bus too wide for explicit port binding: ' + name)
        step = 1 if last >= first else -1
        expanded.extend(bus[1] + '<' + str(i) + '>' for i in range(first, last + step, step))
    return expanded


def wrap_oa_dut(text, name, physical_ports, expected_ports, bench_variables=(),
                baseline_text=None, source_subckt=None):
    """Compare OA terminal objects to bit ports; retain exact Spectre binding."""
    from cadence_runtime import wrap_dut
    from op_provider import parse_deck
    expanded = expand_oa_ports(physical_ports)
    physical_keys = [port_key(p) for p in expanded]
    expected_keys = [port_key(p) for p in expected_ports]
    if len(set(physical_keys)) != len(physical_keys) or len(set(expected_keys)) != len(expected_keys):
        raise ValueError('duplicate/overlapping OA or Bench bit ports')
    if set(physical_keys) != set(expected_keys):
        raise ValueError('actual OA DUT/Bench bit port mismatch: ' + json.dumps(dict(
            oa_only=sorted(set(physical_keys)-set(expected_keys)),
            bench_only=sorted(set(expected_keys)-set(physical_keys)))))
    by_key = dict(zip(expected_keys, expected_ports))
    physical_spectre = [by_key[key] for key in physical_keys]
    deck = parse_deck(text)
    definition = deck['definitions'].get(name)
    instances = definition['instances'] if definition else deck['top']
    nodes = {node for instance in instances for node in instance['nodes']}
    for node in nodes:
        key = port_key(node)
        if key in by_key and node != by_key[key]:
            raise ValueError('exported node spelling differs from Bench binding: ' + node)
    evidence = dict(schema='oa-bus-port-binding-v1', oa_port_count=len(physical_ports),
                    expanded_port_count=len(expanded), bench_port_count=len(expected_ports),
                    bench_port_order=list(expected_ports),
                    oa_expanded_to_bench=physical_spectre, unused_in_both=[])
    if baseline_text is not None:
        original = parse_deck(baseline_text)['definitions'][source_subckt]
        if original['ports'] != expected_ports:
            raise ValueError('baseline port order differs from requested binding')
        original_nodes = {node for instance in original['instances'] for node in instance['nodes']}
        missing = sorted((set(expected_ports) & original_nodes) - nodes)
        if missing:
            raise ValueError('connected baseline port missing from exported DUT: ' + json.dumps(missing))
        evidence['unused_in_both'] = [p for p in expected_ports if p not in original_nodes and p not in nodes]
    # Preserve the exact Bench header order and every exported body token.
    wrapped = wrap_dut(text, name, physical_spectre, expected_ports, bench_variables)
    return wrapped, evidence


def read_psf(args):
    psf=Path(args.psf_dir).resolve();output=Path(args.output).resolve()
    if output.exists():raise ValueError('raw output already exists')
    require_dc_psf(psf)
    request=validate_query(read_json(args.request));before=fingerprint(psf)
    init=Path(os.environ['ST_SKILL_INIT']).resolve()
    if not init.is_file():raise ValueError('native init missing')
    directory=output.parent/'psf_reader';directory.mkdir()
    script=directory/'runtime.ocn';script.write_text(query_script(psf,request,init,directory))
    if args.cds_path:
        cds=Path(args.cds_path).resolve()/'cds.lib'
        if not cds.is_file():raise ValueError('cds.lib missing')
        import json
        (directory/'cds.lib').write_text('INCLUDE '+json.dumps(str(cds))+'\n')
    try:
        native([executable('ST_OCEAN_BIN','ocean'),'-nograph','-restore',str(script)],directory,directory/'ocean.log',args.timeout)
        marker=directory/'runtime.done'
        if not marker.is_file() or marker.read_text().strip()!='OK':raise ValueError('formal PSF completion marker missing')
        with (directory/'nodes.tsv').open() as f:nodes=list(csv.DictReader(f,delimiter='\t'))
        with (directory/'ops.tsv').open() as f:ops=list(csv.DictReader(f,delimiter='\t'))
        raw,sources=consume_query(request,nodes,ops)
    finally:
        if before!=fingerprint(psf):raise ValueError('PSF changed during formal read')
    write_json(str(output)+'.sources.json',dict(query=request,psf_sha256=before,sources=sources,
        intrinsic_op_preserved=True,terminal_differences_computed_by_consumer=True))
    with output.open('x',newline='') as f:
        writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['signal','value'])
        writer.writerows((key,format(value,'.17g')) for key,value in sorted(raw.items()))


def netlist(args):
    from baseline_bundle import load_bundle
    from op_provider import parse_deck
    bundle=load_bundle(args.baseline_bundle)
    if args.view!='schematic':raise ValueError('actual candidate export requires schematic view')
    if args.source_subckt!=bundle['source_subckt'] or Path(args.ports_from).read_text()!=Path(bundle['bench_netlist']).read_text():
        raise ValueError('candidate port binding differs from baseline bundle')
    output=Path(args.output).resolve()
    if output.exists():raise ValueError('OA export output already exists')
    work=Path(args.work_dir).resolve();work.mkdir(parents=True,exist_ok=True)
    if any(work.iterdir()):raise ValueError('candidate OA work directory must be empty')
    cds=Path(args.cds_path).resolve()/'cds.lib'
    if not cds.is_file():raise ValueError('candidate cds.lib missing')
    q=json.dumps;ports=work/'ports.txt';generated=work/'generated'
    (work/'cds.lib').write_text('INCLUDE '+q(str(cds))+'\n')
    code='load('+q(str(Path(os.environ['ST_SKILL_INIT']).resolve()))+')\n'
    code+='envSetVal("asimenv.startup" "projectDir" \'string '+q(str(generated))+')\n'
    code+="simulator('spectre)\ndesign("+' '.join(q(v) for v in (args.lib,args.cell,args.view))+')\n'
    code+='modelFile('+' '.join("'("+q(m['model_file'])+' '+q(m['section_name'])+')' for m in bundle['models'])+')\n'
    if bundle['definition_files']:code+='definitionFile('+' '.join(q(p) for p in bundle['definition_files'])+')\n'
    for key,value in bundle['variables'].items():code+='desVar('+q(key)+' '+q(str(value))+')\n'
    code+='temp('+str(bundle['temperature'])+")\nhostMode('local)\ncreateNetlist(?display nil)\n"
    code+='cv=dbOpenCellViewByType('+' '.join(q(v) for v in (args.lib,args.cell,args.view))+' "" "r")\n'
    code+='unless(cv error("Cannot read actual candidate ports"))\np=outfile('+q(str(ports))+')\n'
    code+='foreach(term cv~>terminals fprintf(p "%s\\n" term~>name))\nclose(p)\ndbClose(cv)\n'
    code='procedure(stCandidateExport()\n'+code+'t)\nresult=errset(stCandidateExport() t)\n'
    code+='when(and(result car(result)) p=outfile('+q(str(work/'runtime.done'))+') fprintf(p "OK\\n") close(p))\nexit()\n'
    script=work/'runtime.ocn';script.write_text(code)
    native([executable('ST_OCEAN_BIN','ocean'),'-nograph','-restore',str(script)],work,work/'ocean.log',args.timeout)
    if not (work/'runtime.done').is_file() or (work/'runtime.done').read_text().strip()!='OK':raise ValueError('candidate OA export incomplete')
    paths=list(generated.rglob('input.scs'))
    if len(paths)!=1:raise ValueError('candidate actual OA input.scs missing or ambiguous')
    expected=parse_deck(Path(bundle['bench_netlist']).read_text())['definitions'][args.source_subckt]['ports']
    text,port_binding=wrap_oa_dut(paths[0].read_text(),args.cell,ports.read_text().splitlines(),expected,
        set(bundle['variables']),baseline_text=Path(bundle['bench_netlist']).read_text(),source_subckt=args.source_subckt)
    print('PORT_BINDING=BUS_BITS_VERIFIED OA='+str(port_binding['oa_port_count'])+
          ' BITS='+str(port_binding['expanded_port_count']))
    print('PORTS_UNUSED_IN_BOTH='+json.dumps(port_binding['unused_in_both']))
    load_bundle(args.baseline_bundle)
    output.write_text(text)
    write_json(str(output)+'.origin.json',dict(working_directory=str(paths[0].parent),dc_test_name='',
        baseline_bundle_sha256=bundle['_bundle_sha256'],actual_oa=[args.lib,args.cell,args.view],port_binding=port_binding))


def simulate(args):
    from baseline_bundle import load_bundle, verify_candidate_simulator
    from read_cascode_solver_settings import effective_controls, check_launch
    bundle=load_bundle(args.baseline_bundle)
    if not bundle['launch_contract'].get('complete'):raise ValueError('saved launch settings have unresolved mappings; inspect omitted_launch_options')
    deck=Path(args.netlist).resolve();before=hashlib.sha256(deck.read_bytes()).hexdigest()
    effective_controls(deck.read_text(),bundle['selected_forms'],bundle['temperature'])
    spectre=executable('ST_SPECTRE_BIN','spectre')
    verify_candidate_simulator(bundle,spectre)
    psf=Path(args.psf_dir).resolve();psf.mkdir(parents=True,exist_ok=False)
    argv=[spectre,str(deck),'+escchars','-format','psfbin','-raw',str(psf)]+bundle['launch_contract']['argv']
    write_json(str(args.log)+'.launch.json',dict(argv=argv,baseline_bundle_sha256=bundle['_bundle_sha256'],netlist_sha256=before))
    native(argv,deck.parent,args.log,args.timeout)
    log=Path(args.log).read_text(errors='replace')
    verify_candidate_simulator(bundle,spectre,log)
    check_launch(bundle['selected_forms'],log)
    require_dc_psf(psf)
    if hashlib.sha256(deck.read_bytes()).hexdigest()!=before:raise ValueError('candidate deck changed during simulation')
    load_bundle(args.baseline_bundle)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['read-psf','netlist','simulate'])
    for name in ('lib','cell','view','mode','cds-path','work-dir','output','netlist','psf-dir','log','ports-from','source-subckt','request','baseline-bundle'):
        parser.add_argument('--'+name,default='')
    parser.add_argument('--timeout',type=int,default=600)
    args=parser.parse_args()
    try:
        if args.command=='read-psf':read_psf(args)
        elif args.command=='netlist':netlist(args)
        else:simulate(args)
        return 0
    except (ValueError,OSError,KeyError,TypeError,subprocess.SubprocessError) as error:
        print('Cascode Cadence runtime: '+str(error),file=sys.stderr);return 70


if __name__=='__main__':sys.exit(main())
