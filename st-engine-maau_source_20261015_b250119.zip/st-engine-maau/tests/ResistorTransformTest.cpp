#include "st/Transform.h"

#include <cmath>
#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

bool near(double left, double right, double tolerance = 1e-9)
{
    return std::fabs(left - right) <= tolerance;
}

st::DeviceCatalog catalog(bool finiteRange = true)
{
    st::DeviceCatalog result;
    st::Diagnostic diagnostic;

    st::DeviceDescriptor mos;
    mos.master = "pmos_core";
    mos.kind = st::DeviceKind::MosP;
    mos.terminal_count = 4;
    // 非标准物理顺序：G/B/D/S。
    mos.terminal_index = {
        { st::TerminalRole::Gate, 0 },
        { st::TerminalRole::Bulk, 1 },
        { st::TerminalRole::Drain, 2 },
        { st::TerminalRole::Source, 3 },
    };
    result.Add(mos, diagnostic);

    st::DeviceDescriptor mos3;
    mos3.master = "pmos_three_pin";
    mos3.kind = st::DeviceKind::MosP;
    mos3.terminal_count = 3;
    mos3.terminal_names_by_index = {"G", "D", "S"};
    mos3.terminal_index = {
        { st::TerminalRole::Gate, 0 },
        { st::TerminalRole::Drain, 1 },
        { st::TerminalRole::Source, 2 },
    };
    result.Add(mos3, diagnostic);

    st::DeviceDescriptor unresolvedFourth = mos3;
    unresolvedFourth.master = "pmos_four_pin_unresolved";
    unresolvedFourth.terminal_count = 4;
    unresolvedFourth.terminal_names_by_index = {"G", "D", "S", "X"};
    result.Add(unresolvedFourth, diagnostic);

    st::DeviceDescriptor resistor2;
    resistor2.master = "r2_pdk";
    resistor2.kind = st::DeviceKind::Resistor;
    resistor2.terminal_count = 2;
    // 非标准物理顺序：负端在前，正端在后。
    resistor2.terminal_index = {
        { st::TerminalRole::Negative, 0 },
        { st::TerminalRole::Positive, 1 },
    };
    resistor2.limits.min_resistance = 10.0;
    resistor2.limits.max_resistance = finiteRange
        ? 1e6 : std::numeric_limits<double>::infinity();
    result.Add(resistor2, diagnostic);

    st::DeviceDescriptor resistor3;
    resistor3.master = "r3_pdk";
    resistor3.kind = st::DeviceKind::Resistor;
    resistor3.terminal_count = 3;
    // 物理顺序：SUB/P/N。
    resistor3.terminal_index = {
        { st::TerminalRole::Substrate, 0 },
        { st::TerminalRole::Positive, 1 },
        { st::TerminalRole::Negative, 2 },
    };
    resistor3.limits.min_resistance = 10.0;
    resistor3.limits.max_resistance = 1e6;
    result.Add(resistor3, diagnostic);
    return result;
}

st::Netlist circuit(bool collisions = false)
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "ldo";
    core.instances.push_back({ "MP", { "VGP", "PVDD", "VOUT", "PVDD" },
        "pmos_core", { { "w", "20u" }, { "l", "180n" } } });
    if (collisions) {
        core.instances.push_back({ "MP_RS", { "PVDD", "VOUT" }, "r2_pdk", {} });
        core.instances.push_back({ "KEEP", { "VGP", "PVDD", "MP_RS_INT", "PVDD" },
            "pmos_core", {} });
    }
    netlist.subckts.push_back(core);
    return netlist;
}

st::ResistorTransformRequest request(std::string master = "r2_pdk")
{
    st::ResistorTransformRequest result;
    result.subckt = "ldo";
    result.target = "MP";
    result.requested_resistance = 1000.0;
    result.resistor.master = std::move(master);
    result.resistor.resistance_parameter = "r";
    result.resistor.grid = 0.5;
    result.search_lower_factor = 0.5;
    result.search_upper_factor = 2.0;
    return result;
}

} // namespace

int main()
{
    const auto devices = catalog();

    auto normal = circuit();
    const auto originalParams = normal.find("ldo")->find("MP")->params;
    auto normalResult = st::applyResistor(normal, request(), devices);
    auto* normalCore = normal.find("ldo");
    auto* retainedMos = normalCore->find("MP");
    auto* resistor = normalCore->find("MP_RS");
    CHECK(normalResult.ok() && retainedMos != nullptr && resistor != nullptr &&
          normalResult.removedInstances.empty(),
        "Source串联电阻保留原MOS，只新增一只PDK电阻");
    CHECK(retainedMos && retainedMos->nets ==
            std::vector<std::string>({ "VGP", "PVDD", "VOUT", "MP_RS_INT" }) &&
          retainedMos->params == originalParams,
        "原MOS的Gate/Bulk/Drain和参数不变，只把Source改接内部节点");
    CHECK(resistor && resistor->nets ==
            std::vector<std::string>({ "PVDD", "MP_RS_INT" }),
        "电阻按PDK的N/P物理顺序串在内部节点与原Source之间");
    CHECK(resistor && resistor->params.at("r") == "1k",
        "用户阻值按PDK网格量化");
    CHECK(near(normalResult.numeric_outputs.at("R_seed"), 1000.0) &&
            near(normalResult.numeric_outputs.at("R_actual"), 1000.0),
        "结果同时回报选中的初值和实际量化值");
    CHECK(near(normalResult.parameter_ranges.at("MP_RS.r").minimum, 500.0) &&
            near(normalResult.parameter_ranges.at("MP_RS.r").maximum, 2000.0),
        "后续Sizing范围以种子比例和PDK硬范围的交集给出");

    st::Netlist threePinMos;
    st::Subckt threePinCore;
    threePinCore.name = "ldo";
    threePinCore.instances.push_back({"MP3", {"CTRL", "VOUT", "PVDD"},
        "pmos_three_pin", {{"w", "20u"}, {"l", "180n"}}});
    threePinMos.subckts.push_back(threePinCore);
    auto threePinRequest = request();
    threePinRequest.target = "MP3";
    const auto threePinOriginalParams = threePinCore.instances[0].params;
    const auto threePinResult = st::applyResistor(threePinMos, threePinRequest, devices);
    const auto* threePinRetained = threePinMos.find("ldo")->find("MP3");
    const auto* threePinResistor = threePinMos.find("ldo")->find("MP3_RS");
    CHECK(threePinResult.ok() && threePinRetained && threePinResistor &&
          threePinRetained->nets ==
              std::vector<std::string>({"CTRL", "VOUT", "MP3_RS_INT"}) &&
          threePinRetained->params == threePinOriginalParams &&
          threePinResistor->nets ==
              std::vector<std::string>({"PVDD", "MP3_RS_INT"}),
          "三端MOS保留原Gate/Drain及参数，仅在PDK证明的Source串真实电阻");

    st::Netlist unresolvedFourPin;
    st::Subckt unresolvedCore;
    unresolvedCore.name = "ldo";
    unresolvedCore.instances.push_back({"MP4", {"CTRL", "VOUT", "PVDD", "WELL"},
        "pmos_four_pin_unresolved", {}});
    unresolvedFourPin.subckts.push_back(unresolvedCore);
    auto unresolvedRequest = request();
    unresolvedRequest.target = "MP4";
    const auto unresolvedBefore = st::emitSpectre(unresolvedFourPin);
    const auto unresolvedResult = st::applyResistor(
        unresolvedFourPin, unresolvedRequest, devices);
    CHECK(!unresolvedResult.ok() &&
          st::emitSpectre(unresolvedFourPin) == unresolvedBefore,
          "四端MOS缺少第四端语义时拒绝，不把未知端子当作三端MOS");

    auto userWins = circuit();
    auto userWinsRequest = request();
    userWinsRequest.case_default_resistance = 2000.0;
    auto userWinsResult = st::applyResistor(userWins, userWinsRequest, devices);
    CHECK(userWinsResult.ok() &&
            near(userWinsResult.numeric_outputs.at("R_actual"), 1000.0),
        "用户阻值优先于Case预置");

    auto caseDefault = circuit();
    auto caseRequest = request();
    caseRequest.requested_resistance.reset();
    caseRequest.case_default_resistance = 2000.0;
    auto caseResult = st::applyResistor(caseDefault, caseRequest, devices);
    CHECK(caseResult.ok() && near(caseResult.numeric_outputs.at("R_actual"), 2000.0),
        "用户未填时使用Case预置阻值");

    auto pdkDefault = circuit();
    auto pdkRequest = request();
    pdkRequest.requested_resistance.reset();
    pdkRequest.case_default_resistance.reset();
    pdkRequest.resistor.grid = 0.0;
    auto pdkResult = st::applyResistor(pdkDefault, pdkRequest, devices);
    CHECK(pdkResult.ok() &&
            near(pdkResult.numeric_outputs.at("R_actual"), std::sqrt(10.0 * 1e6), 1e-6),
        "用户和Case都未填时使用PDK合法正区间的几何中点");

    auto unbounded = circuit();
    auto unboundedRequest = request();
    unboundedRequest.requested_resistance.reset();
    unboundedRequest.case_default_resistance.reset();
    auto unboundedResult = st::applyResistor(
        unbounded, unboundedRequest, catalog(false));
    CHECK(!unboundedResult.ok() &&
            unboundedResult.diags[0].code == st::DiagCode::ResistorMappingFailed,
        "PDK没有有限阻值上界时不猜测默认值");

    auto negative = circuit();
    auto negativeRequest = request();
    negativeRequest.requested_resistance = -10.0;
    const auto negativeBefore = st::emitSpectre(negative);
    auto negativeResult = st::applyResistor(negative, negativeRequest, devices);
    CHECK(!negativeResult.ok() &&
            negativeResult.diags[0].code == st::DiagCode::ResistorEquivalenceUnsupported,
        "用户指定非正电阻时拒绝，而不是取绝对值");
    CHECK(st::emitSpectre(negative) == negativeBefore,
        "非法阻值失败时原电路保持不变");

    auto outOfRange = circuit();
    auto outOfRangeRequest = request();
    outOfRangeRequest.requested_resistance = 1e9;
    auto outOfRangeResult = st::applyResistor(outOfRange, outOfRangeRequest, devices);
    CHECK(!outOfRangeResult.ok() &&
            outOfRangeResult.diags[0].code == st::DiagCode::ResistorMappingFailed,
        "目标阻值超过PDK范围时拒绝映射");

    auto threeTerminal = circuit();
    auto threeTerminalRequest = request("r3_pdk");
    threeTerminalRequest.resistor.extra_terminal_nets[st::TerminalRole::Substrate] = "VSS";
    auto threeTerminalResult = st::applyResistor(
        threeTerminal, threeTerminalRequest, devices);
    auto* r3 = threeTerminal.find("ldo")->find("MP_RS");
    CHECK(threeTerminalResult.ok() && r3 &&
            r3->nets == std::vector<std::string>({ "VSS", "MP_RS_INT", "PVDD" }),
        "三端PDK电阻按模板独立绑定substrate，不复制MOS Bulk");

    auto missingExtra = circuit();
    auto missingExtraResult = st::applyResistor(
        missingExtra, request("r3_pdk"), devices);
    CHECK(!missingExtraResult.ok() &&
            missingExtraResult.diags[0].code == st::DiagCode::InvalidTerminalMap,
        "多端电阻存在未绑定端子时拒绝生成");

    auto collision = circuit(true);
    auto collisionResult = st::applyResistor(collision, request(), devices);
    CHECK(collisionResult.ok() && collision.find("ldo")->find("MP_RS_2") != nullptr &&
          collision.find("ldo")->find("MP")->nets[3] == "MP_RS_INT_2",
        "电阻实例和内部网络冲突时稳定分配后缀");

    auto trialMos = *devices.Find("pmos_core");
    trialMos.bulk_rule_complete = true;
    auto trialResistor = *devices.Find("r2_pdk");
    trialResistor.native_parameter_trials = true;
    trialResistor.normalized_to_cdf = {{"resistance", "r"}, {"length", "segL"}};
    trialResistor.parameter_constraints["resistance"] = {"resistance", "r", 1000, 2000, 0, {1000, 2000}, false};
    trialResistor.parameter_constraints["length"] = {"length", "segL", 2e-6, 2e-6, 0, {2e-6}, false};
    st::DeviceCatalog trialDevices;
    st::Diagnostic trialDiagnostic;
    trialDevices.Add(trialMos, trialDiagnostic);
    trialDevices.Add(trialResistor, trialDiagnostic);
    auto trialRequest = request();
    trialRequest.requested_resistance = 1000;
    auto trialCircuit = circuit();
    CHECK(!st::applyResistor(trialCircuit, trialRequest, trialDevices).ok(),
          "正式Source电阻拒绝原生试点参数");
    trialRequest.experimental_dc = true;
    const auto trialResult = st::applyResistor(trialCircuit, trialRequest, trialDevices);
    const auto* trialInstance = trialCircuit.find("ldo")->find("MP_RS");
    CHECK(trialResult.ok() && trialInstance && trialInstance->params.count("segL") &&
          trialInstance->params.count("r"),
          "实验Source电阻写入实际声明的阻值及全部几何试点参数，不依赖默认值");
    auto rejectedTrialCircuit = circuit();
    trialRequest.requested_resistance = 1500;
    CHECK(!st::applyResistor(rejectedTrialCircuit, trialRequest, trialDevices).ok() &&
          rejectedTrialCircuit.find("ldo")->find("MP_RS") == nullptr,
          "不属于有限试点集合的请求阻值在修改网表前拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Resistor transform tests passed\n";
    } else {
        std::cout << failures << " Resistor transform tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
