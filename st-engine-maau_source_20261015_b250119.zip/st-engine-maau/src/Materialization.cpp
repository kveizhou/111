#include "st/Materialization.h"

#include "st/JsonWriter.h"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <set>

namespace st {
namespace {

bool stopOnFailure(const HostStatus& status, MaterializationStage stage,
                   GenerationResult& result)
{
    if (status.ok) return false;
    result.stage = stage;
    result.message = status.message;
    if (!status.log_path.empty()) result.log_path = status.log_path;
    if (!status.artifact_path.empty()) result.netlist_path = status.artifact_path;
    return true;
}

bool endsWithRole(const std::string& name, const std::string& role)
{
    if (role.empty() || name.size() < role.size() ||
        name.compare(name.size() - role.size(), role.size(), role) != 0) return false;
    if (name.size() == role.size()) return true;
    const auto separator = name[name.size() - role.size() - 1];
    return separator == '.' || separator == '/' || separator == ':';
}

std::string failedExperimentalMosStress(const OperatingPointSnapshot& snapshot,
    const std::vector<ElectricalMosRole>& roles, const std::string& corner,
    GenerationResult& result, bool retainCandidate = false)
{
    for (const auto& role : roles) {
        const MosOperatingPoint* point = nullptr;
        for (const auto& entry : snapshot.mos) {
            const auto& name = entry.first;
            if (!endsWithRole(name, role.leaf_name)) continue;
            if (name != role.leaf_name && !role.container_instance.empty()) {
                const auto parent = name.substr(0, name.size() - role.leaf_name.size() - 1);
                if (!endsWithRole(parent, role.container_instance)) continue;
            }
            if (point != nullptr) return "实验MOS工作点不唯一：" + role.leaf_name;
            point = &entry.second;
        }
        if (point == nullptr) return "实验MOS工作点缺失：" + role.leaf_name;
        const auto prefix = corner + "/" + role.container_instance + "/" + role.leaf_name + "/";
        if (!role.reliability_complete) result.unverified_constraints.push_back(prefix + "reliability_metadata");
        const double voltages[] = {point->vgs, point->vds, point->vg - point->vb};
        const double limits[] = {role.limits.max_abs_vgs, role.limits.max_abs_vds, role.limits.max_abs_vgb};
        const char* names[] = {"vgs", "vds", "vgb"};
        for (std::size_t index = 0; index < 3; ++index) {
            if (!std::isfinite(voltages[index])) return "实验MOS电压测量无效：" + role.leaf_name;
            result.stress_measurements[prefix + names[index]] = voltages[index];
            if (std::isnan(limits[index]) || limits[index] <= 0.0)
                return "实验MOS已知额定值无效：" + role.leaf_name + "/" + names[index];
            if (std::isinf(limits[index])) {
                result.unverified_constraints.push_back(prefix + "reliability_" + names[index]);
            } else if (std::fabs(voltages[index]) > limits[index]) {
                if (retainCandidate) {
                    result.failed_constraints.push_back(prefix + "reliability_" + names[index]);
                    continue;
                }
                return "实验MOS已知额定值越限：" + role.leaf_name + "/reliability_" + names[index];
            }
        }
    }
    return {};
}

std::string failedResistorStress(const OperatingPointSnapshot& snapshot,
                                 const std::vector<ExpectedResistor>& checks,
                                 bool experimentalDc, const std::string& corner,
                                 GenerationResult& result, bool retainCandidate = false)
{
    for (auto check : checks) {
        check.experimental_dc = experimentalDc;
        const auto assessed = EvaluateResistorStress(snapshot, check);
        const auto prefix = corner + "/" + check.operation_id + "/" + check.leaf_name + "/";
        for (const auto& unknown : assessed.unverified_constraints)
            result.unverified_constraints.push_back(prefix + unknown);
        if (assessed.measurements_available) {
            result.stress_measurements[prefix + "voltage"] = assessed.voltage;
            result.stress_measurements[prefix + "current"] = assessed.current;
            result.stress_measurements[prefix + "power"] = assessed.power;
        }
        if (!assessed.ok) {
            if (retainCandidate && assessed.measurements_available &&
                (assessed.failed_constraint == "resistor_voltage" ||
                 assessed.failed_constraint == "resistor_power" ||
                 assessed.failed_constraint == "resistor_current")) {
                result.failed_constraints.push_back(prefix + assessed.failed_constraint);
                continue;
            }
            return "电阻应力硬约束失败[" + check.operation_id + "/" +
                check.leaf_name + "]：" + assessed.failed_constraint;
        }
    }
    return {};
}

} // namespace

HostStatus MaterializationHost::RunVariantOperatingPoint(
    const CellViewRef&,
    const CellViewRef&,
    const AnalysisIdentity&,
    const std::string&,
    const std::string&)
{
    return {false, "宿主不支持变体直流工作点评估", {}, {}};
}

HostStatus MaterializationHost::RunVariantOperatingPoint(
    const CellViewRef&,
    const CellViewRef&,
    const AnalysisIdentity&,
    const std::string&,
    const std::string&,
    const std::string&)
{
    return {false, "宿主不支持电阻直流工作点评估", {}, {}};
}

GenerationResult TopologyVariantMaterializer::Generate(const GenerationRequest& request,
                                                       MaterializationHost& host) const
{
    GenerationResult result;
    for (const auto& mapping : request.publish_clone_map) {
        if (mapping.hierarchy_path == "/") result.target = mapping.target;
    }
    result.plan_path = request.plan_path;
    result.parameter_groups = request.parameter_groups;
    result.iq_delta = request.iq_delta;
    result.parameters_quantized = !request.experimental_dc && request.parameters_quantized;
    result.pvt_ready = false;
    bool pvtChecksPassed = false;
    if (request.experimental_dc) result.unverified_constraints = request.unverified_constraints;
    bool needsResistorOp = !request.resistor_checks.empty();
    for (const auto& check : request.electrical_checks) {
        needsResistorOp = needsResistorOp || !check.resistor.leaf_name.empty();
    }
    const std::string rootSubckt = !request.root_subckt.empty()
        ? request.root_subckt
        : (request.baseline.subckts.empty() ? std::string{}
                                            : request.baseline.subckts.front().name);

    const auto diagnostics = ValidateOaPlan(request.plan);
    std::vector<CellViewRef> stagedViews;
    for (const auto& mapping : request.plan.clone_map) stagedViews.push_back(mapping.target);
    for (const auto& cell : request.plan.generated_cells) {
        stagedViews.push_back(cell.schematic);
        stagedViews.push_back(cell.symbol);
    }
    bool publishMapValid = request.publish_clone_map.size() == stagedViews.size() &&
        !result.target.library.empty() && result.target.library != request.plan.target.library;
    std::set<std::string> sources, targets;
    for (const auto& publish : request.publish_clone_map) {
        const auto key = [](const CellViewRef& view) {
            return view.library + "/" + view.cell + "/" + view.view;
        };
        const auto found = std::find(stagedViews.begin(), stagedViews.end(), publish.source);
        if (found == stagedViews.end() ||
            publish.source.library != request.plan.target.library ||
            publish.target.library != result.target.library ||
            publish.source.view != publish.target.view ||
            SamePhysicalCellView(publish.source, publish.target) ||
            SamePhysicalCellView(publish.target, request.plan.source) ||
            !sources.insert(key(publish.source)).second ||
            !targets.insert(key(publish.target)).second) publishMapValid = false;
    }
    const bool mixedScope = (request.retain_electrical_candidate && !request.experimental_dc) ||
        (request.experimental_dc && request.structure_only) ||
        (!request.experimental_dc &&
         (!request.experimental_mos_checks.empty() || std::any_of(request.electrical_checks.begin(), request.electrical_checks.end(),
             [](const auto& check) { return check.experimental_dc || check.native_parameter_trials || check.resistor.experimental_dc; }) ||
          std::any_of(request.resistor_checks.begin(), request.resistor_checks.end(),
             [](const auto& check) { return check.experimental_dc; })));
    if (!diagnostics.empty() || !publishMapValid || mixedScope ||
        (request.experimental_dc && (!request.run_nominal_dc || request.experimental_mos_checks.empty())) || rootSubckt.empty() ||
        request.work_dir.empty() ||
        request.plan_path.empty() || request.skill_script_path.empty() ||
        (!request.parameters_quantized && !request.structure_only && !request.experimental_dc) ||
        (request.structure_only && (request.run_nominal_dc || request.pvt_configured || needsResistorOp || !request.electrical_checks.empty())) ||
        (request.pvt_configured && !request.run_nominal_dc) ||
        (needsResistorOp && !request.run_nominal_dc)) {
        result.stage = MaterializationStage::ValidatePlan;
        if (mixedScope || (request.experimental_dc && (!request.run_nominal_dc || request.experimental_mos_checks.empty()))) {
            result.message = "实验策略不得进入正式/结构流程，experimental_dc必须执行实际名义DC并提供目标MOS应力检查";
            return result;
        }
        result.message = diagnostics.empty()
            ? (needsResistorOp && !request.run_nominal_dc
                   ? "电阻应力门禁需要最终staging名义DC"
                   : (!request.parameters_quantized
                   ? "待Sizing参数尚未量化到PDK合法取值"
                   : (request.pvt_configured && !request.run_nominal_dc
                          ? "配置PVT时必须先执行最终staging名义DC"
                          : (publishMapValid ? "root_subckt、work_dir、plan_path 或 skill_script_path 为空"
                               : "staging到最终目标的publish clone map不完整")
                     )))
            : diagnostics.front().message;
        return result;
    }

    if (request.experimental_dc) result.target = request.plan.target;
    auto status = host.CopyCircuits(request.plan.clone_map);
    if (stopOnFailure(status, MaterializationStage::CopyCircuit, result)) return result;

    status = host.WritePlanFile(request.plan_path, WritePlanJson(request.plan));
    if (stopOnFailure(status, MaterializationStage::WritePlan, result)) return result;

    status = host.ExecuteSkill(request.work_dir, request.skill_script_path, request.plan_path);
    if (!status.log_path.empty()) result.log_path = status.log_path;
    if (stopOnFailure(status, MaterializationStage::ExecuteSkill, result)) return result;

    // 名义直流工作点检查：staging 变体已物化但尚未发布。
    // 判定 = run-op 成功 + OP 可加载 + 身份与请求一致 + MOS 快照非空。
    // 失败即停止，不进入回读、不发布。
    if (request.run_nominal_dc) {
        if (request.nominal_op_dir.empty() || request.bench.library.empty() ||
            request.nominal_corner.empty() ||
            request.nominal_identity.dut_hash.empty()) {
            result.stage = MaterializationStage::NominalDcCheck;
            result.message = "run_nominal_dc 需要 bench、nominal_corner、"
                             "nominal_identity 和 nominal_op_dir";
            return result;
        }
        const std::string identityTsv =
            (std::filesystem::path(request.nominal_op_dir) / "identity.tsv").string();
        const std::string mosTsv =
            (std::filesystem::path(request.nominal_op_dir) / "mos.tsv").string();
        const std::string resistorTsv = needsResistorOp
            ? (std::filesystem::path(request.nominal_op_dir) / "resistor.tsv").string()
            : std::string{};
        status = needsResistorOp
            ? host.RunVariantOperatingPoint(request.plan.target, request.bench,
                                            request.nominal_identity, identityTsv,
                                            mosTsv, resistorTsv)
            : host.RunVariantOperatingPoint(request.plan.target, request.bench,
                                            request.nominal_identity, identityTsv,
                                            mosTsv);
        if (!status.log_path.empty()) result.log_path = status.log_path;
        if (stopOnFailure(status, MaterializationStage::NominalDcCheck, result)) {
            return result;
        }
        OperatingPointSnapshot nominalOp;
        std::vector<Diagnostic> opDiagnostics;
        if (!LoadOperatingPointTsv(identityTsv, mosTsv, resistorTsv,
                                   nominalOp, opDiagnostics)) {
            result.stage = MaterializationStage::NominalDcCheck;
            result.message = opDiagnostics.empty()
                ? "名义工作点输出无法解析"
                : opDiagnostics.front().message;
            return result;
        }
        if (!IsReusable(nominalOp, request.nominal_identity) || nominalOp.mos.empty()) {
            result.stage = MaterializationStage::NominalDcCheck;
            result.message = "名义工作点身份与staging变体不一致或MOS快照为空";
            return result;
        }
        for (auto electrical : request.electrical_checks) {
            electrical.experimental_dc = request.experimental_dc;
            electrical.resistor.experimental_dc = request.experimental_dc;
            const auto assessed = EvaluateElectricalConstraints(
                nominalOp, electrical, true);
            const auto prefix = request.nominal_corner + "/" + electrical.operation_id + "/";
            for (const auto& unknown : assessed.unverified_constraints)
                result.unverified_constraints.push_back(prefix + unknown);
            for (const auto& value : assessed.stress_measurements)
                result.stress_measurements[prefix + value.first] = value.second;
            if (!assessed.ok) {
                if (request.retain_electrical_candidate && assessed.constraints.at("complete") &&
                    assessed.stress_measurements.count("resistor.current") &&
                    assessed.stress_measurements.count("resistor.voltage")) {
                    for (const auto& [name, passed] : assessed.constraints)
                        if (!passed) result.failed_constraints.push_back(prefix + name);
                    continue;
                }
                result.stage = MaterializationStage::NominalDcCheck;
                result.message = "名义工作点电气硬约束失败";
                if (!electrical.operation_id.empty()) {
                    result.message += "[" + electrical.operation_id + "]";
                }
                result.message += "：" + assessed.first_failed_constraint;
                return result;
            }
        }
        const auto resistorFailure = failedResistorStress(
            nominalOp, request.resistor_checks, request.experimental_dc,
            request.nominal_corner, result, request.retain_electrical_candidate);
        if (!resistorFailure.empty()) {
            result.stage = MaterializationStage::NominalDcCheck;
            result.message = resistorFailure;
            return result;
        }
        const auto mosFailure = failedExperimentalMosStress(
            nominalOp, request.experimental_mos_checks, request.nominal_corner, result,
            request.retain_electrical_candidate);
        if (!mosFailure.empty()) {
            result.stage = MaterializationStage::NominalDcCheck;
            result.message = mosFailure;
            return result;
        }
        result.nominal_dc_ready = true;
    }

    // 已配置 PVT 时，在同一个最终 staging CellView 上逐 Corner 复验，
    // 不复用候选阶段的“通过”结论。nominal_corner 已由上面的名义检查覆盖。
    if (request.pvt_configured) {
        result.pvt_ready = !request.experimental_dc;
        for (const auto& pvt : request.pvt_checks) {
            if (pvt.corner.empty() || pvt.op_dir.empty() ||
                pvt.identity.corner != pvt.corner) {
                result.stage = MaterializationStage::PvtCheck;
                result.message = "PVT检查缺少Corner、身份或输出目录";
                result.pvt_ready = false;
                return result;
            }
            const std::string identityTsv =
                (std::filesystem::path(pvt.op_dir) / "identity.tsv").string();
            const std::string mosTsv =
                (std::filesystem::path(pvt.op_dir) / "mos.tsv").string();
            const std::string resistorTsv = needsResistorOp
                ? (std::filesystem::path(pvt.op_dir) / "resistor.tsv").string()
                : std::string{};
            status = needsResistorOp
                ? host.RunVariantOperatingPoint(request.plan.target, request.bench,
                                                pvt.identity, identityTsv, mosTsv,
                                                resistorTsv)
                : host.RunVariantOperatingPoint(request.plan.target, request.bench,
                                                pvt.identity, identityTsv, mosTsv);
            if (!status.log_path.empty()) result.log_path = status.log_path;
            if (stopOnFailure(status, MaterializationStage::PvtCheck, result)) {
                result.pvt_ready = false;
                result.message = "PVT Corner " + pvt.corner + "：" + result.message;
                return result;
            }
            OperatingPointSnapshot snapshot;
            std::vector<Diagnostic> diagnostics;
            if (!LoadOperatingPointTsv(identityTsv, mosTsv, resistorTsv,
                                       snapshot, diagnostics) ||
                !IsReusable(snapshot, pvt.identity) || snapshot.mos.empty()) {
                result.stage = MaterializationStage::PvtCheck;
                result.message = "PVT Corner " + pvt.corner +
                    " 的工作点缺失、不可解析或身份不一致";
                result.pvt_ready = false;
                return result;
            }
            for (auto electrical : request.electrical_checks) {
                electrical.experimental_dc = request.experimental_dc;
                electrical.resistor.experimental_dc = request.experimental_dc;
                const auto assessed = EvaluateElectricalConstraints(
                    snapshot, electrical, true);
                const auto prefix = pvt.corner + "/" + electrical.operation_id + "/";
                for (const auto& unknown : assessed.unverified_constraints)
                    result.unverified_constraints.push_back(prefix + unknown);
                for (const auto& value : assessed.stress_measurements)
                    result.stress_measurements[prefix + value.first] = value.second;
                if (!assessed.ok) {
                    result.stage = MaterializationStage::PvtCheck;
                    result.message = "PVT Corner " + pvt.corner +
                        " 电气硬约束失败";
                    if (!electrical.operation_id.empty()) {
                        result.message += "[" + electrical.operation_id + "]";
                    }
                    result.message += "：" + assessed.first_failed_constraint;
                    result.pvt_ready = false;
                    return result;
                }
            }
            const auto mosFailure = failedExperimentalMosStress(
                snapshot, request.experimental_mos_checks, pvt.corner, result);
            if (!mosFailure.empty()) {
                result.stage = MaterializationStage::PvtCheck;
                result.message = mosFailure;
                result.pvt_ready = false;
                return result;
            }
            const auto resistorFailure = failedResistorStress(
                snapshot, request.resistor_checks, request.experimental_dc, pvt.corner, result);
            if (!resistorFailure.empty()) {
                result.stage = MaterializationStage::PvtCheck;
                result.message = "PVT Corner " + pvt.corner + "：" +
                    resistorFailure;
                result.pvt_ready = false;
                return result;
            }
        }
        pvtChecksPassed = true;
    }

    Netlist sourceAfter;
    status = host.RegenerateNetlist(request.plan.source, rootSubckt, sourceAfter);
    if (!status.artifact_path.empty()) result.source_netlist_path = status.artifact_path;
    if (stopOnFailure(status, MaterializationStage::VerifySource, result)) return result;
    result.source_verification = VerifyVariantRoundTrip(request.baseline,
                                                        request.baseline, sourceAfter);
    if (!result.source_verification.ok) {
        result.stage = MaterializationStage::VerifySource;
        result.message = result.source_verification.mismatches.empty()
            ? "source verification failed"
            : result.source_verification.mismatches.front();
        return result;
    }

    Netlist roundTrip;
    status = host.RegenerateNetlist(request.plan.target, rootSubckt, roundTrip);
    if (!status.artifact_path.empty()) result.netlist_path = status.artifact_path;
    if (stopOnFailure(status, MaterializationStage::RegenerateNetlist, result)) return result;

    for (const auto& generated : request.plan.generated_cells) {
        const std::string logicalSubckt = "oa_" + generated.schematic.library +
            "__" + generated.schematic.cell;
        Netlist generatedRoundTrip;
        status = host.RegenerateNetlist(generated.schematic, logicalSubckt,
                                        generatedRoundTrip);
        if (!status.artifact_path.empty()) {
            result.generated_netlist_paths.push_back(status.artifact_path);
        }
        if (stopOnFailure(status, MaterializationStage::RegenerateNetlist, result)) {
            if (!generated.package_id.empty()) {
                result.message = generated.package_id + " 封装子Cell回读失败：" +
                    result.message;
            }
            return result;
        }
        const auto* generatedSubckt = generatedRoundTrip.find(logicalSubckt);
        if (generatedSubckt == nullptr) {
            result.stage = MaterializationStage::RegenerateNetlist;
            result.message = generated.package_id + " 封装子Cell回读网表缺少subckt " +
                logicalSubckt;
            return result;
        }
        if (roundTrip.find(logicalSubckt) != nullptr) {
            result.stage = MaterializationStage::RegenerateNetlist;
            result.message = "回读网表出现重复subckt " + logicalSubckt;
            return result;
        }
        roundTrip.subckts.push_back(*generatedSubckt);
    }

    VariantVerificationPolicy parameterPolicy;
    if (request.structure_only || request.experimental_dc) {
        for (const auto& generated : request.plan.generated_cells) {
            const auto scope = "oa_" + generated.schematic.library + "__" + generated.schematic.cell;
            for (const auto& instance : generated.create_instances) {
                parameterPolicy.allowed_extra_parameters_by_instance[{scope, instance.name}] =
                    instance.allowed_extra_cdf_parameters;
            }
        }
    }
    result.verification = VerifyVariantRoundTrip(request.baseline,
        request.expected_variant, roundTrip, parameterPolicy);
    result.topology_hash = result.verification.actual_topology_hash;
    if (!result.verification.ok) {
        result.stage = MaterializationStage::VerifyRoundTrip;
        result.message = result.verification.mismatches.empty()
            ? "round-trip verification failed"
            : result.verification.mismatches.front();
        return result;
    }
    result.structural_ready = true;

    if (request.experimental_dc) {
        result.target = request.plan.target;
        result.ok = result.nominal_dc_ready && result.structural_ready &&
            (!request.pvt_configured || pvtChecksPassed);
        result.experimental_dc_ready = result.ok && result.failed_constraints.empty();
        result.optimization_candidate_ready = result.ok && !result.failed_constraints.empty();
        result.experimental_pvt_ready = result.experimental_dc_ready && request.pvt_configured && pvtChecksPassed;
        result.pvt_ready = false;
        result.ready_for_sizing = false;
        result.reliability_verified = false;
        result.stage = MaterializationStage::Complete;
        result.message = result.experimental_dc_ready
            ? "最低DC条件及实际电路回读通过；性能和完整可靠性未验证"
            : "已生成待优化候选并复验实际DC；电气未满足项已列出，不能视为DC合格";
        return result;
    }

    status = host.PublishCircuits(request.publish_clone_map);
    if (stopOnFailure(status, MaterializationStage::PublishTarget, result)) return result;

    result.ok = true;
    result.ready_for_sizing = !request.structure_only && result.structural_ready && result.nominal_dc_ready &&
        result.parameters_quantized &&
        (!request.pvt_configured || result.pvt_ready);
    result.stage = MaterializationStage::Complete;
    result.message = request.structure_only
        ? "结构模式：源图、父图及全部封装子Cell回读通过后发布；DC/PVT未验证"
        : "Topology Variant已在staging物化，名义DC、源图、父图及全部封装子Cell回读验证通过后发布";
    return result;
}

} // namespace st
