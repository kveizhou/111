# 最低DC自动VBIAS更新

适用：已安装 ldo_shared_subckt_fix_20261015.zip，保留原 candidate 会话。
本包包含该版本之后的自动搜索与最佳候选交付修改，不需要逐个安装中间包。

在服务器 /tmpdata/maau_epc/users/k00981589 目录执行下面一整行：

```csh
unzip -o ldo_minimum_vbias_20261015.zip && bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs
```

命令结束后，分别执行：

```csh
set st_rc = $status
echo "退出码=$st_rc"
```

正常运行无需 reference-resistor-scales，不用手动选择阻值或工作点。
如要新建实验，原 run_cascode_experiment.py 入口也默认自动搜索。

## 自动执行内容

- 复用已有基线、器件和端口资料，保留现有MOS与模板连接。
- 自动调整参考电阻的实际串联段数和联动几何，根据真实DC选择下一点，最多评估16个不同搜索点。候选范围用尽可能少于16点。
- 首个满足最低DC条件的点立即入选；没有合格点时，从已收敛、数据完整的点中选择必要条件不足最少的候选。优先减少非饱和类必要条件失败，再比较饱和不足，最后比较原支路电流变化；不按面积或功耗寻优。
- 用选中点的参数生成最终电路，并额外进行一次同参数DC与实际回读。这是最终电路复验，不是第17个搜索点。
- 本轮不验输出精度、启动时间、稳定性、PVT或功耗/面积优化。实际接线、参数生效、DC收敛、必要工作区及已知器件限制仍检查，未知额定资料标为未验证。

## 预期输出

开始应出现：

```text
AUTO_VBIAS_SEARCH=true
AUTO_VBIAS_MAX_DC_EVALUATIONS=16
```

AUTO_RESISTOR_CANDIDATES 是可选参数表大小，不是要逐个仿真的次数。
每次评估约耗时多少取决于服务器EDA执行；本包不承诺16点必有合格解。

最低DC条件满足：

```text
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
OPTIMIZATION_CANDIDATE_READY=false
```

没有全部满足，但已自动选中并生成待优化电路：

```text
RESULT=OPTIMIZATION_CANDIDATE_READY
EXPERIMENTAL_DC_READY=false
OPTIMIZATION_CANDIDATE_READY=true
UNMET_REQUIREMENTS=具体未满足项
```

两种完整交付都返回退出码0。待优化候选不是电气合格结果，也不保证后续优化一定修复。
SELECTED_POINT、SELECTED_PARAMETERS 是搜索选择；FINAL_VBIAS 和 UNMET_REQUIREMENTS 来自最终电路复验。

结果位置自动输出：

```text
RESULT_CELL=生成的library/cell/schematic
RESULT_NETLIST=最终回读网表路径
SELECTED_PARAMETERS_FILE=选中参数文件路径
FINAL_VBIAS=最终实测偏置
```

READY_FOR_SIZING=false 和 RELIABILITY_VERIFIED=false 沿用原正式验收字段。本次可交付状态用上述 RESULT 判断；结果保留在所示STAGING单元，PUBLISHED=false。本包不改后续优化器接口。

只有没有有效DC结果，或实际执行/读取/回读失败，才返回INCOMPLETE和退出码2。软件错误会停止余下搜索，不会把缺失数据当成某个阻值不合适继续空跑。本包未增加用户交互步骤。

本地验证：50项Python测试、5套C++共388项检查及工具编译通过；包含16点无解选最佳、首个合格停止、最终使用较早所选点和错误停止。实际服务器Cadence/Spectre尚待本次运行验证。
