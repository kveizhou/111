#!/usr/bin/env python3
"""Run one isolated Cascode experiment from completed, server-bound inputs.

Uses the existing experimental inspect/confirm/generate route. Never publishes,
rewrites the old session, invents PDK ratings, or retries a failed native step.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time

from inspect_cascode_pdk_evidence import cached_inputs, latest
from site_data import read_json, write_json

ROOT = Path(__file__).resolve().parents[2]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pairs(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            if key in result and key != 'unverified_constraint':
                raise ValueError('duplicate field in '+str(path)+': '+key)
            result[key] = value
    return result


def solver_trace_stamp(work):
    path = Path(work)/'analysis/solver_trace.jsonl'
    if not path.is_file():
        return None
    stat = path.stat()
    return stat.st_mtime_ns, stat.st_size


def print_solver_result(work, compact=False):
    """Report saved solver decisions, without rerunning or reinterpreting OP."""
    path = Path(work)/'analysis/solver_trace.jsonl'
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    if not rows or any(not isinstance(row, dict) for row in rows):
        raise ValueError('solver trace is empty or malformed: '+str(path))
    print('SOLVER_TRACE='+str(path))
    print('SOLVER_RECORDED_POINTS='+str(len(rows)))
    print('SOLVER_HOST_CALLS='+str(sum(row.get('host_called',row.get('dc_evaluated')) is True for row in rows)))
    # Each record's constraints are the solver's decisions. Null means unknown,
    # not failed. A host error does not establish an electrically infeasible point.
    for row in rows:
        constraints = row.get('constraints', {})
        summary = {k:row.get(k) for k in ('candidate','converged','reason','host_message',
                                         'construction_stage','construction_message')}
        summary['failed_constraints'] = [k for k,v in constraints.items() if v is False]
        summary['unverified_constraints'] = [k for k,v in constraints.items() if v is None]
        if not compact: print('SOLVER_POINT '+json.dumps(summary,ensure_ascii=False,sort_keys=True))
        elif row.get('host_message'): print('EVALUATION_ERROR='+row['host_message'])
        stress=row.get('stress_measurements') or {}
        voltage,current=stress.get('resistor.voltage'),stress.get('resistor.current')
        measured=(abs(voltage/current) if isinstance(voltage,(int,float)) and
                  isinstance(current,(int,float)) and current else None)
        resistor=(row.get('params') or {}).get('resistor',{})
        print('TRIAL_RESULT point='+str(row.get('candidate'))+
              ' converged='+('unknown' if row.get('converged') is None else str(row.get('converged')).lower())+' reason='+str(row.get('reason'))+
              ' requested_R='+str(resistor.get('r','unknown'))+
              ' segments='+str(resistor.get('segments','unknown'))+
              ' measured_V_over_I='+('unknown' if measured is None else format(measured,'.6g')))

    controls = {'w','l','nfin','nf','fingers','m','r','segW','segL','segments','cktW','cktL'}
    selected = next((row for row in rows if row.get('selected') is True), None)
    if selected:
        print('SELECTED_POINT='+str(selected['candidate']))
        print('SELECTED_DC_FEASIBLE='+str(selected.get('kept') is True).lower())
        print('SELECTED_VBIAS='+str((selected.get('stress_measurements') or {}).get('vbias','unknown')))
        print('SELECTED_FAILED_CONSTRAINTS='+json.dumps([k for k,v in selected.get('constraints',{}).items() if v is False]))
        parameters = {group:{k:v for k,v in values.items() if k in controls}
                      for group,values in selected.get('params',{}).items()}
        print('SELECTED_PARAMETERS='+json.dumps(parameters,ensure_ascii=False,sort_keys=True))
    if compact:
        return
    last = rows[-1]
    for key in ('search','metrics','stress_measurements'):
        print('SOLVER_LAST_'+key.upper()+'='+json.dumps(last.get(key),ensure_ascii=False,sort_keys=True))
    # CDF also contains hundreds of fixed presentation/derived fields; retain
    # the actual design controls here, with the complete record left in place.
    controls = {'w','l','nfin','nf','fingers','m','r','segW','segL','segments','cktW','cktL'}
    parameters = {group:{k:v for k,v in values.items() if k in controls}
                  for group,values in last.get('params', {}).items()}
    print('SOLVER_LAST_PARAMETERS='+json.dumps(parameters,ensure_ascii=False,sort_keys=True))


def print_new_solver_result(work, previous_stamp):
    """Do not attribute a retained old trace to an earlier-stage failure."""
    try:
        stamp = solver_trace_stamp(work)
        if stamp is not None and stamp != previous_stamp:
            print_solver_result(work, compact=True)
    except (OSError,ValueError,TypeError,AttributeError) as error:
        print('SOLVER_SUMMARY_UNAVAILABLE='+str(error))


def load_inputs(session, batch, target):
    bridge, bundle, pdk, _, _, _, _, fingerprints = cached_inputs(session, batch)
    selected = latest(bridge.parent.glob('experiment_inputs_*/binding_evidence.json'))
    report = read_json(selected)
    if (report.get('experiment_inputs_ready') is not True or report.get('required_bindings') or
            report.get('native_error') or report.get('accepted_bridge') != str(bridge) or
            report.get('validation_scope') != 'experimental_dc'):
        raise ValueError('latest binding is incomplete or belongs to another baseline')
    pinned = report.get('source_cache_sha256', {})
    if not pinned or any(pinned.get(p) != h for p, h in fingerprints.items()):
        raise ValueError('binding source identity differs from accepted inputs')
    native = report.get('native_evidence_sha256', {})
    if not native:
        raise ValueError('completed native binding fingerprints missing')
    for path, expected in dict(pinned, **native).items():
        if digest(path) != expected:
            raise ValueError('bound evidence changed: '+path)
    if target not in pdk['targets']:
        raise ValueError('target is not in accepted binding: '+target)
    folder = selected.parent
    profile_path, rules_path = folder/'simulation_profile.json', folder/'pdk_facts.json'
    profile, rules = read_json(profile_path), read_json(rules_path)
    if (profile.get('validation_scope') != 'experimental_dc' or
            profile.get('validated_baseline_bundle') != str(bridge/'bundle/baseline_bundle.json') or
            rules.get('source') != str(selected)):
        raise ValueError('executable inputs differ from selected binding')
    from standalone import validate_bundle_profile
    validate_bundle_profile(bundle, profile)
    from experimental_pdk import build_experimental_metadata
    cache = profile['experimental_pdk_cache']
    metadata = build_experimental_metadata(cache['pdk_roots'], Path(cache['probe']), profile, rules)
    preview = read_json(folder/'experimental_metadata.preview.json')
    # v3 binding previews predate preservation of unselected primitive masters.
    # Only this field is derived anew from the same hash-bound native probe.
    preview['non_target_devices'] = metadata['non_target_devices']
    if metadata != preview:
        raise ValueError('bound profile/PDK facts differ from completed metadata preview')
    old = pairs(session/'session.conf')
    source = {k: old['source_'+('library' if k == 'lib' else k)] for k in ('lib','cell','view')}
    if source != bundle['source'] or cache.get('source_dut') != source:
        raise ValueError('old session source differs from bound source')
    manifest = read_json(session/'analysis/standalone_inputs/provider_inputs.json')
    init = manifest.get('init') or str(ROOT/'server/skill/init.il')
    if not Path(init).is_file():
        raise ValueError('saved SKILL init missing: '+init)
    return dict(source=source, bench=bundle['bench'], cds_lib=bundle['cds_lib'],
        core_subckt=old['core_subckt'], target=target, profile=str(profile_path),
        rules=str(rules_path), init=init, binding=str(selected),
        input_sha256={str(p):digest(p) for p in (selected, profile_path, rules_path, session/'session.conf')})


def make_commands(config, output):
    output = Path(output).resolve()
    # A random directory suffix creates a fresh Cadence-safe namespace.
    tag = hashlib.sha256(str(output).encode()).hexdigest()[:12]
    library, cell = 'STEXP_'+tag, 'cascode_'+config['target']+'_'+tag
    operation = output/'operation.conf'
    operation.write_text('id=op_'+config['target']+'\ntype=same_type_cascode\ninstance='+config['target']+'\n')
    source, bench = config['source'], config['bench']
    entry = [sys.executable, str(ROOT/'server/site/standalone.py')]
    inspect = entry + ['inspect', '--validation-scope', 'experimental_dc',
        '--simulation-profile', config['profile'], '--pdk-rules', config['rules'],
        '--backend', str(ROOT/'server/st_virtuoso_backend.sh'),
        '--cds-lib', str(output/'cadence/cds.lib'), '--work-dir', str(output/'work'),
        '--core-subckt', config['core_subckt'], '--variant-lib', library,
        '--variant-cell', cell, '--variant-id', 'EXP_'+tag,
        '--skill', str(ROOT/'skill/standalone_topology_variant.il')]
    for k in ('lib','cell','view'):
        inspect += ['--'+k, source[k], '--bench-'+k, bench[k]]
    return [
        ('prepare', ['bash', str(ROOT/'server/prepare_session.sh'), '--source-cds-lib', config['cds_lib'],
                     '--session-dir', str(output/'cadence'), '--variant-lib', library]),
        ('inspect', inspect),
        ('confirm', entry+['confirm','--session',str(output/'work'),'--operation',str(operation)]),
        ('generate', entry+['generate','--session',str(output/'work')])]


class StageFailure(RuntimeError):
    def __init__(self, stage, code, log):
        self.stage, self.code, self.log = stage, code, Path(log)
        super().__init__(stage+' failed; exit='+str(code)+'; log='+str(log))


def run_stage(stage, argv, output, timeout, env=None):
    log = Path(output)/(stage+'.log')
    print('STAGE='+stage+' START LOG='+str(log), flush=True)
    started, last = time.monotonic(), 0.0
    with log.open('w') as stream:
        proc = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, env=env,
                                start_new_session=True)
        try:
            while True:
                try:
                    code = proc.wait(timeout=min(1, timeout))
                    break
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic()-started
                    if elapsed >= timeout:
                        raise StageFailure(stage, 124, log)
                    if elapsed-last >= 30:
                        print('STAGE='+stage+' RUNNING elapsed_seconds='+str(int(elapsed)), flush=True)
                        last = elapsed
        except BaseException:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=5)
            except ProcessLookupError:
                pass
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            raise
    if stage == 'generate':
        # Surface the small reuse summary on success as well as failure.
        # Keep callback/native logs in generate.log rather than flooding stdout.
        for line in log.read_text(errors='replace').splitlines():
            if line.startswith(('CANDIDATE_OA_MODE=', 'CANDIDATE_READBACK_CELLS=', 'VBIAS_SELECTION ')):
                print(line, flush=True)
    if code:
        raise StageFailure(stage, code, log)
    print('STAGE='+stage+' COMPLETE elapsed_seconds='+str(round(time.monotonic()-started,1)), flush=True)


def build_tool(output, timeout):
    files = sorted(list((ROOT/'src').glob('*.cpp'))+list((ROOT/'include').rglob('*.h'))+
                   [ROOT/'app/st_circuit_tool.cpp', ROOT/'scripts/build.sh'])
    identity = {str(p.relative_to(ROOT)):digest(p) for p in files}
    identity['CXX'] = os.environ.get('CXX', '')
    binary = ROOT/'build/bin/st_circuit_tool'
    stamp = ROOT/'build/cascode-tool-build.json'
    if stamp.is_file() and binary.is_file() and os.access(binary, os.X_OK):
        saved = read_json(stamp)
        if saved.get('sources') == identity and saved.get('binary_sha256') == digest(binary):
            print('TOOL_BUILD=REUSED', flush=True)
            return
    env = dict(os.environ, ST_BUILD_DIR=str(ROOT/'build'))
    run_stage('build', ['bash', str(ROOT/'scripts/build.sh'), '--tool-only'], output, timeout, env)
    write_json(stamp, dict(sources=identity, binary_sha256=digest(binary)))


def validate_result(report):
    required = dict(ok='true', validation_scope='experimental_dc',
                    ready_for_sizing='false', reliability_verified='false', published='false',
                    structural_ready='true', stage='complete')
    if any(report.get(k) != v for k, v in required.items()):
        raise ValueError('experimental completion flags incomplete: '+report.get('message','no message'))
    passed = report.get('experimental_dc_ready') == 'true'
    fallback = report.get('optimization_candidate_ready') == 'true'
    if passed == fallback or (fallback and (report.get('nominal_dc_ready') != 'true' or not report.get('failed_constraints'))):
        raise ValueError('result must identify DC pass or converged optimization candidate')
    target = report.get('target', '').split('/')
    if len(target) != 3 or not target[0].endswith('__STAGING'):
        raise ValueError('experimental result is not an isolated staging CellView')
    return True


def completion_status(report):
    validate_result(report)
    passed = report['experimental_dc_ready'] == 'true'
    return dict(result='EXPERIMENT_DC_PASS' if passed else 'OPTIMIZATION_CANDIDATE_READY',
                experimental_dc_ready=passed, optimization_candidate_ready=not passed, validation=report)


def print_completion(status):
    print('OPTIMIZATION_CANDIDATE_READY='+str(status.get('optimization_candidate_ready',False)).lower())
    report = status.get('validation') or {}
    for label,key in [('RESULT_CELL','target'),('RESULT_NETLIST','roundtrip_netlist'),
                      ('SELECTED_PARAMETERS_FILE','resolved_parameters'),('UNMET_REQUIREMENTS','failed_constraints')]:
        if key in report: print(label+'='+report[key])
    voltages = {k[len('stress.'):]:v for k,v in report.items() if k.startswith('stress.') and k.endswith('/vbias')}
    if voltages: print('FINAL_VBIAS='+json.dumps(voltages,sort_keys=True))


def execute(config, output, timeout, runner=run_stage):
    commands = make_commands(config, output)
    write_json(output/'commands.json', commands)
    env = dict(os.environ, ST_SKILL_INIT=config['init'])
    for stage, argv in commands:
        trace_before = solver_trace_stamp(output/'work') if stage == 'generate' else None
        try:
            if stage == 'generate':
                from experimental_pdk import resistor_trial_file
                work = output/'work'
                manifest = read_json(work/'analysis/standalone_inputs/provider_inputs.json')
                trials = resistor_trial_file(work,manifest,output,None)
                argv += ['--experimental-resistor-trials',str(trials), '--experimental-resistor-auto','true']
            runner(stage, argv, output, timeout, env=env)
            if stage == 'generate': print_new_solver_result(output/'work', trace_before)
        except StageFailure:
            if stage == 'generate':
                print_new_solver_result(output/'work', trace_before)
            raise
    report = pairs(output/'work/reports/validation.txt')
    validate_result(report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--batch', required=True)
    parser.add_argument('--target', default='I21')
    parser.add_argument('--stage-timeout', type=int, default=3600)
    args = parser.parse_args()
    output = None
    status = dict(checker='cascode-experiment-run-v1', result='INCOMPLETE',
                  experimental_dc_ready=False, ready_for_sizing=False,
                  reliability_verified=False, published=False)
    try:
        if args.stage_timeout <= 0 or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', args.target):
            raise ValueError('positive timeout and simple target instance name required')
        session, batch = Path(args.session).resolve(), Path(args.batch).resolve()
        config = load_inputs(session, batch, args.target)
        output = Path(tempfile.mkdtemp(prefix='candidate_'+args.target+'_', dir=str(batch)))
        write_json(output/'inputs.json', config)
        print('CHECKER='+status['checker']+'\nOUTPUT_DIR='+str(output)+'\nTARGET='+args.target, flush=True)
        print('VALIDATION_SCOPE=experimental_dc\nPDK_SOURCE_SEARCH=false\nSOURCE_SESSION='+str(session), flush=True)
        build_tool(output, args.stage_timeout)
        report = execute(config, output, args.stage_timeout)
        status.update(completion_status(report))
    except StageFailure as error:
        status.update(issue=str(error), failed_stage=error.stage, native_exit_code=error.code)
        if error.log.is_file():
            for line in error.log.read_text(errors='replace').splitlines()[-24:]:
                print('STAGE_LOG '+line[:900])
        # Include concise native diagnostics; large/raw detail remains in the run.
        if output:
            logs = sorted((output/'work').rglob('*.log'), key=lambda p:p.stat().st_mtime_ns, reverse=True)
            for path in logs[:3]:
                print('DETAIL_LOG='+str(path))
                for line in path.read_text(errors='replace').splitlines()[-8:]:print('DETAIL '+line[:600])
    except (ValueError, OSError, KeyError, TypeError) as error:
        status['issue'] = str(error)
    except KeyboardInterrupt:
        status['issue'] = 'interrupted; no automatic retry'
    if output:
        write_json(output/'run_status.json', status)
        print('DETAILS_FILE='+str(output/'run_status.json'))
    print('RESULT='+status['result'])
    if status.get('issue'):print('ISSUE '+status['issue'])
    print('EXPERIMENTAL_DC_READY='+str(status['experimental_dc_ready']).lower())
    print_completion(status)
    print('READY_FOR_SIZING=false\nRELIABILITY_VERIFIED=false\nPUBLISHED=false')
    return 0 if status['experimental_dc_ready'] or status.get('optimization_candidate_ready') else 2


if __name__ == '__main__':
    raise SystemExit(main())
