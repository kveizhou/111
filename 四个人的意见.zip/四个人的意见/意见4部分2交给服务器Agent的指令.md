# 复制以下内容发给能访问服务器源码的 Agent

你现在负责修复 Maau / LDO MOS Structure Transform 的跨子模块叠加变换。请先阅读本包的 `原始需求说明.md` 和 `技术方案与修改清单.md`，**必须直接在本地服务器仓库中完成实际修改、运行真实测试并给出日志证据**，不能只讨论方案，更不能因某个 C++ 单测通过就宣称 Virtuoso 物化已成功。

## 根因（不要再尝试只改 Canonical）

- `m_history` 目前被统一传给一次基于最后选中 `parent_subckt` 的单层 Snapshot；不同 parent 目标在这一份 baseline 中不可能全部找到，形成 Bug 2。
- `ChangeSet` 比较被裁剪的 `(subckt,leaf)`，同一个 master 两次实例化对应的不同 occurrence 被错判为同一 MOS，形成 Bug 1。
- **更严重**：即使把 Bug 1 去重修好，如果直接改一个被多个 occurrence 共享的 schematic master，则其它 occurrence 也会被错误变换。必须在变换前按完整实例路径隔离。

## 技术路线（默认要求）

- 用 `(DUT root, 层次路径 segments)` 作为稳定 target ID；保留 original target 与 staging local target 两套身份。
- 每次确认只处理一条新变换：从已提交 staging root 逐段解析当前实际 cellview，沿该路径浅克隆祖先和叶 cell，重绑定**被选中的父实例**到新 symbol/master，沿用现有单层 `Transform.cpp`、`OaPlan.cpp`，物化目标为新 leaf cell。验证后原子切换 committed root。**禁止**恢复所有 subckt 全展开或按 parent 独立 materialize 最后合并。
- `m_history` 只代表历史/重建输入，不能在每次单层 Run 中整批重放；最终发布当前的 committed root，不再重复执行 history。
- 原始 OA 库只读。失败时 root/revision/GUI 状态均不能变化。

## 先做 OA 探针，然后最小改代码

1. 查清服务器 Virtuoso/SKILL 版本、真实 DUT root 与 selected instance 的源库、schematic/symbol 绑定；确认 `dbCopyCellView` 和当前版本 remaster 可行性。
2. 在测试库新建 top，摆两个复用同一 leaf schematic+symbol 的实例，分别对其中一个实例的私有 leaf 加真实 resistor。必须证明只有被选中的顶层 occurrence 改变，未选中的仍引用原 master，顶层网表可正常生成。检查连线、端口、properties/CDF 和 original cell 未变。
3. 专门检查 `I15[104]`、`I21[7]`、`M1[3]` 是否属于不可单独修改的 iterated instance member。若是，暂时返回 `ARRAY_MEMBER_UNSUPPORTED` 并解释理由，不得把修改作用于整条阵列。若实现 detach，必须提交 bus 连接和其它成员参数一致性的验证证据。
4. 在第 2、3 条确认后，新增三个窄职责组件：
   - `OccurrenceResolver`：全路径从 staging DUT root 逐层定位，返回当前实际 `(lib,cell,view)` 与 leaf MOS；
   - `CowPathMaterializer`：只复制沿路径的 cellviews 并重绑定被选中实例，不碰旁支；
   - `StagingSession`：`sessionId`、`revision`、当前 `root`、已提交 target IDs、日志/事务清单、commit/abort。
5. 把原 `structure_transform_service.cc` 主流程拆为 `ApplyOneStagingChange` 和 `RunSingleLevel`，后者只接收一个**当前 staging leaf** 及一个 leaf-local MOS 变换。检查老的 `st_multi_level_materializer.il` 是否还隐藏地再 clone 一次：必须让返回的实际 leaf 始终被父实例引用。
6. 做 T01~T06/T09/T11（详见方案文档），特别是同 master 不同 occurrence、不同 parent 累积、原 master 不变、强制失败回滚。
7. 然后处理阵列成员 detachment T07/T08；Cascode 的 VBIAS 必须独立有可证明的 bias 路由/映射，否则返回 `VBIAS_CONTEXT_REQUIRED`，不得假接电源。

## 更改文件时注意

- GUI：`ldo_structure_transform_page.cpp/.h`，一次只传一条变换；成功提交才灰化/写成功 history；添加当前 staging revision。
- C++：`structure_transform_service.cc`、`ChangeSet.cpp`；`Transform.cpp` 与 `OaPlan.cpp` 尽量不变。
- Python：`st_virtuoso_backend.py`、`st_materialize_main.py`；日志必须按 session/txn 隔离。
- SKILL：`st_multi_level_materializer.il`、`export_snapshot.il`；先证实 symbol 与 schematic 的正确关系、所有对应 port/net，不能只修改字符串 master 名。
- 操作含 `I15[104]` 时，不要无条件替换 `[104]`→`<104>` 然后从字面字符串中取对象；必须从 OA 解析实际 array member。也要检查叶 `M1[3]`。

## 验收硬条件

- T01：`ldo_top.I19.M3` Stack，`ldo_top.ldo_main.ldo_400ma_core.I15[104].M3` Resistor，**两条真实 occurrence 的改造均出现在最终 DUT 顶层网表，且非目标实例无变化**（如果阵列成员需要先拆分，明确列出这个阻塞）。
- T02：先 `I50.M2` Resistor 再跨到另一 `parent_subckt` 做 Stack，不再从“最后 parent”重放历史。
- T03：同一 parent 下两个不同 MOS 连续处理，第二次读到第一次已改的 stage leaf，且不会叠加重复。
- T04：对同一完整路径反复点击，即使变更 type，也拒绝。
- T05：任意第二次 OA 操作故意失败，不改变上一成功 revision 和最终 root。
- T06：共享一个 master 的第三个无关 occurrence 不变。
- T07/T08：若未实现阵列位拆分，绝不能静默成功；要给出实测明确拒绝。
- T11：缺 symbol、端口不一致、断线、无法 netlist 时，即便 Python/SKILL 进程 exit=0 也必须终止发布。

## 交付格式

请直接修改和运行项目，并给出：

1. `git diff --stat`、实际改动的函数和理由；
2. 每个事务的 `original full path → current private leafRef → committed root` 证据；
3. 一份原版与修改版**顶层**网表中目标 occurrence 的对比；
4. T01~T06/T09/T11 的 PASS/FAIL 表，失败项必须包含关键日志、真实阻塞或复现方法，不得伪造“PASS”；
5. 与阵列成员 `I15[104]`/`M1[3]` 有关的 OA 观察结果与 `array` 支持结论；
6. 仍未覆盖的行为（如 Cascode bias）和继续实现所需信息。

**先完成最小的两个同 master 实例的 OA 探针再改业务逻辑。** 不要再次一开始就重写全层级网表解析或单层 `Transform` 算法。
