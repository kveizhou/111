1. 先拍板：推荐方案 D

核心原则

单层变换算法不动：仍然只对一个 parent cell 内部做 Snapshot → 重放 → expected → 物化。
历史不再全局重放：历史按“目标 MOS 所在的物理 cell 实例路径”分组，每组独立单层变换。
目标唯一身份用完整层次路径：修复 Bug 1。
跨子模块组合不靠网表合并，而靠实例重绑定：每个被改的物理 cell 实例生成一个 staging master；从目标向上，按需克隆祖先 cell，只改直接子实例的 master，直到顶层。
只克隆受影响路径的并集，不全展开所有子模块。方案 X 的坑不再踩。
一句话：
叶子 cell 内部怎么改，仍用单层；跨 cell 怎么挂回去，用重绑定计划。

2. 为什么 α 和 γ 不推荐

α：每次立即物化到“累积 staging”

问题在于：

staging cell 被改后，父层实例仍然指向旧 master，必须重绑定；
同一 cell 被多次实例化时，I19 和 I15[104] 都实例化 pio_l80_nfin4_s4，如果只维护一个“累积 staging”，两个物理实例会互相污染；
多次物化到同一 staging 的命名、连线、check&save 状态容易累积不可控；
本质上还是需要实例级重绑定，只是把问题藏到了“累积 staging”里。
所以 α 可以作为局部实现技巧，但不能作为架构。

γ：按子模块分 Tab 并行会话

改动小，但用户最终仍要“合并哪个”。如果不解决实例重绑定，只是把跨模块问题推迟到合并阶段。体验也不满足“连续对任意子模块叠加”。

3. 方案 D 的数据模型

3.1 目标身份

把现在丢失的完整路径补回来：

cpp
struct TargetRef {
  std::string root_dut;          // DUT 顶层 cell
  std::string full_path;         // ldo_top.I19.M3
  std::string physical_cell_path;// ldo_top.I19  （去掉最后一段 MOS 名）
  std::string leaf_instance;     // M3
  std::string parent_lib;
  std::string parent_subckt;     // pio_l80_nfin4_s4
};
Canonical() 不要再是：

cpp
parent_subckt + "/" + leaf_instance   // pio_l80_nfin4_s4/M3  ← Bug 1
改成至少：

cpp
root_dut + "/" + full_path            // ldo1_0_cbb_top/ldo_top.I19.M3
或者直接用 full_path 作为全局唯一键。
这样 ldo_top.I19.M3 和 ldo_top.ldo_main.ldo_400ma_core.I15[104].M3 绝不会撞。

3.2 分组键：物理 cell 实例路径

不要按 parent_subckt 分组，因为同一 master 可能被多次实例化。
按 physical_cell_path 分组：

ldo_top.I19 → master = pio_l80_nfin4_s4
ldo_top.ldo_main.ldo_400ma_core.I15[104] → master = pio_l80_nfin4_s4
这是两个不同组，各自生成不同 staging master，分别重绑定。

同一物理 cell 实例内部的多个 MOS 可以同组叠加，例如：

ldo_top.I50.M2
ldo_top.I50.M0
都落到 ldo_top.I50 这个物理 cell 实例，组内按历史顺序应用。

3.3 ChangeSet 改为“组内冲突检测”

全局唯一：full_path + type + seq 或直接 full_path 若 GUI 已置灰。
组内冲突：同一 physical_cell_path 下，同一 leaf_instance 不能重复变换。
不同 physical_cell_path 即使 parent_subckt 相同，也绝不冲突。
Bug 1 自然消失。

4. 新流程：从“全局 Run”改成“分组 Run + 重绑定计划”

STEP A：扫描时保留祖先链和电源网

StructureMosDevice 增加：

cpp
std::string full_path;
std::string physical_cell_path;   // full_path 去掉 leaf
std::string parent_lib;
std::string parent_subckt;
std::vector<std::string> ancestor_instances;
std::vector<std::string> visible_power_nets; // 给 Bug 3 用
STEP B：确认变换只入历史，不全局重放

GUI 里 m_history 保留完整 deviceId。
“生成电路”预览可以按组做，但最终“生成最终电路”统一物化。

STEP C：按物理 cell 实例分组

cpp
groups = GroupBy(m_history, target.physical_cell_path);
每组：

Snapshot 该组的 parent_subckt；
在 baseline 内只用 leaf_instance 定位（因为该组所有目标都在这个 cell 内部）；
按组内历史顺序应用变换；
得到该组的 expected_netlist；
物化克隆出该组的 staging master，命名带物理路径哈希，例如：
pio_l80_nfin4_s4__st__I19__a13f
注意：同一 master 的不同物理实例，staging cell 必须不同，不能共享。

Bug 2 自然消失：ldo_top.I50.M2 在自己的组里从 ts_nand2_18 导出；I21[7].M1[3] 在自己的组里从 nio_l240_nfin4_s2_p4 导出，不再用一个全局 transform_subckt 覆盖所有历史。

STEP D：构建最小祖先重绑定计划

对每个组，得到：

text
目标物理 cell 路径 P = ldo_top.I19
原 master = pio_l80_nfin4_s4
新 master = pio_l80_nfin4_s4__st__I19__a13f
需要把层次树中 ldo_top 里实例 I19 的 master 改为新 master。
如果 ldo_top 本身也被多个目标共享，则合并：

text
Patch(ldo_top) {
  child_rebinds: [
    I19       -> pio_l80_nfin4_s4__st__I19__a13f,
    I15[104]  -> pio_l80_nfin4_s4__st__I15_104__b27c
  ]
}
再向上，顶层实例 ldo_top 的 master 改为 ldo_top__st__...。

算法：

对每个组路径 P，创建 CellPatch(P)，记录内部变换和 staging master。
对 P 的每个祖先 A，在 CellPatch(A) 中增加一条 child_rebind：直接子实例名 → 子 staging master。
同一祖先合并。
自底向上物化：

先物化叶子组 staging；
再物化父 patch：克隆原父 cell，应用该父 cell 自己的内部变换（如果有），再把直接子实例 master 重绑定到子 staging；
一直到 DUT 顶层。
最终顶层 staging 就是最终电路，不覆盖原 cell。
关键：只克隆目标路径并集上的 cell 实例，不递归展开所有 subckt。
这避开了方案 X 的“全展开、递归死循环、引用名不匹配”。

5. 物化计划 JSON 建议

不要只写“哪个 cell 要克隆、哪些实例增删改”，增加两类操作：

json
{
  "cell_patches": [
    {
      "path": "ldo_top.I19",
      "base_master": "pio_l80_nfin4_s4",
      "staging_master": "pio_l80_nfin4_s4__st__I19__a13f",
      "internal_ops": ["stack M3 ..."]
    },
    {
      "path": "ldo_top",
      "base_master": "ldo_top",
      "staging_master": "ldo_top__st__...",
      "child_rebinds": [
        {"instance": "I19", "new_master": "pio_l80_nfin4_s4__st__I19__a13f"},
        {"instance": "I15[104]", "new_master": "pio_l80_nfin4_s4__st__I15_104__b27c"}
      ]
    }
  ],
  "materialize_order": ["ldo_top.I19", "ldo_top.I15[104]", "ldo_top", "ldo1_0_cbb_top"]
}
SKILL 侧只需要支持：

克隆 cell 到 staging；
在 staging 内执行原有单层变换；
对 staging 内指定直接子实例 dbSetInstHeaderMaster 或等价重绑定；
schCheck + dbSave。
6. 分阶段落地，避免一次大改

阶段 0：止血热修

InstancePath::Canonical() 加入 hierarchy_path 或 root_dut + full_path。修 Bug 1。
Run 检测历史跨 physical_cell_path 时，不要再用最后选中的 transform_subckt 全局重放。临时可以：

只处理当前选中组；
其他组提示“将在最终生成时分组处理”。
先避免 Bug 2 的“找不到就崩”。
阶段 1：分组单层变换

ChangeSet 按 physical_cell_path 分组。
每组独立 Snapshot、重放、生成 expected、物化 staging。
先不做祖先重绑定，只输出多个 staging cell 和清单，用于验证每组变换正确。
阶段 2：最小祖先重绑定

实现 CellPatch 树和 child_rebinds。
先支持“同一 master 不同实例”的 Bug 1 场景。
再支持跨 parent、共享祖先合并。
验证：I19.M3 和 I15[104].M3 各自生成 staging，互不影响；父层只克隆一次 ldo_top，里面两个实例分别重绑定。
阶段 3：Bug 3 电源轨

Cascode VBIAS 不要只从当前 baseline 的 subckt 端口找 VDD/GND。
标准单元 nio_l240_nfin4_s4 端口只有 B D G S，本来就没有电源端口。建议：

ScanMos 时记录祖先层次可见的电源网；
或请求 payload 带 power_net/ground_net；
短期 GUI 对无电源端口的标准单元提示选择电源轨，或禁用 Cascode。
7. 必须保留的验证用例

Bug 1 回归：
ldo_top.I19.M3 Stack + ...I15[104].M3 Resistor。
期望：两个不同 staging master，父层 ldo_top 中 I19 和 I15[104] 分别重绑定，互不污染。
Bug 2 回归：
历史含 ldo_top.I50.M2 + 新选 ...I21[7].M1[3]。
期望：按 ldo_top.I50、...I21[7] 分组，各自 Snapshot，不出现 nio_l240...M2 not found。
同物理实例叠加：
ldo_top.I50.M2 和 ldo_top.I50.M0 都改。
期望：同一 ldo_top.I50 staging 内顺序应用，只生成一个 staging master。
共享祖先合并：
两个目标都在 ldo_top 下不同子实例。
期望：只克隆一个 ldo_top__staging，里面两条 child_rebind。
未目标实例不受影响：
同一 pio_l80_nfin4_s4 的其他实例保持原 master。
8. 最终建议

如果只允许我拍一个方向：

采用方案 D：完整路径唯一化 + 按物理 cell 实例分组单层变换 + 最小祖先链实例重绑定。
先修 Canonical() 和 Run 的全局 transform_subckt，再把物化计划从“单层根层物化”扩展为“CellPatch 树 + child_rebind”。
不要全展开，不要全局历史重放，不要共享 staging master。
这样既保留了已验证的单层变换简单性，又能真正支持“跨子模块连续叠加”，并且 Bug 1、Bug 2 都是从模型上消失，而不是靠提示绕过。
