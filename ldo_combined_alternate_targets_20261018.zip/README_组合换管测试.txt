组合功能换目标测试（2026-10-18）

前提：已安装ldo_source_resistor_precision_fix_20261018.zip并重编过工具。
本包只增加目标分配入口，无需再次重编C++。主st-engine-maau已同步修改。

上传到st-engine-maau同级目录，整行执行：
unzip -o ldo_combined_alternate_targets_20261018.zip && bash st-engine-maau/scripts/test_mixed_cascode.sh combo-alt "$st_batch/candidate_I21_xbb892w0"

本轮复用同一混合测试会话并重新设置活动操作：
1. I105串入真实PDK电阻，再撤销。
2. I29生成同型PMOS Cascode。
3. I85生成异型NMOS Cascode（同极性、不同已准入Master）。
4. I21生成两级共栅Stack。
5. 统一生成；每Cascode最多16次累积自动搜索，保留前组并检查最低条件；Stack包含在最终整体电路DC中。
6. 命令自动核对实际生成网表中的连接、型号、撤销恢复和最终DC结果。

这是现有四个已绑定目标的另一种功能分配，不是扫描四个新目标。中间确认/撤销不单独启动DC。
前几行应为：
RESISTOR_UNDO_TARGET=I105
SAME_TARGET=I29
CROSS_TARGET=I85
STACK_TARGET=I21
STACK_STAGES=2
INTERMEDIATE_DC_SEARCHES=0

实际生成完成且结构正确时：
TEST_GROUPS=3
GENERATED_SUBCELLS=5
RESULT_CELL=实际库/Cell/schematic
RESISTOR_UNDO_RESTORED=PASS TARGET=I105
SAME_CASCODE_D_SIDE=PASS TARGET=I29
CROSS_CASCODE_D_SIDE=PASS TARGET=I85
ORIGINAL_GSB_PRESERVED=PASS
VBIAS_CONNECTIONS=PASS
STACK_SERIES_SHARED_GATE=PASS TARGET=I21 STAGES=2
COMBINED_STRUCTURE_TEST=PASS

只有最终最低DC条件全部满足才输出：
COMBINED_DC_TEST=PASS
COMBINED_FEATURES_TEST=PASS
退出码0。

若成功生成待优化电路但尚有电气未满足项，则显示：
COMBINED_DC_TEST=NOT_PASSED
UNMET_REQUIREMENTS=实际未满足项
OPTIMIZATION_CANDIDATE_READY=true
COMBINED_FEATURES_TEST=INCOMPLETE
退出码2。若后端执行失败或无法保持前组最低条件，可能提前停止，不承诺本轮一定生成或通过。

只复查最近结果，不重跑DC：
bash st-engine-maau/scripts/test_mixed_cascode.sh combo-check "$st_batch/candidate_I21_xbb892w0"

打开最近生成电路：
bash st-engine-maau/scripts/test_mixed_cascode.sh open "$st_batch/candidate_I21_xbb892w0"

只需回传结尾COMBINED_*、UNMET_REQUIREMENTS和RESULT_CELL；提前失败则回传首条实际错误及对应DETAIL。
52项相关Python测试及Shell语法检查本地通过，含后端替身；未在本机运行Cadence/Spectre，新组合电气结果以服务器实测为准。
