"""One-command saved baseline to formal reader acceptance, using process fixtures."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import shutil
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import io
from contextlib import redirect_stdout

import CascodeNodeContextTest as node_fixture
from CascodeSavedDcTest import ENTRY


class CascodeRuntimeBridgeTest(unittest.TestCase):
    def prepare(self,root):
        fixture=node_fixture.CascodeNodeContextTest()
        s,r,p,b,e,base,cache=fixture.fixture(root,peripheral=True)
        old=fixture.seed_v1_node_cache(s,r,p,b,e,base)
        native=root/'formal_ocean'
        native.write_text('#!'+sys.executable+'\n'+'''import csv,json,os,sys
from pathlib import Path
work=Path(sys.argv[-1]).parent
script=Path(sys.argv[-1]).read_text()
assert 'createNetlist(' not in script and 'run()' not in script
source=Path(os.environ['OP_SOURCE']);nodesource=Path(os.environ['NODE_SOURCE'])
(work/'ops.tsv').write_bytes(source.read_bytes())
with nodesource.open() as f:rows=[r for r in csv.DictReader(f,delimiter='\\t') if r['status']=='OK']
if os.environ.get('WRONG_SIGN'):
 text=(work/'ops.tsv').read_text().replace('-1e-06','1e-06');(work/'ops.tsv').write_text(text)
with (work/'nodes.tsv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=['kind','signal','value','status'],delimiter='\\t');writer.writeheader();writer.writerows(rows)
(work/'runtime.done').write_text('OK\\n')
''');native.chmod(0o755)
        e.update(ST_OCEAN_BIN=str(native),OP_SOURCE=str(cache/'baseline_op/values.tsv'),NODE_SOURCE=str(old/'node_read/values.tsv'),
                 ST_VIRTUOSO_BIN='/do-not-read-maestro',ST_SPECTRE_BIN='/do-not-simulate')
        return s,r,p,b,e,base

    def invoke(self,s,r,p,b,e):
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(s),'--maestro-read',str(r),'--preflight',str(p),
            '--batch',str(b),'--prepare-runtime'],env=e,capture_output=True,text=True)

    def test_prepares_reusable_bundle_and_formal_reader_matches_cache_without_rerun(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp));before={f:f.read_bytes() for f in base.rglob('*') if f.is_file()}
            result=self.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            for marker in ('RESULT=RUNTIME_BRIDGE_OK','RUNTIME_CACHE_MATCH=true','SPECTRE_RERUN=false','VBIAS_GENERATED=false','SIMULATION_PROFILE_READY=false'):
                self.assertIn(marker,result.stdout)
            for f,value in before.items():self.assertEqual(f.read_bytes(),value)
            out=next(base.glob('runtime_bridge_*'))
            query=json.loads((out/'query.json').read_text())
            self.assertNotIn('AGND',query['nodes'])
            self.assertFalse(any('net037' in n for n in query['nodes']))
            self.assertTrue((out/'bundle/baseline_bundle.json').exists())
            gaps=json.loads((out/'remaining_inputs.json').read_text())
            self.assertIn('supply_current_signals',gaps['profile_missing'])
            self.assertIn('max_vbias_current',gaps['profile_missing'])
            self.assertEqual(gaps['unresolved_context_nodes'],['AGND',r'net037\<0\>',r'net037\<1\>'])

    def test_wrong_formal_sign_never_passes_cache_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp));e['WRONG_SIGN']='1'
            result=self.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('formal reader differs from validated cache',result.stdout)
            self.assertNotIn('RUNTIME_CACHE_MATCH=true',result.stdout)

    def test_bundle_dependency_error_retains_formal_read_acceptance_and_all_gaps(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp))
            sys.path.insert(0,str(ENTRY.parent))
            import runtime_bridge
            args=SimpleNamespace(session=str(s),maestro_read=str(r),preflight=str(p),batch=str(b),timeout=30)
            stream=io.StringIO()
            failure_message='missing baseline dependency: constants.vams\n'+'detail_'*200
            # Native read runs normally; isolate the export error boundary.
            with patch.dict(os.environ,e),patch('baseline_bundle.export_bundle',side_effect=ValueError(failure_message)),redirect_stdout(stream):
                code=runtime_bridge.prepare_runtime(args)
            self.assertEqual(code,2)
            self.assertIn('RESULT=READER_OK_BUNDLE_INCOMPLETE',stream.getvalue())
            self.assertIn('RUNTIME_CACHE_MATCH=true',stream.getvalue())
            out=next(base.glob('runtime_bridge_*'))
            self.assertTrue((out/'remaining_inputs.json').exists())
            self.assertTrue((out/'comparison.json').exists())
            diagnostics=json.loads((out/'bundle_dependency_issues.json').read_text())
            self.assertEqual(diagnostics['message'],failure_message)
            self.assertEqual(diagnostics['issue_count'],1)
            self.assertIn('BUNDLE_ISSUE_COUNT=1',stream.getvalue())

            # Server v1 predates the explicit evidence-hash/reference fields.
            status=json.loads((out/'bridge_status.json').read_text())
            status.pop('reader_cache_dir',None);status.pop('reader_cache_sha256',None)
            (out/'bridge_status.json').write_text(json.dumps(status))

            # Resume a v1 partial success with no native executable available.
            e['ST_OCEAN_BIN']='/do-not-read-again'
            for _ in range(2):
                resumed=self.invoke(s,r,p,b,e)
                self.assertEqual(resumed.returncode,0,resumed.stdout+resumed.stderr)
                self.assertIn('FORMAL_READER_REUSED=true',resumed.stdout)
                self.assertIn('OCEAN_RERUN=false',resumed.stdout)
                self.assertIn('RUNTIME_CACHE_MATCH=true',resumed.stdout)

    def test_latest_formal_cache_corruption_never_rereads_or_falls_back(self):
        for name in ('query.json','expected_values.json','comparison.json','raw_signed.tsv',
                     'raw_signed.tsv.sources.json','psf_reader/ops.tsv','psf_reader/runtime.done'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as tmp:
                s,r,p,b,e,base=self.prepare(Path(tmp))
                first=self.invoke(s,r,p,b,e)
                self.assertEqual(first.returncode,0,first.stdout+first.stderr)
                out=next(base.glob('runtime_bridge_*'))
                (out/name).write_text('corrupt\n')
                e['ST_OCEAN_BIN']='/do-not-read-again'
                result=self.invoke(s,r,p,b,e)
                self.assertEqual(result.returncode,2,result.stdout+result.stderr)
                self.assertIn('formal reader cache',result.stdout)
                self.assertNotIn('RUNTIME_CACHE_MATCH=true',result.stdout)
                self.assertEqual(len(list(base.glob('runtime_bridge_*'))),1)

    def test_equal_time_success_and_failure_caches_are_ambiguous(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp))
            first=self.invoke(s,r,p,b,e)
            self.assertEqual(first.returncode,0,first.stdout+first.stderr)
            out=next(base.glob('runtime_bridge_*'));other=base/'runtime_bridge_other'
            shutil.copytree(out,other)
            (other/'bridge_status.json').write_text(json.dumps({'cache_match':False,'psf_unchanged':True}))
            stamp=(out/'bridge_status.json').stat().st_mtime_ns
            os.utime(other/'bridge_status.json',ns=(stamp,stamp))
            e['ST_OCEAN_BIN']='/do-not-read-again'
            result=self.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('ambiguous formal reader cache',result.stdout)
            self.assertNotIn('RUNTIME_CACHE_MATCH=true',result.stdout)


if __name__=='__main__':unittest.main()
