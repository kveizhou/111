"""Accept a saved baseline through the formal reader and report remaining inputs."""
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile

from site_data import read_json, write_json, verify_site_inputs
from dc_results import canonical_device, consume_query, validate_query


def reader_evidence_hashes(directory):
    from read_cascode_solver_settings import file_digest
    names = ('query.json','expected_values.json','comparison.json','raw_signed.tsv',
             'raw_signed.tsv.sources.json','psf_reader/nodes.tsv','psf_reader/ops.tsv',
             'psf_reader/runtime.done','psf_reader/runtime.ocn','formal_reader.log')
    return {name:file_digest(directory/name) for name in names}


def accepted_reader_cache(baseline, query, expected, psf_hashes):
    """Replay the latest acceptance, including v1's partial Bundle success."""
    from collect_cascode_batch import table
    from op_provider import read_raw
    candidates = [p for p in baseline.glob('runtime_bridge_*') if p.is_dir()]
    if not candidates:
        return None, None
    def stamp(path):
        status=path/'bridge_status.json'
        return (status if status.is_file() else path).stat().st_mtime_ns
    candidates.sort(key=stamp,reverse=True)
    if len(candidates)>1 and stamp(candidates[0])==stamp(candidates[1]):
        raise ValueError('ambiguous formal reader cache: latest timestamps are equal')
    latest=candidates[0]
    try:
        state = read_json(latest/'bridge_status.json')
        if not isinstance(state,dict):
            raise ValueError('invalid acceptance status')
        if state.get('cache_match') is not True or state.get('psf_unchanged') is not True:
            raise ValueError('latest acceptance is incomplete')
        if state.get('error') != state.get('bundle_error'):
            raise ValueError('latest acceptance has a reader error')
        root = Path(state.get('reader_cache_dir') or latest).resolve()
        if root.parent != baseline.resolve() or not root.name.startswith('runtime_bridge_'):
            raise ValueError('reader evidence outside this baseline')
        hashes = reader_evidence_hashes(root)
        if state.get('reader_cache_sha256') is not None and state['reader_cache_sha256'] != hashes:
            raise ValueError('reader evidence fingerprint changed')
        for directory in set((latest,root)):
            if read_json(directory/'query.json') != query or read_json(directory/'expected_values.json') != expected:
                raise ValueError('query or expected values changed')
            if read_json(directory/'comparison.json') != dict(compared=len(expected),differences={}):
                raise ValueError('comparison is not a complete match')
        if (root/'psf_reader/runtime.done').read_text().strip() != 'OK':
            raise ValueError('completion marker missing')
        sources = read_json(root/'raw_signed.tsv.sources.json')
        if not isinstance(sources,dict):
            raise ValueError('invalid source metadata')
        if sources.get('query') != query or sources.get('psf_sha256') != psf_hashes:
            raise ValueError('source query or PSF differs')
        raw, origins = consume_query(query, table(root/'psf_reader/nodes.tsv'), table(root/'psf_reader/ops.tsv'))
        if sources.get('sources') != origins or sources.get('intrinsic_op_preserved') is not True or sources.get('terminal_differences_computed_by_consumer') is not True:
            raise ValueError('raw source metadata differs')
        if raw != read_raw(root/'raw_signed.tsv') or raw != expected:
            raise ValueError('raw signed values differ from validated cache')
        if hashes != reader_evidence_hashes(root):
            raise ValueError('reader evidence changed during verification')
        return root, hashes
    except (ValueError,OSError,KeyError,TypeError,StopIteration) as error:
        raise ValueError('formal reader cache invalid: '+str(error)) from error


def cache_query(request, report, op_rows):
    nodes=sorted({n for t in request['targets'].values() for n in t['terminals'].values()})
    paths={canonical_device(t['path']) for t in request['targets'].values()}
    parameters={p:[] for p in sorted(paths)}
    for row in op_rows:
        path=canonical_device(row['signal'])
        if row['kind']=='op' and path in paths and row['status']=='OK':
            try:value=float(row['value'])
            except (ValueError,TypeError):raise ValueError('cached OP numeric value invalid')
            if not math.isfinite(value):raise ValueError('cached OP value nonfinite')
            parameters[path].append(row['parameter'])
    currents=sorted(r['signal'] for r in report['voltage_source_currents'] if r['status']=='OK')
    return validate_query(dict(schema='st-dc-query-v1',nodes=nodes,
        device_parameters={p:sorted(items) for p,items in parameters.items()},currents=currents))


def remaining_inputs(bound, report, pdk, bundle):
    profile=read_json(bound['pinned']['rules'])
    profile_keys=('max_branch_current_error','max_vbias_current','vbias_vhigh_net','vbias_vlow_net','supply_current_signals')
    targets={}
    for name,item in pdk['targets'].items():
        dev=item['metadata'][0] if len(item['metadata'])==1 else {}
        missing=[]
        if dev.get('kind') not in ('mos_n','mos_p'):missing.append('proven_mos_polarity')
        for key in ('maxAbsVgs','maxAbsVds','maxAbsVgb','bulkRule','voltageDomains','rules_source'):
            if not dev.get(key):missing.append(key)
        constraints=dev.get('constraints',{})
        if not constraints.get('length'):missing.append('legal_length_domain')
        if not constraints.get('width') and not constraints.get('fin'):missing.append('legal_width_or_fin_domain')
        if not dev.get('electrical_rules',{}).get('dc_signals'):missing.append('documented_dc_signal_mapping')
        targets[name]=dict(oa_library=item['master']['oa_library'],oa_cell=item['master']['oa_cell'],
            missing=missing,recorded_missing=dev.get('missing',[]),existing_constraints=constraints)
    return dict(profile_missing=[k for k in profile_keys if not profile.get(k)],target_pdk=targets,
        unresolved_context_nodes=sorted(i['signal'] for i in report['node_issues']),
        supply_candidates=report['voltage_source_currents'],supply_candidates_are_not_total_current_bindings=True,
        other_required=['VBIAS template N/P/resistor master selection and legal CDF geometry',
            'resistor voltage/current/power ratings by geometry and temperature',
            'BSIM-CMG terminal reliability vs intrinsic saturation consumer contract',
            'fixed-parameter PVT profiles and actual candidate OA/Spectre acceptance'],
        omitted_launch_options=bundle.get('launch_contract',{}).get('omitted_launch_options',[]),
        simulation_profile_ready=False,pdk_electrical_rules_ready=False)


def prepare_runtime(args):
    import collect_cascode_batch as cb
    import read_cascode_solver_settings as reader
    from baseline_bundle import export_bundle, load_bundle
    from op_provider import read_raw
    body=[];out=None;error=None;matched=False;unchanged=False;bundle_ready=False;bundle_error=None;reader_verified=False
    reused=False;ocean_run=False;reader_cache=None;reader_hashes=None
    print('RUNTIME_BRIDGE=START',flush=True)
    try:
        if args.timeout<=0:raise ValueError('timeout must be positive')
        bound,baseline,psf=reader.validated_baseline(args,body)
        before=reader.psf_fingerprint(psf)
        request=reader.node_request(bound,Path(args.batch))
        cached,cache=reader.cached_target_op(bound,baseline,request,before)
        rows,_,node_cache=reader.cached_node_rows(bound,baseline,request,cached,before)
        if node_cache is None:raise ValueError('successful target node cache is required')
        report=reader.summarize_nodes(rows,request,cached)
        if not all(report.get(k) for k in ('data_valid','target_nodes_complete','cgg_complete')):
            raise ValueError('cached target context is incomplete')
        query=cache_query(request,report,cb.table(cache/'baseline_op/values.tsv'))
        node_rows=[r for r in rows if (r['kind']=='node' and r['signal'] in query['nodes']) or (r['kind']=='current' and r['signal'] in query['currents'])]
        expected,_=consume_query(query,node_rows,cb.table(cache/'baseline_op/values.tsv'))
        reader_cache,reader_hashes=accepted_reader_cache(baseline,query,expected,before)
        reused=reader_cache is not None
        out=Path(tempfile.mkdtemp(prefix='runtime_bridge_',dir=str(baseline)))
        body.append('OUTPUT_DIR='+str(out))
        write_json(out/'query.json',query);write_json(out/'expected_values.json',expected)
        bundle={};bundle_path=None
        try:
            bundle_path=export_bundle(bound,baseline,out/'bundle');bundle=load_bundle(bundle_path);bundle_ready=True
        except (ValueError,OSError,KeyError,TypeError) as caught:
            bundle_error=' '.join(str(caught).split())[:1000]
            body.append('BUNDLE_ISSUE '+bundle_error)
            issues=getattr(caught,'issues',None) or [dict(message=str(caught))]
            issue_path=out/'bundle_dependency_issues.json'
            write_json(issue_path,dict(schema='bundle-dependency-issues-v1',message=str(caught),
                issue_count=len(issues),issues=issues,closure_complete=False,
                scope='discovered issues in traversable selected branches; failed branches remain unexpanded'))
            body+=['BUNDLE_ISSUE_COUNT='+str(len(issues)),'BUNDLE_ISSUES_FILE='+str(issue_path)]
            for item in issues[:8]:
                # JSON escaping preserves original whitespace/quotes in copied diagnostics.
                body.append('DEPENDENCY_ISSUE '+json.dumps({k:v for k,v in item.items()
                    if k not in ('section_declarations','declarations_omitted')},ensure_ascii=True))
            body.append('DEPENDENCY_ISSUES_OMITTED='+str(max(0,len(issues)-8)))
        # Dependency collection may be incomplete, but never ignore changed
        # already-pinned source inputs in order to keep the reader running.
        verify_site_inputs(bound['pinned'],bound['env']);cb.unchanged(bound)
        gaps=remaining_inputs(bound,report,cb.pdk(bound,out),bundle)
        gaps['bundle_error']=bundle_error
        gaps['recursive_dependencies_historically_verified']=bundle.get('recursive_dependencies_historically_verified',False)
        gaps['first_fingerprinted_at_export_paths']=bundle.get('first_fingerprinted_at_export_paths',[])
        write_json(out/'remaining_inputs.json',gaps)
        body+=['BASELINE_BUNDLE='+(str(bundle_path) if bundle_ready else 'INCOMPLETE'),'PROFILE_MISSING='+','.join(gaps['profile_missing'])]
        for name,item in gaps['target_pdk'].items():body.append('PDK_MISSING '+name+' '+','.join(item['missing']))
        body+=['REMAINING_INPUTS='+str(out/'remaining_inputs.json'),'UNRESOLVED_CONTEXT_NODES='+str(len(gaps['unresolved_context_nodes']))]
        runtime=Path(__file__).with_name('cascode_runtime.py')
        try:
            if not reused:
                ocean_run=True
                cb.command([sys.executable,str(runtime),'read-psf','--psf-dir',str(psf),'--request',str(out/'query.json'),
                    '--output',str(out/'raw_signed.tsv'),'--cds-path',str(bound['cds'].parent),'--timeout',str(args.timeout)],
                    out,bound['env'],args.timeout+10,out/'formal_reader.log')
                reader_cache=out
            actual=read_raw(reader_cache/'raw_signed.tsv')
            differences={k:dict(expected=expected.get(k),actual=actual.get(k)) for k in set(actual)|set(expected)
                if k not in actual or k not in expected or actual[k]!=expected[k]}
            write_json(out/'comparison.json',dict(compared=len(expected),differences=differences))
            if differences:raise ValueError('formal reader differs from validated cache: '+','.join(sorted(differences)))
            if reused and reader_evidence_hashes(reader_cache)!=reader_hashes:
                raise ValueError('formal reader cache changed during Bundle export')
            reader_hashes=reader_evidence_hashes(reader_cache)
            body.append('FORMAL_READER_CACHE_DIR='+str(reader_cache))
            matched=True;body.append('MATCHED_SIGNALS='+str(len(expected)))
        finally:
            unchanged=before==reader.psf_fingerprint(psf)
            cb.unchanged(bound);verify_site_inputs(bound['pinned'],bound['env'])
            if bundle_ready:load_bundle(bundle_path)
            if not unchanged:raise ValueError('PSF changed during formal reader acceptance')
        reader_verified=matched and unchanged
        if bundle_error:error=bundle_error
    except (ValueError,OSError,KeyError,TypeError,subprocess.SubprocessError) as caught:
        error=' '.join(str(caught).split())[:1000];body.append('ISSUE '+error)
        if out:
            for path in (out/'formal_reader.log',out/'psf_reader/ocean.log'):
                if path.is_file():body+=['LOG '+line[:700] for line in path.read_text(errors='replace').splitlines()[-8:]]
    result='RUNTIME_BRIDGE_OK' if error is None else 'READER_OK_BUNDLE_INCOMPLETE' if reader_verified and bundle_error else 'INCOMPLETE'
    summary=['CHECKER=cascode-runtime-bridge-v2','RESULT='+result,
        'FORMAL_READER_REUSED='+str(reused).lower(),'OCEAN_RERUN='+str(ocean_run).lower(),
        'SPECTRE_RERUN=false','BASELINE_BUNDLE_READY='+str(bundle_ready).lower(),
        'RUNTIME_CACHE_MATCH='+str(reader_verified).lower(),'PSF_UNCHANGED='+str(unchanged).lower()]
    summary+=body+['SIMULATION_PROFILE_READY=false','PDK_ELECTRICAL_RULES_READY=false','ELECTRICAL_VERIFIED=false',
        'VBIAS_GENERATED=false','RAW_DETAILS_REMAIN_ON_SERVER=true']
    if out:
        write_json(out/'bridge_status.json',dict(error=error,bundle_error=bundle_error,cache_match=reader_verified,psf_unchanged=unchanged,
            reader_cache_dir=str(reader_cache) if reader_cache else None,reader_cache_sha256=reader_hashes))
        (out/'summary.txt').write_text('\n'.join(summary)+'\n')
    print('\n'.join(summary));return 0 if error is None else 2
