LDO 候选试参收缩补丁 2026-10-15

适用：已应用 ldo_resistor_geometry_fix_20261015.zip 的现有 st-engine-maau。
本包包括上一 ldo_reader_contract_fix_20261015.zip 的六个文件，不必再单独解压上一包。

四项行为：
1. CDF更新、网表/工作点读取、后端执行等软件错误立即停止，不再换下一个阻值浪费时间。
2. --reference-resistor-scales 可以只给一个值，例如 8；仍可给 8,4,16 作为最多三个可行性试点。
3. 同次generate首次创建真实候选OA；参数点复用同一OA，只更新参数和回读变化子图。每点仍真实导出网表、跑DC，选中后独立生成最终OA并再验证。
4. 软件版本门禁和未改外围全面重复检查保持取消；不重跑已通过且输入未变的基线或PDK扫描。

本地验证通过；没有在本机运行Cadence，服务器参数更新和DC仍待验证。饱和、实际接线、参数生效和最终电气检查没有取消。实验DC通过不等于完整LDO功能、可靠性或PVT验收。

将zip上传到 /tmpdata/maau_epc/users/k00981589，沿用原csh会话和st_batch。
下面unzip开头的一行作为完整的一行执行：

cd /tmpdata/maau_epc/users/k00981589
unzip -o ldo_focused_trials_20261015.zip && bash st-engine-maau/scripts/build.sh --tool-only && python3 st-engine-maau/scripts/resume_cascode_experiment.py --batch "$st_batch" --reuse-verified-inputs --reference-resistor-scales 8,4,16
set st_rc = $status
echo "退出码=$st_rc"

预期流程：
CANDIDATE_OA_MODE=BUILD point=...（首次）
CANDIDATE_READBACK_CELLS=3
若还需后续阻值：
CANDIDATE_OA_MODE=UPDATE point=...（仅参考电阻变化）
CANDIDATE_READBACK_CELLS=1
point编号是现有目录的递增编号，不一定从1开始；cell名保持同一候选模板。第一个点可行时，不应强行出现UPDATE或跑满三点。

如果找到可行点且最终OA验证通过：RESULT=EXPERIMENT_DC_PASS、EXPERIMENTAL_DC_READY=true、退出码0。
如果真实DC收敛但saturation失败：保留真实失败条件，才继续下一阻值；最多三个点。全部失败则RESULT=INCOMPLETE、退出码2。
如果软件调用/读取失败：reason=evaluation_failed、converged=unknown，不继续剩余阻值；无效电气指标为null/unknown，不报假零或伪称电路不收敛。
RELIABILITY_VERIFIED=false、READY_FOR_SIZING=false、PUBLISHED=false仍是本轮实验边界。

请只回传CANDIDATE_OA_MODE、CANDIDATE_READBACK_CELLS、TRIAL_RESULT、RESULT与退出码；若软件失败再加第一条DETAIL错误及SOLVER_POINT的host_message。无需粘贴完整CDF/器件清单。
