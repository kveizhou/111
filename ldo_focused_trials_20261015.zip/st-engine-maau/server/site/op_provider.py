#!/usr/bin/env python3
"""Actual OA -> isolated Bench -> Spectre -> signed raw PSF provider.

The runtime calls Cadence tools directly. This module owns strict binding,
Corner selection and exact signal extraction, without mutating source OA/circuit.
"""
import argparse
import ast
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from site_data import finite, read_json, write_json, verify_site_inputs
from dc_results import canonical_device

INSTANCE = re.compile(r'^\s*(\S+)\s*\(([^)]*)\)\s+(\S+)(.*)$')
ASSIGN = re.compile(r'([A-Za-z_][\w$]*)\s*=\s*("[^"]*"|\S+)')


class RuntimeFailure(RuntimeError):
    def __init__(self, message, code):
        super().__init__(message)
        self.code = code if code in (70, 71) else 70


def lines(text):
    out, previous, continued = [], None, False
    for line in text.splitlines():
        stripped = line.lstrip()
        # Keep comments in emitted decks without treating them as statements.
        if not stripped or stripped.startswith('//'):
            out.append(line)
            continue
        plus = stripped.startswith('+')
        if plus:
            line = stripped[1:].lstrip()
        if plus or continued:
            if previous is None:
                raise ValueError('Spectre continuation without a preceding statement')
            out[previous] += ' ' + line.lstrip()
        else:
            out.append(line)
            previous = len(out)-1
        continued = out[previous].rstrip().endswith('\\')
        if continued:
            out[previous] = out[previous].rstrip()[:-1].rstrip()
    if continued:
        raise ValueError('unterminated Spectre continuation')
    return out


def parse_deck(text):
    deck_lines = lines(text)
    definitions, top, parameters, global_nodes = {}, [], {}, {'0'}
    current = None
    for index, line in enumerate(deck_lines):
        stripped = line.strip()
        if not stripped or stripped.startswith('//'):
            continue
        if stripped.startswith('simulator ') and 'lang=spectre' not in stripped:
            raise ValueError('only explicit Spectre language is supported')
        parts = stripped.split()
        if parts[0] == 'subckt':
            if current or len(parts) < 2 or parts[1] in definitions:
                raise ValueError('nested or duplicate subckt')
            ports = parts[2:]
            if any('=' in port for port in ports):
                raise ValueError('subckt header parameter syntax requires explicit support')
            current = {'name': parts[1], 'ports': ports, 'instances': [], 'parameters': {}, 'start': index}
            definitions[parts[1]] = current
        elif parts[0] == 'ends':
            if current is None or (len(parts) > 1 and parts[1] != current['name']):
                raise ValueError('unmatched ends')
            current['end'] = index
            current = None
        elif parts[0] == 'global':
            global_nodes.update(parts[1:])
        elif parts[0] == 'parameters':
            target = current['parameters'] if current else parameters
            for key, value in ASSIGN.findall(stripped[len('parameters'):]):
                if key in target:
                    raise ValueError('duplicate parameter: ' + key)
                target[key] = value
        else:
            match = INSTANCE.match(line)
            if match:
                name, nodes, master, tail = match.groups()
                inst = {'name': name, 'nodes': nodes.split(), 'master': master,
                        'params': dict(ASSIGN.findall(tail)), 'line': index, 'tail': tail}
                target = current['instances'] if current else top
                if any(i['name'] == name for i in target):
                    raise ValueError('duplicate instance: ' + name)
                target.append(inst)
    if current:
        raise ValueError('missing ends')
    return {'lines': deck_lines, 'definitions': definitions, 'top': top,
            'parameters': parameters, 'globals': global_nodes}


def bench_context_digest(text):
    # Ocean export comments may contain run timestamps. Electrical statements,
    # includes, variables and options remain part of the immutable Bench proof.
    canonical = '\n'.join(line.strip() for line in lines(text)
                          if line.strip() and not line.strip().startswith('//'))
    return hashlib.sha256(canonical.encode()).hexdigest()


def resolve_includes(text, directory):
    pattern = re.compile(r'^(\s*(?:include|ahdl_include)\s+)"([^"]+)"(.*)$')
    out = []
    for line in lines(text):
        match = pattern.match(line)
        if match:
            path = Path(os.path.expandvars(os.path.expanduser(match[2])))
            if '$' in str(path):
                raise ValueError('unset include path environment variable')
            if not path.is_absolute():
                path = Path(directory) / path
            path = path.resolve()
            if not path.is_file():
                raise ValueError('actual netlist include missing: ' + str(path))
            line = match[1] + json.dumps(str(path)) + match[3]
        out.append(line)
    return '\n'.join(out) + '\n'


def check_bench_binding(context_path, text, corner=None):
    suffix = '_' + hashlib.sha256(corner.encode()).hexdigest() if corner is not None else ''
    evidence = Path(context_path).parent / ('bench_binding' + suffix + '.json')
    digest = bench_context_digest(text)
    if evidence.exists():
        if read_json(evidence).get('bench_context_sha256') != digest:
            raise ValueError('Bench electrical context changed since baseline; create a new session')
    else:
        # The CLI and solver are serial; exclusive creation also refuses races.
        with evidence.open('x') as stream:
            json.dump({'bench_context_sha256': digest}, stream)
            stream.write('\n')


def bind_dut(bench_text, dut_text, source_subckt, target_subckt):
    bench, dut = parse_deck(bench_text), parse_deck(dut_text)
    if source_subckt not in bench['definitions'] or target_subckt not in dut['definitions']:
        raise ValueError('physical OA netlist does not contain requested DUT subckt')
    if bench['definitions'][source_subckt]['ports'] != dut['definitions'][target_subckt]['ports']:
        raise ValueError('DUT port names/order changed')
    # Walk actual Bench hierarchy, requiring exactly one occurrence of the DUT.
    occurrences = []
    def visit(instances, path, stack):
        for inst in instances:
            full = '.'.join(path + [inst['name']])
            if inst['master'] == source_subckt:
                occurrences.append((inst, full))
            elif inst['master'] in bench['definitions']:
                if inst['master'] in stack:
                    raise ValueError('recursive Bench hierarchy')
                visit(bench['definitions'][inst['master']]['instances'], path + [inst['name']], stack + [inst['master']])
    visit(bench['top'], [], [])
    if len(occurrences) != 1:
        raise ValueError('Bench DUT occurrence must be unique')
    instance, full_path = occurrences[0]
    rewritten = list(bench['lines'])
    rewritten[instance['line']] = (instance['name'] + ' (' + ' '.join(instance['nodes']) + ') ' +
                                   target_subckt + instance['tail'])
    additions = []
    replacements = {}
    for name, definition in dut['definitions'].items():
        body = dut['lines'][definition['start']:definition['end'] + 1]
        old = bench['definitions'].get(name)
        if old:
            old_body = bench['lines'][old['start']:old['end'] + 1]
            if name == source_subckt and name == target_subckt:
                replacements[old['start']] = (old['end'], body)
            elif body != old_body:
                raise ValueError('conflicting shared subckt: ' + name)
        else:
            additions.extend(body)
    out, index = [], 0
    while index < len(rewritten):
        if index in replacements:
            end, body = replacements[index]
            out.extend(body)
            index = end + 1
        else:
            out.append(rewritten[index])
            index += 1
    # Keep the language declaration ahead of every new Spectre definition.
    positions = [i for i, line in enumerate(out) if line.strip() == 'simulator lang=spectre']
    if len(positions) != 1:
        raise ValueError('unique explicit Spectre language declaration required')
    insert = positions[0] + 1
    out[insert:insert] = additions
    return '\n'.join(out) + '\n', full_path


def flatten_dut(text, root_path, root_master, logical_deck=None, logical_master=None, port_bindings=None):
    deck = parse_deck(text)
    # Resolve the actual instance path, including any surrounding Bench wrapper.
    nodes, parameters, scope, instances = {}, dict(deck['parameters']), '', deck['top']
    root = None
    for part in root_path.split('.'):
        matched = [i for i in instances if i['name'] == part]
        if len(matched) != 1:
            raise ValueError('missing exact DUT hierarchy: ' + root_path)
        root = matched[0]
        resolved_nodes = [nodes.get(n, n if n in deck['globals'] or not scope else scope + '.' + n)
                          for n in root['nodes']]
        if root['master'] not in deck['definitions']:
            raise ValueError('DUT path enters primitive')
        definition = deck['definitions'][root['master']]
        if len(definition['ports']) != len(resolved_nodes):
            raise ValueError('hierarchy port count mismatch')
        nodes = dict(zip(definition['ports'], resolved_nodes))
        parent_parameters = parameters
        parameters = dict(parent_parameters)
        parameters.update(definition['parameters'])
        for key, value in root['params'].items():
            parameters[key] = parameter_value(value, parent_parameters)
        scope = scope + '.' + part if scope else part
        instances = definition['instances']
    if root is None or root['master'] != root_master:
        raise ValueError('DUT hierarchy master mismatch')
    if port_bindings is not None:port_bindings.update(nodes)
    if logical_deck is not None:
        # Resolve the Bench first, then substitute the checked OA readback.
        # Match formal names, not their enumeration order, retaining native nets.
        from cascode_runtime import expand_oa_ports, port_key
        logical = parse_deck(logical_deck)
        definition = logical['definitions'].get(logical_master)
        if definition is None:
            raise ValueError('readback root subckt missing')
        actual = {port_key(k):v for k,v in nodes.items()}
        formals = expand_oa_ports(definition['ports'])
        if len(actual) != len(nodes) or set(actual) != {port_key(p) for p in formals}:
            raise ValueError('readback root ports differ from native DUT')
        nodes = {p:actual[port_key(p)] for p in formals}
        parameters.update(definition['parameters'])
        instances = definition['instances']
        logical['globals'].update(deck['globals'])
        deck, root_master = logical, logical_master
    result = []
    def walk(instances, bindings, params, prefix, stack):
        for inst in instances:
            full = prefix + '.' + inst['name']
            terminals = [bindings.get(n, n if n in deck['globals'] else prefix + '.' + n) for n in inst['nodes']]
            if inst['master'] in deck['definitions']:
                if inst['master'] in stack:
                    raise ValueError('recursive DUT hierarchy')
                definition = deck['definitions'][inst['master']]
                if len(terminals) != len(definition['ports']):
                    raise ValueError('DUT child port count mismatch')
                local_params = dict(params)
                local_params.update(definition['parameters'])
                # Evaluate overrides in parent scope before introducing child defaults.
                for key, value in inst['params'].items():
                    local_params[key] = parameter_value(value, params)
                walk(definition['instances'], dict(zip(definition['ports'], terminals)), local_params,
                     full, stack + [inst['master']])
            else:
                result.append(dict(inst, path=full, nodes=terminals, parameters=params))
    walk(instances, nodes, parameters, scope, [root_master])
    return result


def parameter_value(expression, parameters, stack=()):
    if isinstance(expression, (int, float)):
        return finite(expression)
    expression = str(expression).strip('"')
    units = {'T': 1e12, 'G': 1e9, 'M': 1e6, 'K': 1e3, 'k': 1e3,
             'm': 1e-3, 'u': 1e-6, 'n': 1e-9, 'p': 1e-12, 'f': 1e-15}
    expression = re.sub(r'(?<![\w.])((?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)([TGMKkmunpf])\b',
                        lambda m: '(' + m[1] + '*' + str(units[m[2]]) + ')', expression)
    tree = ast.parse(expression, mode='eval')
    def evaluate(node):
        if isinstance(node, ast.Constant):
            return finite(node.value)
        if isinstance(node, ast.Name):
            if node.id not in parameters or node.id in stack:
                raise ValueError('missing/recursive parameter: ' + node.id)
            return parameter_value(parameters[node.id], parameters, stack + (node.id,))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return evaluate(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            left, right = evaluate(node.left), evaluate(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            return left / right
        raise ValueError('unsupported Spectre parameter expression: ' + expression)
    return finite(evaluate(tree.body))


def request_dc(text):
    deck = parse_deck(text)
    inside = False
    out = []
    for line in deck['lines']:
        parts = line.strip().split()
        if parts and parts[0] == 'subckt': inside = True
        if parts and parts[0] == 'ends': inside = False
        if not inside and len(parts) >= 2:
            if parts[1] in ('tran', 'ac', 'dc', 'noise', 'stb', 'pz', 'xf', 'sp', 'info'):
                continue
            if parts[1] in ('montecarlo', 'sweep') or '{' in line or '}' in line:
                raise ValueError('swept/nested Bench requires a selected single test netlist')
            if parts[1] == 'options' and parts[0] == 'saveOptions':
                continue
        out.append(line)
    out.extend(['dcOp dc annotate=status oppoint=rawfile', 'dcOpInfo info what=oppoint where=rawfile',
                'saveOptions options save=all currents=all subcktprobelvl=99'])
    return '\n'.join(out) + '\n'


def raw_value(raw, name):
    if name == '0': return 0.0
    if name not in raw:
        raise ValueError('missing exact raw PSF signal: ' + name)
    return finite(raw[name])


def total_supply_measurement(raw, supply):
    """Absent measurement is NA; configured signed bindings remain mandatory."""
    if any(item.get('sign') not in (-1, 1) or not item.get('signal') for item in supply):
        raise ValueError('total supply current bindings require explicit signal and sign')
    if not supply:
        return 'NA'
    return finite(sum(raw_value(raw, item['signal']) * item['sign'] for item in supply))


def mos_row(device, raw, catalog, signals):
    roles = catalog['terminal_roles']
    if len(roles) != len(device['nodes']):
        raise ValueError('actual MOS/catalog terminal count conflict')
    values = {role: raw_value(raw, net) for role, net in zip(roles, device['nodes'])}
    name = device.get('output_name', device['path'])
    def signal(key):
        if not signals.get(key):
            raise ValueError('missing PDK DC signal mapping: ' + key)
        return raw_value(raw, device.get('signal_path', device['path']) + ':' + signals[key])
    vd, vg, vs = [values[k] for k in ('drain', 'gate', 'source')]
    vb = values['bulk'] if 'bulk' in values else vs + signal('vbs')
    row = [name, vd, vg, vs, vb, signal('id'), vg - vs, vd - vs, vb - vs,
           signal('vth'), signal('vdsat'), signal('cgg')]
    if signals.get('intrinsic_vgs') or signals.get('intrinsic_vds'):
        row += [signal('intrinsic_vgs'), signal('intrinsic_vds')]
    return row


def resistor_rating(rules, geometry, corner, temperature, experimental_dc=False):
    matched = []
    for rule in rules:
        if rule.get('corner') != corner:
            continue
        if not rule['temperature_min'] <= temperature <= rule['temperature_max']:
            continue
        limits = rule.get('geometry', {})
        if not limits or not all(key in geometry and domain['min'] <= geometry[key] <= domain['max']
                                 for key, domain in limits.items()):
            continue
        if not rule.get('source'):
            raise ValueError('resistor rating source missing')
        if experimental_dc:
            # Missing limits are unverified; supplied invalid limits are errors.
            # Preserve partial proven limits so C++ still checks each one.
            trial_rating = dict(rule)
            for key in ('max_voltage', 'max_power', 'max_current'):
                if key in rule:
                    value = finite(rule[key])
                    if key != 'max_voltage' and value == 0:
                        # Legacy rules use zero for the unused power/current
                        # alternative. Preserve that as unknown, never as a pass.
                        trial_rating.pop(key)
                    elif value <= 0:
                        raise ValueError('resistor rating must be positive: ' + key)
            matched.append(trial_rating)
            continue
        finite(rule.get('max_voltage'), True)
        power, current = finite(rule.get('max_power', 0)), finite(rule.get('max_current', 0))
        if power < 0 or current < 0 or power + current <= 0:
            raise ValueError('resistor rating requires current or power')
        matched.append(rule)
    if not matched and experimental_dc:
        return {}
    if len(matched) != 1:
        raise ValueError('resistor geometry/Corner/temperature rating missing or ambiguous')
    return matched[0]


def apply_corner(text, corner, temperature, original_models, variables):
    deck = parse_deck(text)
    selected = [(str(Path(s['model_file']).resolve()), s['section_name']) for s in corner['sections']]
    if len(set(selected)) != len(selected):
        raise ValueError('duplicate selected model file/section')
    originals = {str(Path(p).resolve()) for p in original_models}
    if not selected or not originals:
        raise ValueError('explicit original/selected Corner model context required')
    out, removed, parameter_names = [], set(), set()
    include = re.compile(r'^\s*include\s+"([^"]+)"(?:\s+section=(\S+))?\s*$')
    inside = False
    for line in deck['lines']:
        parts = line.strip().split()
        if parts and parts[0] == 'subckt': inside = True
        if parts and parts[0] == 'ends': inside = False
        match = include.match(line)
        if match:
            file = Path(match[1])
            if not file.is_absolute():
                raise ValueError('relative include needs an explicit original working directory')
            path = str(file.resolve())
            if path in originals:
                removed.add(path)
                continue
        if not inside and parts and parts[0] == 'parameters':
            values = dict(ASSIGN.findall(line))
            for key in values:
                parameter_names.add(key)
                if key in variables:
                    values[key] = str(variables[key])
            line = 'parameters ' + ' '.join(k + '=' + v for k, v in values.items())
        if not inside and len(parts) >= 2 and parts[1] == 'options':
            line = re.sub(r'\btemp\s*=\s*\S+', 'temp=' + str(temperature), line)
        out.append(line)
    if removed != originals or not set(variables).issubset(parameter_names):
        raise ValueError('Bench model or variable binding is incomplete')
    additions = []
    for path, section in selected:
        if not Path(path).is_file():
            raise ValueError('Corner model does not exist: ' + path)
        additions.append('include ' + json.dumps(path) + ' section=' + section)
    language = [i for i, line in enumerate(out) if line.strip() == 'simulator lang=spectre']
    if len(language) != 1:
        raise ValueError('unique Spectre declaration required for Corner binding')
    out[language[0] + 1:language[0] + 1] = additions
    out.append('stTemperature options temp=' + str(finite(temperature)))
    return '\n'.join(out) + '\n'


def command(runtime, args, directory, label):
    log = directory / (label + '.log')
    with log.open('w') as stream:
        result = subprocess.run([runtime] + args, stdout=stream, stderr=subprocess.STDOUT,
                                cwd=directory, check=False)
    if result.returncode:
        raise RuntimeFailure('Cadence ' + label + ' failed (' + str(result.returncode) + '), log=' + str(log),
                             result.returncode)


def read_raw(path):
    with Path(path).open(newline='') as stream:
        rows = csv.reader(stream, delimiter='\t')
        if next(rows) != ['signal', 'value']:
            raise ValueError('invalid signed raw PSF TSV header')
        values = {}
        for row in rows:
            if len(row) != 2 or not row[0] or row[0] in values:
                raise ValueError('duplicate/invalid raw PSF signal')
            values[row[0]] = finite(float(row[1]))
    return values


def write_tsv(path, header, rows):
    with Path(path).open('x', newline='') as stream:
        writer = csv.writer(stream, delimiter='\t', lineterminator='\n')
        writer.writerow(header)
        for row in rows:
            if any(isinstance(v, str) and any(c in v for c in '\t\r\n') for v in row):
                raise ValueError('invalid TSV field')
            writer.writerow([format(v, '.17g') if isinstance(v, float) else v for v in row])


def load_scanned_catalog(path, tech, version, validation_scope='dc_operating_point'):
    if not path:
        raise ValueError('current scanned device catalog is required')
    with Path(path).open(newline='') as stream:
        catalog_rows = list(csv.DictReader(stream, delimiter='\t'))
    trials = (tech.get('native_parameter_trials') or tech.get('validation_scope') == 'experimental_dc' or
              any(d.get('native_parameter_trials') for d in tech['devices']) or
              any(r.get('native_parameter_trials') == 'true' for r in catalog_rows))
    if trials and validation_scope != 'experimental_dc':
        raise ValueError('native parameter trial metadata requires experimental_dc')
    devices_by_model = {}
    for row in catalog_rows:
        if row['pdk_version'] != version:
            raise ValueError('scanned catalog/request PDK version conflict')
        model = row['model_name']
        rule_devices = [d for d in tech['devices'] if d['cell'] == row['oa_cell'] and
                        (not d.get('oa_library') or d['oa_library'] == row['oa_library'])]
        if len(rule_devices) != 1 or row['kind'] != rule_devices[0]['kind']:
            raise ValueError('catalog/tech cell or polarity identity conflict')
        if row['model_name'] != rule_devices[0].get('model', row['model_name']):
            raise ValueError('catalog/tech model identity conflict')
        if row.get('native_parameter_trials', 'false') not in ('true', 'false'):
            raise ValueError('invalid native_parameter_trials boolean')
        if (row.get('native_parameter_trials', 'false') == 'true') != bool(rule_devices[0].get('native_parameter_trials', False)):
            raise ValueError('catalog/tech native parameter trial identity conflict')
        devices_by_model.setdefault(model, []).append((dict(row,
            terminal_names=row['terminal_names'].split(','),
            terminal_roles=row['terminal_roles'].split(',')), rule_devices[0]))
    if not devices_by_model:
        raise ValueError('empty current PDK catalog')
    return devices_by_model


def read_oa_bindings(path):
    bindings = {}
    with Path(path).open(newline='') as stream:
        for row in csv.DictReader(stream, delimiter='\t'):
            name = row['instance']
            if not name or name in bindings:
                raise ValueError('duplicate/empty physical OA instance binding')
            bindings[name] = dict(row, terminal_names=row['terminal_names'].split(','))
    return bindings


def physical_instance_key(name):
    """Comparison key only; never use it as a netlist or PSF signal name."""
    return re.sub(r'(?<!\\)\\([<>])', r'\1', name)


def expand_physical_bindings(bindings):
    """Expand explicit OA arrays across the full path, retaining raw provenance."""
    expanded = {}
    for original, proof in bindings.items():
        paths = ['']
        for part in physical_instance_key(original).split('.'):
            match = re.fullmatch(r'([^<>]+)<(-?\d+):(-?\d+)>', part)
            if match:
                first, last = int(match[2]), int(match[3])
                if len(paths) * (abs(last-first)+1) > 4096:
                    raise ValueError('physical OA array expansion limit exceeded: ' + original)
                step = 1 if last >= first else -1
                bits = [match[1]+'<'+str(n)+'>' for n in range(first,last+step,step)]
            else:
                bits = [part]
            paths = [prefix+'.'+bit if prefix else bit for prefix in paths for bit in bits]
        for key in paths:
            if key in expanded:
                raise ValueError('ambiguous physical OA expanded instance: ' + key)
            expanded[key] = dict(proof, oa_instance_name=original)
    return expanded


def resolve_device(device, catalogs, bindings):
    proof = bindings.get(device['output_name'])
    if not proof:
        raise ValueError('physical OA master binding missing: ' + device['output_name'])
    if proof.get('model_name') and proof['model_name'] != device['master']:
        raise ValueError('physical OA master model conflict: ' + device['output_name'])
    matches = [(row, dev) for row, dev in catalogs[device['master']]
               if row['oa_library'] == proof['oa_library'] and row['oa_cell'] == proof['oa_cell']]
    if len(matches) != 1:
        raise ValueError('physical OA master/catalog binding ambiguous or missing')
    row, dev = matches[0]
    if (row['terminal_names'] != proof['terminal_names'] or
            len(row['terminal_names']) != len(device['nodes']) or
            len(row['terminal_roles']) != len(device['nodes'])):
        raise ValueError('physical OA/CDF Spectre terminal order conflict')
    return row, dev


def physical_signature(device):
    values = {}
    for name, value in device['params'].items():
        try:
            values[name] = parameter_value(value, device['parameters'])
        except (ValueError, SyntaxError, ZeroDivisionError):
            # Preserve unresolved expressions and their entire environment.
            values[name] = (value, device['parameters'])
    return (device['master'], device['nodes'], values)


def generated_resistor_parent(name):
    """Find a possible group, preserving the full native instance spelling.

    Netlisters use both _res_gen and __res_gen after the segment index. This
    does not prove OA identity or permit changing either spelling in a deck.
    """
    match = re.fullmatch(r'(.+)_(\d+)_{1,2}res_gen', name)
    return match[1] if match else None


def private_resistor_nodes(original, names, root):
    """Repeated public endpoints are not private segment junctions."""
    nodes = {n for name in names for n in original[name]['nodes']}
    outside = {n for name,d in original.items() if name not in names for n in d['nodes']}
    return {n for n in nodes if n.startswith(root+'.') and n not in outside
            and sum(n in original[k]['nodes'] for k in names) > 1}


def load_resistor_readback(evaluation_dir, native_text, root, native_master, logical_master):
    """Use the same candidate's checked actual OA readback, never CDF defaults."""
    folder = Path(evaluation_dir)
    paths = [folder/'validation.txt', folder/'expected/core_expected.scs', folder/'roundtrip/complete.scs']
    contents = [p.read_bytes() for p in paths]
    evidence = {str(p.resolve()):hashlib.sha256(raw).hexdigest() for p,raw in zip(paths,contents)}
    status = dict(line.split('=',1) for line in contents[0].decode().splitlines() if '=' in line)
    if (status.get('ok') != 'true' or not status.get('expected_topology_hash') or
            status['expected_topology_hash'] != status.get('actual_topology_hash')):
        raise ValueError('candidate OA readback has not passed roundtrip validation')
    def flatten(raw):
        leaves = flatten_dut(native_text,root,native_master,raw.decode(),logical_master)
        result = {physical_instance_key(d['path'][len(root)+1:]):d for d in leaves}
        if len(result) != len(leaves):raise ValueError('ambiguous readback instance path')
        return result
    expected, actual = flatten(contents[1]), flatten(contents[2])
    # The C++ validator already checks the whole variant. Independently check
    # each consumed parent's expected identity/connections/explicit parameters.
    verified = {}
    for name, before in expected.items():
        after = actual.get(name)
        if after is None:continue
        a,b = physical_signature(before),physical_signature(after)
        if a[:2] == b[:2] and all(k in b[2] and b[2][k] == v for k,v in a[2].items()):
            verified[name] = after
    expanded = {generated_resistor_parent(physical_instance_key(d['path'][len(root)+1:]))
                for d in flatten_dut(native_text,root,native_master)} - {None}
    for name in expanded.intersection(expected)-set(verified):
        raise ValueError('candidate resistor readback differs from expected: '+name)
    return verified,evidence


def aggregate_resistor_groups(leaves, root, catalogs, bindings, logical_devices, kept):
    """Prove native two-terminal expansions against an actual OA parent.

    Segments remain native simulation objects, not invented OA instances.
    Parallel and series/parallel graphs use the same boundary proof.
    """
    indexed = {physical_instance_key(d['path'][len(root)+1:]):d for d in leaves}
    groups = {}
    for name in indexed:
        parent = generated_resistor_parent(name)
        if parent and name not in kept:groups.setdefault(parent,set()).add(name)
    aggregates, members = {}, {}
    for parent,children in sorted(groups.items()):
        logical = (logical_devices or {}).get(parent)
        if logical is None:continue  # regular binder supplies a precise failure
        proof = bindings.get(parent,{})
        names = children | {parent}
        if proof.get('classification') != 'target' or parent not in indexed:
            raise ValueError('expanded resistor parent OA binding missing: '+parent)
        # OA readback uses the catalog's logical master key; Spectre uses the
        # native model. Tie both to the same actual library/cell proof.
        parent_device = dict(logical, output_name=parent,master=indexed[parent]['master'])
        catalog,dev = resolve_device(parent_device,catalogs,{parent:proof})
        if logical['master'] != catalog.get('master'):
            raise ValueError('expanded resistor readback OA master conflict: '+parent)
        if catalog['kind'] != 'resistor' or catalog['terminal_roles'] != ['positive','negative']:
            raise ValueError('expanded resistor requires verified two-terminal parent: '+parent)
        endpoints = set(parent_device['nodes'])
        if len(endpoints) != 2:raise ValueError('expanded resistor endpoints shorted: '+parent)
        indices = [1]+[int(re.fullmatch(r'.+_(\d+)_{1,2}res_gen',n)[1]) for n in children]
        if sorted(indices) != list(range(1,len(names)+1)):
            raise ValueError('expanded resistor segment indices missing/duplicated: '+parent)
        if 'segments' in logical['params']:
            count = parameter_value(logical['params']['segments'],logical['parameters'])
            if count != len(names):raise ValueError('expanded resistor count differs from OA readback: '+parent)
        segments = [indexed[n] for n in sorted(names)]
        graph = {}
        for n in names:
            device = indexed[n]
            if (device['master'] != parent_device['master'] or len(device['nodes']) != 2 or
                    len(set(device['nodes'])) != 2 or (n != parent and n in bindings)):
                raise ValueError('expanded resistor segment identity/connectivity conflict: '+n)
            a,b = device['nodes'];graph.setdefault(a,[]).append(b);graph.setdefault(b,[]).append(a)
        if not endpoints <= set(graph):raise ValueError('expanded resistor OA endpoint missing: '+parent)
        visited,pending = set(),[parent_device['nodes'][0]]
        while pending:
            node=pending.pop()
            if node in visited:continue
            visited.add(node);pending.extend(graph[node])
        private = set(graph)-endpoints
        if visited != set(graph) or any(len(graph[n])<2 for n in private):
            raise ValueError('expanded resistor disconnected or dangling segment: '+parent)
        if any(not n.startswith(root+'.') for n in private) or any(
                private.intersection(d['nodes']) for n,d in indexed.items() if n not in names):
            raise ValueError('expanded resistor private node has external contact: '+parent)
        parent_device.update(path=indexed[parent]['path'],oa_instance_name=proof['oa_instance_name'],
            segments=segments,private_nodes=sorted(private),binding_kind='native_resistor_network')
        aggregates[parent]=(parent_device,catalog,dev)
        for n in names:members[n]=parent
    return aggregates,members


def preserved_resistor_groups(leaves, baseline, root, catalogs, bindings):
    """Keep unchanged native expansions; do not invent individual OA masters."""
    def indexed(items):
        result = {}
        for device in items:
            name = physical_instance_key(device['path'][len(root)+1:])
            if name in result:
                raise ValueError('duplicate physical comparison path: ' + name)
            result[name] = device
        return result
    actual, original = indexed(leaves), indexed(baseline)
    groups = {}
    for name in original:
        parent = generated_resistor_parent(name)
        if parent is not None:
            groups.setdefault(parent, set()).add(name)
        elif name in bindings and any(row.get('kind') == 'resistor'
                                      for row, _ in catalogs.get(original[name]['master'], [])):
            groups.setdefault(name, set())
    kept, reports = set(), []
    for parent, children in sorted(groups.items()):
        names = children | {parent}
        proof = bindings.get(parent)
        if not proof or proof.get('classification') != 'target' or parent not in original:
            continue
        candidates = catalogs.get(original[parent]['master'], [])
        own = [row for row, _ in candidates if row['oa_library'] == proof['oa_library']
               and row['oa_cell'] == proof['oa_cell'] and row.get('kind') == 'resistor']
        if (len(own) != 1 or own[0]['terminal_names'] != proof['terminal_names'] or
                any(name not in actual for name in names)):
            continue
        present = {name for name in actual if name == parent or
                   generated_resistor_parent(name) == parent}
        if present != names or any(physical_signature(actual[n]) != physical_signature(original[n]) for n in names):
            continue
        # Changed use of an internal segment node also changes the group.
        nodes = private_resistor_nodes(original,names,root)
        def contacts(items):
            return {name: [(i, node) for i, node in enumerate(device['nodes']) if node in nodes]
                    for name, device in items.items() if name not in names and nodes.intersection(device['nodes'])}
        if contacts(actual) != contacts(original):
            continue
        if any(original[n]['master'] != proof.get('model_name') for n in names):
            continue
        kept.update(names)
        reports.append(dict(instance=parent, segments=sorted(names), measurements_extracted=False))
    return kept, reports


def verify_reference_resistor_geometry(device, logical):
    """The selected rhrpo model uses lr/wr/mr, not the OA r property.

    Check the explicit series recipe before spending a Spectre run. This
    adapter is limited to the native model whose geometry was observed.
    """
    if device['master'] != 'rhrpo_2t_ckt':
        return
    if logical is None:
        raise ValueError('reference resistor geometry readback missing: '+device['output_name'])
    params = {k.lower():parameter_value(v,logical['parameters']) for k,v in logical['params'].items()
              if k.lower() in ('segments','cktl','cktw','segl','segw','m')}
    required = ('segments','cktl','cktw','segl','segw','m')
    if any(k not in params or params[k]<=0 for k in required):
        raise ValueError('reference resistor series geometry incomplete: '+device['output_name'])
    count = params['segments']
    segments = device.get('segments',[device])
    close = lambda a,b: math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-18)
    if count != round(count) or count != len(segments):
        raise ValueError('reference resistor native segment count differs: '+device['output_name']+
                         ' expected='+str(count)+' actual='+str(len(segments)))
    if not close(params['cktl'],count*params['segl']) or not close(params['cktw'],params['segw']):
        raise ValueError('reference resistor readback is not the requested series geometry')
    degree = {}
    for segment in segments:
        for key,expected in (('lr',params['segl']),('wr',params['segw']),('mr',params['m'])):
            raw = segment['params'].get(key)
            actual = parameter_value(raw,segment['parameters']) if raw is not None else None
            if actual is None or not close(actual,expected):
                raise ValueError('reference resistor native geometry differs: '+segment['path']+
                                 ' '+key+' expected='+str(expected)+' actual='+str(actual))
        for node in segment['nodes']:degree[node]=degree.get(node,0)+1
    endpoints = set(logical['nodes'])
    if len(endpoints)!=2 or set(degree)!=endpoints|set(device.get('private_nodes',[])) or any(
            value != (1 if node in endpoints else 2) for node,value in degree.items()):
        raise ValueError('reference resistor native expansion is not the requested series chain')
    device['verified_series_geometry'] = dict(segments=int(count),lr=params['segl'],wr=params['segw'],mr=params['m'])


def bind_physical_devices(text, root, root_master, catalogs, bindings,
                          baseline_text=None, baseline_master=None, preserved_report=None,
                          logical_devices=None, focus=None):
    bindings = expand_physical_bindings(bindings)
    leaves = flatten_dut(text, root, root_master)
    kept = set()
    if focus is not None:
        bindings = {k:v for k,v in bindings.items() if k in focus}
        kept = {physical_instance_key(d['path'][len(root)+1:]) for d in leaves} - focus
    elif baseline_text is not None:
        kept, reports = preserved_resistor_groups(leaves,
            flatten_dut(baseline_text, root, baseline_master), root, catalogs, bindings)
        if preserved_report is not None:
            preserved_report.extend(reports)
    aggregates,members = aggregate_resistor_groups(leaves,root,catalogs,bindings,logical_devices,kept)
    result, consumed, seen = [], set(), set()
    for device in leaves:
        device['output_name'] = device['path'][len(root) + 1:]
        key = physical_instance_key(device['output_name'])
        if key in seen:
            raise ValueError('duplicate exported physical instance: ' + key)
        seen.add(key)
        if key in kept:
            if key in bindings:
                consumed.add(key)
            continue
        if key in members:
            parent = members[key]
            if key == parent:
                consumed.add(parent);result.append(aggregates[parent])
            continue
        proof = bindings.get(key, {})
        if proof.get('classification') == 'unproven':
            raise ValueError('unproven physical PDK master: ' + proof['oa_library'] + '/' + proof['oa_cell'])
        if proof.get('classification') == 'non_target':
            if proof.get('model_name') != device['master']:
                raise ValueError('physical non-target PDK model conflict: ' + device['output_name'])
            if len(proof['terminal_names']) != len(device['nodes']):
                raise ValueError('physical non-target PDK terminal count conflict')
            consumed.add(key)
            continue
        if device['master'] not in catalogs:
            if key in bindings:
                raise ValueError('physical PDK instance has an unbound netlist model: ' + device['output_name'])
            # Uncatalogued non-PDK primitives (sources, caps, probes) are retained.
            continue
        catalog, dev = resolve_device(device, catalogs, {device['output_name']: proof})
        consumed.add(key)
        device['oa_instance_name'] = proof['oa_instance_name']
        result.append((device, catalog, dev))
    if set(bindings) != consumed:
        raise ValueError('physical PDK bindings not exported by netlist: ' + ','.join(sorted(set(bindings) - consumed)))
    for device,catalog,_ in result:
        if logical_devices is not None and catalog['kind']=='resistor' and device['master']=='rhrpo_2t_ckt':
            verify_reference_resistor_geometry(device,(logical_devices or {}).get(physical_instance_key(device['output_name'])))
    return result


def bind_candidate_devices(text, root, master, catalogs, bindings, baseline_text,
                           baseline_master, evaluation_dir, preserved_report, evidence, focus=None):
    """Shared production/replay path; only new expansions need OA readback."""
    leaves=flatten_dut(text,root,master)
    expanded=expand_physical_bindings(bindings)
    if focus is None:
        kept,_=preserved_resistor_groups(leaves,flatten_dut(baseline_text,root,baseline_master),
                                        root,catalogs,expanded)
    else:
        kept={physical_instance_key(d['path'][len(root)+1:]) for d in leaves}-focus
    needs_readback=any(generated_resistor_parent(physical_instance_key(d['path'][len(root)+1:]))
        and physical_instance_key(d['path'][len(root)+1:]) not in kept for d in leaves)
    needs_readback = needs_readback or any(d['master']=='rhrpo_2t_ckt' and
        physical_instance_key(d['path'][len(root)+1:]) not in kept for d in leaves)
    logical=None
    if needs_readback:
        logical,pins=load_resistor_readback(evaluation_dir,text,root,master,baseline_master)
        evidence.update(pins)
    return bind_physical_devices(text,root,master,catalogs,bindings,baseline_text=baseline_text,
        baseline_master=baseline_master,preserved_report=preserved_report,logical_devices=logical,focus=focus)


def candidate_focus(text, root, master, baseline_text, baseline_master, targets, target_paths=None):
    """One native netlist comparison; unchanged peripherals still simulate."""
    ports={}
    def indexed(leaves):
        rows={physical_instance_key(d['path'][len(root)+1:]):d for d in leaves}
        if len(rows)!=len(leaves):raise ValueError('duplicate physical instance path')
        return rows
    actual=indexed(flatten_dut(text,root,master,port_bindings=ports))
    before=indexed(flatten_dut(baseline_text,root,baseline_master))
    targets={physical_instance_key(n) for n in targets}
    selected={};wrappers=set()
    for name in sorted(targets):
        if name in actual:
            selected[name]=name
            continue
        # PackageSingleCandidateVariant keeps the original member name inside
        # a wrapper named for the target: I21 becomes I21.I21. This is an
        # exact hierarchy relationship, not a suffix/name-similarity match.
        member=name+'.'+name.rsplit('.',1)[-1]
        if name not in before or member not in actual:
            raise ValueError('confirmed target missing from candidate: '+name+' (also checked '+member+')')
        if actual[member]['master']!=before[name]['master']:
            raise ValueError('packaged original target model changed: '+member)
        selected[name]=member;wrappers.add(name)
    removed=set(before)-set(actual)
    for name in list(removed):
        moved=[w+'.'+name for w in wrappers if w+'.'+name in actual
               and actual[w+'.'+name]['master']==before[name]['master']]
        if len(moved)==1:removed.remove(name)
    if removed:raise ValueError('baseline device missing from candidate: '+','.join(sorted(removed)[:8]))
    if target_paths is not None:target_paths.update(selected)
    focus=set(selected.values()) | {n for n,d in actual.items() if n not in before or physical_signature(d)!=physical_signature(before[n])}
    # If a resistor changed, measure its full native expansion, never one segment.
    parents={generated_resistor_parent(n) or n for n in focus}
    focus.update(n for n in actual if generated_resistor_parent(n) in parents)
    focus.update(n for n in parents if n in actual)
    functional={p:n for p,n in ports.items() if p in ('VOUT','VFB','VREF','AVDD','AGND','PVDD','EN')}
    return focus,len(actual)-len(focus),functional


def confirmed_targets(evaluation_dir, receipt):
    if receipt and receipt.get('mos_rows'):return [row[0] for row in receipt['mos_rows']]
    # The existing evaluator places every trial under work/analysis/candidates.
    from run_cascode_experiment import pairs
    for directory in (Path(evaluation_dir),*Path(evaluation_dir).parents):
        if (directory/'session.conf').is_file() and (directory/'changes').is_dir():
            return [row['instance'] for p in sorted((directory/'changes').glob('*.conf'))
                    for row in [pairs(p)] if row.get('instance')]
    raise ValueError('confirmed experimental target unavailable')


def prepare_bundle_candidate(args, extension, original, bench, cds_lib, runtime, directory):
    from baseline_bundle import load_bundle, prepare_candidate_deck
    from standalone import validate_bundle_profile
    path=extension['validated_baseline_bundle']
    bundle=load_bundle(path,original,bench,args.corner)
    validate_bundle_profile(bundle,extension)
    source=bundle['source_subckt']
    (directory/'bench.scs').write_text(Path(bundle['bench_netlist']).read_text())
    work=directory/'dut_oa';work.mkdir()
    command(runtime,['netlist','--lib',args.dut_lib,'--cell',args.dut_cell,'--view',args.dut_view,
        '--cds-path',str(cds_lib.parent),'--work-dir',str(work),'--mode','fast',
        '--output',str(directory/'dut.scs'),'--ports-from',str(directory/'bench.scs'),
        '--source-subckt',source,'--baseline-bundle',str(path)],directory,'export_dut')
    origin=read_json(directory/'dut.scs.origin.json')
    text,root=prepare_candidate_deck(bundle,(directory/'dut.scs').read_text(),origin['working_directory'],args.dut_cell)
    return bundle,text,root


def require_supported_voltage_semantics(physical_devices, evidence=None):
    """Require an explicit per-device CMG contract, never infer signs or ratings."""
    for device,catalog,dev in physical_devices:
        if catalog['kind'] not in ('mos_n','mos_p'):continue
        mapping=dict(dev['dc_signals']);mapping.update(dev['electrical_rules'].get('dc_signals',{}))
        signal=canonical_device(device['path']+dev.get('signal_postfix',''))
        sources=None if evidence is None else evidence.get('sources',{})
        own=[] if sources is None else [v for k,v in sources.items() if k.startswith(signal+':')]
        native_cmg=any(v.get('device_type','').lower().startswith('bsimcmg') for v in own)
        internal=any(mapping.get(k) for k in ('intrinsic_vgs','intrinsic_vds'))
        cmg=internal or mapping.get('vdsat')=='vdssat' or native_cmg
        if not cmg:continue
        expected={'intrinsic_vgs':'vgs','intrinsic_vds':'vds','vdsat':'vdssat'}
        if any(mapping.get(k)!=v for k,v in expected.items()):
            raise ValueError('intrinsic CMG mapping requires vgs/vds/vdssat: '+signal)
        if 'bulk' not in catalog.get('terminal_roles',[]) and mapping.get('vbs')!='vest':
            raise ValueError('CMG bulk terminal voltage requires explicit vest mapping: '+signal)
        if sources is not None:
            for parameter in expected.values():
                source=sources.get(signal+':'+parameter,{})
                if (source.get('kind')!='op' or source.get('parameter')!=parameter or
                    not source.get('device_type','').lower().startswith('bsimcmg')):
                    raise ValueError('intrinsic CMG native source missing/conflicting: '+signal+':'+parameter)


def write_mos_tsv(path, rows):
    header=['instance','vd','vg','vs','vb','id','vgs','vds','vbs','vth','vdsat','cgg']
    if any(len(row)==14 for row in rows):
        header += ['intrinsic_vgs','intrinsic_vds']
        rows=[row+['NA','NA'] if len(row)==12 else row for row in rows]
    if any(len(row)!=len(header) for row in rows):raise ValueError('invalid MOS voltage columns')
    write_tsv(path,header,rows)


def build_dc_query(physical_devices, supply):
    from dc_results import validate_query
    nodes=set();parameters={};currents=set()
    if any(item.get('sign') not in (-1,1) or not item.get('signal') for item in supply):
        raise ValueError('circuit requires explicitly signed total supply current signal bindings')
    currents.update(item['signal'] for item in supply)
    for device,catalog,dev in physical_devices:
        nodes.update(device['nodes'])
        signal=device['path']+dev['signal_postfix']
        mapping=dict(dev['dc_signals']);mapping.update(dev['electrical_rules'].get('dc_signals',{}))
        if catalog['kind'] in ('mos_n','mos_p'):
            required=['id','vth','vdsat','cgg']
            if mapping.get('intrinsic_vgs') or mapping.get('intrinsic_vds'):
                required += ['intrinsic_vgs','intrinsic_vds']
            if 'bulk' not in catalog['terminal_roles']:required.append('vbs')
            if any(not mapping.get(k) for k in required):raise ValueError('required PDK DC mapping missing: '+signal)
            key=canonical_device(signal)
            if key in parameters:raise ValueError('multiple OA devices bind to same PSF device: '+key)
            parameters[key]=sorted(set(mapping[k] for k in required))
        elif catalog['kind']=='resistor':
            if not mapping.get('current'):raise ValueError('resistor current signal mapping missing: '+signal)
            for segment in device.get('segments',[device]):
                nodes.update(segment['nodes'])
                currents.add(segment['path']+dev['signal_postfix']+':'+mapping['current'])
    return validate_query(dict(schema='st-dc-query-v1',nodes=sorted(nodes),device_parameters=parameters,currents=sorted(currents)))


def resistor_measurement(device, raw, catalog, dev, reltol=1e-3, iabstol=1e-12):
    mapping = dict(dev['dc_signals']);mapping.update(dev['electrical_rules'].get('dc_signals',{}))
    if not mapping.get('current'):raise ValueError('resistor current signal mapping missing')
    volts = {role:raw_value(raw,n) for role,n in zip(catalog['terminal_roles'],device['nodes'])}
    voltage = finite(volts['positive']-volts['negative'])
    if 'segments' not in device:
        current = raw_value(raw,device['path']+dev['signal_postfix']+':'+mapping['current'])
        return dict(instance=device['output_name'],vpos=volts['positive'],vneg=volts['negative'],
                    voltage=voltage,current=current,power=finite(abs(voltage*current)))
    sums,through,segments = {},{},[]
    for segment in device['segments']:
        a,b = segment['nodes']
        current = raw_value(raw,segment['path']+dev['signal_postfix']+':'+mapping['current'])
        drop = raw_value(raw,a)-raw_value(raw,b)
        power = finite(drop*current)
        if power < -iabstol*max(abs(drop),1e-12):
            raise ValueError('expanded resistor current orientation/passivity conflict: '+segment['path'])
        for node,value in ((a,current),(b,-current)):
            sums[node]=sums.get(node,0.)+value;through[node]=through.get(node,0.)+abs(value)
        segments.append(dict(path=segment['path'],voltage=drop,current=current,power=power))
    for node in device['private_nodes']:
        if abs(sums[node]) > iabstol+reltol*through[node]:
            raise ValueError('expanded resistor internal KCL failed: '+node)
    plus,minus = device['nodes'];current=sums[plus]
    if abs(current+sums[minus]) > iabstol+reltol*(through[plus]+through[minus]):
        raise ValueError('expanded resistor boundary KCL failed: '+device['output_name'])
    total_power=finite(sum(row['power'] for row in segments));port_power=finite(voltage*current)
    if abs(total_power-port_power) > iabstol*max(abs(voltage),1e-12)+reltol*max(abs(total_power),abs(port_power)):
        raise ValueError('expanded resistor power balance failed: '+device['output_name'])
    return dict(instance=device['output_name'],vpos=volts['positive'],vneg=volts['negative'],voltage=voltage,
        current=current,power=abs(port_power),segment_power=total_power,segments=segments,
        kcl_verified=True,reltol=reltol,iabstol=iabstol)


def run(args):
    verify_site_inputs(read_json(os.environ['ST_SITE_INPUTS_MANIFEST']), os.environ, verify_content=False)
    directory = Path(args.simulation_dir).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    context_path = os.environ['ST_CIRCUIT_CONTEXT']
    context = read_json(context_path)
    extension = read_json(os.environ['ST_SIMULATION_PROFILE'])
    configs = read_json(os.environ['ST_PDK_METADATA'])
    config_matches = [c for c in configs if c['version'] == args.pdk_version]
    if len(config_matches) != 1:
        raise ValueError('active tech config/requested PDK version conflict')
    tech = config_matches[0]
    scope = extension.get('validation_scope', 'dc_operating_point')
    if scope != 'experimental_dc' and ('experimental_parameter_seeds' in extension or extension.get('native_parameter_trials')):
        raise ValueError('native parameter trials require experimental_dc')
    experimental_dc = scope == 'experimental_dc'
    devices_by_model = load_scanned_catalog(args.device_catalog, tech, args.pdk_version, scope)
    receipt = None
    if experimental_dc and os.environ.get('ST_EXPERIMENT_REUSE_MANIFEST'):
        from experiment_reuse import active_receipt, write_baseline
        receipt = active_receipt()
        if write_baseline(args, receipt):
            return
    runtime = os.environ['ST_CADENCE_RUNTIME_BIN']
    if not Path(runtime).is_absolute() or not os.access(runtime, os.X_OK):
        raise ValueError('ST_CADENCE_RUNTIME_BIN must be an absolute executable')
    side = extension.get('design_side', 'source')
    original = context[side + '_dut']
    corner = extension.get('op_corners', {}).get(args.corner)
    if not corner or 'temperature' not in corner or 'models' not in corner:
        raise ValueError('circuit OP Corner requires temperature, model selection and variables')
    bench = {'lib': args.bench_lib, 'cell': args.bench_cell, 'view': args.bench_view}
    if not any(all(b.get(k) == v for k, v in bench.items()) for b in context[side + '_benches']):
        raise ValueError('requested Bench is outside imported circuit')
    cds_lib = Path(args.cds_lib or (Path(context[side + '_cds_path']) / 'cds.lib')).resolve()
    if not cds_lib.is_file():
        raise ValueError('requested cds.lib missing')
    bundle=None
    reused_export = False
    if extension.get('validated_baseline_bundle'):
        saved = None
        if receipt:
            from experiment_reuse import copy_source_export
            saved = copy_source_export(args,receipt,directory)
        if saved is not None:
            from baseline_bundle import load_bundle
            from standalone import validate_bundle_profile
            bundle=load_bundle(extension['validated_baseline_bundle'],original,bench,args.corner)
            validate_bundle_profile(bundle,extension)
            text,root=saved
            reused_export=True
        else:
            bundle,text,root=prepare_bundle_candidate(args,extension,original,bench,cds_lib,runtime,directory)
        applied_bench=(directory/'bench.scs').read_text()
        target_subckt=args.dut_cell
    else:
        if args.bench_view != 'schematic':
            command(runtime, ['bench-info', '--lib', bench['lib'], '--cell', bench['cell'], '--view', bench['view'],
                              '--cds-path', str(cds_lib.parent), '--work-dir', str(directory),
                              '--output', str(directory / 'bench_info.json')], directory, 'bench_info')
            info = read_json(directory / 'bench_info.json')
            enabled = [name for name, test in info.get('Tests', {}).items() if test.get('enable') is True]
            selected_test = extension.get('bench_test_name')
            if len(enabled) != 1 or (selected_test is not None and selected_test != enabled[0]):
                raise ValueError('OP Bench must have exactly one enabled test matching the circuit selection')
            selected_test = enabled[0]
        else:
            selected_test = None
        source_subckt = extension.get('source_subckt', original['cell'])
        # Use the current isolated OA registry, including generated/staging libraries.
        for label, design, mode in [('bench', bench, 'fast' if args.bench_view == 'schematic' else 'ocean'),
                                    ('dut', {'lib': args.dut_lib, 'cell': args.dut_cell, 'view': args.dut_view}, 'fast')]:
            work = directory / (label + '_oa')
            work.mkdir()
            export_args = ['netlist', '--lib', design['lib'], '--cell', design['cell'], '--view', design['view'],
                              '--cds-path', str(cds_lib.parent), '--work-dir', str(work), '--mode', mode,
                              '--output', str(directory / (label + '.scs'))]
            if label == 'dut':
                export_args.extend(['--ports-from', str(directory / 'bench.scs'), '--source-subckt', source_subckt])
            command(runtime, export_args, directory, 'export_' + label)
        target_subckt = args.dut_cell
        bench_origin = read_json(directory / 'bench.scs.origin.json')
        dut_origin = read_json(directory / 'dut.scs.origin.json')
        if selected_test is not None and bench_origin['dc_test_name'] != selected_test:
            raise ValueError('Ocean exported a different Bench test')
        physical_bench = resolve_includes((directory / 'bench.scs').read_text(), bench_origin['working_directory'])
        physical_dut = resolve_includes((directory / 'dut.scs').read_text(), dut_origin['working_directory'])
        check_bench_binding(context_path, physical_bench)
        applied_bench = apply_corner(physical_bench, {'sections': corner['models']}, corner['temperature'],
                                    extension.get('original_model_files', []), corner.get('variables', {}))
        check_bench_binding(context_path, applied_bench, args.corner)
        text, root = bind_dut(applied_bench, physical_dut,
                              source_subckt, target_subckt)
        text = request_dc(text)
    (directory / 'simulation.scs').write_text(text)
    write_json(directory / 'binding.json', {'dut': [args.dut_lib, args.dut_cell, args.dut_view],
        'bench': bench, 'root_path': root, 'corner': args.corner, 'cds_lib': str(cds_lib),
        'physical_dut_sha256': hashlib.sha256((directory / 'dut.scs').read_bytes()).hexdigest(),
        'physical_bench_sha256': hashlib.sha256((directory / 'bench.scs').read_bytes()).hexdigest(),
        'effective_bench_sha256': bench_context_digest(applied_bench),
        'scanned_catalog_sha256': hashlib.sha256(Path(args.device_catalog).read_bytes()).hexdigest(),
        'simulation_sha256': hashlib.sha256(text.encode()).hexdigest()})
    bindings_backend = os.environ.get('ST_SITE_BINDINGS_BACKEND',
        str(Path(__file__).resolve().parents[1] / 'st_virtuoso_backend.sh'))
    focus=None;functional={};unchanged_count=0;target_paths={}
    if bundle and experimental_dc and not reused_export:
        focus,unchanged_count,functional=candidate_focus(text,root,target_subckt,
            Path(bundle['bench_netlist']).read_text(),bundle['source_subckt'],
            confirmed_targets(Path(args.identity_output).parent,receipt),target_paths)
        for name,path in sorted(target_paths.items()):
            print('TARGET_PHYSICAL_PATH '+name+'='+path,flush=True)
    if not reused_export:
        previous=os.environ.get('ST_BINDING_ROOTS')
        try:
            if focus is not None:
                os.environ['ST_BINDING_ROOTS']='\n'.join(sorted({n.split('.')[0].split('<')[0] for n in focus}))
            command(bindings_backend, ['device-bindings', '--cds-lib', str(cds_lib), '--lib', args.dut_lib,
                '--cell', args.dut_cell, '--view', args.dut_view, '--output', str(directory / 'oa_bindings.tsv')],
                directory, 'physical_oa_bindings')
        finally:
            if previous is None:os.environ.pop('ST_BINDING_ROOTS',None)
            else:os.environ['ST_BINDING_ROOTS']=previous
    bindings = read_oa_bindings(directory / 'oa_bindings.tsv')
    preserved = []
    readback_evidence={}
    if bundle and experimental_dc:
        physical_devices = bind_candidate_devices(text,root,target_subckt,devices_by_model,bindings,
            Path(bundle['bench_netlist']).read_text(),bundle['source_subckt'],
            Path(args.identity_output).resolve().parent,preserved,readback_evidence,focus=focus)
    else:
        physical_devices = bind_physical_devices(text,root,target_subckt,devices_by_model,bindings)
    aggregates=[dict(instance=d['output_name'],nodes=d['nodes'],geometry=d['params'],
        segments=[s['path'] for s in d['segments']]) for d,_,_ in physical_devices if 'segments' in d]
    write_json(directory/'resistor_binding.json',dict(aggregates=aggregates,readback_sha256=readback_evidence))
    if aggregates:print('AGGREGATED_RESISTOR_GROUPS='+str(len(aggregates)),flush=True)
    for device,_,_ in physical_devices:
        if 'verified_series_geometry' in device:
            print('REFERENCE_RESISTOR_NATIVE='+json.dumps(dict(instance=device['output_name'],
                **device['verified_series_geometry']),sort_keys=True),flush=True)
    if experimental_dc:
        write_json(directory/'preserved_resistors.json', preserved)
        if focus is None:print('PRESERVED_RESISTOR_GROUPS='+str(len(preserved)), flush=True)
        print('UNCHANGED_PERIPHERAL_DEVICES_SKIPPED='+str(unchanged_count),flush=True)
        print('FOCUSED_OP_DEVICES='+str(len(physical_devices))+'\nFULL_CIRCUIT_SIMULATION=true',flush=True)
    extra=[]
    read_extra=[]
    if bundle:
        require_supported_voltage_semantics(physical_devices)
        query=build_dc_query(physical_devices,extension.get('supply_current_signals',[]))
        query['nodes']=sorted(set(query['nodes'])|set(functional.values()))
        write_json(directory/'psf_query.json',query)
        extra=['--baseline-bundle',extension['validated_baseline_bundle']]
        read_extra=['--request',str(directory/'psf_query.json'),'--cds-path',str(cds_lib.parent)]
        write_json(directory/'baseline_bundle_binding.json',dict(path=bundle['_bundle_path'],
            sha256=bundle['_bundle_sha256'],launch_contract=bundle['launch_contract']))
    else:
        # Legacy reader has no per-device native source metadata contract.
        for _, _, dev in physical_devices:
            mapping=dict(dev['dc_signals']);mapping.update(dev['electrical_rules'].get('dc_signals',{}))
            if mapping.get('vdsat')=='vdssat' or any(mapping.get(k) for k in ('intrinsic_vgs','intrinsic_vds')):
                raise ValueError('intrinsic CMG extraction requires the formal Bundle reader')
    command(runtime, ['simulate', '--netlist', str(directory / 'simulation.scs'),
                      '--psf-dir', str(directory / 'psf'), '--log', str(directory / 'spectre.log')]+extra,
            directory, 'simulate')
    command(runtime, ['read-psf', '--psf-dir', str(directory / 'psf'),
                      '--output', str(directory / 'raw_signed.tsv')]+read_extra, directory, 'read_psf')
    if bundle:
        from baseline_bundle import load_bundle
        if not experimental_dc:load_bundle(extension['validated_baseline_bundle'],original,bench,args.corner)
        require_supported_voltage_semantics(physical_devices,read_json(str(directory/'raw_signed.tsv')+'.sources.json'))
    raw = read_raw(directory / 'raw_signed.tsv')
    mos, resistors, missing_ratings, resistor_measurements = [], [], [], []
    for device, catalog, dev in physical_devices:
        device['signal_path'] = device['path'] + dev['signal_postfix']
        if bundle:device['signal_path'] = canonical_device(device['signal_path'])
        signals = dict(dev['dc_signals'])
        signals.update(dev['electrical_rules'].get('dc_signals', {}))
        if catalog['kind'] in ('mos_n', 'mos_p'):
            mos.append(mos_row(device, raw, catalog, signals))
        elif catalog['kind'] == 'resistor' and args.resistor_output:
            rating_rules = dev['electrical_rules'].get('resistor_ratings', [])
            geometry_keys = {key for rule in rating_rules for key in rule.get('geometry', {})}
            geometry_keys.update(dev['sim_cdf'].values() if 'sim_cdf' in dev else [])
            if experimental_dc:
                geometry_keys.update(dev.get('normalized_to_cdf', {}).values())
            geometry = {key: parameter_value(value, device['parameters']) for key, value in device['params'].items()
                        if key in geometry_keys}
            if experimental_dc:
                rating = resistor_rating(rating_rules, geometry, args.corner,
                                         corner['temperature'], experimental_dc=True)
                unknown = [key for key in ('max_voltage', 'max_power', 'max_current') if key not in rating]
                if unknown:
                    missing_ratings.append({'instance': device['path'], 'unverified_constraints': unknown})
            else:
                try:
                    rating = resistor_rating(rating_rules, geometry, args.corner, corner['temperature'])
                except ValueError as error:
                    missing_ratings.append({'instance': device['path'], 'reason': str(error)})
                    continue
            measured=resistor_measurement(device,raw,catalog,dev)
            resistor_measurements.append(measured)
            absent = 'NA' if experimental_dc else 0
            resistors.append([device['output_name'], catalog['master'], json.dumps(geometry, sort_keys=True, separators=(',', ':')),
                measured['vpos'], measured['vneg'], measured['current'],
                rating.get('max_voltage', absent), rating.get('max_power', absent),
                rating.get('max_current', absent), rating.get('source', '-')])
    if not mos:
        raise ValueError('no MOS from scanned PDK could be bound to actual DUT/PSF')
    for path,digest in ({} if experimental_dc else readback_evidence).items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:
            raise ValueError('candidate OA readback changed during simulation: '+path)
    supply = extension.get('supply_current_signals', [])
    total = total_supply_measurement(raw, supply)
    functional_values={name:raw_value(raw,node) for name,node in functional.items()}
    for name,value in sorted(functional_values.items()):print('FUNCTIONAL_NODE '+name+'='+str(value),flush=True)
    write_json(directory / 'extraction.json', {'mos_count': len(mos), 'resistor_count': len(resistors),
                                              'functional_node_values':functional_values,
                                              'unchanged_peripheral_devices_skipped':unchanged_count,
                                              'missing_resistor_ratings': missing_ratings,
                                              'resistor_measurements': resistor_measurements,
                                              'validation_scope': scope,
                                              'reliability_verified': False})
    write_tsv(args.identity_output, ['dut_hash', 'bench_hash', 'pdk_version', 'corner', 'topology_hash',
        'parameter_hash', 'solver_version', 'total_supply_current'], [[args.dut_hash, args.bench_hash,
        args.pdk_version, args.corner, args.topology_hash, args.parameter_hash, args.solver_version, total]])
    write_mos_tsv(args.mos_output, mos)
    if args.resistor_output:
        write_tsv(args.resistor_output, ['instance', 'master', 'geometry', 'vpos', 'vneg', 'current',
            'max_voltage', 'max_power', 'max_current', 'rating_source'], resistors)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('dut-lib', 'dut-cell', 'dut-view', 'bench-lib', 'bench-cell', 'bench-view', 'corner',
                 'dut-hash', 'bench-hash', 'pdk-version', 'topology-hash', 'parameter-hash', 'solver-version',
                 'identity-output', 'mos-output', 'simulation-dir'):
        parser.add_argument('--' + name, required=True)
    for name in ('dut-storage', 'bench-storage', 'resistor-output', 'device-catalog', 'cds-lib'):
        parser.add_argument('--' + name, default='')
    args = parser.parse_args()
    args.cds_lib = args.cds_lib or os.environ.get('ST_OP_CDS_LIB', '')
    args.device_catalog = args.device_catalog or os.environ.get('ST_OP_DEVICE_CATALOG', '')
    try:
        run(args)
    except RuntimeFailure as error:
        print('real Cadence OP provider: ' + str(error), file=sys.stderr)
        return error.code
    except (ValueError, KeyError, OSError, RuntimeError, StopIteration, ZeroDivisionError, SyntaxError) as error:
        print('real Cadence OP provider: ' + str(error), file=sys.stderr)
        return 70
    return 0


if __name__ == '__main__':
    sys.exit(main())
