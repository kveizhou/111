import copy
import importlib.util
import json
import pathlib
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("compare_structure", ROOT / "code/compare_structure.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def example():
    return module.load_design(ROOT / "examples/expected.json")


class StructuralComparisonTest(unittest.TestCase):
    def test_order_independent(self):
        a = example()
        b = dict(reversed(list(a.items())))
        b = copy.deepcopy(b)
        for s in b.values():
            s["instances"].reverse()
        self.assertEqual(module.diff(a, b), [])

    def test_engineering_units_and_precision(self):
        for a, b in (("240n", "2.400000000000003e-7"), ("48259.84", "48.25984k"),
                     ("1M", "1meg"), ("1m", "0.001")):
            self.assertTrue(module.equivalent(a, b))
        self.assertFalse(module.equivalent("1M", "1m"))
        self.assertFalse(module.equivalent("48259.84", "48.2598k"))
        self.assertFalse(module.equivalent("1n", "2n"))

    def test_expressions_are_not_evaluated(self):
        self.assertFalse(module.equivalent("w*2", "2*w"))
        self.assertTrue(module.equivalent("w*2", "w*2"))

    def test_swapped_mos_terminals_fail(self):
        a = example(); b = copy.deepcopy(a)
        m = b["LEAF_EDIT"]["instances"][0]
        m["nets"][0], m["nets"][2] = m["nets"][2], m["nets"][0]
        self.assertTrue(module.diff(a, b))

    def test_root_still_references_original_fails(self):
        a = example(); b = copy.deepcopy(a)
        b["TOP"]["instances"][0]["model"] = "LDO_OLD"
        self.assertTrue(module.diff(a, b))

    def test_other_occurrence_must_not_change(self):
        a = example(); b = copy.deepcopy(a)
        b["LS"]["instances"][1]["model"] = "LEAF_EDIT"
        self.assertTrue(module.diff(a, b))

    def test_undeclared_parameter_not_ignored(self):
        a = example(); b = copy.deepcopy(a)
        b["LEAF_EDIT"]["instances"][0]["params"]["m"] = "2"
        self.assertTrue(module.diff(a, b))

    def test_port_order_is_not_sorted(self):
        a = example(); b = copy.deepcopy(a)
        b["LEAF_EDIT"]["pins"].reverse()
        self.assertTrue(module.diff(a, b))

    def test_directives_are_not_discarded(self):
        a = example(); b = copy.deepcopy(a)
        b["@top"]["directives"].append('include "wrong_corner.scs"')
        self.assertTrue(module.diff(a, b))

    def test_add_and_remove(self):
        a = example(); b = copy.deepcopy(a)
        b["LEAF_EDIT"]["instances"].pop()
        self.assertEqual(module.diff(a, b)[0]["kind"], "instance_removed")
        self.assertEqual(module.diff(b, a)[0]["kind"], "instance_added")

    def test_duplicate_name_rejected(self):
        data = json.loads((ROOT / "examples/expected.json").read_text())
        data["subckts"][0]["instances"] *= 2
        with tempfile.TemporaryDirectory() as t:
            p = pathlib.Path(t) / "bad.json"
            p.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                module.load_design(p)

    def test_numeric_change_reports_values(self):
        a = example(); b = copy.deepcopy(a)
        b["LEAF_EDIT"]["instances"][0]["params"]["l"] = "120n"
        rows = module.diff(a, b)
        self.assertEqual(rows[0]["changes"]["params"]["l"]["after"], "120n")


if __name__ == "__main__":
    unittest.main()
