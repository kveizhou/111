#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo 'Usage: bash code/run_local_check.sh /absolute/path/to/st-engine-maau' >&2
  exit 2
fi
package_root=$(cd "$(dirname "$0")/.." && pwd)
engine_root=$(cd "$1" && pwd)
build_dir=$(mktemp -d "${TMPDIR:-/tmp}/maau-hierarchy-answer.XXXXXX")
trap 'rm -rf "$build_dir"' EXIT
"${CXX:-c++}" -std=c++17 -Wall -Wextra -Werror -I"$engine_root/include" \
  "$package_root/code/netlist_json.cpp" "$engine_root/src/Netlist.cpp" \
  -o "$build_dir/netlist_json"
for name in before expected actual_reordered; do
  "$build_dir/netlist_json" "$package_root/examples/$name.scs" "$build_dir/$name.json"
done
python3 -B -m unittest discover -s "$package_root/tests" -v
python3 -B "$package_root/code/compare_structure.py" \
  --before "$build_dir/before.json" --expected "$build_dir/expected.json" \
  --actual "$build_dir/actual_reordered.json" --report "$build_dir/report.json"
echo LOCAL_REFERENCE_CHECK=PASS
echo NATIVE_CADENCE_EXECUTIONS=0
