#!/usr/bin/env python3
"""Compare canonical Netlist JSON produced by the host parser / netlist_json.cpp.

This is NOT a general Spectre parser or electrical-equivalence checker.
Names must already be normalized by the host's explicit OA/netlister mapping.
Exit 0: structure matches; 1: differences; 2: invalid input.
"""
import argparse
import json
import re
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

SUFFIX = {"": 0, "T": 12, "G": 9, "M": 6, "meg": 6,
          "K": 3, "k": 3, "m": -3, "u": -6, "n": -9,
          "p": -12, "f": -15, "a": -18}
NUMBER = re.compile(r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)([A-Za-z]*)\Z")


def numeric(value):
    match = NUMBER.fullmatch(value.strip())
    if not match or match[2] not in SUFFIX:
        return None
    try:
        return Decimal(match[1]) * (Decimal(10) ** SUFFIX[match[2]])
    except InvalidOperation:
        return None


def equivalent(a, b):
    if a == b:
        return True
    x, y = numeric(a), numeric(b)
    return (x is not None and y is not None and
            abs(x-y) <= Decimal("1e-12") * max(abs(x), abs(y)))


def indexed(rows, label):
    if not isinstance(rows, list):
        raise ValueError(label + " must be a list")
    result = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str) or not row["name"]:
            raise ValueError(label + " requires a nonempty name")
        if row["name"] in result:
            raise ValueError(label + " duplicate: " + row["name"])
        result[row["name"]] = row
    return result


def strings(value, label):
    if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
        raise ValueError(label + " must be a list of strings")


def params(value):
    if not isinstance(value, dict) or any(not isinstance(v, str) for v in value.values()):
        raise ValueError("parameters must map names to string values")


def load_design(path):
    design = json.loads(Path(path).read_text(encoding="utf-8"))
    if design.get("schema") != "maau-netlist-v1":
        raise ValueError("unsupported / missing schema")
    strings(design["preamble"], "preamble")
    scopes = indexed(design["subckts"], "subckts")
    if "@top" in scopes:
        raise ValueError("@top is reserved")
    scopes["@top"] = {"name": "@top", "pins": [], "params": {},
                       "directives": design["preamble"], "instances": design["top_instances"]}
    for scope in scopes.values():
        strings(scope["pins"], "pins")
        strings(scope["directives"], "directives")
        params(scope["params"])
        for inst in indexed(scope["instances"], scope["name"]).values():
            if not isinstance(inst["model"], str) or not inst["model"]:
                raise ValueError("invalid master")
            strings(inst["nets"], "nets")
            params(inst["params"])
    return scopes


def parameter_changes(before, after):
    return {k: {"before": before.get(k), "after": after.get(k)}
            for k in sorted(before.keys() | after.keys())
            if k not in before or k not in after or not equivalent(before[k], after[k])}


def diff(before, after):
    changes = []
    for name in sorted(before.keys() | after.keys()):
        if name not in before or name not in after:
            changes.append({"scope": name, "kind": "scope_added" if name in after else "scope_removed",
                            "before": before.get(name), "after": after.get(name)})
            continue
        left, right = before[name], after[name]
        for field in ("pins", "directives"):
            # Positional ports and directive order are electrically meaningful.
            if left[field] != right[field]:
                changes.append({"scope": name, "kind": field, "before": left[field], "after": right[field]})
        delta = parameter_changes(left["params"], right["params"])
        if delta:
            changes.append({"scope": name, "kind": "scope_parameters", "changes": delta})
        a, b = indexed(left["instances"], name), indexed(right["instances"], name)
        for inst in sorted(a.keys() | b.keys()):
            record = {"scope": name, "instance": inst}
            if inst not in a or inst not in b:
                record.update(kind="instance_added" if inst in b else "instance_removed",
                              before=a.get(inst), after=b.get(inst))
                changes.append(record)
                continue
            fields = {k: {"before": a[inst][k], "after": b[inst][k]}
                      for k in ("model", "nets") if a[inst][k] != b[inst][k]}
            delta = parameter_changes(a[inst]["params"], b[inst]["params"])
            if delta:
                fields["params"] = delta
            if fields:
                record.update(kind="instance_changed", changes=fields)
                changes.append(record)
    return changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", required=True)
    parser.add_argument("--expected", required=True)
    parser.add_argument("--actual", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    try:
        before, expected, actual = [load_design(p) for p in (args.before, args.expected, args.actual)]
        mismatches = diff(expected, actual)
        report = {"result": "STRUCTURE_MATCH" if not mismatches else "STRUCTURE_MISMATCH",
                  "electrical_verified": False, "mismatches": mismatches,
                  "intended_changes": diff(before, expected), "actual_changes": diff(before, actual)}
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("RESULT=" + report["result"])
        print("MISMATCH_COUNT=" + str(len(mismatches)))
        print("ELECTRICAL_VERIFIED=false")
        print("REPORT=" + args.report)
        return 1 if mismatches else 0
    except (OSError, ValueError, TypeError, KeyError) as error:
        print("RESULT=INVALID_INPUT\nISSUE=" + str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
