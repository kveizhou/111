// Reference CLI for the existing st::parseSpectre supported subset.
// Production integration should call writeNetlistJson on the host's parsed,
// normalized Netlist; this file does not implement a general Spectre parser.
#include "st/Netlist.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace {
void quote(std::ostream& out, const std::string& text) {
    out << '"';
    for (unsigned char c : text) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c < 32) out << "\\u" << std::hex << std::setw(4)
                            << std::setfill('0') << unsigned(c) << std::dec;
        else out << c;
    }
    out << '"';
}
void strings(std::ostream& out, const std::vector<std::string>& values) {
    out << '['; bool first = true;
    for (const auto& s : values) { if (!first) out << ','; first = false; quote(out, s); }
    out << ']';
}
void params(std::ostream& out, const std::map<std::string, std::string>& values) {
    out << '{'; bool first = true;
    for (const auto& [key, value] : values) {
        if (!first) out << ',';
        first = false; quote(out, key); out << ':'; quote(out, value);
    }
    out << '}';
}
void instances(std::ostream& out, const std::vector<st::Instance>& values) {
    out << '['; bool first = true;
    for (const auto& inst : values) {
        if (!first) out << ',';
        first = false;
        out << "{\"name\":"; quote(out, inst.name);
        out << ",\"model\":"; quote(out, inst.model);
        out << ",\"nets\":"; strings(out, inst.nets);
        out << ",\"params\":"; params(out, inst.params); out << '}';
    }
    out << ']';
}
}

void writeNetlistJson(std::ostream& out, const st::Netlist& netlist) {
    out << "{\"schema\":\"maau-netlist-v1\",\"preamble\":";
    strings(out, netlist.preamble);
    out << ",\"top_instances\":"; instances(out, netlist.topInstances);
    out << ",\"subckts\":["; bool first = true;
    for (const auto& scope : netlist.subckts) {
        if (!first) out << ',';
        first = false;
        out << "{\"name\":"; quote(out, scope.name);
        out << ",\"pins\":"; strings(out, scope.pins);
        out << ",\"params\":"; params(out, scope.params);
        out << ",\"directives\":"; strings(out, scope.bodyDirectives);
        out << ",\"instances\":"; instances(out, scope.instances); out << '}';
    }
    out << "]}\n";
}

int main(int argc, char** argv) {
    if (argc != 3) { std::cerr << "Usage: netlist_json normalized.scs output.json\n"; return 2; }
    try {
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("cannot open input");
        std::ostringstream text; text << input.rdbuf();
        std::vector<st::Diagnostic> errors;
        const auto netlist = st::parseSpectre(text.str(), errors);
        if (!errors.empty()) throw std::runtime_error("existing parser reported an error");
        if (netlist.subckts.empty() && netlist.topInstances.empty())
            throw std::runtime_error("no circuit instances or subckt definitions parsed");
        std::ofstream output(argv[2]);
        if (!output) throw std::runtime_error("cannot open output");
        writeNetlistJson(output, netlist);
        output.close();
        if (!output) throw std::runtime_error("cannot write output");
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 2; }
}
