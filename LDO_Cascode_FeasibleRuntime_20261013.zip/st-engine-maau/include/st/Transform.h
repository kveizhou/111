#pragma once
// 四类结构变换的正式工程入口。端子、器件兼容性、Bias 和工艺限制
// 必须由 DeviceCatalog/ResistorTemplate 与自动求解器结果明确提供。
#include "Netlist.h"
#include "Bias.h"
#include "DcSolver.h"

#include <optional>

namespace st {

struct ParameterRange {
    double initial = 0.0;
    double minimum = 0.0;
    double maximum = 0.0;
    double grid = 0.0;
};

// 一次变换的产出清单（对应变体记录里的 operations 段）
struct TransformOutcome {
    std::vector<std::string> addedInstances;
    std::vector<std::string> removedInstances;
    std::vector<std::string> modifiedInstances;
    std::vector<std::string> addedNets;
    // FixedBias Cascode 的 VBIAS 模板层级实例。独立报告，不进 addedInstances，
    // 以便封装阶段把它单独包成 VBIAS 子Cell而不是并入功能封装。
    std::vector<std::string> bias_instances;
    std::vector<std::string> notes;        // 非阻断提示（如"栅网络被保留"）
    std::map<std::string, std::vector<std::string>> parameter_groups;
    std::map<std::string, ParameterRange> parameter_ranges;
    std::map<std::string, double> numeric_outputs;
    std::vector<std::string> external_ports;
    double iq_delta = 0.0;
    std::vector<BiasResolution::Cost> bias_costs;
    std::vector<Diagnostic> diags;
    bool ok() const {
        for (const auto& d : diags) if (isError(d.code)) return false;
        return true;
    }
};

enum class GatePolicy {
    SharedGate,
    FixedBias,
};

struct CascodeTransformRequest {
    std::string subckt;
    std::string target;
    std::string new_master; // 空表示与原管同 master
    GatePolicy gate_policy = GatePolicy::FixedBias;
    // FixedBias 只消费自动求解器已闭环的结果：求解参数（含新增管量化值）
    // 和按固定拓扑构建的模板。产品操作文件不提供模板、参考电流、OP
    // 或电压窗等手工输入。SharedGate 路径不需要任何 bias 输入。
    std::optional<AutoBiasSolveResult> solved_bias;
    std::optional<AutoBiasTemplateResult> bias_template;
    // 模板 VHIGH/VLOW 端口要接的父层真实轨网；VS_ORIG/VG_CTRL 从网表读
    // 变换前原管的 Source/Gate，输出网按 模板输出名 + "_" + target 分配。
    std::string vbias_vhigh_net;
    std::string vbias_vlow_net;
    std::string voltage_domain;
    std::string nmos_bulk_net;
    bool tie_isolated_pmos_to_source = true;
};

TransformOutcome applyCascode(Netlist& nl, const CascodeTransformRequest& request,
                              const DeviceCatalog& catalog);

struct ResistorTemplate {
    std::string master;
    std::string resistance_parameter = "r";
    double grid = 0.0;
    double minimum_resistance = 0.0;
    double maximum_resistance = std::numeric_limits<double>::infinity();
    // Positive/Negative 连接 MOS Source 内部节点和原 Source 网络；
    // 这里仅绑定 substrate、well 等额外端子。
    std::map<TerminalRole, std::string> extra_terminal_nets;
};

struct ResistorTransformRequest {
    std::string subckt;
    std::string target;
    // 初值优先级：用户值 -> Case 预置 -> PDK 合法范围几何中点。
    std::optional<double> requested_resistance;
    std::optional<double> case_default_resistance;
    double search_lower_factor = 0.5;
    double search_upper_factor = 2.0;
    ResistorTemplate resistor;
};

TransformOutcome applyResistor(Netlist& nl, const ResistorTransformRequest& request,
                               const DeviceCatalog& catalog);

enum class StackIntent {
    EffectiveLength,
};

struct StackTransformRequest {
    std::string subckt;
    std::string target;
    int stage_count = 2;
    StackIntent intent = StackIntent::EffectiveLength;
    GatePolicy gate_policy = GatePolicy::SharedGate;
    std::string voltage_domain;
    std::string nmos_bulk_net;
    bool tie_isolated_pmos_to_source = true;
    // Set only by a structure-only session. Preserve actual original Bulk and
    // dimensions; no electrical voltage-domain or well policy is inferred.
    bool structure_only = false;
};

// 业务数据库只保存这个逻辑对象；只有仿真、网表或 OA 预览物化时，
// 才调用 materializeStack 展开成 N 个实际 MOS。
struct LogicalMosStack {
    std::string subckt;
    std::string original_instance;
    std::string master;
    int stage_count = 0;
    StackIntent intent = StackIntent::EffectiveLength;
    GatePolicy gate_policy = GatePolicy::SharedGate;
    std::string drain_net;
    std::string original_gate_net;
    std::string source_net;
    std::string original_bulk_net;
    std::map<std::string, std::string> original_params;
    // Drain -> Source 顺序：M0, M0_S1, ..., M0_S(N-1)。
    std::vector<std::string> stage_instance_names;
    std::vector<std::string> middle_nets;
    std::vector<std::string> gate_nets;
    std::vector<std::string> bulk_nets;
    std::vector<std::map<std::string, std::string>> stage_params;
    std::map<std::string, std::vector<std::string>> sizing_groups;
};

struct StackPlan {
    LogicalMosStack stack;
    std::vector<Diagnostic> diags;
    bool ok() const {
        for (const auto& diagnostic : diags) {
            if (isError(diagnostic.code)) return false;
        }
        return true;
    }
};

StackPlan planStack(const Netlist& nl, const StackTransformRequest& request,
                    const DeviceCatalog& catalog);
TransformOutcome materializeStack(Netlist& nl, const LogicalMosStack& stack,
                                  const DeviceCatalog& catalog);

} // namespace st
