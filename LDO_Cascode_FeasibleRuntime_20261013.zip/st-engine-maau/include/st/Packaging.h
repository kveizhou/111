#pragma once

#include "ChangeSet.h"
#include "OaPlan.h"

#include <string>
#include <map>
#include <vector>

namespace st {

// One generated child cell.  circuit.name is the generated cell name and
// circuit.pins is the exact symbol/schematic terminal order used by the parent.
struct GeneratedTopologyPackage {
    std::string package_id;
    std::string cell_name;
    std::string parent_instance_name;
    std::vector<std::string> operation_ids;
    // Every original root instance represented by this package. Usually this
    // has one entry, but merged/repeated transforms may consume more than one.
    std::vector<std::string> replaced_parent_instances;
    std::vector<std::string> member_instances;
    Subckt circuit;
    std::map<std::string, std::string> original_instance_by_member{};
};

struct PackageTopologyResult {
    Netlist netlist;
    std::vector<GeneratedTopologyPackage> packages;
    std::vector<Diagnostic> diagnostics;
    bool ok() const { return diagnostics.empty(); }
};

// Convert the flat, electrically validated transform result into a hierarchy
// suitable for Virtuoso display.  Electrically connected repeated operations
// are merged into one package so a later transform of an earlier added device
// cannot create overlapping/nested wrapper ownership.
PackageTopologyResult PackageTopologyVariant(
    const Netlist& baseline,
    const Netlist& flatVariant,
    const std::string& coreSubckt,
    const ChangeSet& changes,
    const ReplayResult& replay,
    const std::string& generatedCellPrefix,
    const std::string& generatedLibrary);

// DC 求解器的单操作候选已经是 applyCascode 产生的完整扁平网表。
// 本入口从基线/候选差异恢复一次封装所需的 outcome，用于将
// 功能 Cascode 和 VBIAS 模板物化为唯一 OA CellView 后再跑 DC。
PackageTopologyResult PackageSingleCandidateVariant(
    const Netlist& baseline,
    const Netlist& flatCandidate,
    const std::string& coreSubckt,
    const std::string& targetInstance,
    const std::string& generatedCellPrefix,
    const std::string& generatedLibrary);

// Build one generated schematic+symbol CellView per package and place only a
// wrapper instance in the cloned parent schematic.
OaPlanBuildResult BuildPackagedOaMaterializationPlan(
    const Netlist& baseline,
    const PackageTopologyResult& packaged,
    const DeviceCatalog& catalog,
    const OaPlanBuildContext& context,
    const std::string& generatedLibrary);

} // namespace st
