#pragma once

#include "OperatingPoint.h"

#include <string>

namespace st {

struct ExpectedResistor {
    std::string operation_id;
    std::string container_instance;
    std::string leaf_name;
    std::string master;
};

struct ResistorStressResult {
    bool ok = false;
    std::string failed_constraint;
    double voltage = 0.0;
    double power = 0.0;
    double current = 0.0;
};

// Check one expected added resistor against a Corner-specific OP and rating.
// No OP/rating or an ambiguous hierarchical name fails closed.
ResistorStressResult EvaluateResistorStress(
    const OperatingPointSnapshot& snapshot,
    const ExpectedResistor& expected);

} // namespace st
