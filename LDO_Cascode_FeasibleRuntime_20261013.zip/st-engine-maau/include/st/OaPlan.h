#pragma once

#include "Netlist.h"

#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace st {

struct CellViewRef {
    std::string library;
    std::string cell;
    std::string view;
    // 同名 L/C/V 可能位于不同 cds.lib/工作区；存储路径和修订号
    // 参与身份比较，避免把源图与隔离副本误判为同一对象。
    std::string storage_path;
    std::string revision;

    CellViewRef() = default;
    CellViewRef(std::string libraryValue, std::string cellValue,
                std::string viewValue, std::string storagePathValue = {},
                std::string revisionValue = {})
        : library(std::move(libraryValue)), cell(std::move(cellValue)),
          view(std::move(viewValue)), storage_path(std::move(storagePathValue)),
          revision(std::move(revisionValue)) {}
};

inline bool operator==(const CellViewRef& left, const CellViewRef& right)
{
    return left.library == right.library && left.cell == right.cell && left.view == right.view &&
        left.storage_path == right.storage_path && left.revision == right.revision;
}

inline bool SamePhysicalCellView(const CellViewRef& left, const CellViewRef& right)
{
    return left.library == right.library && left.cell == right.cell &&
        left.view == right.view && left.storage_path == right.storage_path;
}

struct OaPoint {
    double x = 0.0;
    double y = 0.0;
};

struct OaCloneMapping {
    CellViewRef source;
    CellViewRef target;
    std::string hierarchy_path;
    // 非根层级必须声明在哪个已克隆父cell中重绑定哪个实例，
    // 以保证只改选中的层级分支，不污染同cell的其他实例。
    std::string parent_hierarchy_path;
    std::string parent_instance_name;

    OaCloneMapping() = default;
    OaCloneMapping(CellViewRef sourceValue, CellViewRef targetValue,
                   std::string hierarchyPathValue,
                   std::string parentHierarchyPathValue = {},
                   std::string parentInstanceNameValue = {})
        : source(std::move(sourceValue)), target(std::move(targetValue)),
          hierarchy_path(std::move(hierarchyPathValue)),
          parent_hierarchy_path(std::move(parentHierarchyPathValue)),
          parent_instance_name(std::move(parentInstanceNameValue)) {}
};

struct OaDeleteInstance {
    std::string hierarchy_path;
    std::string name;
};

struct OaTerminalConnection {
    std::string semantic_terminal;
    std::string pdk_terminal;
    std::string net;
};

struct OaCreateInstance {
    std::string hierarchy_path;
    std::string name;
    CellViewRef master;
    OaPoint location;
    std::string orientation = "R0";
    std::vector<OaTerminalConnection> connections;
    std::size_t expected_terminal_count = 0;
    std::map<std::string, std::string> cdf_parameters;
    // Unchanged MOS properties come from the isolated root, before deletion.
    CellViewRef property_source{};
    std::string property_source_instance{};
    // Only unspecified defaults on a newly created structural device.
    std::set<std::string> allowed_extra_cdf_parameters{};
};

struct OaCreatePort {
    std::string hierarchy_path;
    std::string name;
    std::string direction;
    std::string net;
    OaPoint location;
};

struct OaDirectWire {
    std::string hierarchy_path;
    std::string net;
    std::string from_instance;
    std::string from_terminal;
    std::string to_instance;
    std::string to_terminal;
};

struct OaWire {
    std::string hierarchy_path;
    std::string net;
    std::vector<OaPoint> points;
};

struct PreviewIdentity {
    std::string variant_id;
    std::string parameter_set_id;
    std::string materializer_version;
};

// A fully generated child cell used to keep a topology transform compact in
// the parent schematic.  The schematic and symbol have the same library/cell
// identity and different views.  All nested object paths use
// /@generated/<package_id> and never refer to a source-design clone.
struct OaGeneratedCell {
    std::string package_id;
    CellViewRef schematic;
    CellViewRef symbol;
    OaPoint symbol_lower_left;
    OaPoint symbol_upper_right;
    std::vector<OaCreateInstance> create_instances;
    std::vector<OaCreatePort> create_ports;
    std::vector<OaDirectWire> direct_wires;
    std::vector<OaWire> wires;
};

struct OaMaterializationPlan {
    int schema_version = 1;
    CellViewRef source;
    CellViewRef target;
    std::vector<OaCloneMapping> clone_map;
    std::vector<OaGeneratedCell> generated_cells;
    std::vector<OaDeleteInstance> delete_instances;
    std::vector<OaCreateInstance> create_instances;
    std::vector<OaCreatePort> create_ports;
    // Newly introduced series nodes must be represented by a physical wire
    // between the two real symbol pins.  Two independent labelled stubs are
    // not reliable for these nodes in the deployed Virtuoso/PDK flow.
    std::vector<OaDirectWire> direct_wires;
    std::vector<OaWire> wires;
    bool check_and_save = true;
    PreviewIdentity preview;
};

std::vector<Diagnostic> ValidateOaPlan(const OaMaterializationPlan& plan);

struct OaPlanBuildContext {
    CellViewRef source;
    CellViewRef target;
    std::vector<OaCloneMapping> clone_map;
    std::map<std::string, std::string> hierarchy_by_subckt;
    // key = hierarchy_path + ":" + object name
    std::map<std::string, OaPoint> locations;
    std::map<std::string, std::string> port_directions;
    std::vector<OaWire> wires;
    PreviewIdentity preview;
    bool structure_only = false;
};

struct OaPlanBuildResult {
    OaMaterializationPlan plan;
    std::vector<Diagnostic> diagnostics;
    bool ok() const { return diagnostics.empty(); }
};

OaPlanBuildResult BuildOaMaterializationPlan(const Netlist& baseline,
                                             const Netlist& variant,
                                             const DeviceCatalog& catalog,
                                             const OaPlanBuildContext& context);

} // namespace st
