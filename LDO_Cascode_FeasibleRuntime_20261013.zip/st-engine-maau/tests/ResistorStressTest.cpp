#include "st/ResistorStress.h"

#include <iostream>

int main()
{
    st::OperatingPointSnapshot op;
    op.resistors["R_REF_N"] = {"pdk_r", "w=2u,l=10u", 1.2, 0.2,
                                1e-4, 1.0, 1e-4, 0.0, "pdk/tt_25c"};
    const st::ExpectedResistor role{"bias", {}, "R_REF_N", "pdk_r"};
    const auto atLimit = st::EvaluateResistorStress(op, role);
    if (!atLimit.ok) {
        std::cout << "FAIL: exact voltage/power limit should pass: "
                  << atLimit.failed_constraint << '\n';
        return 1;
    }
    op.resistors["R_REF_N"].vpos = 1.21;
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_voltage") {
        std::cout << "FAIL: over-voltage resistor should fail\n";
        return 1;
    }
    op.resistors["R_REF_N"].max_voltage = 2.0;
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_power") {
        std::cout << "FAIL: over-power resistor should fail\n";
        return 1;
    }
    op.resistors["R_REF_N"].max_power = 0.0;
    op.resistors["R_REF_N"].max_current = 9e-5;
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_current") {
        std::cout << "FAIL: over-current resistor should fail\n";
        return 1;
    }
    op.resistors["R_REF_N"].max_current = 2e-4;
    if (!st::EvaluateResistorStress(op, role).ok) {
        std::cout << "FAIL: PDK current-only rating should work\n";
        return 1;
    }
    op.resistors["R_REF_N"].master = "other_master";
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_master") {
        std::cout << "FAIL: rating for different master should fail\n";
        return 1;
    }
    op.resistors.clear();
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_op_missing") {
        std::cout << "FAIL: missing resistor OP should fail\n";
        return 1;
    }
    op.resistors["A.R_REF_N"] = {"pdk_r", "w=2u,l=10u", 1.2, 0.2,
                                  1e-4, 2.0, 2e-4, 0.0, "pdk/tt_25c"};
    op.resistors["B.R_REF_N"] = op.resistors["A.R_REF_N"];
    if (st::EvaluateResistorStress(op, role).failed_constraint != "resistor_op_ambiguous") {
        std::cout << "FAIL: ambiguous hierarchy should fail\n";
        return 1;
    }
    const st::ExpectedResistor scoped{"bias", "A", "R_REF_N", "pdk_r"};
    if (!st::EvaluateResistorStress(op, scoped).ok) {
        std::cout << "FAIL: scoped hierarchy should resolve uniquely\n";
        return 1;
    }
    op.resistors.clear();
    op.resistors["R_REF_N"] = {"pdk_r", "w=2u,l=10u", 1.2, 0.2,
                               1e-4, 2.0, 2e-4, 0.0, "pdk/tt_25c"};
    if (st::EvaluateResistorStress(op, scoped).failed_constraint !=
        "resistor_op_missing") {
        std::cout << "FAIL: scoped role must not consume an unscoped duplicate\n";
        return 1;
    }
    std::cout << "Resistor stress tests passed\n";
    return 0;
}
