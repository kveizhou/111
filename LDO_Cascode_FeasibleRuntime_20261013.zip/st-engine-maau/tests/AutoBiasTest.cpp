#include "st/AutoBias.h"

#include "st/Netlist.h"
#include "st/PdkCatalog.h"

#include <iostream>
#include <sstream>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::ParameterConstraint makeConstraint(const std::string& semantic,
                                       const std::string& cdf,
                                       double minimum, double maximum,
                                       double grid)
{
    st::ParameterConstraint constraint;
    constraint.semantic_name = semantic;
    constraint.cdf_name = cdf;
    constraint.minimum = minimum;
    constraint.maximum = maximum;
    constraint.grid = grid;
    return constraint;
}

st::DeviceDescriptor makeMos(const std::string& master, st::DeviceKind kind,
                             const std::string& library,
                             const std::vector<std::string>& terminalNames,
                             const std::vector<st::TerminalRole>& terminalRoles)
{
    st::DeviceDescriptor descriptor;
    descriptor.master = master;
    descriptor.kind = kind;
    descriptor.terminal_count = terminalNames.size();
    descriptor.terminal_names_by_index = terminalNames;
    descriptor.terminal_roles_by_index = terminalRoles;
    for (std::size_t index = 0; index < terminalRoles.size(); ++index) {
        if (terminalRoles[index] != st::TerminalRole::Other) {
            descriptor.terminal_index[terminalRoles[index]] = index;
        }
    }
    descriptor.oa_library = library;
    descriptor.oa_cell = master + "_cell";
    descriptor.oa_view = "symbol";
    descriptor.pdk_name = "fake_pdk";
    descriptor.pdk_version = "v1";
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains = {"core"};
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.limits.max_abs_vgs = 1.5;
    descriptor.limits.max_abs_vds = 1.5;
    descriptor.limits.max_abs_vgb = 1.5;
    descriptor.parameter_constraints["width"] =
        makeConstraint("width", "w", 2e-7, 1e-5, 5e-8);
    descriptor.parameter_constraints["length"] =
        makeConstraint("length", "l", 1.8e-7, 2e-6, 1e-8);
    return descriptor;
}

st::DeviceDescriptor makeResistor(const std::string& master,
                                  const std::string& library)
{
    st::DeviceDescriptor descriptor;
    descriptor.master = master;
    descriptor.kind = st::DeviceKind::Resistor;
    descriptor.terminal_count = 2;
    descriptor.terminal_names_by_index = {"PLUS", "MINUS"};
    descriptor.terminal_roles_by_index = {st::TerminalRole::Positive,
                                          st::TerminalRole::Negative};
    descriptor.terminal_index[st::TerminalRole::Positive] = 0;
    descriptor.terminal_index[st::TerminalRole::Negative] = 1;
    descriptor.oa_library = library;
    descriptor.oa_cell = master + "_cell";
    descriptor.oa_view = "symbol";
    descriptor.pdk_name = "fake_pdk";
    descriptor.pdk_version = "v1";
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains = {"core"};
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.parameter_constraints["resistance"] =
        makeConstraint("resistance", "r", 100.0, 1e6, 100.0);
    return descriptor;
}

st::DeviceCatalog makeNmosTemplateCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    // 控制管/同型新增管：标准 D,G,S,B 物理顺序
    catalog.Add(makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk}),
                diagnostic);
    // 异型新增管候选：同极性、同 Library、不同 Cell
    catalog.Add(makeMos("cas_nmos", st::DeviceKind::MosN, "pdkA_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk}),
                diagnostic);
    // 镜像 PMOS 首选：与控制管同 Library；物理端子顺序故意打乱为 G,D,S,B，
    // 验证模板按角色而不是数组下标连接
    catalog.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib",
                        {"G", "D", "S", "B"},
                        {st::TerminalRole::Gate, st::TerminalRole::Drain,
                         st::TerminalRole::Source, st::TerminalRole::Bulk}),
                diagnostic);
    // 镜像 PMOS 备选：Library 不同，即使可靠性余量更大也必须排后
    auto mirB = makeMos("mir_pmos_b", st::DeviceKind::MosP, "pdkB_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk});
    mirB.limits.max_abs_vgs = 3.0;
    mirB.limits.max_abs_vds = 3.0;
    mirB.limits.max_abs_vgb = 3.0;
    catalog.Add(mirB, diagnostic);
    // 镜像 PMOS 干扰项：同 Library 但电压域不允许，必须被拒绝
    auto mirC = makeMos("mir_pmos_c", st::DeviceKind::MosP, "pdkA_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk});
    mirC.voltage_domain = "hv";
    mirC.allowed_voltage_domains = {"hv"};
    catalog.Add(mirC, diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib"), diagnostic);
    return catalog;
}

st::DeviceCatalog makePmosTemplateCatalog()
{
    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    // PMOS 控制管/新增管：孤立阱，验证源衬相连
    auto ctlP = makeMos("ctl_pmos", st::DeviceKind::MosP, "pdkA_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk});
    ctlP.isolated_well = true;
    catalog.Add(ctlP, diagnostic);
    // 镜像 NMOS
    catalog.Add(makeMos("mir_nmos_a", st::DeviceKind::MosN, "pdkA_lib",
                        {"D", "G", "S", "B"},
                        {st::TerminalRole::Drain, st::TerminalRole::Gate,
                         st::TerminalRole::Source, st::TerminalRole::Bulk}),
                diagnostic);
    catalog.Add(makeResistor("res_two_term", "pdkA_lib"), diagnostic);
    return catalog;
}

st::BiasSizing makeSizing()
{
    st::BiasSizing sizing;
    sizing.cascode_parameters = {{"w", "2u"}, {"l", "0.24u"}};
    sizing.element_parameters["P_REF"] = {{"w", "4u"}, {"l", "0.5u"}};
    sizing.element_parameters["P_OUT_N"] = {{"w", "4u"}, {"l", "0.5u"}};
    sizing.element_parameters["N_CAS_REP_N"] = {{"w", "2u"}, {"l", "0.24u"}};
    sizing.element_parameters["N_CTRL_REP_N"] = {{"w", "2u"}, {"l", "0.24u"}};
    sizing.element_parameters["R_REF_N"] = {{"r", "10.05k"}};
    sizing.element_parameters["R_REF_P"] = {{"r", "10.05k"}};
    sizing.element_parameters["N_REF"] = {{"w", "4u"}, {"l", "0.5u"}};
    sizing.element_parameters["N_OUT_P"] = {{"w", "4u"}, {"l", "0.5u"}};
    sizing.element_parameters["P_CAS_REP_P"] = {{"w", "2u"}, {"l", "0.24u"}};
    sizing.element_parameters["P_CTRL_REP_P"] = {{"w", "2u"}, {"l", "0.24u"}};
    sizing.nominal_voltage = 0.8;
    sizing.iq_delta = 4e-6;
    return sizing;
}

st::AutoBiasTemplateRequest makeNmosRequest()
{
    st::AutoBiasTemplateRequest request;
    request.operation_id = "op1";
    request.polarity = st::DeviceKind::MosN;
    request.voltage_domain = "core";
    request.vhigh_net = "AVDD";
    request.vlow_net = "VSS";
    request.original_source_net = "VSRC";
    request.control_gate_net = "G0";
    request.control_master = "ctl_nmos";
    request.cascode_master = "ctl_nmos";
    return request;
}

const st::BiasElementPlan* findElement(const st::AutoBiasTemplateResult& result,
                                       const std::string& name)
{
    for (const auto& element : result.elements) {
        if (element.name == name) return &element;
    }
    return nullptr;
}

std::string netByRole(const st::BiasElementPlan& element,
                      const st::DeviceCatalog& catalog, st::TerminalRole role)
{
    const auto* descriptor = catalog.Find(element.model);
    if (descriptor == nullptr) return "<no-model>";
    const auto found = descriptor->terminal_index.find(role);
    if (found == descriptor->terminal_index.end() ||
        found->second >= element.nets.size()) {
        return "<no-role>";
    }
    return element.nets[found->second];
}

bool netsByRoleAre(const st::BiasElementPlan& element,
                   const st::DeviceCatalog& catalog, const std::string& drain,
                   const std::string& gate, const std::string& source,
                   const std::string& bulk)
{
    return netByRole(element, catalog, st::TerminalRole::Drain) == drain &&
           netByRole(element, catalog, st::TerminalRole::Gate) == gate &&
           netByRole(element, catalog, st::TerminalRole::Source) == source &&
           netByRole(element, catalog, st::TerminalRole::Bulk) == bulk;
}

std::string serialize(const st::AutoBiasTemplateResult& result)
{
    std::ostringstream out;
    out << result.ok << '|' << result.template_id << '|' << result.output_net
        << '|';
    for (const auto& port : result.ports) out << port << ',';
    out << '|';
    for (const auto& element : result.elements) {
        out << element.name << ':' << element.model << '(';
        for (const auto& net : element.nets) out << net << ',';
        out << ')';
        for (const auto& param : element.params) {
            out << param.first << '=' << param.second << ';';
        }
        out << ' ';
    }
    return out.str();
}

bool mentionsForbidden(const st::AutoBiasTemplateResult& result)
{
    const std::string blob = serialize(result);
    return blob.find("IREF") != std::string::npos ||
           blob.find("n18") != std::string::npos ||
           blob.find("p18") != std::string::npos ||
           blob.find("rhrpo") != std::string::npos;
}

bool hasDiag(const st::AutoBiasTemplateResult& result, st::DiagCode code)
{
    for (const auto& diagnostic : result.diagnostics) {
        if (diagnostic.code == code) return true;
    }
    return false;
}

} // namespace

int main()
{
    const auto catalog = makeNmosTemplateCatalog();
    const auto sizing = makeSizing();

    // ---- NMOS 模板精确连接 ----
    const auto nmos = st::BuildAutoBiasTemplate(makeNmosRequest(), sizing, catalog);
    CHECK(nmos.ok, "NMOS 自给电 VBIAS 模板构建成功");
    st::DeviceCatalog resistorWithoutMosLimits;
    st::Diagnostic resistorDiagnostic;
    for (const auto& [name, device] : catalog.Descriptors()) {
        auto copy = device;
        if (copy.kind == st::DeviceKind::Resistor) {
            copy.reliability_complete = false;
            copy.bulk_rule_complete = false;
        }
        resistorWithoutMosLimits.Add(copy, resistorDiagnostic);
    }
    CHECK(st::BuildAutoBiasTemplate(makeNmosRequest(), sizing,
                                    resistorWithoutMosLimits).ok,
          "真实电阻无需MOS的VGS/Bulk声明，实际电阻应力另行复验");
    CHECK(nmos.template_id == "VBIAS_N_CASCODE_AUTO" &&
              nmos.output_net == "VBIAS_N",
          "NMOS 模板身份与输出网络固定");
    CHECK(nmos.ports == std::vector<std::string>(
                            {"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N"}),
          "NMOS 模板端口顺序固定为 VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_N");
    CHECK(nmos.elements.size() == 5, "NMOS 模板恰好五个内部角色");

    {
        auto expanded = catalog;
        st::Diagnostic diagnostic;
        auto stronger = *catalog.Find("mir_pmos_a");
        stronger.master = "zzz_stronger";
        stronger.limits.max_abs_vgs = 9.0;
        stronger.limits.max_abs_vds = 9.0;
        stronger.limits.max_abs_vgb = 9.0;
        expanded.Add(stronger, diagnostic);
        std::vector<st::AutoBiasDevicePlan> plans;
        CHECK(st::SelectAutoBiasDeviceCandidates(makeNmosRequest(), expanded, plans, diagnostic) &&
                  plans.size() == 1 && plans.front().mirror->master == "mir_pmos_a",
              "Device selection binds one compatible fixed pair instead of every PDK combination");
    }
    {
        auto explicitSizing = sizing;
        explicitSizing.mirror_master = "mir_pmos_b";
        explicitSizing.resistor_master = "res_two_term";
        const auto explicitBuilt = st::BuildAutoBiasTemplate(makeNmosRequest(), explicitSizing, catalog);
        const auto* explicitMirror = findElement(explicitBuilt, "P_REF");
        CHECK(explicitBuilt.ok && explicitMirror && explicitMirror->model == "mir_pmos_b",
              "Builder preserves an explicit compatible master without reselecting the default");
        explicitSizing.mirror_master = "mir_pmos_c";
        CHECK(!st::BuildAutoBiasTemplate(makeNmosRequest(), explicitSizing, catalog).ok,
              "Explicit incompatible voltage-domain master is still rejected");
        explicitSizing.mirror_master = "ctl_nmos";
        CHECK(!st::BuildAutoBiasTemplate(makeNmosRequest(), explicitSizing, catalog).ok,
              "Explicit wrong-polarity mirror master is still rejected");
    }
    const auto* pRef = findElement(nmos, "P_REF");
    const auto* rRefN = findElement(nmos, "R_REF_N");
    const auto* pOutN = findElement(nmos, "P_OUT_N");
    const auto* nCasRepN = findElement(nmos, "N_CAS_REP_N");
    const auto* nCtrlRepN = findElement(nmos, "N_CTRL_REP_N");
    CHECK(pRef && rRefN && pOutN && nCasRepN && nCtrlRepN,
          "NMOS 模板五个角色全部存在");
    if (pRef && rRefN && pOutN && nCasRepN && nCtrlRepN) {
        CHECK(pRef->model == "mir_pmos_a",
              "镜像管优先选择与控制管同 PDK Library 的合法器件");
        CHECK(netsByRoleAre(*pRef, catalog, "PBIAS_REF", "PBIAS_REF", "VHIGH",
                            "VHIGH"),
              "P_REF 二极管连接：D=G=PBIAS_REF,S=VHIGH,B=VHIGH（物理顺序打乱仍按角色）");
        CHECK(netByRole(*rRefN, catalog, st::TerminalRole::Positive) ==
                      "PBIAS_REF" &&
              netByRole(*rRefN, catalog, st::TerminalRole::Negative) == "VLOW",
              "R_REF_N 连接 PBIAS_REF 到 VLOW");
        CHECK(netsByRoleAre(*pOutN, catalog, "VBIAS_N", "PBIAS_REF", "VHIGH",
                            "VHIGH"),
              "P_OUT_N 镜像供流：D=VBIAS_N,G=PBIAS_REF,S=VHIGH");
        CHECK(nCasRepN->model == "ctl_nmos" &&
                  netsByRoleAre(*nCasRepN, catalog, "VBIAS_N", "VBIAS_N",
                                "X_REP_N", "VLOW"),
              "N_CAS_REP_N 二极管连接模拟新增 Cascode");
        CHECK(nCtrlRepN->model == "ctl_nmos" &&
                  netsByRoleAre(*nCtrlRepN, catalog, "X_REP_N", "VG_CTRL",
                                "VS_ORIG", "VLOW"),
              "N_CTRL_REP_N 模拟原管：G=VG_CTRL,S=VS_ORIG");
    }

    // ---- 参数按角色写入且经量化 ----
    if (pRef && rRefN) {
        CHECK(pRef->params.count("w") && pRef->params.at("w") == "4u" &&
                  pRef->params.count("l") && pRef->params.at("l") == "0.5u",
              "元素参数按角色名存取，与实例顺序无关");
        CHECK(rRefN->params.count("r") && rRefN->params.at("r") == "10k",
              "电阻值经 PDK 网格量化（10.05k→10k，min=100/grid=100 锚定网格）");
    }

    // ---- 无 IREF / 无硬编码 Cell 名 ----
    CHECK(!mentionsForbidden(nmos),
          "NMOS 模板不含 IREF 端口，也不含 n18/p18/rhrpo 硬编码名");

    // ---- 异型 Cascode：Replica 各自使用 control/cascode master ----
    auto crossRequest = makeNmosRequest();
    crossRequest.cascode_master = "cas_nmos";
    const auto cross = st::BuildAutoBiasTemplate(crossRequest, sizing, catalog);
    const auto* crossCasRep =
        cross.ok ? findElement(cross, "N_CAS_REP_N") : nullptr;
    const auto* crossCtrlRep =
        cross.ok ? findElement(cross, "N_CTRL_REP_N") : nullptr;
    CHECK(cross.ok && crossCasRep && crossCtrlRep &&
              crossCasRep->model == "cas_nmos" &&
              crossCtrlRep->model == "ctl_nmos",
          "异型时 Cascode Replica 用新 master，Control Replica 仍用原 master");

    // ---- PMOS 模板精确连接 ----
    const auto pmosCatalog = makePmosTemplateCatalog();
    st::AutoBiasTemplateRequest pmosRequest;
    pmosRequest.operation_id = "op2";
    pmosRequest.polarity = st::DeviceKind::MosP;
    pmosRequest.voltage_domain = "core";
    pmosRequest.vhigh_net = "AVDD";
    pmosRequest.vlow_net = "VSS";
    pmosRequest.original_source_net = "VSRC_P";
    pmosRequest.control_gate_net = "G0P";
    pmosRequest.control_master = "ctl_pmos";
    pmosRequest.cascode_master = "ctl_pmos";
    const auto pmos =
        st::BuildAutoBiasTemplate(pmosRequest, sizing, pmosCatalog);
    CHECK(pmos.ok, "PMOS 自给电 VBIAS 模板构建成功");
    CHECK(pmos.template_id == "VBIAS_P_CASCODE_AUTO" &&
              pmos.output_net == "VBIAS_P",
          "PMOS 模板身份与输出网络固定");
    CHECK(pmos.ports == std::vector<std::string>(
                            {"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_P"}),
          "PMOS 模板端口顺序固定为 VHIGH,VLOW,VS_ORIG,VG_CTRL,VBIAS_P");
    const auto* rRefP = findElement(pmos, "R_REF_P");
    const auto* nRef = findElement(pmos, "N_REF");
    const auto* pCasRepP = findElement(pmos, "P_CAS_REP_P");
    const auto* pCtrlRepP = findElement(pmos, "P_CTRL_REP_P");
    const auto* nOutP = findElement(pmos, "N_OUT_P");
    CHECK(pmos.elements.size() == 5 && rRefP && nRef && pCasRepP &&
              pCtrlRepP && nOutP,
          "PMOS 模板恰好五个内部角色");
    if (rRefP && nRef && pCasRepP && pCtrlRepP && nOutP) {
        CHECK(netByRole(*rRefP, pmosCatalog, st::TerminalRole::Positive) ==
                      "VHIGH" &&
              netByRole(*rRefP, pmosCatalog, st::TerminalRole::Negative) ==
                      "NBIAS_REF",
              "R_REF_P 连接 VHIGH 到 NBIAS_REF");
        CHECK(nRef->model == "mir_nmos_a" &&
                  netsByRoleAre(*nRef, pmosCatalog, "NBIAS_REF", "NBIAS_REF",
                                "VLOW", "VLOW"),
              "N_REF 二极管连接 NMOS：D=G=NBIAS_REF,S=VLOW");
        CHECK(netsByRoleAre(*pCasRepP, pmosCatalog, "VBIAS_P", "VBIAS_P",
                            "VS_ORIG", "VS_ORIG"),
              "P_CAS_REP_P 孤立阱源衬相连：D=G=VBIAS_P,S=B=VS_ORIG");
        CHECK(netsByRoleAre(*pCtrlRepP, pmosCatalog, "X_REP_P", "VG_CTRL",
                            "VBIAS_P", "VBIAS_P"),
              "P_CTRL_REP_P 模拟原管：G=VG_CTRL,S=B=VBIAS_P");
        CHECK(netsByRoleAre(*nOutP, pmosCatalog, "X_REP_P", "NBIAS_REF",
                            "VLOW", "VLOW"),
              "N_OUT_P 吸流：D=X_REP_P,G=NBIAS_REF,S=VLOW");
    }
    CHECK(!mentionsForbidden(pmos),
          "PMOS 模板不含 IREF 端口，也不含 n18/p18/rhrpo 硬编码名");

    // ---- 换一套 PDK 命名仍按角色选型 ----
    {
        auto renamed = makeNmosTemplateCatalog();
        // 重新构造一份全改名的目录
        st::DeviceCatalog renamedCatalog;
        st::Diagnostic diagnostic;
        renamedCatalog.Add(makeMos("umc_nch_ctl", st::DeviceKind::MosN,
                                   "umc_lib", {"D", "G", "S", "B"},
                                   {st::TerminalRole::Drain,
                                    st::TerminalRole::Gate,
                                    st::TerminalRole::Source,
                                    st::TerminalRole::Bulk}),
                           diagnostic);
        renamedCatalog.Add(makeMos("umc_pch_mir", st::DeviceKind::MosP,
                                   "umc_lib", {"D", "G", "S", "B"},
                                   {st::TerminalRole::Drain,
                                    st::TerminalRole::Gate,
                                    st::TerminalRole::Source,
                                    st::TerminalRole::Bulk}),
                           diagnostic);
        renamedCatalog.Add(makeResistor("umc_rpo", "umc_lib"), diagnostic);
        auto renamedRequest = makeNmosRequest();
        renamedRequest.control_master = "umc_nch_ctl";
        renamedRequest.cascode_master = "umc_nch_ctl";
        const auto rebuilt =
            st::BuildAutoBiasTemplate(renamedRequest, sizing, renamedCatalog);
        const auto* rebuiltRef =
            rebuilt.ok ? findElement(rebuilt, "P_REF") : nullptr;
        const auto* rebuiltR =
            rebuilt.ok ? findElement(rebuilt, "R_REF_N") : nullptr;
        CHECK(rebuilt.ok && rebuiltRef && rebuiltR &&
                  rebuiltRef->model == "umc_pch_mir" &&
                  rebuiltR->model == "umc_rpo" &&
                  netsByRoleAre(*rebuiltRef, renamedCatalog, "PBIAS_REF",
                                "PBIAS_REF", "VHIGH", "VHIGH"),
              "PDK Library/Cell 名整体更换后仍按角色选择合法器件");
    }

    // ---- 结果确定性 ----
    const auto again = st::BuildAutoBiasTemplate(makeNmosRequest(), sizing,
                                                 catalog);
    CHECK(again.ok && serialize(again) == serialize(nmos),
          "同一输入两次构建结果逐字段一致");

    // ---- 拒绝路径 ----
    {
        auto unknown = sizing;
        unknown.element_parameters["P_REF"]["unregistered_cdf"] = "enabled";
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), unknown, catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "未知CDF参数必须拒绝，不能将字符串或数值原样透传");
    }
    {
        auto unknownCascode = sizing;
        unknownCascode.cascode_parameters["unregistered_cascode_cdf"] = "1";
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), unknownCascode, catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "实际新增Cascode参数也必须登记CDF，不能仅校验Replica参数");
    }
    {
        auto outside = sizing;
        outside.element_parameters["P_REF"]["w"] = "100u";
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), outside, catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "显式参数超出真实CDF范围时拒绝，不能静默夹到边界");
    }
    {
        st::DeviceCatalog integerCatalog;
        st::Diagnostic diagnostic;
        for (const auto& [name, descriptor] : catalog.Descriptors()) {
            auto copy = descriptor;
            copy.parameter_constraints["multiplier"] =
                makeConstraint("multiplier", "m", 1.0, 4.0, 1.0);
            copy.parameter_constraints["multiplier"].integer_only = true;
            integerCatalog.Add(copy, diagnostic);
        }
        auto fractional = sizing;
        fractional.element_parameters["P_REF"]["m"] = "1.5";
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), fractional, integerCatalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "真实CDF声明整数类型时拒绝小数输入，不能静默舍入类型错误");
    }
    {
        st::DeviceCatalog conflictCatalog;
        st::Diagnostic diagnostic;
        for (const auto& [name, descriptor] : catalog.Descriptors()) {
            auto copy = descriptor;
            copy.normalized_to_cdf["width"] = "wrong_width_cdf";
            conflictCatalog.Add(copy, diagnostic);
        }
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), sizing, conflictCatalog);
        CHECK(!rejected.ok,
              "语义到CDF映射与登记约束冲突时拒绝选型，不猜正确参数名");
    }
    {
        // Bulk 规则缺失
        auto badCatalog = makeNmosTemplateCatalog();
        st::DeviceCatalog bulkMissing;
        st::Diagnostic diagnostic;
        for (const auto& [name, descriptor] : badCatalog.Descriptors()) {
            auto copy = descriptor;
            if (copy.kind == st::DeviceKind::MosP) copy.bulk_rule_complete = false;
            bulkMissing.Add(copy, diagnostic);
        }
        const auto rejected =
            st::BuildAutoBiasTemplate(makeNmosRequest(), sizing, bulkMissing);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BulkPolicyUnresolved),
              "候选 Bulk/Well 规则缺失时返回 BulkPolicyUnresolved，不默认短接 Source");
    }
    {
        // 目录中没有真实电阻
        st::DeviceCatalog noResistor;
        st::Diagnostic diagnostic;
        noResistor.Add(makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib",
                               {"D", "G", "S", "B"},
                               {st::TerminalRole::Drain, st::TerminalRole::Gate,
                                st::TerminalRole::Source,
                                st::TerminalRole::Bulk}),
                       diagnostic);
        noResistor.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib",
                               {"D", "G", "S", "B"},
                               {st::TerminalRole::Drain, st::TerminalRole::Gate,
                                st::TerminalRole::Source,
                                st::TerminalRole::Bulk}),
                       diagnostic);
        const auto rejected =
            st::BuildAutoBiasTemplate(makeNmosRequest(), sizing, noResistor);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::MissingInput),
              "PDK 扫描不到真实电阻时拒绝生成");
    }
    {
        // 电阻缺少可量化阻值约束
        st::DeviceCatalog badResistor;
        st::Diagnostic diagnostic;
        badResistor.Add(makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib",
                                {"D", "G", "S", "B"},
                                {st::TerminalRole::Drain,
                                 st::TerminalRole::Gate,
                                 st::TerminalRole::Source,
                                 st::TerminalRole::Bulk}),
                        diagnostic);
        badResistor.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib",
                                {"D", "G", "S", "B"},
                                {st::TerminalRole::Drain,
                                 st::TerminalRole::Gate,
                                 st::TerminalRole::Source,
                                 st::TerminalRole::Bulk}),
                        diagnostic);
        auto resistor = makeResistor("res_no_constraint", "pdkA_lib");
        resistor.parameter_constraints.clear();
        badResistor.Add(resistor, diagnostic);
        const auto rejected =
            st::BuildAutoBiasTemplate(makeNmosRequest(), sizing, badResistor);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::MissingInput),
              "电阻缺少可量化参数约束时拒绝生成");
    }
    {
        // “有参数”不等于“有阻值参数”，不能用其他 CDF 约束冒充。
        st::DeviceCatalog wrongConstraint;
        st::Diagnostic diagnostic;
        wrongConstraint.Add(makeMos("ctl_nmos", st::DeviceKind::MosN,
                                    "pdkA_lib", {"D", "G", "S", "B"},
                                    {st::TerminalRole::Drain,
                                     st::TerminalRole::Gate,
                                     st::TerminalRole::Source,
                                     st::TerminalRole::Bulk}),
                            diagnostic);
        wrongConstraint.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP,
                                    "pdkA_lib", {"D", "G", "S", "B"},
                                    {st::TerminalRole::Drain,
                                     st::TerminalRole::Gate,
                                     st::TerminalRole::Source,
                                     st::TerminalRole::Bulk}),
                            diagnostic);
        auto resistor = makeResistor("res_wrong_constraint", "pdkA_lib");
        resistor.parameter_constraints.clear();
        resistor.parameter_constraints["width"] =
            makeConstraint("width", "w", 1e-7, 1e-5, 1e-8);
        wrongConstraint.Add(resistor, diagnostic);
        const auto rejected = st::BuildAutoBiasTemplate(
            makeNmosRequest(), sizing, wrongConstraint);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::MissingInput),
              "电阻必须明确声明可量化 resistance 约束");
    }
    {
        // 控制管可靠性数据不完整
        st::DeviceCatalog unreliable;
        st::Diagnostic diagnostic;
        auto ctl = makeMos("ctl_nmos", st::DeviceKind::MosN, "pdkA_lib",
                           {"D", "G", "S", "B"},
                           {st::TerminalRole::Drain, st::TerminalRole::Gate,
                            st::TerminalRole::Source, st::TerminalRole::Bulk});
        ctl.reliability_complete = false;
        unreliable.Add(ctl, diagnostic);
        unreliable.Add(makeMos("mir_pmos_a", st::DeviceKind::MosP, "pdkA_lib",
                               {"D", "G", "S", "B"},
                               {st::TerminalRole::Drain, st::TerminalRole::Gate,
                                st::TerminalRole::Source,
                                st::TerminalRole::Bulk}),
                       diagnostic);
        unreliable.Add(makeResistor("res_two_term", "pdkA_lib"), diagnostic);
        const auto rejected =
            st::BuildAutoBiasTemplate(makeNmosRequest(), sizing, unreliable);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::MissingInput),
              "控制管可靠性数据不完整时拒绝生成，不猜耐压");
    }
    {
        // 求解参数缺角色
        auto incompleteSizing = makeSizing();
        incompleteSizing.element_parameters.erase("N_CAS_REP_N");
        const auto rejected = st::BuildAutoBiasTemplate(makeNmosRequest(),
                                                        incompleteSizing,
                                                        catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::MissingInput),
              "BiasSizing 缺少任一角色参数时拒绝生成");
    }
    {
        // 数值参数无法解析
        auto badValue = makeSizing();
        badValue.element_parameters["R_REF_N"] = {{"r", "abc"}};
        const auto rejected =
            st::BuildAutoBiasTemplate(makeNmosRequest(), badValue, catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "无法解析为数值的参数按 BadParam 拒绝");
    }
    {
        // 极性非法
        auto badPolarity = makeNmosRequest();
        badPolarity.polarity = st::DeviceKind::Resistor;
        const auto rejected =
            st::BuildAutoBiasTemplate(badPolarity, sizing, catalog);
        CHECK(!rejected.ok && hasDiag(rejected, st::DiagCode::BadParam),
              "模板请求极性不是 NMOS/PMOS 时拒绝");
    }

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Auto bias tests passed\n";
    } else {
        std::cout << failures << " Auto bias tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
