#include "st/Standalone.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                          \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                          \
        }                                                                        \
    } while (false)

std::filesystem::path tempFile(const std::string& name, const std::string& text)
{
    const auto root = std::filesystem::temp_directory_path() / "st_standalone_test";
    std::filesystem::create_directories(root);
    const auto path = root / name;
    std::ofstream output(path);
    output << text;
    return path;
}

} // namespace

int main()
{
    const auto catalogPath = tempFile("catalog.tsv",
        "master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\tcompatible_masters\tmin_width\tmax_width\tmin_length\tmax_length\tmin_resistance\tmax_resistance\tmax_abs_vgs\tmax_abs_vds\tmax_abs_vgb\tmax_stack\tallowed_voltage_domains\tisolated_well\tsource_drain_interchangeable\tpdk_name\tpdk_version\tmodel_name\tw_fin_formula\tparameter_constraints\tmodel_sections\tcorners\treliability_complete\tbulk_rule_complete\n"
        "nsvt\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tnsvt\tsymbol\tcore\tdeprecated_wrong\t1e-7\t1e-3\t1e-7\t1e-5\t0\tinf\t1.2\t1.2\t1.2\t100\tcore,io\ttrue\ttrue\tPDK\t1.0\tnsvt\t\twidth:w:1e-7:1e-3:1e-8:\ttt\tff\ttrue\ttrue\n"
        "nlvt\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tnlvt\tsymbol\tcore\t\t1e-7\t1e-3\t1e-7\t1e-5\t0\tinf\t1.2\t1.2\t1.2\t100\tcore\ttrue\ttrue\tPDK\t1.0\tnlvt\t\twidth:w:1e-7:1e-3:1e-8:\ttt\tff\ttrue\ttrue\n"
        "n_bad\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn_bad\tsymbol\tcore\t\t1e-7\t1e-3\t1e-7\t1e-5\t0\tinf\t1.2\t1.2\t1.2\t100\tcore\ttrue\ttrue\tPDK\t1.0\tn_bad\t\twidth:w:1e-7:1e-3:1e-8:\ttt\tff\tfalse\ttrue\n"
        "child_amp\tsubckt\tIN,OUT\tother,other\tLDO\tchild_amp\tsymbol\tcore\t\t0\tinf\t0\tinf\t0\tinf\tinf\tinf\tinf\t0\tcore\tfalse\tfalse\tPDK\t1.0\tchild_amp\t\t\t\t\tfalse\tfalse\n");

    st::DeviceCatalog catalog;
    std::vector<st::Diagnostic> diagnostics;
    CHECK(st::standalone::LoadDeviceCatalogTsv(catalogPath, catalog, diagnostics),
          "读取后端导出的PDK器件目录");
    CHECK(catalog.Find("nsvt") != nullptr && catalog.Find("nsvt")->isolated_well &&
          catalog.Find("nsvt")->source_drain_interchangeable &&
          catalog.Find("nsvt")->allowed_voltage_domains.count("io") == 1 &&
          catalog.Find("nsvt")->reliability_complete &&
          catalog.Find("nsvt")->parameter_constraints.count("width") == 1 &&
          std::filesystem::exists(catalogPath.parent_path() / "analysis/pdk_catalog.json"),
          "器件目录保留PDK的参数、可靠性、Well、D/S互换和多电压域规则，并输出稳定JSON");

    const std::string constraintHeader =
        "master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\tpdk_name\tpdk_version\tmodel_name\tw_fin_formula\tparameter_constraints\tmodel_sections\tcorners\treliability_complete\tbulk_rule_complete\n";
    const auto invalidIntegerConstraintPath = tempFile("invalid_integer_constraint.tsv",
        constraintHeader +
        "n_bad_integer\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn_bad_integer\tsymbol\tcore\tPDK\t1\tn_bad_integer\t\tfingers:nf:1.5:8:1:\ttt\tff\ttrue\ttrue\n");
    const auto invalidInfiniteConstraintPath = tempFile("invalid_infinite_constraint.tsv",
        constraintHeader +
        "n_bad_infinite\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn_bad_infinite\tsymbol\tcore\tPDK\t1\tn_bad_infinite\t\twidth:w:1:8:inf:\ttt\tff\ttrue\ttrue\n");
    const auto invalidNanConstraintPath = tempFile("invalid_nan_constraint.tsv",
        constraintHeader +
        "n_bad_nan\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn_bad_nan\tsymbol\tcore\tPDK\t1\tn_bad_nan\t\twidth:w:nan:8:1:\ttt\tff\ttrue\ttrue\n");
    st::DeviceCatalog invalidConstraintCatalog;
    diagnostics.clear();
    CHECK(!st::standalone::LoadDeviceCatalogTsv(invalidIntegerConstraintPath,
                                                invalidConstraintCatalog, diagnostics) &&
          !diagnostics.empty() && diagnostics.front().message.find("parameter_constraints") !=
              std::string::npos,
          "TSV明确拒绝integer_only的非整数边界");
    diagnostics.clear();
    CHECK(!st::standalone::LoadDeviceCatalogTsv(invalidInfiniteConstraintPath,
                                                invalidConstraintCatalog, diagnostics) &&
          !diagnostics.empty() && diagnostics.front().message.find("parameter_constraints") !=
              std::string::npos,
          "TSV明确拒绝Inf参数约束元数据");
    diagnostics.clear();
    CHECK(!st::standalone::LoadDeviceCatalogTsv(invalidNanConstraintPath,
                                                invalidConstraintCatalog, diagnostics) &&
          !diagnostics.empty() && diagnostics.front().message.find("parameter_constraints") !=
              std::string::npos,
          "TSV明确拒绝NaN参数约束元数据");

    st::Netlist netlist;
    st::Subckt core;
    core.name = "ldo_core";
    core.instances.push_back({"M0", {"OUT", "CTRL", "VSS", "VSS"},
                              "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    core.instances.push_back({"X1", {"CTRL", "OUT"}, "child_amp", {}});
    core.instances.push_back({"MYSTERY", {"A", "B", "C", "D"}, "unknown", {}});
    netlist.subckts.push_back(core);

    auto inventory = st::standalone::ListDirectMos(netlist, "ldo_core", catalog);
    CHECK(inventory.ok, "核心subckt存在时可以生成MOS清单");
    CHECK(inventory.devices.size() == 1 && inventory.devices[0].instance == "M0",
          "只列当前层已由PDK登记的MOS，不递归子模块也不按名称猜测");
    CHECK(inventory.devices[0].drain_net == "OUT" &&
          inventory.devices[0].gate_net == "CTRL" &&
          inventory.devices[0].source_net == "VSS" &&
          inventory.devices[0].bulk_net == "VSS",
          "清单按真实terminal role输出D/G/S/B网络");
    CHECK(inventory.devices[0].cross_flavor_candidates ==
              std::vector<std::string>({"nlvt"}),
          "清单动态筛选同极性、不同master、同电压域且完整的候选，不读取旧配对字段");
    CHECK(inventory.devices[0].candidate_rejections.count("n_bad") == 1,
          "MOS清单保留动态候选的拒绝原因");
    st::Netlist incompleteMetadataNetlist;
    st::Subckt incompleteMetadataCore;
    incompleteMetadataCore.name = "ldo_core";
    incompleteMetadataCore.instances.push_back({"M_NO_LIMITS", {"OUT", "CTRL", "VSS", "VSS"},
                                                 "n_bad", {{"w", "2u"}, {"l", "240n"}}});
    incompleteMetadataNetlist.subckts.push_back(incompleteMetadataCore);
    const auto incompleteInventory = st::standalone::ListDirectMos(
        incompleteMetadataNetlist, "ldo_core", catalog);
    CHECK(incompleteInventory.ok && incompleteInventory.devices.size() == 1 &&
          incompleteInventory.devices[0].instance == "M_NO_LIMITS",
          "已证明端子角色的当前层MOS即使缺少可靠性资料仍进入可选清单");

    const auto threePinCatalogPath = tempFile("three_pin_catalog.tsv",
        "master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\tvoltage_domain\n"
        "p3\tmos_p\tG,D,S\tgate,drain,source\tPDK3\tp3\tsymbol\tcore\n");
    st::DeviceCatalog threePinCatalog;
    std::vector<st::Diagnostic> threePinDiagnostics;
    CHECK(st::standalone::LoadDeviceCatalogTsv(
              threePinCatalogPath, threePinCatalog, threePinDiagnostics),
          "真实PDK目录可载入仅有D/G/S外部端子的MOS master");
    st::Netlist threePinNetlist;
    st::Subckt threePinCore;
    threePinCore.name = "three_pin_core";
    threePinCore.instances.push_back({"MP3", {"CTRL", "OUT", "VDD"},
                                      "p3", {{"w", "2u"}}});
    threePinNetlist.subckts.push_back(threePinCore);
    const auto threePinInventory = st::standalone::ListDirectMos(
        threePinNetlist, "three_pin_core", threePinCatalog);
    CHECK(threePinInventory.ok && threePinInventory.devices.size() == 1 &&
          threePinInventory.devices[0].instance == "MP3" &&
          threePinInventory.devices[0].drain_net == "OUT" &&
          threePinInventory.devices[0].gate_net == "CTRL" &&
          threePinInventory.devices[0].source_net == "VDD" &&
          threePinInventory.devices[0].bulk_net.empty(),
          "三端MOS进入当前层清单，按PDK端子语义取得D/G/S且不虚构Bulk");
    const auto candidatesJsonPath = tempFile("cross_flavor_candidates.json", "");
    std::string inventoryError;
    CHECK(st::standalone::WriteCrossFlavorCandidatesJson(
              candidatesJsonPath, inventory, inventoryError) &&
          std::filesystem::file_size(candidatesJsonPath) > 0,
          "MOS清单可以输出候选及拒绝原因JSON报告");
    std::ifstream candidatesInput(candidatesJsonPath);
    const std::string candidatesText((std::istreambuf_iterator<char>(candidatesInput)),
                                     std::istreambuf_iterator<char>());
    CHECK(candidatesText ==
              "{\"devices\":[{\"instance\":\"M0\",\"master\":\"nsvt\",\"accepted\":[\"nlvt\"],\"candidate_rejections\":{\"child_amp\":[\"polarity_mismatch\"],\"n_bad\":[\"reliability_incomplete\"]}}]}\n",
          "候选JSON稳定地记录accepted及具体rejection内容和顺序");

    auto missing = st::standalone::ListDirectMos(netlist, "not_a_cell", catalog);
    CHECK(!missing.ok && !missing.diagnostics.empty(),
          "核心subckt不存在时明确失败而不是扫描其他层级");

    const auto legacyManualBiasPath = tempFile("legacy_manual_bias.conf",
        "id=legacy_manual_bias\n"
        "type=same_type_cascode\n"
        "instance=M0\n"
        "gate_policy=fixed\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n"
        "bias.reference_current=2u\n");
    const auto parsed = st::standalone::ParseTransformRequest(
        legacyManualBiasPath, "ldo_core");
    CHECK(!parsed.ok && !parsed.diagnostics.empty() &&
          parsed.diagnostics.front().message.find("自动求解器接管") != std::string::npos,
          "旧的手工Bias字段必须被明确拒绝");

    const auto samePath = tempFile("same.conf",
        "id=op_same\n"
        "type=same_type_cascode\n"
        "instance=M0\n"
        "gate_policy=fixed\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n");
    auto same = st::standalone::ParseTransformRequest(samePath, "ldo_core");
    CHECK(same.ok && same.request.type == st::TransformType::SameTypeCascode,
          "解析同型Cascode操作");
    CHECK(std::get<st::CascodeTransformRequest>(same.request.payload).subckt == "ldo_core" &&
          std::get<st::CascodeTransformRequest>(same.request.payload).gate_policy ==
              st::GatePolicy::FixedBias,
          "Cascode产品路径保持原Gate并登记自动求解意图");
    const auto& samePayload = std::get<st::CascodeTransformRequest>(same.request.payload);
    CHECK(!samePayload.solved_bias.has_value() && !samePayload.bias_template.has_value(),
          "操作文件不再传入模板、工作点或手工Bias值");

    const auto rejectedSharedCascodePath = tempFile("shared_cascode.conf",
        "id=bad_shared\n"
        "type=same_type_cascode\n"
        "instance=M0\n"
        "gate_policy=shared\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n");
    CHECK(!st::standalone::ParseTransformRequest(
              rejectedSharedCascodePath, "ldo_core").ok,
          "产品操作文件拒绝把Cascode新增管直接接原Gate");

    const auto crossPath = tempFile("cross.conf",
        "id=op_cross\n"
        "type=cross_flavor_cascode\n"
        "instance=M0\n"
        "new_master=nlvt\n"
        "gate_policy=fixed\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n");
    auto cross = st::standalone::ParseTransformRequest(crossPath, "ldo_core");
    CHECK(cross.ok && cross.request.type == st::TransformType::CrossFlavorCascode,
          "解析不含手工Bias输入的跨Flavor Cascode");
    const auto& crossPayload = std::get<st::CascodeTransformRequest>(cross.request.payload);
    CHECK(!crossPayload.solved_bias.has_value() && !crossPayload.bias_template.has_value(),
          "跨Flavor Cascode把Bias求解留给自动求解器");

    const auto forbiddenBiasDevicePath = tempFile("forbidden_bias_device.conf",
        "id=bad_bias_device\n"
        "type=same_type_cascode\n"
        "instance=M0\n"
        "gate_policy=fixed\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n"
        "bias.element.1.model=user_chosen_mos\n");
    CHECK(!st::standalone::ParseTransformRequest(
              forbiddenBiasDevicePath, "ldo_core").ok,
          "用户不能指定VBIAS模板内部MOS，必须由工具从PDK目录自动选择");

    const auto resistorPath = tempFile("resistor.conf",
        "id=op_r\n"
        "type=resistor\n"
        "instance=M0\n"
        "resistor.master=r2_pdk\n"
        "resistor.parameter=r\n"
        "resistor.value=2k\n"
        "resistor.grid=0.5\n"
        "resistor.min=1\n"
        "resistor.max=1000000\n");
    auto resistor = st::standalone::ParseTransformRequest(resistorPath, "ldo_core");
    CHECK(resistor.ok && resistor.request.type == st::TransformType::AddSourceResistor,
          "解析MOS Source串联电阻操作");
    CHECK(std::get<st::ResistorTransformRequest>(resistor.request.payload)
              .requested_resistance == std::optional<double>(2000.0),
          "用户填写的电阻值作为最高优先级可选值");

    const auto defaultResistorPath = tempFile("resistor_default.conf",
        "id=op_r_default\n"
        "type=resistor\n"
        "instance=M0\n"
        "resistor.master=r2_pdk\n");
    const auto defaultResistor = st::standalone::ParseTransformRequest(
        defaultResistorPath, "ldo_core");
    CHECK(defaultResistor.ok &&
          !std::get<st::ResistorTransformRequest>(defaultResistor.request.payload)
                  .requested_resistance.has_value() &&
          !std::get<st::ResistorTransformRequest>(defaultResistor.request.payload)
                  .case_default_resistance.has_value(),
          "用户和Case都未填阻值时保留缺省，由变换层使用PDK中间值");

    const auto caseResistorPath = tempFile("resistor_case.conf",
        "id=op_r_case\n"
        "type=resistor\n"
        "instance=M0\n"
        "resistor.master=r2_pdk\n"
        "resistor.case_default=5k\n");
    const auto caseResistor = st::standalone::ParseTransformRequest(
        caseResistorPath, "ldo_core");
    CHECK(caseResistor.ok &&
          std::get<st::ResistorTransformRequest>(caseResistor.request.payload)
                  .case_default_resistance == std::optional<double>(5000.0),
          "操作文件可登记次优先级的Case预置阻值");

    const auto stackPath = tempFile("stack.conf",
        "id=op_stack\n"
        "type=stack\n"
        "instance=M0\n"
        "stage_count=3\n"
        "gate_policy=shared\n"
        "intent=effective_length\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n");
    auto stack = st::standalone::ParseTransformRequest(stackPath, "ldo_core");
    CHECK(stack.ok && stack.request.type == st::TransformType::MosStack &&
          std::get<st::StackTransformRequest>(stack.request.payload).stage_count == 3,
          "解析2到100级共享栅Stack操作");

    const auto rejectedStagedPath = tempFile("stack_staged.conf",
        "id=bad_stack\n"
        "type=stack\n"
        "instance=M0\n"
        "stage_count=3\n"
        "gate_policy=staged\n"
        "voltage_domain=core\n"
        "nmos_bulk_net=VSS\n");
    CHECK(!st::standalone::ParseTransformRequest(rejectedStagedPath, "ldo_core").ok,
          "产品操作文件只允许Stack所有级共享原Gate");

    const auto invalidPath = tempFile("invalid.conf",
        "id=bad\n"
        "type=resistor\n"
        "instance=M0\n");
    auto invalid = st::standalone::ParseTransformRequest(invalidPath, "ldo_core");
    CHECK(!invalid.ok && !invalid.diagnostics.empty(),
          "缺少PDK电阻master时拒绝MOS Source串联电阻操作");

    const auto geometryPath = tempFile("geometry.tsv",
        "instance\tx\ty\torientation\tcell_left\tcell_bottom\tcell_right\tcell_top\n"
        "M0\t10\t20\tR0\t-50\t-40\t100\t80\n"
        "X1\t30\t40\tR0\t-50\t-40\t100\t80\n");
    st::standalone::RootGeometry geometry;
    diagnostics.clear();
    CHECK(st::standalone::LoadRootGeometryTsv(geometryPath, geometry, diagnostics),
          "读取核心cell当前层实例坐标");

    st::StackTransformRequest stackRequest;
    stackRequest.subckt = "ldo_core";
    stackRequest.target = "M0";
    stackRequest.stage_count = 3;
    stackRequest.gate_policy = st::GatePolicy::SharedGate;
    stackRequest.voltage_domain = "core";
    stackRequest.nmos_bulk_net = "VSS";
    auto stackPlan = st::planStack(netlist, stackRequest, catalog);
    st::Netlist stackVariant = netlist;
    auto stackOutcome = st::materializeStack(stackVariant, stackPlan.stack, catalog);
    CHECK(stackPlan.ok() && stackOutcome.ok(), "构造三级Stack期望网表用于OA计划");

    const st::CellViewRef source{"SRC", "ldo_core", "schematic", "/project", "r1"};
    const st::CellViewRef staging{"STAGING", "ldo_core__TV0001_STAGING", "schematic",
                                  "/project", "r1"};
    const st::PreviewIdentity preview{"TV0001", "initial", "standalone-v1"};
    auto context = st::standalone::BuildRootOaContext(
        netlist, stackVariant, "ldo_core", source, staging, geometry, preview);
    CHECK(context.ok && context.context.clone_map.size() == 1 &&
          context.context.clone_map[0].hierarchy_path == "/",
          "OA上下文只克隆用户选择的核心cell，不递归子模块");
    const auto originalLocation = geometry.instance_locations.at("M0");
    const auto retainedLocation = context.context.locations.at("/:M0");
    const auto stackLocation1 = context.context.locations.at("/:M0_S1");
    const auto stackLocation2 = context.context.locations.at("/:M0_S2");
    CHECK((retainedLocation.x != originalLocation.x ||
           retainedLocation.y != originalLocation.y) &&
          (stackLocation1.x != retainedLocation.x ||
           stackLocation1.y != retainedLocation.y) &&
          (stackLocation2.x != stackLocation1.x ||
           stackLocation2.y != stackLocation1.y),
          "Drain侧原实例和新增Stack器件在OA重建时使用不冲突的新坐标");
    auto oaPlan = st::BuildOaMaterializationPlan(
        netlist, stackVariant, catalog, context.context);
    CHECK(oaPlan.ok() && oaPlan.plan.delete_instances.size() == 1 &&
          oaPlan.plan.create_instances.size() == 3,
          "三级Stack生成删除一只原MOS并创建三只MOS的合法OA计划");
    CHECK(!oaPlan.plan.wires.empty(),
          "每个新增器件端子网络都有确定性的可见标签导线");

    auto cascodeVariant = netlist;
    cascodeVariant.find("ldo_core")->find("M0")->nets[0] = "M0_MID";
    cascodeVariant.find("ldo_core")->instances.push_back(
        {"M0_CAS", {"OUT", "CTRL", "M0_MID", "VSS"}, "nsvt",
         {{"w", "2u"}, {"l", "240n"}}});
    auto cascodeContext = st::standalone::BuildRootOaContext(
        netlist, cascodeVariant, "ldo_core", source, staging, geometry, preview);
    const auto cascodeRecreated = cascodeContext.context.locations.at("/:M0");
    const auto cascodeAdded = cascodeContext.context.locations.at("/:M0_CAS");
    CHECK(cascodeContext.ok &&
          cascodeRecreated.x > 100.0 && cascodeAdded.x > 100.0 &&
          (cascodeRecreated.x != cascodeAdded.x || cascodeRecreated.y != cascodeAdded.y),
          "Cascode重建器件进入整个原理图边界右侧的独立区域而不是固定偏移");

    auto multiBase = netlist;
    multiBase.find("ldo_core")->instances.insert(
        multiBase.find("ldo_core")->instances.begin() + 1,
        {"M1", {"OUT2", "CTRL2", "VSS", "VSS"}, "nsvt",
         {{"w", "3u"}, {"l", "240n"}}});
    auto multiVariant = multiBase;
    multiVariant.find("ldo_core")->find("M0")->nets[0] = "M0_MID";
    multiVariant.find("ldo_core")->find("M1")->nets[0] = "M1_MID";
    multiVariant.find("ldo_core")->instances.push_back(
        {"M0_CAS", {"OUT", "CTRL", "M0_MID", "VSS"}, "nsvt",
         {{"w", "2u"}, {"l", "240n"}}});
    multiVariant.find("ldo_core")->instances.push_back(
        {"M1_CAS", {"OUT2", "CTRL2", "M1_MID", "VSS"}, "nsvt",
         {{"w", "3u"}, {"l", "240n"}}});
    auto multiGeometry = geometry;
    multiGeometry.instance_locations["M1"] = {20.0, 30.0};
    auto multiContext = st::standalone::BuildRootOaContext(
        multiBase, multiVariant, "ldo_core", source, staging, multiGeometry, preview);
    std::set<std::pair<double, double>> occupiedLocations;
    bool allOutsideOriginal = multiContext.ok;
    for (const auto* name : {"M0", "M1", "M0_CAS", "M1_CAS"}) {
        const auto location = multiContext.context.locations.find(std::string("/:") + name);
        if (location == multiContext.context.locations.end()) {
            allOutsideOriginal = false;
            continue;
        }
        allOutsideOriginal = allOutsideOriginal && location->second.x > 100.0;
        occupiedLocations.emplace(location->second.x, location->second.y);
    }
    CHECK(allOutsideOriginal && occupiedLocations.size() == 4,
          "同一Change Set连续修改多只MOS时所有重建和新增器件使用全局唯一隔离位置");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Standalone tests passed\n";
    } else {
        std::cout << failures << " standalone tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
