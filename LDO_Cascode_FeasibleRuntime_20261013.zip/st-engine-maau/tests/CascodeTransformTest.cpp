#include "st/AutoBias.h"
#include "st/DcSolver.h"
#include "st/Transform.h"
#include "st/PdkCatalog.h"

#include <iostream>
#include <map>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::DeviceDescriptor mos(std::string master, st::DeviceKind kind,
                         std::string library = "logic", bool fixed = false)
{
    st::DeviceDescriptor descriptor;
    descriptor.master = std::move(master);
    descriptor.kind = kind;
    descriptor.terminal_count = 4;
    // 故意使用 B/S/G/D，证明变换按端子语义而不是位置猜测。
    descriptor.terminal_index = {
        {st::TerminalRole::Bulk, 0},
        {st::TerminalRole::Source, 1},
        {st::TerminalRole::Gate, 2},
        {st::TerminalRole::Drain, 3},
    };
    descriptor.terminal_names_by_index = {"B", "S", "G", "D"};
    descriptor.terminal_roles_by_index = {
        st::TerminalRole::Bulk, st::TerminalRole::Source,
        st::TerminalRole::Gate, st::TerminalRole::Drain,
    };
    if (!fixed) {
        descriptor.normalized_to_cdf = {
            {"width", "w"}, {"length", "l"}, {"fingers", "nf"},
        };
    }
    descriptor.oa_library = std::move(library);
    descriptor.oa_cell = descriptor.master;
    descriptor.oa_view = "symbol";
    descriptor.device_family = kind == st::DeviceKind::MosN
        ? "fake_core_nmos" : "fake_core_pmos";
    descriptor.flavor_id = descriptor.master;
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains.insert("core");
    descriptor.limits.min_width = 100e-9;
    descriptor.limits.max_width = 100e-6;
    descriptor.limits.min_length = 100e-9;
    descriptor.limits.max_length = 10e-6;
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.parameter_constraints["width"] =
        {"width", "w", 100e-9, 100e-6, 10e-9, {}, false};
    descriptor.parameter_constraints["length"] =
        {"length", "l", 100e-9, 10e-6, 10e-9, {}, false};
    descriptor.parameter_constraints["fingers"] =
        {"fingers", "nf", 1.0, 100.0, 1.0, {}, true};
    return descriptor;
}

st::DeviceDescriptor resistor()
{
    st::DeviceDescriptor descriptor;
    descriptor.master = "r2";
    descriptor.kind = st::DeviceKind::Resistor;
    descriptor.terminal_count = 2;
    descriptor.terminal_index = {
        {st::TerminalRole::Positive, 0},
        {st::TerminalRole::Negative, 1},
    };
    descriptor.terminal_names_by_index = {"P", "N"};
    descriptor.terminal_roles_by_index = {st::TerminalRole::Positive,
                                          st::TerminalRole::Negative};
    descriptor.normalized_to_cdf = {{"resistance", "r"}};
    descriptor.oa_library = "logic";
    descriptor.oa_cell = "r2";
    descriptor.oa_view = "symbol";
    descriptor.voltage_domain = "core";
    descriptor.allowed_voltage_domains.insert("core");
    descriptor.reliability_complete = true;
    descriptor.bulk_rule_complete = true;
    descriptor.parameter_constraints["resistance"] =
        {"resistance", "r", 1.0, 1e9, 1.0, {}, false};
    return descriptor;
}

st::DeviceCatalog catalog()
{
    st::DeviceCatalog result;
    st::Diagnostic diagnostic;
    result.Add(mos("nsvt", st::DeviceKind::MosN), diagnostic);
    auto nlvt = mos("nlvt", st::DeviceKind::MosN);
    nlvt.normalized_to_cdf = {
        {"width", "wf"}, {"length", "lg"}, {"fingers", "nfin"},
    };
    nlvt.parameter_constraints["width"].cdf_name = "wf";
    nlvt.parameter_constraints["length"].cdf_name = "lg";
    nlvt.parameter_constraints["fingers"].cdf_name = "nfin";
    result.Add(nlvt, diagnostic);
    result.Add(mos("psvt", st::DeviceKind::MosP), diagnostic);
    result.Add(resistor(), diagnostic);
    return result;
}

st::Netlist nmosCircuit()
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "core";
    core.pins = {"AVDD", "AGND", "IREF_P"};
    core.instances.push_back({"M0", {"AGND", "SOURCE", "CTRL", "OUT"}, "nsvt",
        {{"w", "2u"}, {"l", "240n"}, {"nf", "4"}}});
    netlist.subckts.push_back(core);
    return netlist;
}

st::Netlist pmosCircuit()
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "core";
    core.pins = {"AVDD", "AGND", "IREF_N"};
    core.instances.push_back({"P0", {"AVDD", "AVDD", "PCTRL", "POUT"}, "psvt",
        {{"w", "4u"}, {"l", "240n"}, {"nf", "4"}}});
    netlist.subckts.push_back(core);
    return netlist;
}

// 手工构造一份"求解器已经跑完"的结果：参数即 Task 6 会填入的量化值。
st::AutoBiasSolveResult solved(const st::BiasSizing& sizing)
{
    st::AutoBiasSolveResult result;
    result.ok = true;
    result.sizing = sizing;
    return result;
}

st::CascodeTransformRequest nmosRequest(
    const st::DeviceCatalog& devices,
    const std::string& controlMaster = "nsvt",
    const std::string& cascodeMaster = "nsvt",
    const std::map<std::string, std::string>& cascodeParams =
        {{"w", "2u"}, {"l", "240n"}, {"nf", "4"}})
{
    st::CascodeTransformRequest request;
    request.subckt = "core";
    request.target = "M0";
    request.gate_policy = st::GatePolicy::FixedBias;
    request.nmos_bulk_net = "AGND";
    request.voltage_domain = "core";
    request.vbias_vhigh_net = "AVDD";
    request.vbias_vlow_net = "AGND";

    st::BiasSizing sizing;
    sizing.mirror_master = "psvt";
    sizing.resistor_master = "r2";
    sizing.cascode_parameters = cascodeParams;
    sizing.element_parameters["P_REF"] = {{"w", "2u"}, {"l", "240n"}, {"nf", "1"}};
    sizing.element_parameters["R_REF_N"] = {{"r", "10k"}};
    sizing.element_parameters["P_OUT_N"] = {{"w", "2u"}, {"l", "240n"}, {"nf", "2"}};
    sizing.element_parameters["N_CAS_REP_N"] = cascodeParams;
    sizing.element_parameters["N_CTRL_REP_N"] = controlMaster == "nfixed"
        ? std::map<std::string, std::string>{}
        : std::map<std::string, std::string>{{"w", "2u"}, {"l", "240n"}, {"nf", "4"}};
    sizing.nominal_voltage = 0.81;
    sizing.iq_delta = 4e-6;
    request.solved_bias = solved(sizing);

    st::AutoBiasTemplateRequest templateRequest;
    templateRequest.operation_id = "op_nmos";
    templateRequest.polarity = st::DeviceKind::MosN;
    templateRequest.voltage_domain = "core";
    templateRequest.vhigh_net = "AVDD";
    templateRequest.vlow_net = "AGND";
    templateRequest.original_source_net = "SOURCE";
    templateRequest.control_gate_net = "CTRL";
    templateRequest.control_master = controlMaster;
    templateRequest.cascode_master = cascodeMaster;
    request.bias_template = st::BuildAutoBiasTemplate(templateRequest, sizing, devices);
    return request;
}

st::CascodeTransformRequest pmosRequest(const st::DeviceCatalog& devices)
{
    st::CascodeTransformRequest request;
    request.subckt = "core";
    request.target = "P0";
    request.gate_policy = st::GatePolicy::FixedBias;
    request.voltage_domain = "core";
    request.vbias_vhigh_net = "AVDD";
    request.vbias_vlow_net = "AGND";

    st::BiasSizing sizing;
    sizing.mirror_master = "nsvt";
    sizing.resistor_master = "r2";
    sizing.cascode_parameters = {{"w", "4u"}, {"l", "240n"}, {"nf", "4"}};
    sizing.element_parameters["R_REF_P"] = {{"r", "10k"}};
    sizing.element_parameters["N_REF"] = {{"w", "2u"}, {"l", "240n"}, {"nf", "1"}};
    sizing.element_parameters["P_CAS_REP_P"] = sizing.cascode_parameters;
    sizing.element_parameters["P_CTRL_REP_P"] = sizing.cascode_parameters;
    sizing.element_parameters["N_OUT_P"] = {{"w", "2u"}, {"l", "240n"}, {"nf", "2"}};
    sizing.nominal_voltage = 0.42;
    sizing.iq_delta = 3e-6;
    request.solved_bias = solved(sizing);

    st::AutoBiasTemplateRequest templateRequest;
    templateRequest.operation_id = "op_pmos";
    templateRequest.polarity = st::DeviceKind::MosP;
    templateRequest.voltage_domain = "core";
    templateRequest.vhigh_net = "AVDD";
    templateRequest.vlow_net = "AGND";
    templateRequest.original_source_net = "AVDD";
    templateRequest.control_gate_net = "PCTRL";
    templateRequest.control_master = "psvt";
    templateRequest.cascode_master = "psvt";
    request.bias_template = st::BuildAutoBiasTemplate(templateRequest, sizing, devices);
    return request;
}

} // namespace

int main()
{
    const auto devices = catalog();

    auto nmos = nmosCircuit();
    const auto nmosResult = st::applyCascode(nmos, nmosRequest(devices), devices);
    auto* nmosCore = nmos.find("core");
    auto* nmosOriginal = nmosCore->find("M0");
    auto* nmosCascode = nmosCore->find("M0_CAS");
    CHECK(nmosResult.ok() && nmosOriginal && nmosCascode,
        "NMOS Cascode消费自动求解器给出的VBIAS结果");
    CHECK(nmosOriginal && nmosOriginal->nets ==
            std::vector<std::string>({"AGND", "SOURCE", "CTRL", "M0_MID"}),
        "NMOS原管保持Source/Gate/Bulk，Drain改接中间节点");
    CHECK(nmosCascode && nmosCascode->nets ==
            std::vector<std::string>({"AGND", "M0_MID", "VBIAS_N_M0", "OUT"}),
        "NMOS新管位于原Drain侧，Gate接模板输出网");
    const std::map<std::string, std::string> expectedCascodeParams =
        {{"w", "2u"}, {"l", "240n"}, {"nf", "4"}};
    CHECK(nmosCascode && nmosCascode->params == expectedCascodeParams,
        "新增管使用求解器量化后的cascode_parameters");
    const auto* nmosBiasInstance = nmosCore->find("I_VBIAS_N_M0");
    CHECK(nmosBiasInstance != nullptr &&
            nmosBiasInstance->model == "VBIAS_N_CASCODE_AUTO_M0" &&
            nmosBiasInstance->nets ==
                std::vector<std::string>({"AVDD", "AGND", "SOURCE", "CTRL", "VBIAS_N_M0"}),
        "父层只有一个VBIAS模板层级实例，VHIGH/VLOW/VS_ORIG/VG_CTRL接真实父层网");
    CHECK(nmosCore->find("P_REF") == nullptr && nmosCore->find("R_REF_N") == nullptr &&
            nmosCore->find("N_CTRL_REP_N") == nullptr,
        "模板五角色不散落在父层电路里");
    const auto* nmosBiasSubckt = nmos.find("VBIAS_N_CASCODE_AUTO_M0");
    CHECK(nmosBiasSubckt != nullptr &&
            nmosBiasSubckt->pins ==
                std::vector<std::string>({"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N"}) &&
            nmosBiasSubckt->instances.size() == 5,
        "模板以独立subckt存在，固定五端口五角色");
    CHECK(nmosBiasSubckt != nullptr &&
            nmosBiasSubckt->find("P_REF") != nullptr &&
            nmosBiasSubckt->find("P_REF")->params.at("nf") == "1",
        "模板角色携带求解器量化参数");
    CHECK(nmosResult.bias_instances == std::vector<std::string>({"I_VBIAS_N_M0"}) &&
            nmosResult.addedInstances == std::vector<std::string>({"M0_CAS"}),
        "bias实例独立报告，不混入功能封装分组");
    CHECK(nmosResult.iq_delta == 4e-6,
        "自动VBIAS的参考和输出支路计入IQ");

    auto missingSolve = nmosCircuit();
    auto missingSolveRequest = nmosRequest(devices);
    missingSolveRequest.solved_bias.reset();
    const std::string missingSolveBefore = st::emitSpectre(missingSolve);
    const auto missingSolveResult = st::applyCascode(
        missingSolve, missingSolveRequest, devices);
    CHECK(!missingSolveResult.ok() &&
            missingSolveResult.diags[0].code == st::DiagCode::BiasUnavailable &&
            st::emitSpectre(missingSolve) == missingSolveBefore,
        "FixedBias缺少求解结果时拒绝且不留下半个变换");

    auto missingTemplate = nmosCircuit();
    auto missingTemplateRequest = nmosRequest(devices);
    missingTemplateRequest.bias_template.reset();
    const std::string missingTemplateBefore = st::emitSpectre(missingTemplate);
    const auto missingTemplateResult = st::applyCascode(
        missingTemplate, missingTemplateRequest, devices);
    CHECK(!missingTemplateResult.ok() &&
            missingTemplateResult.diags[0].code == st::DiagCode::BiasUnavailable &&
            st::emitSpectre(missingTemplate) == missingTemplateBefore,
        "FixedBias缺少模板构建结果时拒绝");

    auto missingRails = nmosCircuit();
    auto missingRailsRequest = nmosRequest(devices);
    missingRailsRequest.vbias_vhigh_net.clear();
    const auto missingRailsResult = st::applyCascode(
        missingRails, missingRailsRequest, devices);
    CHECK(!missingRailsResult.ok() &&
            missingRailsResult.diags[0].code == st::DiagCode::BiasUnavailable,
        "FixedBias缺少模板电源轨父层网时拒绝");

    auto collidingOutput = nmosCircuit();
    collidingOutput.find("core")->instances.push_back(
        {"M_EXISTING_BIAS", {"AGND", "SOURCE", "CTRL", "VBIAS_N_M0"}, "nsvt",
         {{"w", "2u"}, {"l", "240n"}, {"nf", "4"}}});
    const std::string collidingBefore = st::emitSpectre(collidingOutput);
    const auto collidingResult = st::applyCascode(
        collidingOutput, nmosRequest(devices), devices);
    CHECK(!collidingResult.ok() &&
            collidingResult.diags[0].code == st::DiagCode::TargetConflict &&
            st::emitSpectre(collidingOutput) == collidingBefore,
        "FixedBias拒绝复用原电路已经存在的Bias输出网络");

    auto pmos = pmosCircuit();
    const auto pmosResult = st::applyCascode(pmos, pmosRequest(devices), devices);
    auto* pmosCore = pmos.find("core");
    auto* pmosOriginal = pmosCore->find("P0");
    auto* pmosCascode = pmosCore->find("P0_CAS");
    CHECK(pmosResult.ok() && pmosOriginal && pmosCascode,
        "PMOS Cascode消费自动求解器给出的VBIAS结果");
    CHECK(pmosOriginal && pmosOriginal->nets ==
            std::vector<std::string>({"AVDD", "P0_MID", "PCTRL", "POUT"}),
        "PMOS原管保持Drain/Gate/Bulk，Source改接中间节点");
    CHECK(pmosCascode && pmosCascode->nets ==
            std::vector<std::string>({"AVDD", "AVDD", "VBIAS_P_P0", "P0_MID"}),
        "PMOS新管放在原Source侧（原理图上方）");
    const auto* pmosBiasInstance = pmosCore->find("I_VBIAS_P_P0");
    CHECK(pmosBiasInstance != nullptr &&
            pmosBiasInstance->model == "VBIAS_P_CASCODE_AUTO_P0" &&
            pmosBiasInstance->nets ==
                std::vector<std::string>({"AVDD", "AGND", "AVDD", "PCTRL", "VBIAS_P_P0"}),
        "PMOS模板实例的VS_ORIG接变换前原Source网，不被改写到中间节点");
    const auto* pmosBiasSubckt = pmos.find("VBIAS_P_CASCODE_AUTO_P0");
    CHECK(pmosBiasSubckt != nullptr && pmosBiasSubckt->instances.size() == 5 &&
            pmosCore->find("N_REF") == nullptr,
        "PMOS模板五角色同样只存在于独立subckt");
    CHECK(pmosResult.iq_delta == 3e-6, "PMOS自动VBIAS计入IQ");

    auto shared = nmosCircuit();
    auto sharedRequest = nmosRequest(devices);
    sharedRequest.gate_policy = st::GatePolicy::SharedGate;
    sharedRequest.solved_bias.reset();
    sharedRequest.bias_template.reset();
    const auto sharedResult = st::applyCascode(shared, sharedRequest, devices);
    CHECK(sharedResult.ok() && shared.find("core")->find("M0_CAS")->nets[2] == "CTRL" &&
            sharedResult.bias_instances.empty(),
        "共栅Cascode保持两管Gate短接，不需要也不生成VBIAS");

    auto crossFlavor = nmosCircuit();
    auto crossRequest = nmosRequest(devices, "nsvt", "nlvt",
        {{"wf", "2u"}, {"lg", "240n"}, {"nfin", "4"}});
    crossRequest.new_master = "nlvt";
    const auto crossResult = st::applyCascode(crossFlavor, crossRequest, devices);
    auto* crossCascode = crossFlavor.find("core")->find("M0_CAS");
    CHECK(crossResult.ok() && crossCascode && crossCascode->model == "nlvt",
        "异型Cascode执行接受动态PDK目录中的合法同极性目标，不依赖旧兼容表");
    CHECK(crossCascode && crossCascode->params.at("wf") == "2u" &&
            crossCascode->params.at("lg") == "240n" &&
            crossCascode->params.at("nfin") == "4",
        "异型新增管使用求解器按目标master语义量化的参数");
    CHECK(crossFlavor.find("VBIAS_N_CASCODE_AUTO_M0") != nullptr &&
            crossFlavor.find("VBIAS_N_CASCODE_AUTO_M0")->find("N_CAS_REP_N")->model == "nlvt",
        "异型Cascode的模板Replica跟随新增管master");

    st::DeviceCatalog fixedCatalog = catalog();
    st::Diagnostic diagnostic;
    auto nfixed = mos("nfixed", st::DeviceKind::MosN, "logic", true);
    fixedCatalog.Add(nfixed, diagnostic);
    fixedCatalog.Add(mos("nfixed_hv", st::DeviceKind::MosN, "logic", true), diagnostic);
    auto fixedCircuit = nmosCircuit();
    fixedCircuit.find("core")->find("M0")->model = "nfixed";
    fixedCircuit.find("core")->find("M0")->params.clear();
    auto fixedRequest = nmosRequest(fixedCatalog, "nfixed", "nfixed_hv", {});
    fixedRequest.new_master = "nfixed_hv";
    const auto fixedResult = st::applyCascode(fixedCircuit, fixedRequest, fixedCatalog);
    CHECK(fixedResult.ok() &&
            fixedCircuit.find("core")->find("M0_CAS")->model == "nfixed_hv" &&
            fixedCircuit.find("core")->find("M0_CAS")->params.empty(),
        "尺寸编码在master名中的异型MOS不虚构W/L参数");

    auto wrongPolarity = nmosCircuit();
    auto wrongPolarityRequest = nmosRequest(devices);
    wrongPolarityRequest.new_master = "psvt";
    const auto wrongPolarityResult = st::applyCascode(
        wrongPolarity, wrongPolarityRequest, devices);
    CHECK(!wrongPolarityResult.ok() &&
            wrongPolarityResult.diags[0].code == st::DiagCode::PolarityMismatch,
        "异型只允许同极性，不允许N上加P或P上加N");

    auto legacyOnlyCatalog = catalog();
    auto legacyOriginal = *legacyOnlyCatalog.Find("nsvt");
    legacyOriginal.compatible_masters.insert("n_legacy_only");
    auto legacyOnly = mos("n_legacy_only", st::DeviceKind::MosN);
    legacyOnly.reliability_complete = false;
    legacyOnlyCatalog.Add(legacyOriginal, diagnostic);
    legacyOnlyCatalog.Add(legacyOnly, diagnostic);
    auto legacyOnlyCircuit = nmosCircuit();
    auto legacyOnlyRequest = nmosRequest(legacyOnlyCatalog);
    legacyOnlyRequest.new_master = "n_legacy_only";
    const auto legacyOnlyResult = st::applyCascode(
        legacyOnlyCircuit, legacyOnlyRequest, legacyOnlyCatalog);
    CHECK(!legacyOnlyResult.ok() &&
            legacyOnlyResult.diags[0].code == st::DiagCode::DeviceIncompatible,
        "旧兼容表列出但动态可靠性元数据不完整的目标必须拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Cascode transform tests passed\n";
    } else {
        std::cout << failures << " Cascode transform tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
