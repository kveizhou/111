#include "st/VariantVerifier.h"

#include <algorithm>
#include <iostream>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                           \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                           \
        }                                                                        \
    } while (false)

st::Netlist baseline()
{
    st::Netlist netlist;
    st::Subckt core;
    core.name = "core";
    core.pins = { "OUT", "CTRL", "SOURCE", "VSS" };
    core.instances.push_back({ "M0", { "OUT", "CTRL", "SOURCE", "VSS" },
        "nsvt", { { "w", "2u" }, { "l", "240n" } } });
    core.instances.push_back({ "KEEP", { "CTRL", "VSS" }, "r2", { { "r", "1k" } } });
    netlist.subckts.push_back(core);
    return netlist;
}

st::Netlist expected()
{
    auto netlist = baseline();
    auto* core = netlist.find("core");
    core->find("M0")->nets[0] = "M0_MID";
    core->instances.push_back({ "M0_CAS", { "OUT", "VBIAS", "M0_MID", "VSS" },
        "nsvt", { { "w", "2u" }, { "l", "240n" } } });
    core->pins.push_back("VBIAS");
    return netlist;
}

} // namespace

int main()
{
    const auto base = baseline();
    const auto wanted = expected();

    auto actual = wanted;
    // OA/netlister允许改变实例输出顺序，并可能增加求值后的派生参数；
    // subckt pin 是位置端口，顺序不能改变。
    auto* actualCore = actual.find("core");
    std::reverse(actualCore->instances.begin(), actualCore->instances.end());
    actualCore->find("M0_CAS")->params["ad"] = "1p";
    st::VariantVerificationPolicy derivedParameterPolicy;
    derivedParameterPolicy.allowed_extra_instance_parameters.insert("ad");
    auto pass = st::VerifyVariantRoundTrip(base, wanted, actual, derivedParameterPolicy);
    CHECK(pass.ok && pass.ready_for_sizing,
        "实例顺序变化和额外派生参数不影响已要求结构/参数的验证");
    CHECK(pass.expected_topology_hash == pass.actual_topology_hash,
        "等价连接得到相同的顺序无关Topology hash");

    auto resistorWanted = wanted;
    resistorWanted.find("core")->instances.push_back({"NEW_R", {"SOURCE", "VSS"},
        "r2", {{"r", "1k"}}});
    auto resistorActual = resistorWanted;
    resistorActual.find("core")->find("NEW_R")->params["segL"] = "2u";
    st::VariantVerificationPolicy scopedDefaults;
    scopedDefaults.allowed_extra_parameters_by_instance[{"core", "NEW_R"}] = {"segL"};
    CHECK(st::VerifyVariantRoundTrip(base, resistorWanted, resistorActual, scopedDefaults).ok,
        "只允许指定新增实例已声明但未指定的CDF默认字段");
    auto wrongR = resistorActual;
    wrongR.find("core")->find("NEW_R")->params["r"] = "2k";
    CHECK(!st::VerifyVariantRoundTrip(base, resistorWanted, wrongR, scopedDefaults).ok,
        "新增器件默认字段许可不能放宽用户要求阻值");
    auto leakedDefaults = resistorActual;
    leakedDefaults.find("core")->find("M0")->params["segL"] = "2u";
    CHECK(!st::VerifyVariantRoundTrip(base, resistorWanted, leakedDefaults, scopedDefaults).ok,
        "新电阻字段许可不扩散到原MOS或其他实例");
    auto unknownDefault = resistorActual;
    unknownDefault.find("core")->find("NEW_R")->params["undeclared"] = "1";
    CHECK(!st::VerifyVariantRoundTrip(base, resistorWanted, unknownDefault, scopedDefaults).ok,
        "新电阻未声明的额外CDF参数仍拒绝");
    auto originalEmpty = wanted;
    originalEmpty.find("core")->find("M0")->params["cellHeight_misMatch"] = "";
    auto changedEmpty = originalEmpty;
    changedEmpty.find("core")->find("M0")->params["cellHeight_misMatch"] = "598.5n";
    CHECK(!st::VerifyVariantRoundTrip(base, originalEmpty, changedEmpty, scopedDefaults).ok,
        "原MOS空值仍严格比较，不给cellHeight_misMatch加豁免");

    auto wrongConnection = wanted;
    wrongConnection.find("core")->find("M0_CAS")->nets[1] = "WRONG_BIAS";
    auto wrongConnectionReport = st::VerifyVariantRoundTrip(base, wanted, wrongConnection);
    CHECK(!wrongConnectionReport.ok && !wrongConnectionReport.ready_for_sizing &&
            wrongConnectionReport.diags[0].code == st::DiagCode::VariantStructureMismatch,
        "新增Cascode的Bias连接错误时禁止进入Sizing");

    auto changedUntouched = wanted;
    changedUntouched.find("core")->find("KEEP")->nets[0] = "BROKEN";
    auto changedUntouchedReport = st::VerifyVariantRoundTrip(base, wanted, changedUntouched);
    CHECK(!changedUntouchedReport.ok,
        "未选择实例被OA物化意外改动时验证失败");

    auto resetParameter = wanted;
    resetParameter.find("core")->find("M0_CAS")->params["w"] = "1u";
    auto resetParameterReport = st::VerifyVariantRoundTrip(base, wanted, resetParameter);
    CHECK(!resetParameterReport.ok &&
            resetParameterReport.diags[0].code == st::DiagCode::VariantParameterMismatch,
        "CDF把新增器件尺寸恢复默认值时禁止进入Sizing");

    auto equivalentEngineeringParameter = wanted;
    equivalentEngineeringParameter.find("core")->find("KEEP")->params["r"] = "1K";
    auto equivalentEngineeringParameterReport = st::VerifyVariantRoundTrip(
        base, wanted, equivalentEngineeringParameter);
    CHECK(equivalentEngineeringParameterReport.ok &&
            equivalentEngineeringParameterReport.ready_for_sizing,
        "回读工程数值仅单位后缀大小写不同时仍视为同一参数值");

    auto missingInstance = wanted;
    missingInstance.find("core")->remove("M0_CAS");
    auto missingReport = st::VerifyVariantRoundTrip(base, wanted, missingInstance);
    CHECK(!missingReport.ok, "OA结果缺少应新增实例时验证失败");

    auto extraInstance = wanted;
    extraInstance.find("core")->instances.push_back({ "UNEXPECTED", { "OUT", "VSS" }, "r2", {} });
    auto extraReport = st::VerifyVariantRoundTrip(base, wanted, extraInstance);
    CHECK(!extraReport.ok, "OA结果出现计划外实例时验证失败");

    auto wrongPort = wanted;
    wrongPort.find("core")->pins.pop_back();
    auto wrongPortReport = st::VerifyVariantRoundTrip(base, wanted, wrongPort);
    CHECK(!wrongPortReport.ok, "新增外部Bias端口丢失时验证失败");

    auto reversedPorts = wanted;
    std::reverse(reversedPorts.find("core")->pins.begin(),
                 reversedPorts.find("core")->pins.end());
    auto reversedPortsReport = st::VerifyVariantRoundTrip(base, wanted, reversedPorts);
    CHECK(!reversedPortsReport.ok && !reversedPortsReport.ready_for_sizing,
        "subckt位置端口顺序变化时必须拒绝，不能排序后视为等价");

    auto unexpectedParameter = wanted;
    unexpectedParameter.find("core")->find("M0_CAS")->params["mystery"] = "1";
    auto unexpectedParameterReport = st::VerifyVariantRoundTrip(base, wanted, unexpectedParameter);
    CHECK(!unexpectedParameterReport.ok &&
            unexpectedParameterReport.diags[0].code == st::DiagCode::VariantParameterMismatch,
        "未进入PDK派生参数白名单的额外参数不能静默通过");

    auto duplicateInstance = wanted;
    duplicateInstance.find("core")->instances.push_back(
        *duplicateInstance.find("core")->find("M0_CAS"));
    auto duplicateInstanceReport = st::VerifyVariantRoundTrip(base, wanted, duplicateInstance);
    CHECK(!duplicateInstanceReport.ok, "round-trip存在重复实例名时拒绝");

    auto duplicateSubckt = wanted;
    duplicateSubckt.subckts.push_back(duplicateSubckt.subckts.front());
    auto duplicateSubcktReport = st::VerifyVariantRoundTrip(base, wanted, duplicateSubckt);
    CHECK(!duplicateSubcktReport.ok, "round-trip存在重复subckt名时拒绝");

    auto expectedWithContext = wanted;
    expectedWithContext.preamble = { "include \"models.scs\"" };
    expectedWithContext.find("core")->params["gain"] = "2";
    auto contextLost = expectedWithContext;
    contextLost.preamble.clear();
    contextLost.find("core")->params.clear();
    auto contextLostReport = st::VerifyVariantRoundTrip(base, expectedWithContext, contextLost);
    CHECK(!contextLostReport.ok,
        "round-trip丢失模型include或subckt参数时拒绝");

    CHECK(st::ComputeNetlistTopologyHash(wanted) == st::ComputeNetlistTopologyHash(actual),
        "Topology hash只依赖层级、实例、master和连接，不依赖输出顺序或派生参数");

    // 封装变体的VBIAS模板子电路同样是round-trip验证对象：
    // 模板以独立subckt存在，父层只有一个层级实例。
    auto vbiasExpected = wanted;
    vbiasExpected.find("core")->instances.push_back({"I_VBIAS_N_M0",
        { "VDD", "VSS", "SOURCE", "CTRL", "VBIAS_N_M0" },
        "VBIAS_N_CASCODE_AUTO_M0", {} });
    st::Subckt biasSubckt;
    biasSubckt.name = "VBIAS_N_CASCODE_AUTO_M0";
    biasSubckt.pins = { "VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N" };
    biasSubckt.instances.push_back({ "P_REF",
        { "PBIAS_REF", "PBIAS_REF", "VHIGH", "VHIGH" }, "psvt",
        { { "w", "2u" }, { "l", "240n" } } });
    biasSubckt.instances.push_back({ "N_CTRL_REP_N",
        { "X_REP_N", "VG_CTRL", "VS_ORIG", "VLOW" }, "nsvt",
        { { "w", "2u" }, { "l", "240n" } } });
    vbiasExpected.subckts.push_back(biasSubckt);

    auto vbiasActual = vbiasExpected;
    auto* actualBias = vbiasActual.find("VBIAS_N_CASCODE_AUTO_M0");
    std::reverse(actualBias->instances.begin(), actualBias->instances.end());
    actualBias->find("P_REF")->params["ad"] = "1p";
    auto vbiasPass = st::VerifyVariantRoundTrip(
        base, vbiasExpected, vbiasActual, derivedParameterPolicy);
    CHECK(vbiasPass.ok && vbiasPass.ready_for_sizing,
        "VBIAS模板子电路内部实例顺序变化和批准的派生参数不影响验证");

    auto vbiasDrift = vbiasExpected;
    vbiasDrift.find("VBIAS_N_CASCODE_AUTO_M0")->find("N_CTRL_REP_N")->params["w"] = "1u";
    auto vbiasDriftReport = st::VerifyVariantRoundTrip(base, vbiasExpected, vbiasDrift);
    CHECK(!vbiasDriftReport.ok &&
            vbiasDriftReport.diags[0].code == st::DiagCode::VariantParameterMismatch,
        "VBIAS模板角色参数被回读改动时禁止进入Sizing");

    auto vbiasMissing = wanted;
    auto vbiasMissingReport = st::VerifyVariantRoundTrip(
        base, vbiasExpected, vbiasMissing);
    CHECK(!vbiasMissingReport.ok &&
            vbiasMissingReport.diags[0].code == st::DiagCode::VariantStructureMismatch,
        "OA结果丢失整个VBIAS模板子电路时验证失败");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Variant verifier tests passed\n";
    } else {
        std::cout << failures << " Variant verifier tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
