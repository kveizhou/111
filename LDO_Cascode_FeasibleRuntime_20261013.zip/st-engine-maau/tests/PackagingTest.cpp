#include "st/Packaging.h"
#include "st/JsonWriter.h"

#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                         \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                         \
        }                                                                        \
    } while (false)

st::TransformRequest operation(const std::string& id, const std::string& target,
                               st::TransformType type)
{
    st::TransformRequest result;
    result.operation_id = id;
    result.target = {"/", "core", target};
    result.type = type;
    st::CascodeTransformRequest payload;
    payload.subckt = "core";
    payload.target = target;
    result.payload = payload;
    return result;
}

st::DeviceDescriptor descriptor(const std::string& master, st::DeviceKind kind,
                                const std::vector<std::string>& terminals,
                                const std::vector<st::TerminalRole>& roles)
{
    st::DeviceDescriptor value;
    value.master = master;
    value.kind = kind;
    value.terminal_count = terminals.size();
    value.terminal_names_by_index = terminals;
    value.terminal_roles_by_index = roles;
    value.oa_library = "pdk";
    value.oa_cell = master;
    value.oa_view = "symbol";
    if (kind == st::DeviceKind::Resistor) {
        value.normalized_to_cdf = {{"resistance", "r"}, {"cdf_segL", "segL"}, {"cdf_model", "model"}};
    }
    for (std::size_t index = 0; index < roles.size(); ++index) {
        value.terminal_index[roles[index]] = index;
    }
    return value;
}

} // namespace

int main()
{
    st::Netlist baseline;
    st::Subckt core;
    core.name = "core";
    core.pins = {"OUT0", "OUT1", "OUT2", "OUT3", "CTRL", "VBIAS", "VDD", "VSS"};
    for (int index = 0; index < 4; ++index) {
        core.instances.push_back({"M" + std::to_string(index),
            {"OUT" + std::to_string(index), "CTRL", "VSS", "VSS"},
            "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    }
    baseline.subckts.push_back(core);

    auto flat = baseline;
    auto* transformed = flat.find("core");
    transformed->find("M0")->nets[0] = "M0_MID";
    transformed->instances.push_back({"M0_CAS", {"OUT0", "VBIAS", "M0_MID", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    transformed->find("M1")->nets[0] = "M1_MID";
    transformed->instances.push_back({"M1_CAS", {"OUT1", "VBIAS", "M1_MID", "VSS"},
        "nlvt", {{"w", "2u"}, {"l", "240n"}}});
    transformed->find("M2")->nets[2] = "M2_RS_INT";
    transformed->instances.push_back({"M2_RS", {"M2_RS_INT", "VSS"},
        "r2", {{"r", "1k"}}});
    transformed->find("M3")->nets[2] = "M3_MID1";
    transformed->instances.push_back({"M3_S1", {"M3_MID1", "CTRL", "VSS", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    // 自动VBIAS求解+模板消费后的扁平结果：父层只有一个模板层级实例，
    // 模板五角色在独立subckt里（固定端口序VHIGH/VLOW/VS_ORIG/VG_CTRL/VBIAS_N）。
    transformed->instances.push_back({"I_VBIAS_N_M0",
        {"VDD", "VSS", "VSS", "CTRL", "VBIAS_N_M0"},
        "VBIAS_N_CASCODE_AUTO_M0", {}});
    st::Subckt biasTemplate;
    biasTemplate.name = "VBIAS_N_CASCODE_AUTO_M0";
    biasTemplate.pins = {"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N"};
    biasTemplate.instances.push_back({"P_REF",
        {"PBIAS_REF", "PBIAS_REF", "VHIGH", "VHIGH"}, "psvt",
        {{"w", "2u"}, {"l", "240n"}}});
    biasTemplate.instances.push_back({"R_REF_N", {"PBIAS_REF", "VLOW"}, "r2",
        {{"r", "10k"}}});
    biasTemplate.instances.push_back({"P_OUT_N",
        {"VBIAS_N", "PBIAS_REF", "VHIGH", "VHIGH"}, "psvt",
        {{"w", "2u"}, {"l", "240n"}}});
    biasTemplate.instances.push_back({"N_CAS_REP_N",
        {"VBIAS_N", "VBIAS_N", "X_REP_N", "VLOW"}, "nsvt",
        {{"w", "2u"}, {"l", "240n"}}});
    biasTemplate.instances.push_back({"N_CTRL_REP_N",
        {"X_REP_N", "VG_CTRL", "VS_ORIG", "VLOW"}, "nsvt",
        {{"w", "2u"}, {"l", "240n"}}});
    flat.subckts.push_back(biasTemplate);

    st::ChangeSet changes;
    st::Diagnostic diagnostic;
    auto op0 = operation("same", "M0", st::TransformType::SameTypeCascode);
    auto op1 = operation("cross", "M1", st::TransformType::CrossFlavorCascode);
    std::get<st::CascodeTransformRequest>(op1.payload).new_master = "nlvt";
    st::ResistorTransformRequest resistor;
    resistor.subckt = "core";
    resistor.target = "M2";
    auto op2 = operation("res", "M2", st::TransformType::AddSourceResistor);
    op2.payload = resistor;
    st::StackTransformRequest stack;
    stack.subckt = "core";
    stack.target = "M3";
    stack.stage_count = 2;
    auto op3 = operation("stack", "M3", st::TransformType::MosStack);
    op3.payload = stack;
    CHECK(changes.Confirm(op0, diagnostic) && changes.Confirm(op1, diagnostic) &&
          changes.Confirm(op2, diagnostic) && changes.Confirm(op3, diagnostic),
          "四类变换可以组成待封装Change Set");

    st::ReplayResult replay;
    replay.ok = true;
    replay.outcomes.resize(4);
    replay.outcomes[0].modifiedInstances = {"M0"};
    replay.outcomes[0].addedInstances = {"M0_CAS"};
    replay.outcomes[0].addedNets = {"M0_MID"};
    replay.outcomes[0].bias_instances = {"I_VBIAS_N_M0"};
    replay.outcomes[1].modifiedInstances = {"M1"};
    replay.outcomes[1].addedInstances = {"M1_CAS"};
    replay.outcomes[1].addedNets = {"M1_MID"};
    replay.outcomes[2].modifiedInstances = {"M2"};
    replay.outcomes[2].addedInstances = {"M2_RS"};
    replay.outcomes[2].addedNets = {"M2_RS_INT"};
    replay.outcomes[3].modifiedInstances = {"M3"};
    replay.outcomes[3].addedInstances = {"M3_S1"};
    replay.outcomes[3].addedNets = {"M3_MID1"};

    const auto packaged = st::PackageTopologyVariant(
        baseline, flat, "core", changes, replay, "core_TV0001", "variant");
    CHECK(packaged.ok() && packaged.packages.size() == 5,
          "四类变换各产功能封装，FixedBias Cascode额外产独立VBIAS封装");
    const auto* packagedCore = packaged.netlist.find("core");
    CHECK(packagedCore != nullptr && packagedCore->instances.size() == 5,
          "核心电路只保留封装wrapper实例，不再散放新增器件和bias模板器件");
    CHECK(packaged.netlist.find("VBIAS_N_CASCODE_AUTO_M0") == nullptr,
          "VBIAS模板定义载具并入封装后不再残留为扁平subckt");
    const auto& vbiasPackage = packaged.packages[4];
    CHECK(vbiasPackage.package_id == "VBIAS0001" &&
          vbiasPackage.cell_name == "core_TV0001__VBIAS0001" &&
          vbiasPackage.parent_instance_name == "I_VBIAS_N_M0" &&
          vbiasPackage.replaced_parent_instances.empty() &&
          vbiasPackage.operation_ids == std::vector<std::string>({"same"}),
          "VBIAS封装独立计数、不替换任何基线实例、归属产生它的操作");
    CHECK(vbiasPackage.circuit.pins ==
              std::vector<std::string>({"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N"}) &&
          vbiasPackage.circuit.instances.size() == 5,
          "VBIAS封装保持模板固定端口序并包含全部五个角色");
    const auto* vbiasWrapper = packagedCore->find("I_VBIAS_N_M0");
    CHECK(vbiasWrapper != nullptr && vbiasWrapper->model == vbiasPackage.circuit.name &&
          vbiasWrapper->nets ==
              std::vector<std::string>({"VDD", "VSS", "VSS", "CTRL", "VBIAS_N_M0"}),
          "VBIAS wrapper保持真实父层网（VHIGH=VDD、VS_ORIG=原Source网）");
    CHECK(packaged.packages[0].circuit.instances.size() == 2 &&
          packaged.packages[1].circuit.instances.size() == 2 &&
          packaged.packages[2].circuit.instances.size() == 2 &&
          packaged.packages[3].circuit.instances.size() == 2,
          "每个功能封装内部包含该变换的真实器件");
    CHECK(packaged.packages[0].circuit.find("M0")->nets[1] == "CTRL" &&
          packaged.packages[0].circuit.find("M0_CAS")->nets[1] == "VBIAS",
          "Cascode封装保持原MOS栅极并只给新增MOS接VBIAS");
    CHECK(packaged.packages[3].circuit.find("M3")->nets[1] == "CTRL" &&
          packaged.packages[3].circuit.find("M3_S1")->nets[1] == "CTRL",
          "Stack封装内所有级共享原Gate");

    st::DeviceCatalog catalog;
    CHECK(catalog.Add(descriptor("nsvt", st::DeviceKind::MosN,
              {"D", "G", "S", "B"}, {st::TerminalRole::Drain,
               st::TerminalRole::Gate, st::TerminalRole::Source,
               st::TerminalRole::Bulk}), diagnostic) &&
          catalog.Add(descriptor("nlvt", st::DeviceKind::MosN,
              {"D", "G", "S", "B"}, {st::TerminalRole::Drain,
               st::TerminalRole::Gate, st::TerminalRole::Source,
               st::TerminalRole::Bulk}), diagnostic) &&
          catalog.Add(descriptor("psvt", st::DeviceKind::MosP,
              {"D", "G", "S", "B"}, {st::TerminalRole::Drain,
               st::TerminalRole::Gate, st::TerminalRole::Source,
               st::TerminalRole::Bulk}), diagnostic) &&
          catalog.Add(descriptor("r2", st::DeviceKind::Resistor,
              {"P", "N"}, {st::TerminalRole::Positive,
               st::TerminalRole::Negative}), diagnostic),
          "封装OA计划使用PDK真实master与terminal顺序");
    st::OaPlanBuildContext buildContext;
    buildContext.source = {"design", "core", "schematic", "/source"};
    buildContext.target = {"variant__STAGING", "core_tv__STAGING",
                           "schematic", "/session"};
    buildContext.clone_map.push_back({buildContext.source, buildContext.target, "/"});
    buildContext.hierarchy_by_subckt["core"] = "/";
    buildContext.preview = {"TV0001", "initial", "standalone-v2"};
    for (std::size_t index = 0; index < packaged.packages.size(); ++index) {
        const auto& package = packaged.packages[index];
        buildContext.locations["/:" + package.parent_instance_name] =
            {100.0, 20.0 - static_cast<double>(index) * 8.0};
        for (const auto& pin : package.circuit.pins) {
            buildContext.wires.push_back({"/", pin,
                {{90.0, 20.0 - static_cast<double>(index) * 8.0},
                 {99.0, 20.0 - static_cast<double>(index) * 8.0}}});
        }
    }
    const auto packagedPlan = st::BuildPackagedOaMaterializationPlan(
        baseline, packaged, catalog, buildContext, "variant");
    CHECK(packagedPlan.ok() && packagedPlan.plan.schema_version == 3 &&
          packagedPlan.plan.generated_cells.size() == 5,
          "功能封装和VBIAS封装都生成schematic+symbol CellView计划，schema版本3");
    CHECK(packagedPlan.plan.create_instances.size() == 5 &&
          packagedPlan.plan.delete_instances.size() == 4,
          "父电路删除四个原管、创建四个功能wrapper加一个VBIAS wrapper");
    const auto& vbiasCell = packagedPlan.plan.generated_cells[4];
    CHECK(vbiasCell.package_id == "VBIAS0001" &&
          vbiasCell.create_instances.size() == 5 &&
          vbiasCell.create_ports.size() == 5,
          "VBIAS子Cell物化五个角色并创建五个端口");
    CHECK(!vbiasCell.direct_wires.empty(),
          "VBIAS模板内部串联节点使用引脚到引脚实体线");
    const auto& vbiasWrapperPlan = packagedPlan.plan.create_instances[4];
    CHECK(vbiasWrapperPlan.name == "I_VBIAS_N_M0" &&
          vbiasWrapperPlan.connections.size() == 5 &&
          vbiasWrapperPlan.connections[0].pdk_terminal == "VHIGH" &&
          vbiasWrapperPlan.connections[0].net == "VDD" &&
          vbiasWrapperPlan.connections[2].pdk_terminal == "VS_ORIG" &&
          vbiasWrapperPlan.connections[2].net == "VSS" &&
          vbiasWrapperPlan.connections[4].pdk_terminal == "VBIAS_N" &&
          vbiasWrapperPlan.connections[4].net == "VBIAS_N_M0",
          "VBIAS wrapper按模板端口序映射真实父层网，不假设pin名等于net名");
    CHECK(packagedPlan.plan.generated_cells[0].create_instances.size() == 2 &&
          packagedPlan.plan.generated_cells[0].create_ports.size() ==
              packaged.packages[0].circuit.pins.size(),
          "子Cell内部保留真实器件并为边界网络创建端口");
    CHECK(!packagedPlan.plan.generated_cells[0].direct_wires.empty(),
          "Cascode内部串联节点使用引脚到引脚实体线");
    CHECK(!packagedPlan.plan.generated_cells[2].direct_wires.empty(),
          "MOS Source与电阻的内部串联节点使用引脚到引脚实体线");

    const auto preservedJson = st::WritePlanJson(packagedPlan.plan);
    CHECK(preservedJson.find("\"copy_properties_from\":{") != std::string::npos &&
          preservedJson.find("\"instance\":\"M2\"") != std::string::npos,
          "未改参数的原MOS通过隔离根图显式属性复制，不重写有效CDF默认值");
    CHECK(preservedJson.find("\"instance\":\"M3\"") != std::string::npos,
          "共栅Stack各级追溯到原MOS显式属性，不按master或尺寸猜来源");
    CHECK(packagedPlan.plan.generated_cells[2].create_instances[0].property_source == buildContext.target &&
          packagedPlan.plan.generated_cells[2].create_instances[0].property_source_instance == "M2" &&
          packagedPlan.plan.generated_cells[3].create_instances[1].property_source_instance == "M3",
          "原MOS和新增Stack级精确绑定隔离根图原实例");
    auto structuralContext = buildContext;
    structuralContext.structure_only = true;
    const auto structuralPlan = st::BuildPackagedOaMaterializationPlan(
        baseline, packaged, catalog, structuralContext, "variant");
    const auto& newResistor = structuralPlan.plan.generated_cells[2].create_instances[1];
    CHECK(newResistor.allowed_extra_cdf_parameters == std::set<std::string>({"model", "segL"}) &&
          newResistor.property_source_instance.empty(),
          "新增结构电阻仅许可其真实CDF声明中未指定的字段，r仍是要求值");
    CHECK(packagedPlan.plan.generated_cells[2].create_instances[1].allowed_extra_cdf_parameters.empty(),
          "默认电气会话不放宽新增电阻的回读字段");
    auto resizedPackage = packaged;
    resizedPackage.packages[2].circuit.find("M2")->params["w"] = "3u";
    const auto resizedPlan = st::BuildPackagedOaMaterializationPlan(
        baseline, resizedPackage, catalog, buildContext, "variant");
    CHECK(resizedPlan.ok() &&
          resizedPlan.plan.generated_cells[2].create_instances[0].property_source_instance.empty() &&
          resizedPlan.plan.generated_cells[2].create_instances[0].cdf_parameters.at("w") == "3u",
          "参数已改变的MOS仍走实际CDF写入，不能用原属性复制覆盖用户修改");
    auto unsafeSource = packagedPlan.plan;
    unsafeSource.generated_cells[2].create_instances[0].property_source = buildContext.source;
    CHECK(!st::ValidateOaPlan(unsafeSource).empty(), "属性复制计划不能改为读取源库实例");
    auto unsafeApproval = packagedPlan.plan;
    unsafeApproval.generated_cells[2].create_instances[0].allowed_extra_cdf_parameters.insert("cellHeight_misMatch");
    CHECK(!st::ValidateOaPlan(unsafeApproval).empty(), "复制原MOS不能同时放宽该实例的回读字段");

    st::DeviceCatalog limitedCatalog;
    auto limitedNsvt = descriptor("nsvt", st::DeviceKind::MosN,
        {"D", "G", "S", "B"}, {st::TerminalRole::Drain,
         st::TerminalRole::Gate, st::TerminalRole::Source, st::TerminalRole::Bulk});
    limitedNsvt.normalized_to_cdf = {{"width", "w"}, {"length", "l"}};
    auto limitedNlvt = descriptor("nlvt", st::DeviceKind::MosN,
        {"D", "G", "S", "B"}, {st::TerminalRole::Drain,
         st::TerminalRole::Gate, st::TerminalRole::Source, st::TerminalRole::Bulk});
    limitedNlvt.normalized_to_cdf = {{"width", "w"}, {"length", "l"}};
    auto limitedResistor = descriptor("r2", st::DeviceKind::Resistor,
        {"P", "N"}, {st::TerminalRole::Positive, st::TerminalRole::Negative});
    limitedResistor.normalized_to_cdf = {{"resistance", "r"}};
    limitedResistor.limits.max_resistance = 500.0;
    CHECK(limitedCatalog.Add(limitedNsvt, diagnostic) &&
          limitedCatalog.Add(limitedNlvt, diagnostic) &&
          limitedCatalog.Add(limitedResistor, diagnostic),
          "构造有限阻值范围的PDK目录");
    const auto rejectedPlan = st::BuildPackagedOaMaterializationPlan(
        baseline, packaged, limitedCatalog, buildContext, "variant");
    CHECK(!rejectedPlan.ok() &&
          rejectedPlan.diagnostics.front().code ==
              st::DiagCode::DeviceParameterOutOfRange,
          "封装物化前仍拒绝超出PDK范围的新增器件参数");

    auto chainedFlat = baseline;
    auto* chainedCore = chainedFlat.find("core");
    chainedCore->find("M0")->nets[0] = "M0_MID";
    chainedCore->instances.push_back({"M0_CAS", {"M0_OUT2", "VBIAS", "M0_MID", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    chainedCore->instances.push_back({"M0_CAS_CAS", {"OUT0", "VBIAS", "M0_OUT2", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    st::ChangeSet chainedChanges;
    CHECK(chainedChanges.Confirm(op0, diagnostic), "链式变换先确认第一步");
    auto chainedOp = operation("same_again", "M0_CAS", st::TransformType::SameTypeCascode);
    CHECK(chainedChanges.Confirm(chainedOp, diagnostic), "链式变换可继续修改新增MOS");
    st::ReplayResult chainedReplay;
    chainedReplay.ok = true;
    chainedReplay.outcomes.resize(2);
    chainedReplay.outcomes[0].modifiedInstances = {"M0"};
    chainedReplay.outcomes[0].addedInstances = {"M0_CAS"};
    chainedReplay.outcomes[0].addedNets = {"M0_MID"};
    chainedReplay.outcomes[1].modifiedInstances = {"M0_CAS"};
    chainedReplay.outcomes[1].addedInstances = {"M0_CAS_CAS"};
    chainedReplay.outcomes[1].addedNets = {"M0_OUT2"};
    const auto chained = st::PackageTopologyVariant(
        baseline, chainedFlat, "core", chainedChanges, chainedReplay,
        "core_TV0002", "variant");
    CHECK(chained.ok() && chained.packages.size() == 1 &&
          chained.packages[0].circuit.instances.size() == 3,
          "多次修改同一派生区域时合并成一个封装，避免封装互相覆盖");

    // ================= 两个FixedBias Cascode的封装隔离 =================
    st::Netlist isoBaseline;
    st::Subckt isoCore;
    isoCore.name = "core";
    isoCore.pins = {"OUT0", "OUT1", "CTRL", "VDD", "VSS"};
    isoCore.instances.push_back({"M0", {"OUT0", "CTRL", "VSS", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    isoCore.instances.push_back({"M1", {"OUT1", "CTRL", "VSS", "VSS"},
        "nsvt", {{"w", "2u"}, {"l", "240n"}}});
    isoBaseline.subckts.push_back(isoCore);
    auto isoFlat = isoBaseline;
    auto* isoTransformed = isoFlat.find("core");
    isoTransformed->find("M0")->nets[0] = "M0_MID";
    isoTransformed->instances.push_back({"M0_CAS",
        {"OUT0", "VBIAS_N_M0", "M0_MID", "VSS"}, "nsvt",
        {{"w", "2u"}, {"l", "240n"}}});
    isoTransformed->find("M1")->nets[0] = "M1_MID";
    isoTransformed->instances.push_back({"M1_CAS",
        {"OUT1", "VBIAS_N_M1", "M1_MID", "VSS"}, "nsvt",
        {{"w", "3u"}, {"l", "240n"}}});
    const std::map<std::string, std::map<std::string, std::string>> isoRoles = {
        {"P_REF", {{"w", "2u"}, {"l", "240n"}}},
        {"P_OUT_N", {{"w", "2u"}, {"l", "240n"}}},
        {"N_CAS_REP_N", {{"w", "2u"}, {"l", "240n"}}},
        {"N_CTRL_REP_N", {{"w", "2u"}, {"l", "240n"}}},
    };
    for (const std::string& target : {std::string("M0"), std::string("M1")}) {
        // 每次重新find：上一轮的subckts.push_back可能已使旧指针悬垂。
        isoFlat.find("core")->instances.push_back({"I_VBIAS_N_" + target,
            {"VDD", "VSS", "VSS", "CTRL", "VBIAS_N_" + target},
            "VBIAS_N_CASCODE_AUTO_" + target, {}});
        st::Subckt isoTemplate;
        isoTemplate.name = "VBIAS_N_CASCODE_AUTO_" + target;
        isoTemplate.pins = {"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", "VBIAS_N"};
        isoTemplate.instances.push_back({"P_REF",
            {"PBIAS_REF", "PBIAS_REF", "VHIGH", "VHIGH"}, "psvt",
            isoRoles.at("P_REF")});
        isoTemplate.instances.push_back({"R_REF_N", {"PBIAS_REF", "VLOW"}, "r2",
            {{"r", "10k"}}});
        isoTemplate.instances.push_back({"P_OUT_N",
            {"VBIAS_N", "PBIAS_REF", "VHIGH", "VHIGH"}, "psvt",
            isoRoles.at("P_OUT_N")});
        isoTemplate.instances.push_back({"N_CAS_REP_N",
            {"VBIAS_N", "VBIAS_N", "X_REP_N", "VLOW"}, "nsvt",
            isoRoles.at("N_CAS_REP_N")});
        isoTemplate.instances.push_back({"N_CTRL_REP_N",
            {"X_REP_N", "VG_CTRL", "VS_ORIG", "VLOW"}, "nsvt",
            isoRoles.at("N_CTRL_REP_N")});
        isoFlat.subckts.push_back(isoTemplate);
    }
    st::ChangeSet isoChanges;
    auto isoOp0 = operation("same_m0", "M0", st::TransformType::SameTypeCascode);
    auto isoOp1 = operation("same_m1", "M1", st::TransformType::SameTypeCascode);
    CHECK(isoChanges.Confirm(isoOp0, diagnostic) &&
          isoChanges.Confirm(isoOp1, diagnostic),
          "两个FixedBias Cascode操作可组成Change Set");
    st::ReplayResult isoReplay;
    isoReplay.ok = true;
    isoReplay.outcomes.resize(2);
    isoReplay.outcomes[0].modifiedInstances = {"M0"};
    isoReplay.outcomes[0].addedInstances = {"M0_CAS"};
    isoReplay.outcomes[0].addedNets = {"M0_MID"};
    isoReplay.outcomes[0].bias_instances = {"I_VBIAS_N_M0"};
    isoReplay.outcomes[1].modifiedInstances = {"M1"};
    isoReplay.outcomes[1].addedInstances = {"M1_CAS"};
    isoReplay.outcomes[1].addedNets = {"M1_MID"};
    isoReplay.outcomes[1].bias_instances = {"I_VBIAS_N_M1"};
    const auto isoPackaged = st::PackageTopologyVariant(
        isoBaseline, isoFlat, "core", isoChanges, isoReplay, "core_TV0003",
        "variant");
    CHECK(isoPackaged.ok() && isoPackaged.packages.size() == 4 &&
          isoPackaged.packages[0].package_id == "PKG0001" &&
          isoPackaged.packages[1].package_id == "PKG0002" &&
          isoPackaged.packages[2].package_id == "VBIAS0001" &&
          isoPackaged.packages[3].package_id == "VBIAS0002",
          "两个Cascode产PKG0001/PKG0002/VBIAS0001/VBIAS0002四封装");
    std::set<std::string> isoCellNames;
    std::set<std::string> isoCircuitNames;
    for (const auto& package : isoPackaged.packages) {
        isoCellNames.insert(package.cell_name);
        isoCircuitNames.insert(package.circuit.name);
    }
    CHECK(isoCellNames.size() == 4 && isoCircuitNames.size() == 4,
          "四套封装的CellView名与电路名互不共享");
    CHECK(isoPackaged.packages[2].parent_instance_name == "I_VBIAS_N_M0" &&
          isoPackaged.packages[3].parent_instance_name == "I_VBIAS_N_M1" &&
          isoPackaged.packages[2].operation_ids ==
              std::vector<std::string>({"same_m0"}) &&
          isoPackaged.packages[3].operation_ids ==
              std::vector<std::string>({"same_m1"}) &&
          isoPackaged.packages[2].replaced_parent_instances.empty() &&
          isoPackaged.packages[3].replaced_parent_instances.empty(),
          "两个VBIAS封装各有独立父wrapper、各归属产生它的操作、不替换基线实例");
    const auto* isoPackagedCore = isoPackaged.netlist.find("core");
    CHECK(isoPackagedCore != nullptr &&
          isoPackagedCore->instances.size() == 4 &&
          isoPackagedCore->find("I_VBIAS_N_M0")->nets[4] == "VBIAS_N_M0" &&
          isoPackagedCore->find("I_VBIAS_N_M1")->nets[4] == "VBIAS_N_M1",
          "两个VBIAS wrapper的输出网互不共享");
    CHECK(isoPackaged.netlist.find("VBIAS_N_CASCODE_AUTO_M0") == nullptr &&
          isoPackaged.netlist.find("VBIAS_N_CASCODE_AUTO_M1") == nullptr,
          "两个模板载具都并入各自封装，扁平网表无残留");

    st::OaPlanBuildContext isoContext;
    isoContext.source = {"design", "core", "schematic", "/source"};
    isoContext.target = {"variant__STAGING", "core_tv3__STAGING", "schematic",
                         "/session"};
    isoContext.clone_map.push_back({isoContext.source, isoContext.target, "/"});
    isoContext.hierarchy_by_subckt["core"] = "/";
    isoContext.preview = {"TV0003", "initial", "standalone-v2"};
    for (std::size_t index = 0; index < isoPackaged.packages.size(); ++index) {
        const auto& package = isoPackaged.packages[index];
        isoContext.locations["/:" + package.parent_instance_name] =
            {100.0, 40.0 - static_cast<double>(index) * 8.0};
    }
    const auto isoPlan = st::BuildPackagedOaMaterializationPlan(
        isoBaseline, isoPackaged, catalog, isoContext, "variant");
    CHECK(isoPlan.ok() && isoPlan.plan.generated_cells.size() == 4,
          "双Cascode计划生成四个子Cell");
    std::set<std::string> isoSchematicCells;
    for (const auto& cell : isoPlan.plan.generated_cells) {
        isoSchematicCells.insert(cell.schematic.library + "/" +
                                 cell.schematic.cell);
    }
    CHECK(isoSchematicCells.size() == 4,
          "四个generated cell的schematic CellView互不共享");
    std::map<std::string, st::OaPoint> isoWrapperLocations;
    for (const auto& instance : isoPlan.plan.create_instances) {
        isoWrapperLocations[instance.name] = instance.location;
    }
    CHECK(isoWrapperLocations.count("I_VBIAS_N_M0") == 1 &&
          isoWrapperLocations.count("I_VBIAS_N_M1") == 1 &&
          !(isoWrapperLocations["I_VBIAS_N_M0"].x ==
                isoWrapperLocations["I_VBIAS_N_M1"].x &&
            isoWrapperLocations["I_VBIAS_N_M0"].y ==
                isoWrapperLocations["I_VBIAS_N_M1"].y),
          "两个VBIAS wrapper的放置区域互不共享");

    std::cout << "\n========================================\n";
    if (failures == 0) std::cout << "Packaging tests passed\n";
    else std::cout << failures << " packaging tests failed\n";
    return failures == 0 ? 0 : 1;
}
