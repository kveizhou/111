#include "st/PdkCatalog.h"

#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                         \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                         \
        }                                                                        \
    } while (false)

bool hasReason(const st::CandidateSelection& selection, const std::string& master,
               const std::string& reason)
{
    const auto found = selection.rejected_reasons.find(master);
    if (found == selection.rejected_reasons.end()) return false;
    for (const auto& value : found->second) {
        if (value == reason) return true;
    }
    return false;
}

bool hasAccepted(const st::CandidateSelection& selection, const std::string& master)
{
    for (const auto* candidate : selection.accepted) {
        if (candidate->master == master) return true;
    }
    return false;
}

template <typename Action>
bool throwsInvalidArgument(Action action)
{
    try {
        action();
    } catch (const std::invalid_argument&) {
        return true;
    }
    return false;
}

st::DeviceDescriptor mos(const std::string& master, st::DeviceKind kind,
                         const std::string& library = "PDK_CORE")
{
    st::DeviceDescriptor value;
    value.master = master;
    value.kind = kind;
    value.terminal_count = 4;
    value.terminal_names_by_index = {"D", "G", "S", "B"};
    value.terminal_roles_by_index = {
        st::TerminalRole::Drain, st::TerminalRole::Gate,
        st::TerminalRole::Source, st::TerminalRole::Bulk,
    };
    value.terminal_index = {
        {st::TerminalRole::Drain, 0}, {st::TerminalRole::Gate, 1},
        {st::TerminalRole::Source, 2}, {st::TerminalRole::Bulk, 3},
    };
    value.oa_library = library;
    value.oa_cell = master;
    value.oa_view = "symbol";
    value.device_family = kind == st::DeviceKind::MosN ? "core_nmos" : "core_pmos";
    value.flavor_id = "1v8";
    value.voltage_domain = "core";
    value.allowed_voltage_domains.insert("core");
    value.reliability_complete = true;
    value.bulk_rule_complete = true;
    value.parameter_constraints["width"] = {"width", "w", 1e-7, 1e-4, 1e-8, {}, false};
    return value;
}

} // namespace

int main()
{
    const st::ParameterConstraint fin{"fins", "nf", 1.0, 8.0, 0.0,
                                      {1.0, 2.0, 3.0, 4.0, 8.0}, true};
    const st::ParameterConstraint resistance{"resistance", "r", 100.0, 2000.0,
                                             100.0, {}, false};
    const st::ParameterConstraint integer{"fingers", "nf", 1.0, 64.0, 1.0, {}, true};
    const st::ParameterConstraint discreteIntegerIgnoredGrid{
        "fingers", "nf", 1.0, 8.0, 0.5, {1.0, 3.0, 8.0}, true};
    CHECK(st::QuantizeParameter(3.2, fin) == 3.0,
          "离散FIN参数量化为最近的合法FIN");
    CHECK(std::fabs(st::QuantizeParameter(1400.0, resistance) - 1400.0) < 1e-12,
          "连续电阻按100欧姆网格保持1.4千欧姆");
    CHECK(st::QuantizeParameter(3.6, integer) == 4.0,
          "整数尺寸参数量化为最近整数");
    CHECK(st::QuantizeParameter(3.2, discreteIntegerIgnoredGrid) == 3.0,
          "integer_only离散参数忽略未使用的非整数grid并只返回合法离散值");
    CHECK(st::QuantizeParameter(-1.0, resistance) == 100.0 &&
          st::QuantizeParameter(3000.0, resistance) == 2000.0,
          "越界参数被夹到合法边界");
    const st::ParameterConstraint nonAlignedGrid{"width", "w", 1.0, 5.0, 3.0, {}, false};
    CHECK(st::QuantizeParameter(100.0, nonAlignedGrid) == 4.0,
          "不对齐上界的网格量化停在区间内最后一个合法网格点");
    const st::ParameterConstraint integerBoundary{"fingers", "nf", 1.5, 8.0, 1.0, {}, true};
    const st::ParameterConstraint invalidGrid{"width", "w", 1.0, 8.0,
                                               std::numeric_limits<double>::infinity(), {}, false};
    const st::ParameterConstraint invalidDiscrete{"fins", "nf", 1.0, 4.0, 0.0,
                                                   {0.0, 5.0}, true};
    const st::ParameterConstraint invalidDiscreteNan{"fins", "nf", 1.0, 4.0, 0.0,
                                                      {std::numeric_limits<double>::quiet_NaN()}, true};
    CHECK(throwsInvalidArgument([&] { st::QuantizeParameter(2.0, integerBoundary); }) &&
          throwsInvalidArgument([&] { st::QuantizeParameter(2.0, invalidGrid); }) &&
          throwsInvalidArgument([&] { st::QuantizeParameter(2.0, invalidDiscrete); }) &&
          throwsInvalidArgument([&] { st::QuantizeParameter(2.0, invalidDiscreteNan); }),
          "拒绝非整数整数边界、非有限网格和越界或非有限离散值");
    std::string constraintReason;
    CHECK(!st::ValidateParameterConstraint(invalidDiscreteNan, &constraintReason) &&
          !constraintReason.empty(),
          "公开参数约束校验明确拒绝程序化NaN离散值");

    st::DeviceCatalog catalog;
    st::Diagnostic diagnostic;
    auto original = mos("n18_original", st::DeviceKind::MosN);
    auto accepted = mos("n18_alt", st::DeviceKind::MosN);
    accepted.flavor_id = "3v3";
    accepted.normalized_to_cdf = {{"length", "l"}, {"width", "w"}};
    accepted.limits.min_width = 1.0;
    accepted.limits.max_width = 9.0;
    accepted.limits.min_length = 2.0;
    accepted.limits.max_length = 10.0;
    accepted.limits.min_resistance = 3.0;
    accepted.limits.max_resistance = 11.0;
    accepted.limits.max_abs_vgs = 4.0;
    accepted.limits.max_abs_vds = 5.0;
    accepted.limits.max_abs_vgb = 6.0;
    accepted.limits.max_stack_level = 7;
    accepted.isolated_well = true;
    accepted.source_drain_interchangeable = true;
    auto missingReliability = mos("n_unknown_limits", st::DeviceKind::MosN);
    missingReliability.reliability_complete = false;
    auto missingSource = mos("n_missing_source", st::DeviceKind::MosN);
    missingSource.terminal_index.erase(st::TerminalRole::Source);
    missingSource.terminal_roles_by_index[2] = st::TerminalRole::Other;
    auto ioOnly = mos("n_io_only", st::DeviceKind::MosN);
    ioOnly.voltage_domain = "io";
    ioOnly.allowed_voltage_domains = {"io"};
    auto pmos = mos("p18_alt", st::DeviceKind::MosP);
    auto noCdf = mos("n_missing_cdf", st::DeviceKind::MosN);
    noCdf.oa_view.clear();
    auto noBulkRule = mos("n_missing_bulk_rule", st::DeviceKind::MosN);
    noBulkRule.bulk_rule_complete = false;
    auto noGeometry = mos("n_no_geometry", st::DeviceKind::MosN);
    noGeometry.parameter_constraints.clear();
    auto invalidConstraint = mos("n_invalid_constraint", st::DeviceKind::MosN);
    invalidConstraint.parameter_constraints.clear();
    invalidConstraint.parameter_constraints["legacy_width_key"] =
        {"width", "w", 1.0, 8.0, std::numeric_limits<double>::infinity(), {}, false};
    auto fixedIntegerGeometry = mos("n_fixed_integer_geometry", st::DeviceKind::MosN);
    fixedIntegerGeometry.flavor_id = "5v0";
    fixedIntegerGeometry.parameter_constraints = {
        {"fingers", {"fingers", "nf", 3.0, 3.0, 0.0, {}, true}},
    };
    auto sameFlavorDifferentMaster = mos("n_same_flavor", st::DeviceKind::MosN);
    auto missingFamily = mos("n_missing_family", st::DeviceKind::MosN);
    missingFamily.device_family.clear();
    missingFamily.flavor_id = "3v3";
    auto missingFlavor = mos("n_missing_flavor", st::DeviceKind::MosN);
    missingFlavor.flavor_id.clear();
    auto differentFamily = mos("n_different_family", st::DeviceKind::MosN);
    differentFamily.device_family = "io_nmos";
    differentFamily.flavor_id = "3v3";

    for (const auto* descriptor : {&original, &accepted, &missingReliability,
                                   &missingSource, &ioOnly, &pmos, &noCdf,
                                   &noBulkRule, &noGeometry, &invalidConstraint,
                                   &fixedIntegerGeometry, &sameFlavorDifferentMaster,
                                   &missingFamily, &missingFlavor, &differentFamily}) {
        CHECK(catalog.Add(*descriptor, diagnostic), "测试目录接受原始扫描记录");
    }

    const auto selection = st::SelectCrossFlavorCandidates(original, catalog, "core");
    auto threePinOriginal = original;
    threePinOriginal.terminal_count = 3;
    threePinOriginal.terminal_names_by_index.pop_back();
    threePinOriginal.terminal_roles_by_index.pop_back();
    threePinOriginal.terminal_index.erase(st::TerminalRole::Bulk);
    const auto threePinSelection = st::SelectCrossFlavorCandidates(
        threePinOriginal, catalog, "core");
    CHECK(!hasAccepted(threePinSelection, "n18_alt") &&
          hasReason(threePinSelection, "n18_alt", "original_mos_terminal_bulk_missing"),
          "三端原MOS可做Source电阻，但不把四端Cascode master误报为可直接变换");
    CHECK(selection.accepted.size() == 6 &&
          hasAccepted(selection, "n18_alt") &&
          hasAccepted(selection, "n_fixed_integer_geometry") &&
          hasAccepted(selection, "n_same_flavor") &&
          hasAccepted(selection, "n_missing_family") &&
          hasAccepted(selection, "n_missing_flavor") &&
          hasAccepted(selection, "n_different_family"),
          "同极性且不同master的完整器件均可候选，附加分类元数据不决定准入");
    CHECK(hasReason(selection, "n_unknown_limits", "reliability_incomplete"),
          "缺可靠性数据的候选保留明确拒绝原因");
    CHECK(hasReason(selection, "n_missing_source", "mos_terminal_source_missing"),
          "缺Source语义端子的候选被明确拒绝");
    CHECK(hasReason(selection, "n_io_only", "voltage_domain_unsupported"),
          "错误电压域的候选被明确拒绝");
    CHECK(hasReason(selection, "p18_alt", "polarity_mismatch") &&
          selection.rejected_reasons.at("p18_alt") ==
              std::vector<std::string>({"polarity_mismatch"}) &&
          hasReason(selection, "n_missing_cdf", "oa_master_incomplete") &&
          hasReason(selection, "n_missing_bulk_rule", "bulk_rule_incomplete") &&
          hasReason(selection, "n_no_geometry", "quantizable_geometry_missing") &&
          hasReason(selection, "n_invalid_constraint", "parameter_constraint_width_invalid"),
          "不同极性仅报告极性拒绝，其余动态准入规则保留具体原因");

    st::DeviceCatalog sortingCatalog;
    auto sameLibraryA = mos("a_same_library", st::DeviceKind::MosN, "PDK_CORE");
    auto sameLibraryB = mos("b_same_library", st::DeviceKind::MosN, "PDK_CORE");
    auto otherLibrary = mos("z_other_library", st::DeviceKind::MosN, "PDK_IO");
    auto lowerMargin = mos("c_lower_margin", st::DeviceKind::MosN, "PDK_CORE");
    auto unquantifiedMargin = mos("aa_unquantified_margin", st::DeviceKind::MosN, "PDK_CORE");
    sameLibraryA.flavor_id = "flavor_a";
    sameLibraryB.flavor_id = "flavor_b";
    otherLibrary.flavor_id = "flavor_c";
    lowerMargin.flavor_id = "flavor_d";
    unquantifiedMargin.flavor_id = "flavor_e";
    sameLibraryA.limits.max_abs_vgs = sameLibraryA.limits.max_abs_vds =
        sameLibraryA.limits.max_abs_vgb = 2.0;
    sameLibraryB.limits = sameLibraryA.limits;
    otherLibrary.limits = sameLibraryA.limits;
    lowerMargin.limits.max_abs_vgs = lowerMargin.limits.max_abs_vds =
        lowerMargin.limits.max_abs_vgb = 1.2;
    for (const auto* descriptor : {&sameLibraryA, &sameLibraryB, &otherLibrary, &lowerMargin,
                                   &unquantifiedMargin}) {
        CHECK(sortingCatalog.Add(*descriptor, diagnostic), "排序目录接受合法候选");
    }
    const auto sorted = st::SelectCrossFlavorCandidates(original, sortingCatalog, "core");
    CHECK(sorted.accepted.size() == 5 &&
          sorted.accepted[0]->master == "a_same_library" &&
          sorted.accepted[1]->master == "b_same_library" &&
          sorted.accepted[2]->master == "z_other_library" &&
          sorted.accepted[3]->master == "c_lower_margin" &&
          sorted.accepted[4]->master == "aa_unquantified_margin",
          "候选按可证实可靠性余量、同PDK Library和master名字典序稳定排序，未量化余量不冒充最大值");

    const auto jsonFirst = st::WritePdkCatalogJson(catalog);
    const auto jsonSecond = st::WritePdkCatalogJson(catalog);
    CHECK(jsonFirst == jsonSecond && jsonFirst.find("\"n18_alt\"") != std::string::npos &&
          jsonFirst.find("\"parameter_constraints\"") != std::string::npos &&
          jsonFirst.find("\"normalized_to_cdf\"") != std::string::npos &&
          jsonFirst.find("\"device_family\":\"core_nmos\"") != std::string::npos &&
          jsonFirst.find("\"flavor_id\":\"3v3\"") != std::string::npos &&
          jsonFirst.find("\"min_width\":1") != std::string::npos &&
          jsonFirst.find("\"max_width\":9") != std::string::npos &&
          jsonFirst.find("\"min_length\":2") != std::string::npos &&
          jsonFirst.find("\"max_length\":10") != std::string::npos &&
          jsonFirst.find("\"min_resistance\":3") != std::string::npos &&
          jsonFirst.find("\"max_resistance\":11") != std::string::npos &&
          jsonFirst.find("\"max_abs_vgs\":4") != std::string::npos &&
          jsonFirst.find("\"max_abs_vds\":5") != std::string::npos &&
          jsonFirst.find("\"max_abs_vgb\":6") != std::string::npos &&
          jsonFirst.find("\"max_stack_level\":7") != std::string::npos &&
          jsonFirst.find("\"isolated_well\":true") != std::string::npos &&
          jsonFirst.find("\"source_drain_interchangeable\":true") != std::string::npos,
          "PDK目录JSON稳定且完整输出尺寸、可靠性、Well与D/S归一化字段");

    std::cout << "\n========================================\n";
    if (failures == 0) std::cout << "PdkCatalog tests passed\n";
    else std::cout << failures << " PdkCatalog tests failed\n";
    return failures == 0 ? 0 : 1;
}
