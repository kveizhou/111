#include "st/OperatingPoint.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                          \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                          \
        }                                                                        \
    } while (false)

const char* kMosHeader =
    "instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\n";
const char* kIdentityHeader =
    "dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\t"
    "parameter_hash\tsolver_version\ttotal_supply_current\n";

void write(const std::filesystem::path& path, const std::string& contents)
{
    std::filesystem::create_directories(path.parent_path());
    std::ofstream(path) << contents;
}

bool load(const std::filesystem::path& identity,
          const std::filesystem::path& mos,
          st::OperatingPointSnapshot& snapshot,
          std::vector<st::Diagnostic>& diagnostics)
{
    diagnostics.clear();
    return st::LoadOperatingPointTsv(identity, mos, snapshot, diagnostics);
}

} // namespace

int main()
{
    const auto root = std::filesystem::temp_directory_path() /
        "st_operating_point_test";
    std::filesystem::remove_all(root);
    std::filesystem::create_directories(root);
    const auto identity = root / "identity.tsv";
    const auto mos = root / "mos.tsv";

    write(identity, std::string(kIdentityHeader) +
        "dut-a\tbench-a\tpdk-1\ttt_25c\ttopo-a\tparam-a\tsolver-1\t0\n");
    write(mos, std::string(kMosHeader) +
        "MN0\t1.2\t0.8\t0\t0\t0.00012\t0.8\t1.2\t0\t0.31\t0.17\t0\n"
        "MP0\t0\t0.4\t1.2\t1.2\t-0.00008\t-0.8\t-1.2\t0\t-0.29\t-0.16\t2e-13\n");
    st::OperatingPointSnapshot snapshot;
    std::vector<st::Diagnostic> diagnostics;
    CHECK(load(identity, mos, snapshot, diagnostics),
          "完整NMOS/PMOS工作点TSV可加载");
    CHECK(snapshot.identity.dut_hash == "dut-a" &&
          snapshot.identity.bench_hash == "bench-a" &&
          snapshot.identity.pdk_version == "pdk-1" &&
          snapshot.identity.corner == "tt_25c" &&
          snapshot.identity.topology_hash == "topo-a" &&
          snapshot.identity.parameter_hash == "param-a" &&
          snapshot.identity.solver_version == "solver-1" &&
          snapshot.total_supply_current == 0.0 && snapshot.mos.size() == 2,
          "七项身份字段、零电流和两条MOS记录完整保真");
    CHECK(snapshot.mos.at("MN0").vs == 0.0 &&
          snapshot.mos.at("MN0").cgg == 0.0 &&
          snapshot.mos.at("MP0").id == -0.00008 &&
          snapshot.mos.at("MP0").vdsat == -0.16,
          "所有有限数包括0和负号原样保留");

    write(identity, std::string(kIdentityHeader) +
        "dut-a\tbench-a\tpdk-1\ttt_25c\ttopo-a\tparam-a\tsolver-1\tNA\n");
    CHECK(load(identity, mos, snapshot, diagnostics), "optional total supply current can be unavailable");
    CHECK(!snapshot.total_supply_current.has_value(), "unavailable current is explicitly absent");
    CHECK(st::WriteOperatingPointTsv(root / "optional/identity.tsv", root / "optional/mos.tsv",
                                    snapshot, diagnostics), "unavailable total current serializes");
    std::ifstream optionalIdentity(root / "optional/identity.tsv");
    std::string optionalText((std::istreambuf_iterator<char>(optionalIdentity)), {});
    CHECK(optionalText.find("\tNA\n") != std::string::npos, "missing total current round-trips as NA, never zero");
    write(root / "resistor.tsv", "not_a_valid_resistor_header\n");
    diagnostics.clear();
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "存在电阻证据文件时，不允许忽略损坏的电阻记录");
    std::filesystem::remove(root / "resistor.tsv");

    const auto resistor = root / "resistor.tsv";
    const std::string resistorHeader =
        "instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\tmax_voltage\t"
        "max_power\tmax_current\trating_source\n";
    const std::string validResistor =
        "R_REF_N\trhrpo\tw=2u,l=10u\t1.2\t0.2\t0.0001\t1.5\t0.0002\t0\t"
        "pdk-model/tt_25c\n";
    write(resistor, resistorHeader + validResistor);
    CHECK(st::LoadOperatingPointTsv(root, snapshot, diagnostics) &&
          snapshot.resistors.size() == 1 &&
          snapshot.resistors.at("R_REF_N").current == 0.0001,
          "电阻实际端电位、电流及当前几何/Corner额定值可加载");
    st::OperatingPointSnapshot roundTrip;
    CHECK(st::WriteOperatingPointTsv(root / "copy/identity.tsv",
                                     root / "copy/mos.tsv",
                                     root / "copy/resistor.tsv",
                                     snapshot, diagnostics) &&
          st::LoadOperatingPointTsv(root / "copy", roundTrip, diagnostics) &&
          roundTrip.resistors.at("R_REF_N").max_power == 0.0002,
          "电阻额定值写入后回读保真");
    write(resistor, resistorHeader + validResistor + validResistor);
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "重复电阻实例拒绝");
    write(resistor, resistorHeader +
        "R_REF_N\trhrpo\tw=2u,l=10u\t1.2\t0.2\tnan\t1.5\t0.0002\t0\tpdk\n");
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "非有限电阻电流拒绝");
    write(resistor, resistorHeader +
        "R_REF_N\trhrpo\tw=2u,l=10u\t1.2\t0.2\t0.0001\t0\t0.0002\t0\tpdk\n");
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "缺额定电压拒绝");
    write(resistor, resistorHeader +
        "R_REF_N\trhrpo\tw=2u,l=10u\t1.2\t0.2\t0.0001\t1.5\t0\t0\tpdk\n");
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "功耗与电流额定均缺失时拒绝");
    write(resistor, resistorHeader +
        "R_REF_N\trhrpo\tw=2u,l=10u\t1.2\t0.2\t0.0001\t1.5\t0.0002\t0\t\n");
    CHECK(!st::LoadOperatingPointTsv(root, snapshot, diagnostics),
          "额定来源缺失时拒绝");
    std::filesystem::remove(resistor);
    CHECK(!st::LoadOperatingPointTsv(identity, mos, resistor,
                                     snapshot, diagnostics),
          "显式要求电阻证据时缺文件拒绝");

    const auto expected = snapshot.identity;
    CHECK(st::IsReusable(snapshot, expected),
          "七个身份字段完全一致时快照可复用");
    for (int field = 0; field < 7; ++field) {
        auto changed = expected;
        if (field == 0) changed.dut_hash = "dut-b";
        if (field == 1) changed.bench_hash = "bench-b";
        if (field == 2) changed.pdk_version = "pdk-2";
        if (field == 3) changed.corner = "ss_125c";
        if (field == 4) changed.topology_hash = "topo-b";
        if (field == 5) changed.parameter_hash = "param-b";
        if (field == 6) changed.solver_version = "solver-2";
        CHECK(!st::IsReusable(snapshot, changed),
              "任一身份字段不同时快照不可复用");
    }
    st::OperatingPointSnapshot emptyIdentitySnapshot;
    CHECK(!st::IsReusable(emptyIdentitySnapshot, {}),
          "全空身份不能因形式相等而被复用");

    write(mos,
        "instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tcgg\n"
        "MN0\t1\t1\t0\t0\t1e-4\t1\t1\t0\t0.3\t1e-13\n");
    CHECK(!load(identity, mos, snapshot, diagnostics) && !diagnostics.empty() &&
          diagnostics.front().code == st::DiagCode::MissingInput,
          "缺失vdsat列被拒绝并返回MissingInput");

    write(mos, std::string(kMosHeader) +
        "MN0\t1\t1\t0\t0\t1e-4\t1\t1\t0\t0.3\t0.1\t1e-13\n"
        "MN0\t1\t1\t0\t0\t1e-4\t1\t1\t0\t0.3\t0.1\t1e-13\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "重复MOS实例记录被拒绝");

    write(mos, std::string(kMosHeader) +
        "MN0\t1\t1\t0\t0\tnan\t1\t1\t0\t0.3\t0.1\t1e-13\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "NaN工作点被拒绝");
    write(mos, std::string(kMosHeader) +
        "MN0\t1\t1\t0\t0\tinf\t1\t1\t0\t0.3\t0.1\t1e-13\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "Inf工作点被拒绝");
    write(mos, std::string(kMosHeader) +
        "MN0\t1\t1\t0\t0\t12uA\t1\t1\t0\t0.3\t0.1\t1e-13\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "带未授权后缀的坏数字被拒绝");

    write(mos, kMosHeader);
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "header-only MOS TSV被拒绝");
    write(mos, std::string(kMosHeader) +
        "MN0\t1\t1\t0\t0\t1e-4\t1\t1\t0\t0.3\t0.1\t1e-13\n");

    write(identity, std::string(kIdentityHeader) +
        "\tbench-a\tpdk-1\ttt_25c\ttopo-a\tparam-a\tsolver-1\t1e-3\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "空身份字段被拒绝");
    write(identity, std::string(kIdentityHeader) +
        "dut-a\tbench-a\tpdk-1\ttt_25c\t1e-3\n"
        "dut-a\tbench-a\tpdk-1\ttt_25c\t1e-3\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "重复身份数据记录被拒绝");
    write(identity, std::string(kIdentityHeader) +
        "dut-a\tbench-a\tpdk-1\ttt_25c\tbroken\n");
    CHECK(!load(identity, mos, snapshot, diagnostics),
          "非数字总电源电流被拒绝");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Operating point tests passed\n";
    } else {
        std::cout << failures << " operating point tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
