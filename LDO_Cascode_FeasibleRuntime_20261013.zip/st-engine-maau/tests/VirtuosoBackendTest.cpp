#include "st/JsonWriter.h"
#include "st/Materialization.h"
#include "st/Standalone.h"
#include "st/VirtuosoBackend.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace {

int failures = 0;

#define CHECK(condition, message)                                                \
    do {                                                                         \
        if (!(condition)) {                                                      \
            ++failures;                                                          \
            std::cout << "FAIL: " << message << "\n";                          \
        } else {                                                                 \
            std::cout << "ok:   " << message << "\n";                          \
        }                                                                        \
    } while (false)

st::Netlist baseCircuit()
{
    st::Netlist result;
    st::Subckt core;
    core.name = "core";
    core.instances.push_back({"M0", {"OUT", "CTRL", "VSS", "VSS"},
        "nmos", {{"w", "2u"}, {"l", "240n"}}});
    result.subckts.push_back(core);
    return result;
}

st::Netlist expectedCircuit()
{
    auto result = baseCircuit();
    auto* core = result.find("core");
    core->find("M0")->nets[0] = "M0_MID";
    core->instances.push_back({"M0_CAS", {"OUT", "CTRL", "M0_MID", "VSS"},
        "nmos", {{"w", "2u"}, {"l", "240n"}}});
    return result;
}

st::Netlist packagedExpectedCircuit()
{
    st::Netlist result;
    st::Subckt core;
    core.name = "core";
    core.instances.push_back({"M0", {"OUT", "CTRL", "VSS"},
        "oa_STAGING__core__TV0001__PKG0001", {}});
    result.subckts.push_back(core);

    st::Subckt package;
    package.name = "oa_STAGING__core__TV0001__PKG0001";
    package.pins = {"OUT", "CTRL", "VSS"};
    package.instances.push_back({"M0", {"M0_MID", "CTRL", "VSS", "VSS"},
        "nmos", {{"w", "2u"}, {"l", "240n"}}});
    package.instances.push_back({"M0_CAS", {"OUT", "CTRL", "M0_MID", "VSS"},
        "nmos", {{"w", "2u"}, {"l", "240n"}}});
    result.subckts.push_back(package);
    return result;
}

std::string option(const std::vector<std::string>& arguments, const std::string& name)
{
    for (std::size_t index = 0; index + 1 < arguments.size(); ++index) {
        if (arguments[index] == name) return arguments[index + 1];
    }
    return {};
}

void writeText(const std::filesystem::path& path, const std::string& text)
{
    std::filesystem::create_directories(path.parent_path());
    std::ofstream(path) << text;
}

std::string readText(const std::filesystem::path& path)
{
    std::ifstream input(path);
    return {(std::istreambuf_iterator<char>(input)),
            std::istreambuf_iterator<char>()};
}

std::string validScanCatalog()
{
    return
        "master\tkind\tterminal_names\tterminal_roles\toa_library\toa_cell\toa_view\t"
        "voltage_domain\tnormalized_to_cdf\tmin_width\tmax_width\tmin_length\t"
        "max_length\tmin_resistance\tmax_resistance\tmax_abs_vgs\tmax_abs_vds\t"
        "max_abs_vgb\tmax_stack\tallowed_voltage_domains\tisolated_well\t"
        "source_drain_interchangeable\tpdk_name\tpdk_version\tmodel_name\t"
        "w_fin_formula\tparameter_constraints\tmodel_sections\tcorners\t"
        "reliability_complete\tbulk_rule_complete\tprocess_identity\t"
        "kind_source\tterminal_source\tcdf_source\treliability_source\t"
        "bulk_source\tdomain_source\tcorner_source\tdevice_proof_source\n"
        "oa_PDK__n18\tmos_n\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tn18\tsymbol\t"
        "core\twidth:w,length:l\t1e-7\t1e-3\t1e-7\t1e-5\t\t\t1.2\t1.2\t1.2\t"
        "100\tcore\ttrue\ttrue\tPDK_TECH\t1.0\tn18\t\t"
        "width:w:1e-7:1e-3:1e-8:;length:l:1e-7:1e-5:1e-8:\ttt\ttt\ttrue\ttrue\t"
        "PDK_TECH\tsite_pdk_metadata\toa_symbol\tcdf\tpdk_reliability\t"
        "pdk_bulk_rule\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n"
        "oa_PDK__p18\tmos_p\tD,G,S,B\tdrain,gate,source,bulk\tPDK\tp18\tsymbol\t"
        "core\twidth:w,length:l\t1e-7\t1e-3\t1e-7\t1e-5\t\t\t1.2\t1.2\t1.2\t"
        "100\tcore\ttrue\ttrue\tPDK_TECH\t1.0\tp18\t\t"
        "width:w:1e-7:1e-3:1e-8:;length:l:1e-7:1e-5:1e-8:\ttt\ttt\ttrue\ttrue\t"
        "PDK_TECH\tsite_pdk_metadata\toa_symbol\tcdf\tpdk_reliability\t"
        "pdk_bulk_rule\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n"
        "oa_PDK__rpo\tresistor\tPLUS,MINUS\tpositive,negative\tPDK\trpo\tsymbol\t"
        "core\tresistance:r\t\t\t\t\t100\t1e6\t\t\t\t"
        "100\tcore\tfalse\tfalse\tPDK_TECH\t1.0\trpo\t\t"
        "resistance:r:100:1e6:100:\ttt\ttt\tfalse\tfalse\t"
        "PDK_TECH\tsite_pdk_metadata\toa_symbol\tcdf\t\t"
        "\tpdk_domain\tactive_model_context\tpdk_primitive_registry\n";
}

class RecordingRunner : public st::standalone::ProcessRunner {
public:
    std::vector<std::vector<std::string>> calls;
    bool omitNetlist = false;
    bool omitScanCatalog = false;
    bool omitScanIdentity = false;
    bool emptyScanIdentity = false;
    bool headerOnlyScanCatalog = false;
    bool incompleteScanIdentity = false;
    bool missingSourceIdentity = false;
    bool nameOnlyScanKind = false;
    bool omitScanPmos = false;
    std::string scanCatalogOverride;
    int scanExitCode = 0;
    bool omitOpIdentity = false;
    bool omitOpMos = false;
    bool omitOpResistor = false;
    bool emptyOpMos = false;
    bool headerOnlyOpMos = false;
    bool invalidOpIdentity = false;
    bool wrongOpCorner = false;
    bool symlinkOpIdentity = false;
    bool fifoOpIdentity = false;
    bool directoryOpIdentity = false;
    bool sabotageOpBackupCleanup = false;
    int opExitCode = 0;
    bool packagedMode = false;
    bool corruptGeneratedCell = false;

    st::standalone::ProcessResult Run(const std::vector<std::string>& arguments,
                                      const std::filesystem::path& logPath) override
    {
        calls.push_back(arguments);
        std::filesystem::create_directories(logPath.parent_path());
        std::ofstream(logPath) << "fake backend ok\n";
        if (arguments.size() > 1 && arguments[1] == "scan-pdk") {
            if (scanExitCode != 0) return {scanExitCode, "fake scan failure"};
            const auto catalog = option(arguments, "--catalog-output");
            const auto identity = option(arguments, "--identity-output");
            std::filesystem::create_directories(
                std::filesystem::path(catalog).parent_path());
            std::filesystem::create_directories(
                std::filesystem::path(identity).parent_path());
            if (!omitScanCatalog) {
                auto contents = scanCatalogOverride.empty() ? validScanCatalog() : scanCatalogOverride;
                if (nameOnlyScanKind) {
                    const std::string proven = "site_pdk_metadata";
                    const auto at = contents.find(proven);
                    if (at != std::string::npos) {
                        contents.replace(at, proven.size(), "name_inference");
                    }
                }
                if (omitScanPmos) {
                    const auto begin = contents.find("oa_PDK__p18");
                    const auto end = begin == std::string::npos
                        ? std::string::npos : contents.find('\n', begin);
                    if (begin != std::string::npos && end != std::string::npos) {
                        contents.erase(begin, end - begin + 1);
                    }
                }
                std::ofstream(catalog) << (headerOnlyScanCatalog
                    ? contents.substr(0, contents.find('\n') + 1) : contents);
            }
            if (!omitScanIdentity) {
                std::ofstream(identity) << (emptyScanIdentity ? "" :
                    "source_library\tprocess_identity\tidentity_source\tcontext_complete\t"
                    "model_context_complete\tpdk_name\tpdk_version\tscan_complete\t"
                    "diagnostic\tcandidate_libraries\n"
                    "SRC\t" + std::string(missingSourceIdentity ? "" : "PDK_TECH") +
                    "\ttech_attachment\ttrue\tfalse\tPDK_TECH\t1.0\t" +
                    std::string(incompleteScanIdentity ? "false" : "true") +
                    "\t\tPDK\n");
            }
        }
        if (arguments.size() > 1 && arguments[1] == "run-op") {
            if (opExitCode != 0) return {opExitCode, "fake operating-point failure"};
            const auto identity = option(arguments, "--identity-output");
            const auto mos = option(arguments, "--mos-output");
            std::filesystem::create_directories(
                std::filesystem::path(identity).parent_path());
            std::filesystem::create_directories(
                std::filesystem::path(mos).parent_path());
            if (!omitOpIdentity) {
                const auto identityText = invalidOpIdentity
                    ? "dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\t"
                      "parameter_hash\tsolver_version\ttotal_supply_current\n"
                      "\tbench-a\tpdk-1\ttt/25 C\ttopo-a\tparam-a\tsolver-1\t1e-3\n"
                    : "dut_hash\tbench_hash\tpdk_version\tcorner\ttopology_hash\t"
                      "parameter_hash\tsolver_version\ttotal_supply_current\n"
                      "dut-a\tbench-a\tpdk-1\t" +
                      std::string(wrongOpCorner ? "wrong-corner" :
                                  option(arguments, "--corner")) + "\t" +
                      option(arguments, "--topology-hash") + "\t" +
                      option(arguments, "--parameter-hash") + "\t" +
                      option(arguments, "--solver-version") + "\t1e-3\n";
                if (symlinkOpIdentity) {
                    const auto target = std::filesystem::path(identity).string() +
                        ".provider-target";
                    std::ofstream(target) << identityText;
                    std::filesystem::create_symlink(target, identity);
                } else if (fifoOpIdentity) {
                    ::mkfifo(identity.c_str(), 0600);
                } else if (directoryOpIdentity) {
                    std::filesystem::create_directory(identity);
                    std::ofstream(std::filesystem::path(identity) / "provider-file")
                        << "retain\n";
                } else {
                    std::ofstream(identity) << identityText;
                }
            }
            if (!omitOpMos) {
                const std::string header =
                    "instance\tvd\tvg\tvs\tvb\tid\tvgs\tvds\tvbs\tvth\tvdsat\tcgg\n";
                std::ofstream(mos) << (emptyOpMos ? "" :
                    (headerOnlyOpMos ? header : header +
                    "M0\t1.2\t0.8\t0\t0\t1e-4\t0.8\t1.2\t0\t0.3\t0.2\t1e-13\n"));
            }
            const auto resistor = option(arguments, "--resistor-output");
            if (!resistor.empty() && !omitOpResistor) {
                std::ofstream(resistor)
                    << "instance\tmaster\tgeometry\tvpos\tvneg\tcurrent\t"
                       "max_voltage\tmax_power\tmax_current\trating_source\n"
                       "R_REF_N\tpdk_r\tw=2u\t1.2\t0.2\t1e-4\t1.5\t2e-4\t0\tpdk/tt\n";
            }
            if (sabotageOpBackupCleanup) {
                const auto identityPath = std::filesystem::path(identity);
                const auto prefix = identityPath.filename().string() +
                    ".st-op-backup-";
                for (const auto& entry :
                     std::filesystem::directory_iterator(identityPath.parent_path())) {
                    if (entry.path().filename().string().rfind(prefix, 0) != 0) continue;
                    std::filesystem::remove(entry.path());
                    std::filesystem::create_directory(entry.path());
                    std::ofstream(entry.path() / "cleanup-blocker") << "retain\n";
                    break;
                }
            }
        }
        if (arguments.size() > 1 && arguments[1] == "netlist" && !omitNetlist) {
            const auto output = option(arguments, "--output");
            std::filesystem::create_directories(std::filesystem::path(output).parent_path());
            const auto logicalSubckt = option(arguments, "--core-subckt");
            const bool source = option(arguments, "--lib") == "SRC";
            auto roundTrip = source ? baseCircuit() :
                (packagedMode ? packagedExpectedCircuit() : expectedCircuit());
            if (packagedMode && !source) {
                roundTrip.subckts.erase(
                    std::remove_if(roundTrip.subckts.begin(), roundTrip.subckts.end(),
                        [&](const st::Subckt& subckt) {
                            return subckt.name != logicalSubckt;
                        }),
                    roundTrip.subckts.end());
                if (corruptGeneratedCell && logicalSubckt != "core" &&
                    !roundTrip.subckts.empty() &&
                    !roundTrip.subckts.front().instances.empty()) {
                    roundTrip.subckts.front().instances.front().nets.front() = "WRONG_NET";
                }
            } else {
                roundTrip.subckts.front().name = logicalSubckt.empty()
                    ? option(arguments, "--cell") : logicalSubckt;
            }
            std::ofstream(output) << st::emitSpectre(roundTrip);
        }
        return {0, {}};
    }
};

st::OaMaterializationPlan plan(const std::filesystem::path& root)
{
    st::OaMaterializationPlan result;
    result.source = {"SRC", "core", "schematic", root.string(), "r1"};
    result.target = {"STAGING", "core__staging", "schematic", root.string(), "r1"};
    result.clone_map.push_back({result.source, result.target, "/"});
    result.preview = {"TV0001", "initial", "standalone-v1"};
    st::OaCreateInstance create;
    create.hierarchy_path = "/";
    create.name = "M0_CAS";
    create.master = {"PDK", "nmos", "symbol"};
    create.expected_terminal_count = 4;
    create.connections = {{"Drain", "D", "OUT"}, {"Gate", "G", "CTRL"},
                          {"Source", "S", "M0_MID"}, {"Bulk", "B", "VSS"}};
    result.create_instances.push_back(create);
    result.wires = {{"/", "OUT", {{0, 0}, {1, 0}}},
                    {"/", "CTRL", {{0, 1}, {1, 1}}},
                    {"/", "M0_MID", {{0, 2}, {1, 2}}},
                    {"/", "VSS", {{0, 3}, {1, 3}}}};
    return result;
}

st::OaMaterializationPlan packagedPlan(const std::filesystem::path& root)
{
    auto result = plan(root);
    result.schema_version = 2;
    result.create_instances.clear();
    result.wires.clear();

    st::OaGeneratedCell generated;
    generated.package_id = "PKG0001";
    generated.schematic = {"STAGING", "core__TV0001__PKG0001", "schematic",
                           root.string()};
    generated.symbol = {"STAGING", "core__TV0001__PKG0001", "symbol",
                        root.string()};
    generated.symbol_lower_left = {-1.5, -1.5};
    generated.symbol_upper_right = {1.5, 1.5};
    const std::string scope = "/@generated/PKG0001";
    generated.create_instances.push_back({scope, "M0",
        {"PDK", "nmos", "symbol"}, {0.0, 0.0}, "R0",
        {{"Drain", "D", "M0_MID"}, {"Gate", "G", "CTRL"},
         {"Source", "S", "VSS"}, {"Bulk", "B", "VSS"}}, 4,
        {{"w", "2u"}, {"l", "240n"}}});
    generated.create_instances.push_back({scope, "M0_CAS",
        {"PDK", "nmos", "symbol"}, {0.0, 3.0}, "R0",
        {{"Drain", "D", "OUT"}, {"Gate", "G", "CTRL"},
         {"Source", "S", "M0_MID"}, {"Bulk", "B", "VSS"}}, 4,
        {{"w", "2u"}, {"l", "240n"}}});
    generated.create_ports = {
        {scope, "OUT", "inputOutput", "OUT", {-4.0, 1.0}},
        {scope, "CTRL", "inputOutput", "CTRL", {-4.0, 0.0}},
        {scope, "VSS", "inputOutput", "VSS", {-4.0, -1.0}},
    };
    generated.direct_wires.push_back(
        {scope, "M0_MID", "M0", "D", "M0_CAS", "S"});
    result.generated_cells.push_back(generated);

    st::OaCreateInstance wrapper;
    wrapper.hierarchy_path = "/";
    wrapper.name = "M0";
    wrapper.master = generated.symbol;
    wrapper.expected_terminal_count = 3;
    wrapper.connections = {{"Other", "OUT", "OUT"},
                           {"Other", "CTRL", "CTRL"},
                           {"Other", "VSS", "VSS"}};
    result.create_instances.push_back(wrapper);
    return result;
}

} // namespace

int main()
{
    const auto root = std::filesystem::temp_directory_path() / "st_backend_test";
    std::filesystem::remove_all(root);
    std::filesystem::create_directories(root);

    RecordingRunner runner;
    st::standalone::BackendPaths paths;
    paths.cds_lib = root / "cds.lib";
    paths.source_roundtrip = root / "after/source_roundtrip.scs";
    paths.target_roundtrip = root / "after/core_roundtrip.scs";
    paths.log_dir = root / "logs";
    paths.core_subckt = "core";
    std::ofstream(paths.cds_lib) << "DEFINE SRC " << root.string() << "\n";
    st::standalone::ProcessVirtuosoBackend backend("/opt/site/st_virtuoso_backend",
                                                   paths, runner);

    const st::standalone::PdkScanOutputs scanOutputs{
        root / "before/pdk/device_catalog.tsv",
        root / "before/pdk/pdk_identity.tsv",
    };
    const auto canonicalRoot = std::filesystem::canonical(root);
    const auto expectedCatalogPath =
        canonicalRoot / "before/pdk/device_catalog.tsv";
    const auto expectedIdentityPath =
        canonicalRoot / "before/pdk/pdk_identity.tsv";
    const st::CellViewRef scanSource{"SRC", "core", "schematic", root.string(), "r1"};
    const auto scanned = backend.ScanPdk(scanSource, scanOutputs);
    CHECK(scanned.ok && scanned.log_path == (root / "logs/scan_pdk.log").string() &&
          scanned.artifact_path == expectedCatalogPath.parent_path().string(),
          "PDK扫描成功时返回固定日志和扫描主目录");
    CHECK(runner.calls.size() == 1 && runner.calls.front() == std::vector<std::string>({
              "/opt/site/st_virtuoso_backend", "scan-pdk",
              "--cds-lib", paths.cds_lib.string(),
              "--lib", "SRC", "--cell", "core", "--view", "schematic",
              "--catalog-output", expectedCatalogPath.string(),
              "--identity-output", expectedIdentityPath.string()}),
          "PDK扫描命令只包含规定参数且顺序固定");
    st::DeviceCatalog scannedCatalog;
    std::vector<st::Diagnostic> scanDiagnostics;
    CHECK(st::standalone::LoadDeviceCatalogTsv(
              scanOutputs.raw_catalog_tsv, scannedCatalog, scanDiagnostics) &&
          scannedCatalog.Find("oa_PDK__n18") != nullptr,
          "PDK扫描成功夹具可由Task2完整TSV loader读取");

    CHECK(scannedCatalog.Find("oa_PDK__rpo") != nullptr &&
          !scannedCatalog.Find("oa_PDK__rpo")->reliability_complete &&
          !scannedCatalog.Find("oa_PDK__rpo")->bulk_rule_complete,
          "普通电阻如实保留空MOS规则及false完整标记");
    const auto inventoryVariant = [](bool badProof) {
        std::istringstream input(validScanCatalog());
        std::string header, row, out;
        std::getline(input, header);
        out = header + '\n';
        std::vector<std::string> names;
        std::istringstream columns(header);
        for (std::string value; std::getline(columns, value, '\t');) names.push_back(value);
        while (std::getline(input, row)) {
            std::vector<std::string> values;
            std::istringstream fields(row);
            for (std::string value; std::getline(fields, value, '\t');) values.push_back(value);
            values.resize(names.size());
            const auto set = [&](const std::string& key, const std::string& value) {
                values[std::find(names.begin(), names.end(), key) - names.begin()] = value;
            };
            if (values.front() == "oa_PDK__n18") {
                set("terminal_names", "D,G,S");
                set("terminal_roles", "drain,gate,source");
                for (const auto& key : {"cdf_source", "bulk_source", "reliability_source",
                                       "domain_source", "corner_source", "parameter_constraints",
                                       "max_abs_vgs", "max_abs_vds", "max_abs_vgb"}) set(key, "");
                set("reliability_complete", "false");
                set("bulk_rule_complete", "false");
                if (badProof) set("terminal_source", "guess_by_name");
            }
            for (std::size_t i = 0; i < values.size(); ++i) {
                if (i) out += '\t';
                out += values[i];
            }
            out += '\n';
        }
        return out;
    };
    RecordingRunner threePinRunner;
    threePinRunner.scanCatalogOverride = inventoryVariant(false);
    st::standalone::ProcessVirtuosoBackend threePinBackend(
        "/opt/site/st_virtuoso_backend", paths, threePinRunner);
    CHECK(threePinBackend.ScanPdk(scanSource, scanOutputs).ok,
          "已证明三端MOS可进入清单而不虚构CDF/Bulk/可靠性");
    RecordingRunner unprovenPinRunner;
    unprovenPinRunner.scanCatalogOverride = inventoryVariant(true);
    st::standalone::ProcessVirtuosoBackend unprovenPinBackend(
        "/opt/site/st_virtuoso_backend", paths, unprovenPinRunner);
    CHECK(!unprovenPinBackend.ScanPdk(scanSource, scanOutputs).ok &&
          !std::filesystem::exists(scanOutputs.raw_catalog_tsv) &&
          !std::filesystem::exists(scanOutputs.pdk_identity_tsv),
          "端子来源推断时拒绝清单并清理正式双输出");

    RecordingRunner failedScanRunner;
    failedScanRunner.scanExitCode = 9;
    st::standalone::ProcessVirtuosoBackend failedScanBackend(
        "/opt/site/st_virtuoso_backend", paths, failedScanRunner);
    CHECK(!failedScanBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描后端非零退出时失败");

    RecordingRunner missingScanRunner;
    missingScanRunner.omitScanCatalog = true;
    st::standalone::ProcessVirtuosoBackend missingScanBackend(
        "/opt/site/st_virtuoso_backend", paths, missingScanRunner);
    CHECK(!missingScanBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描退出0但catalog缺失时仍失败");

    RecordingRunner missingIdentityRunner;
    missingIdentityRunner.omitScanIdentity = true;
    st::standalone::ProcessVirtuosoBackend missingIdentityBackend(
        "/opt/site/st_virtuoso_backend", paths, missingIdentityRunner);
    CHECK(!missingIdentityBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描退出0但identity缺失时仍失败");

    RecordingRunner emptyScanRunner;
    emptyScanRunner.emptyScanIdentity = true;
    st::standalone::ProcessVirtuosoBackend emptyScanBackend(
        "/opt/site/st_virtuoso_backend", paths, emptyScanRunner);
    CHECK(!emptyScanBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描退出0但identity为空时仍失败");

    RecordingRunner headerOnlyScanRunner;
    headerOnlyScanRunner.headerOnlyScanCatalog = true;
    st::standalone::ProcessVirtuosoBackend headerOnlyScanBackend(
        "/opt/site/st_virtuoso_backend", paths, headerOnlyScanRunner);
    const auto headerOnlyStatus =
        headerOnlyScanBackend.ScanPdk(scanSource, scanOutputs);
    CHECK(!headerOnlyStatus.ok &&
          !std::filesystem::exists(expectedCatalogPath) &&
          !std::filesystem::exists(expectedIdentityPath),
          "PDK扫描拒绝header-only catalog且不保留看似有效的正式产物");

    RecordingRunner incompleteIdentityRunner;
    incompleteIdentityRunner.incompleteScanIdentity = true;
    st::standalone::ProcessVirtuosoBackend incompleteIdentityBackend(
        "/opt/site/st_virtuoso_backend", paths, incompleteIdentityRunner);
    const auto incompleteIdentityStatus =
        incompleteIdentityBackend.ScanPdk(scanSource, scanOutputs);
    CHECK(!incompleteIdentityStatus.ok &&
          !std::filesystem::exists(expectedCatalogPath) &&
          !std::filesystem::exists(expectedIdentityPath),
          "PDK扫描拒绝scan_complete=false且清理无效正式产物");

    RecordingRunner missingSourceIdentityRunner;
    missingSourceIdentityRunner.missingSourceIdentity = true;
    st::standalone::ProcessVirtuosoBackend missingSourceIdentityBackend(
        "/opt/site/st_virtuoso_backend", paths, missingSourceIdentityRunner);
    CHECK(!missingSourceIdentityBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描拒绝空source process identity");

    RecordingRunner nameOnlyRunner;
    nameOnlyRunner.nameOnlyScanKind = true;
    st::standalone::ProcessVirtuosoBackend nameOnlyBackend(
        "/opt/site/st_virtuoso_backend", paths, nameOnlyRunner);
    CHECK(!nameOnlyBackend.ScanPdk(scanSource, scanOutputs).ok,
          "PDK扫描拒绝仅靠Cell/Model名推断的器件类型");

    RecordingRunner noPmosRunner;
    noPmosRunner.omitScanPmos = true;
    st::standalone::ProcessVirtuosoBackend noPmosBackend(
        "/opt/site/st_virtuoso_backend", paths, noPmosRunner);
    CHECK(noPmosBackend.ScanPdk(scanSource, scanOutputs).ok,
          "器件清单无需提前满足VBIAS模板所需N/P/R组合");

    const auto collision = root / "collision.tsv";
    std::ofstream(collision) << "must remain\n";
    RecordingRunner collisionRunner;
    st::standalone::ProcessVirtuosoBackend collisionBackend(
        "/opt/site/st_virtuoso_backend", paths, collisionRunner);
    const st::standalone::PdkScanOutputs collidingOutputs{
        root / "same/../collision.tsv", collision,
    };
    const auto collisionStatus = collisionBackend.ScanPdk(scanSource, collidingOutputs);
    std::ifstream collisionInput(collision);
    const std::string collisionText((std::istreambuf_iterator<char>(collisionInput)),
                                    std::istreambuf_iterator<char>());
    CHECK(!collisionStatus.ok && collisionRunner.calls.empty() &&
          collisionText == "must remain\n",
          "PDK扫描在清理前拒绝规范化后相同的双输出路径");

    const auto realOutputDirectory = root / "real-output";
    const auto aliasOutputDirectory = root / "alias-output";
    std::filesystem::create_directories(realOutputDirectory);
    std::filesystem::create_directory_symlink(
        realOutputDirectory, aliasOutputDirectory);
    const auto aliasedCollision = realOutputDirectory / "same.tsv";
    std::ofstream(aliasedCollision) << "symlink target must remain\n";
    RecordingRunner aliasedCollisionRunner;
    st::standalone::ProcessVirtuosoBackend aliasedCollisionBackend(
        "/opt/site/st_virtuoso_backend", paths, aliasedCollisionRunner);
    const auto aliasedCollisionStatus = aliasedCollisionBackend.ScanPdk(
        scanSource, {aliasedCollision, aliasOutputDirectory / "same.tsv"});
    std::ifstream aliasedCollisionInput(aliasedCollision);
    const std::string aliasedCollisionText(
        (std::istreambuf_iterator<char>(aliasedCollisionInput)),
        std::istreambuf_iterator<char>());
    CHECK(!aliasedCollisionStatus.ok && aliasedCollisionRunner.calls.empty() &&
          aliasedCollisionText == "symlink target must remain\n",
          "PDK扫描在清理前拒绝目录符号链接指向的同一输出文件");

    const auto temporaryCollisionCatalog = root / "temporary-collision/catalog.tsv";
    const auto temporaryCollisionIdentity = root / "temporary-collision/catalog.tsv.tmp";
    std::filesystem::create_directories(temporaryCollisionCatalog.parent_path());
    std::ofstream(temporaryCollisionCatalog) << "catalog must remain\n";
    std::ofstream(temporaryCollisionIdentity) << "identity must remain\n";
    RecordingRunner temporaryCollisionRunner;
    st::standalone::ProcessVirtuosoBackend temporaryCollisionBackend(
        "/opt/site/st_virtuoso_backend", paths, temporaryCollisionRunner);
    const auto temporaryCollisionStatus = temporaryCollisionBackend.ScanPdk(
        scanSource, {temporaryCollisionCatalog, temporaryCollisionIdentity});
    std::ifstream temporaryCatalogInput(temporaryCollisionCatalog);
    std::ifstream temporaryIdentityInput(temporaryCollisionIdentity);
    const std::string temporaryCatalogText(
        (std::istreambuf_iterator<char>(temporaryCatalogInput)),
        std::istreambuf_iterator<char>());
    const std::string temporaryIdentityText(
        (std::istreambuf_iterator<char>(temporaryIdentityInput)),
        std::istreambuf_iterator<char>());
    CHECK(!temporaryCollisionStatus.ok && temporaryCollisionRunner.calls.empty() &&
          temporaryCatalogText == "catalog must remain\n" &&
          temporaryIdentityText == "identity must remain\n",
          "PDK扫描在清理前拒绝catalog临时路径等于identity正式路径");

    const auto reverseCollisionCatalog = root / "reverse-collision/identity.tsv.tmp";
    const auto reverseCollisionIdentity = root / "reverse-collision/identity.tsv";
    std::filesystem::create_directories(reverseCollisionCatalog.parent_path());
    std::ofstream(reverseCollisionCatalog) << "reverse catalog must remain\n";
    std::ofstream(reverseCollisionIdentity) << "reverse identity must remain\n";
    RecordingRunner reverseCollisionRunner;
    st::standalone::ProcessVirtuosoBackend reverseCollisionBackend(
        "/opt/site/st_virtuoso_backend", paths, reverseCollisionRunner);
    const auto reverseCollisionStatus = reverseCollisionBackend.ScanPdk(
        scanSource, {reverseCollisionCatalog, reverseCollisionIdentity});
    std::ifstream reverseCatalogInput(reverseCollisionCatalog);
    std::ifstream reverseIdentityInput(reverseCollisionIdentity);
    const std::string reverseCatalogText(
        (std::istreambuf_iterator<char>(reverseCatalogInput)),
        std::istreambuf_iterator<char>());
    const std::string reverseIdentityText(
        (std::istreambuf_iterator<char>(reverseIdentityInput)),
        std::istreambuf_iterator<char>());
    CHECK(!reverseCollisionStatus.ok && reverseCollisionRunner.calls.empty() &&
          reverseCatalogText == "reverse catalog must remain\n" &&
          reverseIdentityText == "reverse identity must remain\n",
          "PDK扫描在清理前拒绝identity临时路径等于catalog正式路径");

    runner.calls.clear();
    const auto originalCwd = std::filesystem::current_path();
    std::filesystem::current_path(root);
    const st::standalone::PdkScanOutputs relativeOutputs{
        "relative_catalog.tsv", "relative/identity.tsv",
    };
    const auto expectedRelativeCatalog =
        std::filesystem::absolute(relativeOutputs.raw_catalog_tsv).lexically_normal();
    const auto expectedRelativeIdentity =
        std::filesystem::absolute(relativeOutputs.pdk_identity_tsv).lexically_normal();
    const auto relativeStatus = backend.ScanPdk(scanSource, relativeOutputs);
    std::filesystem::current_path(originalCwd);
    CHECK(relativeStatus.ok,
          "PDK扫描接受单文件和子目录相对输出");
    CHECK(runner.calls.size() == 1,
          "相对输出PDK扫描只调用一次后端");
    const auto actualRelativeCatalog = option(runner.calls.front(), "--catalog-output");
    const auto actualRelativeIdentity = option(runner.calls.front(), "--identity-output");
    CHECK(actualRelativeCatalog == expectedRelativeCatalog.string(),
          "catalog相对路径绝对化，actual=" + actualRelativeCatalog +
              " expected=" + expectedRelativeCatalog.string());
    CHECK(actualRelativeIdentity == expectedRelativeIdentity.string(),
          "identity相对路径绝对化，actual=" + actualRelativeIdentity +
              " expected=" + expectedRelativeIdentity.string());
    CHECK(std::filesystem::exists(expectedRelativeCatalog) &&
          std::filesystem::exists(expectedRelativeIdentity),
          "PDK扫描相对输出实际落在调用者cwd而非后端切换后的目录");

    runner.calls.clear();
    const st::CellViewRef opDut{"DERIVED", "core__TV0001", "schematic", {}, "r2"};
    const st::CellViewRef opBench{"BENCH", "tb_core", "schematic", {}, "r7"};
    const st::standalone::OperatingPointOutputs opOutputs{
        root / "analysis/op/identity.tsv", root / "analysis/op/mos.tsv",
    };
    const st::AnalysisIdentity opIdentity{"dut-a", "bench-a", "pdk-1",
        "tt/25 C", "topo-a", "param-a", "solver-1"};
    const auto identityFor = [&](const std::string& corner) {
        auto identity = opIdentity;
        identity.corner = corner;
        return identity;
    };
    const auto expectedOpIdentity =
        canonicalRoot / "analysis/op/identity.tsv";
    const auto expectedOpMos = canonicalRoot / "analysis/op/mos.tsv";
    const auto opStatus = backend.RunOperatingPoint(
        opDut, opBench, opIdentity, opOutputs);
    CHECK(opStatus.ok &&
          opStatus.log_path ==
              (root / "logs/run_op_tt_25_C_topo_a_param_a.log").string() &&
          opStatus.artifact_path == expectedOpIdentity.parent_path().string(),
          "run-op成功时返回安全Corner日志和分析目录");
    CHECK(runner.calls.size() == 1 && runner.calls.front() ==
          std::vector<std::string>({
              "/opt/site/st_virtuoso_backend", "run-op",
              "--cds-lib", paths.cds_lib.string(),
              "--dut-lib", "DERIVED", "--dut-cell", "core__TV0001",
              "--dut-view", "schematic",
              "--bench-lib", "BENCH", "--bench-cell", "tb_core",
              "--bench-view", "schematic",
              "--corner", "tt/25 C",
              "--dut-hash", "dut-a", "--bench-hash", "bench-a",
              "--pdk-version", "pdk-1", "--topology-hash", "topo-a",
              "--parameter-hash", "param-a", "--solver-version", "solver-1",
              "--identity-output", expectedOpIdentity.string(),
              "--mos-output", expectedOpMos.string()}),
          "run-op只启动一次并完整传入DUT、Bench、七项身份和双输出");
    st::OperatingPointSnapshot opSnapshot;
    std::vector<st::Diagnostic> opDiagnostics;
    CHECK(st::LoadOperatingPointTsv(expectedOpIdentity, expectedOpMos,
                                    opSnapshot, opDiagnostics) &&
          opSnapshot.mos.count("M0") == 1,
          "run-op成功产物可由核心OP loader解析");

    const st::standalone::OperatingPointOutputs resistorOutputs{
        root / "analysis/op-resistor/identity.tsv",
        root / "analysis/op-resistor/mos.tsv",
        root / "analysis/op-resistor/resistor.tsv"};
    runner.calls.clear();
    const auto activeCatalog = root / "analysis/pdk_scan/run_0001/raw_catalog.tsv";
    backend.UseOperatingPointCatalog(activeCatalog);
    CHECK(backend.RunOperatingPoint(opDut, opBench, opIdentity,
                                    resistorOutputs).ok &&
          option(runner.calls.back(), "--resistor-output") ==
              (canonicalRoot / "analysis/op-resistor/resistor.tsv").string() &&
          st::LoadOperatingPointTsv(resistorOutputs.identity_tsv,
                                    resistorOutputs.mos_tsv,
                                    resistorOutputs.resistor_tsv,
                                    opSnapshot, opDiagnostics) &&
          opSnapshot.resistors.count("R_REF_N") == 1,
          "三份工作点证据经后端事务传递并验证");
    CHECK(option(runner.calls.back(), "--device-catalog") == activeCatalog.string(),
          "OP使用本轮重扫通过的完整PDK目录路径");
    RecordingRunner missingResistorRunner;
    missingResistorRunner.omitOpResistor = true;
    st::standalone::ProcessVirtuosoBackend missingResistorBackend(
        "/opt/site/st_virtuoso_backend", paths, missingResistorRunner);
    writeText(resistorOutputs.resistor_tsv, "old resistor\n");
    CHECK(!missingResistorBackend.RunOperatingPoint(
              opDut, opBench, opIdentity, resistorOutputs).ok &&
          readText(resistorOutputs.resistor_tsv) == "old resistor\n",
          "缺第三份证据时后端还原旧电阻文件且拒绝放行");
    RecordingRunner conflictingResistorRunner;
    st::standalone::ProcessVirtuosoBackend conflictingResistorBackend(
        "/opt/site/st_virtuoso_backend", paths, conflictingResistorRunner);
    CHECK(!conflictingResistorBackend.RunOperatingPoint(
              opDut, opBench, opIdentity,
              {resistorOutputs.identity_tsv, resistorOutputs.mos_tsv,
               resistorOutputs.identity_tsv}).ok &&
          conflictingResistorRunner.calls.empty(),
          "电阻输出与身份输出冲突时在启动后端前拒绝");

    CHECK(std::find(runner.calls.front().begin(), runner.calls.front().end(),
                    "--candidate-netlist") == runner.calls.front().end(),
          "run-op只仿真请求的OA CellView，不存在候选网表旁路");

    RecordingRunner invalidInputRunner;
    st::standalone::ProcessVirtuosoBackend invalidInputBackend(
        "/opt/site/st_virtuoso_backend", paths, invalidInputRunner);
    auto incompleteDut = opDut;
    incompleteDut.cell.clear();
    CHECK(!invalidInputBackend.RunOperatingPoint(
              incompleteDut, opBench, identityFor("tt"), opOutputs).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在启动前拒绝不完整DUT L/C/V");
    auto incompleteBench = opBench;
    incompleteBench.view.clear();
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, incompleteBench, identityFor("tt"), opOutputs).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在启动前拒绝不完整Bench L/C/V");
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor(""), opOutputs).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在启动前拒绝空Corner");
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {{}, opOutputs.mos_tsv}).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在启动前拒绝空输出路径");

    const auto opCollision = root / "analysis/op-collision.tsv";
    std::ofstream(opCollision) << "must remain\n";
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {root / "analysis/same/../op-collision.tsv",
                                      opCollision}).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在任何清理前拒绝规范化后相同的双输出");
    const auto opTempCollision = root / "analysis/op-temp/identity.tsv";
    std::filesystem::create_directories(opTempCollision.parent_path());
    std::ofstream(opTempCollision) << "identity must remain\n";
    std::ofstream(opTempCollision.string() + ".tmp") << "mos must remain\n";
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"),
              {opTempCollision, opTempCollision.string() + ".tmp"}).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在清理前拒绝正式输出与另一临时路径冲突");

    const auto hardIdentity = root / "analysis/op-hard/identity.tsv";
    const auto hardMos = root / "analysis/op-hard/mos.tsv";
    std::filesystem::create_directories(hardIdentity.parent_path());
    std::ofstream(hardIdentity) << "hardlink must remain\n";
    std::filesystem::create_hard_link(hardIdentity, hardMos);
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {hardIdentity, hardMos}).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在清理前拒绝两正式输出硬链接同一inode");

    const auto symlinkIdentity = root / "analysis/op-symlink/identity.tsv";
    const auto symlinkMos = root / "analysis/op-symlink/mos.tsv";
    std::filesystem::create_directories(symlinkIdentity.parent_path());
    std::ofstream(symlinkIdentity) << "symlink must remain\n";
    std::filesystem::create_symlink(symlinkIdentity, symlinkMos);
    CHECK(!invalidInputBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {symlinkIdentity, symlinkMos}).ok &&
          invalidInputRunner.calls.empty(),
          "run-op在清理前拒绝两正式输出符号链接同一inode");

    const st::standalone::OperatingPointOutputs preservedOutputs{
        root / "analysis/op-preserved/identity.tsv",
        root / "analysis/op-preserved/mos.tsv",
    };
    writeText(preservedOutputs.identity_tsv, "old identity\n");
    writeText(preservedOutputs.mos_tsv, "old mos\n");
    writeText(preservedOutputs.identity_tsv.string() + ".tmp", "old identity temp\n");
    writeText(preservedOutputs.mos_tsv.string() + ".tmp", "old mos temp\n");
    RecordingRunner failedOpRunner;
    failedOpRunner.opExitCode = 70;
    st::standalone::ProcessVirtuosoBackend failedOpBackend(
        "/opt/site/st_virtuoso_backend", paths, failedOpRunner);
    CHECK(!failedOpBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), preservedOutputs).ok,
          "run-op传播provider失败");
    CHECK(readText(preservedOutputs.identity_tsv) == "old identity\n" &&
          readText(preservedOutputs.mos_tsv) == "old mos\n" &&
          readText(preservedOutputs.identity_tsv.string() + ".tmp") ==
              "old identity temp\n" &&
          readText(preservedOutputs.mos_tsv.string() + ".tmp") == "old mos temp\n",
          "run-op失败时恢复调用前已有的四个输出文件");

    const st::standalone::OperatingPointOutputs danglingOutputs{
        root / "analysis/op-dangling/identity.tsv",
        root / "analysis/op-dangling/mos.tsv",
    };
    std::filesystem::create_directories(danglingOutputs.identity_tsv.parent_path());
    const auto danglingIdentityTarget = root / "missing/old-identity.tsv";
    const auto danglingMosTarget = root / "missing/old-mos.tsv";
    const auto danglingIdentityTempTarget = root / "missing/old-identity.tmp";
    const auto danglingMosTempTarget = root / "missing/old-mos.tmp";
    std::filesystem::create_symlink(danglingIdentityTarget,
                                    danglingOutputs.identity_tsv);
    std::filesystem::create_symlink(danglingMosTarget, danglingOutputs.mos_tsv);
    std::filesystem::create_symlink(
        danglingIdentityTempTarget, danglingOutputs.identity_tsv.string() + ".tmp");
    std::filesystem::create_symlink(
        danglingMosTempTarget, danglingOutputs.mos_tsv.string() + ".tmp");
    RecordingRunner danglingFailureRunner;
    danglingFailureRunner.opExitCode = 70;
    st::standalone::ProcessVirtuosoBackend danglingFailureBackend(
        "/opt/site/st_virtuoso_backend", paths, danglingFailureRunner);
    CHECK(!danglingFailureBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), danglingOutputs).ok &&
          std::filesystem::is_symlink(
              std::filesystem::symlink_status(danglingOutputs.identity_tsv)) &&
          std::filesystem::read_symlink(danglingOutputs.identity_tsv) ==
              danglingIdentityTarget &&
          std::filesystem::is_symlink(
              std::filesystem::symlink_status(danglingOutputs.mos_tsv)) &&
          std::filesystem::read_symlink(danglingOutputs.mos_tsv) ==
              danglingMosTarget &&
          std::filesystem::read_symlink(danglingOutputs.identity_tsv.string() +
                                        ".tmp") == danglingIdentityTempTarget &&
          std::filesystem::read_symlink(danglingOutputs.mos_tsv.string() +
                                        ".tmp") == danglingMosTempTarget,
          "run-op失败时原样恢复四个调用前悬空符号链接");

    const auto rejectedObjectRoot = root / "analysis/op-rejected-objects";
    std::filesystem::create_directories(rejectedObjectRoot / "identity-dir");
    RecordingRunner rejectedDirectoryRunner;
    st::standalone::ProcessVirtuosoBackend rejectedDirectoryBackend(
        "/opt/site/st_virtuoso_backend", paths, rejectedDirectoryRunner);
    CHECK(!rejectedDirectoryBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"),
              {rejectedObjectRoot / "identity-dir",
               rejectedObjectRoot / "directory-mos.tsv"}).ok &&
          rejectedDirectoryRunner.calls.empty() &&
          std::filesystem::is_directory(rejectedObjectRoot / "identity-dir"),
          "run-op在移动前拒绝已有目录且不破坏它");
    const auto oldFifo = rejectedObjectRoot / "identity-fifo";
    ::mkfifo(oldFifo.c_str(), 0600);
    RecordingRunner rejectedFifoRunner;
    st::standalone::ProcessVirtuosoBackend rejectedFifoBackend(
        "/opt/site/st_virtuoso_backend", paths, rejectedFifoRunner);
    CHECK(!rejectedFifoBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"),
              {oldFifo, rejectedObjectRoot / "fifo-mos.tsv"}).ok &&
          rejectedFifoRunner.calls.empty() &&
          std::filesystem::is_fifo(std::filesystem::symlink_status(oldFifo)),
          "run-op在移动前拒绝已有FIFO且不挂起或破坏它");

    for (const auto& mode : {std::string("symlink"), std::string("fifo"),
                             std::string("directory")}) {
        RecordingRunner invalidObjectRunner;
        invalidObjectRunner.symlinkOpIdentity = mode == "symlink";
        invalidObjectRunner.fifoOpIdentity = mode == "fifo";
        invalidObjectRunner.directoryOpIdentity = mode == "directory";
        st::standalone::ProcessVirtuosoBackend invalidObjectBackend(
            "/opt/site/st_virtuoso_backend", paths, invalidObjectRunner);
        const auto modeRoot = root / ("analysis/op-provider-" + mode);
        writeText(modeRoot / "identity.tsv", "old identity\n");
        writeText(modeRoot / "mos.tsv", "old mos\n");
        const auto status = invalidObjectBackend.RunOperatingPoint(
            opDut, opBench, identityFor("tt"),
            {modeRoot / "identity.tsv", modeRoot / "mos.tsv"});
        CHECK(!status.ok && readText(modeRoot / "identity.tsv") == "old identity\n" &&
              readText(modeRoot / "mos.tsv") == "old mos\n",
              "run-op拒绝provider新生成的非普通文件: " + mode);
    }

    const st::standalone::OperatingPointOutputs wrongCornerOutputs{
        root / "analysis/op-wrong-corner/identity.tsv",
        root / "analysis/op-wrong-corner/mos.tsv",
    };
    writeText(wrongCornerOutputs.identity_tsv, "old identity\n");
    writeText(wrongCornerOutputs.mos_tsv, "old mos\n");
    RecordingRunner wrongCornerRunner;
    wrongCornerRunner.wrongOpCorner = true;
    st::standalone::ProcessVirtuosoBackend wrongCornerBackend(
        "/opt/site/st_virtuoso_backend", paths, wrongCornerRunner);
    CHECK(!wrongCornerBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), wrongCornerOutputs).ok &&
          readText(wrongCornerOutputs.identity_tsv) == "old identity\n" &&
          readText(wrongCornerOutputs.mos_tsv) == "old mos\n",
          "run-op拒绝不匹配Corner并恢复旧正式输出");

    const st::standalone::OperatingPointOutputs cleanupFailureOutputs{
        root / "analysis/op-cleanup-failure/identity.tsv",
        root / "analysis/op-cleanup-failure/mos.tsv",
    };
    writeText(cleanupFailureOutputs.identity_tsv, "old identity\n");
    writeText(cleanupFailureOutputs.mos_tsv, "old mos\n");
    RecordingRunner cleanupFailureRunner;
    cleanupFailureRunner.sabotageOpBackupCleanup = true;
    st::standalone::ProcessVirtuosoBackend cleanupFailureBackend(
        "/opt/site/st_virtuoso_backend", paths, cleanupFailureRunner);
    const auto cleanupFailure = cleanupFailureBackend.RunOperatingPoint(
        opDut, opBench, identityFor("tt"), cleanupFailureOutputs);
    bool retainedCleanupBackup = false;
    for (const auto& entry : std::filesystem::directory_iterator(
             cleanupFailureOutputs.identity_tsv.parent_path())) {
        if (entry.path().filename().string().rfind(
                "identity.tsv.st-op-backup-", 0) == 0 &&
            std::filesystem::is_directory(entry.path())) {
            retainedCleanupBackup = true;
        }
    }
    CHECK(!cleanupFailure.ok &&
          cleanupFailure.message.find(".st-op-backup-") != std::string::npos &&
          retainedCleanupBackup &&
          readText(cleanupFailureOutputs.identity_tsv).find("dut_hash") == 0 &&
          readText(cleanupFailureOutputs.mos_tsv).find("instance") == 0,
          "备份清理故障后保留已提交新输出并报告备份路径");

    RecordingRunner missingOpRunner;
    missingOpRunner.omitOpMos = true;
    st::standalone::ProcessVirtuosoBackend missingOpBackend(
        "/opt/site/st_virtuoso_backend", paths, missingOpRunner);
    CHECK(!missingOpBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {root / "analysis/missing/id.tsv",
                                       root / "analysis/missing/mos.tsv"}).ok,
          "run-op退出0但MOS输出缺失时仍失败");
    RecordingRunner headerOnlyOpRunner;
    headerOnlyOpRunner.headerOnlyOpMos = true;
    st::standalone::ProcessVirtuosoBackend headerOnlyOpBackend(
        "/opt/site/st_virtuoso_backend", paths, headerOnlyOpRunner);
    CHECK(!headerOnlyOpBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {root / "analysis/header/id.tsv",
                                       root / "analysis/header/mos.tsv"}).ok,
          "run-op拒绝header-only MOS输出");
    RecordingRunner invalidIdentityOpRunner;
    invalidIdentityOpRunner.invalidOpIdentity = true;
    st::standalone::ProcessVirtuosoBackend invalidIdentityOpBackend(
        "/opt/site/st_virtuoso_backend", paths, invalidIdentityOpRunner);
    CHECK(!invalidIdentityOpBackend.RunOperatingPoint(
              opDut, opBench, identityFor("tt"), {root / "analysis/bad-id/id.tsv",
                                       root / "analysis/bad-id/mos.tsv"}).ok,
          "run-op拒绝身份不完整的输出");

    runner.calls.clear();

    st::GenerationRequest request;
    request.plan = plan(root);
    request.baseline = baseCircuit();
    request.expected_variant = expectedCircuit();
    request.root_subckt = "core";
    request.work_dir = root.string();
    request.plan_path = (root / "materialization/plan.json").string();
    request.skill_script_path = "/opt/st-engine/skill/topology_variant.il";
    request.publish_clone_map.push_back({request.plan.target,
        {"DERIVED", "core__TV0001", "schematic", root.string(), "r1"}, "/"});

    st::TopologyVariantMaterializer materializer;
    const auto generated = materializer.Generate(request, backend);
    CHECK(generated.ok && !generated.ready_for_sizing &&
          generated.structural_ready && !generated.nominal_dc_ready,
          "未请求DC的宿主无关物化器只声明结构回读通过，不冒充Sizing就绪");
    std::vector<std::string> verbs;
    for (const auto& call : runner.calls) if (call.size() > 1) verbs.push_back(call[1]);
    CHECK(verbs == std::vector<std::string>({"clone", "materialize", "netlist",
                                             "netlist", "publish"}),
          "后端调用顺序固定为克隆、SKILL物化、双回读、发布");
    bool logicalSubcktForwarded = true;
    for (const auto& call : runner.calls) {
        if (call.size() > 1 && call[1] == "netlist" &&
            option(call, "--core-subckt") != "core") {
            logicalSubcktForwarded = false;
        }
    }
    CHECK(logicalSubcktForwarded,
          "源图和改名后的派生Cell回读时都保留原逻辑subckt名称");
    CHECK(std::filesystem::exists(paths.source_roundtrip) &&
          std::filesystem::exists(paths.target_roundtrip),
          "回读网表写入会话after目录");

    RecordingRunner packagedRunner;
    packagedRunner.packagedMode = true;
    st::standalone::ProcessVirtuosoBackend packagedBackend(
        "/opt/site/st_virtuoso_backend", paths, packagedRunner);
    auto packagedRequest = request;
    packagedRequest.plan = packagedPlan(root);
    packagedRequest.expected_variant = packagedExpectedCircuit();
    packagedRequest.publish_clone_map.clear();
    packagedRequest.publish_clone_map.push_back({packagedRequest.plan.target,
        {"DERIVED", "core__TV0001", "schematic", root.string(), "r1"}, "/"});
    const auto incompletePublish = materializer.Generate(packagedRequest, packagedBackend);
    CHECK(!incompletePublish.ok && packagedRunner.calls.empty(),
          "发布映射遗漏封装schematic/symbol时在任何数据库操作前拒绝");
    for (const auto& cell : packagedRequest.plan.generated_cells) {
        auto publishedSchematic = cell.schematic;
        auto publishedSymbol = cell.symbol;
        publishedSchematic.library = "DERIVED";
        publishedSymbol.library = "DERIVED";
        packagedRequest.publish_clone_map.push_back({cell.schematic, publishedSchematic,
                                                     "@" + cell.package_id + "/schematic"});
        packagedRequest.publish_clone_map.push_back({cell.symbol, publishedSymbol,
                                                     "@" + cell.package_id + "/symbol"});
    }
    const auto packaged = materializer.Generate(packagedRequest, packagedBackend);
    CHECK(packaged.ok && !packaged.ready_for_sizing &&
          packaged.structural_ready && !packaged.nominal_dc_ready,
          "父电路和封装子Cell可通过结构回读，但未请求DC时不声明Sizing就绪");
    std::vector<std::string> packagedVerbs;
    for (const auto& call : packagedRunner.calls) {
        if (call.size() > 1) packagedVerbs.push_back(call[1]);
    }
    CHECK(packagedVerbs == std::vector<std::string>({"clone", "materialize", "netlist",
                                                     "netlist", "netlist", "publish"}),
          "每个封装子Cell都额外执行一次独立回读网表化");
    CHECK(packaged.generated_netlist_paths.size() == 1 &&
          std::filesystem::exists(packaged.generated_netlist_paths.front()),
          "封装子Cell回读网表单独保存为可追溯产物");

    RecordingRunner corruptPackageRunner;
    corruptPackageRunner.packagedMode = true;
    corruptPackageRunner.corruptGeneratedCell = true;
    st::standalone::ProcessVirtuosoBackend corruptPackageBackend(
        "/opt/site/st_virtuoso_backend", paths, corruptPackageRunner);
    const auto corruptPackage = materializer.Generate(packagedRequest, corruptPackageBackend);
    CHECK(!corruptPackage.ok && !corruptPackage.ready_for_sizing &&
          corruptPackage.stage == st::MaterializationStage::VerifyRoundTrip,
          "封装内任一真实器件连线回读不一致时拒绝发布");
    CHECK(corruptPackageRunner.calls.empty() ||
          corruptPackageRunner.calls.back().size() < 2 ||
          corruptPackageRunner.calls.back()[1] != "publish",
          "封装子Cell校验失败后不调用publish");

    std::filesystem::remove(paths.source_roundtrip);
    std::filesystem::remove(paths.target_roundtrip);
    RecordingRunner missingArtifactRunner;
    missingArtifactRunner.omitNetlist = true;
    st::standalone::ProcessVirtuosoBackend missingBackend(
        "/opt/site/st_virtuoso_backend", paths, missingArtifactRunner);
    const auto missing = materializer.Generate(request, missingBackend);
    CHECK(!missing.ok && missing.stage == st::MaterializationStage::VerifySource,
          "后端返回成功但未生成网表时仍明确失败");

    std::cout << "\n========================================\n";
    if (failures == 0) {
        std::cout << "Virtuoso backend tests passed\n";
    } else {
        std::cout << failures << " Virtuoso backend tests failed\n";
    }
    return failures == 0 ? 0 : 1;
}
