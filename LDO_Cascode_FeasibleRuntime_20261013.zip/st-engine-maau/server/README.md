# 真实 LDO 服务器执行说明

当前续跑采用工程 README 顶部的 `--prepare-runtime`；需更新完整 RuntimeBridge 包，保留旧 cadence_runtime.py、旧 session 和 runs。只验证正式读取接入及集中缺项，不重跑基线，不生成 VBIAS。

2026-10-10 当前完整包：**`LDO服务器测试包_物化日志完整保留_2026-10-10.zip`**，包含此前原 MOS 显式属性保留等全部修复。本批仅修复成功 materialize 日志被截为前 240 行的问题，完整保留后面的属性复制证据；C++/电路生成/回读与发布规则不改，已编译服务器无需重编。用户当前只回传 grep 退出 1，不能据此判定生成失败；先按 [日志缺失检查](../docs/服务器结构测试_物化日志缺失检查_2026-10-10.md) 读取当前 validation.txt，不重复 generate 或删除会话。属性保留实际 OA/发布验收仍以服务器报告为准。

**此前 CDF 类型修复：** 已确认符号列表与同名 OA 字符串的区别，严格 reader 转换名称表示后继续校验端子数量、名称和唯一性。本批所需扫描政策、日志及验证文件均在当前完整源码包中；真实 OA 运行结果仍须由服务器提供。


`inspect --validation-scope structure_only` 读取真实工艺 OA/CDF，无需 Bench、仿真模型或轨网；确认/撤回/fresh 后可物化、回读和整组发布电阻/Stack，再 open。结构结果 `structural_ready=true`，DC/PVT/Sizing 为 false。下面关于 Bench、可靠性和 OP 的要求属于默认电气会话，不能再用于阻止显式结构会话；结构模式不创建 Cascode/VBIAS。

**2026-10-08 当前独立入口：** 见 `docs/standalone-pdk-server-validation.md`。独立编译、从所选源电路自动发现 PDK（可选 `--pdk-root` 覆盖），由项目内 Provider 直接调用 OCEAN/Spectre；KimiCode 只作参考。下方旧命令中的 Case/Maau 现场接入表述属于历史流程，不是当前产品必需条件；实际测试路径仍可作为该 Capless 的线索。

> 下方 `ocldo_structure_001` 命令保留为历史演示，**不能直接作为当前版本的 generate 会话命令**：它没有 Bench L/C/V、VBIAS 高低轨网，且会话号可能已使用。它现在只可能建立只读发现会话。I53 的早期“替换电阻”示例也不代表现在的“保留 MOS、Source 串电阻”语义。当前通用流程见以下说明及 `docs/023-026结构变换独立测试命令.md`。

## 当前多电路入口

每个导入电路提供自己的源 `cds.lib` 与 DUT L/C/V。用 `prepare_session.sh --source-cds-lib ... --session-dir ... --variant-lib ...` 建立全新隔离会话；示例里的 `HiAplat...`、`smicnp1p`、I52/I53 和会话号只属于已有 Capless 测试，不能当成通用配置。

当前产品 CLI 的 `inspect` **先扫描该 DUT 所绑定的真实 PDK**，再从扫描目录生成本会话的 `analysis/device_policy.tsv` 并导出结构网表；源图和后续回读使用同一器件端序与 CDF 参数映射。真实器件由扫描目录和 OA master 决定，不由 `server/config/device_policy.tsv` 的历史示例行决定。检查 `analysis/pdk_scan/inspect/raw_catalog.tsv`、`pdk_identity.tsv` 和 `scan_pdk.log`，以及 `before/device_catalog.tsv` 与 `analysis/device_policy.tsv`。

当前层清单也收录经 PDK 证明只有 D/G/S 三个外部端子的 MOS；其 Bulk 列为空，Source 串电阻只改这只 MOS 的真实 Source 连接。三端 master 的内部体连接遵循 PDK 自身模型，不能假造外部 Bulk。四端及以上器件仍须有明确 Bulk 角色；Cascode、Stack、VBIAS 仍按自己的 Bulk/Well 条件筛选。

Bench L/C/V、Corner 和供电轨应从导入 Case 的配置及 OA/仿真环境核对。`inspect` 可在这些资料未齐时只读列出当前层 MOS；Bench 缺失的会话不能 `generate`，Cascode 还需要真实高低轨。两项电流上限可同时省略做名义 DC 求参，显式提供时成对且必须通过；完整性能尚未签核。KimiCode 的 `CircuitTestBenchConfig` 与 `TestBenchManager` 可作为读取来源，但尚未接入独立 CLI；不能用旧实验数值代替。

真实服务器必须有可读取 PDK 权威元数据的 `ST_PDK_TECH_ADAPTER` 和可执行 Maau/Spectre OP 的现场 `ST_OP_PROVIDER_BIN`（或站点链接的 provider）。`setup_backend.csh`、编译、Fake Host 测试通过并不能代替这两个现场实现或真实器件回读证据。

已知 Capless 可以先做**不需要 Bench、轨网或电流指标**的只读 PDK 扫描。下列路径只供这一个测试 Case 使用；务必先在服务器核对文件存在、代码已上传、`ST_PDK_TECH_ADAPTER` 指向真实现场实现：

```csh
cd /tmpdata/maau_epc/users/k00981589/st-engine-maau
source server/setup_backend.csh /tmpdata/maau_epc/users/k00981589/st-engine-maau
set scan_dir = `mktemp -d /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/pdk_scan.XXXXXX`
./server/st_virtuoso_backend.sh scan-pdk --cds-lib /tmpdata/maau_epc/users/k00981589/HiAplatRV500_ldo_sim_ldo1_0_cbb_top/circuit/cds/target/cds.lib --lib HiAplat730RV200_Maau_cal --cell ocldo18to12_200ma_core --view schematic --catalog-output "$scan_dir/catalog.tsv" --identity-output "$scan_dir/identity.tsv" >& "$scan_dir/scan.log"
set scan_status = $status
echo $scan_status
```

只在 `scan_status=0` 且 `catalog.tsv`、`identity.tsv` 非空时读出 PDK 身份和器件；否则保留 `scan.log` 与工具报告的原始运行目录，先修现场适配。此命令不会创建或修改派生 CellView。

## 历史 001 会话示例：仅供路径格式参考

先在真实服务器对已导入 DUT 做一次只读 `scan-pdk`，它只需要源 `cds.lib` 和 DUT L/C/V，用于确认实际 PDK 库、器件和模型上下文。随后可运行只读 `inspect` 生成结构网表、器件目录、坐标和当前层 MOS 清单；Case 的 Bench/轨网映射可在准备正式 generate 会话前再核对。既有 Capless 的 DUT 线索为
`HiAplat730RV200_Maau_cal/ocldo18to12_200ma_core/schematic`，须在服务器重新核对。

只有这一步的退出码、日志和四个产物均正确，才进入 `confirm` 和 `generate`。

## 1. 加载环境并重新构建

以下命令在 csh/tcsh 中逐行执行：

```csh
cd /tmpdata/maau_epc/users/k00981589/st-engine-maau
source server/setup_backend.csh /tmpdata/maau_epc/users/k00981589/st-engine-maau
./scripts/build.sh
./scripts/test.sh
```

历史版本曾报告（当前测试数量以本次服务器构建输出为准）：

```text
test programs passed: 14
demos passed: 2
cli help passed: 1
server backend contract passed: 1
```

## 2. 准备隔离的 Cadence 会话库

下面是一条完整命令；可整行复制：

```csh
./server/prepare_session.sh --source-cds-lib /tmpdata/maau_epc/users/k00981589/HiAplatRV500_ldo_sim_ldo1_0_cbb_top/circuit/cds/target/cds.lib --session-dir /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/cadence --variant-lib HiAplat730RV200_Maau_cal_ST
```

预期只输出：

```text
/tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/cadence/cds.lib
```

这个新 `cds.lib` 只读 `INCLUDE` 原项目库表，并把以下两个可写库放在独立目录：

- `HiAplat730RV200_Maau_cal_ST`：最终派生电路；
- `HiAplat730RV200_Maau_cal_ST__STAGING`：生成过程中的临时电路。

原项目的 `cds.lib` 和源 schematic 不会被修改。

## 3. 执行真实只读 inspect

下面也是一条完整命令：

```csh
./build/bin/st_circuit_tool inspect --backend /tmpdata/maau_epc/users/k00981589/st-engine-maau/server/st_virtuoso_backend.sh --cds-lib /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/cadence/cds.lib --lib HiAplat730RV200_Maau_cal --cell ocldo18to12_200ma_core --view schematic --core-subckt ocldo18to12_200ma_core --work-dir /tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/work --variant-lib HiAplat730RV200_Maau_cal_ST --variant-cell ocldo18to12_200ma_core__TV0001 --variant-id TV0001 --skill /tmpdata/maau_epc/users/k00981589/st-engine-maau/skill/standalone_topology_variant.il
```

命令结束后立刻执行：

```csh
echo $status
```

成功标准：退出码为 `0`，终端打印“会话已创建”和非空的“可修改 MOS”清单，并且以下文件均非空：

```text
/tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/work/before/core_before.scs
/tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/work/before/device_catalog.tsv
/tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/work/before/geometry.tsv
/tmpdata/maau_epc/users/k00981589/st-engine-maau-runs/ocldo_structure_001/work/before/mos_inventory.tsv
```

## 4. 这一步返回什么

若 `inspect` 成功，请返回：

1. `inspect` 的完整终端输出和 `echo $status`；
2. `work/logs/snapshot.log`；
3. `work/before/core_before.scs` 的开头 80 行；
4. 完整的 `device_catalog.tsv` 和 `mos_inventory.tsv`。

若失败，请只返回终端错误和 `work/logs/snapshot.log`，先不要执行 `confirm` 或 `generate`。失败不等于原电路被改坏，因为此阶段以只读模式打开源 schematic。

## 5. 后续结构变换顺序

真实 `inspect` 通过后，再从 `mos_inventory.tsv` 中选择一个非阵列标量 MOS 做第一轮同型 Cascode：

```text
inspect
  -> confirm 一项同型 Cascode
  -> list 检查逻辑结果
  -> generate
  -> 源图回读不变
  -> staging 父图回读与期望网表一致
  -> 每个封装子Cell单独回读与期望子电路一致
  -> publish 最终派生 cellview
  -> open 在 Virtuoso GUI 中打开派生原理图
```

第一轮不要选择 `I18<119:0>`、`I19<119:0>` 这类阵列。阵列和 2～100 级 Stack 在标量链路跑通后单独验证。

`ready_for_sizing=true` 只代表结构物化和回读一致，不代表 LDO 性能已经提高；性能验证仍由后续 Sizing 和仿真完成。

当前可选候选错误续跑见 docs/服务器结构测试_候选端子冲突隔离与续跑_2026-10-10.md。先用失败会话运行真实原生检查，再用新工作目录 inspect。
