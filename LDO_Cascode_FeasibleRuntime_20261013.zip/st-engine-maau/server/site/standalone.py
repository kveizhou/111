#!/usr/bin/env python3
"""Independent PDK-path entry point for the existing structure-transform CLI."""
import argparse
import csv
import hashlib
import os
from pathlib import Path
import subprocess
import sys

from site_data import read_json, write_json, write_metadata, pin_site_inputs, verify_site_inputs
from standalone_pdk import build_metadata
from structural_pdk import build_structure_metadata
from pdk_discovery import discover, helper_init

ROOT = Path(__file__).resolve().parents[2]


def options(arguments):
    if len(arguments) % 2:
        raise ValueError('engine options must be --key value pairs')
    result = {}
    for index in range(0, len(arguments), 2):
        key = arguments[index]
        if not key.startswith('--') or key[2:] in result:
            raise ValueError('invalid/duplicate engine option: ' + key)
        result[key[2:]] = arguments[index + 1]
    return result


def environment(inputs, manifest):
    env = dict(os.environ)
    # Remove optional legacy bridge settings from the default standalone route.
    for key in ('ST_SITE_CASE_CONTEXT', 'ST_SITE_CASE_RULES', 'ST_SITE_TECH_METADATA', 'ST_MAAU_RUNTIME_BIN'):
        env.pop(key, None)
    env.update({'ST_CIRCUIT_CONTEXT': inputs['context'], 'ST_SIMULATION_PROFILE': inputs['rules'],
        'ST_PDK_METADATA': inputs['tech'], 'ST_CADENCE_RUNTIME_BIN': inputs['runtime'],
        'ST_PDK_TECH_ADAPTER': inputs['adapter'], 'ST_SITE_INPUTS_MANIFEST': str(manifest),
        'ST_OP_PROVIDER_BIN': str(ROOT / 'server/site/op_provider.py'), 'ST_ENGINE_ROOT': str(ROOT)})
    if inputs.get('init'):
        env['ST_SKILL_INIT'] = inputs['init']
    env['ST_VALIDATION_SCOPE'] = read_json(inputs['rules']).get('validation_scope', 'dc_operating_point')
    return env


def validate_bundle_profile(bundle,profile):
    name=bundle['corner']
    if profile.get('nominal_corner')!=name or set(profile.get('op_corners',{}))!={name} or set(profile.get('pvt_corners',[]))-{name}:
        raise ValueError('baseline bundle proves only its exact single Corner')
    selected=profile['op_corners'][name]
    if selected.get('temperature')!=bundle['temperature'] or selected.get('variables',{})!=bundle['variables']:
        raise ValueError('profile temperature/variables differ from validated baseline bundle')
    def models(items):return [(m['model_file'],m['section_name']) for m in items]
    if models(selected['models'])!=models(bundle['models']):raise ValueError('profile model selection differs from baseline bundle')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['discover-pdk', 'inspect', 'generate', 'confirm', 'list', 'undo', 'fresh', 'open'])
    parser.add_argument('--engine', default=str(ROOT / 'build/bin/st_circuit_tool'))
    parser.add_argument('--pdk-root', help='optional explicit PDK root; otherwise discover from the selected OA source')
    parser.add_argument('--simulation-profile', help='independent Bench/models/Corner/limits JSON')
    parser.add_argument('--pdk-rules', help='documented electrical rules absent from actual model/CDF')
    parser.add_argument('--validation-scope', choices=['dc_operating_point', 'structure_only'])
    args, remaining = parser.parse_known_args()
    try:
        explicit = options(remaining)
        if args.command in ('discover-pdk', 'inspect'):
            init = helper_init()
            probe_env = dict(os.environ)
            for key in ('ST_SITE_INPUTS_MANIFEST', 'ST_SITE_CASE_CONTEXT', 'ST_CIRCUIT_CONTEXT', 'ST_PDK_TECH_ADAPTER'):
                probe_env.pop(key, None)
            probe_env.update({'ST_SKILL_INIT': init, 'ST_ENGINE_ROOT': str(ROOT)})
        if args.command == 'discover-pdk':
            explicit.setdefault('view', 'schematic')
            output = Path(explicit['output']).resolve()
            output.mkdir(parents=True, exist_ok=False)
            data, libraries = discover(explicit['backend'], explicit['cds-lib'],
                {k: explicit[k] for k in ('lib', 'cell', 'view')}, output, probe_env)
            status = subprocess.run([explicit['backend'], 'probe-pdk', '--cds-lib', explicit['cds-lib'],
                '--libraries-file', str(libraries), '--output', str(output / 'pdk_probe.tsv')],
                env=probe_env, check=False)
            if status.returncode: return status.returncode
            with (output / 'pdk_probe.tsv').open(newline='') as stream:
                count = len({(r['oa_library'], r['oa_cell']) for r in csv.DictReader(stream, delimiter='\t')})
            if not count: raise ValueError('actual source-bound OA/CDF probe is empty')
            print('PROBE_MASTERS=' + str(count))
            print('只读发现与 OA/CDF 扫描完成；证据目录=' + str(output))
            return 0
        if args.command == 'inspect':
            scope = args.validation_scope or 'dc_operating_point'
            structure_only = scope == 'structure_only'
            if not structure_only and not args.simulation_profile:
                raise ValueError('inspect requires --simulation-profile')
            session = Path(explicit['work-dir']).resolve()
            if (session / 'session.conf').exists():
                raise ValueError('session already exists; choose a new work-dir')
            archive = session / 'analysis/standalone_inputs'
            archive.mkdir(parents=True, exist_ok=False)
            profile = read_json(args.simulation_profile) if args.simulation_profile else {}
            profile['validation_scope'] = scope
            explicit['validation-scope'] = scope
            explicit.setdefault('view', 'schematic')
            if not structure_only:
                explicit.setdefault('bench-view', 'schematic')
            bundle_path=profile.get('validated_baseline_bundle')
            bundle=None
            if bundle_path:
                from baseline_bundle import load_bundle
                if structure_only:raise ValueError('baseline bundle is for a new DC session only')
                bundle=load_bundle(bundle_path,{k:explicit[k] for k in ('lib','cell','view')},
                    {k:explicit['bench-'+k] for k in ('lib','cell','view')},profile.get('nominal_corner'))
                validate_bundle_profile(bundle,profile)
            if explicit.get('bench-view', 'schematic') != 'schematic' and bundle is None:
                raise ValueError('declare the actual schematic Bench for standalone OP')
            context = {'source_dut': {key: explicit[key] for key in ('lib', 'cell', 'view')},
                'source_benches': [] if structure_only else [{key: explicit['bench-' + key] for key in ('lib', 'cell', 'view')}],
                'source_cds_path': str(Path(explicit['cds-lib']).resolve().parent)}
            for key in ('nominal_corner', 'pvt_corners', 'vbias_vhigh_net', 'vbias_vlow_net',
                        'max_branch_current_error', 'max_vbias_current'):
                if key in profile:
                    value = profile[key]
                    value = ','.join(value) if isinstance(value, list) else str(value)
                    cli_key = key.replace('_', '-')
                    if cli_key in explicit and explicit[cli_key] != value:
                        raise ValueError('profile/CLI conflict: ' + cli_key)
                    explicit[cli_key] = value
            profile['nominal_corner'] = explicit.get('nominal-corner', profile.get('nominal_corner', ''))
            if not structure_only and profile['nominal_corner'] not in profile.get('op_corners', {}):
                raise ValueError('nominal Corner not declared in simulation profile')
            if not structure_only:
                profile.setdefault('original_model_files', sorted({m['model_file'] for m in
                    profile['op_corners'][profile['nominal_corner']]['models']}))
            if profile.get('design_side', 'source') != 'source':
                raise ValueError('standalone context has only the explicitly selected source DUT')
            probe = archive / 'pdk_probe.tsv'
            backend = explicit['backend']
            discovery = None
            if args.pdk_root:
                pdk_alias = Path(args.pdk_root).expanduser().absolute()
                pdk_root = pdk_alias.resolve()
                if not pdk_root.is_dir(): raise ValueError('PDK root must be an existing directory')
                probe_options = ['--pdk-root', str(pdk_root), '--pdk-root-alias', str(pdk_alias)]
                roots = pdk_alias
            else:
                discovery, libraries = discover(backend, explicit['cds-lib'], context['source_dut'], archive, probe_env)
                roots = discovery['pdk_alias_paths']
                probe_options = ['--libraries-file', str(libraries)]
            status = subprocess.run([backend, 'probe-pdk', '--cds-lib', explicit['cds-lib']]
                + probe_options + ['--output', str(probe)], env=probe_env, check=False)
            if status.returncode: return status.returncode
            rules = read_json(args.pdk_rules) if args.pdk_rules else {}
            metadata = (build_structure_metadata(roots, probe, rules,
                discovery['technology_library'] if discovery else None) if structure_only else
                build_metadata(roots, probe, profile, rules,
                discovery['technology_library'] if discovery else None))
            write_json(archive / 'pdk_diagnostics.json', {'rejected_devices': metadata['rejected_devices'],
                'unreadable_model_files': metadata['unreadable_model_files'],
                'missing': {d['cell']: d['missing'] for d in metadata['devices'] if d['missing']}})
            tech, adapter = archive / 'pdk_metadata.json', archive / 'pdk_adapter.il'
            write_metadata([metadata], tech, adapter)
            context_file, profile_file = archive / 'context.json', archive / 'simulation_profile.json'
            write_json(context_file, context)
            write_json(profile_file, profile)
            inputs = {'context': str(context_file), 'rules': str(profile_file), 'tech': str(tech),
                'adapter': str(adapter), 'runtime': str(ROOT / 'server/site' / ('cascode_runtime.py' if bundle else 'cadence_runtime.py')), 'init': init}
            inputs = pin_site_inputs(inputs)
            if bundle:
                inputs['file_sha256'].update(bundle['file_sha256'])
                inputs['file_sha256'][bundle['_bundle_path']]=bundle['_bundle_sha256']
                for module in (ROOT/'server/site').glob('*.py'):
                    inputs['file_sha256'][str(module.resolve())]=hashlib.sha256(module.read_bytes()).hexdigest()
            # Raw model declarations determine kind and constraints: pin all read files.
            inputs['file_sha256'].update(metadata['model_file_sha256'])
            for file in (probe, archive / 'discovery.tsv', archive / 'pdk_discovery.json',
                         archive / 'pdk_libraries.tsv', ROOT / 'server/site/prepare_skill_plan.py',
                         ROOT / 'server/skill/init.il', ROOT / 'server/skill/pdk_adapter.il'):
                if file.is_file():
                    inputs['file_sha256'][str(file.resolve())] = hashlib.sha256(file.read_bytes()).hexdigest()
            manifest = archive / 'provider_inputs.json'
            write_json(manifest, inputs)
            remaining = [item for key, value in explicit.items() for item in ('--' + key, value)]
        else:
            session = Path(explicit['session']).resolve()
            manifest = session / 'analysis/standalone_inputs/provider_inputs.json'
            inputs = read_json(manifest)
            verify_site_inputs(inputs)
        return subprocess.run([args.engine, args.command] + remaining,
            env=environment(inputs, manifest), check=False).returncode
    except (KeyError, ValueError, OSError) as error:
        print('standalone circuit: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
