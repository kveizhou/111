"""Standalone JSON, PDK metadata and immutable simulation input helpers."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile


def read_json(path):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('duplicate JSON key: ' + key)
            out[key] = value
        return out
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON: ' + x)))

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix=path.name + '.', delete=False) as stream:
        temp = Path(stream.name)
        try:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        except Exception:
            if temp.exists():
                temp.unlink()
            raise
    os.replace(temp, path)

def finite(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError('expected finite numeric value')
    if positive and value <= 0:
        raise ValueError('expected positive value')
    return float(value)

def actual_path(value, parent):
    value = os.path.expandvars(os.path.expanduser(value))
    if '$' in value:
        raise ValueError('unset path environment variable: ' + value)
    path = Path(value)
    return str((path if path.is_absolute() else parent / path).resolve())

def unit_scale(unit, semantic):
    dimension = semantic in ('width', 'total_width', 'length')
    scales = {'m': 1, 'meter': 1, 'metre': 1, 'meters': 1, 'um': 1e-6,
              'µm': 1e-6, 'nm': 1e-9, 'mm': 1e-3, 'lengthMetric': 1}
    if dimension:
        # An empty unit does not prove whether the config uses meters or microns.
        if unit not in scales:
            raise ValueError('unproven dimension unit: ' + str(unit))
        return scales[unit]
    if semantic == 'resistance':
        if unit not in ('ohm', 'Ohm', 'ohms', 'Ohms', 'Ω'):
            raise ValueError('unproven resistance unit: ' + str(unit))
    elif unit not in ('', '1', 'integer', 'count'):
        raise ValueError('unproven count unit: ' + str(unit))
    return 1

def constraint(param, semantic):
    scale = unit_scale(param.get('units', ''), semantic)
    value = param.get('constraint')
    values = value if isinstance(value, list) else [value] if isinstance(value, (int, float)) else []
    if not values:
        return None
    values = sorted(set(finite(v, True) * scale for v in values))
    if semantic in ('fingers', 'fin', 'multiplier') and any(v != int(v) for v in values):
        raise ValueError('count constraint is not integral')
    return {'min': values[0], 'max': values[-1], 'grid': 0, 'allowed': values}

def pin_site_inputs(inputs):
    pinned = dict(inputs)
    files = {Path(inputs[key]).resolve() for key in ('context', 'rules', 'tech', 'adapter', 'runtime')}
    if inputs.get('init'):
        files.add(Path(inputs['init']).resolve())
    configs = read_json(inputs['tech'])
    rules = read_json(inputs['rules'])
    models = [s['model_file'] for c in configs for corner in c.get('corners', []) for s in corner['sections']]
    models += rules.get('original_model_files', [])
    models += [s['model_file'] for corner in rules.get('op_corners', {}).values() for s in corner['models']]
    files.update(Path(path).resolve() for path in models)
    pinned['file_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)}
    return pinned

def verify_site_inputs(inputs, environment=None):
    fingerprints = inputs.get('file_sha256')
    if not fingerprints:
        raise ValueError('site input fingerprints missing; create a new standalone circuit session')
    required = {str(Path(inputs[key]).resolve()) for key in ('context', 'rules', 'tech', 'adapter', 'runtime')}
    if inputs.get('init'):
        required.add(str(Path(inputs['init']).resolve()))
    if not required.issubset(fingerprints):
        raise ValueError('incomplete site input fingerprints')
    if environment is not None:
        names = {'context': 'ST_CIRCUIT_CONTEXT', 'rules': 'ST_SIMULATION_PROFILE',
                 'tech': 'ST_PDK_METADATA', 'adapter': 'ST_PDK_TECH_ADAPTER',
                 'runtime': 'ST_CADENCE_RUNTIME_BIN'}
        if inputs.get('init'):
            names['init'] = 'ST_SKILL_INIT'
        for key, variable in names.items():
            active = environment.get(variable, '')
            if not active or Path(active).resolve() != Path(inputs[key]).resolve():
                raise ValueError('active site input path differs from pinned input: ' + variable)
    for path, expected in fingerprints.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError('site input changed since import; create a new session: ' + path)

def skill(value):
    if value is None or value is False:
        return 'nil'
    if value is True:
        return 't'
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (int, float)):
        return format(finite(value), '.17g')
    if isinstance(value, dict):
        return 'list(' + ' '.join('list(' + skill(k) + ' ' + skill(v) + ')' for k, v in sorted(value.items())) + ')'
    return 'list(' + ' '.join(skill(v) for v in value) + ')'

def skill_metadata(config):
    descriptions = {}
    for dev in config['devices']:
        row = {'kind': dev['kind'], 'modelName': dev['model'], 'kindSource': dev['source'],
               'deviceProofSource': dev['source'], 'normalizedToCdf': [
                   k + ':' + v for k, v in sorted(dev['normalized_to_cdf'].items())],
               'parameterConstraints': []}
        for key, c in sorted(dev['constraints'].items()):
            name = dev['normalized_to_cdf'][key]
            row['parameterConstraints'].append(':'.join([key, name, str(c['min']), str(c['max']),
                str(c['grid']), ','.join(str(v) for v in c['allowed'])]))
            prefix = {'width': 'Width', 'length': 'Length', 'resistance': 'Resistance'}.get(key)
            if prefix:
                row['min' + prefix], row['max' + prefix] = c['min'], c['max']
        row['cdfSource'] = dev.get('cdf_source', dev['source']) if dev['constraints'] or config.get('validation_scope') == 'structure_only' else ''
        for key in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'bulkRule', 'voltageDomains', 'terminalRoles',
                    'wFinFormula', 'maxStackLevel', 'sourceDrainInterchangeable'):
            if key in dev:
                row[key] = dev[key]
        for key in ('reliabilitySource', 'bulkSource', 'domainSource'):
            row[key] = dev.get('rules_source', '')
        descriptions[(dev['oa_library'] + '/' if dev.get('oa_library') else '') + dev['cell']] = row
    return {'pdkName': config['pdk_name'], 'pdkVersion': config['version'],
            'roots': sorted(set(config['pdk_paths'] + config.get('pdk_alias_paths', []))),
            'source': config['source'], 'devices': descriptions,
            'otherDevices': {(dev['oa_library'] + '/' + dev['cell']):
                {'kind': 'non_target', 'modelName': dev['model'], 'source': dev['source']}
                for dev in config.get('non_target_devices', [])},
            'modelFiles': sorted({s['model_file'] for c in config['corners'] for s in c['sections']}),
            'modelSections': sorted({s['section_name'] for c in config['corners'] for s in c['sections']}),
            'corners': [c['name'] for c in config['corners']]}

def write_metadata(configs, output, skill_output):
    write_json(output, configs)
    target = Path(skill_output).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    adapter = Path(__file__).resolve().parents[1] / 'skill/site_metadata_adapter.il'
    target.write_text('; Generated from scanned PDK metadata.\n' +
                      'stSiteConfigs = ' + skill([skill_metadata(c) for c in configs]) + '\n' +
                      'load(' + skill(str(adapter)) + ')\n', encoding='utf-8')

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--verify-inputs", required=True)
    args=parser.parse_args()
    verify_site_inputs(read_json(args.verify_inputs), os.environ)
