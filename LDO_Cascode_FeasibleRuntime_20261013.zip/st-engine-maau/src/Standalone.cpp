#include "st/Standalone.h"
#include "st/PdkCatalog.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <limits>
#include <set>
#include <sstream>

namespace st::standalone {
namespace {

std::string trim(const std::string& input)
{
    const auto first = input.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = input.find_last_not_of(" \t\r\n");
    return input.substr(first, last - first + 1);
}

std::vector<std::string> split(const std::string& input, char separator)
{
    std::vector<std::string> values;
    std::string value;
    std::istringstream stream(input);
    while (std::getline(stream, value, separator)) values.push_back(trim(value));
    if (!input.empty() && input.back() == separator) values.emplace_back();
    return values;
}

std::string lower(std::string value)
{
    std::transform(value.begin(), value.end(), value.begin(),
        [](unsigned char character) { return static_cast<char>(std::tolower(character)); });
    return value;
}

bool parseDouble(const std::string& text, double& value)
{
    const auto normalized = lower(trim(text));
    if (normalized == "inf" || normalized == "+inf" || normalized == "infinity") {
        value = std::numeric_limits<double>::infinity();
        return true;
    }
    if (normalized == "-inf" || normalized == "-infinity") {
        value = -std::numeric_limits<double>::infinity();
        return true;
    }
    char* end = nullptr;
    errno = 0;
    value = std::strtod(normalized.c_str(), &end);
    return errno == 0 && end != normalized.c_str() && end != nullptr && *end == '\0' &&
        !std::isnan(value);
}

bool parseInt(const std::string& text, int& value)
{
    char* end = nullptr;
    errno = 0;
    const long parsed = std::strtol(text.c_str(), &end, 10);
    if (errno != 0 || end == text.c_str() || end == nullptr || *end != '\0' ||
        parsed < std::numeric_limits<int>::min() || parsed > std::numeric_limits<int>::max()) {
        return false;
    }
    value = static_cast<int>(parsed);
    return true;
}

bool parseKind(const std::string& text, DeviceKind& kind)
{
    const auto value = lower(trim(text));
    if (value == "mos_n" || value == "nmos") kind = DeviceKind::MosN;
    else if (value == "mos_p" || value == "pmos") kind = DeviceKind::MosP;
    else if (value == "mos") kind = DeviceKind::Mos;
    else if (value == "resistor") kind = DeviceKind::Resistor;
    else if (value == "capacitor") kind = DeviceKind::Capacitor;
    else if (value == "subckt") kind = DeviceKind::Subckt;
    else if (value == "source") kind = DeviceKind::Source;
    else if (value == "other") kind = DeviceKind::Other;
    else return false;
    return true;
}

bool parseRole(const std::string& text, TerminalRole& role)
{
    const auto value = lower(trim(text));
    if (value == "drain" || value == "d") role = TerminalRole::Drain;
    else if (value == "gate" || value == "g") role = TerminalRole::Gate;
    else if (value == "source" || value == "s") role = TerminalRole::Source;
    else if (value == "bulk" || value == "b") role = TerminalRole::Bulk;
    else if (value == "positive" || value == "p") role = TerminalRole::Positive;
    else if (value == "negative" || value == "n") role = TerminalRole::Negative;
    else if (value == "substrate") role = TerminalRole::Substrate;
    else if (value == "well") role = TerminalRole::Well;
    else if (value == "other") role = TerminalRole::Other;
    else return false;
    return true;
}

std::string field(const std::vector<std::string>& values,
                  const std::map<std::string, std::size_t>& columns,
                  const std::string& name)
{
    const auto found = columns.find(name);
    return found == columns.end() || found->second >= values.size()
        ? std::string{} : values[found->second];
}

bool requiredColumnsPresent(const std::map<std::string, std::size_t>& columns)
{
    const char* required[] = {
        "master", "kind", "terminal_names", "terminal_roles",
        "oa_library", "oa_cell", "oa_view", "voltage_domain",
    };
    for (const auto* name : required) {
        if (columns.count(name) == 0) return false;
    }
    return true;
}

bool setOptionalDouble(const std::vector<std::string>& values,
                       const std::map<std::string, std::size_t>& columns,
                       const std::string& name, double& destination)
{
    const auto text = field(values, columns, name);
    return text.empty() || parseDouble(text, destination);
}

std::string kindName(DeviceKind kind)
{
    return kind == DeviceKind::MosN ? "NMOS" : kind == DeviceKind::MosP ? "PMOS" : "MOS";
}

bool parseParameterConstraints(const std::string& text,
                               std::map<std::string, ParameterConstraint>& constraints)
{
    constraints.clear();
    for (const auto& serialized : split(text, ';')) {
        if (serialized.empty()) continue;
        const auto fields = split(serialized, ':');
        if (fields.size() != 6 || fields[0].empty() || fields[1].empty()) return false;
        ParameterConstraint constraint;
        constraint.semantic_name = fields[0];
        constraint.cdf_name = fields[1];
        if (!parseDouble(fields[2], constraint.minimum) ||
            !parseDouble(fields[3], constraint.maximum) ||
            !parseDouble(fields[4], constraint.grid) ||
            constraint.minimum > constraint.maximum || constraint.grid < 0.0) {
            return false;
        }
        for (const auto& discrete : split(fields[5], ',')) {
            if (discrete.empty()) continue;
            double value = 0.0;
            if (!parseDouble(discrete, value)) return false;
            constraint.discrete_values.push_back(value);
        }
        const auto normalized = lower(constraint.semantic_name);
        constraint.integer_only = normalized == "finger" || normalized == "fingers" ||
            normalized == "fin" || normalized == "fins";
        if (!constraints.emplace(constraint.semantic_name, std::move(constraint)).second) return false;
    }
    for (const auto& entry : constraints) {
        if (!ValidateParameterConstraint(entry.second)) return false;
    }
    return true;
}

std::string candidateRejectionsText(const std::map<std::string, std::vector<std::string>>& rejections)
{
    std::ostringstream output;
    bool firstMaster = true;
    for (const auto& entry : rejections) {
        if (!firstMaster) output << ';';
        firstMaster = false;
        output << entry.first << '=';
        for (std::size_t index = 0; index < entry.second.size(); ++index) {
            if (index != 0) output << '|';
            output << entry.second[index];
        }
    }
    return output.str();
}

std::string jsonEscape(const std::string& value)
{
    std::ostringstream output;
    for (const char character : value) {
        if (character == '\\') output << "\\\\";
        else if (character == '"') output << "\\\"";
        else if (character == '\n') output << "\\n";
        else output << character;
    }
    return output.str();
}

using Values = std::map<std::string, std::string>;

bool loadValues(const std::filesystem::path& path, Values& values, std::string& error)
{
    std::ifstream input(path);
    if (!input) {
        error = "无法读取操作文件：" + path.string();
        return false;
    }
    std::string line;
    std::size_t row = 0;
    while (std::getline(input, line)) {
        ++row;
        line = trim(line);
        if (line.empty() || line.front() == '#') continue;
        const auto separator = line.find('=');
        if (separator == std::string::npos || trim(line.substr(0, separator)).empty()) {
            error = "操作文件第" + std::to_string(row) + "行不是key=value";
            return false;
        }
        const auto key = lower(trim(line.substr(0, separator)));
        const auto value = trim(line.substr(separator + 1));
        if (!values.emplace(key, value).second) {
            error = "操作文件存在重复字段：" + key;
            return false;
        }
    }
    return true;
}

bool getRequired(const Values& values, const std::string& key,
                 std::string& value, std::string& error)
{
    const auto found = values.find(key);
    if (found == values.end() || found->second.empty()) {
        error = "操作文件缺少必需字段：" + key;
        return false;
    }
    value = found->second;
    return true;
}

std::string getOptional(const Values& values, const std::string& key,
                        const std::string& fallback = {})
{
    const auto found = values.find(key);
    return found == values.end() ? fallback : found->second;
}

bool parseNumber(const std::string& text, double& value)
{
    if (parseDouble(text, value)) return true;
    bool ok = false;
    value = parseSuffixValue(text, ok);
    return ok && std::isfinite(value);
}

bool getOptionalNumber(const Values& values, const std::string& key,
                       double fallback, double& value, std::string& error)
{
    const auto found = values.find(key);
    if (found == values.end() || found->second.empty()) {
        value = fallback;
        return true;
    }
    if (!parseNumber(found->second, value)) {
        error = "操作文件字段" + key + "不是有效数值：" + found->second;
        return false;
    }
    return true;
}

bool getOptionalNumber(const Values& values, const std::string& key,
                       std::optional<double>& value, std::string& error)
{
    const auto found = values.find(key);
    if (found == values.end() || found->second.empty()) {
        value.reset();
        return true;
    }
    double parsed = 0.0;
    if (!parseNumber(found->second, parsed)) {
        error = "操作文件字段" + key + "不是有效数值：" + found->second;
        return false;
    }
    value = parsed;
    return true;
}

bool parseBooleanText(const std::string& text, bool& value)
{
    const auto normalized = lower(trim(text));
    if (normalized == "true" || normalized == "yes" || normalized == "1") {
        value = true;
        return true;
    }
    if (normalized == "false" || normalized == "no" || normalized == "0") {
        value = false;
        return true;
    }
    return false;
}

bool getOptionalBoolean(const Values& values, const std::string& key,
                        bool fallback, bool& value, std::string& error)
{
    const auto found = values.find(key);
    if (found == values.end() || found->second.empty()) {
        value = fallback;
        return true;
    }
    if (!parseBooleanText(found->second, value)) {
        error = "操作文件字段" + key + "不是有效布尔值";
        return false;
    }
    return true;
}

Diagnostic operationError(const std::string& message)
{
    return {DiagCode::MissingInput, message};
}

bool sameInstance(const Instance& left, const Instance& right)
{
    return left.model == right.model && left.nets == right.nets &&
        left.params == right.params;
}

bool startsWith(const std::string& value, const std::string& prefix)
{
    return value.size() >= prefix.size() &&
        value.compare(0, prefix.size(), prefix) == 0;
}

} // namespace

std::string CellViewIdentityHash(const std::string& library,
                                 const std::string& cell,
                                 const std::string& view,
                                 const std::string& storagePath)
{
    // FNV-1a 64bit；字段间用 NUL 分隔避免拼接歧义。输出固定 16 位十六进制，
    // 与后端 fake/真实实现对同一 L/C/V+storage 必须得到逐字节一致的结果。
    std::uint64_t hash = 14695981039346656037ull;
    const auto feed = [&hash](const std::string& field) {
        for (const unsigned char ch : field) {
            hash ^= ch;
            hash *= 1099511628211ull;
        }
        hash ^= 0xffu;
        hash *= 1099511628211ull;
    };
    feed(library);
    feed(cell);
    feed(view);
    feed(storagePath);
    std::ostringstream output;
    output << std::hex;
    output.width(16);
    output.fill('0');
    output << hash;
    return output.str();
}

bool LoadDeviceCatalogTsv(const std::filesystem::path& path,
                          DeviceCatalog& catalog,
                          std::vector<Diagnostic>& diagnostics)
{
    diagnostics.clear();
    std::ifstream input(path);
    if (!input) {
        diagnostics.push_back({DiagCode::MissingInput,
            "无法读取PDK器件目录：" + path.string()});
        return false;
    }

    std::string line;
    if (!std::getline(input, line)) {
        diagnostics.push_back({DiagCode::MissingInput, "PDK器件目录为空"});
        return false;
    }
    const auto header = split(line, '\t');
    std::map<std::string, std::size_t> columns;
    for (std::size_t index = 0; index < header.size(); ++index) {
        columns[lower(header[index])] = index;
    }
    if (!requiredColumnsPresent(columns)) {
        diagnostics.push_back({DiagCode::MissingInput,
            "PDK器件目录缺少必需列"});
        return false;
    }

    std::size_t row = 1;
    bool any = false;
    while (std::getline(input, line)) {
        ++row;
        if (trim(line).empty() || trim(line).front() == '#') continue;
        const auto values = split(line, '\t');
        DeviceDescriptor descriptor;
        descriptor.master = field(values, columns, "master");
        if (!parseKind(field(values, columns, "kind"), descriptor.kind)) {
            diagnostics.push_back({DiagCode::MissingInput,
                "PDK器件目录第" + std::to_string(row) + "行kind无效"});
            continue;
        }
        descriptor.terminal_names_by_index = split(field(values, columns, "terminal_names"), ',');
        const auto roleNames = split(field(values, columns, "terminal_roles"), ',');
        if (descriptor.terminal_names_by_index.empty() ||
            roleNames.size() != descriptor.terminal_names_by_index.size()) {
            diagnostics.push_back({DiagCode::InvalidTerminalMap,
                "PDK器件目录第" + std::to_string(row) + "行terminal定义不完整"});
            continue;
        }
        descriptor.terminal_count = descriptor.terminal_names_by_index.size();
        bool rolesValid = true;
        for (std::size_t index = 0; index < roleNames.size(); ++index) {
            TerminalRole role = TerminalRole::Other;
            if (!parseRole(roleNames[index], role)) {
                rolesValid = false;
                break;
            }
            descriptor.terminal_roles_by_index.push_back(role);
            if (role != TerminalRole::Other) descriptor.terminal_index[role] = index;
        }
        if (!rolesValid) {
            diagnostics.push_back({DiagCode::InvalidTerminalMap,
                "PDK器件目录第" + std::to_string(row) + "行terminal role无效"});
            continue;
        }

        descriptor.oa_library = field(values, columns, "oa_library");
        descriptor.oa_cell = field(values, columns, "oa_cell");
        descriptor.oa_view = field(values, columns, "oa_view");
        descriptor.pdk_name = field(values, columns, "pdk_name");
        descriptor.pdk_version = field(values, columns, "pdk_version");
        descriptor.model_name = field(values, columns, "model_name");
        descriptor.device_family = field(values, columns, "device_family");
        descriptor.flavor_id = field(values, columns, "flavor_id");
        descriptor.w_fin_formula = field(values, columns, "w_fin_formula");
        if (!parseParameterConstraints(field(values, columns, "parameter_constraints"),
                                       descriptor.parameter_constraints)) {
            diagnostics.push_back({DiagCode::MissingInput,
                "PDK器件目录第" + std::to_string(row) + "行parameter_constraints无效"});
            continue;
        }
        for (const auto& section : split(field(values, columns, "model_sections"), ',')) {
            if (!section.empty()) descriptor.model_sections.insert(section);
        }
        for (const auto& corner : split(field(values, columns, "corners"), ',')) {
            if (!corner.empty()) descriptor.corners.insert(corner);
        }
        descriptor.voltage_domain = field(values, columns, "voltage_domain");
        if (!descriptor.voltage_domain.empty()) {
            descriptor.allowed_voltage_domains.insert(descriptor.voltage_domain);
        }
        for (const auto& domain : split(field(values, columns, "allowed_voltage_domains"), ',')) {
            if (!domain.empty()) descriptor.allowed_voltage_domains.insert(domain);
        }
        const auto isolatedWell = field(values, columns, "isolated_well");
        const auto interchangeable = field(values, columns, "source_drain_interchangeable");
        const auto reliabilityComplete = field(values, columns, "reliability_complete");
        const auto bulkRuleComplete = field(values, columns, "bulk_rule_complete");
        if ((!isolatedWell.empty() &&
             !parseBooleanText(isolatedWell, descriptor.isolated_well)) ||
            (!interchangeable.empty() &&
             !parseBooleanText(interchangeable, descriptor.source_drain_interchangeable)) ||
            (!reliabilityComplete.empty() &&
             !parseBooleanText(reliabilityComplete, descriptor.reliability_complete)) ||
            (!bulkRuleComplete.empty() &&
             !parseBooleanText(bulkRuleComplete, descriptor.bulk_rule_complete))) {
            diagnostics.push_back({DiagCode::MissingInput,
                "PDK器件目录第" + std::to_string(row) + "行布尔属性无效"});
            continue;
        }
        for (const auto& compatible : split(field(values, columns, "compatible_masters"), ',')) {
            if (!compatible.empty()) descriptor.compatible_masters.insert(compatible);
        }
        for (const auto& mapping : split(field(values, columns, "normalized_to_cdf"), ',')) {
            const auto separator = mapping.find(':');
            if (separator != std::string::npos) {
                descriptor.normalized_to_cdf[trim(mapping.substr(0, separator))] =
                    trim(mapping.substr(separator + 1));
            }
        }

        bool limitsValid =
            setOptionalDouble(values, columns, "min_width", descriptor.limits.min_width) &&
            setOptionalDouble(values, columns, "max_width", descriptor.limits.max_width) &&
            setOptionalDouble(values, columns, "min_length", descriptor.limits.min_length) &&
            setOptionalDouble(values, columns, "max_length", descriptor.limits.max_length) &&
            setOptionalDouble(values, columns, "min_resistance", descriptor.limits.min_resistance) &&
            setOptionalDouble(values, columns, "max_resistance", descriptor.limits.max_resistance) &&
            setOptionalDouble(values, columns, "max_abs_vgs", descriptor.limits.max_abs_vgs) &&
            setOptionalDouble(values, columns, "max_abs_vds", descriptor.limits.max_abs_vds) &&
            setOptionalDouble(values, columns, "max_abs_vgb", descriptor.limits.max_abs_vgb);
        const auto maxStack = field(values, columns, "max_stack");
        if (!maxStack.empty()) limitsValid = limitsValid && parseInt(maxStack, descriptor.limits.max_stack_level);
        if (!limitsValid) {
            diagnostics.push_back({DiagCode::MissingInput,
                "PDK器件目录第" + std::to_string(row) + "行数值限制无效"});
            continue;
        }

        Diagnostic diagnostic;
        if (!catalog.Add(descriptor, diagnostic)) {
            diagnostics.push_back(std::move(diagnostic));
            continue;
        }
        any = true;
    }
    if (!any && diagnostics.empty()) {
        diagnostics.push_back({DiagCode::MissingInput, "PDK器件目录没有器件记录"});
    }
    if (!any || !diagnostics.empty()) return false;

    const auto catalogRoot = path.parent_path().filename() == "before"
        ? path.parent_path().parent_path() : path.parent_path();
    const auto outputPath = catalogRoot / "analysis/pdk_catalog.json";
    std::error_code filesystemError;
    std::filesystem::create_directories(outputPath.parent_path(), filesystemError);
    std::ofstream output(outputPath);
    if (filesystemError || !output) {
        diagnostics.push_back({DiagCode::MissingInput,
            "无法写归一化PDK目录：" + outputPath.string()});
        return false;
    }
    output << WritePdkCatalogJson(catalog);
    if (!output) {
        diagnostics.push_back({DiagCode::MissingInput,
            "归一化PDK目录写入失败：" + outputPath.string()});
        return false;
    }
    return true;
}

MosInventoryResult ListDirectMos(const Netlist& netlist,
                                 const std::string& coreSubckt,
                                 const DeviceCatalog& catalog)
{
    MosInventoryResult result;
    const auto* core = netlist.find(coreSubckt);
    if (core == nullptr) {
        result.diagnostics.push_back({DiagCode::NotFound,
            "核心subckt " + coreSubckt + " 不存在；不会改为扫描其他层级"});
        return result;
    }
    for (const auto& instance : core->instances) {
        const auto* descriptor = catalog.Find(instance.model);
        if (descriptor == nullptr ||
            !isMosKind(descriptor->kind)) {
            continue;
        }
        Diagnostic diagnostic;
        DirectMosDevice device;
        device.instance = instance.name;
        device.master = instance.model;
        device.kind = descriptor->kind;
        device.parameters = instance.params;
        if (!getTerminalNet(instance, catalog, TerminalRole::Drain, device.drain_net, diagnostic) ||
            !getTerminalNet(instance, catalog, TerminalRole::Gate, device.gate_net, diagnostic) ||
            !getTerminalNet(instance, catalog, TerminalRole::Source, device.source_net, diagnostic) ||
            (descriptor->terminal_count != 3 &&
             !getTerminalNet(instance, catalog, TerminalRole::Bulk,
                             device.bulk_net, diagnostic))) {
            result.diagnostics.push_back(std::move(diagnostic));
            return result;
        }
        const auto selection = SelectCrossFlavorCandidates(
            *descriptor, catalog, descriptor->voltage_domain);
        for (const auto* accepted : selection.accepted) {
            device.cross_flavor_candidates.push_back(accepted->master);
        }
        device.candidate_rejections = selection.rejected_reasons;
        result.devices.push_back(std::move(device));
    }
    result.ok = true;
    return result;
}

bool WriteMosInventoryTsv(const std::filesystem::path& path,
                          const MosInventoryResult& inventory,
                          std::string& error)
{
    error.clear();
    std::ofstream output(path);
    if (!output) {
        error = "无法写MOS清单：" + path.string();
        return false;
    }
    output << "instance\tpolarity\tmaster\tdrain\tgate\tsource\tbulk\t"
              "cross_flavor_candidates\tcandidate_rejections\tparameters\n";
    for (const auto& device : inventory.devices) {
        output << device.instance << '\t' << kindName(device.kind) << '\t' << device.master
               << '\t' << device.drain_net << '\t' << device.gate_net << '\t'
               << device.source_net << '\t' << device.bulk_net << '\t';
        for (std::size_t index = 0; index < device.cross_flavor_candidates.size(); ++index) {
            if (index != 0) output << ',';
            output << device.cross_flavor_candidates[index];
        }
        output << '\t' << candidateRejectionsText(device.candidate_rejections) << '\t';
        bool first = true;
        for (const auto& parameter : device.parameters) {
            if (!first) output << ',';
            first = false;
            output << parameter.first << '=' << parameter.second;
        }
        output << '\n';
    }
    if (!output) {
        error = "MOS清单写入失败：" + path.string();
        return false;
    }
    return true;
}

bool WriteCrossFlavorCandidatesJson(const std::filesystem::path& path,
                                    const MosInventoryResult& inventory,
                                    std::string& error)
{
    error.clear();
    std::ofstream output(path);
    if (!output) {
        error = "无法写异型候选报告：" + path.string();
        return false;
    }
    output << "{\"devices\":[";
    for (std::size_t index = 0; index < inventory.devices.size(); ++index) {
        if (index != 0) output << ',';
        const auto& device = inventory.devices[index];
        output << "{\"instance\":\"" << jsonEscape(device.instance)
               << "\",\"master\":\"" << jsonEscape(device.master)
               << "\",\"accepted\":[";
        for (std::size_t candidate = 0; candidate < device.cross_flavor_candidates.size(); ++candidate) {
            if (candidate != 0) output << ',';
            output << '"' << jsonEscape(device.cross_flavor_candidates[candidate]) << '"';
        }
        output << "],\"candidate_rejections\":{";
        bool firstRejection = true;
        for (const auto& rejection : device.candidate_rejections) {
            if (!firstRejection) output << ',';
            firstRejection = false;
            output << '"' << jsonEscape(rejection.first) << "\":[";
            for (std::size_t reason = 0; reason < rejection.second.size(); ++reason) {
                if (reason != 0) output << ',';
                output << '"' << jsonEscape(rejection.second[reason]) << '"';
            }
            output << ']';
        }
        output << "}}";
    }
    output << "]}\n";
    if (!output) {
        error = "异型候选报告写入失败：" + path.string();
        return false;
    }
    return true;
}

TransformRequestParseResult ParseTransformRequest(
    const std::filesystem::path& path,
    const std::string& defaultSubckt)
{
    TransformRequestParseResult result;
    Values values;
    std::string error;
    if (!loadValues(path, values, error)) {
        result.diagnostics.push_back(operationError(error));
        return result;
    }

    std::string type;
    std::string instance;
    if (!getRequired(values, "id", result.request.operation_id, error) ||
        !getRequired(values, "type", type, error) ||
        !getRequired(values, "instance", instance, error)) {
        result.diagnostics.push_back(operationError(error));
        return result;
    }
    const std::string subckt = getOptional(values, "subckt", defaultSubckt);
    if (subckt.empty()) {
        result.diagnostics.push_back(operationError("操作文件缺少subckt且会话没有默认核心subckt"));
        return result;
    }
    result.request.target = {"/", subckt, instance};
    type = lower(type);

    if (type == "same_type_cascode" || type == "cross_flavor_cascode") {
        static const std::set<std::string> owned = {
            "bias.reference_net", "bias.reference_current", "bias.voltage",
            "bias.output_net"
        };
        static const std::set<std::string> automaticOwned = {
            "vdsat_ctrl", "vdsat_cas", "margin", "cascode_vgs_min",
            "cascode_vgs_max"
        };
        for (const auto& entry : values) {
            const auto& key = entry.first;
            if (owned.count(key) != 0 || key.rfind("bias.element.", 0) == 0 ||
                key.rfind("bias.", 0) == 0 || key.rfind("op.", 0) == 0 ||
                key.rfind("terminal.", 0) == 0 || automaticOwned.count(key) != 0) {
                result.diagnostics.push_back(
                    operationError("字段" + key + "已由自动求解器接管"));
                return result;
            }
        }
        CascodeTransformRequest request;
        request.subckt = subckt;
        request.target = instance;
        request.voltage_domain = getOptional(values, "voltage_domain");
        request.nmos_bulk_net = getOptional(values, "nmos_bulk_net");
        if (!getOptionalBoolean(values, "tie_isolated_pmos_to_source", true,
                                request.tie_isolated_pmos_to_source, error)) {
            result.diagnostics.push_back(operationError(error));
            return result;
        }
        const auto gatePolicy = lower(getOptional(values, "gate_policy", "fixed"));
        if (gatePolicy == "fixed") request.gate_policy = GatePolicy::FixedBias;
        else {
            result.diagnostics.push_back(operationError(
                "Cascode产品路径只支持fixed：原MOS Gate保持不变，新增MOS Gate接VBIAS"));
            return result;
        }

        if (type == "cross_flavor_cascode") {
            if (!getRequired(values, "new_master", request.new_master, error)) {
                result.diagnostics.push_back(operationError(error));
                return result;
            }
            result.request.type = TransformType::CrossFlavorCascode;
        } else {
            result.request.type = TransformType::SameTypeCascode;
        }

        result.request.payload = std::move(request);
    } else if (type == "resistor") {
        ResistorTransformRequest request;
        request.subckt = subckt;
        request.target = instance;
        result.request.type = TransformType::AddSourceResistor;
        if (!getRequired(values, "resistor.master", request.resistor.master, error) ||
            !getOptionalNumber(values, "resistor.value",
                               request.requested_resistance, error) ||
            !getOptionalNumber(values, "resistor.case_default",
                               request.case_default_resistance, error) ||
            !getOptionalNumber(values, "resistor.grid", 0.0, request.resistor.grid, error) ||
            !getOptionalNumber(values, "resistor.min", 0.0,
                               request.resistor.minimum_resistance, error) ||
            !getOptionalNumber(values, "resistor.max",
                               std::numeric_limits<double>::infinity(),
                               request.resistor.maximum_resistance, error) ||
            !getOptionalNumber(values, "search_lower_factor", 0.5,
                               request.search_lower_factor, error) ||
            !getOptionalNumber(values, "search_upper_factor", 2.0,
                               request.search_upper_factor, error)) {
            result.diagnostics.push_back(operationError(error));
            return result;
        }
        request.resistor.resistance_parameter =
            getOptional(values, "resistor.parameter", "r");
        const std::map<std::string, TerminalRole> extraRoles = {
            {"substrate", TerminalRole::Substrate}, {"well", TerminalRole::Well},
        };
        for (const auto& role : extraRoles) {
            const auto net = getOptional(values, "resistor.extra." + role.first);
            if (!net.empty()) request.resistor.extra_terminal_nets[role.second] = net;
        }
        result.request.payload = std::move(request);
    } else if (type == "stack") {
        StackTransformRequest request;
        request.subckt = subckt;
        request.target = instance;
        request.voltage_domain = getOptional(values, "voltage_domain");
        request.nmos_bulk_net = getOptional(values, "nmos_bulk_net");
        result.request.type = TransformType::MosStack;
        std::string countText;
        if (!getRequired(values, "stage_count", countText, error) ||
            !parseInt(countText, request.stage_count)) {
            if (error.empty()) error = "stage_count必须是整数";
            result.diagnostics.push_back(operationError(error));
            return result;
        }
        const auto gatePolicy = lower(getOptional(values, "gate_policy", "shared"));
        if (gatePolicy == "shared") request.gate_policy = GatePolicy::SharedGate;
        else {
            result.diagnostics.push_back(operationError(
                "Stack产品路径只支持shared，所有级Gate连接原Gate"));
            return result;
        }
        const auto intent = lower(getOptional(values, "intent", "effective_length"));
        if (intent == "effective_length") request.intent = StackIntent::EffectiveLength;
        else {
            result.diagnostics.push_back(operationError("Stack intent无效"));
            return result;
        }
        if (!getOptionalBoolean(values, "tie_isolated_pmos_to_source", true,
                                request.tie_isolated_pmos_to_source, error)) {
            result.diagnostics.push_back(operationError(error));
            return result;
        }
        result.request.payload = std::move(request);
    } else {
        result.diagnostics.push_back(operationError("未知变换类型：" + type));
        return result;
    }

    result.ok = true;
    return result;
}

bool LoadRootGeometryTsv(const std::filesystem::path& path,
                         RootGeometry& geometry,
                         std::vector<Diagnostic>& diagnostics)
{
    diagnostics.clear();
    geometry.instance_locations.clear();
    geometry.has_cell_bbox = false;
    geometry.cell_lower_left = {};
    geometry.cell_upper_right = {};
    std::ifstream input(path);
    if (!input) {
        diagnostics.push_back({DiagCode::MissingInput,
            "无法读取核心实例坐标：" + path.string()});
        return false;
    }
    std::string line;
    if (!std::getline(input, line)) {
        diagnostics.push_back({DiagCode::MissingInput, "核心实例坐标文件为空"});
        return false;
    }
    const auto header = split(line, '\t');
    std::map<std::string, std::size_t> columns;
    for (std::size_t index = 0; index < header.size(); ++index) {
        columns[lower(header[index])] = index;
    }
    if (columns.count("instance") == 0 || columns.count("x") == 0 ||
        columns.count("y") == 0) {
        diagnostics.push_back({DiagCode::MissingInput,
            "核心实例坐标文件必须包含instance、x、y列"});
        return false;
    }
    const char* bboxColumns[] = {
        "cell_left", "cell_bottom", "cell_right", "cell_top",
    };
    std::size_t bboxColumnCount = 0;
    for (const auto* name : bboxColumns) {
        if (columns.count(name) != 0) ++bboxColumnCount;
    }
    if (bboxColumnCount != 0 && bboxColumnCount != 4) {
        diagnostics.push_back({DiagCode::MissingInput,
            "核心实例坐标文件的cell边界列必须同时包含left、bottom、right、top"});
        return false;
    }
    std::size_t row = 1;
    while (std::getline(input, line)) {
        ++row;
        if (trim(line).empty() || trim(line).front() == '#') continue;
        const auto values = split(line, '\t');
        const auto instance = field(values, columns, "instance");
        OaPoint point;
        if (instance.empty() || !parseNumber(field(values, columns, "x"), point.x) ||
            !parseNumber(field(values, columns, "y"), point.y) ||
            !geometry.instance_locations.emplace(instance, point).second) {
            diagnostics.push_back({DiagCode::MissingInput,
                "核心实例坐标第" + std::to_string(row) + "行无效或实例重复"});
            continue;
        }
        if (bboxColumnCount == 4) {
            OaPoint lowerLeft;
            OaPoint upperRight;
            if (!parseNumber(field(values, columns, "cell_left"), lowerLeft.x) ||
                !parseNumber(field(values, columns, "cell_bottom"), lowerLeft.y) ||
                !parseNumber(field(values, columns, "cell_right"), upperRight.x) ||
                !parseNumber(field(values, columns, "cell_top"), upperRight.y) ||
                upperRight.x <= lowerLeft.x || upperRight.y <= lowerLeft.y) {
                diagnostics.push_back({DiagCode::MissingInput,
                    "核心实例坐标第" + std::to_string(row) + "行cell边界无效"});
                continue;
            }
            if (!geometry.has_cell_bbox) {
                geometry.has_cell_bbox = true;
                geometry.cell_lower_left = lowerLeft;
                geometry.cell_upper_right = upperRight;
            } else if (geometry.cell_lower_left.x != lowerLeft.x ||
                       geometry.cell_lower_left.y != lowerLeft.y ||
                       geometry.cell_upper_right.x != upperRight.x ||
                       geometry.cell_upper_right.y != upperRight.y) {
                diagnostics.push_back({DiagCode::MissingInput,
                    "核心实例坐标第" + std::to_string(row) + "行cell边界与前文不一致"});
            }
        }
    }
    if (geometry.instance_locations.empty() && diagnostics.empty()) {
        diagnostics.push_back({DiagCode::MissingInput, "核心实例坐标没有记录"});
    }
    return !geometry.instance_locations.empty() && diagnostics.empty();
}

RootOaContextResult BuildRootOaContext(
    const Netlist& baseline,
    const Netlist& variant,
    const std::string& coreSubckt,
    const CellViewRef& source,
    const CellViewRef& staging,
    const RootGeometry& geometry,
    const PreviewIdentity& preview)
{
    RootOaContextResult result;
    const auto* baseCore = baseline.find(coreSubckt);
    const auto* variantCore = variant.find(coreSubckt);
    if (baseCore == nullptr || variantCore == nullptr) {
        result.diagnostics.push_back({DiagCode::NotFound,
            "基线或期望网表缺少核心subckt " + coreSubckt});
        return result;
    }

    result.context.source = source;
    result.context.target = staging;
    result.context.clone_map.push_back({source, staging, "/"});
    result.context.hierarchy_by_subckt[coreSubckt] = "/";
    result.context.preview = preview;

    std::vector<std::string> changedBaseNames;
    for (const auto& original : baseCore->instances) {
        const auto* changed = variantCore->find(original.name);
        if (changed == nullptr || !sameInstance(original, *changed)) {
            changedBaseNames.push_back(original.name);
            const auto location = geometry.instance_locations.find(original.name);
            if (location == geometry.instance_locations.end()) {
                result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                    "被修改实例缺少原图坐标：" + original.name});
            }
        }
    }
    if (changedBaseNames.empty()) {
        result.diagnostics.push_back({DiagCode::OaPlanInvalid,
            "基线与期望网表之间没有结构变化"});
        return result;
    }
    if (!result.diagnostics.empty()) return result;

    double placementRight = geometry.has_cell_bbox
        ? geometry.cell_upper_right.x
        : geometry.instance_locations.begin()->second.x;
    double placementTop = geometry.has_cell_bbox
        ? geometry.cell_upper_right.y
        : geometry.instance_locations.begin()->second.y;
    if (!geometry.has_cell_bbox) {
        for (const auto& entry : geometry.instance_locations) {
            placementRight = std::max(placementRight, entry.second.x);
            placementTop = std::max(placementTop, entry.second.y);
        }
    }
    constexpr double kPlacementMargin = 20.0;
    constexpr double kColumnPitch = 8.0;
    constexpr double kRowPitch = 4.0;
    constexpr std::size_t kRowsPerColumn = 25;
    const double placementX = placementRight + kPlacementMargin;
    std::size_t placementIndex = 0;
    std::set<std::string> wiredNets;
    for (const auto& changed : variantCore->instances) {
        const auto* original = baseCore->find(changed.name);
        if (original != nullptr && sameInstance(*original, changed)) continue;

        std::string anchorName;
        if (original != nullptr) {
            anchorName = changed.name;
        } else {
            std::size_t bestLength = 0;
            for (const auto& candidate : changedBaseNames) {
                if (startsWith(changed.name, candidate + "_") && candidate.size() > bestLength) {
                    anchorName = candidate;
                    bestLength = candidate.size();
                }
            }
            if (anchorName.empty()) anchorName = changedBaseNames.front();
        }
        const auto anchor = geometry.instance_locations.find(anchorName);
        if (anchor == geometry.instance_locations.end()) {
            result.diagnostics.push_back({DiagCode::OaPlanInvalid,
                "新增实例无法找到布局锚点：" + changed.name});
            continue;
        }
        // The old schematic wires remain after deleting the original instance.
        // A fixed offset from that instance can still land on an unrelated old
        // wire.  Recreate every changed/new device in a dedicated area to the
        // right of the complete source schematic boundary.  Labeled pin stubs
        // then establish the intended electrical nets during check-and-save.
        const auto index = placementIndex++;
        OaPoint point;
        point.x = placementX + kColumnPitch *
            static_cast<double>(index / kRowsPerColumn);
        point.y = placementTop - kRowPitch *
            static_cast<double>(index % kRowsPerColumn);
        result.context.locations["/:" + changed.name] = point;

        for (std::size_t terminal = 0; terminal < changed.nets.size(); ++terminal) {
            const auto& net = changed.nets[terminal];
            if (net.empty() || !wiredNets.insert(net).second) continue;
            const double y = point.y + 0.25 * static_cast<double>(terminal);
            result.context.wires.push_back({"/", net,
                {{point.x - 1.5, y}, {point.x - 0.5, y}}});
        }
    }

    double portY = placementTop;
    const double portX = placementX + kColumnPitch *
        static_cast<double>((placementIndex / kRowsPerColumn) + 1);
    for (const auto& pin : variantCore->pins) {
        if (std::find(baseCore->pins.begin(), baseCore->pins.end(), pin) != baseCore->pins.end()) {
            continue;
        }
        result.context.locations["/:" + pin] = {portX, portY};
        result.context.port_directions["/:" + pin] = "inputOutput";
        portY += 2.0;
    }
    result.ok = result.diagnostics.empty();
    return result;
}

} // namespace st::standalone
