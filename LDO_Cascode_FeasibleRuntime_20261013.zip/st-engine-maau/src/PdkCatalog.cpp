#include "st/PdkCatalog.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>

namespace st {
namespace {

bool hasMosRole(const DeviceDescriptor& descriptor, TerminalRole role)
{
    const auto found = descriptor.terminal_index.find(role);
    return descriptor.terminal_count == 4 && found != descriptor.terminal_index.end() &&
        found->second < descriptor.terminal_count;
}

bool supportsDomain(const DeviceDescriptor& descriptor, const std::string& domain)
{
    if (domain.empty()) return false;
    if (!descriptor.allowed_voltage_domains.empty()) {
        return descriptor.allowed_voltage_domains.count(domain) != 0;
    }
    return descriptor.voltage_domain == domain;
}

bool quantizableGeometry(const DeviceDescriptor& descriptor,
                         std::vector<std::string>& invalidConstraints)
{
    bool hasQuantizableGeometry = false;
    for (const auto& entry : descriptor.parameter_constraints) {
        const auto& constraint = entry.second;
        std::string reason;
        if (!ValidateParameterConstraint(constraint, &reason)) {
            const auto& semantic = constraint.semantic_name.empty()
                ? entry.first : constraint.semantic_name;
            invalidConstraints.push_back("parameter_constraint_" + semantic + "_invalid");
            continue;
        }
        const auto& name = constraint.semantic_name.empty() ? entry.first : constraint.semantic_name;
        if ((name == "width" || name == "length" || name == "fingers" ||
             name == "fin" || name == "fins") &&
            !constraint.cdf_name.empty()) {
            hasQuantizableGeometry = true;
        }
    }
    return hasQuantizableGeometry;
}

double reliabilityMargin(const DeviceDescriptor& descriptor)
{
    const double values[] = {
        descriptor.limits.max_abs_vgs,
        descriptor.limits.max_abs_vds,
        descriptor.limits.max_abs_vgb,
    };
    double margin = std::numeric_limits<double>::infinity();
    bool hasMeasuredLimit = false;
    for (const double value : values) {
        if (std::isfinite(value)) {
            margin = std::min(margin, value);
            hasMeasuredLimit = true;
        }
    }
    // reliability_complete permits use of a device, but does not manufacture
    // comparable headroom when no finite limit exists.
    return hasMeasuredLimit ? margin : -std::numeric_limits<double>::infinity();
}

std::string jsonEscape(const std::string& value)
{
    std::ostringstream output;
    for (const unsigned char character : value) {
        switch (character) {
        case '\\': output << "\\\\"; break;
        case '"': output << "\\\""; break;
        case '\n': output << "\\n"; break;
        case '\r': output << "\\r"; break;
        case '\t': output << "\\t"; break;
        default:
            if (character < 0x20) {
                output << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                       << static_cast<unsigned int>(character) << std::dec << std::setfill(' ');
            } else {
                output << character;
            }
        }
    }
    return output.str();
}

std::string jsonNumber(double value)
{
    if (!std::isfinite(value)) return "null";
    std::ostringstream output;
    output << std::setprecision(17) << value;
    return output.str();
}

void jsonStringArray(std::ostream& output, const std::set<std::string>& values)
{
    output << '[';
    bool first = true;
    for (const auto& value : values) {
        if (!first) output << ',';
        first = false;
        output << '"' << jsonEscape(value) << '"';
    }
    output << ']';
}

const char* kindName(DeviceKind kind)
{
    switch (kind) {
    case DeviceKind::MosN: return "mos_n";
    case DeviceKind::MosP: return "mos_p";
    case DeviceKind::Mos: return "mos";
    case DeviceKind::Resistor: return "resistor";
    case DeviceKind::Capacitor: return "capacitor";
    case DeviceKind::Subckt: return "subckt";
    case DeviceKind::Source: return "source";
    case DeviceKind::Other: return "other";
    }
    return "other";
}

const char* roleName(TerminalRole role)
{
    switch (role) {
    case TerminalRole::Drain: return "drain";
    case TerminalRole::Gate: return "gate";
    case TerminalRole::Source: return "source";
    case TerminalRole::Bulk: return "bulk";
    case TerminalRole::Positive: return "positive";
    case TerminalRole::Negative: return "negative";
    case TerminalRole::Substrate: return "substrate";
    case TerminalRole::Well: return "well";
    case TerminalRole::Other: return "other";
    }
    return "other";
}

void jsonVectorArray(std::ostream& output, const std::vector<std::string>& values)
{
    output << '[';
    for (std::size_t index = 0; index < values.size(); ++index) {
        if (index != 0) output << ',';
        output << '"' << jsonEscape(values[index]) << '"';
    }
    output << ']';
}

bool isInteger(double value)
{
    return std::fabs(value - std::round(value)) <=
        std::numeric_limits<double>::epsilon() * std::max(1.0, std::fabs(value)) * 4.0;
}

} // namespace

bool ValidateParameterConstraint(const ParameterConstraint& constraint,
                                 std::string* reason)
{
    const auto fail = [reason](const std::string& message) {
        if (reason != nullptr) *reason = message;
        return false;
    };
    if (!std::isfinite(constraint.minimum) || !std::isfinite(constraint.maximum) ||
        constraint.minimum > constraint.maximum) {
        return fail("minimum/maximum must be finite and ordered");
    }
    if (!std::isfinite(constraint.grid) || constraint.grid < 0.0) {
        return fail("grid must be finite and non-negative");
    }
    if (constraint.integer_only &&
        (!isInteger(constraint.minimum) || !isInteger(constraint.maximum))) {
        return fail("integer-only minimum/maximum must be integers");
    }
    if (!constraint.discrete_values.empty()) {
        std::set<double> unique;
        for (const double discrete : constraint.discrete_values) {
            if (!std::isfinite(discrete) || discrete < constraint.minimum ||
                discrete > constraint.maximum) {
                return fail("discrete value must be finite and in range");
            }
            if (constraint.integer_only && !isInteger(discrete)) {
                return fail("integer-only discrete value must be an integer");
            }
            unique.insert(discrete);
        }
        if (unique.empty()) return fail("discrete domain must not be empty");
    } else if (constraint.integer_only && constraint.grid > 0.0 &&
               !isInteger(constraint.grid)) {
        return fail("integer-only grid must be an integer when it is used");
    }
    if (reason != nullptr) reason->clear();
    return true;
}

double QuantizeParameter(double value, const ParameterConstraint& constraint)
{
    std::string reason;
    if (!ValidateParameterConstraint(constraint, &reason)) {
        throw std::invalid_argument("parameter constraint is invalid: " + reason);
    }
    if (!std::isfinite(value)) {
        throw std::invalid_argument("parameter value is not finite");
    }
    double quantized = std::max(constraint.minimum, std::min(value, constraint.maximum));
    if (!constraint.discrete_values.empty()) {
        const auto nearest = std::min_element(constraint.discrete_values.begin(),
                                              constraint.discrete_values.end(),
            [quantized](double left, double right) {
                const auto leftDistance = std::fabs(left - quantized);
                const auto rightDistance = std::fabs(right - quantized);
                return leftDistance == rightDistance ? left < right : leftDistance < rightDistance;
            });
        quantized = *nearest;
    } else if (constraint.grid > 0.0) {
        const double lastIndex = std::floor(
            (constraint.maximum - constraint.minimum) / constraint.grid);
        if (!std::isfinite(lastIndex) || lastIndex < 0.0) {
            throw std::invalid_argument("parameter constraint has no legal grid point");
        }
        double lowerIndex = std::floor((quantized - constraint.minimum) / constraint.grid);
        lowerIndex = std::max(0.0, std::min(lowerIndex, lastIndex));
        double lower = constraint.minimum + lowerIndex * constraint.grid;
        while (lower > constraint.maximum && lowerIndex > 0.0) {
            lowerIndex -= 1.0;
            lower = constraint.minimum + lowerIndex * constraint.grid;
        }
        const double upperIndex = std::min(lastIndex, lowerIndex + 1.0);
        const double upper = constraint.minimum + upperIndex * constraint.grid;
        quantized = std::fabs(upper - quantized) < std::fabs(quantized - lower) ? upper : lower;
    }
    if (constraint.integer_only) quantized = std::round(quantized);
    if (quantized < constraint.minimum || quantized > constraint.maximum ||
        (constraint.integer_only && !isInteger(quantized))) {
        throw std::invalid_argument("parameter value cannot be quantized legally");
    }
    return quantized;
}

CandidateSelection SelectCrossFlavorCandidates(
    const DeviceDescriptor& original, const DeviceCatalog& catalog,
    const std::string& voltage_domain)
{
    CandidateSelection result;
    for (const auto& entry : catalog.Descriptors()) {
        const auto& candidate = entry.second;
        if (candidate.master == original.master) continue;
        std::vector<std::string> reasons;
        if (candidate.kind != original.kind) {
            result.rejected_reasons.emplace(candidate.master,
                                            std::vector<std::string>{"polarity_mismatch"});
            continue;
        }
        if (candidate.oa_library.empty() || candidate.oa_cell.empty() || candidate.oa_view.empty()) {
            reasons.push_back("oa_master_incomplete");
        }
        const std::pair<TerminalRole, const char*> required[] = {
            {TerminalRole::Drain, "drain"}, {TerminalRole::Gate, "gate"},
            {TerminalRole::Source, "source"}, {TerminalRole::Bulk, "bulk"},
        };
        for (const auto& requiredRole : required) {
            if (!hasMosRole(candidate, requiredRole.first)) {
                reasons.push_back(std::string("mos_terminal_") + requiredRole.second + "_missing");
            }
        }
        if (!hasMosRole(original, TerminalRole::Bulk)) {
            reasons.push_back("original_mos_terminal_bulk_missing");
        }
        if (!candidate.reliability_complete) reasons.push_back("reliability_incomplete");
        if (!candidate.bulk_rule_complete) reasons.push_back("bulk_rule_incomplete");
        if (!supportsDomain(candidate, voltage_domain)) reasons.push_back("voltage_domain_unsupported");
        std::vector<std::string> invalidConstraints;
        if (!quantizableGeometry(candidate, invalidConstraints)) {
            reasons.push_back("quantizable_geometry_missing");
        }
        reasons.insert(reasons.end(), invalidConstraints.begin(), invalidConstraints.end());
        if (reasons.empty()) result.accepted.push_back(&candidate);
        else result.rejected_reasons.emplace(candidate.master, std::move(reasons));
    }
    std::sort(result.accepted.begin(), result.accepted.end(), [&original](const auto* left, const auto* right) {
        const auto leftMargin = reliabilityMargin(*left);
        const auto rightMargin = reliabilityMargin(*right);
        if (leftMargin != rightMargin) return leftMargin > rightMargin;
        const bool leftSameLibrary = left->oa_library == original.oa_library;
        const bool rightSameLibrary = right->oa_library == original.oa_library;
        if (leftSameLibrary != rightSameLibrary) return leftSameLibrary;
        return left->master < right->master;
    });
    return result;
}

std::string WritePdkCatalogJson(const DeviceCatalog& catalog)
{
    std::ostringstream output;
    output << "{\"devices\":[";
    bool firstDevice = true;
    for (const auto& entry : catalog.Descriptors()) {
        const auto& descriptor = entry.second;
        if (!firstDevice) output << ',';
        firstDevice = false;
        output << "{\"master\":\"" << jsonEscape(descriptor.master)
               << "\",\"kind\":\"" << kindName(descriptor.kind)
               << "\",\"pdk_name\":\"" << jsonEscape(descriptor.pdk_name)
               << "\",\"pdk_version\":\"" << jsonEscape(descriptor.pdk_version)
               << "\",\"model_name\":\"" << jsonEscape(descriptor.model_name)
               << "\",\"device_family\":\"" << jsonEscape(descriptor.device_family)
               << "\",\"flavor_id\":\"" << jsonEscape(descriptor.flavor_id)
               << "\",\"oa_library\":\"" << jsonEscape(descriptor.oa_library)
               << "\",\"oa_cell\":\"" << jsonEscape(descriptor.oa_cell)
               << "\",\"oa_view\":\"" << jsonEscape(descriptor.oa_view)
               << "\",\"voltage_domain\":\"" << jsonEscape(descriptor.voltage_domain)
               << "\",\"w_fin_formula\":\"" << jsonEscape(descriptor.w_fin_formula)
               << "\",\"terminal_count\":" << descriptor.terminal_count
               << ",\"terminal_names\":";
        jsonVectorArray(output, descriptor.terminal_names_by_index);
        output << ",\"terminal_roles\":[";
        for (std::size_t index = 0; index < descriptor.terminal_roles_by_index.size(); ++index) {
            if (index != 0) output << ',';
            output << '"' << roleName(descriptor.terminal_roles_by_index[index]) << '"';
        }
        output << "],\"normalized_to_cdf\":{";
        bool firstMapping = true;
        for (const auto& mapping : descriptor.normalized_to_cdf) {
            if (!firstMapping) output << ',';
            firstMapping = false;
            output << '"' << jsonEscape(mapping.first) << "\":\""
                   << jsonEscape(mapping.second) << '"';
        }
        output << "},\"compatible_masters_deprecated\":";
        jsonStringArray(output, descriptor.compatible_masters);
        output << ",\"model_sections\":";
        jsonStringArray(output, descriptor.model_sections);
        output << ",\"corners\":";
        jsonStringArray(output, descriptor.corners);
        output << ",\"reliability_complete\":" << (descriptor.reliability_complete ? "true" : "false")
               << ",\"bulk_rule_complete\":" << (descriptor.bulk_rule_complete ? "true" : "false")
               << ",\"allowed_voltage_domains\":";
        jsonStringArray(output, descriptor.allowed_voltage_domains);
        output << ",\"parameter_constraints\":{";
        bool firstConstraint = true;
        for (const auto& constraintEntry : descriptor.parameter_constraints) {
            const auto& constraint = constraintEntry.second;
            if (!firstConstraint) output << ',';
            firstConstraint = false;
            output << '"' << jsonEscape(constraintEntry.first) << "\":{\"semantic_name\":\""
                   << jsonEscape(constraint.semantic_name) << "\",\"cdf_name\":\""
                   << jsonEscape(constraint.cdf_name) << "\",\"minimum\":"
                   << jsonNumber(constraint.minimum) << ",\"maximum\":"
                   << jsonNumber(constraint.maximum) << ",\"grid\":"
                   << jsonNumber(constraint.grid) << ",\"discrete_values\":[";
            for (std::size_t index = 0; index < constraint.discrete_values.size(); ++index) {
                if (index != 0) output << ',';
                output << jsonNumber(constraint.discrete_values[index]);
            }
            output << "],\"integer_only\":" << (constraint.integer_only ? "true" : "false") << '}';
        }
        output << "},\"isolated_well\":" << (descriptor.isolated_well ? "true" : "false")
               << ",\"source_drain_interchangeable\":"
               << (descriptor.source_drain_interchangeable ? "true" : "false")
               << ",\"limits\":{\"min_width\":" << jsonNumber(descriptor.limits.min_width)
               << ",\"max_width\":" << jsonNumber(descriptor.limits.max_width)
               << ",\"min_length\":" << jsonNumber(descriptor.limits.min_length)
               << ",\"max_length\":" << jsonNumber(descriptor.limits.max_length)
               << ",\"min_resistance\":" << jsonNumber(descriptor.limits.min_resistance)
               << ",\"max_resistance\":" << jsonNumber(descriptor.limits.max_resistance)
               << ",\"max_abs_vgs\":" << jsonNumber(descriptor.limits.max_abs_vgs)
               << ",\"max_abs_vds\":" << jsonNumber(descriptor.limits.max_abs_vds)
               << ",\"max_abs_vgb\":" << jsonNumber(descriptor.limits.max_abs_vgb)
               << ",\"max_stack_level\":" << descriptor.limits.max_stack_level << "}}";
    }
    output << "]}\n";
    return output.str();
}

} // namespace st
