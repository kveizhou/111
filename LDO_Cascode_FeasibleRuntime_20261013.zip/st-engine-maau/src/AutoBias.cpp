// =============================================================
// AutoBias.cpp — 一套自给电 VBIAS 结构的 N/P 互补连接与器件选择
// 固定连接见批准规格 §7.1/§7.2；本文件不出现任何固定 PDK Cell 名。
// =============================================================
#include "st/AutoBias.h"

#include "st/Netlist.h"
#include "st/PdkCatalog.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <set>

namespace st {
namespace {

bool supportsDomain(const DeviceDescriptor& descriptor, const std::string& domain)
{
    if (domain.empty()) return true;
    if (!descriptor.allowed_voltage_domains.empty()) {
        return descriptor.allowed_voltage_domains.count(domain) != 0;
    }
    return !descriptor.voltage_domain.empty() &&
           descriptor.voltage_domain == domain;
}

bool hasMosTerminals(const DeviceDescriptor& descriptor)
{
    return descriptor.terminal_count >= 4 &&
           descriptor.terminal_names_by_index.size() == descriptor.terminal_count &&
           descriptor.terminal_index.count(TerminalRole::Drain) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Gate) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Source) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Bulk) != 0;
}

// 仅缺 Bulk/Well 规则不算“可用”，但要单独识别，以便返回 BulkPolicyUnresolved
// 而不是笼统的 MissingInput。
bool mosBlockedOnlyByBulkRule(const DeviceDescriptor& descriptor,
                              DeviceKind kind, const std::string& domain)
{
    return descriptor.kind == kind && descriptor.reliability_complete &&
           !descriptor.oa_library.empty() && !descriptor.oa_cell.empty() &&
           hasMosTerminals(descriptor) && supportsDomain(descriptor, domain) &&
           !descriptor.bulk_rule_complete;
}

bool validParameterMetadata(const DeviceDescriptor& descriptor)
{
    std::set<std::string> cdfNames;
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        const std::string semantic = constraint.semantic_name.empty()
            ? name : constraint.semantic_name;
        const auto mapping = descriptor.normalized_to_cdf.find(semantic);
        if (constraint.cdf_name.empty() ||
            !ValidateParameterConstraint(constraint) ||
            !cdfNames.insert(constraint.cdf_name).second ||
            (mapping != descriptor.normalized_to_cdf.end() &&
             mapping->second != constraint.cdf_name)) {
            return false;
        }
    }
    return true;
}

bool mosUsable(const DeviceDescriptor& descriptor, DeviceKind kind,
               const std::string& domain)
{
    return descriptor.kind == kind && descriptor.reliability_complete &&
           validParameterMetadata(descriptor) &&
           descriptor.bulk_rule_complete &&
           !descriptor.oa_library.empty() && !descriptor.oa_cell.empty() &&
           !descriptor.oa_view.empty() && hasMosTerminals(descriptor) &&
           supportsDomain(descriptor, domain);
}

bool resistorUsable(const DeviceDescriptor& descriptor, const std::string& domain)
{
    bool hasResistance = false;
    for (const auto& [name, constraint] : descriptor.parameter_constraints) {
        const std::string semantic = constraint.semantic_name.empty()
            ? name : constraint.semantic_name;
        if (semantic == "resistance" && !constraint.cdf_name.empty() &&
            ValidateParameterConstraint(constraint)) {
            hasResistance = true;
        }
    }
    return descriptor.kind == DeviceKind::Resistor &&
           validParameterMetadata(descriptor) &&
           !descriptor.oa_library.empty() && !descriptor.oa_cell.empty() &&
           !descriptor.oa_view.empty() &&
           descriptor.terminal_index.count(TerminalRole::Positive) != 0 &&
           descriptor.terminal_index.count(TerminalRole::Negative) != 0 &&
           hasResistance &&
           supportsDomain(descriptor, domain);
}

std::vector<const DeviceDescriptor*> selectMirrorMos(const DeviceCatalog& catalog,
                                        DeviceKind mirrorKind,
                                        const std::string& domain,
                                        const std::string& controlLibrary,
                                        bool& blockedOnlyByBulk)
{
    std::vector<const DeviceDescriptor*> candidates;
    blockedOnlyByBulk = false;
    for (const auto& [name, descriptor] : catalog.Descriptors()) {
        if (mosUsable(descriptor, mirrorKind, domain)) {
            candidates.push_back(&descriptor);
        } else if (mosBlockedOnlyByBulkRule(descriptor, mirrorKind, domain)) {
            blockedOnlyByBulk = true;
        }
    }
    std::sort(candidates.begin(), candidates.end(),
        [&controlLibrary](const DeviceDescriptor* left,
                          const DeviceDescriptor* right) {
            const bool leftSame = left->oa_library == controlLibrary;
            const bool rightSame = right->oa_library == controlLibrary;
            if (leftSame != rightSame) return leftSame;
            return left->master < right->master;
        });
    return candidates;
}

std::vector<const DeviceDescriptor*> selectResistor(const DeviceCatalog& catalog,
                                       const std::string& domain,
                                       const std::string& controlLibrary)
{
    std::vector<const DeviceDescriptor*> candidates;
    for (const auto& [name, descriptor] : catalog.Descriptors()) {
        if (resistorUsable(descriptor, domain)) candidates.push_back(&descriptor);
    }
    std::sort(candidates.begin(), candidates.end(),
        [&controlLibrary](const DeviceDescriptor* left,
                          const DeviceDescriptor* right) {
            const bool leftSame = left->oa_library == controlLibrary;
            const bool rightSame = right->oa_library == controlLibrary;
            if (leftSame != rightSame) return leftSame;
            return left->master < right->master;
        });
    return candidates;
}

// Bulk/Well：目录规则完整是前置条件；孤立阱源衬相连，否则 NMOS→VLOW、PMOS→VHIGH。
std::string mosBulkNet(const DeviceDescriptor& descriptor, DeviceKind polarity,
                       const std::string& sourceNet, const std::string& vhighNet,
                       const std::string& vlowNet)
{
    if (descriptor.isolated_well) return sourceNet;
    return polarity == DeviceKind::MosN ? vlowNet : vhighNet;
}

bool buildMosNets(const DeviceDescriptor& descriptor, const std::string& drain,
                  const std::string& gate, const std::string& source,
                  const std::string& bulk, std::vector<std::string>& nets)
{
    nets.assign(descriptor.terminal_count, std::string{});
    const std::pair<TerminalRole, const std::string*> bindings[] = {
        {TerminalRole::Drain, &drain},
        {TerminalRole::Gate, &gate},
        {TerminalRole::Source, &source},
        {TerminalRole::Bulk, &bulk},
    };
    for (const auto& [role, net] : bindings) {
        const auto found = descriptor.terminal_index.find(role);
        if (found == descriptor.terminal_index.end() ||
            found->second >= nets.size()) {
            return false;
        }
        nets[found->second] = *net;
    }
    return std::find(nets.begin(), nets.end(), std::string{}) == nets.end();
}

bool buildResistorNets(const DeviceDescriptor& descriptor,
                       const std::string& positive, const std::string& negative,
                       const std::string& vhighNet, const std::string& vlowNet,
                       std::vector<std::string>& nets)
{
    nets.assign(descriptor.terminal_count, std::string{});
    for (std::size_t index = 0; index < descriptor.terminal_count; ++index) {
        const auto role = index < descriptor.terminal_roles_by_index.size()
            ? descriptor.terminal_roles_by_index[index] : TerminalRole::Other;
        switch (role) {
        case TerminalRole::Positive: nets[index] = positive; break;
        case TerminalRole::Negative: nets[index] = negative; break;
        case TerminalRole::Substrate: nets[index] = vlowNet; break;
        case TerminalRole::Well: nets[index] = vhighNet; break;
        default: return false;
        }
    }
    return std::find(nets.begin(), nets.end(), std::string{}) == nets.end();
}

// 所有写入值均须登记真实CDF约束；量化未改变数值时保留原文。
bool quantizeElementParams(const DeviceDescriptor& descriptor,
                           const std::map<std::string, std::string>& roleParams,
                           const std::string& roleName,
                           std::map<std::string, std::string>& out,
                           Diagnostic& diagnostic,
                           bool requireUnchanged = false)
{
    out.clear();
    if (!validParameterMetadata(descriptor)) {
        diagnostic = {DiagCode::BadParam,
            "角色 " + roleName + " 的CDF映射或参数约束无效：" + descriptor.master};
        return false;
    }
    for (const auto& [cdfName, text] : roleParams) {
        const ParameterConstraint* constraint = nullptr;
        for (const auto& [semantic, candidate] : descriptor.parameter_constraints) {
            if (candidate.cdf_name == cdfName) {
                constraint = &candidate;
                break;
            }
        }
        if (constraint == nullptr) {
            diagnostic = {DiagCode::BadParam,
                "角色 " + roleName + " 的参数 " + cdfName +
                " 未登记真实CDF数值约束：" + descriptor.master};
            return false;
        }
        bool parsed = false;
        const double value = parseSuffixValue(text, parsed);
        if (!parsed || !std::isfinite(value)) {
            diagnostic = {DiagCode::BadParam,
                "角色 " + roleName + " 的参数 " + cdfName + " 不是合法数值：" + text};
            return false;
        }
        if (value < constraint->minimum || value > constraint->maximum ||
            (constraint->integer_only &&
             std::fabs(value - std::round(value)) >
                 1e-12 * std::max(1.0, std::fabs(value)))) {
            diagnostic = {DiagCode::BadParam,
                "角色 " + roleName + " 的参数 " + cdfName +
                " 不符合CDF类型或范围：" + text};
            return false;
        }
        try {
            const double quantized = QuantizeParameter(value, *constraint);
            if (requireUnchanged && std::fabs(quantized - value) >
                    1e-8 * std::max({std::fabs(value), std::fabs(quantized), 1e-30})) {
                diagnostic = {DiagCode::BadParam,
                    "角色 " + roleName + " 的参数 " + cdfName +
                    " 不在真实CDF量化域内，拒绝改变原管Replica：" + text};
                return false;
            }
            const bool unchangedWithinRoundoff = std::fabs(quantized - value) <=
                1e-12 * std::max({std::fabs(value), std::fabs(quantized), 1e-30});
            out[cdfName] = requireUnchanged || unchangedWithinRoundoff
                ? text : FormatAutoBiasParameter(quantized);
        } catch (const std::exception&) {
            diagnostic = {DiagCode::BadParam,
                "角色 " + roleName + " 的参数 " + cdfName +
                " 无法量化到 PDK 合法取值：" + text};
            return false;
        }
    }
    return true;
}

struct RoleSpec {
    std::string name;
    const DeviceDescriptor* descriptor;
    std::string drain_or_positive;
    std::string gate;
    std::string source_or_negative;
    std::string bulk;
    bool is_resistor = false;
};

bool buildElement(const RoleSpec& spec, const std::string& vhighNet,
                  const std::string& vlowNet, const BiasSizing& sizing,
                  BiasElementPlan& element, Diagnostic& diagnostic)
{
    const auto params = sizing.element_parameters.find(spec.name);
    if (params == sizing.element_parameters.end()) {
        diagnostic = {DiagCode::MissingInput,
            "BiasSizing 缺少角色 " + spec.name + " 的求解参数"};
        return false;
    }
    element.name = spec.name;
    element.model = spec.descriptor->master;
    const bool netsOk = spec.is_resistor
        ? buildResistorNets(*spec.descriptor, spec.drain_or_positive,
                            spec.source_or_negative, vhighNet, vlowNet,
                            element.nets)
        : buildMosNets(*spec.descriptor, spec.drain_or_positive, spec.gate,
                       spec.source_or_negative, spec.bulk, element.nets);
    if (!netsOk) {
        diagnostic = {DiagCode::InvalidTerminalMap,
            "角色 " + spec.name + " 的端子无法按 PDK 角色完整连接"};
        return false;
    }
    return quantizeElementParams(*spec.descriptor, params->second, spec.name,
                                 element.params, diagnostic);
}

} // namespace

std::string FormatAutoBiasParameter(double value)
{
    const std::string compact = formatEngineering(value);
    bool parsed = false;
    const double roundTrip = parseSuffixValue(compact, parsed);
    if (parsed && roundTrip == value) return compact;
    char buffer[64];
    std::snprintf(buffer, sizeof buffer, "%.17g", value);
    return buffer;
}

bool QuantizeAutoBiasParameters(
    const DeviceDescriptor& descriptor,
    const std::map<std::string, std::string>& parameters,
    const std::string& role,
    std::map<std::string, std::string>& out,
    Diagnostic& diagnostic,
    bool require_unchanged)
{
    return quantizeElementParams(descriptor, parameters, role, out, diagnostic,
                                 require_unchanged);
}

bool SelectAutoBiasDeviceCandidates(const AutoBiasTemplateRequest& request,
                                    const DeviceCatalog& catalog,
                                    std::vector<AutoBiasDevicePlan>& plans,
                                    Diagnostic& diagnostic)
{
    plans.clear();
    AutoBiasDevicePlan plan;
    if (request.polarity != DeviceKind::MosN &&
        request.polarity != DeviceKind::MosP) {
        diagnostic = {DiagCode::BadParam,
                      "VBIAS 模板极性只允许 NMOS 或 PMOS"};
        return false;
    }
    if (request.vhigh_net.empty() || request.vlow_net.empty() ||
        request.original_source_net.empty() || request.control_gate_net.empty()) {
        diagnostic = {DiagCode::MissingInput,
                      "VBIAS 模板请求的外部网络不完整"};
        return false;
    }
    plan.control = catalog.Find(request.control_master);
    if (plan.control == nullptr) {
        diagnostic = {DiagCode::NotFound,
                      "控制管 master 不在当前 PDK 目录：" + request.control_master};
        return false;
    }
    plan.cascode = catalog.Find(request.cascode_master);
    if (plan.cascode == nullptr) {
        diagnostic = {DiagCode::NotFound,
                      "Cascode master 不在当前 PDK 目录：" + request.cascode_master};
        return false;
    }
    if (plan.control->kind != request.polarity ||
        plan.cascode->kind != request.polarity) {
        diagnostic = {DiagCode::PolarityMismatch,
                      "控制管/Cascode 与请求的模板极性不一致"};
        return false;
    }
    if (!mosUsable(*plan.control, request.polarity, request.voltage_domain)) {
        diagnostic = {DiagCode::MissingInput,
                      "控制管缺少可靠性、Bulk 规则、端子或电压域数据：" +
                          request.control_master};
        return false;
    }
    if (!mosUsable(*plan.cascode, request.polarity, request.voltage_domain)) {
        diagnostic = {DiagCode::MissingInput,
                      "Cascode 管缺少可靠性、Bulk 规则、端子或电压域数据：" +
                          request.cascode_master};
        return false;
    }

    const DeviceKind mirrorKind = request.polarity == DeviceKind::MosN
        ? DeviceKind::MosP : DeviceKind::MosN;
    bool blockedOnlyByBulk = false;
    const auto mirrors = selectMirrorMos(catalog, mirrorKind, request.voltage_domain,
                                         plan.control->oa_library, blockedOnlyByBulk);
    if (mirrors.empty()) {
        if (blockedOnlyByBulk) {
            diagnostic = {DiagCode::BulkPolicyUnresolved,
                "镜像管候选的 Bulk/Well 规则缺失，拒绝默认短接 Source"};
        } else {
            diagnostic = {DiagCode::MissingInput,
                          "当前 PDK 目录没有可用的镜像 MOS"};
        }
        return false;
    }
    const auto resistors = selectResistor(catalog, request.voltage_domain,
                                          plan.control->oa_library);
    if (resistors.empty()) {
        diagnostic = {DiagCode::MissingInput,
                      "当前 PDK 目录没有可用的真实电阻"};
        return false;
    }
    // Bind a small fixed set by source library and stable master name.
    // Compatibility discovery is retained; electrical performance never ranks masters.
    plan.mirror = mirrors.front();
    plan.resistor = resistors.front();
    plans.push_back(plan);
    return true;
}

bool SelectAutoBiasDevices(const AutoBiasTemplateRequest& request,
                           const DeviceCatalog& catalog,
                           AutoBiasDevicePlan& plan,
                           Diagnostic& diagnostic)
{
    std::vector<AutoBiasDevicePlan> plans;
    if (!SelectAutoBiasDeviceCandidates(request, catalog, plans, diagnostic)) {
        return false;
    }
    plan = plans.front();
    return true;
}

AutoBiasTemplateResult BuildAutoBiasTemplate(
    const AutoBiasTemplateRequest& request,
    const BiasSizing& sizing,
    const DeviceCatalog& catalog)
{
    AutoBiasTemplateResult result;
    AutoBiasDevicePlan plan;
    std::vector<AutoBiasDevicePlan> plans;
    Diagnostic selectionDiagnostic;
    if (!SelectAutoBiasDeviceCandidates(request, catalog, plans, selectionDiagnostic)) {
        result.diagnostics.push_back(std::move(selectionDiagnostic));
        return result;
    }
    plan = plans.front();
    if (!sizing.mirror_master.empty() || !sizing.resistor_master.empty()) {
        // An explicitly bound legal pair is authoritative, even when it differs
        // from the deterministic default chosen for a new solve.
        const auto* mirror = catalog.Find(sizing.mirror_master);
        const auto* resistor = catalog.Find(sizing.resistor_master);
        const DeviceKind mirrorKind = request.polarity == DeviceKind::MosN
            ? DeviceKind::MosP : DeviceKind::MosN;
        if (mirror == nullptr || resistor == nullptr ||
            !mosUsable(*mirror, mirrorKind, request.voltage_domain) ||
            !resistorUsable(*resistor, request.voltage_domain)) {
            result.diagnostics.push_back({DiagCode::BadParam,
                "BiasSizing选中Mirror/Resistor master不属于当前PDK合法组合：" +
                sizing.mirror_master + "/" + sizing.resistor_master});
            return result;
        }
        plan.mirror = mirror;
        plan.resistor = resistor;
    }
    const DeviceDescriptor* control = plan.control;
    const DeviceDescriptor* cascode = plan.cascode;
    const DeviceDescriptor* mirror = plan.mirror;
    const DeviceDescriptor* resistor = plan.resistor;
    std::map<std::string, std::string> checkedCascodeParams;
    Diagnostic cascodeDiagnostic;
    if (!QuantizeAutoBiasParameters(*cascode, sizing.cascode_parameters,
                                    "actual_cascode", checkedCascodeParams,
                                    cascodeDiagnostic, true)) {
        result.diagnostics.push_back(std::move(cascodeDiagnostic));
        return result;
    }

    const bool isN = request.polarity == DeviceKind::MosN;
    // 模板是独立子电路：内部所有连接只能引用固定端口名（VHIGH/VLOW/VS_ORIG/
    // VG_CTRL），请求里的父层网络名只用于非空校验，由 Task 7 在实例化时映射。
    result.template_id = isN ? "VBIAS_N_CASCODE_AUTO" : "VBIAS_P_CASCODE_AUTO";
    result.output_net = isN ? "VBIAS_N" : "VBIAS_P";
    result.ports = {"VHIGH", "VLOW", "VS_ORIG", "VG_CTRL", result.output_net};

    const std::string refNode = isN ? "PBIAS_REF" : "NBIAS_REF";
    const std::string xNode = isN ? "X_REP_N" : "X_REP_P";

    std::vector<RoleSpec> roles;
    if (isN) {
        roles = {
            {"P_REF", mirror, refNode, refNode, "VHIGH",
             mosBulkNet(*mirror, DeviceKind::MosP, "VHIGH", "VHIGH", "VLOW")},
            {"R_REF_N", resistor, refNode, {}, "VLOW", {}, true},
            {"P_OUT_N", mirror, result.output_net, refNode, "VHIGH",
             mosBulkNet(*mirror, DeviceKind::MosP, "VHIGH", "VHIGH", "VLOW")},
            {"N_CAS_REP_N", cascode, result.output_net, result.output_net,
             xNode, mosBulkNet(*cascode, DeviceKind::MosN, xNode, "VHIGH",
                               "VLOW")},
            {"N_CTRL_REP_N", control, xNode, "VG_CTRL", "VS_ORIG",
             mosBulkNet(*control, DeviceKind::MosN, "VS_ORIG", "VHIGH",
                        "VLOW")},
        };
    } else {
        roles = {
            {"R_REF_P", resistor, "VHIGH", {}, refNode, {}, true},
            {"N_REF", mirror, refNode, refNode, "VLOW",
             mosBulkNet(*mirror, DeviceKind::MosN, "VLOW", "VHIGH", "VLOW")},
            {"P_CAS_REP_P", cascode, result.output_net, result.output_net,
             "VS_ORIG", mosBulkNet(*cascode, DeviceKind::MosP, "VS_ORIG",
                                   "VHIGH", "VLOW")},
            {"P_CTRL_REP_P", control, xNode, "VG_CTRL", result.output_net,
             mosBulkNet(*control, DeviceKind::MosP, result.output_net,
                        "VHIGH", "VLOW")},
            {"N_OUT_P", mirror, xNode, refNode, "VLOW",
             mosBulkNet(*mirror, DeviceKind::MosN, "VLOW", "VHIGH", "VLOW")},
        };
    }

    for (const auto& spec : roles) {
        BiasElementPlan element;
        Diagnostic diagnostic;
        if (!buildElement(spec, "VHIGH", "VLOW", sizing, element, diagnostic)) {
            result.diagnostics.push_back(std::move(diagnostic));
            return result;
        }
        result.elements.push_back(std::move(element));
    }
    result.ok = true;
    return result;
}

} // namespace st
