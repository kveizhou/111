# 独立结构变换工程：自动 PDK 识别与服务器验证（2026-10-08）

当前产品入口是本项目的独立 C++ CLI 和项目内 Python/Cadence 脚本。
KimiCode 仅用于参考和复用代码；默认构建、PDK 识别和工作点执行均不要求 Maau 软件、原生库、工艺 Registry 或 Case 文件。
`integration/maau` 与 `server/site/maau_*` 保留为可选历史接入，默认流程不调用它们。

## 独立编译

```sh
./scripts/build.sh
./scripts/test.sh
```

服务器需有 Virtuoso、OCEAN、Spectre 和许可证，Python 3.8+。工具自带 `server/skill/init.il`，setup 和后台默认使用此文件，无需人工找一个 init.il。JSON 先由严格 Python 解析转换为本次动作的 SKILL 数据表达式，再由工具读取。
`setup_backend.csh` 不再内置某个 Maau 安装路径。它会默认选择本项目的 `op_provider.py` / `cadence_runtime.py`。
设置的路径必须来自本次电路和 PDK，不能照抄 KimiCode 或其他工程的实际地址。
独立 OCEAN netlisting 显式加载同一 `ST_SKILL_INIT`，加载失败即停止；本次 helper 路径/内容归档并固定，后续命令恢复该会话的初始化环境。已有额外站点 helper 可显式用 `ST_SKILL_INIT` 指定绝对文件；环境中的 `CCSinvokeInstCdfCallbacks` 仍用于真实 CDF callback，包内 init 不声称包含所有 PDK 初始化或该支持函数。缺失时 materialize 会明确停止并保留日志，需要用当前服务器的实际启动配置修复。

## 使用方式

### 无 Bench 的结构验收（2026-10-09）

显式 `inspect --validation-scope structure_only` 自动从源电路发现 PDK，只读实际 OA/CDF，不要求 simulation profile、Bench、模型 Corner 或供电轨。仅允许保留 MOS 的 Source 串电阻和同 master 共栅 Stack；端序与参数声明仍来自实际 CDF。原 MOS 参数、Gate 和外部 Bulk 保留，未知 N/P 不猜测；真实三端 master 不新增 Bulk。未公布 CDF 范围如实记录未知，具体参数仍经实际 callback/check/save/回读检查。

确认/undo/fresh/generate/open 均由相同独立入口恢复会话范围。generate 保留源图/父图/所有封装子图回读和 staging 整组发布；仅结构成功可 open，DC/PVT/Sizing 均 false。任何后续确认/撤回/fresh 会使旧验证报告失效。具有 Bench 的 DC/VBIAS 路线继续使用下方原流程。

本次 Capless 固定两目标、四个操作文件与完整服务器命令见 [无 Bench 的电阻/Stack 测试](结构测试_无Bench_逐步命令与预期输出_2026-10-09.md)。`prepare_structure_test.py` 只自动准备测试配置；选出的 target/阻值不代表电气适用性已经验证。

### 只读发现与默认 DC/VBIAS 会话

既有 `prepare_session.sh` 创建隔离 `cds.lib` 的步骤保留。默认读取所选源 CellView 的 technology attachment、工艺库 readPath 以及同工艺的实际 OA/CDF primitive 器件库路径。工艺库、器件库可位于不同目录，逐个记录；不猜测共同父目录，不取另一个电路的 PDK。没有注册在 `cds.lib` 的器件库必须先由本次工程正确注册。显式 `--pdk-root` 保留为可选覆盖方式。

只读发现入口无需 Bench/profile/性能要求：

```sh
python3 server/site/standalone.py discover-pdk \
  --backend /ACTUAL/ENGINE/server/st_virtuoso_backend.sh \
  --cds-lib /ACTUAL/SESSION/cadence/cds.lib \
  --lib ACTUAL_SOURCE_LIBRARY --cell ACTUAL_CORE --view schematic \
  --output /ACTUAL/NEW_DISCOVERY_DIRECTORY
```

输出 `源电路=...`、`工艺库=...`、`工艺库路径=...`、`器件库=... 路径=...`、`PDK_DISCOVERY_OK` 和 `PROBE_MASTERS=实际数目`。产物包括 `discovery.tsv`、`pdk_discovery.json`、`pdk_libraries.tsv`、`pdk_probe.tsv`。工艺未关联、实际 primitive 的工艺冲突、没有同工艺器件库或扫描为空均停止。当前发现范围是所选 Core 当前层，不下钻子 Cell。

```sh
python3 server/site/standalone.py inspect \
  --simulation-profile /ACTUAL/THIS_CIRCUIT/simulation_profile.json \
  --pdk-rules /ACTUAL/THIS_PDK/documented_rules.json \
  --backend /ACTUAL/ENGINE/server/st_virtuoso_backend.sh \
  --cds-lib /ACTUAL/SESSION/cadence/cds.lib \
  --lib ACTUAL_SOURCE_LIBRARY --cell ACTUAL_CORE --view schematic \
  --core-subckt ACTUAL_CORE \
  --bench-lib ACTUAL_BENCH_LIBRARY --bench-cell ACTUAL_BENCH --bench-view schematic \
  --work-dir /ACTUAL/NEW_SESSION/work \
  --variant-lib ACTUAL_DERIVED_LIBRARY --variant-cell ACTUAL_NEW_CELL \
  --variant-id ACTUAL_NEW_ID \
  --skill /ACTUAL/ENGINE/skill/standalone_topology_variant.il
```

上述路径是参数占位，不是某个已经执行的服务器地址。`--pdk-rules` 是可选的数据补充：
真实模型/CDF 足以证明的内容直接解析；不能证明的范围、电压域、Bulk/Well、可靠性和电阻额定值需要 PDK 文档提供，缺失会在 `pdk_diagnostics.json` 中说明，相应自动候选不能放行。
CDF 的工程后缀和原生 `lengthMetric` 只换算一次，实际 CDF/文档范围与模型有效域取交集；未知单位不会被模型范围替代。没有 model 默认值的真实 OA master 仍会留下身份和缺失诊断，可以由有来源规则补充。所选 PDK 内未证明的器件会明确阻断工作点；非目标器件也需有真实模型/文档证据，不能按未入 MOS 清单而忽略。
这不能理解为“任意 PDK 地址都必然能直接生成有效 VBIAS”。加密模型、非标准声明和 PDK 特有 callback 需以真实资料验证。

后续保持原来的命令顺序和操作文件格式；同一独立入口会恢复该会话的 PDK 和仿真上下文：

```sh
python3 server/site/standalone.py confirm --session /ACTUAL/NEW_SESSION/work --operation /ACTUAL/operation.conf
python3 server/site/standalone.py list --session /ACTUAL/NEW_SESSION/work
python3 server/site/standalone.py generate --session /ACTUAL/NEW_SESSION/work
python3 server/site/standalone.py open --session /ACTUAL/NEW_SESSION/work
```

源电路及子 Cell 选择范围、四类变换、独立 VBIAS、候选 OA 回读和发布门禁继续由原 C++ 引擎处理。

## 每个电路的仿真条件

`simulation_profile.json` 是本项目普通 JSON，不是 Maau Case。它声明已有 Bench 的实际电气条件：

- `nominal_corner`、可选 `pvt_corners`；
- `op_corners[corner]`：实际 `temperature`、`models`（model_file/section_name）及 `variables`；
- Cascode 所需的 `vbias_vhigh_net`、`vbias_vlow_net`；
- 选填的 `max_branch_current_error`、`max_vbias_current`：暂无性能 Spec 时同时省略；提供时成对且为有限正数，候选及最终 DC/PVT 严格执行；
- `supply_current_signals`：实际完整 PSF 电源电流名及 `sign=1/-1`；
- 可选 `source_subckt`（与 OA cell 名不同的实际子电路名）。

`original_model_files` 默认取名义 Corner 声明的模型文件，也可显式提供。
模型文件可以位于原始 PDK 根目录之外；本次配置明确指定的模型及其字面 `include` 文件都会解析并固定 hash。不能从其他工程补入路径。
当前独立通用入口使用 schematic Bench。模型 sections、设计变量和温度明确指定；未确认的条件不从其他工程借用。
PDK 文档补充规则的 `devices` 可用 `library/cell` 唯一 master 身份作为 key，支持准确类型、模型、CDF 映射、范围、DC signal 名称及电气规则，并必须提供 `source`。
有明确 PDK 上限时可补充正整数 `maxStackLevel`；Stack 同时受该上限和工具最多 100 级的限制。原始 PDK 路径别名和实际路径均保留以便追溯。

无性能 Spec 时，照常使用真实模型、供电、负载和温度求参。报告中的 `validation_scope=dc_operating_point`、`performance_verified=false` 表示直流可行性范围；`current_limits_applied` 说明本次是否应用了用户电流上限。已有启动、稳定性、动态性能目标需要另行仿真验证。

## 实际执行与证据

1. 源电路工艺关联及真实注册路径（或显式 PDK 根目录）→ 实际 OA/CDF probe → 模型类型证据 → 本会话 metadata / SKILL adapter。发现原始记录、JSON 摘要、实际库列表和 probe 均固定 SHA256。
2. 固定输入和模型文件 hash；后续命令的活动路径也必须一致，条件改变需新会话。
3. 实际 OA Bench/DUT → OCEAN netlist；顶层 DUT 变为子电路前，核对真实 OA 端口与 Bench 中源 DUT 端口。原始 include 目录保留。
   Profile 设计变量保留在 Bench 作用域，Corner 更新会作用到 DUT；DUT 原有局部参数保持局部作用域。
4. 按 Corner 更新 Bench 条件 → 唯一 DUT 替换 → 实际 OA master/模型/CDF Spectre 端序完整核对。
5. 直接执行 Spectre → OCEAN 读取 `dcOp` / `dcOpInfo`，保留符号 → 核心工作点/可靠性/电阻/发布门禁。

输入产物保存在 `analysis/standalone_inputs/`；仿真、原始 PSF、signed TSV、OA bindings 和绑定摘要仍在各 OP 目录。
本地进程测试属于契约测试，真实 Cadence/PDK 的结果仍需服务器命令、退出码、日志和原始产物确认。

Cadence API 依据：[OCEAN netlist 目录与启动顺序](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/35371/creatnetlist-with-ocean-in-a-specific-directory)、[dcOpInfo 参数读取](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/2731/use-of-dc-operating-point-parameters-in-calculations-and-plots/475388)、[外部子电路与 CDF termOrder](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/56691/how-to-skip-exclude-a-subckt-s-definition-during-netlisting-for-specific-subckt-s)。这些说明不代表本项目已经现场通过。

原生 CDF `lengthMetric` 与工程后缀依据：[Cadence CDF 示例](https://community.cadence.com/cadence_technology_forums/f/pcell-designer/43429/adding-terminal-and-pins-in-pcell-using-pcell-designer-tool/1365285)。本项目的范围转换仍需用实际 PDK probe 数据核对。

工艺关联读取依据：[Cadence techGetTechLibName](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/26791/how-to-let-a-attached-library-s-techlibname-becomes-itself-library-name)、[Cadence techGetTechFile](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/20229/function-to-get-techfile-via-parameters)。Python 转换 JSON 为 SKILL 数据的思路参考 [Cadence JSON 读取讨论](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/52493/json-to-skill/1385518)。这些依据说明 API/方法，实际 ICADVM18.1 行为需要服务器验收。
