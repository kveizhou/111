四组 Cascode：兆单位读取修复与续跑

适用：上一轮已出现 MIXED_ADMISSION=PASS，并确认 I21/I105/I29/I85 四组；两个 PMOS 因要求值1544314.8799999999、实读值1.5443148800M而失败。

上传 ldo_mixed_mega_retry_fix_20261016.zip 到服务器原工作目录。只执行下面这一整行：

unzip -o ldo_mixed_mega_retry_fix_20261016.zip && bash st-engine-maau/scripts/build.sh --tool-only && bash st-engine-maau/scripts/test_mixed_cascode.sh retry-four "$st_batch/candidate_I21_xbb892w0"

本包修改C++数值解析，因此必须重编。M按百万解析，m仍按千分之一解析；不放宽真实数值差异检查。
retry-four自动读取之前创建的混合会话位置，继续原四组，不重新接入型号，不清空/重新确认操作，也不撤销。

前段预期：
MIXED_RETRY_FOUR=true
ACTIVE_GROUPS=4
REUSE_PREFLIGHT=PASS

若上轮唯一已通过的I21参数完整且仍在本次PDK接受表内，还会出现：
PREVIOUS_SELECTION_SEED_REUSED=true
PREVIOUS_DC_VERDICT_REUSED=false
SHARED_INITIAL_SEED_FROM_OPERATION=op_I21
FIRST_TRIAL_RESISTANCE_OHMS=505763.1232

这是共用初值，不是沿用旧通过结论。I21先试已解点；其它三组仍各自自动寻找，最多16次。每组及最终组合仍需真实DC评估。

只有最终四组实际通过，末尾才会出现：
TEST_GROUPS=4
GENERATED_SUBCELLS=8
MIXED_CASCODE_TEST=PASS

此时才继续原定撤销步骤，每一步等PASS后再执行下一步：

bash st-engine-maau/scripts/test_mixed_cascode.sh three "$st_batch/candidate_I21_xbb892w0"
bash st-engine-maau/scripts/test_mixed_cascode.sh two "$st_batch/candidate_I21_xbb892w0"

最后保留同型NMOS I21和异型PMOS I105，停止撤销。

注意：上轮I85的best_effort/saturation是电气未通过，与这次修复的软件数值误判不同。本补丁不承诺它自动通过。若显示OPTIMIZATION_CANDIDATE_READY，表示已经生成待优化候选，仍不等于四组DC PASS；若显示INCOMPLETE，表示生成尚未完成。两种情况都先不执行three/two。
若未通过，只需提供末尾OPERATION_SELECTION、RESULT、UNMET_REQUIREMENTS、ISSUE和MIXED_CASCODE_TEST行，无需贴每30秒的RUNNING行，无需手动挑型号或阻值。

本地已通过工具编译、235项C++检查和39项Python测试。真实服务器新一轮DC仍待验证。
