#!/usr/bin/env python3
"""Prepare an isolated experiment input draft from accepted caches; no EDA runs.

This succeeds when the draft is saved, not when a circuit or PDK rule passes.
It never searches PDK internals, substitutes CDF defaults, or edits old sessions.
"""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile

from inspect_cascode_pdk_evidence import cached_inputs
from site_data import read_json, write_json


def mapping(value):
    if isinstance(value, dict):
        return dict(value)
    return dict(part.split(':', 1) for part in (value or '').split(',') if ':' in part)


def geometry_mapping(master, rows):
    """Discard generated cdf_* aliases; retain unique physical semantics.

    Additional actual numeric values are frozen by experimental_pdk after it
    reads the instance. Text, model names and layout switches are not trials.
    Fin width is not inferred to be total channel width.
    """
    result = {k:v for k,v in mapping(master.get('normalized_to_cdf')).items()
              if not k.startswith('cdf_')}
    parameters = {r.get('parameter') for r in rows}
    for semantic, parameter in (('length','l'),('fin','nfin'),('fingers','fingers'),('multiplier','m')):
        if semantic not in result and parameter in parameters and parameter not in result.values():
            result[semantic] = parameter
    if len(result) != len(set(result.values())):
        raise ValueError('conflicting physical CDF semantic mappings')
    return result


def prepare(session, batch, bind_native=False, timeout=180):
    bridge, bundle, pdk, native, probe, rails, notes, hashes = cached_inputs(session, batch)
    output = Path(tempfile.mkdtemp(prefix='experiment_inputs_', dir=str(bridge.parent)))
    native_path = batch/'native_records.json'
    probe_path = session/'analysis/standalone_inputs/pdk_probe.tsv'
    roots = sorted({str(Path(p).absolute()) for c in pdk.get('metadata', []) for p in c.get('pdk_paths', [])})
    profile = dict(validation_scope='experimental_dc', nominal_corner=bundle.get('corner'),
        op_corners={bundle.get('corner'): dict(temperature=bundle.get('temperature'),
            variables=bundle.get('variables', {}), models=bundle.get('models', []))},
        pvt_corners=[], validated_baseline_bundle=str(bridge/'bundle/baseline_bundle.json'),
        experimental_pdk_cache=dict(probe=str(probe_path), probe_sha256=hashes.get(str(probe_path)),
            pdk_roots=roots, source_dut=bundle.get('source')),
        experimental_parameter_seeds={})
    # Preserve existing explicit electrical limits/bindings, never derive ratings
    # or supply ownership from the magnitude of a baseline operating point.
    manifest_path = session/'analysis/standalone_inputs/provider_inputs.json'
    if manifest_path.is_file():
        manifest = read_json(manifest_path)
        path = Path(manifest['rules'])
        expected = manifest.get('file_sha256', {}).get(str(path.resolve()))
        if not expected or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('saved simulation profile changed or unbound')
        previous = read_json(path)
        for key in ('vbias_vhigh_net', 'vbias_vlow_net', 'max_branch_current_error', 'max_vbias_current'):
            if key in previous:
                profile[key] = previous[key]
    rules = dict(source=str(bridge/'pdk.json'), devices={})
    pending = []
    selected = [(name, item['master'], item.get('metadata', [])) for name, item in sorted(pdk['targets'].items())]
    # List the small real resistor set. Do not choose a CDF default as a seed.
    resistors = sorted([m for m in pdk.get('catalog', []) if m.get('kind') == 'resistor'],
                       key=lambda m: (m.get('oa_library', ''), m.get('oa_cell', '')))
    if not resistors:
        pending.append('real_resistor_master_and_actual_instance_seed')
    else:
        pending.append('select_one_real_resistor_and_read_its_actual_instance_parameters')
    for instance, master, metadata in selected:
        key = master['oa_library']+'/'+master['oa_cell']
        dev = metadata[0] if len(metadata) == 1 else {}
        target_probe = [r for r in probe if r.get('oa_library') == master['oa_library'] and r.get('oa_cell') == master['oa_cell']]
        rule = dict(model=master.get('model_name', ''), normalized_to_cdf=geometry_mapping(master, target_probe))
        for field in ('kind', 'bulkRule', 'voltageDomains', 'maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'constraints',
                      'dc_signals', 'signal_postfix', 'sim_cdf', 'wFinFormula'):
            if field in dev:
                rule[field] = dev[field]
        names = master.get('terminal_names', '').split(',')
        roles = master.get('terminal_roles', '').split(',')
        if len(names) == len(roles) and len(names) == len(set(names)) and all(names):
            rule['terminalRoles'] = dict(zip(names, roles))
        if rule.get('kind') not in ('mos_n', 'mos_p'):
            rule.pop('kind', None)
            pending.append(instance+': proven_polarity')
        if rule.get('bulkRule') not in ('isolated_well', 'rail'):
            pending.append(instance+': body_connection_strategy')
        semantics = set(rule['normalized_to_cdf'])
        if 'length' not in semantics or not semantics.intersection({'width', 'total_width', 'fin', 'fins'}):
            pending.append(instance+': geometry_to_CDF_mapping')
        if not rule.get('dc_signals', {}).get('intrinsic_vds'):
            pending.append(instance+': documented_CMG_OP_mapping')
        rows = [r for r in native if r.get('scope') == instance and r.get('kind') == 'cdf_value' and r.get('status') == 'OK']
        if not rows:
            pending.append(instance+': actual_instance_parameters')
        profile['experimental_parameter_seeds'][key] = dict(instance=instance, native_records=str(native_path),
            native_records_sha256=hashes.get(str(native_path)), trials={})
        rules['devices'][key] = rule
    for key in ('vbias_vhigh_net', 'vbias_vlow_net'):
        if not profile.get(key):
            pending.append(key)
    if not probe:
        pending.append('actual_OA_CDF_probe')
    if not roots:
        pending.append('source_bound_PDK_roots')
    report = dict(schema='cascode-experiment-preparation-v1', accepted_bridge=str(bridge),
        validation_scope='experimental_dc', required_bindings=sorted(set(pending)),
        deferred=['readable_callback_source', 'res_calc.il', 'complete_parameter_domain',
                  'complete_MOS_and_resistor_ratings_before_experiment'],
        resistor_candidates=[{k: m.get(k) for k in ('oa_library', 'oa_cell', 'model_name', 'terminal_names', 'terminal_roles')}
                             for m in resistors], rail_candidates=rails, cache_notes=notes,
        source_cache_sha256=hashes, input_draft_only=True, experiment_inputs_ready=False,
        native_executions=0, reliability_verified=False, ready_for_sizing=False, vbias_generated=False)
    # Deliberately not a runnable profile until minimal physical bindings are
    # completed. No copying these draft files over an existing session.
    write_json(output/'simulation_profile.draft.json', profile)
    write_json(output/'pdk_facts.draft.json', rules)
    write_json(output/'preparation.json', report)
    if bind_native:
        from experiment_bindings import bind
        return bind(output, session, batch, bridge, bundle, pdk, profile, rules, report, timeout)
    lines = ['CHECKER=cascode-experiment-preparation-v2', 'RESULT=INPUT_DRAFT_PREPARED',
        'VALIDATION_SCOPE=experimental_dc', 'PDK_SOURCE_SEARCH=false', 'COMPLETE_PARAMETER_DOMAIN_REQUIRED=false',
        'COMPLETE_RATINGS_REQUIRED_BEFORE_EXPERIMENT=false', 'NATIVE_EXECUTIONS=0', 'SPECTRE_RERUN=false',
        'EXPERIMENT_INPUTS_READY=false', 'RELIABILITY_VERIFIED=false', 'READY_FOR_SIZING=false', 'VBIAS_GENERATED=false',
        'OUTPUT_DIR='+str(output), 'PENDING_BINDINGS='+','.join(report['required_bindings']),
        'RESISTOR_CANDIDATE_COUNT='+str(len(resistors)), 'DETAILS_FILE='+str(output/'preparation.json')]
    (output/'summary.txt').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', required=True)
    parser.add_argument('--batch', required=True)
    parser.add_argument('--bind-native', action='store_true', help='one read-only OCEAN/OA/PSF binding pass, no simulation')
    parser.add_argument('--native-timeout', type=int, default=180)
    args = parser.parse_args()
    try:
        if args.native_timeout <= 0:
            raise ValueError('native timeout must be positive')
        return prepare(Path(args.session).resolve(), Path(args.batch).resolve(), args.bind_native, args.native_timeout)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print('CHECKER=cascode-experiment-preparation-v2\nRESULT=INCOMPLETE\nISSUE '+str(error))
        print('NATIVE_EXECUTIONS=0\nRELIABILITY_VERIFIED=false\nVBIAS_GENERATED=false')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
