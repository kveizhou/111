# st-engine：独立电路结构变换工具

2026-10-14 最新接续：服务器 binding-v3 已通过，输入准备完成。下一步运行 `run_cascode_experiment.py --session "$st_work" --batch "$st_batch"`，自动仅编译主工具、读取成功绑定并创建 I21 同型 Cascode 隔离实验；采用实际参数起点，运行原生 CDF/DC/回读，结果留在 staging。此轮会执行 Cadence，不保证找到可行点；失败不自动重试。命令和成功标志见 [服务器验证说明](docs/experimental-cdf-server-validation.md)。

2026-10-14 历史：绑定 v3 修复 I105.B=PVDD 与模板 AVDD 的同网异名误拒绝，依据已验收层级端口映射核对，不能只凭相同电压放行。BulkAlias 的 --reuse-native 已由用户回传退出 0。

2026-10-14 当前续接：绑定 v1 已读到模型 TYPE=1/0，但电阻种子原接线字符串比较阻断。现用 `prepare_cascode_experiment.py --reuse-native` 复用该次完整原生记录，按 CMG 文档消费枚举；不再启动 EDA。原电阻接线仅保留上下文，新候选接线仍执行既有回读与电气门禁。见 [复用验证步骤](docs/experimental-cdf-server-validation.md)。

2026-10-14 接续：实验准备已由用户回传退出 0。新增 `prepare_cascode_experiment.py --bind-native`，规范化数值参数映射，一次 OCEAN 只读源 OA 与保存 PSF，核实实际模型类型、Bulk/轨网及真实电阻种子；不运行 Spectre。只读成功并补齐输入不代表 VBIAS 验收。详见下面实验验证说明。

2026-10-14 最新：三项缩减已落实到显式 `experimental_dc` 路径。无需先读懂 PDK 源码或整理完整参数域；逐候选原生 CDF 和回读仍保留。未知额定值允许隔离实验、明确未验证；已知越限仍拒绝，实验不发布、不标为最终通过。服务器下一步和预期输出见 [实验验证说明](docs/experimental-cdf-server-validation.md)。不要继续执行下面历史 res_calc.il 资料命令。

以下为历史交付记录。

2026-10-13 历史续跑：sources-v1返回18个文件（17个OPAQUE），遗漏电阻文件却返回成功；该读取判据已修复。上传独立 `read_cascode_pdk_sources_v2.py` 到工程父目录，沿用当前变量执行：

```csh
set st_src_stamp = `date +%Y%m%d_%H%M%S`
python3 /tmpdata/maau_epc/users/k00981589/read_cascode_pdk_sources_v2.py --session "$st_work" --batch "$st_batch" >& "$st_run/logs/pdk_sources_v2_${st_src_stamp}.log"
set st_rc = $status
cat "$st_run/logs/pdk_sources_v2_${st_src_stamp}.log"
echo "电阻资料读取退出码=$st_rc"
```

本次默认仅补读res_calc.il。只复用同一上下文缓存的确切路径，并在已记录根目录检查这个文件名，不遍历PDK、不打开回调、不启动EDA。明确输出EVIDENCE_FILE和SELECTION，不再静默遗漏。成功必须有RESISTOR_SOURCE_READ=true、RESULT=PDK_SOURCES_READ_OK、退出0；找不到或不可读返回2并保留选择报告。无论读取是否成功，耐压/电阻额定等真实规则仍未确认，不能据此生成电气已验证的VBIAS。若返回2直接提供日志，不反复重试或重做DC。

以下保留历史交付，不重复执行。

2026-10-13 当前步骤：用户已回传 v2 的完整 CDF 回调。l 输入限制70–242nm/1nm取整（小于106nm还改变diffColor），nfin限制4–20/整数；这不是完整电气规则。下一步仅上传独立 `read_cascode_pdk_sources.py` 到服务器工程父目录并执行：

```csh
set st_src_stamp = `date +%Y%m%d_%H%M%S`
python3 /tmpdata/maau_epc/users/k00981589/read_cascode_pdk_sources.py --session "$st_work" --batch "$st_batch" >& "$st_run/logs/pdk_sources_${st_src_stamp}.log"
set st_rc = $status
cat "$st_run/logs/pdk_sources_${st_src_stamp}.log"
echo "定向资料读取退出码=$st_rc"
```

脚本从已有JSON取得精确路径，只读已找到的res_calc.il、libInit.il和后者直接加载的回调文件，不递归搜索、模拟或执行CDF；输出全新pdk_sources_*目录。退出0/RESULT=PDK_SOURCES_READ_OK仅表示文件读取流程完成，OPAQUE表示内容不能作为明文读取；规则仍未应用。缺文件等返回2并列出问题，不反复运行同一命令。日志中的规则文字仍需结合器件/单位/温度确认，未找到的耐压不可从默认值或当前OP推算。

本地已补齐 CMG 内部电压消费：端口电压做耐压检查，内部vds对照vdssat做饱和判断；保留旧TSV格式，原生来源必须逐器件匹配。新CLI solver身份为st-dc-solver-v2-intrinsic，防止复用旧判据结果。实际服务器尚未验证这批求解器变化，后续部署需要完整源码重编；当前只读脚本独立运行，无须先覆盖工程/重编/重跑DC。

以下为历史交付记录，不重复执行已完成步骤。

2026-10-13 最新资料脚本：**inspect_cascode_pdk_evidence_v2.py**。用户回传v1已读到目标CDF回调，但摘要截断且普通SKILL函数造成误报；v2完整输出回调并定向检索，保留原基线/接入结果，原始JSON不改写。上传独立文件到服务器工程父目录后执行：

```csh
python3 /tmpdata/maau_epc/users/k00981589/inspect_cascode_pdk_evidence_v2.py --session "$st_work" --batch "$st_batch"
echo "器件资料读取退出码=$status"
```

预期CHECKER=cascode-pdk-evidence-v2、RESULT=EVIDENCE_COLLECTED、退出0；当前已有完整原生记录时CALLBACK_OUTPUT_COMPLETE=true，回调在CALLBACK_BEGIN/END间完整显示。此标志仅表示回调输出完整，规则仍待确认。PDK_ELECTRICAL_RULES_READY=false不是新失败；真实耐压/合法域/电阻额定依据未自动应用。可选--cached-only仅读缓存。不要再根据器件名或截断预览填入电气规则。

以下保留前批交付记录，不重复执行旧步骤。

2026-10-13 最新进展：用户已回传 FeasibleRuntime 的现场接入通过（v3、退出0、222项一致、Spectre身份确认）。不再重复 --prepare-runtime。下一步按用户要求，从已有 CDF/PDK 查找器件规则依据；新增独立单文件 inspect_cascode_pdk_evidence.py，可上传工程父目录运行：

```csh
python3 ../inspect_cascode_pdk_evidence.py --session "$st_work" --batch "$st_batch"
echo "器件资料检索退出码=$status"
```

脚本自行定位最新成功目录，仅读取缓存与有限范围的PDK文字/文档目录；不运行Cadence，不修改规则，输出到新的pdk_evidence_*目录。预期 RESULT=EVIDENCE_COLLECTED、退出0；TEXT_HITS/DOCUMENTS_FOUND取决于真实资料，SEARCH_LIMITED说明有范围限制或跳过，不是电气失败。返回完整摘要即可。完整片段留在DETAILS_FILE，规则确认前PDK_ELECTRICAL_RULES_READY仍为false。此脚本不依赖其他新代码，无需覆盖旧引擎。

以下为最近完整更新包及历史说明，既已验收的步骤不用重做。

2026-10-13 当前交付：**LDO_Cascode_FeasibleRuntime_20261013.zip**。落实用户确认的四项缩减：使用固定合法器件集合，找到首组 DC 可行参数即进入后续验收；不要求整机精确 IQ 或无关外围节点；模型使用现场 Spectre 加载，不再递归检查、完整封存模型内部。缺失总供电测量显式为 NA/null，不补零。目标节点、VBIAS 支路、接线、器件合法性、可靠性及约定 PVT 等条件保留。

完整包上传到 `/tmpdata/maau_epc/users/k00981589/`，在原 csh/tcsh 会话执行（保留已有 st_work/st_setup/st_preflight/st_batch 变量）：

```csh
cd /tmpdata/maau_epc/users/k00981589/st-engine-maau
unzip -oq ../LDO_Cascode_FeasibleRuntime_20261013.zip -d ..
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "现场接入退出码=$status"
```

解压仅覆盖包内代码，保留兄弟 runs 目录与原现场数据。这一步只执行 Python 接入检查，无需重编 C++，复用已有 222 项正式读取证据，不重跑 DC/OCEAN/Spectre。包内 C++ 求解器也已修改，后续首次使用新求解器生成候选前需要在服务器重新编译；本条检查不会执行旧 C++ 二进制。

预期 `CHECKER=cascode-runtime-bridge-v3`、`RESULT=RUNTIME_BRIDGE_OK`、`BASELINE_CONTEXT_READY=true`、`BASELINE_BINDING_KIND=native-site`、`FORMAL_READER_REUSED=true`、`RUNTIME_CACHE_MATCH=true`、`PSF_UNCHANGED=true`、`OCEAN_RERUN=false`、`SPECTRE_RERUN=false`、退出 0。`MODEL_INTERNALS_CHECKED=false` / `DEPENDENCY_CLOSURE_COMPLETE=false` 是明确取消完整内部封存后的正常状态；兼容字段 `BASELINE_BUNDLE_READY=true` 仅表示现场上下文文件已可用，不代表模型闭包完整。

`PROFILE_MISSING` 仍要求真实高低供电轨；无性能 Spec 时两项电流限值可同时省略，若提供其中一项则另一项仍必需。`PDK_MISSING` 仍列出真实器件规则；`UNRESOLVED_CONTEXT_NODES=3` 不再阻断目标上下文。摘要同时报告历史 `BASELINE_SPECTRE_VERSION` 和 `NATIVE_SIMULATOR_IDENTITY_READY`；若为 UNAVAILABLE/false，应连同摘要回传，后续候选启动仍拒绝身份未确认的工具。已绑定输入、直接引用模型和缓存变化仍报错，原生模型加载失败仍失败。

本地已通过 19 个 C++ 测试程序、76 项相关 Python 测试、8 项服务器辅助测试、2 Demo、CLI 与后端契约。独立复核 P1/P2=0。本次未在真实 Cadence 运行；完整 LDO 验收尚未完成。CMG 内部/端口电压消费、真实 PDK/Profile 绑定、候选生成与约定启动/稳定性/PVT 仍待完成，相关 READY / ELECTRICAL_VERIFIED / VBIAS_GENERATED 保持 false。不要因这些 false 重跑旧基线；回传本次摘要和退出码即可。旧 cadence_runtime.py 字节保持。

以下仅为历史记录，不需要重复旧步骤，涉及完整递归封存的旧要求由本批范围修订替代。

2026-10-13 历史交付：**LDO_Cascode_SectionLabels_20261013.zip**。用户确认服务器真实模型节名为 `18_total_HF`，此前代码自定“字母/下划线开头”约束误拒绝。已同步修复 SPICE/Spectre 的声明及引用解析，保留名称精确匹配、节配对、跨节遍历、循环及漂移检查。

上传完整包到原工程父目录，在当前 st-engine-maau 目录执行：

```csh
unzip -o ../LDO_Cascode_SectionLabels_20261013.zip -d ..
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "基线封存退出码=$status"
```

继续复用已验证的 222 项缓存，不重跑 OCEAN/Spectre/DC，不改模型/PSF/旧会话。封存完整才 RESULT=RUNTIME_BRIDGE_OK / BASELINE_BUNDLE_READY=true / 退出 0。尚有依赖问题时，不生成合格 Bundle；集中输出 BUNDLE_ISSUE_COUNT、DEPENDENCY_ISSUE、BUNDLE_ISSUES_FILE。完整消息保存为 bundle_dependency_issues.json，包括可解析选中分支内已发现的问题，无法继续解析的失败分支明确不视为完整检查，节声明摘要截断有计数。若仍失败，返回这些摘要行和退出码，无需手工转录整个模型。该诊断不放宽 PDK/Profile/CMG/PVT/VBIAS 的门禁。

本批本地专项通过不能代替真实服务器模型验收；旧 cadence_runtime.py 保持字节不变。以下保留此前交付记录，无需重做旧步骤。

2026-10-13 前批交付：**LDO_Cascode_ModelSections_20261013.zip**。服务器已确认正式读取缓存复用成功（222 项一致，OCEAN/Spectre 未重跑，PSF 未变）；此前封存按文件路径判环且忽略 section，可能误拒绝同模型文件的跨节引用。本批改为按文件及选中 section 遍历，保留真正循环检查与完整引用链；只展开选中节，文件内容仍整体哈希，额外模型选择也保留其 section。

完整包上传到原工程父目录，在当前 st-engine-maau 目录执行：

```csh
unzip -o ../LDO_Cascode_ModelSections_20261013.zip -d ..
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "基线封存退出码=$status"
```

同一个包重复解压会覆盖包内同名代码，不会清空兄弟 runs 目录或修改真实 PDK。保持既有 shell 变量/会话/结果，无须重新编译或重新运行 DC。预期 FORMAL_READER_REUSED=true、OCEAN_RERUN=false、SPECTRE_RERUN=false；封存完成才 BASELINE_BUNDLE_READY=true / RESULT=RUNTIME_BRIDGE_OK / 退出 0。如果仍存在真实循环或其它依赖问题，保留缓存与具体 BUNDLE_ISSUE，不声明封存成功。模型原文件仅只读，旧 cadence_runtime.py 字节保持。本批真实模型封存尚待服务器验证，PDK/Profile/CMG/PVT 与 VBIAS 电气门禁仍未通过。

以下保留此前交付记录，不需要重复旧步骤。

2026-10-13 前批交付：**LDO_Cascode_BundleResume_20261013.zip**。服务器已回传正式 reader 的 222 个有符号值与缓存一致，PSF 未改；Bundle 因 `.lib mos_si_flag_on` 节声明被误作文件引用而失败。本批补齐 SPICE 节声明/文件引用解析，不改变基线。

将完整包覆盖到原 st-engine-maau 目录后，仍执行同一条命令，无需重编或重跑 DC：

```csh
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "基线封存退出码=$status"
```

预期 `FORMAL_READER_REUSED=true`、`OCEAN_RERUN=false`、`SPECTRE_RERUN=false`、`RUNTIME_CACHE_MATCH=true`。最新 v1 成功读取会经过原生表/来源/请求/PSF/有符号值复算验证后直接复用，后续复用还核对来源文件哈希；不修改旧证据或回退到更早成功目录。Bundle 完成时 `BASELINE_BUNDLE_READY=true`、`RESULT=RUNTIME_BRIDGE_OK`、退出 0；若实际模型还有未支持依赖，则仍保存已通过读取、列 BUNDLE_ISSUE 并退出 2，不重复 OCEAN。无法验证最新读取证据时停止并说明原因。

上述是封存/读取验收。PDK 可靠性与几何、供电范围、CMG 内部/端口电压消费及固定参数 PVT 仍待完成，`SIMULATION_PROFILE_READY`、`PDK_ELECTRICAL_RULES_READY`、`ELECTRICAL_VERIFIED`、`VBIAS_GENERATED` 保持 false。旧 cadence_runtime.py 字节保持，KimiCode 未修改。本批修复的真实服务器验收待回传。

以下保留前批交付记录；不需要重复其读取步骤。

2026-10-13 前批交付：**LDO_Cascode_RuntimeBridge_20261013.zip**。服务器已回传 node-context-v2 / TARGET_CONTEXT_READ_OK / 退出 0，目标节点、cgg 与 OP 缓存已验收；三个外围节点缺失保留，不再逐项续读。

本批使用版本化 `cascode_runtime.py` 与共享 `dc_results.py`，保留旧 `cadence_runtime.py` 字节和旧 session。正式 Provider 的 Bundle 分支复用已验证 Bench/Corner/DC，实际导出候选 DUT 后唯一替换。`--prepare-runtime` 用同一旧 PSF 校验正式读取器与缓存数值完全一致，并集中生成 remaining_inputs.json。它不运行 Spectre，不修改 OA，不生成 VBIAS，也不生成伪完整电气 profile。

完整包覆盖到原 st-engine-maau 目录后，保留现有 shell 变量，执行：

```csh
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --prepare-runtime
echo "正式读取接入退出码=$status"
```

预期 `RESULT=RUNTIME_BRIDGE_OK`、`RUNTIME_CACHE_MATCH=true`、`PSF_UNCHANGED=true`；原始报告保存在输出的 runtime_bridge_* 目录。若 Bundle 依赖暂不可封存而正式读取已匹配，返回 `READER_OK_BUNDLE_INCOMPLETE` / 退出 2，同时保留 `RUNTIME_CACHE_MATCH=true` 和具体 BUNDLE_ISSUE，不需要因此重跑旧 DC。PDK 几何、可靠性、Bias 电阻额定条件、供电统计范围和 BSIM-CMG 端口/内部电压的求解器消费契约仍待完成，READY / ELECTRICAL_VERIFIED / VBIAS_GENERATED 保持 false。Bundle 只有一个 Corner；其它 PVT 条件必须独立绑定。未完整映射的启动设置集中列入 omitted_launch_options，并阻止候选仿真，不能忽略后声称完整继承。

这是正式入口的本地接入验证，原生 Cadence 验收待本次服务器回传。DCHelper 的有符号 raw 数据与 vdsat/vdssat 映射被用于核对，未复用取绝对值或缺失补零的便捷接口，也未修改 KimiCode。

以下是旧批次记录及命令，保留溯源；无需重复执行。


2026-10-13 上一批交付：**LDO_Cascode_NodeResume_20261013.zip**。服务器回传已证明 I21/I105 八个 D/G/S/B 端口电压、cgg/reversed 和端口差分读取完成；v1 退出 2 是另外三个外围请求节点未找到。核心 AGND 实际映射到 ldo_sim_top.AGND_IP，已读到；缺失的 root AGND 不能用这个值替代。缺项底层原因尚不明确，用户摘要来自转录，原始缓存为准。

同一个读取文件升级为 `--read-node-context` v2：验证上次请求、PSF、原生表和报告，复用已经成功的数据，只对缺项按原始全名直接查询。保存输出名称清单和原生来源哈希，连续续读只合并此前缺项；最新缓存完整性失败不回退其他缓存。已有 DC、OP 和 OA 均不重跑/修改。

服务器替换同一个 `server/site/read_cascode_solver_settings.py` 后执行：

```csh
set st_node_stamp = `date +%Y%m%d_%H%M%S`
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --read-node-context >& "$st_run/logs/node_context_${st_node_stamp}.log"
set st_rc = $status
cat "$st_run/logs/node_context_${st_node_stamp}.log"
echo "节点上下文读取退出码=$st_rc"
```

按本次服务器缓存，预期 `CHECKER=cascode-node-context-v2`、`NODE_VALUES_REUSED=true`、`NODE_QUERY_COUNT=3`、`TARGET_NODES_COMPLETE=true`、`CACHED_CGG_COMPLETE=true`、`PSF_UNCHANGED=true`。若三个外围节点仍缺，退出 0 的含义仅是 `RESULT=TARGET_CONTEXT_READ_OK`，同时明确 `NODE_READ=PARTIAL`、`CONTEXT_NODES_COMPLETE=false` 和全部缺项；并非全部上下文通过。只有全请求数值完整才输出 `BASELINE_CONTEXT_READ_OK` / `NODE_READ=COMPLETE`。目标缺项、坏数值/重复、原生失败或来源变化仍退出 2。日志与退出码一并回传；失败停在本步，不重跑 DC、不改固定输入。

新增 `VSOURCE_TOPOLOGY` 与保留的有符号 `VSOURCE_CURRENT_CANDIDATE` 用于下一步核对 V0/V4 的统计角色；电流候选不能直接相加为总供电。正式 config/候选 Provider、PDK 几何与可靠性规则、供电计量和 VBIAS 闭环未完成，相关 READY / ELECTRICAL_VERIFIED / VBIAS_GENERATED 继续 false。

本轮改动和缓存兼容仅本地验证，三缺项的定向查询仍需服务器。v1 的目标端口已由用户回传验证，不因外围缺项否认这部分成果；不把 v2 本地夹具升级为原生执行。证据与限制见 [P-033](docs/02-实施计划.md) 和 [本轮验证目录](docs/validation/2026-10-13-node-resume/)。

沿用 [Cadence 的 dcOp / outputs(?map nil) / getData 示例](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/37727/any-way-to-format-the-print-statement-in-spice)。outputs 名称清单用于诊断，不再以它的成员判断阻止真实定向 getData；查不到的名称仍缺失，不推断为别名或零，不做模糊匹配。缓存来源包含每次实际查询表、请求和原生完成标记，全部保留在服务器。

2026-10-13 最新服务器验收：**原电路基线 DC 与 I21/I105 工作点读取已通过**。用户回传 cascode-saved-op-v3、BASELINE_READ_OK、退出 0；两目标各读到 106 个数值参数，vdsat←vdssat 实测生效，PSF 未改变，未重跑 Spectre。所选条件仍是 Copy_PT_FUNC_703 / 125°C。证据与后续缺口见 [P-031](docs/02-实施计划.md) 和 [回传登记](docs/validation/2026-10-13-baseline-accepted/server_feedback.json)。这是用户服务器摘要验证，本机未取得原始 PSF。

上一版已交付完整包为 **LDO_Cascode_OPSchema_20261013.zip**；当时完成基线 OP 服务器验收，节点续读按上方新入口执行。正式 config/候选 Provider、PDK 电气规则及 Cascode/VBIAS 闭环尚未完成。

原始参数、状态和归一化来源留在新的 baseline_op.json / baseline_op_report.json；摘要总是先给 I21/I105 已读数值，然后列出各自缺项/冲突。OP_READ=COMPLETE 表示原生读取结束且表结构有效；OP_REQUIRED_FIELDS_COMPLETE=true 才表示所需有符号字段在各自同一器件上完整，仍不等于电气验收。真正缺参、非有限必填值、别名冲突或多个完整器件无法唯一定位仍退出 2。未删除 vdsat 门槛、不推算/补零、不取绝对值。

以下是本次已成功执行的 **--read-op-only** 命令，保留用于复查；当前无需重复执行：

```csh
set st_op_stamp = `date +%Y%m%d_%H%M%S`
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --read-op-only >& "$st_run/logs/saved_op_${st_op_stamp}.log"
set st_rc = $status
cat "$st_run/logs/saved_op_${st_op_stamp}.log"
echo "工作点读取退出码=$st_rc"
```

入口在当前 batch 中选择 status 时间最新的 converged 基线，打印 BASELINE_DIR；对该份缓存、完成标记、实际网表/模型/变量、有效设置、APS 日志及非空 PSF 重新核对，失败不回退其他基线。只创建该基线下的 op_review_* 子目录，调用 OCEAN，不读取 Maestro、不生成网表、不运行 Spectre。PSF 用流式 SHA-256 在读取前后核对，原始基线及旧错误保留。旧格式如果存在非空 Definition Files 而没有历史哈希，则拒绝复用，不能猜测其未改变。

摘要标识 `CHECKER=cascode-saved-op-v3`；成功应有 `SPECTRE_RERUN=false`、`BASELINE_DC=CONVERGED`、`OP_READ=COMPLETE`、`OP_REQUIRED_FIELDS_COMPLETE=true`、`PSF_UNCHANGED=true`、两目标 OP 和 `RESULT=BASELINE_READ_OK`/退出 0。必填字段缺项/无效仍返回 INCOMPLETE/退出 2，此时 OP_READ 可以是 COMPLETE，而 OP_REQUIRED_FIELDS_COMPLETE=false；设置已应用与 DC 已完成状态独立保留。错误优先给 OP 日志尾部/类型与命中记录；摘要最多 190 行，原始数据留服务器。只完成读取不代表电气可接受，ELECTRICAL_VERIFIED/VBIAS_GENERATED 仍为 false。

读取方法依据 Cadence 关于 [dcOpInfo 器件参数与节点 DC 结果的区别](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/16070/capturing-all-operating-point-info-in-a-text-file)、[按类型枚举器件/参数](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/2731/use-of-dc-operating-point-parameters-in-calculations-and-plots/475388)及 [outputs 的原始网表名映射](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/37727/any-way-to-format-the-print-statement-in-spice)。本机没有 Cadence；本次用户回传已验证 I21/I105 的实际数据读取，其他正式候选流程仍需独立验证。

参数映射来自 KimiCode/src/modules/optimization/elements/evaluationengine/dcsignoisetool.cc:104 的 IsVdsatSignal，以及 common/core/ops/signal_reader/signal_reader.cc:71 的查表模式。仅采用有依据的 vdsat←vdssat 映射：其他缺字段不能拿 vdssat 补上。参考 SignalReader 对任意缺参也尝试 vdssat、SignalTable 取绝对值与模糊查名的行为不适用于本次诊断。完整参考链路已读，底层 DCHelper/SpecSimulationTask 本地仍为空，因此不依赖其未提供实现。

[Cadence 的 BSIM-CMG 参数说明](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/43222/parameters-of-a-finfet)确认 vdssat 的含义，并区分内部 vds/vgs 与端口 vdst/vgst。新读取同时保留这些原字段，不互相替代；VBIAS 求参与可靠性判定仍需后续结合实际模型和电路审查。本次两目标的映射已实测通过，不等于候选电气门禁通过。

数值格式依据：[Cadence 对整数/浮点与 %g 的说明](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/26631/analysis/1327597)，以及 [float() 类型转换示例](https://community.cadence.com/cadence_blogs_8/b/pcb/posts/understanding-data-type-conversion-for-effective-allegro-skill-programming)。本地新增整数 region=0/1、整数电流 0、有符号浮点的边界回归；不替代原生 OCEAN 验证。

本次已核对传输的代码.md 中的新 DC 参考源码（KimiCode/src/，仅阅读）：

| 参考位置 | 实际作用及当前限制 |
| --- | --- |
| modules/optimization/elements/preprocess/internal/persistence/pre_simulation_helper.cc:175、common/core/ops/simulator/simulation_flow.cc:24 | 组装温度/模型/保存项，串接网表处理、仿真、信号绑定；可指导后续正式 Host 集成。 |
| common/core/ops/simulator/simulator.cc:26 | 封装 SpecSimulationTask 阻塞执行、PSF/日志路径及错误返回；底层 platform/skill/spec_task.cc 当前为空。 |
| modules/optimization/elements/evaluationengine/dcsignoisetool.cc:60、preprocess/internal/summary/psf_data.cc:17 | 读取 dcOp.dc、参数名称映射、导出原始信号；DCHelper .cc/.h 和 psf_ext.h 当前为空，完整解析器仍缺。 |
| service/access/get_dc_point.cc:20、modules/optimization/elements/preprocess/internal/persistence/dcac_filter.cc | 前者仅查保存选项状态；后者仅更新优化输入 keyDevice，不是 DC runner。 |
| modules/optimization/elements/postprocess/internal/smallsignalsim/small_signal_simulation.cc:73 | 多 PVT 循环都写同一 _modify.scs，存在路径覆盖风险；本轮未修改/执行该参考项目。 |

参考实现中 dcsignoisetool.cc:154 的单信号分支取绝对值；当前 OP 诊断必须保留电压/电流符号。SimulationAdapter 会重写保存项/温度/模型，不能直接套到当前已收敛基线。后续正式集成应补齐底层文件、明确保存数据来源和参数/层级映射，独立输出每个 Corner，继续分开判断完成、收敛、OP 完整与电气合格。本轮仅修复当前续读错误。

此前 R2 基线启动入口（以下 --run-dc 会重新仿真，当前续读无需执行）：

2026-10-13 R2 修正：服务器在读取完成后被 tran 的带引号动态表阻断，DC 尚未启动。现在先识别并整条排除非 DC 分析，输出 `SKIPPED_NON_DC index=2 analysis=tran` 等；不会把动态表传入基线。实际要使用的设置仍严格校验，错误集中为 `FAILED_SAVED_FORM index=... name=... issue=...`，附非法字符位置/附近原文，或非空恢复状态及重复字段值。若服务器原文确有 restart/savestate 非空或重复 abstol，则继续明确拒绝，不依照聊天转录清空或改写。新版基线摘要标识为 `CHECKER=cascode-saved-dc-v2`。本地修复不表示真实基线已通过。

2026-10-13 R2 历史包：**LDO_Cascode_SavedDC_R2_20261013.zip**。用户已回传保存设置读取成功：7 个完整表达式、退出 0。下一步用同一个 `server/site/read_cascode_solver_settings.py` 的 `--run-dc`，在独立目录按保存的 DC/APS 设置复测原电路。当前服务器只替换这个 Python 文件即可；无需重编 C++ 或重扫 PDK。

```csh
set st_dc_stamp = `date +%Y%m%d_%H%M%S`
python3 server/site/read_cascode_solver_settings.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --batch "$st_batch" --run-dc --dc-timeout 600 >& "$st_run/logs/saved_dc_${st_dc_stamp}.log"
set st_rc = $status
cat "$st_run/logs/saved_dc_${st_dc_stamp}.log"
echo "基线DC退出码=$st_rc"
```

沿用当前终端已存在的 `st_*` 变量，不从聊天转录重建路径。入口重新只读导出原生设置及 Definition Files，只应用字面 DC/options/envOption/ic/nodeset；不加载整个导出脚本。保存的 maxiters=150/maxsteps=10000、APS/Conservative/Manual/4 线程交给 OCEAN 原生处理；Corner 仍为 Copy_PT_FUNC_703/125°C，覆盖 base test 的 27°C。原 DC 超时与保存设置存在差异，但差异是否导致超时仍待本次实验。

先用实际 config 生成网表，核对原电路/参数/模型/变量不变，并核对实际 DC 迭代参数、温度和关键标量容差，再在 local 模式运行并复核；保存的 tran/stb 不运行，da_en 动态表不用于 DC。APS 启动证据、非空 DC/OP PSF 和 I21/I105 有符号 OP 均必须具备，才返回 `RESULT=BASELINE_READ_OK`、`BASELINE_DC=CONVERGED`、退出 0。失败返回 `RESULT=INCOMPLETE`/退出 2，附有效控制语句、错误与有限日志尾部；不要绕过失败继续生成 VBIAS。缺 OP 时可能 DC 已完成但整体仍不通过。

新目录位于已有 `st_batch/dc_review_ports_*`；原始材料、OCEAN、网表、PSF 和 JSON 留服务器，摘要最多 190 行。原生只读/网表/OP 各阶段默认 180 秒，DC 600 秒；Ctrl+C 清理本入口子进程组，退出 130。`JOB_POLICY_ERROR_PRESENT` 保留原 Maestro 问题，local 诊断成功也不等于修复其调度。不加 `--run-dc` 时仍保持原只读行为，成功为 `RESULT=READ_OK`，不启动 Spectre。

本地外部进程夹具不等于 Cadence 语义或真实服务器验收。即使基线完成，`SIMULATION_PROFILE_READY=false`、`PDK_ELECTRICAL_RULES_READY=false`、`ELECTRICAL_VERIFIED=false`、`VBIAS_GENERATED=false` 仍保留；正式 config 接入、真实 FinFET 几何/可靠性规则、Cascode 求参与发布尚待完成。APS 设置形式参考 [Cadence 原生 OCEAN 示例](https://community.cadence.com/cadence_technology_forums/f/custom-ic-design/41116/spectre-tran-simulation-and-multithreading)，本机未执行 Cadence。

此前批量包：**LDO_Cascode_Batch_20261012.zip**。批量入口 `server/site/collect_cascode_batch.py` 复用已成功的会话、Maestro 读取和 config 网表缓存，一次收集 I21/I105、控制/负载文字引用、真实 PDK/CDF 缺项；再只读取得源 CDF 和保存测试的 Definition Files，尝试原电路单点 DC 及目标带符号 OP。每阶段单独报告，原始日志/PSF 留服务器，stdout 最多 190 行。它不生成 Cascode/VBIAS，DC 收敛仍不是电气验收。12 项批量专项及当时完整回归通过；用户实际服务器批量 INPUT/CONTEXT/PDK/NATIVE/UNCHANGED 完成，原 DC 在 600 秒超时后由脚本发送 SIGTERM 中止，OP 跳过，退出 2。

```bash
python3 server/site/collect_cascode_batch.py --session "$st_work" --maestro-read "$st_setup/maestro_read.json" --preflight "$st_preflight" --output "$st_batch"
```

`st_batch` 必须是新的绝对目录。退出 0 表示本批各项收集完成；退出 2 保留已完成阶段和错误摘要，直接回传整份 stdout 即可。每个 Cadence 进程默认超时 600 秒；Ctrl+C 清理本入口的子进程组并返回 130。不会重新确认已选择的 Corner，也不会修改既有源 OA、配置、波形或已验证的结构变体。完整 Cascode 电气接入、当前 FinFET 参数约束和可靠性资料仍未完成。

2026-10-12 前置入口：用户已选 `Copy_PT_FUNC_703`（125°C、AVDD=1.14、iout=10m）。`server/site/preflight_cascode_bench.py` 从 READ_OK 配置缓存保持变量大小写并使用真实 `config_presim` 在独立目录生成网表；只回传核心路径、源激励与参数摘要，原始文件留服务器。该前置入口不运行 Spectre、不生成 VBIAS，不需要重编 C++ 或重扫 PDK；用户已经回传其实际成功结果，后续改用上方批量入口。完整 DC 接入的 FinFET 参数约束、可靠性与激励设置仍需补齐，当前不能说全部开发仅剩验收。


2026-10-12 服务器进展：用户返回 `check_structure_result.py` 的四次真实只读导出、`RESULT=PASS`、`FAILED_CHECKS=0` 和退出 0；该次 Source 电阻/三管共栅 Stack 的结构已验证。电气、GUI 外观及显式 OA 属性独立校验仍未完成。同型/不同 master Cascode 和自动 VBIAS 尚未完成真实服务器验收。

新增 `server/site/read_maestro_setup.py`：从现有会话的实际 cds.lib，只读打开用户指定 Bench 的 Maestro view，读取测试设计、模型/section、变量及 Corner 覆盖/启用标志。完整报告保留服务器，摘要最多 190 行；不保存、不生成网表、不仿真、不把 config 改为 schematic、不创建或修改 simulation profile。用户已回传 Maestro 原生 READ_OK、865 条设置和退出 0，并已取得成功的 config 前置网表；不能把这些证据当作 Cascode/DC 已通过。

```bash
python3 server/site/read_maestro_setup.py --session "$st_work" --bench-lib HiAplatRV500_ldo_sim --bench-cell ldo1_1_stb_dc_sim_cbb --setup-view maestro_pvt_ea --expected-library-path /tmpdata/maau_epc/users/k00981589/maau_cbb/HiAplatRV500_ldo_sim --output "$st_setup"
```

2026-10-10 当前完整包：**`LDO服务器测试包_物化日志完整保留_2026-10-10.zip`**，包含此前原 MOS 显式属性保留等全部修复。本批仅修复成功 materialize 日志被截为前 240 行的问题，完整保留后面的属性复制证据；C++/电路生成/回读与发布规则不改，已编译服务器无需重编。用户当前只回传 grep 退出 1，不能据此判定生成失败；先按 [日志缺失检查](docs/服务器结构测试_物化日志缺失检查_2026-10-10.md) 读取当前 validation.txt，不重复 generate 或删除会话。属性保留实际 OA/发布验收仍以服务器报告为准。

**此前 CDF 类型修复：** 已确认符号列表与同名 OA 字符串的区别，严格 reader 转换名称表示后继续校验端子数量、名称和唯一性。本批所需扫描政策、日志及验证文件均在当前完整源码包中；真实 OA 运行结果仍须由服务器提供。


当前版本支持自动识别 PDK、无 Bench 的 `structure_only` 电阻/共栅 Stack 结构生成，以及没有性能 Spec 时的名义 DC 求参。结构模式仍验证真实 OA/CDF、源图及父子图回读并整组发布，但 DC/PVT/Sizing 为 false；不能据此声称改后电路工作正常。用户已回传 R3 真实 PDK 发现成功，本批真实 OA 生成/发布以及 Spectre 求参仍待服务器验收。

这是一个独立 C++17 工程。Maau 代码只用于参考已有网表化流程，默认构建不依赖 Maau。工具接收 Virtuoso 工程的 `cds.lib + 核心 library/cell/view`，由服务器适配器自动生成原始网表，不要求用户手工提供网表。

2026-10-08 当前产品入口见 [自动 PDK 识别与服务器验证](docs/standalone-pdk-server-validation.md)，手工命令见 [逐步命令与预期输出](docs/服务器测试_逐步命令与预期输出_2026-10-09_R3.md)：
`server/site/standalone.py` 默认从所选源电路的工艺关联和注册路径发现 PDK，解析实际 OA/CDF 和模型，并恢复独立仿真上下文。`--pdk-root` 是可选覆盖；工具 init.il 默认随包提供。
工作点默认直接调用 Cadence/OCEAN/Spectre。`integration/maau` 与 `server/site/maau_*` 是可选历史接入。
本页后面的原 C++ 命令说明其结构命令和产物；使用真实自动 VBIAS 时通过独立入口保存和恢复本次 PDK/仿真配置。

工具支持：

1. 同型 Cascode；
2. 同极性、不同真实 PDK master 的 Cascode；
3. 保留 MOS，并在其电气 Source 路径串联 PDK 电阻；
4. 2～100 级同型 MOS Stack。

同一会话可连续“确认变换”，最后只生成一个派生电路；`undo` 撤销上次修改，`fresh` 恢复初始逻辑结构。源 schematic、config 和网表不会被覆盖。

## 当前真正实现的流程

```text
核心 library/cell/schematic
  -> 后端调用 Virtuoso/OCEAN 生成 before/core_before.scs
  -> 导出 PDK/CDF/termOrder 和当前层实例坐标
  -> 只列核心 cell 当前层直接 MOS
  -> Confirm / Undo / Fresh 维护一个 Change Set
  -> 在结构化网表上执行四类变换
  -> 每个独立变换区域封装为子 schematic + symbol
  -> 多次修改同一派生区域时合并为一个封装
  -> expected/core_expected.scs
  -> baseline/expected diff 生成 materialization/plan.json
  -> 克隆源 schematic 到 staging
  -> SKILL 创建封装子Cell中的真实PDK器件、端口和symbol
  -> 父 schematic 只删除原管并放置一个wrapper实例
  -> check/save
  -> source 和 staging 分别重新生成网表
  -> 验证源图未变，expected 与 after/core_roundtrip.scs 等价
  -> 发布最终派生 library/cell/schematic
```

工具不会从 testbench 开始递归扫描整个工程。它只显示所选核心 cell 当前层的 MOS；若要修改子模块内部的 MOS，请把该子模块重新作为核心 L/C/V 建立会话。

## 一键编译与测试

本机没有 CMake 也能编译：

```bash
cd "/Users/zkw/Desktop/ChatGPT/Maau UI的一次讨论/st-engine-maau"
./scripts/build.sh
./scripts/test.sh
```

这两个命令默认只编译和测试独立工具，不读取 `integration/maau`。如需额外验证旧 Maau 接入兼容层，可显式执行：

```bash
ST_BUILD_MAAU_COMPAT=ON ./scripts/build.sh
ST_BUILD_MAAU_COMPAT=ON ./scripts/test.sh
```

生成的程序在：

```text
build/bin/st_circuit_tool
```

有 CMake 时也可以：

```bash
cmake -S . -B build-cmake
cmake --build build-cmake
ctest --test-dir build-cmake --output-on-failure
```

默认 CMake 构建不包含 Maau 兼容层。只有需要验证旧接入契约时才增加：

```bash
cmake -S . -B build-cmake -DST_BUILD_MAAU_COMPAT=ON
```

## 实际使用

第一步，从 Virtuoso 核心电路建立工作会话：

```bash
./build/bin/st_circuit_tool inspect \
  --backend /path/to/st-engine-maau/server/st_virtuoso_backend.sh \
  --cds-lib /project/cds.lib \
  --lib LDO_LIB \
  --cell capless_ldo \
  --view schematic \
  --core-subckt capless_ldo \
  --bench-lib LDO_BENCH \
  --bench-cell capless_ldo_tb \
  --bench-view schematic \
  --simulator spectre \
  --nominal-corner tt \
  --vbias-vhigh-net AVDD \
  --vbias-vlow-net VSS \
  --work-dir /project/result/ldo_structure_session \
  --variant-lib LDO_DERIVED \
  --variant-cell capless_ldo__TV0001 \
  --variant-id TV0001 \
  --skill /path/to/st-engine-maau/skill/standalone_topology_variant.il
```

`--bench-*` 声明真实测试台，`--vbias-vhigh-net/--vbias-vlow-net` 声明父层轨网。上述底层 C++ CLI 的只读发现可省略这两组成组选项；Bench 缺失时不能 `generate`，Cascode 还需要真实高低轨；两项电流上限可同时省略。它们从本次电路配置与 OA/仿真环境核对。当前自动 PDK 配置入口为 `standalone.py inspect --simulation-profile`（只读发现用 `standalone.py discover-pdk`），会设置并恢复独立 Provider 上下文；见文首链接。
暂无性能 Spec 时省略 `--max-branch-current-error` 和 `--max-vbias-current`，求解名义 DC 可行的器件与参数，不填写虚构指标。将来有实际要求时，两项一起提供为有限正数；候选及最终 DC/PVT 都按这些上限拒绝超限结果。这里的 Case 表示普通电路配置，不要求 Maau Case 文件。可选 `--pvt-corners tt,ss,ff` 声明 PVT 角。会话 Manifest（schema=3）记录扫描目录内容 hash；generate 重扫后同时比对版本和内容。

它会先按当前 DUT 扫描真实 PDK，再由扫描结果生成本会话的 OA 端序/CDF 策略并导出结构网表。Capless 演示用的 `server/config/device_policy.tsv` 不参与产品 CLI 的器件选择。它会打印可修改 MOS，并生成：

```text
before/core_before.scs
before/device_catalog.tsv
before/geometry.tsv
before/mos_inventory.tsv
analysis/device_policy.tsv
analysis/pdk_scan/inspect/raw_catalog.tsv
analysis/pdk_scan/inspect/pdk_identity.tsv
analysis/pdk_catalog.json
analysis/cross_flavor_candidates.json
session.conf
```

第二步，确认一项修改。四类示例位于 `examples/operations/`，其中器件名和
master 必须替换为当前真实电路数据；Cascode 的偏置电压和工作点**不需要**
用户填写，由 generate 时的自动 VBIAS 求解器从基线直流仿真自动取得：

```bash
./build/bin/st_circuit_tool confirm \
  --session /project/result/ldo_structure_session \
  --operation examples/operations/same_type_cascode.conf
```

产品路径的固定规则是：

- 同型/异型 Cascode 保留原 MOS 的 Gate，只把新增 Cascode MOS 的 Gate 接到工具自动生成的 VBIAS；
- VBIAS 不复用原图网络，固定展开 `VBIAS_N_CASCODE_AUTO` 或 `VBIAS_P_CASCODE_AUTO` 自给电 Mirror+Replica 模板（接父层声明的轨网，无 IREF 外部参考端口）；模板内部 MOS 与偏置参数由工具从当前 PDK/Case 目录按极性和电压域自动选择并经 Spectre 候选复验求解，用户不选模板内部管子、不填偏置电压；
- MOS Stack 的所有级 Gate 共用原 MOS Gate，不使用分压 Gate；
- MOS Source 串联电阻保留原 MOS；阻值优先用户填值，其次 Case 预置，最后使用 PDK 有限正合法区间的几何中点，不从 DC 工作点计算；
- Stack 的 Drain 侧保留原实例名，向 Source 侧依次命名为 `_S1`、`_S2`…；
- NMOS Cascode 放在原 Drain 侧，PMOS Cascode 放在原 Source 侧（标准原理图中通常是原管上方）；同型与跨 Flavor Cascode 均保持原 MOS Gate 不变；
- 新增 MOS、电阻和 Bias 模板的 master、terminal order、CDF 参数及范围都必须来自 `device_catalog.tsv`，超出 PDK 边界时拒绝生成。

需要时执行：

```bash
./build/bin/st_circuit_tool list --session /project/result/ldo_structure_session
./build/bin/st_circuit_tool undo --session /project/result/ldo_structure_session
./build/bin/st_circuit_tool fresh --session /project/result/ldo_structure_session
```

第三步，确认最终修改并生成电路：

```bash
./build/bin/st_circuit_tool generate --session /project/result/ldo_structure_session
```

generate 自动完成闭环：PDK 重扫比对 → 基线直流工作点（身份一致才复用
`analysis/baseline_op/`）→ 对每个 FixedBias Cascode 操作运行自动 VBIAS
求解（每候选完整装配"原管改线 + 新增 Cascode + 独立 VBIAS 模板"，经
clone → materialize 物化成唯一临时 OA CellView，再从该候选 CellView
回读网表并 run-op；候选独立目录 `analysis/candidates/candidate_NNN/`
留档审计网表、计划、身份和工作点；轨迹写入
`analysis/solver_trace.jsonl`，逐操作参数写入
`analysis/resolved_parameters.json`）→ 封装与 OA 计划 → SKILL 物化到
staging → 对 staging 变体做名义 DC 检查（`analysis/variant_op/`）→
源图、父图与全部封装子 Cell 回读一致 → 发布。

任何候选无解时：保留非空求解轨迹和逐项拒绝原因，不写 OA 计划、不 clone、
不发布，`reports/validation.txt` 明确 `ready_for_sizing=false`。

全部通过才会输出四状态和放行结论：

```text
structural_ready=true
nominal_dc_ready=true
pvt_ready=false
parameters_quantized=true
ready_for_sizing=true
派生电路=LDO_DERIVED/capless_ldo__TV0001/schematic
```

`pvt_ready` 在配置了 `--pvt-corners` 且全部 Corner 复验通过时才为 true
（任一 Corner 失败都会使 `pvt_ready=false`、`ready_for_sizing=false` 并
阻止发布）；未配置时恒为 false。它不表示 AC、瞬态、PSRR、噪声已签核。

打开派生原理图：

```bash
./build/bin/st_circuit_tool open --session /project/result/ldo_structure_session
```

## 已实现的服务器后端

仓库内的 `server/st_virtuoso_backend.sh` 已实现八个子命令：

- `scan-pdk`：扫描真实 PDK，生成模板器件目录并给出 pdk_version；
- `run-op`：对指定 OA DUT L/C/V（DUT 基线或已物化的候选 CellView）跑直流工作点，身份七字段随请求透传；
- `snapshot`：从源 L/C/V 生成基线网表、PDK/CDF 器件目录和根层坐标；
- `clone`：复制 source cellview 到 staging；
- `materialize`：加载 SKILL 和 JSON 计划，执行 CDF、端口、连线及 check/save；
- `netlist`：从指定 L/C/V 生成指定 `.scs`；
- `publish`：把已验证 staging 发布成最终派生 cellview；
- `open`：在 Virtuoso 打开最终派生 L/C/V。

八个 Runner 按参数数组处理，不使用 `eval`。`server/setup_backend.csh` 负责加载服务器环境，`server/prepare_session.sh` 负责创建不覆盖源项目的独立 `cds.lib`、派生库和 staging 库。真实 LDO 的逐步命令见 `server/README.md`。

`scan-pdk` 输出的 `device_catalog.tsv` 必须提供真实 terminal order/role、OA master、CDF 参数语义、电压域和工艺限制。只有 D/G/S 三个外部端子的 MOS 也进入当前层清单并可选择 Source 串电阻，Bulk 留空；四端及以上器件仍须证明 Bulk 语义。代码不会把实例数组位置直接猜成 D/G/S/B，也不会根据 `M` 开头猜器件类型。

`server/skill/pdk_adapter.il` 为 `standalone_topology_variant.il` 提供以下 PDK/版本适配入口：

```text
StTopologyParseJsonFile
StTopologyApplyCdfParameters
StTopologyCreatePort
StTopologyCreateWrapperSymbol
StTopologyCheckAndSave
```

启动 `materialize` 所用的 Cadence/SKILL 进程前，还必须设置工程根目录：

```bash
export ST_ENGINE_ROOT=/path/to/st-engine-maau
```

八个 Runner 从 `server/setup_backend.csh` 继承该环境变量。若未设置，SKILL 会直接报错退出，不会继续操作 schematic。

这是必须的工程边界：不同 PDK 的 CDF callback、pin master 和检查入口不能由通用代码安全猜出。

## 会话输出

```text
before/core_before.scs              源 schematic 自动生成的基线
analysis/pdk_catalog.json           scan-pdk 扫描出的模板器件目录
analysis/cross_flavor_candidates.json  同极性不同 master 候选（保留内部文件名）
analysis/baseline_op.json           基线直流工作点（含身份哈希）
analysis/baseline_op/               基线 OP 原始产物
analysis/candidates/candidate_NNN/  每个求解候选的独立目录：审计网表
                                    flat_candidate.scs、plan.json、identity.tsv、
                                    mos.tsv；候选 OA CellView 在候选库中唯一命名
analysis/solver_trace.jsonl         逐候选、逐约束的求解轨迹
analysis/resolved_parameters.json   逐操作求解结果与逐 Corner 复验结论
analysis/variant_op/                派生变体名义 DC 检查产物
expected/core_expected.scs          结构变换核心生成的期望网表
materialization/plan.json           SKILL/OA 差异计划
after/source_roundtrip.scs          源图保护回读
after/core_roundtrip.scs            派生 schematic 回读
after/package_XXXX_*.scs            每个封装子Cell的独立回读
reports/validation.txt              最终状态、L/C/V、路径、hash、VBIAS支路电流
logs/                               八个后端阶段日志
```

`expected/core_expected.scs` 包含核心电路中的 wrapper 和每个生成子Cell的层级网表。`after/core_roundtrip.scs` 保存核心父图回读；每个子Cell还会额外生成 `after/package_XXXX_*.scs`，再与期望子电路逐一比较。父图或任一子Cell的端口、master、连线或参数不一致，都不会发布，也不会输出 `ready_for_sizing=true`。

`ready_for_sizing=true` 说明结构回读、名义 DC、已提供的两项电流门禁和参数量化通过；配置 PVT 时还要求相应复验通过。报告同时保存 `validation_scope=dc_operating_point`、`performance_verified=false`、`current_limits_applied=true/false`。它不说明完整 LDO 性能或整机 IQ 已签核，也不会自动启动 Sizing。

## 当前验证边界

本地可以验证 C++ 编译、四类结构算法、当前层 MOS 清单、Change Set、命令行工作流、后端调用顺序、OA 计划和网表回读比较。当前机器没有真实 Virtuoso、目标 PDK 和许可证，因此真实服务器上的以下项目仍为 `planned_not_run`：

- 仓库内八动词后端在 ICADVM18.1 上的首次真实执行；
- 目标 PDK 的 CDF callback、symbol terminal、额外 Well/Bulk 端子；
- 真实 schematic 的局部摆放显示和 check/save；
- 真实源图、派生父图与每个封装子Cell的网表化、打开和截图。

这些项目必须以服务器命令、退出码、日志、派生 L/C/V 和三份网表为证据，不能只凭“脚本已生成”判定完成。

完整设计与实施计划见：

- `docs/superpowers/specs/2026-09-15-standalone-virtuoso-flow-design.md`
- `docs/superpowers/plans/2026-09-15-standalone-virtuoso-flow.md`
- `docs/superpowers/specs/2026-09-16-server-backend-design.md`
- `docs/superpowers/plans/2026-09-16-server-backend.md`
