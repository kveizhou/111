"""Continuation contracts; subprocess fixtures are not Cadence validation."""
import contextlib
import importlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))


class RunTest(unittest.TestCase):
    def module(self):
        return importlib.import_module('run_cascode_experiment')

    def test_tool_only_build_does_not_compile_all_test_programs(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            for d in ('scripts', 'server', 'server/bin', 'server/site', 'tests', 'src'):
                (root/d).mkdir(parents=True, exist_ok=True)
            for d in ('scripts', 'server', 'server/bin'):
                (root/d/'dummy.sh').touch()
            (root/'server/site/dummy.py').touch()
            (root/'tests/ServerBackendContractTest.sh').touch()
            shutil.copyfile(ROOT/'scripts/build.sh', root/'scripts/build.sh')
            compiler = root/'compiler'
            compiler.write_text('#!/bin/sh\necho call >> "$COUNT_FILE"\n')
            compiler.chmod(0o755)
            env = dict(os.environ, CXX=str(compiler), COUNT_FILE=str(root/'count'))
            env.pop('ST_BUILD_DIR', None)
            done = subprocess.run(['bash', str(root/'scripts/build.sh'), '--tool-only'], env=env, capture_output=True)
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual((root/'count').read_text().splitlines(), ['call'])

    def config(self, root):
        return dict(source={'lib':'original', 'cell':'core', 'view':'schematic'},
            bench={'lib':'benches', 'cell':'saved', 'view':'config'},
            cds_lib=str(root/'old/cds.lib'), core_subckt='core', target='I21',
            profile=str(root/'binding/simulation_profile.json'),
            rules=str(root/'binding/pdk_facts.json'), init=str(root/'original_init.il'))

    def test_commands_keep_original_source_and_use_distinct_session_and_library(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as name:
            root=Path(name); output=root/'new'; output.mkdir()
            commands=m.make_commands(self.config(root), output)
            inspect=commands[1][1]; opts=dict(zip(inspect[3::2],inspect[4::2]))
            self.assertEqual(commands[1][0], 'inspect')
            self.assertEqual(opts['--validation-scope'], 'experimental_dc')
            self.assertEqual(opts['--lib'], 'original')
            self.assertEqual(opts['--bench-view'], 'config')
            self.assertEqual(Path(opts['--work-dir']), (output/'work').resolve())
            self.assertNotEqual(opts['--cds-lib'], self.config(root)['cds_lib'])
            self.assertNotEqual(opts['--variant-lib'], 'original')
            self.assertEqual([c[0] for c in commands], ['prepare', 'inspect', 'confirm', 'generate'])
            self.assertIn('instance=I21\n', (output/'operation.conf').read_text())

    def test_pipeline_stops_after_failed_inspect_without_confirm_or_generate(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name:
            out=Path(name);calls=[]
            def runner(stage, argv, output, timeout, env=None):
                calls.append(stage)
                if stage=='inspect': raise m.StageFailure(stage, 3, output/'inspect.log')
            with self.assertRaises(m.StageFailure):
                m.execute(self.config(out),out,10,runner=runner)
            self.assertEqual(calls,['prepare','inspect'])

    def test_exit_zero_without_experimental_report_is_not_success(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            with self.assertRaises((ValueError, OSError)):
                m.execute(self.config(out),out,10,runner=lambda *a,**kw:None)

    def test_ready_requires_staging_and_all_experimental_flags(self):
        m=self.module()
        good=dict(ok='true',validation_scope='experimental_dc',experimental_dc_ready='true',
            ready_for_sizing='false',reliability_verified='false',published='false',
            target='experiment__STAGING/cell/schematic',stage='complete',structural_ready='true',
            parameters_quantized='true')
        self.assertTrue(m.validate_result(good))
        for key, value in [('published','true'),('ready_for_sizing','true'),('ok','false'),
                           ('experimental_dc_ready','false'),('target','original/core/schematic')]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                m.validate_result(dict(good,**{key:value}))

    def test_timeout_terminates_stage_and_keeps_log(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
            out=Path(name)
            with self.assertRaises(m.StageFailure):
                m.run_stage('slow',[sys.executable,'-u','-c','import time; print("started"); time.sleep(30)'],out,0.1)
            self.assertIn('started',(out/'slow.log').read_text())

    def test_binding_to_runner_uses_real_metadata_and_rejects_drift(self):
        import ExperimentBindingResumeTest as fixtures
        import experiment_bindings
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
            root=Path(name).resolve()
            out,old,session,batch,bridge,bundle,pdk,profile,rules,report,request,node,origins=fixtures.ResumeTest().make_case(root)
            bundle.update(bench=dict(lib='TB',cell='test',view='config'),corner='C',temperature=125,variables={},models=[])
            profile.update(nominal_corner='C',op_corners={'C':dict(temperature=125,variables={},models=[])},
                validated_baseline_bundle=str(bridge/'bundle/baseline_bundle.json'))
            profile['experimental_pdk_cache']['source_dut']=bundle['source']
            (session/'session.conf').write_text('source_library=USER\nsource_cell=core\nsource_view=schematic\ncore_subckt=core\n')
            with patch('experiment_bindings.cached_binding_context',return_value=(request,node,origins,{})):
                self.assertEqual(experiment_bindings.bind(out,session,batch,bridge,bundle,pdk,profile,rules,report,10,reuse_dir=old),0)
            cache=(bridge,bundle,pdk,[],[],{},[],report['source_cache_sha256'])
            with patch.object(m,'cached_inputs',return_value=cache):
                config=m.load_inputs(session,batch,'I21')
                self.assertEqual(config['source'],bundle['source'])
                self.assertEqual(config['bench']['view'],'config')
                rules_file=out/'pdk_facts.json'; original_rules=rules_file.read_text()
                changed=json.loads(original_rules)
                changed['devices']['PDK/opaque_a']['bulkRule']='isolated_well'
                rules_file.write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError,'metadata preview'):
                    m.load_inputs(session,batch,'I21')
                rules_file.write_text(original_rules)
                evidence=out/'binding_evidence.json';original_evidence=evidence.read_text()
                changed=json.loads(original_evidence);changed['experiment_inputs_ready']=False
                evidence.write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError,'latest binding'):
                    m.load_inputs(session,batch,'I21')
                evidence.write_text(original_evidence)
                (out/'I21_model_type.txt').write_text('changed')
                with self.assertRaisesRegex(ValueError,'evidence changed'):
                    m.load_inputs(session,batch,'I21')

    def test_preserved_primitive_remains_in_simulation_but_is_not_selectable(self):
        from experimental_pdk import preserved_primitives
        rows=[dict(oa_library='PDK',oa_cell='untouched',model_name='opaque',terminal_names='A,B',has_schematic='false')]
        result=preserved_primitives({'PDK/untouched':rows}, set(), 'probe.tsv')
        self.assertEqual(result[0]['model'],'opaque')
        self.assertEqual(preserved_primitives({'PDK/untouched':rows}, {'PDK/untouched'}, 'probe.tsv'),[])
        for changed in (dict(rows[0],has_schematic='true'),dict(rows[0],model_name='different')):
            self.assertEqual(preserved_primitives({'PDK/untouched':rows+[changed]},set(),'probe.tsv'),[])


if __name__=='__main__':unittest.main()
