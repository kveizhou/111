"""Source-bound finite native CDF trials, never a claimed PDK legal domain.

Input: profile.experimental_parameter_seeds["library/cell"] contains instance,
native_records (absolute collect_cascode_batch JSON), its SHA256, and optional
trials keyed by normalized parameter name. Trial literals use the parameter's
CDF units, as do actual cdf_value records. No defValue is used as an instance.
"""
import csv
import hashlib
import json
import math
from pathlib import Path

from site_data import finite, read_json
from standalone_pdk import cdf_numeric

MAX_TRIAL_COMBINATIONS = 16
MAX_TRIAL_VALUES = 5
MAX_MASTERS = 12


def _source(value, label):
    if (not isinstance(value, str) or not value.strip() or value.lower() in ('unknown', 'missing') or
            'guess' in value.lower() or 'inference' in value.lower()):
        raise ValueError('proven ' + label + ' source is required')
    return value


def load_actual_seed(seed, model, parameters, master=None):
    """Read only a fingerprinted native instance-value cache, not base CDF."""
    instance = _source(seed.get('instance'), 'actual instance seed')
    path = Path(seed.get('native_records', ''))
    if not path.is_absolute() or not path.is_file():
        raise ValueError('actual instance seed native_records must be an existing absolute file')
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if seed.get('native_records_sha256') != digest:
        raise ValueError('actual instance seed native_records changed or SHA256 missing: ' + str(path))
    values, binding = {}, {}
    for record in read_json(path):
        if record.get('scope') != instance or record.get('kind') not in ('cdf_value', 'source'):
            continue
        target = binding if record['kind'] == 'source' else values
        name = record.get('name')
        if name in target or record.get('status') != 'OK':
            raise ValueError('actual instance seed duplicate or failed value: ' + instance + '/' + str(name))
        text = record.get('raw_value', '')
        try:
            value = json.loads(text)
        except (ValueError, TypeError):
            value = text
        target[name] = value
    if not values:
        raise ValueError('actual instance seed cdf_value records missing: ' + instance)
    if values.get('model', values.get('modelName')) != model:
        raise ValueError('actual instance seed model binding missing/conflicting: ' + instance)
    if master and binding.get('oa_library', '') + '/' + binding.get('oa_cell', '') != master:
        raise ValueError('actual instance seed OA master binding missing/conflicting: ' + instance)
    missing = set(parameters) - values.keys()
    if missing:
        raise ValueError('actual instance seed parameters missing: ' + ','.join(sorted(missing)))
    return values, str(path.resolve()), digest


def _unit_semantic(row, semantic):
    unit = row.get('units', '')
    if semantic.startswith('cdf_'):
        if unit in ('m', 'meter', 'metre', 'meters', 'um', 'µm', 'nm', 'mm', 'lengthMetric'):
            return 'length'
        if unit in ('ohm', 'Ohm', 'ohms', 'Ohms', 'Ω', 'resistance'):
            return 'resistance'
    return semantic


def _numeric(value, row, semantic):
    if isinstance(value, bool):
        raise ValueError('boolean is not a numeric CDF trial')
    passthrough = semantic.startswith('cdf_')
    unit = row.get('units', '')
    result = cdf_numeric(value, unit, _unit_semantic(row, semantic))
    finite(result, not passthrough)
    if (semantic in ('fin', 'fins', 'fingers', 'multiplier') or row.get('cdf_type') == 'int') and result != int(result):
        raise ValueError('count trial must be integral: ' + semantic)
    return result


def _known_bounds(values, row, semantic, declared):
    """Reject every contradicted known fact, even when the other bound is absent."""
    bounds = []
    for field in ('min', 'max'):
        text = row.get(field)
        if text not in (None, ''):
            try:
                value = cdf_numeric(text, row.get('units', ''), _unit_semantic(row, semantic))
            except ValueError:
                # Expressions are not understood; the native callback still gates them.
                continue
            finite(value)
            bounds.append((field, value, 'actual CDF'))
        if field in declared:
            bounds.append((field, finite(declared[field]), 'documented rule'))
    for field, limit, source in bounds:
        if any((v < limit and not math.isclose(v, limit, rel_tol=1e-12)) if field == 'min'
               else (v > limit and not math.isclose(v, limit, rel_tol=1e-12)) for v in values):
            raise ValueError('trial violates known ' + source + ' bound: ' + semantic + '/' + field)
    allowed = declared.get('allowed', [])
    if allowed:
        allowed = [finite(v) for v in allowed]
        if any(not any(math.isclose(v, x, rel_tol=1e-12) for x in allowed) for v in values):
            raise ValueError('trial violates known allowed bound: ' + semantic)
    grid = finite(declared.get('grid', 0))
    if grid < 0:
        raise ValueError('known parameter grid must be nonnegative')
    if grid:
        origin = finite(declared.get('min', 0))
        if any(not math.isclose((v-origin)/grid, round((v-origin)/grid), abs_tol=1e-7) for v in values):
            raise ValueError('trial violates known grid bound: ' + semantic)
    if row.get('choices'):
        try:
            choices = [_numeric(text, row, semantic) for text in row['choices'].split(',')]
        except ValueError:
            choices = []
        if choices and any(not any(math.isclose(v, x, rel_tol=1e-12) for x in choices) for v in values):
            raise ValueError('trial violates known CDF choice bound: ' + semantic)
    return [{'field': field, 'value': value, 'source': source} for field, value, source in bounds]


def preserved_primitives(groups, selected, source):
    """Keep proven, unselected primitive identities; no type/rating inference.

    These never enter the transform catalog or its parameter search. The
    existing physical binding reader still checks their model and terminal
    count, while source/variant netlist verification protects the circuit.
    """
    result = []
    for key, rows in sorted(groups.items()):
        if key in selected:
            continue
        first = rows[0]
        names = first['terminal_names'].split(',')
        if (not first['model_name'] or not all(names) or len(set(names)) != len(names) or
                any(row.get('has_schematic') != 'false' or
                    row['model_name'] != first['model_name'] or
                    row['terminal_names'] != first['terminal_names'] for row in rows)):
            continue
        result.append(dict(oa_library=first['oa_library'],cell=first['oa_cell'],
                           model=first['model_name'],source=source))
    return result


def build_experimental_metadata(root, probe_path, profile, rules, pdk_name=None):
    if profile.get('validation_scope') != 'experimental_dc':
        raise ValueError('native parameter trials require experimental_dc')
    source = _source(rules.get('source'), 'device facts')
    requested = root if isinstance(root, (list, tuple)) else [root]
    aliases = list(dict.fromkeys(str(Path(p).absolute()) for p in requested))
    roots = list(dict.fromkeys(str(Path(p).resolve()) for p in aliases))
    if not roots or any(not Path(p).is_dir() for p in roots):
        raise ValueError('PDK root must be an existing directory')
    seeds = profile.get('experimental_parameter_seeds', {})
    if not isinstance(seeds, dict) or not seeds or len(seeds) > MAX_MASTERS:
        raise ValueError('actual instance seed selection required (at most 12 masters)')
    groups = {}
    with Path(probe_path).open(newline='') as stream:
        reader = csv.DictReader(stream, delimiter='\t')
        required = {'oa_library', 'oa_cell', 'model_name', 'terminal_names', 'parameter', 'units', 'has_schematic'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('experimental trials require extended actual OA/CDF probe')
        for row in reader:
            key = row['oa_library'] + '/' + row['oa_cell']
            if None in row:
                raise ValueError('malformed actual OA/CDF probe')
            groups.setdefault(key, []).append(row)
    devices, fingerprints = [], {str(Path(probe_path).resolve()): hashlib.sha256(Path(probe_path).read_bytes()).hexdigest()}
    for key, seed in sorted(seeds.items()):
        rows = groups.get(key)
        if not rows:
            raise ValueError('selected master missing from actual OA/CDF probe: ' + key)
        identity = rows[0]
        if any(r['terminal_names'] != identity['terminal_names'] or r['model_name'] != identity['model_name'] for r in rows):
            raise ValueError('conflicting actual OA/CDF identity: ' + key)
        if identity.get('has_schematic') != 'false':
            raise ValueError('selected trial master is not a proven primitive: ' + key)
        rule = rules.get('devices', {}).get(key, {})
        kind = rule.get('kind')
        if kind not in ('mos_n', 'mos_p', 'resistor'):
            raise ValueError('proven device type/polarity required: ' + key)
        names = identity['terminal_names'].split(',')
        roles = rule.get('terminalRoles', {})
        required_roles = ('positive', 'negative') if kind == 'resistor' else ('drain', 'gate', 'source', 'bulk')
        if (not names or '' in names or len(names) != len(set(names)) or set(roles) != set(names)
                or any(list(roles.values()).count(role) != 1 for role in required_roles)
                or (kind != 'resistor' and len(names) != 4)
                or (kind == 'resistor' and len(names) not in (2, 3))
                or any(role not in required_roles + ('substrate',) for role in roles.values())):
            raise ValueError('proven actual terminal mapping required: ' + key)
        if kind != 'resistor':
            _source(rule.get('bulkRule'), 'Bulk strategy for ' + key)
            # These are the only body conventions implemented by AutoBias:
            # isolated_well follows the template's source connection; rail
            # binds NMOS to VLOW and PMOS to VHIGH. Do not turn arbitrary
            # documentation text (e.g. "ground") into a proven rail policy.
            if rule['bulkRule'] not in ('isolated_well', 'rail'):
                raise ValueError('supported Bulk strategy must be isolated_well or rail: ' + key)
        model = rule.get('model', identity['model_name'])
        if not model or (identity['model_name'] and model != identity['model_name']):
            raise ValueError('actual model identity missing/conflicting: ' + key)
        mapping = dict(rule.get('normalized_to_cdf', {}))
        if not mapping or len(set(mapping.values())) != len(mapping):
            raise ValueError('explicit unique normalized_to_cdf mapping required: ' + key)
        by_parameter = {r['parameter']: r for r in rows if r['parameter']}
        if not set(mapping.values()).issubset(by_parameter):
            raise ValueError('mapped parameter absent from actual CDF: ' + key)
        values, native_path, digest = load_actual_seed(seed, model, mapping.values(), key)
        fingerprints[native_path] = digest
        # Preserve additional measured numeric CDF properties at their actual
        # value by default. cdf_* conveys no guessed geometry meaning.
        for parameter in sorted(set(values) & set(by_parameter) - set(mapping.values())):
            semantic = 'cdf_' + parameter
            try:
                _numeric(values[parameter], by_parameter[parameter], semantic)
            except ValueError:
                continue
            mapping[semantic] = parameter
        trial_input = seed.get('trials', {})
        if not isinstance(trial_input, dict) or set(trial_input) - mapping.keys():
            raise ValueError('trial parameter has no explicit CDF mapping: ' + key)
        constraints, actual, known, combinations = {}, {}, {}, 1
        for semantic, parameter in mapping.items():
            row = by_parameter[parameter]
            actual[semantic] = _numeric(values[parameter], row, semantic)
            proposed = trial_input.get(semantic, [])
            if not isinstance(proposed, list) or len(proposed) > MAX_TRIAL_VALUES:
                raise ValueError('finite trial list must contain at most 5 values: ' + semantic)
            # Seed first is part of the native-trial contract: existing C++
            # initializers use discrete_values.front(). Bounds remain sorted.
            trials = [actual[semantic]] + sorted(set(_numeric(v, row, semantic) for v in proposed) - {actual[semantic]})
            if len(trials) > MAX_TRIAL_VALUES:
                raise ValueError('finite trial list including actual seed exceeds 5 values: ' + semantic)
            known[semantic] = _known_bounds(trials, row, semantic, rule.get('constraints', {}).get(semantic, {}))
            combinations *= len(trials)
            if combinations > MAX_TRIAL_COMBINATIONS:
                raise ValueError('finite trial combinations exceed 16 per master: ' + key)
            constraints[semantic] = dict(min=min(trials), max=max(trials), grid=0, allowed=trials)
        if kind == 'resistor':
            adequate = 'resistance' in constraints
        else:
            adequate = 'length' in constraints and bool({'width', 'total_width', 'fin', 'fins'} & constraints.keys())
        if not adequate:
            raise ValueError('actual mapped geometry seed incomplete: ' + key)
        missing = ['parameter_domain_unverified']
        dev = dict(cell=identity['oa_cell'], oa_library=identity['oa_library'], model=model, kind=kind,
            normalized_to_cdf=mapping, constraints=constraints, native_parameter_trials=True,
            parameter_domain_verified=False, native_trial_combinations=combinations,
            actual_parameter_seed=actual, actual_seed_instance=seed['instance'], actual_seed_source=native_path,
            known_parameter_bounds=known, source=source, rules_source=source,
            cdf_source=str(Path(probe_path).resolve()) + '; actual seed: ' + native_path + '; finite trials, not proven legal domain',
            electrical_rules=rule, sim_cdf=rule.get('sim_cdf', {}),
            dc_signals=rule.get('dc_signals', {'id': 'id', 'vth': 'vth', 'vdsat': 'vdsat', 'cgg': 'cgg', 'vbs': 'vbs'}),
            signal_postfix=rule.get('signal_postfix', ''), missing=missing)
        for name in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb', 'bulkRule', 'voltageDomains', 'terminalRoles',
                     'wFinFormula', 'maxStackLevel', 'sourceDrainInterchangeable'):
            if name in rule:
                dev[name] = finite(rule[name], True) if name.startswith('maxAbs') else rule[name]
        if 'maxStackLevel' in dev:
            maximum = finite(dev['maxStackLevel'], True)
            if maximum != int(maximum) or maximum > 2147483647:
                raise ValueError('PDK maxStackLevel must be a positive integer: ' + key)
            dev['maxStackLevel'] = int(maximum)
        if 'sourceDrainInterchangeable' in dev and not isinstance(dev['sourceDrainInterchangeable'], bool):
            raise ValueError('PDK sourceDrainInterchangeable must be boolean: ' + key)
        if kind != 'resistor' and not all(k in dev for k in ('maxAbsVgs', 'maxAbsVds', 'maxAbsVgb')):
            missing.append('reliability')
        if not dev.get('voltageDomains'):
            missing.append('voltage_domain')
        devices.append(dev)
    payload = dict(roots=roots, sources=fingerprints, rules=rules, profile=profile)
    version = hashlib.sha256(json.dumps(payload, sort_keys=True, allow_nan=False).encode()).hexdigest()
    return dict(tech_name=pdk_name or Path(roots[0]).name, pdk_name=pdk_name or Path(roots[0]).name,
        pdk_paths=roots, pdk_alias_paths=aliases, version='experimental-sha256:' + version,
        source=str(Path(probe_path).resolve()), validation_scope='experimental_dc', native_parameter_trials=True,
        parameter_domain_verified=False, reliability_verified=False,
        corners=[dict(name=n, sections=c['models']) for n, c in profile.get('op_corners', {}).items()],
        temperatures=[], devices=devices, model_file_sha256={}, source_file_sha256=fingerprints,
        rejected_devices=[], unreadable_model_files=[],
        non_target_devices=preserved_primitives(groups, set(seeds), str(Path(probe_path).resolve())),
        model_internal_scan_performed=False)
