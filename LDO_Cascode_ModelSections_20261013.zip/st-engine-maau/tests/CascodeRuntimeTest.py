"""Formal reader boundary tests. Fixtures do not execute Cadence/SKILL."""
import csv
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

SITE = Path(__file__).resolve().parents[1] / 'server/site'
sys.path.insert(0, str(SITE))


class CascodeRuntimeTest(unittest.TestCase):
    def module(self):
        self.assertTrue((SITE/'dc_results.py').is_file(), 'shared formal reader is missing')
        return importlib.import_module('dc_results')

    def query(self):
        return dict(schema='st-dc-query-v1', nodes=['0','AVDD','core.S'],
                    device_parameters={'core.I105':['id','region','vdssat','cgg']}, currents=['V0:p'])

    def rows(self):
        nodes=[dict(kind=k,signal=s,value=v,status='OK') for k,s,v in
               [('node','AVDD','1.14'),('node','core.S','0.4'),('current','V0:p','-0.0084')]]
        ops=[dict(kind='device',signal='core.I105',parameter='',value='bsimcmg',status='META')]
        ops += [dict(kind='op',signal='core.I105',parameter=k,value=v,status='OK')
                for k,v in [('id','-4.1e-7'),('region','1'),('vdssat','0.18'),('cgg','6.3e-16')]]
        return nodes,ops

    def test_signed_raw_and_integer_preserved_with_explicit_sources(self):
        mod=self.module();nodes,ops=self.rows()
        raw,sources=mod.consume_query(self.query(),nodes,ops)
        self.assertEqual(raw['core.I105:id'],-4.1e-7)
        self.assertEqual(raw['core.I105:region'],1.0)
        self.assertEqual(raw['V0:p'],-.0084)
        self.assertEqual(raw['0'],0)
        self.assertNotIn('core.I105:vdsat',raw)
        self.assertEqual(sources['core.I105:vdssat']['parameter'],'vdssat')
        self.assertEqual(sources['0']['kind'],'reference_zero')

    def test_missing_bad_duplicate_or_wrong_prefix_never_becomes_zero(self):
        mod=self.module()
        for mode in ('missing','nan','nonnumeric','duplicate','prefix','ambiguous'):
            with self.subTest(mode=mode):
                nodes,ops=self.rows()
                if mode=='missing':nodes.pop(1)
                if mode=='nan':nodes[0]['value']='nan'
                if mode=='nonnumeric':nodes[0]['status']='NON_NUMERIC';nodes[0]['value']=''
                if mode=='duplicate':nodes.append(dict(nodes[0]))
                if mode=='prefix':
                    for r in ops:r['signal']='core.I105.extra'
                if mode=='ambiguous':ops.append(dict(ops[1],signal='/core/I105'))
                with self.assertRaises(ValueError):mod.consume_query(self.query(),nodes,ops)

    def test_alias_conflict_is_rejected_even_if_only_vdssat_requested(self):
        mod=self.module();nodes,ops=self.rows()
        ops.append(dict(kind='op',signal='core.I105',parameter='vdsat',value='9',status='OK'))
        with self.assertRaisesRegex(ValueError,'vdsat/vdssat'):mod.consume_query(self.query(),nodes,ops)

    def test_request_rejects_duplicates_empty_untyped_and_colon_collisions(self):
        mod=self.module()
        for bad in ({},dict(self.query(),nodes=['x','x']),dict(self.query(),nodes=['x:y']),
                    dict(self.query(),currents=['wrong']),dict(self.query(),device_parameters={'x':[]})):
            with self.subTest(bad=bad),self.assertRaises(ValueError):mod.validate_query(bad)

    def test_native_builders_share_validated_scalar_code_and_finish_once(self):
        mod=self.module()
        code=mod.query_script(Path('/psf'),self.query(),Path('/init'),Path('/work'))
        self.assertEqual(code.count('exit()'),1)
        self.assertIn('float(scalar)',code)
        self.assertIn('outputs(?type kind ?map nil)',code)
        self.assertIn("pv(device param ?result 'dcOpInfo)",code)
        self.assertIn('stFocusExact=t',code)
        self.assertIn('stNodeCurrents=list("V0:p")',code)
        self.assertNotIn('createNetlist(',code)
        self.assertNotIn('run()',code)
        # Parenthesis/string balance only, not a SKILL interpreter.
        depth=0;quoted=False;escaped=False
        for ch in code:
            if quoted:
                if escaped:escaped=False
                elif ch=='\\':escaped=True
                elif ch=='"':quoted=False
            elif ch=='"':quoted=True
            elif ch=='(':depth+=1
            elif ch==')':depth-=1
            self.assertGreaterEqual(depth,0)
        self.assertEqual(depth,0);self.assertFalse(quoted)

    def test_cli_reads_requested_psf_once_without_simulation_and_retains_failures(self):
        self.module()
        for mode in ('ok','dc_filename','no_marker','missing','changed_psf'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                d=Path(tmp);psf=d/'psf';psf.mkdir();(psf/'dcOp.dc').write_text('fixture')
                (psf/'dcOpInfo.info').write_text('fixture')
                if mode=='dc_filename':(psf/'dcOp.dc').rename(psf/'dc.dc')
                q=d/'query.json';q.write_text(json.dumps(self.query()))
                nodes,ops=self.rows()
                if mode=='missing':nodes.pop(0)
                (d/'nodes.json').write_text(json.dumps(nodes));(d/'ops.json').write_text(json.dumps(ops))
                native=d/'ocean';native.write_text('#!'+sys.executable+'\n'+'''import csv,json,os,sys
from pathlib import Path
work=Path(sys.argv[-1]).parent
assert 'createNetlist(' not in Path(sys.argv[-1]).read_text()
src=Path(os.environ['FIXTURE_DIR'])
for name,fields in [('nodes',['kind','signal','value','status']),('ops',['kind','signal','parameter','value','status'])]:
 with (work/(name+'.tsv')).open('w') as f:
  writer=csv.DictWriter(f,fieldnames=fields,delimiter='\\t');writer.writeheader();writer.writerows(json.loads((src/(name+'.json')).read_text()))
if os.environ['MODE']!='no_marker':(work/'runtime.done').write_text('OK\\n')
if os.environ['MODE']=='changed_psf':(src/'psf/dcOp.dc').write_text('changed')
''');native.chmod(0o755)
                init=d/'init.il';init.write_text('; fixture')
                env=dict(os.environ,ST_OCEAN_BIN=str(native),ST_SKILL_INIT=str(init),FIXTURE_DIR=str(d),MODE=mode)
                result=subprocess.run([sys.executable,str(SITE/'cascode_runtime.py'),'read-psf','--psf-dir',str(psf),
                    '--request',str(q),'--output',str(d/'raw.tsv')],env=env,text=True,capture_output=True)
                success=mode in ('ok','dc_filename')
                self.assertEqual(result.returncode,0 if success else 70,result.stdout+result.stderr)
                self.assertTrue((d/'psf_reader/ocean.log').exists())
                self.assertEqual((d/'raw.tsv').exists(),success)
                if success:
                    with (d/'raw.tsv').open() as f:raw={r['signal']:float(r['value']) for r in csv.DictReader(f,delimiter='\t')}
                    self.assertEqual(raw['core.I105:id'],-4.1e-7)
                    self.assertTrue((d/'raw.tsv.sources.json').is_file())

    def test_candidate_simulation_uses_saved_aps_controls_and_requires_actual_psf(self):
        runtime=importlib.import_module('cascode_runtime')
        self.assertTrue(hasattr(runtime,'simulate'),'formal candidate simulation missing')
        import BaselineBundleTest as fixture
        for mode in ('ok','no_psf','timeout','wrong_controls'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);mod,bundle,path,_,_,_=fixture.BaselineBundleTest().export(root)
                deck=root/'candidate.scs';deck.write_text(Path(bundle['bench_netlist']).read_text())
                if mode=='wrong_controls':deck.write_text(deck.read_text().replace('maxiters=150','maxiters=5'))
                native=root/'spectre';native.write_text('#!'+sys.executable+'\n'+'''import json,os,sys,time
from pathlib import Path
Path('observed_argv.json').write_text(json.dumps(sys.argv[1:]))
if os.environ['MODE']=='timeout':time.sleep(5)
psf=Path(sys.argv[sys.argv.index('-raw')+1])
if os.environ['MODE']!='no_psf':
 (psf/'dcOp.dc').write_text('fixture');(psf/'dcOpInfo.info').write_text('fixture')
print('Command line: '+' '.join(sys.argv))
''');native.chmod(0o755)
                args=SimpleNamespace(baseline_bundle=str(path),netlist=str(deck),psf_dir=str(root/'candidate_psf'),log=str(root/'spectre.log'),timeout=1 if mode=='timeout' else 10)
                with patch.dict(os.environ,ST_SPECTRE_BIN=str(native),MODE=mode):
                    if mode=='ok':runtime.simulate(args)
                    else:
                        with self.assertRaises(ValueError):runtime.simulate(args)
                if mode=='wrong_controls':self.assertFalse((root/'observed_argv.json').exists())
                elif mode=='timeout':
                    self.assertTrue((root/'spectre.log').exists())
                    self.assertFalse((root/'candidate_psf/dcOp.dc').exists())
                else:
                    argv=json.loads((root/'observed_argv.json').read_text())
                    self.assertIn('+aps=conservative',argv);self.assertIn('+mt=4',argv)

    def test_candidate_export_uses_bundle_definitions_and_variables_with_actual_oa_ports(self):
        runtime=importlib.import_module('cascode_runtime')
        self.assertTrue(hasattr(runtime,'netlist'),'formal OA netlisting missing')
        import BaselineBundleTest as fixture
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);mod,bundle,path,_,_,_=fixture.BaselineBundleTest().export(root)
            work=root/'candidate_oa';init=root/'init.il';init.write_text(';fixture')
            native=root/'ocean';native.write_text('#!'+sys.executable+'\n'+'''import sys
from pathlib import Path
work=Path(sys.argv[-1]).parent
code=Path(sys.argv[-1]).read_text()
assert 'definitionFile(' in code and 'desVar("VIN" "1.14")' in code
assert 'temp(125.0)' in code and 'run()' not in code
generated=work/'generated';generated.mkdir()
(generated/'input.scs').write_text('simulator lang=spectre\\nM0 (D G S B) nmod l=20n nfin=2\\n')
(work/'ports.txt').write_text('B\\nS\\nG\\nD\\n')
(work/'runtime.done').write_text('OK\\n')
''');native.chmod(0o755)
            args=SimpleNamespace(baseline_bundle=str(path),lib='DERIVED',cell='candidate',view='schematic',work_dir=str(work),cds_path=str(root),
                output=str(root/'candidate.scs'),ports_from=bundle['bench_netlist'],source_subckt='core',timeout=10)
            with patch.dict(os.environ,ST_OCEAN_BIN=str(native),ST_SKILL_INIT=str(init)):runtime.netlist(args)
            text=(root/'candidate.scs').read_text()
            self.assertIn('subckt candidate D G S B',text)
            self.assertIn('M0 (D G S B)',text)


if __name__=='__main__':unittest.main()
