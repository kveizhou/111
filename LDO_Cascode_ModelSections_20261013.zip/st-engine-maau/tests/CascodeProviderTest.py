"""Formal candidate contracts; native subprocesses remain fixture boundaries."""
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace

SITE=Path(__file__).resolve().parents[1]/'server/site'
sys.path.insert(0,str(SITE))


class CascodeProviderTest(unittest.TestCase):
    def test_intrinsic_cmg_saturation_cannot_reach_electrical_success_contract(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'require_supported_voltage_semantics'),'CMG consumer gate missing')
        physical=[(dict(path='X.P'),dict(kind='mos_p'),dict(dc_signals={'vdsat':'vdssat'},electrical_rules={}))]
        with self.assertRaisesRegex(ValueError,'intrinsic'):op.require_supported_voltage_semantics(physical)
        physical[0][2]['dc_signals']['vdsat']='vdsat'
        sources={'sources':{'X.P:vdsat':dict(kind='op',device_type='bsimcmg')}}
        with self.assertRaisesRegex(ValueError,'intrinsic'):op.require_supported_voltage_semantics(physical,sources)
        op.require_supported_voltage_semantics(physical,{'sources':{'X.P:vdsat':dict(kind='op',device_type='bsim4')}})

    def test_bundle_candidate_only_exports_actual_dut_and_preserves_baseline_controls(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'prepare_bundle_candidate'),'formal Bundle provider branch missing')
        import BaselineBundleTest as fixture
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);mod,bundle,path,_,_,_=fixture.BaselineBundleTest().export(root)
            runtime=root/'runtime';runtime.write_text('#!'+sys.executable+'\n'+'''import json,sys
from pathlib import Path
assert sys.argv[1]=='netlist'
args=dict(zip(sys.argv[2::2],sys.argv[3::2]))
assert args['--cell']=='candidate' and '--baseline-bundle' in args
out=Path(args['--output'])
out.write_text('simulator lang=spectre\\nsubckt candidate D G S B\\nM0 (D G S B) nmod l=30n nfin=2\\nends candidate\\n')
Path(str(out)+'.origin.json').write_text(json.dumps({'working_directory':str(out.parent),'dc_test_name':''}))
''');runtime.chmod(0o755)
            run=root/'run';run.mkdir()
            args=SimpleNamespace(dut_lib='DERIVED',dut_cell='candidate',dut_view='schematic',corner=bundle['corner'])
            extension=dict(validated_baseline_bundle=str(path),nominal_corner=bundle['corner'],op_corners={bundle['corner']:dict(temperature=bundle['temperature'],models=bundle['models'],variables=bundle['variables'])})
            actual,text,root_path=op.prepare_bundle_candidate(args,extension,bundle['source'],bundle['bench'],root/'cds.lib',str(runtime),run)
            self.assertEqual(root_path,'TOP.DUT')
            self.assertIn('maxiters=150 maxsteps=10000',text)
            self.assertIn('ic G=0.3',text);self.assertIn('nodeset G=0.4',text)
            self.assertIn('l=30n',text)
            self.assertFalse((run/'export_bench.log').exists())
            self.assertEqual((run/'bench.scs').read_text(),Path(bundle['bench_netlist']).read_text())

    def test_query_is_built_from_physical_nodes_and_explicit_pdk_mappings(self):
        op=importlib.import_module('op_provider')
        self.assertTrue(hasattr(op,'build_dc_query'),'formal candidate query integration missing')
        physical=[(dict(path='X0.P',nodes=['OUT','G','VDD','VDD']),
            dict(kind='mos_p',terminal_roles=['drain','gate','source','bulk']),
            dict(signal_postfix='.M',dc_signals={'id':'ids','vth':'vth','vdsat':'vdssat','cgg':'cgg'},electrical_rules={})),
            (dict(path='X0.R',nodes=['OUT','0']),dict(kind='resistor',terminal_roles=['positive','negative']),
             dict(signal_postfix='',dc_signals={},electrical_rules={'dc_signals':{'current':'1'}}))]
        query=op.build_dc_query(physical,[{'signal':'V0:p','sign':-1}])
        self.assertEqual(set(query['nodes']),{'OUT','G','VDD','0'})
        self.assertEqual(query['device_parameters'],{'X0.P.M':['cgg','ids','vdssat','vth']})
        self.assertEqual(query['currents'],['V0:p','X0.R:1'])
        physical[0][2]['dc_signals'].pop('vdsat')
        with self.assertRaisesRegex(ValueError,'mapping'):op.build_dc_query(physical,[{'signal':'V0:p','sign':-1}])

    def test_bundle_profile_checks_single_corner_and_case_sensitive_variables(self):
        mod=importlib.import_module('standalone')
        self.assertTrue(hasattr(mod,'validate_bundle_profile'),'new session Bundle validation missing')
        bundle=dict(corner='hot',temperature=125,models=[dict(model_file='/model',section_name='ss',sha256='h')],variables={'iout':'10m','IOUT':'200m'})
        profile=dict(nominal_corner='hot',op_corners={'hot':dict(temperature=125,models=[dict(model_file='/model',section_name='ss')],variables={'iout':'10m','IOUT':'200m'})},pvt_corners=[])
        mod.validate_bundle_profile(bundle,profile)
        for bad in ('temp','variable','other_corner','nominal'):
            item=json.loads(json.dumps(profile))
            if bad=='temp':item['op_corners']['hot']['temperature']=27
            if bad=='variable':item['op_corners']['hot']['variables']['iout']='200m'
            if bad=='other_corner':item['pvt_corners']=['cold']
            if bad=='nominal':item['nominal_corner']='cold'
            with self.subTest(bad=bad),self.assertRaises(ValueError):mod.validate_bundle_profile(bundle,item)


if __name__=='__main__':unittest.main()
