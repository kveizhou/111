#!/usr/bin/env python3
"""Interactive server testing for the standalone engine; no embedded PDK address."""
import argparse
import csv
from datetime import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import time


class InputPending(Exception):
    pass


class CommandFailure(Exception):
    def __init__(self, code, log):
        self.code, self.log = code, log
        super().__init__('命令失败，退出码={}；日志={}'.format(code, log))


def ask(label, default=None, optional=False):
    while True:
        suffix = ' [{}]'.format(default) if default is not None else ''
        value = input(label + suffix + '：').strip()
        if value == '?':
            raise InputPending('此项暂时未知；保留已完成的测试和扫描证据')
        value = value or (str(default) if default is not None else '')
        if value or optional:
            if any(c in value for c in ('\n', '\r', '\x00')):
                print('输入不能含换行或 NUL')
                continue
            return value
        print('请填实际值；不知道可输入 ? 停止')


def choice(label, allowed, default=None):
    while True:
        value = ask(label, default)
        if value in allowed: return value
        print('请选择：' + ', '.join(allowed))


def path_input(label, default=None, directory=False, optional=False):
    while True:
        value = ask(label, default, optional)
        if not value: return None
        candidate = Path(value).expanduser()
        if not candidate.is_absolute():
            print('请填写绝对路径')
            continue
        if (candidate.is_dir() if directory else candidate.is_file()) and os.access(candidate, os.R_OK):
            return candidate.resolve()
        print('路径不存在或不可读，请检查后重新输入')


def number(label, positive=False):
    while True:
        try:
            value = float(ask(label))
            if not math.isfinite(value) or (positive and value <= 0): raise ValueError()
            return value
        except ValueError:
            print('请输入有限{}数值'.format('正' if positive else ''))


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def new_run(parent):
    default = 'ocldo_structure_' + datetime.now().strftime('%Y%m%d_%H%M%S')
    while True:
        name = ask('新会话名称（不复用旧目录）', default)
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
            print('会话名称只用字母、数字和下划线，并以字母或下划线开头')
            continue
        target = parent / name
        try:
            target.mkdir(parents=True, exist_ok=False)
            return target
        except FileExistsError:
            print('目录已存在，保留旧证据；请换新名称')


class Runner:
    def __init__(self, project, logs, env):
        self.project, self.logs, self.env = project, logs, env
        logs.mkdir(parents=True, exist_ok=True)

    def run(self, name, command):
        log = self.logs / (name + '.log')
        print('\n执行：' + shlex.join([str(x) for x in command]), flush=True)
        print('日志：' + str(log) + '（编译和候选仿真可能需要数分钟）', flush=True)
        started = time.monotonic()
        stamp = datetime.now().astimezone().isoformat()
        with log.open('x', encoding='utf-8') as stream:
            result = subprocess.run([str(x) for x in command], cwd=str(self.project),
                                    env=self.env, stdout=stream, stderr=subprocess.STDOUT, check=False)
        record = {'command': [str(x) for x in command], 'cwd': str(self.project),
                  'started_at': stamp, 'elapsed_seconds': round(time.monotonic() - started, 3),
                  'exit_code': result.returncode, 'log': str(log)}
        with (self.logs / 'commands.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
        print('\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-25:]))
        print('退出码：' + str(result.returncode), flush=True)
        if result.returncode: raise CommandFailure(result.returncode, log)


def check_source(project):
    manifest = project / 'docs/validation/2026-10-13-bundle-resume/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-runtime-bridge/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-node-resume/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-node-context/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-baseline-accepted/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-op-schema/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-op-numeric/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-op-resume/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-saved-dc-selection/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-13-saved-dc/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-cascode-settings/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-cascode-batch/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-cascode-preflight/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-maestro-read/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-structure-result/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-12-core-reference/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-materialize-logging/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-cdf-properties/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-cdf-roundtrip-diagnostic/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-candidate-isolation/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-fin-mos/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-10-cdf-terminal-symbol/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-09-terminal-diagnostic/server-source-sha256.json'
    if not manifest.is_file():
        manifest = project / 'docs/validation/2026-10-09-test-root/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-09-structure-only/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-09-tech-owner/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-09-discovery-identity/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-09/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-08/server-source-sha256.json'
    if not manifest.exists():
        manifest = project / 'docs/validation/2026-10-07/server-source-sha256.json'
    expected = json.loads(manifest.read_text(encoding='utf-8'))
    for name, sha in expected.items():
        path = project / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != sha:
            raise ValueError('服务器源码不匹配本次测试包：' + name + '；请上传完整新源码')
    print('已核对本次源码文件：' + str(len(expected)))


def clean_environment(project):
    env = dict(os.environ)
    for key in list(env):
        if key.startswith(('ST_SITE_', 'ST_MAAU_')) or key in (
            'ST_CIRCUIT_CONTEXT', 'ST_SIMULATION_PROFILE', 'ST_PDK_METADATA',
            'ST_PDK_TECH_ADAPTER', 'ST_VIRTUOSO_BIN', 'ST_BACKEND_RUN_ROOT'):
            env.pop(key, None)
    env.update({'ST_ENGINE_ROOT': str(project), 'ST_BUILD_DIR': str(project / 'build'),
                'ST_BUILD_MAAU_COMPAT': 'OFF', 'ST_BUILD_MAAU_SITE_PROVIDER': 'OFF',
                'ST_OP_PROVIDER_BIN': str(project / 'server/site/op_provider.py'),
                'ST_CADENCE_RUNTIME_BIN': str(project / 'server/site/cadence_runtime.py')})
    for verb in ('scan_pdk', 'run_op', 'snapshot', 'clone', 'materialize', 'netlist', 'publish', 'open'):
        env['ST_' + verb.upper() + '_RUNNER'] = str(project / 'server/bin' / (verb + '_runner.sh'))
    env['ST_VIRTUOSO_BACKEND'] = str(project / 'server/st_virtuoso_backend.sh')
    return env


def collect_profile(source_cell):
    print('\n逐项声明实际仿真条件；任何不知道的必填项可输入 ?，不会填假值。')
    nominal = ask('名义 Corner 名称')
    corners = [x.strip() for x in ask('PVT Corner 名称，逗号分隔；回车仅测名义 DC', optional=True).split(',') if x.strip()]
    high, low = ask('父层 VBIAS 高轨网名'), ask('父层 VBIAS 低轨网名')
    limits = {}
    while True:
        error = ask('主支路最大相对误差，选填；暂无性能Spec直接回车', optional=True)
        current = ask('新增VBIAS最大电流，单位A，选填；暂无性能Spec直接回车', optional=True)
        if not error and not current:
            print('本次只求直流可行参数，未验证完整性能。')
            break
        try:
            error, current = float(error), float(current)
            if not all(math.isfinite(x) and x > 0 for x in (error, current)):
                raise ValueError()
            limits = {'max_branch_current_error': error, 'max_vbias_current': current}
            break
        except ValueError:
            print('两项一起留空，或一起填写实际有限正数；不能只填一项。')
    subckt = ask('Bench 内源 DUT 的实际子电路名', source_cell)
    op = {}
    for corner in dict.fromkeys([nominal] + corners):
        print('\nCorner：' + corner)
        temperature = number('实际温度，摄氏度')
        models = []
        while True:
            model = path_input('实际模型文件绝对路径' if not models else '再添加模型文件；回车结束', optional=bool(models))
            if model is None: break
            section = ask('这个文件使用的 section；无 section 才留空', optional=True)
            models.append({'model_file': str(model), 'section_name': section})
        while True:
            text = ask('实际设计变量，JSON 对象；回车保留 Bench 原变量', '{}')
            try:
                variables = json.loads(text)
                if not isinstance(variables, dict): raise ValueError()
                if any(not isinstance(k, str) or isinstance(v, (list, dict, bool)) or v is None
                       for k, v in variables.items()): raise ValueError()
                json.dumps(variables, allow_nan=False)
                break
            except (ValueError, TypeError):
                print('请填有效 JSON 对象，例如 {"变量名":"实际值"}')
        op[corner] = {'temperature': temperature, 'models': models, 'variables': variables}
    signals = []
    while True:
        signal = ask('实际 PSF 电源电流完整名称' if not signals else '再添加电源电流 signal；回车结束', optional=bool(signals))
        if not signal: break
        sign = int(choice('计入供电电流时的符号 1 或 -1（按实际方向）', ('1', '-1')))
        signals.append({'signal': signal, 'sign': sign})
    return {'nominal_corner': nominal, 'pvt_corners': corners, 'op_corners': op,
            'vbias_vhigh_net': high, 'vbias_vlow_net': low,
            'source_subckt': subckt, 'supply_current_signals': signals, **limits}


def tsv(path):
    with path.open(encoding='utf-8') as stream:
        return list(csv.DictReader(stream, delimiter='\t'))


def collect_operation(inventory, devices):
    kind = choice('变换：1 Source 串电阻；2 同 master Cascode；3 同 N/P 不同 master Cascode；4 共栅 Stack；0 只 inspect',
                  ('0', '1', '2', '3', '4'), '0')
    if kind == '0': raise InputPending('已完成 inspect，尚未进行结构生成')
    by_instance = {row['instance']: row for row in inventory}
    while True:
        target = ask('选择上述当前层 MOS 的实例名')
        if target in by_instance: break
        print('该实例不在当前层 MOS 清单中')
    original = by_instance[target]
    operation = {'id': 'op_server_one', 'instance': target}
    if kind == '1':
        operation['type'] = 'resistor'
        candidates = {d['master']: d for d in devices if d['kind'] == 'resistor'}
        for master, device in candidates.items():
            print('电阻：{}  OA={}/{}  CDF={}'.format(master, device.get('oa_library', ''),
                  device.get('oa_cell', ''), device.get('normalized_to_cdf', {})))
        if not candidates: raise ValueError('本次 catalog 没有真实电阻')
        while True:
            master = ask('选择扫描中的电阻 master')
            if master in candidates: break
            print('该 master 不在本次电阻目录')
        device = candidates[master]
        parameter = device.get('normalized_to_cdf', {}).get('resistance')
        constraint = device.get('parameter_constraints', {}).get('resistance', {})
        if not parameter or not constraint or constraint.get('cdf_name') != parameter:
            raise ValueError('所选电阻缺少已证明的 resistance CDF 映射/合法域；先补实际 PDK 规则')
        if device.get('terminal_count') != 2:
            raise ValueError('本次简易向导仅创建二端电阻操作；多端电阻请使用已有操作文件并声明附加端网')
        for source, output in (('minimum', 'resistor.min'), ('maximum', 'resistor.max'), ('grid', 'resistor.grid')):
            value = constraint.get(source)
            if value is None or not math.isfinite(value): raise ValueError('电阻 CDF 合法域缺失：' + source)
            operation[output] = str(value)
        operation.update({'resistor.master': master, 'resistor.parameter': parameter,
                          'resistor.value': str(number('要串入 Source 的阻值，单位 ohm', True))})
    else:
        operation['type'] = {'2': 'same_type_cascode', '3': 'cross_flavor_cascode', '4': 'stack'}[kind]
        source = next(d for d in devices if d['master'] == original['master'])
        operation['voltage_domain'] = ask('实际电压域（须在本次 PDK 中允许）', source.get('voltage_domain') or None)
        if original['polarity'] == 'mos_n':
            operation['nmos_bulk_net'] = ask('新增 NMOS 的实际 Bulk 网名', original.get('bulk') or None)
        operation['tie_isolated_pmos_to_source'] = 'true'
        operation['gate_policy'] = 'shared' if kind == '4' else 'fixed'
        if kind == '3':
            candidates = original.get('cross_flavor_candidates', '').split(',')
            candidates = [x for x in candidates if x]
            print('同 N/P 不同 master 候选：' + ', '.join(candidates))
            if not candidates: raise ValueError('本目标没有通过实际 PDK 准入的不同 master 候选')
            while True:
                master = ask('选择上述不同 master')
                if master in candidates: break
                print('请选择当前目标已准入的 master')
            operation['new_master'] = master
        if kind == '4':
            while True:
                count = ask('Stack 级数，2–100 且不超过实际 PDK 上限')
                if count.isdigit() and 2 <= int(count) <= 100: break
                print('请输入 2–100 的整数；引擎还会核对 PDK 上限')
            operation['stage_count'] = count
    return operation


def check_final(work):
    report = work / 'reports/validation.txt'
    values = dict(line.split('=', 1) for line in report.read_text(encoding='utf-8').splitlines() if '=' in line)
    if any(values.get(k) != v for k, v in (('ok', 'true'), ('ready_for_sizing', 'true'), ('stage', 'complete'))):
        raise ValueError('validation 未放行；查看 ' + str(report))
    if (work / 'before/core_before.scs').read_bytes() != (work / 'after/source_roundtrip.scs').read_bytes():
        raise ValueError('源电路回读与原图不同，停止 open；保留证据排查')
    print(report.read_text(encoding='utf-8'))
    print('源电路网表 cmp 等价检查通过（逐字节）')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    run = None
    try:
        project = Path(args.project).resolve()
        check_source(project)
        mode = choice('测试范围：1 编译回归；2 加只读 PDK 扫描（首次推荐）；3 完整单项结构验证', ('1', '2', '3'), '2')
        parent = Path(ask('测试产物父目录，绝对路径', str(project.parent / (project.name + '-runs')))).expanduser()
        if not parent.is_absolute(): raise ValueError('测试产物目录必须是绝对路径')
        run = new_run(parent)
        env = clean_environment(project)
        runner = Runner(project, run / 'logs', env)
        runner.run('01_build', ['bash', project / 'scripts/build.sh'])
        runner.run('02_tests', ['bash', project / 'scripts/test.sh'])
        runner.run('03_interactive_tests', [sys.executable, project / 'tests/ServerTestInteractiveTest.py'])
        if mode == '1':
            print('编译/本地回归阶段结束；未运行真实 PDK/仿真。')
            return 0
        for tool in (['virtuoso'] if mode == '2' else ['virtuoso', 'ocean', 'spectre']):
            found = shutil.which(tool)
            if not found: raise ValueError('未找到 ' + tool + '；按原服务器方式加载 Cadence 环境后重新测试')
            print(tool + '=' + found)
        init = Path(env.get('ST_SKILL_INIT') or project / 'server/skill/init.il').resolve()
        if not init.is_file(): raise ValueError('启动 helper 不存在：' + str(init))
        env['ST_SKILL_INIT'] = str(init)
        env['ST_VIRTUOSO_BIN'] = shutil.which('virtuoso')
        known_cds = project.parent / 'HiAplatRV500_ldo_sim_ldo1_0_cbb_top/circuit/cds/target/cds.lib'
        cds = path_input('原工程 cds.lib 的绝对路径', str(known_cds) if known_cds.is_file() else None)
        variant = ask('派生库名称（独立于源库）', 'HiAplat730RV200_Maau_cal_ST')
        source_lib = ask('源 Core 库名', 'HiAplat730RV200_Maau_cal')
        source_cell = ask('源 Core Cell 名', 'ocldo18to12_200ma_core')
        write_json(run / 'test_inputs.json', {'mode': mode, 'project': str(project),
                   'source_lib': source_lib, 'source_cell': source_cell, 'pdk_mode': 'source_technology_discovery',
                   'skill_init': str(init), 'source_cds_lib': str(cds), 'variant_library': variant})
        backend = project / 'server/st_virtuoso_backend.sh'
        runner.run('04_prepare', ['bash', project / 'server/prepare_session.sh', '--source-cds-lib', cds,
                   '--session-dir', run / 'cadence', '--variant-lib', variant])
        session_cds = run / 'cadence/cds.lib'
        entry = [sys.executable, project / 'server/site/standalone.py']
        runner.run('05_probe', entry + ['discover-pdk', '--backend', backend, '--cds-lib', session_cds,
                   '--lib', source_lib, '--cell', source_cell, '--view', 'schematic', '--output', run / 'pdk_discovery'])
        probe = run / 'pdk_discovery/pdk_probe.tsv'
        rows = tsv(probe)
        identities = sorted({(r['oa_library'], r['oa_cell']) for r in rows})
        if not identities: raise ValueError('PDK 扫描为空；核对实际根目录及 cds.lib 内已注册库')
        print('只读扫描实际 OA master 数：{}；产物：{}'.format(len(identities), probe))
        if mode == '2':
            print('只读扫描阶段结束；尚未做结构生成或电气放行。')
            return 0
        bench_lib, bench_cell = ask('实际 schematic Bench 库名'), ask('实际 schematic Bench Cell 名')
        profile_path = path_input('已有 simulation_profile.json 绝对路径；回车逐项输入生成', optional=True)
        if profile_path is None:
            profile_path = run / 'simulation_profile.json'
            write_json(profile_path, collect_profile(source_cell))
        rules = path_input('有来源的 PDK rules JSON 绝对路径；无补充文件则回车', optional=True)
        work = run / 'work'
        variant_id = 'TV_' + run.name
        inspect = entry + ['inspect', '--simulation-profile', profile_path,
                   '--backend', backend, '--cds-lib', session_cds, '--lib', source_lib, '--cell', source_cell,
                   '--view', 'schematic', '--core-subckt', source_cell, '--bench-lib', bench_lib,
                   '--bench-cell', bench_cell, '--bench-view', 'schematic', '--work-dir', work,
                   '--variant-lib', variant, '--variant-cell', source_cell + '__' + variant_id,
                   '--variant-id', variant_id, '--skill', project / 'skill/standalone_topology_variant.il']
        if rules: inspect.extend(['--pdk-rules', rules])
        runner.run('06_inspect', inspect)
        inventory = tsv(work / 'before/mos_inventory.tsv')
        for r in inventory:
            print('{} {} {} D={} G={} S={} B={}'.format(r['instance'], r['polarity'], r['master'],
                  r['drain'], r['gate'], r['source'], r['bulk']))
        print('实际当前层 MOS 数量：' + str(len(inventory)))
        operation = path_input('已有操作文件绝对路径；回车交互选择一项变换', optional=True)
        if operation is None:
            devices = json.loads((work / 'analysis/pdk_catalog.json').read_text())['devices']
            values = collect_operation(inventory, devices)
            operation = run / 'operation.conf'
            with operation.open('x', encoding='utf-8') as stream:
                stream.write(''.join(k + '=' + v + '\n' for k, v in values.items()))
        print('\n本次操作文件：' + str(operation) + '\n' + operation.read_text(encoding='utf-8'))
        runner.run('07_confirm', entry + ['confirm', '--session', work, '--operation', operation])
        runner.run('08_list', entry + ['list', '--session', work])
        runner.run('09_generate', entry + ['generate', '--session', work])
        check_final(work)
        print('当前配置的单项验证已通过；DC 结果不代表所有 PVT/动态性能或整机 IQ 已验证。')
        if choice('是否打开已放行的派生原理图？y/n', ('y', 'n'), 'n') == 'y':
            runner.run('10_open', entry + ['open', '--session', work])
        return 0
    except InputPending as error:
        print('停在已完成阶段：' + str(error) + '；完整结构验证未完成（退出码 3）')
        return 3
    except CommandFailure as error:
        print(str(error), file=sys.stderr)
        return error.code if 1 <= error.code <= 255 else 1
    except (OSError, ValueError, KeyError, StopIteration) as error:
        print('测试停止：' + str(error), file=sys.stderr)
        return 2
    except (EOFError, KeyboardInterrupt):
        print('\n输入结束/中断；已生成的证据保留。')
        return 130
    finally:
        if run: print('\n请回传本次目录（尤其 logs、pdk_probe.tsv、work/reports 与 diagnostics）：' + str(run))


if __name__ == '__main__':
    sys.exit(main())
