#!/usr/bin/env python3
"""Continue generate in the existing failed experiment; no rebuild/re-inspect.

An explicit, known port-reader update uses a separate manifest; the old input
manifest is retained. All other fingerprints and experimental gates still run.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/site'))
from run_cascode_experiment import StageFailure, pairs, run_stage, validate_result
from site_data import read_json, write_json, verify_site_inputs
from inspect_cascode_pdk_evidence import latest


def port_updated_inputs(original):
    """Allow exactly the published before/after runtime pair; verify all else."""
    release=read_json(ROOT/'scripts/cascode_bus_ports_update.json')
    runtime=str((ROOT/'server/site/cascode_runtime.py').resolve())
    if (release.get('schema')!='cascode-bus-ports-update-v1' or
            str(Path(original['runtime']).resolve())!=runtime or
            original['file_sha256'].get(runtime)!=release['before_sha256'] or
            hashlib.sha256(Path(runtime).read_bytes()).hexdigest()!=release['after_sha256']):
        raise ValueError('port runtime update does not match the published before/after hashes')
    updated=copy.deepcopy(original)
    updated['file_sha256'][runtime]=release['after_sha256']
    verify_site_inputs(updated)
    return updated,release


def reuse_updated_inputs(original):
    release=read_json(ROOT/'scripts/cascode_reuse_update.json')
    if release.get('schema')!='cascode-reuse-update-v1':
        raise ValueError('unsupported reuse update release')
    updated=copy.deepcopy(original)
    for relative,entry in release['files'].items():
        path=(ROOT/relative).resolve()
        if ROOT not in path.parents:
            raise ValueError('update path outside engine')
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        old=original['file_sha256'].get(str(path))
        if actual!=entry['after_sha256'] or old not in entry['before_sha256']+[entry['after_sha256']]:
            raise ValueError('reuse update does not match published code: '+relative)
        updated['file_sha256'][str(path)]=actual
    verify_site_inputs(updated)
    return updated,release


def retained_port_preflight(candidate, inputs):
    """Run the repaired pure parser on retained evidence before launching EDA."""
    from cascode_runtime import wrap_oa_dut
    from op_provider import parse_deck
    baseline=candidate/'work/analysis/baseline_op'
    if any((baseline/name).exists() for name in ('identity.tsv','mos.tsv')):
        raise ValueError('existing OP outputs predate this runtime upgrade; do not reuse them')
    export=latest(baseline.glob('raw_op/st-op-simulation.*/export_dut.log'))
    directory=export.parent;dut=directory/'dut_oa'
    used={}
    def read(path):
        path=Path(path);data=path.read_bytes()
        used[str(path)]=hashlib.sha256(data).hexdigest()
        return data.decode('utf-8')
    if 'actual OA DUT/Bench port mismatch' not in read(export):
        raise ValueError('latest retained export was not the known OA/Bench port failure')
    if read(dut/'runtime.done').strip()!='OK':raise ValueError('retained native export incomplete')
    bundle=read_json(read_json(inputs['rules'])['validated_baseline_bundle'])
    bench_text=read(directory/'bench.scs')
    if bench_text!=read(bundle['bench_netlist']):raise ValueError('retained Bench differs from accepted Bench')
    designs=re.findall(r'^\s*design\(([^\n]*)\)\s*$',read(dut/'runtime.ocn'),re.M)
    if len(designs)!=1:raise ValueError('retained actual OA design is ambiguous')
    actual=[json.loads(v) for v in re.findall(r'"(?:[^"\\]|\\.)*"',designs[0])]
    if actual!=[bundle['source'][k] for k in ('lib','cell','view')]:
        raise ValueError('retained export is not the accepted baseline source OA')
    generated=list((dut/'generated').rglob('input.scs'))
    if len(generated)!=1:raise ValueError('retained input.scs missing or ambiguous')
    ports=parse_deck(bench_text)['definitions'][bundle['source_subckt']]['ports']
    _,evidence=wrap_oa_dut(read(generated[0]),actual[1],read(dut/'ports.txt').splitlines(),ports,
        bundle['variables'],baseline_text=bench_text,source_subckt=bundle['source_subckt'])
    for path,digest in used.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:
            raise ValueError('retained port evidence changed during read: '+path)
    evidence.update(simulation_directory=str(directory),file_sha256=used,native_executions=0)
    print('PORT_PREFLIGHT=PASS\nPORT_BINDING=BUS_BITS_VERIFIED OA='+str(evidence['oa_port_count'])+
          ' BITS='+str(evidence['expanded_port_count']),flush=True)
    print('PORTS_UNUSED_IN_BOTH='+json.dumps(evidence['unused_in_both']),flush=True)
    return evidence


def resume(candidate, timeout, runner=run_stage, upgrade_port_reader=False, reuse_verified_inputs=False):
    candidate=Path(candidate).resolve();work=candidate/'work'
    status_path=candidate/'run_status.json'
    previous=list(candidate.glob('resume_generate_*/run_status.json'))
    if previous:status_path=latest(previous)
    previous_status=read_json(status_path)
    if previous_status.get('failed_stage')!='generate' or previous_status.get('result')!='INCOMPLETE':
        raise ValueError('latest attempt is not a failed generate; refusing to repeat other stages')
    if pairs(work/'session.conf').get('validation_scope')!='experimental_dc':
        raise ValueError('resume requires the existing experimental_dc session')
    if not list((work/'changes').glob('*.conf')):
        raise ValueError('confirmed operation missing; no automatic confirm')
    original_path=work/'analysis/standalone_inputs/provider_inputs.json'
    manifest=read_json(original_path)
    original_digest=hashlib.sha256(original_path.read_bytes()).hexdigest()
    reuse=reuse_verified_inputs or bool(previous_status.get('reuse_manifest'))
    upgraded=reuse or upgrade_port_reader or bool(previous_status.get('provider_manifest'))
    receipt=None
    if reuse:
        from experiment_reuse import prepare_receipt, check_files
        manifest,release=reuse_updated_inputs(manifest)
        if previous_status.get('reuse_manifest'):
            if previous_status.get('original_provider_manifest_sha256')!=original_digest:
                raise ValueError('original inputs changed since reuse preparation')
            prior=read_json(previous_status['provider_manifest'])
            # A previous attempt pins the prior release too. Apply the same
            # explicit code-only migration; its receipt and every other input
            # are still verified, rather than rejecting the known update.
            prior,_=reuse_updated_inputs(prior)
            receipt_path=str(Path(previous_status['reuse_manifest']).resolve())
            receipt=read_json(receipt_path)
            expected=copy.deepcopy(manifest)
            expected['file_sha256'][receipt_path]=hashlib.sha256(Path(receipt_path).read_bytes()).hexdigest()
            if prior!=expected:raise ValueError('previous reuse inputs differ from current release')
            check_files(receipt['file_sha256'])
        else:
            receipt=prepare_receipt(candidate,manifest)
        print('REUSE_PREFLIGHT=PASS\nPDK_SCAN_REUSE_READY=true\nPORT_EVIDENCE_REUSED=true\nDEVICE_BINDINGS_REUSED=true',flush=True)
        print('BASELINE_DC_REUSE_READY='+str(bool(receipt['mos_rows'])).lower(),flush=True)
        print('BASELINE_REUSE_REASON='+receipt['baseline_reuse_reason'],flush=True)
        print('PRESERVED_RESISTOR_GROUPS='+str(len(receipt['preserved_resistors'])),flush=True)
    elif upgraded:
        manifest,release=port_updated_inputs(manifest)
        if previous_status.get('provider_manifest'):
            if (previous_status.get('original_provider_manifest_sha256')!=original_digest or
                    read_json(previous_status['provider_manifest'])!=manifest):
                raise ValueError('previous upgraded manifest differs from this exact port update')
            evidence=dict(reused_from=previous_status['provider_manifest'],native_executions=0)
        else:
            evidence=retained_port_preflight(candidate,manifest)
    else:
        verify_site_inputs(manifest)
    inputs=read_json(candidate/'inputs.json')
    for name,digest in inputs.get('input_sha256',{}).items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:
            raise ValueError('bound experiment input changed: '+name)
    if not os.access(ROOT/'build/bin/st_circuit_tool',os.X_OK):
        raise ValueError('compiled tool missing; no automatic rebuild during resume')
    output=Path(tempfile.mkdtemp(prefix='resume_generate_',dir=str(candidate)))
    if (work/'logs').is_dir():shutil.copytree(work/'logs',output/'previous_work_logs')
    argv=[sys.executable,str(ROOT/'server/site/standalone.py'),'generate','--session',str(work)]
    status=dict(checker='cascode-experiment-resume-v3' if reuse else 'cascode-experiment-resume-v2',result='INCOMPLETE',
                candidate=str(candidate),experimental_dc_ready=False,ready_for_sizing=False,
                reliability_verified=False,published=False)
    env=None
    if upgraded:
        from standalone import environment
        active=output/'provider_inputs.json'
        if reuse:
            receipt_path=output/'reuse_manifest.json'
            write_json(receipt_path,receipt)
            manifest['file_sha256'][str(receipt_path)]=hashlib.sha256(receipt_path.read_bytes()).hexdigest()
        write_json(active,manifest)
        write_json(output/('reuse_upgrade.json' if reuse else 'port_runtime_upgrade.json'),dict(release=release,
            port_preflight={'reused':True} if reuse else evidence,
            original_manifest=str(original_path),original_manifest_sha256=original_digest))
        env=environment(manifest,active)
        if reuse:
            env['ST_EXPERIMENT_REUSE_MANIFEST']=str(receipt_path)
            status['reuse_manifest']=str(receipt_path)
        argv=[str(ROOT/'build/bin/st_circuit_tool'),'generate','--session',str(work)]
        status.update(provider_manifest=str(active),original_provider_manifest_sha256=original_digest)
        print(('REUSE_RUNTIME_UPGRADED=true' if reuse else 'PORT_RUNTIME_UPGRADED=true')+
              '\nORIGINAL_INPUT_MANIFEST_UNCHANGED=true',flush=True)
    write_json(output/'command.json',argv)
    print('CHECKER='+status['checker']+'\nCANDIDATE_DIR='+str(candidate)+'\nOUTPUT_DIR='+str(output),flush=True)
    print('RESUME_STAGE=generate\nREBUILD=false\nINSPECT_REUSED=true\nCONFIRM_REUSED=true',flush=True)
    try:
        if upgraded:runner('generate',argv,output,timeout,env=env)
        else:runner('generate',argv,output,timeout)
        report=pairs(work/'reports/validation.txt');validate_result(report)
        status.update(result='EXPERIMENT_DC_PASS',experimental_dc_ready=True,validation=report)
    except StageFailure as error:
        status.update(issue=str(error),failed_stage='generate',native_exit_code=error.code)
        if error.log.is_file():
            for line in error.log.read_text(errors='replace').splitlines()[-24:]:print('STAGE_LOG '+line[:900])
        logs=sorted(work.rglob('*.log'),key=lambda p:p.stat().st_mtime_ns,reverse=True)
        for log in logs[:3]:
            print('DETAIL_LOG='+str(log))
            for line in log.read_text(errors='replace').splitlines()[-10:]:print('DETAIL '+line[:700])
    except (OSError,ValueError,KeyError,TypeError) as error:
        status.update(issue=str(error),failed_stage='generate')
    except KeyboardInterrupt:
        status.update(issue='interrupted; no automatic retry',failed_stage='generate')
    write_json(output/'run_status.json',status)
    print('DETAILS_FILE='+str(output/'run_status.json')+'\nRESULT='+status['result'])
    if status.get('issue'):print('ISSUE '+status['issue'])
    print('EXPERIMENTAL_DC_READY='+str(status['experimental_dc_ready']).lower())
    print('READY_FOR_SIZING=false\nRELIABILITY_VERIFIED=false\nPUBLISHED=false')
    return 0 if status['experimental_dc_ready'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--batch',help='select the latest candidate from this batch')
    source.add_argument('--candidate',help='explicit candidate directory')
    parser.add_argument('--stage-timeout',type=int,default=1800)
    parser.add_argument('--upgrade-port-reader',action='store_true',
                        help='use the published bus-port runtime update with a separate input manifest')
    parser.add_argument('--reuse-verified-inputs',action='store_true',
                        help='reuse same-session verified source evidence and retain unchanged peripheral resistors')
    args=parser.parse_args()
    try:
        if args.stage_timeout<=0:raise ValueError('timeout must be positive')
        candidate=Path(args.candidate).resolve() if args.candidate else latest(Path(args.batch).resolve().glob('candidate_*/run_status.json')).parent
        return resume(candidate,args.stage_timeout,upgrade_port_reader=args.upgrade_port_reader,
                      reuse_verified_inputs=args.reuse_verified_inputs)
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('CHECKER=cascode-experiment-resume-v3\nRESULT=INCOMPLETE\nISSUE '+str(error))
        print('EXPERIMENTAL_DC_READY=false\nPUBLISHED=false')
        return 2


if __name__=='__main__':raise SystemExit(main())
