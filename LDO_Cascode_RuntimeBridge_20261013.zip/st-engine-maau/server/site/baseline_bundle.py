"""Hash-bound saved-DC evidence and candidate DUT binding, without native runs.

The caller supplies the bound inputs returned by validated_baseline. A bundle is
local to its server/session: paths are explicit and no electrical readiness is
inferred from the existence of DC data. Only literal dependency paths are
supported; implicit simulator search paths are not guessed.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex

from site_data import finite, read_json, write_json


SCHEMA_VERSION = 1
_INCLUDE = re.compile(r'^(include|ahdl_include|`include)\s+("(?:\\.|[^"\\])*")(.*)$')
_SECTION = re.compile(r'\s+section\s*=\s*([A-Za-z_][\w.-]*)\s*$')


def _digest(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_fingerprints(fingerprints):
    if not isinstance(fingerprints, dict) or not fingerprints:
        raise ValueError('baseline file fingerprints are required')
    for name, expected in fingerprints.items():
        path = Path(name)
        if not path.is_absolute() or not re.fullmatch(r'[0-9a-f]{64}', str(expected)):
            raise ValueError('invalid baseline fingerprint: ' + str(name))
        if not path.is_file() or _digest(path) != expected:
            raise ValueError('baseline dependency changed or missing: ' + str(path))


def _clean_comments(text):
    """Remove comments while preserving strings and line boundaries."""
    out = []
    index = 0
    quoted = False
    while index < len(text):
        char = text[index]
        if quoted:
            out.append(char)
            if char == '\\' and index + 1 < len(text):
                index += 1
                out.append(text[index])
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
            out.append(char)
        elif text.startswith('//', index):
            end = text.find('\n', index)
            index = len(text) if end < 0 else end
            continue
        elif text.startswith('/*', index):
            end = text.find('*/', index + 2)
            if end < 0:
                raise ValueError('unterminated dependency comment')
            out.append(' ' + '\n' * text[index:end + 2].count('\n'))
            index = end + 2
            continue
        else:
            out.append(char)
        index += 1
    if quoted:
        raise ValueError('unterminated dependency string')
    return ''.join(out)


def _literal_path(raw, origin):
    name = json.loads(raw)
    if not isinstance(name, str) or not name or any(c in name for c in '\r\n\t\0'):
        raise ValueError('invalid dependency path')
    expanded = os.path.expandvars(os.path.expanduser(name))
    if '$' in expanded:
        raise ValueError('unresolved dependency environment: ' + name)
    path = Path(expanded)
    path = path if path.is_absolute() else Path(origin) / path
    if not path.is_file():
        raise ValueError('unresolved literal dependency: ' + str(path))
    # Directory aliases are fine. A file symlink changing the directory used
    # for its own relative includes needs an explicit dependency-origin proof.
    resolved = path.resolve()
    if path.parent.resolve() != resolved.parent:
        raise ValueError('dependency file symlink changes include origin: ' + str(path))
    return resolved


def _include(line, origin):
    stripped = line.strip()
    starts = re.match(r'^(?:include|ahdl_include|`include|\.include|\.inc|\.lib|#include)\b', stripped, re.I)
    if not starts:
        return None
    match = _INCLUDE.fullmatch(stripped)
    if not match:
        raise ValueError('non-literal or unsupported dependency: ' + stripped[:250])
    kind, raw, tail = match.groups()
    section = None
    if tail.strip():
        selected = _SECTION.fullmatch(tail)
        if kind != 'include' or not selected:
            raise ValueError('unsupported dependency suffix: ' + stripped[:250])
        section = selected[1]
    path = _literal_path(raw, origin)
    return dict(kind=kind, path=str(path), section=section)


def _dependency_lines(text):
    from op_provider import lines
    if re.search(r'(?:\bpragma\s+protect\b|^\s*`?protect\b|^\s*encrypted\b)', text, re.I | re.M):
        raise ValueError('encrypted dependency requires explicit dependency manifest')
    return lines(_clean_comments(text))


def _absolute_deck(text, origin):
    rewritten = []
    for line in _dependency_lines(text):
        dependency = _include(line, origin)
        if dependency:
            if dependency['kind'] == '`include':
                raise ValueError('Verilog include is not supported in the Spectre root deck')
            line = dependency['kind'] + ' ' + json.dumps(dependency['path'])
            if dependency['section'] is not None:
                line += ' section=' + dependency['section']
        rewritten.append(line)
    return '\n'.join(rewritten) + '\n'


def _dependencies(text, origin, extra=()):
    fingerprints = {}
    references = []
    visiting = set()

    def visit(path):
        path = Path(path).resolve()
        name = str(path)
        if name in visiting:
            raise ValueError('recursive dependency include: ' + name)
        if name in fingerprints:
            return
        if not path.is_file():
            raise ValueError('missing baseline dependency: ' + name)
        visiting.add(name)
        fingerprint = _digest(path)
        try:
            content = path.read_text()
        except UnicodeError as error:
            raise ValueError('unreadable dependency text: ' + name) from error
        for line in _dependency_lines(content):
            dependency = _include(line, path.parent)
            if dependency:
                references.append(dependency)
                visit(dependency['path'])
        visiting.remove(name)
        if _digest(path) != fingerprint:
            raise ValueError('dependency changed while reading: ' + name)
        fingerprints[name] = fingerprint

    for line in _dependency_lines(text):
        dependency = _include(line, origin)
        if dependency:
            references.append(dependency)
            visit(dependency['path'])
    for path in extra:
        visit(path)
    return fingerprints, references


def _root_path(text, source_subckt):
    from op_provider import parse_deck
    deck = parse_deck(text)
    if source_subckt not in deck['definitions']:
        raise ValueError('source subckt missing from verified baseline')
    occurrences = []
    count = 0

    def visit(instances, prefix, parents):
        nonlocal count
        for inst in instances:
            count += 1
            if count > 100000 or len(parents) > 100:
                raise ValueError('baseline hierarchy exceeds supported bound')
            path = prefix + inst['name']
            if inst['master'] == source_subckt:
                occurrences.append(path)
            elif inst['master'] in deck['definitions']:
                if inst['master'] in parents:
                    raise ValueError('recursive baseline hierarchy')
                visit(deck['definitions'][inst['master']]['instances'], path + '.', parents + [inst['master']])
    visit(deck['top'], '', [])
    if len(occurrences) != 1:
        raise ValueError('baseline source DUT occurrence must be unique')
    return occurrences[0]


def _native_commands(baseline):
    """Retain full native command paragraphs, including indented continuations."""
    commands = []
    for directory in ('baseline_run', 'baseline_generated', 'baseline_results'):
        for path in sorted((Path(baseline) / directory).rglob('*')):
            if not path.is_file() or path.suffix not in ('.log', '.out'):
                continue
            paragraph = None
            for line in path.read_text(errors='replace').splitlines() + ['']:
                if 'Command line:' in line:
                    if paragraph:
                        commands.append(' '.join(paragraph))
                    paragraph = [line.split('Command line:', 1)[1].strip().rstrip('\\').strip()]
                elif paragraph is not None and line.strip() and line[:1].isspace():
                    paragraph.append(line.strip().rstrip('\\').strip())
                elif paragraph is not None:
                    if any(paragraph):
                        commands.append(' '.join(paragraph).strip())
                    paragraph = None
    return list(dict.fromkeys(commands))


def _launch_contract(selected, launch_evidence, command_evidence):
    from read_cascode_solver_settings import literal_call, saved_values, check_launch
    _, options, turbo = saved_values(selected)
    check_launch(selected, '\n'.join(launch_evidence))
    allowed = {'categ', 'uniMode', 'errorLevel', 'mtOption', 'numThreads'}
    level = str(turbo.get('errorLevel', '')).lower()
    threads = str(turbo.get('numThreads', ''))
    if level not in ('conservative', 'moderate', 'liberal') or turbo.get('mtOption') != 'Manual' or not threads.isdigit() or int(threads) < 1:
        raise ValueError('explicit supported APS accuracy/manual thread settings required')
    env_options = {}
    for form in selected:
        name, args = literal_call(form)
        if name == 'envOption':
            for key, value in zip(args[::2], args[1::2]):
                env_options[key.lstrip("?'")] = json.loads(value) if isinstance(value, str) and value.startswith('"') else value
    omitted = [dict(name=name, value=turbo[name], source='turboOpts',
                    reason='saved setting retained; standalone launcher semantics not proven')
               for name in sorted(set(turbo) - allowed)]
    omitted += [dict(name=name, value=env_options[name], source='envOption',
                     reason='saved environment retained; standalone launcher semantics not proven')
                for name in sorted(set(env_options) - {'licQueueTimeOut', 'analysisOrder'})]
    # A few settings are emitted as launcher flags rather than deck options.
    # Derive their spelling only from matching native baseline command evidence.
    commands = []
    for command in command_evidence:
        try:
            commands.append(shlex.split(command))
        except ValueError as error:
            raise ValueError('malformed native launch evidence') from error
    aps_commands = [command for command in commands
                    if any(re.match(r'^\+\+?aps(?:=|$)', token, re.I) for token in command)]
    tokens = [token for command in aps_commands for token in command]
    if not tokens:
        # Older proof readers retained only the APS/thread-bearing log lines.
        # These prove core launch flags, not omitted command-line controls.
        tokens = ' '.join(launch_evidence).split()
    aps_flags = {token.lower() for token in tokens if re.match(r'^\+\+?aps(?:=|$)', token, re.I)}
    mt_flags = {token for token in tokens if re.match(r'^\+mt(?:=|$)', token)}
    if len(aps_flags) != 1 or next(iter(aps_flags)) not in ('+aps=' + level, '++aps=' + level):
        raise ValueError('native APS accuracy/variant is missing or conflicting')
    if mt_flags != {'+mt=' + threads}:
        raise ValueError('native manual thread count is missing or conflicting')
    argv = [next(iter(aps_flags)), '+mt=' + threads]
    for name, mapping, suffix in (('licQueueTimeOut', env_options, 'lqtimeout'),
                                  ('maxwarns', options, 'maxw'), ('maxnotes', options, 'maxn')):
        if name not in mapping:
            continue
        value = str(mapping[name])
        if not value.isdigit():
            raise ValueError('unsupported saved launcher value: ' + name)
        matches = set()
        observed = set()
        for command in commands:
            for index, token in enumerate(command):
                if token in ('+' + suffix, '-' + suffix):
                    actual = command[index + 1] if index + 1 < len(command) else None
                    observed.add(actual)
                    if actual == value:
                        matches.add((token, value))
                elif token.startswith(('+' + suffix + '=', '-' + suffix + '=')):
                    actual = token.split('=', 1)[1]
                    observed.add(actual)
                    if actual == value:
                        matches.add((token,))
        if len(matches) == 1 and observed == {value}:
            argv.extend(next(iter(matches)))
        else:
            omitted.append(dict(name=name, value=mapping[name], reason='native flag/value evidence missing or ambiguous'))
    return dict(argv=argv, engine='APS', error_level=level, thread_mode='Manual', num_threads=int(threads),
                replay_scope='validated_saved_launch_controls', complete=not omitted,
                saved_turbo_options=turbo, saved_env_options=env_options,
                omitted_launch_options=omitted)


def export_bundle(bound, baseline, output):
    """Export a previously validated baseline; never call a native executable."""
    from collect_cascode_batch import literal_files
    from read_cascode_solver_settings import extract_forms, dc_settings, effective_controls, simulation_evidence
    baseline = Path(baseline).resolve()
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('baseline bundle output must be a new directory')
    fixed = {}
    historical = {}

    def retain_saved(fingerprints):
        if not isinstance(fingerprints, dict):
            raise ValueError('saved baseline fingerprints must be an object')
        for name, expected in fingerprints.items():
            if name in historical and historical[name] != expected:
                raise ValueError('conflicting saved baseline fingerprints: ' + name)
            historical[name] = expected
            fixed[name] = expected

    retain_saved(bound['fixed'])
    retain_saved(bound.get('pinned', {}).get('file_sha256', {}))
    _verify_fingerprints(fixed)
    exports = list((baseline / 'baseline_generated').rglob('input.scs'))
    if len(exports) != 1:
        raise ValueError('verified baseline config export missing or ambiguous')
    actual = exports[0]
    text = (baseline / 'baseline_run.scs').read_text()
    if actual.read_text() != text or (baseline / 'baseline_run/runtime.done').read_text().strip() != 'OK':
        raise ValueError('baseline run/export binding is incomplete')
    if read_json(baseline / 'baseline_status.json').get('converged') is not True:
        raise ValueError('a converged baseline is required')
    forms = read_json(baseline / 'settings_forms.json')
    if forms != extract_forms((baseline / 'saved_test.ocn').read_text()):
        raise ValueError('saved settings cache differs from native export')
    selected, _ = dc_settings(forms)
    settings = bound['settings']
    temperature = finite(settings['temperature'])
    controls = effective_controls(text, selected, temperature)
    psf, launch_evidence = simulation_evidence(baseline, selected)
    launch_commands = _native_commands(baseline)
    launch = _launch_contract(selected, launch_evidence, launch_commands)
    definitions = literal_files((baseline / 'definition_files.txt').read_text())
    if definitions:
        definition_hashes = read_json(baseline / 'baseline_definition_hashes.json')
        expected = {name: _digest(name) for name in definitions}
        if definition_hashes != expected:
            raise ValueError('Definition Files differ from historical baseline fingerprints')
        retain_saved(definition_hashes)
    models = settings['models']
    if not models or len({(m['model_file'], m['section_name']) for m in models}) != len(models):
        raise ValueError('missing or duplicate baseline model selection')
    for model in models:
        retain_saved({model['model_file']: model['sha256']})
    _verify_fingerprints(fixed)
    dependencies, references = _dependencies(text, actual.parent,
                                            definitions + [m['model_file'] for m in models])
    absolute = _absolute_deck(text, actual.parent)
    source = {key: bound['cfg']['source_' + field] for key, field in (('lib', 'library'), ('cell', 'cell'), ('view', 'view'))}
    source_subckt = source['cell']
    root_path = _root_path(absolute, source_subckt)
    required = [baseline / name for name in ('baseline_run.scs', 'baseline_netlist.scs', 'baseline_status.json',
                'settings_forms.json', 'saved_test.ocn', 'definition_files.txt', 'baseline_run/runtime.done')]
    if definitions:
        required.append(baseline / 'baseline_definition_hashes.json')
    required.append(actual)
    required.extend(p for p in psf.rglob('*') if p.is_file())
    required.extend(p for directory in ('baseline_run', 'baseline_generated', 'baseline_results')
                    for p in (baseline / directory).rglob('*') if p.is_file() and p.suffix in ('.log', '.out'))
    for path in required:
        name = str(path)
        current = _digest(path)
        if name in fixed and fixed[name] != current:
            raise ValueError('baseline evidence changed during export: ' + name)
        fixed[name] = current
    for name, current in dependencies.items():
        if name in fixed and fixed[name] != current:
            raise ValueError('dependency conflicts with validated inputs: ' + name)
        fixed[name] = current
    _verify_fingerprints(fixed)
    selection = bound['data']['selection']
    bundle = dict(schema_version=SCHEMA_VERSION, kind='cascode-baseline-bundle',
                  session=str(Path(bound['session']).resolve()), baseline=str(baseline),
                  cds_lib=str(Path(bound['cds']).resolve()), source=source, bench=dict(settings['design']),
                  maestro={key: selection[field] for key, field in (('lib', 'bench_library'), ('cell', 'bench_cell'), ('view', 'setup_view'))},
                  test_name=settings['test_name'], corner=settings['corner'], temperature=temperature,
                  variables=dict(settings['variables']), models=models, source_subckt=source_subckt, root_path=root_path,
                  selected_forms=selected, definition_files=definitions, launch_contract=launch,
                  launch_evidence=launch_evidence, launch_command_evidence=launch_commands, effective_controls=controls,
                  dependency_references=references, dependency_sha256=dependencies,
                  file_sha256=fixed, bench_netlist=str(output / 'bench.scs'),
                  simulation_profile_ready=False, pdk_electrical_rules_ready=False,
                  electrical_verified=False, vbias_generated=False)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'bench.scs').write_text(absolute)
    bundle['bench_sha256'] = _digest(output / 'bench.scs')
    bundle['file_sha256'][str(output / 'bench.scs')] = bundle['bench_sha256']
    # Prior hashes retain their original values. Newly discovered transitive
    # files are an export-time snapshot, not proof of their contents at the
    # historical PSF run. Keep that limit machine-readable for the bridge.
    bundle['historical_verified_paths'] = sorted(historical)
    bundle['first_fingerprinted_at_export_paths'] = sorted(set(fixed) - set(historical))
    bundle['recursive_dependencies_historically_verified'] = set(dependencies) <= set(historical)
    _verify_fingerprints(bundle['file_sha256'])
    manifest = output / 'baseline_bundle.json'
    write_json(manifest, bundle)
    manifest.with_suffix('.sha256').write_text(_digest(manifest) + '\n')
    return manifest


def load_bundle(path, expected_source=None, expected_bench=None, corner=None):
    """Revalidate all referenced evidence and optional exact request identities."""
    from read_cascode_solver_settings import effective_controls
    path = Path(path).resolve()
    if path.with_suffix('.sha256').read_text().strip() != _digest(path):
        raise ValueError('baseline bundle manifest fingerprint changed')
    bundle = read_json(path)
    if bundle.get('schema_version') != SCHEMA_VERSION or bundle.get('kind') != 'cascode-baseline-bundle':
        raise ValueError('unsupported baseline bundle schema')
    for name, expected in (('source', expected_source), ('bench', expected_bench), ('corner', corner)):
        if expected is not None and bundle[name] != expected:
            raise ValueError('baseline bundle ' + name + ' identity mismatch')
    if any(bundle.get(key) is not False for key in ('simulation_profile_ready', 'pdk_electrical_rules_ready', 'electrical_verified', 'vbias_generated')):
        raise ValueError('baseline evidence cannot claim electrical/profile readiness')
    _verify_fingerprints(bundle['file_sha256'])
    historical = bundle['historical_verified_paths']
    first_seen = bundle['first_fingerprinted_at_export_paths']
    if (not isinstance(historical, list) or not isinstance(first_seen, list)
            or historical != sorted(set(historical)) or first_seen != sorted(set(first_seen))
            or set(historical) & set(first_seen)
            or set(historical) | set(first_seen) != set(bundle['file_sha256'])
            or bundle['recursive_dependencies_historically_verified'] is not
                (set(bundle['dependency_sha256']) <= set(historical))):
        raise ValueError('invalid baseline fingerprint history scope')
    bench = Path(bundle['bench_netlist'])
    if bench.parent != path.parent or _digest(bench) != bundle['bench_sha256']:
        raise ValueError('bundle Bench path/fingerprint mismatch')
    text = bench.read_text()
    if _root_path(text, bundle['source_subckt']) != bundle['root_path']:
        raise ValueError('bundle source hierarchy mismatch')
    if effective_controls(text, bundle['selected_forms'], bundle['temperature']) != bundle['effective_controls']:
        raise ValueError('bundle effective DC controls mismatch')
    dependencies, references = _dependencies(text, bench.parent,
        bundle['definition_files'] + [model['model_file'] for model in bundle['models']])
    if dependencies != bundle['dependency_sha256'] or references != bundle['dependency_references']:
        raise ValueError('baseline dependency resolution changed')
    if _native_commands(bundle['baseline']) != bundle['launch_command_evidence']:
        raise ValueError('baseline native command evidence changed')
    if _launch_contract(bundle['selected_forms'], bundle['launch_evidence'], bundle['launch_command_evidence']) != bundle['launch_contract']:
        raise ValueError('baseline launch contract differs from saved evidence')
    return dict(bundle, _bundle_path=str(path), _bundle_sha256=_digest(path))


def _top_level_contract(text, origin):
    from op_provider import parse_deck
    deck = parse_deck(text)
    owned = {index for definition in deck['definitions'].values()
             for index in range(definition['start'], definition['end'] + 1)}
    include_refs = []
    statements = []
    for index, line in enumerate(deck['lines']):
        stripped = line.strip()
        if index in owned or not stripped or stripped.startswith('//'):
            continue
        dependency = _include(stripped, origin)
        if dependency:
            include_refs.append(dependency)
        elif re.match(r'^(?:simulator|global|parameters|save|ic|nodeset)\b', stripped):
            continue
        elif re.match(r'^\S+\s+(?:options|info|dc|tran|stb|ac|noise|pz|xf)\b', stripped):
            continue
        else:
            statements.append(' '.join(stripped.split()))
    return dict(globals=deck['globals'], parameters=deck['parameters'], includes=include_refs,
                statements=statements, top=deck['top'])


def prepare_candidate_deck(bundle, candidate_text, origin, target_subckt):
    """Bind only the explicitly named candidate DUT into the immutable Bench."""
    from op_provider import bind_dut
    current = load_bundle(bundle['_bundle_path'])
    if current != bundle:
        raise ValueError('loaded baseline bundle was modified by the caller')
    if not isinstance(target_subckt, str) or not target_subckt or re.search(r'\s', target_subckt):
        raise ValueError('an explicit candidate subckt is required')
    bench_text = Path(bundle['bench_netlist']).read_text()
    candidate = _absolute_deck(candidate_text, Path(origin))
    # bind_dut retains subcircuit bodies; includes there must be proven too.
    dependencies, references = _dependencies(candidate, Path(origin))
    if any(bundle['dependency_sha256'].get(name) != value for name, value in dependencies.items()) or any(
            reference not in bundle['dependency_references'] for reference in references):
        raise ValueError('candidate introduces an untracked dependency or model section')
    baseline_contract = _top_level_contract(bench_text, Path(bundle['bench_netlist']).parent)
    contract = _top_level_contract(candidate, Path(origin))
    if contract['top']:
        raise ValueError('candidate export must contain a wrapped DUT, not top-level instances')
    if not contract['globals'].issubset(baseline_contract['globals']):
        raise ValueError('candidate introduces a global absent from verified Bench')
    if any(baseline_contract['parameters'].get(key) != value for key, value in contract['parameters'].items()):
        raise ValueError('candidate top-level parameters differ from verified Bench')
    if any(reference not in baseline_contract['includes'] for reference in contract['includes']):
        raise ValueError('candidate introduces an include/section absent from verified Bench')
    if any(statement not in baseline_contract['statements'] for statement in contract['statements']):
        raise ValueError('candidate introduces a top-level model or unsupported statement')
    text, root = bind_dut(bench_text, candidate, bundle['source_subckt'], target_subckt)
    if root != bundle['root_path']:
        raise ValueError('candidate binding changed the verified source root path')
    load_bundle(bundle['_bundle_path'])
    return text, root
