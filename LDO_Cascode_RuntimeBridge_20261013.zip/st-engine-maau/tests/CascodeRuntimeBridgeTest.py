"""One-command saved baseline to formal reader acceptance, using process fixtures."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import io
from contextlib import redirect_stdout

import CascodeNodeContextTest as node_fixture
from CascodeSavedDcTest import ENTRY


class CascodeRuntimeBridgeTest(unittest.TestCase):
    def prepare(self,root):
        fixture=node_fixture.CascodeNodeContextTest()
        s,r,p,b,e,base,cache=fixture.fixture(root,peripheral=True)
        old=fixture.seed_v1_node_cache(s,r,p,b,e,base)
        native=root/'formal_ocean'
        native.write_text('#!'+sys.executable+'\n'+'''import csv,json,os,sys
from pathlib import Path
work=Path(sys.argv[-1]).parent
script=Path(sys.argv[-1]).read_text()
assert 'createNetlist(' not in script and 'run()' not in script
source=Path(os.environ['OP_SOURCE']);nodesource=Path(os.environ['NODE_SOURCE'])
(work/'ops.tsv').write_bytes(source.read_bytes())
with nodesource.open() as f:rows=[r for r in csv.DictReader(f,delimiter='\\t') if r['status']=='OK']
if os.environ.get('WRONG_SIGN'):
 text=(work/'ops.tsv').read_text().replace('-1e-06','1e-06');(work/'ops.tsv').write_text(text)
with (work/'nodes.tsv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=['kind','signal','value','status'],delimiter='\\t');writer.writeheader();writer.writerows(rows)
(work/'runtime.done').write_text('OK\\n')
''');native.chmod(0o755)
        e.update(ST_OCEAN_BIN=str(native),OP_SOURCE=str(cache/'baseline_op/values.tsv'),NODE_SOURCE=str(old/'node_read/values.tsv'),
                 ST_VIRTUOSO_BIN='/do-not-read-maestro',ST_SPECTRE_BIN='/do-not-simulate')
        return s,r,p,b,e,base

    def invoke(self,s,r,p,b,e):
        return subprocess.run([sys.executable,str(ENTRY),'--session',str(s),'--maestro-read',str(r),'--preflight',str(p),
            '--batch',str(b),'--prepare-runtime'],env=e,capture_output=True,text=True)

    def test_prepares_reusable_bundle_and_formal_reader_matches_cache_without_rerun(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp));before={f:f.read_bytes() for f in base.rglob('*') if f.is_file()}
            result=self.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            for marker in ('RESULT=RUNTIME_BRIDGE_OK','RUNTIME_CACHE_MATCH=true','SPECTRE_RERUN=false','VBIAS_GENERATED=false','SIMULATION_PROFILE_READY=false'):
                self.assertIn(marker,result.stdout)
            for f,value in before.items():self.assertEqual(f.read_bytes(),value)
            out=next(base.glob('runtime_bridge_*'))
            query=json.loads((out/'query.json').read_text())
            self.assertNotIn('AGND',query['nodes'])
            self.assertFalse(any('net037' in n for n in query['nodes']))
            self.assertTrue((out/'bundle/baseline_bundle.json').exists())
            gaps=json.loads((out/'remaining_inputs.json').read_text())
            self.assertIn('supply_current_signals',gaps['profile_missing'])
            self.assertIn('max_vbias_current',gaps['profile_missing'])
            self.assertEqual(gaps['unresolved_context_nodes'],['AGND',r'net037\<0\>',r'net037\<1\>'])

    def test_wrong_formal_sign_never_passes_cache_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp));e['WRONG_SIGN']='1'
            result=self.invoke(s,r,p,b,e)
            self.assertEqual(result.returncode,2,result.stdout+result.stderr)
            self.assertIn('formal reader differs from validated cache',result.stdout)
            self.assertNotIn('RUNTIME_CACHE_MATCH=true',result.stdout)

    def test_bundle_dependency_error_retains_formal_read_acceptance_and_all_gaps(self):
        with tempfile.TemporaryDirectory() as tmp:
            s,r,p,b,e,base=self.prepare(Path(tmp))
            sys.path.insert(0,str(ENTRY.parent))
            import runtime_bridge
            args=SimpleNamespace(session=str(s),maestro_read=str(r),preflight=str(p),batch=str(b),timeout=30)
            stream=io.StringIO()
            # Native read runs normally; isolate the export error boundary.
            with patch.dict(os.environ,e),patch('baseline_bundle.export_bundle',side_effect=ValueError('missing baseline dependency: constants.vams')),redirect_stdout(stream):
                code=runtime_bridge.prepare_runtime(args)
            self.assertEqual(code,2)
            self.assertIn('RESULT=READER_OK_BUNDLE_INCOMPLETE',stream.getvalue())
            self.assertIn('RUNTIME_CACHE_MATCH=true',stream.getvalue())
            out=next(base.glob('runtime_bridge_*'))
            self.assertTrue((out/'remaining_inputs.json').exists())
            self.assertTrue((out/'comparison.json').exists())


if __name__=='__main__':unittest.main()
