"""Immutable baseline/candidate contracts; no native Cadence execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
ENTRY = ROOT / 'server/site/baseline_bundle.py'
sys.path.insert(0, str(ENTRY.parent))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class BaselineBundleTest(unittest.TestCase):
    def module(self):
        self.assertTrue(ENTRY.is_file(), 'BaselineBundle implementation is missing')
        spec = importlib.util.spec_from_file_location('baseline_bundle_under_test', ENTRY)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def fixture(self, root):
        root = root.resolve()
        baseline = root / 'session/batch/dc_review_ports_fixture'
        origin = baseline / 'baseline_generated'
        origin.mkdir(parents=True)
        shared = root / 'shared'
        shared.mkdir()
        model = shared / 'model.scs'
        leaf = shared / 'device.scs'
        leaf.write_text('model nmod bsimcmg type=n\n')
        model.write_text('section tt\ninclude "device.scs"\nendsection tt\n')
        definition = shared / 'definition.scs'
        extra = shared / 'constants.scs'
        extra.write_text('parameters EXTRA=1\n')
        definition.write_text('include "constants.scs"\n')
        ahdl = shared / 'load.va'
        header = shared / 'local.vams'
        header.write_text('`define LOCAL_CONST 1\n')
        ahdl.write_text('`include "local.vams"\nmodule load(p,n); inout p,n; endmodule\n')
        forms = [
            'analysis(\'dc ?anaName "dc" ?saveOppoint t ?oppoint "rawfile" ?maxiters "150" ?maxsteps "10000")',
            'analysis(\'tran ?stop "1u")',
            'option(\'reltol "1e-3")',
            'option(?categ \'turboOpts \'uniMode "APS" \'errorLevel "Conservative" \'mtOption "Manual" \'numThreads "4")',
            'ic("G" 0.3)',
            'nodeset("G" 0.4)',
            'temp(27)',
        ]
        deck = '''simulator lang=spectre
global 0 VSS!
parameters VIN=1.14
include "../../../../shared/model.scs" section=tt
include "../../../../shared/definition.scs"
ahdl_include "../../../../shared/load.va"
model localmod resistor r=1
subckt core D G S B
M0 (D G S B) nmod l=20n nfin=2
ends core
subckt wrap P Q R T
DUT (P Q R T) core
ends wrap
TOP (VIN G 0 0) wrap
V0 (VIN 0) vsource dc=VIN
simulatorOptions options temp=125 reltol=1e-3
dcOp dc maxiters=150 maxsteps=10000
dcOpInfo info what=oppoint where=rawfile
saveOptions options save=all currents=all subcktprobelvl=99
ic G=0.3
nodeset G=0.4
'''
        (origin / 'input.scs').write_text(deck)
        (baseline / 'baseline_run.scs').write_text(deck)
        (baseline / 'baseline_netlist.scs').write_text(deck)
        (baseline / 'saved_test.ocn').write_text('\n'.join(forms) + '\nrun()\n')
        (baseline / 'settings_forms.json').write_text(json.dumps(forms))
        (baseline / 'definition_files.txt').write_text('(' + json.dumps(str(definition)) + ')\n')
        (baseline / 'baseline_definition_hashes.json').write_text(json.dumps({str(definition): digest(definition)}))
        (baseline / 'baseline_status.json').write_text(json.dumps({'converged': True}))
        work = baseline / 'baseline_run'
        work.mkdir()
        (work / 'runtime.done').write_text('OK\n')
        (work / 'ocean.log').write_text('Command line: spectre +aps=conservative +mt=4 input.scs\n')
        psf = baseline / 'baseline_results/psf'
        psf.mkdir(parents=True)
        (psf / 'dcOp.dc').write_text('fixture nodes')
        (psf / 'dcOpInfo.info').write_text('fixture OP')
        session = baseline.parent.parent
        (session / 'session.conf').write_text('source_library=LIB\nsource_cell=core\nsource_view=schematic\n')
        cds = root / 'cds.lib'
        cds.write_text('DEFINE LIB /fixture/oa\n')
        fixed = [p for p in baseline.rglob('*') if p.is_file()] + [session / 'session.conf', cds]
        bound = {
            'session': session,
            'cfg': {'source_library': 'LIB', 'source_cell': 'core', 'source_view': 'schematic'},
            'cds': cds,
            'fixed': {str(p): digest(p) for p in fixed},
            'settings': {'design': {'lib': 'BENCH', 'cell': 'tb', 'view': 'config_presim'},
                         'test_name': 'saved_dc', 'corner': 'Copy_PT_FUNC_703', 'temperature': 125.0,
                         'variables': {'VIN': '1.14'},
                         'models': [{'model_file': str(model), 'section_name': 'tt', 'sha256': digest(model)}]},
            'data': {'selection': {'bench_library': 'BENCH', 'bench_cell': 'maestro_tb', 'setup_view': 'maestro'}},
        }
        return bound, baseline, root / 'bundle', {'model': model, 'leaf': leaf, 'definition': definition,
                                                 'extra': extra, 'ahdl': ahdl, 'header': header, 'psf': psf}

    def export(self, root):
        module = self.module()
        bound, baseline, output, paths = self.fixture(root)
        manifest = module.export_bundle(bound, baseline, output)
        return module, module.load_bundle(manifest), manifest, bound, baseline, paths

    def test_exports_fixed_config_dc_and_recursive_dependencies_without_mutating_inputs(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, paths = self.fixture(Path(tmp))
            before = {p: p.read_bytes() for p in Path(tmp).rglob('*') if p.is_file()}
            manifest = module.export_bundle(bound, baseline, output)
            bundle = module.load_bundle(manifest, expected_source={'lib': 'LIB', 'cell': 'core', 'view': 'schematic'},
                                        expected_bench=bound['settings']['design'], corner='Copy_PT_FUNC_703')
            self.assertEqual(bundle['root_path'], 'TOP.DUT')
            self.assertEqual(bundle['source_subckt'], 'core')
            self.assertEqual(bundle['bench']['view'], 'config_presim')
            self.assertEqual(bundle['launch_contract']['argv'], ['+aps=conservative', '+mt=4'])
            self.assertEqual(bundle['variables'], {'VIN': '1.14'})
            self.assertEqual(bundle['maestro']['view'], 'maestro')
            for name in ('model', 'leaf', 'definition', 'extra', 'ahdl', 'header'):
                self.assertEqual(bundle['file_sha256'][str(paths[name])], digest(paths[name]))
            self.assertFalse(bundle['simulation_profile_ready'])
            self.assertFalse(bundle['pdk_electrical_rules_ready'])
            text = Path(bundle['bench_netlist']).read_text()
            self.assertIn('include ' + json.dumps(str(paths['model'])) + ' section=tt', text)
            self.assertIn('dcOp dc maxiters=150 maxsteps=10000', text)
            self.assertIn('ic G=0.3\nnodeset G=0.4', text)
            for path, content in before.items():
                self.assertEqual(path.read_bytes(), content)

    def test_load_rejects_source_bench_and_corner_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, path, *_ = self.export(Path(tmp))
            for kwargs in ({'expected_source': {'lib': 'WRONG', 'cell': 'core', 'view': 'schematic'}},
                           {'expected_bench': {'lib': 'BENCH', 'cell': 'tb', 'view': 'schematic'}},
                           {'corner': 'other'}):
                with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                    module.load_bundle(path, **kwargs)

    def test_load_rejects_changed_fixed_recursive_dependency_psf_or_bundle_deck(self):
        for key in ('model', 'leaf', 'definition', 'extra', 'ahdl', 'header', 'fixed', 'psf', 'deck'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                module, bundle, manifest, bound, baseline, paths = self.export(Path(tmp))
                path = (bound['session'] / 'session.conf' if key == 'fixed' else
                        paths['psf'] / 'dcOp.dc' if key == 'psf' else
                        Path(bundle['bench_netlist']) if key == 'deck' else paths[key])
                path.write_text(path.read_text() + '\nchanged\n')
                with self.assertRaises(ValueError):
                    module.load_bundle(manifest)

    def test_manifest_content_is_hash_bound(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, _, manifest, *_ = self.export(Path(tmp))
            value = json.loads(manifest.read_text())
            value['temperature'] = 27
            manifest.write_text(json.dumps(value))
            with self.assertRaises(ValueError):
                module.load_bundle(manifest)

    def test_export_rejects_drift_before_creating_a_bundle(self):
        for key in ('fixed', 'model', 'definition'):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                target = bound['session'] / 'session.conf' if key == 'fixed' else paths[key]
                target.write_text(target.read_text() + '\nchanged\n')
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output)
                self.assertFalse(output.exists())

    def test_unresolved_and_nonliteral_dependency_is_rejected(self):
        for include in ('include "missing.scs"', 'include dynamic_path',
                        'include "$UNDEFINED_BASELINE_BUNDLE_TEST/model.scs"',
                        '`include "missing.vams"'):
            with self.subTest(include=include), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                paths['leaf'].write_text(include + '\n')
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output)

    def test_unsupported_launch_or_missing_effective_controls_is_rejected(self):
        for mode in ('classic', 'threads', 'controls', 'launch'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                if mode in ('classic', 'threads'):
                    replacement = ('"APS"', '"Spectre"') if mode == 'classic' else ('"4"', '"4;evil"')
                    for name in ('settings_forms.json', 'saved_test.ocn'):
                        p = baseline / name
                        p.write_text(p.read_text().replace(*replacement))
                        bound['fixed'][str(p)] = digest(p)
                elif mode == 'controls':
                    for p in (baseline / 'baseline_run.scs', baseline / 'baseline_generated/input.scs'):
                        p.write_text(p.read_text().replace('maxiters=150', 'maxiters=2'))
                        bound['fixed'][str(p)] = digest(p)
                else:
                    p = baseline / 'baseline_run/ocean.log'
                    p.write_text('Command line: spectre input.scs\n')
                    bound['fixed'][str(p)] = digest(p)
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output)

    def test_candidate_replaces_only_dut_and_preserves_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            candidate = '''simulator lang=spectre
subckt candidate D G S B
M0 (D G S B) nmod l=20n nfin=3
ends candidate
'''
            text, root = module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')
            self.assertEqual(root, 'TOP.DUT')
            self.assertIn('DUT (P Q R T) candidate', text)
            self.assertIn('M0 (D G S B) nmod l=20n nfin=3', text)
            for line in ('V0 (VIN 0) vsource dc=VIN', 'simulatorOptions options temp=125 reltol=1e-3',
                         'dcOp dc maxiters=150 maxsteps=10000', 'ic G=0.3', 'nodeset G=0.4'):
                self.assertIn(line, text)

    def test_candidate_top_level_changes_cannot_be_silently_dropped(self):
        for extra in ('include "candidate_only.scs"', 'global NEW_GLOBAL', 'parameters VIN=2',
                      'model localmod resistor r=2', 'model unseen resistor r=2'):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                module, bundle, _, *_ = self.export(root)
                (root / 'candidate_only.scs').write_text('model added resistor r=1\n')
                candidate = 'simulator lang=spectre\n' + extra + '\nsubckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\n'
                with self.assertRaises(ValueError):
                    module.prepare_candidate_deck(bundle, candidate, root, 'candidate')

    def test_candidate_port_and_shared_definition_drift_is_rejected(self):
        for candidate in ('subckt candidate G D S B\nM0 (D G S B) nmod\nends candidate\n',
                          'subckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\nsubckt wrap P Q R T\nDUT (Q P R T) core\nends wrap\n'):
            with self.subTest(candidate=candidate), tempfile.TemporaryDirectory() as tmp:
                module, bundle, _, *_ = self.export(Path(tmp))
                with self.assertRaises(ValueError):
                    module.prepare_candidate_deck(bundle, 'simulator lang=spectre\n' + candidate, Path(tmp), 'candidate')

    def test_candidate_rechecks_bundle_files_and_rejects_mutated_loaded_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, _, _, paths = self.export(Path(tmp))
            candidate = 'simulator lang=spectre\nsubckt candidate D G S B\nM0 (D G S B) nmod\nends candidate\n'
            changed = dict(bundle, root_path='WRONG')
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(changed, candidate, Path(tmp), 'candidate')
            paths['leaf'].write_text('model changed resistor r=1\n')
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')

    def test_existing_output_is_never_overwritten(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            output.mkdir()
            (output / 'keep').write_text('untouched')
            with self.assertRaises(ValueError):
                module.export_bundle(bound, baseline, output)
            self.assertEqual((output / 'keep').read_text(), 'untouched')

    def test_extra_launch_flags_require_saved_values_and_matching_native_evidence(self):
        for proven in (False, True):
            with self.subTest(proven=proven), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, _ = self.fixture(Path(tmp))
                forms = json.loads((baseline / 'settings_forms.json').read_text())
                forms += ['envOption(\'licQueueTimeOut "900")', 'option(\'maxwarns "5" \'maxnotes "7")']
                (baseline / 'settings_forms.json').write_text(json.dumps(forms))
                (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
                log = baseline / 'baseline_run/ocean.log'
                if proven:
                    log.write_text('Command line: spectre +aps=conservative +mt=4 +lqtimeout 900 -maxw 5 -maxn 7 input.scs\n')
                for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                    p = baseline / name
                    bound['fixed'][str(p)] = digest(p)
                bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
                contract = bundle['launch_contract']
                self.assertEqual(contract['complete'], proven)
                if proven:
                    self.assertEqual(contract['argv'], ['+aps=conservative', '+mt=4', '+lqtimeout', '900', '-maxw', '5', '-maxn', '7'])
                    self.assertEqual(contract['omitted_launch_options'], [])
                else:
                    self.assertEqual({item['name'] for item in contract['omitted_launch_options']}, {'licQueueTimeOut', 'maxwarns', 'maxnotes'})

    def test_multiple_sections_of_same_model_are_preserved(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, paths = self.fixture(Path(tmp))
            bound['settings']['models'].append(dict(bound['settings']['models'][0], section_name='pre'))
            for name in ('baseline_run.scs', 'baseline_generated/input.scs'):
                p = baseline / name
                p.write_text(p.read_text().replace('section=tt', 'section=tt\ninclude "../../../../shared/model.scs" section=pre'))
                bound['fixed'][str(p)] = digest(p)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
            self.assertEqual([m['section_name'] for m in bundle['models']], ['tt', 'pre'])

    def test_extended_native_turbo_settings_are_preserved_without_claiming_full_launch_replay(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms[3] = forms[3][:-1] + ' \'cktpreset "None" \'digitalspeed "2" \'dcOPSolver "APS" \'disableVddOverride t \'optvdd "3.3" \'psrOption "Default" \'psrXpsmsOption "Default" \'preserveOption "None" \'rfmtOption "Disable")'
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            for name in ('settings_forms.json', 'saved_test.ocn'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
            self.assertEqual(bundle['launch_contract']['saved_turbo_options']['dcOPSolver'], 'APS')
            self.assertEqual(bundle['launch_contract']['saved_turbo_options']['disableVddOverride'], 't')
            self.assertFalse(bundle['launch_contract']['complete'])
            self.assertIn('cktpreset', {item['name'] for item in bundle['launch_contract']['omitted_launch_options']})

    def test_saved_extra_launch_flags_are_verified_from_full_multiline_native_command(self):
        module = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms += ['envOption(\'licQueueTimeOut "900")', 'option(\'maxwarns "5" \'maxnotes "7")']
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            (baseline / 'baseline_run/ocean.log').write_text('Command line:\n    spectre input.scs +escchars \\\n    +aps=conservative +mt=4 \\\n    +lqtimeout 900 -maxw 5 -maxn 7\n\nSimulator ready\n')
            for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
            self.assertTrue(bundle['launch_contract']['complete'])
            self.assertIn('+lqtimeout', bundle['launch_contract']['argv'])
            self.assertIn('-maxn', bundle['launch_contract']['argv'])

    def test_candidate_cannot_add_untracked_include_inside_subcircuit(self):
        with tempfile.TemporaryDirectory() as tmp:
            module, bundle, _, *_ = self.export(Path(tmp))
            (Path(tmp) / 'other.scs').write_text('model another resistor r=2\n')
            candidate = 'simulator lang=spectre\nsubckt candidate D G S B\ninclude "other.scs"\nM0 (D G S B) nmod\nends candidate\n'
            with self.assertRaises(ValueError):
                module.prepare_candidate_deck(bundle, candidate, Path(tmp), 'candidate')

    def test_exact_native_aps_variant_is_preserved_and_conflicting_flags_are_rejected(self):
        for flags in ('++aps=conservative +mt=4', '+aps=conservative +mt=4 +mt=8'):
            with self.subTest(flags=flags), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, _ = self.fixture(Path(tmp))
                log = baseline / 'baseline_run/ocean.log'
                log.write_text('Command line: spectre ' + flags + ' input.scs\n')
                bound['fixed'][str(log)] = digest(log)
                if flags.startswith('++'):
                    bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
                    self.assertEqual(bundle['launch_contract']['argv'][0], '++aps=conservative')
                else:
                    with self.assertRaises(ValueError):
                        module.export_bundle(bound, baseline, output)

    def test_ambiguous_extra_launch_flags_and_unproven_environment_are_explicitly_omitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self.module()
            bound, baseline, output, _ = self.fixture(Path(tmp))
            forms = json.loads((baseline / 'settings_forms.json').read_text())
            forms += ['envOption(\'licQueueTimeOut "900" \'customRunMode "saved")']
            (baseline / 'settings_forms.json').write_text(json.dumps(forms))
            (baseline / 'saved_test.ocn').write_text('\n'.join(forms))
            (baseline / 'baseline_run/ocean.log').write_text('Command line: spectre +aps=conservative +mt=4 +lqtimeout 900 +lqtimeout 10 input.scs\n')
            for name in ('settings_forms.json', 'saved_test.ocn', 'baseline_run/ocean.log'):
                bound['fixed'][str(baseline / name)] = digest(baseline / name)
            bundle = module.load_bundle(module.export_bundle(bound, baseline, output))
            contract = bundle['launch_contract']
            self.assertFalse(contract['complete'])
            self.assertNotIn('+lqtimeout', contract['argv'])
            self.assertEqual({item['name'] for item in contract['omitted_launch_options']}, {'licQueueTimeOut', 'customRunMode'})

    def test_bundle_retains_pinned_hashes_and_distinguishes_new_dependency_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            module = self.module()
            bound, baseline, output, paths = self.fixture(Path(tmp))
            pinned = baseline.parent.parent / 'pinned_init.il'
            pinned.write_text('; original pinned initialization\n')
            bound['pinned'] = {'file_sha256': {str(pinned): digest(pinned)}}
            manifest = module.export_bundle(bound, baseline, output)
            bundle = module.load_bundle(manifest)
            self.assertEqual(bundle['file_sha256'][str(pinned)], digest(pinned))
            historical = set(bundle['historical_verified_paths'])
            first_seen = set(bundle['first_fingerprinted_at_export_paths'])
            self.assertIn(str(pinned), historical)
            self.assertIn(str(paths['model']), historical)
            self.assertIn(str(paths['definition']), historical)
            self.assertIn(str(paths['leaf']), first_seen)
            self.assertIn(str(paths['header']), first_seen)
            self.assertNotIn(str(paths['leaf']), historical)
            self.assertFalse(historical & first_seen)
            self.assertEqual(historical | first_seen, set(bundle['file_sha256']))
            self.assertFalse(bundle['recursive_dependencies_historically_verified'])
            pinned.write_text('; changed after bundle export\n')
            with self.assertRaises(ValueError):
                module.load_bundle(manifest)

    def test_stale_or_conflicting_pinned_fingerprints_are_not_recomputed(self):
        for mode in ('stale', 'conflicting_fixed', 'conflicting_model'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                module = self.module()
                bound, baseline, output, paths = self.fixture(Path(tmp))
                pinned = baseline.parent.parent / 'pinned_init.il'
                pinned.write_text('; original pinned initialization\n')
                old_hash = digest(pinned)
                bound['pinned'] = {'file_sha256': {str(pinned): old_hash}}
                if mode == 'stale':
                    pinned.write_text('; drift before export\n')
                elif mode == 'conflicting_fixed':
                    bound['fixed'][str(pinned)] = '0' * 64
                else:
                    bound['pinned']['file_sha256'][str(paths['model'])] = '0' * 64
                with self.assertRaises(ValueError):
                    module.export_bundle(bound, baseline, output)
                self.assertFalse(output.exists())


if __name__ == '__main__':
    unittest.main()
