同一张电路：四组 Cascode -> 撤回一组 -> 再撤回一组

适用：已有 candidate_I21_xbb892w0/work，会话为 experimental_dc；在此前最终 Cell 续跑补丁基础上更新。
在 /tmpdata/maau_epc/users/k00981589 执行。沿用当前 $st_batch，无须切换 Bash/csh；下面用 bash 显式运行脚本。

最终测试安排（四个不同原 MOS）：
01 同型 NMOS，优先 I21，最终保留。
02 异型 PMOS，优先 I105，最终保留。
03 同型 PMOS，自动选择另一只已有合格绑定的 PMOS，第二次撤销。
04 异型 NMOS，自动选择另一只已有合格绑定的 NMOS，第一次撤销。
异型 = 同极性、不同真实 OA Master。不是 NMOS 换 PMOS，不用原型号冒充。
若 I21/I105 无法满足对应角色，自动在已有合格目录中选择其它实例；实际选择由 OPERATION_INDEX 行给出。

1. 上传更新包到上述目录，解压并编译（只执行一次）：

unzip -o ldo_multi_cascode_test_20261016.zip && bash st-engine-maau/scripts/build.sh --tool-only

预期：built tool only: .../st-engine-maau/build/bin/st_circuit_tool

2. 生成四组：

bash st-engine-maau/scripts/test_mixed_cascode.sh four "$st_batch/candidate_I21_xbb892w0"

这一步先自动准备四个操作，成功后清空当前逻辑操作清单并按 01、02、03、04 确认；从原图生成四组。
原始 OA 不修改；以前生成的结果 Cell 仍存在。
不会重新 inspect，也不要求用户填阻值、端子或器件型号。
预期先看到：
MIXED_FOUR_READY=true
OPERATION_COUNT=4
ACTIVE_GROUPS=4
随后逐组自动搜索 VBIAS，最后联合验证生成图。
成功结束时：
RESULT=EXPERIMENT_DC_PASS
EXPERIMENTAL_DC_READY=true
TEST_GROUPS=4
GENERATED_SUBCELLS=8
RESULT_CELL=.../schematic
MIXED_CASCODE_TEST=PASS
8 个子 Cell 是每组一个 Cascode 功能封装加一个 VBIAS 子电路；四组都在同一张最终父图内。

3. 撤销第四组（异型 NMOS），重新生成三组：

bash st-engine-maau/scripts/test_mixed_cascode.sh three "$st_batch/candidate_I21_xbb892w0"

内部实际执行一次 standalone.py undo，随后按当前三项操作生成。
预期：
已撤销最后一次修改，剩余操作数=3
ACTIVE_GROUPS=3
RESULT=EXPERIMENT_DC_PASS
TEST_GROUPS=3
GENERATED_SUBCELLS=6
MIXED_CASCODE_TEST=PASS

4. 撤销第三组（同型 PMOS），重新生成两组：

bash st-engine-maau/scripts/test_mixed_cascode.sh two "$st_batch/candidate_I21_xbb892w0"

内部再执行一次 undo，然后生成剩余两组。到这里停止，不再撤销 01 或 02。
预期：
已撤销最后一次修改，剩余操作数=2
ACTIVE_GROUPS=2
RESULT=EXPERIMENT_DC_PASS
TEST_GROUPS=2
GENERATED_SUBCELLS=4
MIXED_CASCODE_TEST=PASS
FINAL_RETAINED=same_type_NMOS,cross_flavor_PMOS

5. 查看最终操作列表，并打开最后两组所在的最新 Virtuoso 父图（可选）：

python3 st-engine-maau/server/site/standalone.py list --session "$st_batch/candidate_I21_xbb892w0/work"
python3 st-engine-maau/server/site/standalone.py open --session "$st_batch/candidate_I21_xbb892w0/work"

列表应显示“已确认操作: 2”，类型分别为 same_type_cascode 和 cross_flavor_cascode。
undo 改的是逻辑操作，重新生成后才得到撤销后的新 Cell；不会把已打开的旧结果图原地改掉。

如何判断结果：
- 以上 PASS 行为条件性预期，不是已在服务器测得的结论。
- 如果准备阶段显示 MIXED_FOUR_READY=false / OPERATIONS_NOT_PREPARED，当前已绑定目录不足四个目标或缺少异型型号；此时不会清空旧操作、不会跑 DC，也不能声称异型通过。只需返回该段短输出，不用重复长时间续跑或手动挑阻值。
- 如果生成显示 OPTIMIZATION_CANDIDATE_READY，说明产生了待优化电路，尚未满足最低 DC，测试脚本会返回 NOT_PASSED，不能算四组测试通过。
- 如果出现 INCOMPLETE，当前阶段未完成；不要把尚未生成的图视为撤销完成。
- three、two 必须依次各运行一次；重复或错序调用会在 undo 前停止，避免多撤一组。
- 生成失败而操作已变更时，继续同一操作集合使用：
python3 st-engine-maau/scripts/resume_cascode_experiment.py --candidate "$st_batch/candidate_I21_xbb892w0" --reuse-verified-inputs --stage-timeout 14400
该命令不会再执行 undo。不要重复运行 four 重新清空/确认，或重复运行 three/two 再撤一项。
- 当前搜索上限是每组最多 16 个候选 DC，满足即停；四组最多 64 个搜索评估，另有最终组合 DC。不是四组总共 16 点，不能按单管耗时估计全部测试。
- 按当前操作重新生成会刷新目标集合并实测，不复用旧的电气通过结论。本批不修改电气标准、不增加优化算法。
- READY_FOR_SIZING=false、RELIABILITY_VERIFIED=false、PUBLISHED=false 是当前实验模式边界。

本地验证：实际 C++ CLI 编排 + 替身宿主测试覆盖 NMOS/PMOS 同型与异型、四组混合、4->3->2、原连接恢复；Python覆盖操作选择和服务器脚本命令。替身输出不等于真实 PDK/Spectre 通过。真实四组及撤销后的 DC 由上述服务器命令验证。
