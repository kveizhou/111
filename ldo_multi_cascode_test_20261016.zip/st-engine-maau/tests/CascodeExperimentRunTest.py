"""Continuation contracts; subprocess fixtures are not Cadence validation."""
import contextlib
import importlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server/site'))


class RunTest(unittest.TestCase):
    def module(self):
        return importlib.import_module('run_cascode_experiment')

    def test_tool_only_build_does_not_compile_all_test_programs(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            for d in ('scripts', 'server', 'server/bin', 'server/site', 'tests', 'src'):
                (root/d).mkdir(parents=True, exist_ok=True)
            for d in ('scripts', 'server', 'server/bin'):
                (root/d/'dummy.sh').touch()
            (root/'server/site/dummy.py').touch()
            (root/'tests/ServerBackendContractTest.sh').touch()
            shutil.copyfile(ROOT/'scripts/build.sh', root/'scripts/build.sh')
            compiler = root/'compiler'
            compiler.write_text('#!/bin/sh\necho call >> "$COUNT_FILE"\n')
            compiler.chmod(0o755)
            env = dict(os.environ, CXX=str(compiler), COUNT_FILE=str(root/'count'))
            env.pop('ST_BUILD_DIR', None)
            done = subprocess.run(['bash', str(root/'scripts/build.sh'), '--tool-only'], env=env, capture_output=True)
            self.assertEqual(done.returncode, 0, done.stderr)
            self.assertEqual((root/'count').read_text().splitlines(), ['call'])

    def config(self, root):
        return dict(source={'lib':'original', 'cell':'core', 'view':'schematic'},
            bench={'lib':'benches', 'cell':'saved', 'view':'config'},
            cds_lib=str(root/'old/cds.lib'), core_subckt='core', target='I21',
            profile=str(root/'binding/simulation_profile.json'),
            rules=str(root/'binding/pdk_facts.json'), init=str(root/'original_init.il'))

    def test_commands_keep_original_source_and_use_distinct_session_and_library(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as name:
            root=Path(name); output=root/'new'; output.mkdir()
            commands=m.make_commands(self.config(root), output)
            inspect=commands[1][1]; opts=dict(zip(inspect[3::2],inspect[4::2]))
            self.assertEqual(commands[1][0], 'inspect')
            self.assertEqual(opts['--validation-scope'], 'experimental_dc')
            self.assertEqual(opts['--lib'], 'original')
            self.assertEqual(opts['--bench-view'], 'config')
            self.assertEqual(Path(opts['--work-dir']), (output/'work').resolve())
            self.assertNotEqual(opts['--cds-lib'], self.config(root)['cds_lib'])
            self.assertNotEqual(opts['--variant-lib'], 'original')
            self.assertEqual([c[0] for c in commands], ['prepare', 'inspect', 'confirm', 'generate'])
            self.assertIn('instance=I21\n', (output/'operation.conf').read_text())

    def test_pipeline_stops_after_failed_inspect_without_confirm_or_generate(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name:
            out=Path(name);calls=[]
            def runner(stage, argv, output, timeout, env=None):
                calls.append(stage)
                if stage=='inspect': raise m.StageFailure(stage, 3, output/'inspect.log')
            with self.assertRaises(m.StageFailure):
                m.execute(self.config(out),out,10,runner=runner)
            self.assertEqual(calls,['prepare','inspect'])

    def test_exit_zero_without_experimental_report_is_not_success(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            with self.assertRaises((ValueError, OSError)):
                m.execute(self.config(out),out,10,runner=lambda *a,**kw:None)

    def test_first_generate_automatically_supplies_trials_without_user_choice(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name:
            out=Path(name);commands=[]
            def runner(stage,argv,output,timeout,env=None):
                commands.append((stage,argv))
                if stage=='generate':
                    self.assertIn('--experimental-resistor-auto',argv)
                    self.assertIn('--experimental-resistor-trials',argv)
                    raise m.StageFailure(stage,4,out/'generate.log')
            with patch.object(m,'read_json',return_value={}), \
                 patch('experimental_pdk.resistor_trial_file',return_value=out/'trials.tsv') as table, \
                 self.assertRaises(m.StageFailure):
                m.execute(self.config(out),out,10,runner=runner)
            self.assertEqual([s for s,a in commands],['prepare','inspect','confirm','generate'])
            self.assertIsNone(table.call_args.args[-1])

    def test_selected_point_summary_is_not_last_trial(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()) as output:
            work=Path(name);(work/'analysis').mkdir()
            rows=[dict(candidate=i,selected=i==2,kept=False,converged=True,reason='saturation',
                  constraints={'saturation':False},params={'resistor':{'r':str(i*10000)}},
                  stress_measurements={'vbias':i*0.1}) for i in (1,2,3)]
            (work/'analysis/solver_trace.jsonl').write_text('\n'.join(json.dumps(row) for row in rows))
            m.print_solver_result(work,compact=True)
            self.assertIn('SELECTED_POINT=2',output.getvalue())
            self.assertIn('SELECTED_VBIAS=0.2',output.getvalue())
            self.assertIn('SELECTED_PARAMETERS={"resistor": {"r": "20000"}}',output.getvalue())
            self.assertNotIn('SOLVER_LAST_',output.getvalue())

    def test_candidate_flags_require_measured_dc_and_do_not_promote_to_pass(self):
        m=self.module()
        report=dict(ok='true',validation_scope='experimental_dc',experimental_dc_ready='false',
                    optimization_candidate_ready='true',nominal_dc_ready='true',failed_constraints='op1/saturation',
                    ready_for_sizing='false',reliability_verified='false',published='false',structural_ready='true',
                    parameters_quantized='false',stage='complete',target='X__STAGING/Y/schematic')
        self.assertEqual(m.completion_status(report)['result'],'OPTIMIZATION_CANDIDATE_READY')
        for change in ({'experimental_dc_ready':'true'},{'nominal_dc_ready':'false'},
                       {'failed_constraints':''},{'optimization_candidate_ready':'false'}):
            with self.subTest(change=change),self.assertRaises(ValueError):
                m.completion_status(dict(report,**change))

    def test_ready_requires_staging_and_all_experimental_flags(self):
        m=self.module()
        good=dict(ok='true',validation_scope='experimental_dc',experimental_dc_ready='true',
            ready_for_sizing='false',reliability_verified='false',published='false',
            target='experiment__STAGING/cell/schematic',stage='complete',structural_ready='true',
            parameters_quantized='false')
        self.assertTrue(m.validate_result(good))
        for key, value in [('published','true'),('ready_for_sizing','true'),('ok','false'),
                           ('experimental_dc_ready','false'),('target','original/core/schematic')]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                m.validate_result(dict(good,**{key:value}))

    def test_timeout_terminates_stage_and_keeps_log(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
            out=Path(name)
            with self.assertRaises(m.StageFailure):
                m.run_stage('slow',[sys.executable,'-u','-c','import time; print("started"); time.sleep(30)'],out,0.1)
            self.assertIn('started',(out/'slow.log').read_text())

    def test_generate_surfaces_reuse_summary_on_success_and_failure(self):
        m=self.module()
        for code in (0, 4):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as name:
                output=io.StringIO()
                command=[sys.executable,'-c',
                    'print("large callback detail"); print("CANDIDATE_OA_MODE=UPDATE point=2"); '
                    'print("CANDIDATE_READBACK_CELLS=1"); raise SystemExit('+str(code)+')']
                with contextlib.redirect_stdout(output):
                    if code:
                        with self.assertRaises(m.StageFailure): m.run_stage('generate',command,name,10)
                    else: m.run_stage('generate',command,name,10)
                self.assertIn('CANDIDATE_OA_MODE=UPDATE point=2',output.getvalue())
                self.assertIn('CANDIDATE_READBACK_CELLS=1',output.getvalue())
                self.assertNotIn('large callback detail',output.getvalue())

    def test_binding_to_runner_uses_real_metadata_and_rejects_drift(self):
        import ExperimentBindingResumeTest as fixtures
        import experiment_bindings
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
            root=Path(name).resolve()
            out,old,session,batch,bridge,bundle,pdk,profile,rules,report,request,node,origins=fixtures.ResumeTest().make_case(root)
            bundle.update(bench=dict(lib='TB',cell='test',view='config'),corner='C',temperature=125,variables={},models=[])
            profile.update(nominal_corner='C',op_corners={'C':dict(temperature=125,variables={},models=[])},
                validated_baseline_bundle=str(bridge/'bundle/baseline_bundle.json'))
            profile['experimental_pdk_cache']['source_dut']=bundle['source']
            (session/'session.conf').write_text('source_library=USER\nsource_cell=core\nsource_view=schematic\ncore_subckt=core\n')
            with patch('experiment_bindings.cached_binding_context',return_value=(request,node,origins,{})):
                self.assertEqual(experiment_bindings.bind(out,session,batch,bridge,bundle,pdk,profile,rules,report,10,reuse_dir=old),0)
            cache=(bridge,bundle,pdk,[],[],{},[],report['source_cache_sha256'])
            with patch.object(m,'cached_inputs',return_value=cache):
                config=m.load_inputs(session,batch,'I21')
                self.assertEqual(config['source'],bundle['source'])
                self.assertEqual(config['bench']['view'],'config')
                rules_file=out/'pdk_facts.json'; original_rules=rules_file.read_text()
                changed=json.loads(original_rules)
                changed['devices']['PDK/opaque_a']['bulkRule']='isolated_well'
                rules_file.write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError,'metadata preview'):
                    m.load_inputs(session,batch,'I21')
                rules_file.write_text(original_rules)
                evidence=out/'binding_evidence.json';original_evidence=evidence.read_text()
                changed=json.loads(original_evidence);changed['experiment_inputs_ready']=False
                evidence.write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError,'latest binding'):
                    m.load_inputs(session,batch,'I21')
                evidence.write_text(original_evidence)
                (out/'I21_model_type.txt').write_text('changed')
                with self.assertRaisesRegex(ValueError,'evidence changed'):
                    m.load_inputs(session,batch,'I21')

    def test_preserved_primitive_remains_in_simulation_but_is_not_selectable(self):
        from experimental_pdk import preserved_primitives
        rows=[dict(oa_library='PDK',oa_cell='untouched',model_name='opaque',terminal_names='A,B',has_schematic='false')]
        result=preserved_primitives({'PDK/untouched':rows}, set(), 'probe.tsv')
        self.assertEqual(result[0]['model'],'opaque')
        self.assertEqual(preserved_primitives({'PDK/untouched':rows}, {'PDK/untouched'}, 'probe.tsv'),[])
        for changed in (dict(rows[0],has_schematic='true'),dict(rows[0],model_name='different')):
            self.assertEqual(preserved_primitives({'PDK/untouched':rows+[changed]},set(),'probe.tsv'),[])

    def operation_fixture(self, work):
        (work/'before').mkdir();(work/'analysis').mkdir();(work/'changes').mkdir()
        (work/'session.conf').write_text('validation_scope=experimental_dc\n')
        (work/'changes/0001.conf').write_text('id=old\ninstance=I21\n')
        (work/'before/mos_inventory.tsv').write_text(
            'instance\tpolarity\tmaster\tdrain\tgate\tsource\tbulk\tcross_flavor_candidates\n'
            'I21\tmos_n\tN\tD1\tG1\tS1\tAGND\tN_ALT\n'
            'I105\tmos_p\tP\tD2\tG2\tS2\tPVDD\tP_ALT\n')
        devices=[dict(master=name,kind=kind,oa_library='PDK',oa_cell=name,
                      bulk_rule_complete=True,isolated_well=False,voltage_domain='')
                 for name,kind in [('N','mos_n'),('N_ALT','mos_n'),('P','mos_p'),('P_ALT','mos_p')]]
        (work/'analysis/pdk_catalog.json').write_text(json.dumps(dict(devices=devices)))
        return devices

    def test_prepares_two_mos_operations_without_editing_active_changes_or_bias(self):
        m=self.module()
        for kind in ('same_type_cascode','cross_flavor_cascode'):
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
                work=Path(name);self.operation_fixture(work)
                before={p:p.read_bytes() for p in work.rglob('*') if p.is_file()}
                folder=m.prepare_operations(work,['I21','I105'],kind)
                n=m.pairs(folder/'I21.conf');p=m.pairs(folder/'I105.conf')
                self.assertEqual(n['instance'],'I21');self.assertEqual(p['instance'],'I105')
                self.assertEqual(n['nmos_bulk_net'],'AGND')
                self.assertEqual(p['tie_isolated_pmos_to_source'],'false')
                self.assertEqual(n['gate_policy'],'fixed')
                self.assertNotIn('bias.voltage',n);self.assertNotIn('resistor.value',n)
                if kind=='cross_flavor_cascode':
                    self.assertEqual(n['new_master'],'N_ALT');self.assertEqual(p['new_master'],'P_ALT')
                else:self.assertNotIn('new_master',n)
                self.assertTrue(all(p.read_bytes()==data for p,data in before.items()))

    def test_missing_cross_master_or_bad_identity_never_falls_back_to_same_type(self):
        m=self.module()
        for mode in ('no_alternative','opposite','same_oa','missing_bulk','duplicate_target'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
                work=Path(name);devices=self.operation_fixture(work);targets=['I21','I105']
                if mode=='no_alternative':
                    inv=work/'before/mos_inventory.tsv';inv.write_text(inv.read_text().replace('\tP_ALT\n','\t\n'))
                if mode=='opposite':devices[1]['kind']='mos_p'
                if mode=='same_oa':devices[1]['oa_cell']='N'
                if mode=='missing_bulk':devices[1]['bulk_rule_complete']=False
                if mode=='duplicate_target':targets=['I21','I21']
                (work/'analysis/pdk_catalog.json').write_text(json.dumps(dict(devices=devices)))
                with self.assertRaises(ValueError):m.prepare_operations(work,targets,'cross_flavor_cascode')
                self.assertFalse((work/'test_operations').exists())

    def test_multi_operation_summary_does_not_present_first_selection_as_the_whole_result(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()) as output:
            work=Path(name);(work/'analysis').mkdir()
            (work/'analysis/solver_trace.jsonl').write_text('\n'.join(json.dumps(dict(candidate=1,
                selected=True,kept=True,converged=True,constraints={},params={},stress_measurements={})) for _ in range(2)))
            ops=[dict(operation='op_'+target,type='same_type_cascode',status='solved',selection={'candidate':1})
                 for target in ('I21','I105')]
            (work/'analysis/resolved_parameters.json').write_text(json.dumps(dict(operations=ops)))
            m.print_solver_result(work,compact=True)
            text=output.getvalue()
            self.assertIn('SOLVER_OPERATION_COUNT=2',text)
            self.assertEqual(text.count('OPERATION_SELECTION '),2)
            self.assertNotIn('SELECTED_POINT=',text)

    def test_mixed_four_prepares_distinct_targets_in_undo_order(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()) as output:
            work=Path(name);self.operation_fixture(work)
            with (work/'before/mos_inventory.tsv').open('a') as stream:
                stream.write('I22\tmos_n\tN\tD3\tG3\tS3\tAGND\tN_ALT\n'
                             'I106\tmos_p\tP\tD4\tG4\tS4\tPVDD\tP_ALT\n')
            original=(work/'changes/0001.conf').read_bytes()
            folder=m.prepare_mixed_four(work)
            ops=[m.pairs(folder/(str(i).zfill(2)+'.conf')) for i in range(1,5)]
            self.assertEqual([o['instance'] for o in ops],['I21','I105','I106','I22'])
            self.assertEqual([o['type'] for o in ops],['same_type_cascode','cross_flavor_cascode']*2)
            self.assertEqual([o.get('new_master') for o in ops],[None,'P_ALT',None,'N_ALT'])
            self.assertEqual((work/'changes/0001.conf').read_bytes(),original)
            self.assertIn('RETAINED_OPERATIONS=1,2',output.getvalue())

    def test_mixed_four_does_not_duplicate_targets_or_fake_missing_flavor(self):
        m=self.module()
        for extra in (False,True):
            with tempfile.TemporaryDirectory() as name,contextlib.redirect_stdout(io.StringIO()):
                work=Path(name);self.operation_fixture(work)
                if extra:
                    inv=work/'before/mos_inventory.tsv'
                    inv.write_text(inv.read_text().replace('\tP_ALT\n','\t\n')+
                        'I22\tmos_n\tN\tD3\tG3\tS3\tAGND\tN_ALT\n'
                        'I106\tmos_p\tP\tD4\tG4\tS4\tPVDD\t\n')
                with self.assertRaises(ValueError):m.prepare_mixed_four(work)
                self.assertFalse((work/'test_operations').exists())

    def test_server_command_driver_stops_at_two_and_rejects_repeated_undo(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);engine=root/'engine';site=engine/'server/site';scripts=engine/'scripts'
            site.mkdir(parents=True);scripts.mkdir();candidate=root/'candidate';work=candidate/'work'
            (work/'changes').mkdir(parents=True)
            driver=scripts/'test_mixed_cascode.sh'
            shutil.copyfile(ROOT/'scripts/test_mixed_cascode.sh',driver)
            (site/'run_cascode_experiment.py').write_text('''import pathlib,sys
def pairs(path): return dict(s.split('=',1) for s in pathlib.Path(path).read_text().splitlines() if '=' in s)
if __name__=='__main__':
 w=pathlib.Path(sys.argv[sys.argv.index('--session')+1]);d=w/'test_operations/mixed_four';d.mkdir(parents=True)
 for i in range(1,5): (d/('%02d.conf'%i)).write_text('id=op%d\\ninstance=M%d\\ntype=%s\\n'%(i,i,'same_type_cascode' if i%2 else 'cross_flavor_cascode'))
''')
            (site/'standalone.py').write_text('''import pathlib,sys,shutil
w=pathlib.Path(sys.argv[sys.argv.index('--session')+1]);files=sorted((w/'changes').glob('*.conf'))
if sys.argv[1]=='fresh':
 for p in files:p.unlink()
elif sys.argv[1]=='confirm':shutil.copyfile(sys.argv[sys.argv.index('--operation')+1],w/'changes'/('%02d.conf'%(len(files)+1)))
elif sys.argv[1]=='undo':
 files[-1].unlink()
 with (w/'undo_calls').open('a') as f:f.write('undo\\n')
''')
            (scripts/'resume_cascode_experiment.py').write_text('''import pathlib,sys
assert '--generate-current' in sys.argv
w=pathlib.Path(sys.argv[sys.argv.index('--candidate')+1])/'work';d=w/'reports';d.mkdir(exist_ok=True)
n=len(list((w/'changes').glob('*.conf')))
(d/'validation.txt').write_text('ok=true\\nstage=complete\\nstructural_ready=true\\nexperimental_dc_ready=true\\nfailed_constraints=\\ngenerated_cells=%d\\ntarget=STAGING/result/schematic\\n'%(n*2))
''')
            for stage,count in [('four',4),('three',3),('two',2)]:
                done=subprocess.run(['bash',str(driver),stage,str(candidate)],capture_output=True,text=True)
                self.assertEqual(done.returncode,0,done.stdout+done.stderr)
                self.assertIn('TEST_GROUPS='+str(count),done.stdout)
                self.assertIn('MIXED_CASCODE_TEST=PASS',done.stdout)
            self.assertEqual((work/'undo_calls').read_text().splitlines(),['undo','undo'])
            done=subprocess.run(['bash',str(driver),'two',str(candidate)],capture_output=True,text=True)
            self.assertEqual(done.returncode,2)
            self.assertEqual(len(list((work/'changes').glob('*.conf'))),2)
            self.assertEqual((work/'undo_calls').read_text().splitlines(),['undo','undo'])


if __name__=='__main__':unittest.main()
