"""Resume contracts with pinned file fixtures; no Cadence runs."""
import contextlib
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))


class ResumeTest(unittest.TestCase):
    def module(self):return importlib.import_module('resume_cascode_experiment')

    def setUp(self):
        self.module()
        def native(work,manifest,output,device,columns):
            rows=[]
            def add(i,kind,name,value):
                rows.append(dict(scope=str(i+1),kind=kind,name=name,status='OK',raw_value=json.dumps(value)))
            for i in range(len(next(iter(columns.values())))):
                add(i,'r_status','apply','OK')
                for name,values in columns.items():
                    add(i,'r_value',name,format(values[i],'.17g'))
                    for field in ('min','max'):add(i,'r_'+field,name,None)
                    add(i,'r_callback',name,'test_native_callback()')
            return rows
        check=patch('experimental_pdk.native_resistor_trials',side_effect=native)
        self.native_check=check.start();self.addCleanup(check.stop)

    def fixture(self,root):
        candidate=root/'candidate_I21_test';work=candidate/'work'
        inputs=work/'analysis/standalone_inputs';inputs.mkdir(parents=True)
        (work/'changes').mkdir();(work/'changes/001.conf').write_text('id=one\ninstance=I21\n')
        (work/'logs').mkdir();(work/'logs/old.log').write_text('original failure')
        (work/'session.conf').write_text('validation_scope=experimental_dc\n')
        (candidate/'inputs.json').write_text(json.dumps(dict(target='I21',input_sha256={})))
        (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',failed_stage='generate')))
        manifest={}
        for key in ('context','rules','tech','adapter','runtime'):
            p=inputs/(key+'.json');p.write_text(json.dumps(dict(validation_scope='experimental_dc')))
            manifest[key]=str(p)
        manifest['file_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in manifest.values()}
        (inputs/'provider_inputs.json').write_text(json.dumps(manifest))
        return candidate,manifest

    def test_resumes_only_generate_keeps_existing_inputs_and_logs(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            root=Path(d).resolve();candidate,manifest=self.fixture(root);calls=[]
            protected={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
            def run(stage,argv,output,timeout):
                calls.append(argv)
                report=candidate/'work/reports/validation.txt';report.parent.mkdir()
                report.write_text('ok=true\nvalidation_scope=experimental_dc\nexperimental_dc_ready=true\nready_for_sizing=false\nreliability_verified=false\npublished=false\nstructural_ready=true\nparameters_quantized=false\nstage=complete\ntarget=X__STAGING/Y/schematic\n')
            result=m.resume(candidate,10,runner=run)
            self.assertEqual(result,0)
            self.assertEqual(len(calls),1)
            self.assertEqual(calls[0][2:],[ 'generate','--session',str(candidate/'work')])
            self.assertTrue(all(p.read_bytes()==data for p,data in protected.items()))
            attempt=next(candidate.glob('resume_generate_*'))
            self.assertFalse((attempt/'previous_work_logs').exists())
            self.assertEqual((candidate/'work/logs/old.log').read_text(),'original failure')

    def test_best_effort_is_a_completed_delivery_but_not_dc_pass(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()) as output:
            candidate,_=self.fixture(Path(d).resolve())
            def runner(stage,argv,out,timeout):
                report=candidate/'work/reports/validation.txt';report.parent.mkdir()
                report.write_text('ok=true\nvalidation_scope=experimental_dc\nexperimental_dc_ready=false\n'
                    'optimization_candidate_ready=true\nnominal_dc_ready=true\nfailed_constraints=nominal/op1/saturation\n'
                    'ready_for_sizing=false\nreliability_verified=false\npublished=false\nstructural_ready=true\n'
                    'parameters_quantized=false\nstage=complete\ntarget=X__STAGING/Y/schematic\n')
            self.assertEqual(m.resume(candidate,10,runner=runner),0)
            status=json.loads(next(candidate.glob('resume_generate_*/run_status.json')).read_text())
            self.assertEqual(status['result'],'OPTIMIZATION_CANDIDATE_READY')
            self.assertFalse(status['experimental_dc_ready'])
            self.assertTrue(status['optimization_candidate_ready'])
            self.assertIn('UNMET_REQUIREMENTS=nominal/op1/saturation',output.getvalue())

    def test_prior_pass_only_reorders_current_pdk_accepted_complete_tuples(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()) as output:
            candidate,_=self.fixture(Path(d).resolve());work=candidate/'work'
            report=work/'reports/validation.txt';report.parent.mkdir()
            report.write_text('ok=false\nstage=nominal_dc_check\n')
            resolved=work/'analysis/resolved_parameters.json'
            saved=dict(operations=[dict(status='solved',selection=dict(dc_feasible=True),
                sizing=dict(resistor_master='RMASTER',elements={'R_REF_N':dict(r='505.7631232K',
                    segments='262',cktL='628.8u',segW='800n')}))])
            original=('RMASTER\tr\t48259.84,505763.12319999997,772157.44\n'
                      'RMASTER\tsegments\t25,262,400\n'
                      'RMASTER\tcktL\t60u,628.8u,960u\n'
                      'RMASTER\tsegW\t800n,800n,800n\n')
            # Production tables contain numeric SI literals; saved parameters use suffixes.
            original=original.replace('60u,628.8u,960u','0.00006,0.0006288,0.00096').replace('800n,800n,800n','8e-7,8e-7,8e-7')
            trials=Path(d)/'trials.tsv'
            for mode in ('solved','copy_circuit','execute_skill','verify_roundtrip','other_master',
                         'geometry_changed','excluded','not_solved','missing','electrical_failure'):
                data=json.loads(json.dumps(saved));report.write_text('stage=nominal_dc_check\n')
                text=original
                if mode in ('copy_circuit','execute_skill','verify_roundtrip'):
                    report.write_text('ok=false\nstage='+mode+'\n')
                elif mode=='other_master':data['operations'][0]['sizing']['resistor_master']='OTHER'
                elif mode=='geometry_changed':data['operations'][0]['sizing']['elements']['R_REF_N']['segW']='900n'
                elif mode=='excluded':text=text.replace('505763.12319999997','500000')
                elif mode=='not_solved':data['operations'][0]['selection']['dc_feasible']=False
                elif mode=='missing':del data['operations'][0]['sizing']['elements']['R_REF_N']['segments']
                elif mode=='electrical_failure':report.write_text('stage=solve\n')
                resolved.write_text(json.dumps(data));trials.write_text(text)
                before={row.split()[1]:row.split()[2].split(',') for row in text.splitlines()}
                m.prefer_selected_resistor(work,trials)
                after={row.split()[1]:row.split()[2].split(',') for row in trials.read_text().splitlines()}
                if mode in ('solved','copy_circuit','execute_skill','verify_roundtrip'):
                    for name in before:self.assertEqual(after[name],[before[name][i] for i in (1,0,2)])
                else:self.assertEqual(trials.read_text(),text,mode)
            self.assertIn('PREVIOUS_DC_VERDICT_REUSED=false',output.getvalue())

    def test_drift_and_non_generate_failure_do_not_run_native(self):
        m=self.module()
        for mode in ('drift','not_generate','no_changes'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d:
                candidate,manifest=self.fixture(Path(d).resolve())
                if mode=='drift':Path(manifest['rules']).write_text('{}')
                elif mode=='not_generate':(candidate/'run_status.json').write_text('{"failed_stage":"inspect"}')
                else:(candidate/'work/changes/001.conf').unlink()
                with self.assertRaises((ValueError,OSError)):
                    m.resume(candidate,10,runner=lambda *a: self.fail('must not run'))

    def test_failure_is_retained_without_success_promotion(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            candidate,_=self.fixture(Path(d).resolve())
            def failed(stage,argv,output,timeout):
                log=output/'generate.log';log.write_text('next actual failure')
                raise m.StageFailure(stage,3,log)
            self.assertEqual(m.resume(candidate,10,runner=failed),2)
            status=json.loads(next(candidate.glob('resume_generate_*/run_status.json')).read_text())
            self.assertEqual(status['native_exit_code'],3)
            self.assertFalse(status['experimental_dc_ready'])

    def test_show_saved_result_reads_actual_trace_without_running_or_writing(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            candidate,_=self.fixture(Path(d).resolve())
            trace=candidate/'work/analysis/solver_trace.jsonl'
            row=dict(candidate=1,dc_evaluated=True,converged=True,reason='saturation',
                host_message='',constraints=dict(saturation=False,branch_continuity=False,
                                                reliability_vgs=None,complete=True),
                search=dict(nominal_budget=16),metrics=dict(saturation_margin=-0.02),
                stress_measurements={'N_REP.vds':0.1,'resistor.voltage':0.237837,'resistor.current':4.04573e-5},
                params={'cascode':{'l':'240n','nfin':'6','cdf_presentation':'fixed'}})
            trace.write_text(json.dumps(row)+'\n')
            protected={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
            output=io.StringIO()
            with patch.object(sys,'argv',['resume','--candidate',str(candidate),'--show-last-result']), \
                 patch.object(m,'resume',side_effect=AssertionError('must not generate')), \
                 contextlib.redirect_stdout(output):
                self.assertEqual(m.main(),0)
            text=output.getvalue()
            point=json.loads(next(line.split(' ',1)[1] for line in text.splitlines() if line.startswith('SOLVER_POINT ')))
            self.assertEqual(point['failed_constraints'],['saturation','branch_continuity'])
            self.assertEqual(point['unverified_constraints'],['reliability_vgs'])
            self.assertIn('"saturation_margin": -0.02',text)
            self.assertIn('"l": "240n"',text)
            self.assertNotIn('cdf_presentation',text)
            self.assertIn('SOLVER_HOST_CALLS=1',text)
            self.assertIn('RESULT=SAVED_SOLVER_RESULT_READ_OK',text)
            self.assertIn('measured_V_over_I=5878.72',text)
            self.assertEqual(set(protected),{p for p in candidate.rglob('*') if p.is_file()})
            self.assertTrue(all(p.read_bytes()==raw for p,raw in protected.items()))

    def test_backend_failure_summary_does_not_invent_electrical_results(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            candidate,_=self.fixture(Path(d).resolve())
            trace=candidate/'work/analysis/solver_trace.jsonl'
            trace.write_text(json.dumps(dict(candidate=1,host_called=True,dc_evaluated=None,
                converged=None,reason='evaluation_failed',host_message='geometry incomplete',
                constraints={'converged':None,'saturation':None,'reliability_vgs':None},
                metrics=None,stress_measurements={},params={}))+'\n')
            output=io.StringIO()
            with patch.object(sys,'argv',['resume','--candidate',str(candidate),'--show-last-result']), \
                 contextlib.redirect_stdout(output):
                self.assertEqual(m.main(),0)
            text=output.getvalue()
            point=json.loads(next(line.split(' ',1)[1] for line in text.splitlines() if line.startswith('SOLVER_POINT ')))
            self.assertEqual(point['failed_constraints'],[])
            self.assertIsNone(point['converged'])
            self.assertIn('SOLVER_HOST_CALLS=1',text)
            self.assertIn('converged=unknown reason=evaluation_failed',text)
            self.assertIn('SOLVER_LAST_METRICS=null',text)

    def test_resistor_trials_use_actual_seed_check_known_bounds_and_preserve_order(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            root=Path(d).resolve();candidate,manifest=self.fixture(root)
            work=candidate/'work';(work/'before').mkdir()
            (work/'before/device_catalog.tsv').write_text('master\toa_library\toa_cell\tkind\tnative_parameter_trials\nRMASTER\tPDK\tR\tresistor\ttrue\n')
            probe=root/'probe.tsv'
            probe.write_text('oa_library\toa_cell\tparameter\tunits\tmin\tmax\nPDK\tR\tr\tresistance\t1\t1000000\n')
            Path(manifest['rules']).write_text(json.dumps(dict(validation_scope='experimental_dc',
                experimental_pdk_cache=dict(probe=str(probe)))))
            Path(manifest['tech']).write_text(json.dumps([dict(devices=[dict(kind='resistor',
                oa_library='PDK',cell='R',native_parameter_trials=True,
                normalized_to_cdf={'resistance':'r'},actual_parameter_seed={'resistance':48259.84})])]))
            original={p:p.read_bytes() for p in work.rglob('*') if p.is_file()}
            output=root/'output';output.mkdir()
            path=m.resistor_trial_file(work,manifest,output,['8','4','16'])
            fields=path.read_text().strip().split('\t')
            self.assertEqual(fields[:2],['RMASTER','r'])
            self.assertEqual([float(v) for v in fields[2].split(',')],[48259.84*v for v in (8,4,16)])
            self.assertTrue(all(p.read_bytes()==raw for p,raw in original.items()))
            single_output=root/'single';single_output.mkdir()
            single=m.resistor_trial_file(work,manifest,single_output,['8'])
            self.assertEqual(float(single.read_text().strip().split('\t')[2]),48259.84*8)
            for scales in (['100','4'],['0','4'],['nan','4'],['4','4'],[]):
                with self.subTest(scales=scales),self.assertRaises(ValueError):
                    m.resistor_trial_file(work,manifest,output,scales)
            manifest['file_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
                                     for k,p in manifest.items() if k!='file_sha256'}
            (work/'analysis/standalone_inputs/provider_inputs.json').write_text(json.dumps(manifest))
            commands=[]
            def reject(stage,argv,folder,timeout):
                commands.append(argv)
                trial=Path(argv[argv.index('--experimental-resistor-trials')+1])
                self.assertEqual(trial.read_bytes(),path.read_bytes())
                log=folder/'generate.log';log.write_text('saturation')
                raise m.StageFailure(stage,4,log)
            self.assertEqual(m.resume(candidate,10,runner=reject,reference_resistor_scales=['8','4','16']),2)
            self.assertEqual(m.resume(candidate,10,runner=reject),2)
            self.assertEqual(len(commands),2)
            statuses=[json.loads(p.read_text()) for p in candidate.glob('resume_generate_*/run_status.json')]
            self.assertTrue(all(s['reference_resistor_scales']==['8','4','16'] for s in statuses))

    def test_geometry_trials_keep_seed_segment_shape_and_pair_each_resistance(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            root=Path(d).resolve();candidate,manifest=self.fixture(root)
            work=candidate/'work';(work/'before').mkdir()
            (work/'before/device_catalog.tsv').write_text('master\toa_library\toa_cell\tkind\tnative_parameter_trials\nRMASTER\tPDK\trhrpo_2t_ckt\tresistor\ttrue\n')
            seed={'r':48259.84,'m':1,'segments':25,'cktL':60e-6,'cktW':800e-9,
                  'segL':2.4e-6,'segW':800e-9,'leff':2.4e-6,'nfin':16}
            mapping={('resistance' if k=='r' else 'cdf_'+k):k for k in seed}
            dev=dict(kind='resistor',oa_library='PDK',cell='rhrpo_2t_ckt',native_parameter_trials=True,
                     normalized_to_cdf=mapping,actual_parameter_seed={k:seed[v] for k,v in mapping.items()})
            probe=root/'probe.tsv'
            probe.write_text('oa_library\toa_cell\tparameter\tunits\tmin\tmax\n'+
                ''.join('PDK\trhrpo_2t_ckt\t'+k+'\t'+('resistance' if k=='r' else '')+'\t\t\n' for k in seed))
            Path(manifest['rules']).write_text(json.dumps(dict(validation_scope='experimental_dc',
                experimental_pdk_cache=dict(probe=str(probe)))))
            Path(manifest['tech']).write_text(json.dumps([dict(devices=[dev])]))
            output=root/'output';output.mkdir()
            path=m.resistor_trial_file(work,manifest,output,['8','4','16'])
            columns={line.split('\t')[1]:[float(v) for v in line.split('\t')[2].split(',')]
                     for line in path.read_text().splitlines()}
            self.assertEqual(columns['segments'],[200,100,400])
            self.assertEqual(columns['r'],[48259.84*v for v in (8,4,16)])
            for i,count in enumerate((200,100,400)):
                self.assertAlmostEqual(columns['cktL'][i],count*2.4e-6)
                self.assertEqual(columns['segL'][i],2.4e-6)
                self.assertEqual(columns['segW'][i],800e-9)
            # Automatic mode proposes finite integer counts; it does not run them all.
            path=m.resistor_trial_file(work,manifest,output,None)
            auto={line.split('\t')[1]:[float(v) for v in line.split('\t')[2].split(',')]
                  for line in path.read_text().splitlines()}
            self.assertEqual(auto['segments'][0],25)
            self.assertEqual(len(auto['segments']),800)
            for i,n in enumerate(auto['segments']):
                self.assertEqual(n,int(n))
                self.assertAlmostEqual(auto['cktL'][i],n*2.4e-6)
                self.assertAlmostEqual(auto['r'][i],48259.84*n/25)
            # Only the native accepted points, including holes, reach the CLI table.
            original_native=self.native_check.side_effect
            def clamped(*args):
                records=original_native(*args)
                for row in records:
                    if row['kind']=='r_value' and row['name']=='segments' and row['raw_value'] in ('"195"','"400"'):
                        row['raw_value']='"100"'
                return records
            self.native_check.side_effect=clamped
            path=m.resistor_trial_file(work,manifest,output,None)
            admitted={line.split('\t')[1]:[float(v) for v in line.split('\t')[2].split(',')]
                      for line in path.read_text().splitlines()}
            self.assertEqual(len(admitted['segments']),798)
            self.assertNotIn(195,admitted['segments']);self.assertNotIn(400,admitted['segments'])
            self.assertEqual(json.loads((output/'resistor_pdk_check.json').read_text())['accepted_count'],798)
            def refused(*args):
                records=original_native(*args)
                for row in records:
                    if row['kind']=='r_status':row['raw_value']='"REJECTED"'
                return records
            self.native_check.side_effect=refused
            refused_output=root/'refused';refused_output.mkdir()
            with self.assertRaisesRegex(ValueError,'no PDK-accepted'):
                m.resistor_trial_file(work,manifest,refused_output,None)
            self.assertFalse((refused_output/'reference_resistor_trials.tsv').exists())
            self.native_check.side_effect=original_native
            original_probe=probe.read_text()
            probe.write_text(original_probe.replace('segments\t\t\t','segments\t\t10\t50'))
            path=m.resistor_trial_file(work,manifest,output,None)
            auto={line.split('\t')[1]:[float(v) for v in line.split('\t')[2].split(',')]
                  for line in path.read_text().splitlines()}
            self.assertEqual(set(auto['segments']),set(range(10,51)))
            self.assertEqual(len({len(v) for v in auto.values()}),1)
            probe.write_text(original_probe)
            for mode in ('missing','wrong_total','noninteger','known_limit'):
                bad=json.loads(json.dumps(dev));scales=['8','4','16']
                if mode=='missing':del bad['actual_parameter_seed']['cdf_segments']
                if mode=='wrong_total':bad['actual_parameter_seed']['cdf_cktL']=10e-6
                if mode=='noninteger':scales=['1.01','4','16']
                if mode=='known_limit':
                    probe.write_text(probe.read_text().replace('segments\t\t\t','segments\t\t1\t50'))
                Path(manifest['tech']).write_text(json.dumps([dict(devices=[bad])]))
                with self.subTest(mode=mode),self.assertRaises(ValueError):
                    m.resistor_trial_file(work,manifest,output,scales)

    def test_cli_defaults_to_automatic_not_previous_manual_trials(self):
        m=self.module()
        with patch.object(sys,'argv',['resume','--candidate','/tmp/candidate']), \
             patch.object(m,'resume',return_value=0) as call:
            self.assertEqual(m.main(),0)
            self.assertTrue(call.call_args.kwargs['automatic_resistor_search'])
            self.assertIsNone(call.call_args.kwargs['reference_resistor_scales'])
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            candidate,_=self.fixture(Path(d).resolve())
            (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',
                failed_stage='generate',reference_resistor_scales=['8','4','16'])))
            def run(stage,argv,folder,timeout):
                self.assertIn('--experimental-resistor-auto',argv)
                log=folder/'generate.log';log.write_text('no candidate')
                raise m.StageFailure(stage,4,log)
            with patch.object(m,'resistor_trial_file',return_value=Path(d)/'trials.tsv') as table:
                self.assertEqual(m.resume(candidate,10,runner=run,automatic_resistor_search=True),2)
                self.assertIsNone(table.call_args.args[-1])

    def test_fresh_search_ignores_previous_selection_and_manual_scales(self):
        m=self.module()
        with patch.object(sys,'argv',['resume','--candidate','/tmp/candidate','--fresh-search','--reuse-verified-inputs']), \
             patch.object(m,'resume',return_value=0) as call:
            self.assertEqual(m.main(),0)
            self.assertTrue(call.call_args.kwargs['fresh_search'])
            self.assertTrue(call.call_args.kwargs['reuse_verified_inputs'])
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()) as output:
            candidate,_=self.fixture(Path(d).resolve());calls=[]
            (candidate/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',
                failed_stage='generate',reference_resistor_scales=['8','4','16'])))
            def run(stage,argv,folder,timeout):
                calls.append(argv)
                self.assertIn('--experimental-resistor-auto',argv)
                log=folder/'generate.log';log.write_text('new actual evaluation')
                raise m.StageFailure(stage,4,log)
            with patch.object(m,'resistor_trial_file',return_value=Path(d)/'trials.tsv') as table, \
                 patch.object(m,'prefer_selected_resistor',side_effect=AssertionError('must not prefer old point')):
                self.assertEqual(m.resume(candidate,10,runner=run,fresh_search=True),2)
                self.assertIsNone(table.call_args.args[-1])
            self.assertEqual(len(calls),1)
            self.assertIn('FRESH_VBIAS_SEARCH=true',output.getvalue())
            self.assertIn('PREVIOUS_SELECTION_SEED_REUSED=false',output.getvalue())
            status=json.loads(next(candidate.glob('resume_generate_*/run_status.json')).read_text())
            self.assertTrue(status['fresh_search'])
            self.assertFalse(status['experimental_dc_ready'])
            with self.assertRaisesRegex(ValueError,'omit --reference-resistor-scales'):
                m.resume(candidate,10,runner=run,fresh_search=True,reference_resistor_scales=['8'])

    def test_resume_reports_new_rejection_but_not_old_trace(self):
        m=self.module()
        for updated in (False,True):
            with self.subTest(updated=updated),tempfile.TemporaryDirectory() as d:
                candidate,_=self.fixture(Path(d).resolve())
                trace=candidate/'work/analysis/solver_trace.jsonl'
                trace.write_text('{"candidate":1,"reason":"old_failure"}\n')
                output=io.StringIO()
                def failed(stage,argv,folder,timeout):
                    if updated:
                        trace.write_text(json.dumps(dict(candidate=2,converged=False,
                            host_message='native export failed',constraints={'converged':False}))+'\n')
                    log=folder/'generate.log';log.write_text('actual failure')
                    raise m.StageFailure(stage,3,log)
                with contextlib.redirect_stdout(output):
                    self.assertEqual(m.resume(candidate,10,runner=failed),2)
                self.assertNotIn('old_failure',output.getvalue())
                self.assertEqual('TRIAL_RESULT ' in output.getvalue(),updated)
                if updated:self.assertIn('native export failed',output.getvalue())

    def test_generate_current_refreshes_targets_after_success_add_and_undo(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()) as output:
            root=Path(d).resolve();candidate,manifest=self.fixture(root);work=candidate/'work'
            (candidate/'run_status.json').write_text(json.dumps(dict(result='EXPERIMENT_DC_PASS',
                reuse_manifest='old-target-receipt-must-not-be-read',provider_manifest='old-inputs')))
            second=work/'changes/002.conf';second.write_text('id=two\ninstance=I105\n')
            tool=root/'engine/build/bin/st_circuit_tool';tool.parent.mkdir(parents=True);tool.touch();tool.chmod(0o755)
            seen=[]
            def receipt(folder,inputs):
                names=[m.pairs(p)['instance'] for p in sorted((work/'changes').glob('*.conf'))]
                seen.append(names)
                return dict(file_sha256={},mos_rows=[[name] for name in names],
                            baseline_reuse_reason='accepted DC',preserved_resistors=[])
            def run(stage,argv,out,timeout,env=None):
                actual=json.loads(Path(env['ST_EXPERIMENT_REUSE_MANIFEST']).read_text())
                self.assertEqual([r[0] for r in actual['mos_rows']],seen[-1])
                self.assertIn('--experimental-resistor-auto',argv)
                report=work/'reports/validation.txt';report.parent.mkdir(exist_ok=True)
                report.write_text('ok=true\nvalidation_scope=experimental_dc\nexperimental_dc_ready=true\n'
                    'ready_for_sizing=false\nreliability_verified=false\npublished=false\nstructural_ready=true\n'
                    'nominal_dc_ready=true\nstage=complete\ntarget=X__STAGING/Y/schematic\n')
            with patch.object(m,'ROOT',root/'engine'),patch('experiment_reuse.prepare_receipt',side_effect=receipt), \
                 patch.object(m,'resistor_trial_file',return_value=root/'trials.tsv'), \
                 patch.object(m,'prefer_selected_resistor',side_effect=AssertionError('old target seed must not be reused')):
                self.assertEqual(m.resume(candidate,10,runner=run,generate_current=True),0)
                second.unlink()  # same active change set state produced by CLI undo
                self.assertEqual(m.resume(candidate,10,runner=run,generate_current=True),0)
                (work/'changes/001.conf').unlink()
                with self.assertRaisesRegex(ValueError,'confirmed operation missing'):
                    m.resume(candidate,10,runner=run,generate_current=True)
            self.assertEqual(seen,[['I21','I105'],['I21']])
            self.assertIn('PREVIOUS_TARGET_BINDINGS_REUSED=false',output.getvalue())

    def test_any_adapter_update_resumes_but_changed_cached_data_does_not(self):
        m=self.module()
        digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
        for mode in ('known','unknown_prior','receipt_drift','evidence_drift','other_input_drift'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
                root=Path(d).resolve();candidate,manifest=self.fixture(root)
                engine=root/'engine';(engine/'scripts').mkdir(parents=True)
                adapter=engine/'server/skill/pdk_adapter.il';adapter.parent.mkdir(parents=True)
                adapter.write_text('old adapter');old=digest(adapter)
                manifest['file_sha256'][str(adapter)]=old
                original=candidate/'work/analysis/standalone_inputs/provider_inputs.json'
                original.write_text(json.dumps(manifest))
                prior_dir=candidate/'resume_generate_prior';prior_dir.mkdir()
                receipt=prior_dir/'reuse_manifest.json'
                evidence=candidate/'baseline_evidence';evidence.write_text('accepted baseline fixture')
                receipt.write_text(json.dumps(dict(file_sha256={str(evidence):digest(evidence)},mos_rows=[['cached']],
                    baseline_reuse_reason='unchanged',preserved_resistors=[])))
                prior=json.loads(json.dumps(manifest))
                prior['file_sha256'][str(receipt)]=digest(receipt)
                if mode=='unknown_prior':prior['file_sha256'][str(adapter)]='unrecognised'
                provider=prior_dir/'provider_inputs.json';provider.write_text(json.dumps(prior))
                (prior_dir/'run_status.json').write_text(json.dumps(dict(result='INCOMPLETE',failed_stage='generate',
                    reuse_manifest=str(receipt),provider_manifest=str(provider),original_provider_manifest_sha256=digest(original))))
                adapter.write_text('new adapter')
                (engine/'scripts/cascode_reuse_update.json').write_text(json.dumps(dict(schema='cascode-reuse-update-v1',
                    files={'server/skill/pdk_adapter.il':dict(before_sha256=[old],after_sha256=digest(adapter))})))
                tool=engine/'build/bin/st_circuit_tool';tool.parent.mkdir(parents=True);tool.touch();tool.chmod(0o755)
                if mode=='receipt_drift':receipt.write_text(receipt.read_text()+'\n')
                if mode=='evidence_drift':evidence.write_text('changed baseline')
                if mode=='other_input_drift':Path(manifest['rules']).write_text('{"changed":true}')
                protected={p:p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
                calls=[]
                def runner(stage,argv,output,timeout,env=None):
                    calls.append(argv)
                    active=json.loads(Path(env['ST_SITE_INPUTS_MANIFEST']).read_text())
                    self.assertEqual(active['adapter'],manifest['adapter'])
                    self.assertEqual(json.loads(Path(env['ST_EXPERIMENT_REUSE_MANIFEST']).read_text()),json.loads(receipt.read_text()))
                    log=output/'generate.log';log.write_text('native candidate pending')
                    raise m.StageFailure(stage,3,log)
                with patch.object(m,'ROOT',engine):
                    if mode in ('known','unknown_prior'):self.assertEqual(m.resume(candidate,10,runner=runner),2)
                    else:
                        with self.assertRaises(ValueError):m.resume(candidate,10,runner=runner)
                self.assertEqual(len(calls),1 if mode in ('known','unknown_prior') else 0)
                self.assertTrue(all(p.read_bytes()==raw for p,raw in protected.items()))


if __name__=='__main__':unittest.main()
