#!/usr/bin/env bash
# Server functional test: four mixed groups -> three -> two. No PDK scan.
set -euo pipefail
if [[ $# != 2 || ! "$1" =~ ^(four|three|two)$ ]]; then
    echo "usage: bash $0 {four|three|two} CANDIDATE_DIR" >&2
    exit 2
fi
stage=$1
candidate=$2
engine=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
work="$candidate/work"
site="$engine/server/site"
ops="$work/test_operations/mixed_four"

check_operations() {
    python3 - "$site" "$work" "$1" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from run_cascode_experiment import pairs
work=pathlib.Path(sys.argv[2]);count=int(sys.argv[3])
files=sorted((work/'changes').glob('*.conf'))
expected=[pairs(work/'test_operations/mixed_four'/('%02d.conf'%i)) for i in range(1,count+1)]
actual=[pairs(p) for p in files]
fields=('id','type','instance','new_master')
if len(actual)!=count or any(any(a.get(k)!=b.get(k) for k in fields) for a,b in zip(actual,expected)):
    print('RESULT=TEST_SEQUENCE_MISMATCH; expected active prefix of %d prepared operations; no undo performed'%count)
    sys.exit(2)
print('ACTIVE_GROUPS='+str(count))
for index,op in enumerate(actual,1):
    print('ACTIVE_GROUP=%d TARGET=%s TYPE=%s'%(index,op['instance'],op['type']))
PY
}

if [[ "$stage" == four ]]; then
    # Prepare all four first: unavailable cross-flavor devices leave the
    # user's current operations and successful result untouched.
    python3 "$site/run_cascode_experiment.py" --session "$work" --prepare-mixed-four
    python3 "$site/standalone.py" fresh --session "$work"
    for index in 01 02 03 04; do
        python3 "$site/standalone.py" confirm --session "$work" --operation "$ops/$index.conf"
    done
    count=4
else
    if [[ "$stage" == three ]]; then count=3; else count=2; fi
    check_operations "$((count+1))"
    python3 "$site/standalone.py" undo --session "$work"
fi
check_operations "$count"
python3 "$engine/scripts/resume_cascode_experiment.py" --candidate "$candidate" --generate-current --stage-timeout 14400
python3 - "$site" "$work" "$count" <<'PY'
import pathlib,sys
sys.path.insert(0,sys.argv[1])
from run_cascode_experiment import pairs
work=pathlib.Path(sys.argv[2]);count=int(sys.argv[3])
r=pairs(work/'reports/validation.txt')
print('TEST_GROUPS='+str(count))
print('GENERATED_SUBCELLS='+r.get('generated_cells','unknown'))
print('RESULT_CELL='+r.get('target','unknown'))
if not (r.get('ok')=='true' and r.get('stage')=='complete' and
        r.get('structural_ready')=='true' and r.get('experimental_dc_ready')=='true' and
        not r.get('failed_constraints') and r.get('generated_cells')==str(count*2)):
    print('MIXED_CASCODE_TEST=NOT_PASSED; see the actual generation result above')
    sys.exit(2)
print('MIXED_CASCODE_TEST=PASS')
if count==2: print('FINAL_RETAINED=same_type_NMOS,cross_flavor_PMOS')
PY
