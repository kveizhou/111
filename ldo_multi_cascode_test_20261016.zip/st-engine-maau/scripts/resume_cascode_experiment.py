#!/usr/bin/env python3
"""Continue generate in the existing failed experiment; no rebuild/re-inspect.

Current engine code resumes the existing circuit. Only circuit inputs are
checked at entry; candidate wiring, parameters and simulation remain required.
"""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server/site'))
from run_cascode_experiment import (StageFailure, pairs, run_stage, validate_result,
    solver_trace_stamp, print_solver_result, print_new_solver_result, completion_status, print_completion)
from site_data import read_json, write_json, verify_site_inputs
from inspect_cascode_pdk_evidence import latest
from experimental_pdk import resistor_trial_file


def port_updated_inputs(original):
    """Compatibility entry for the former port-only update command."""
    return reuse_updated_inputs(original)


def reuse_updated_inputs(original):
    """Use current code with the existing circuit inputs; no release whitelist."""
    verify_site_inputs(original)
    return copy.deepcopy(original), {'policy':'current_engine'}


def retained_port_preflight(candidate, inputs):
    """Run the repaired pure parser on retained evidence before launching EDA."""
    from cascode_runtime import wrap_oa_dut
    from op_provider import parse_deck
    baseline=candidate/'work/analysis/baseline_op'
    if any((baseline/name).exists() for name in ('identity.tsv','mos.tsv')):
        raise ValueError('existing OP outputs predate this runtime upgrade; do not reuse them')
    export=latest(baseline.glob('raw_op/st-op-simulation.*/export_dut.log'))
    directory=export.parent;dut=directory/'dut_oa'
    used={}
    def read(path):
        path=Path(path);data=path.read_bytes()
        used[str(path)]=hashlib.sha256(data).hexdigest()
        return data.decode('utf-8')
    if 'actual OA DUT/Bench port mismatch' not in read(export):
        raise ValueError('latest retained export was not the known OA/Bench port failure')
    if read(dut/'runtime.done').strip()!='OK':raise ValueError('retained native export incomplete')
    bundle=read_json(read_json(inputs['rules'])['validated_baseline_bundle'])
    bench_text=read(directory/'bench.scs')
    if bench_text!=read(bundle['bench_netlist']):raise ValueError('retained Bench differs from accepted Bench')
    designs=re.findall(r'^\s*design\(([^\n]*)\)\s*$',read(dut/'runtime.ocn'),re.M)
    if len(designs)!=1:raise ValueError('retained actual OA design is ambiguous')
    actual=[json.loads(v) for v in re.findall(r'"(?:[^"\\]|\\.)*"',designs[0])]
    if actual!=[bundle['source'][k] for k in ('lib','cell','view')]:
        raise ValueError('retained export is not the accepted baseline source OA')
    generated=list((dut/'generated').rglob('input.scs'))
    if len(generated)!=1:raise ValueError('retained input.scs missing or ambiguous')
    ports=parse_deck(bench_text)['definitions'][bundle['source_subckt']]['ports']
    _,evidence=wrap_oa_dut(read(generated[0]),actual[1],read(dut/'ports.txt').splitlines(),ports,
        bundle['variables'],baseline_text=bench_text,source_subckt=bundle['source_subckt'])
    for path,digest in used.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:
            raise ValueError('retained port evidence changed during read: '+path)
    evidence.update(simulation_directory=str(directory),file_sha256=used,native_executions=0)
    print('PORT_PREFLIGHT=PASS\nPORT_BINDING=BUS_BITS_VERIFIED OA='+str(evidence['oa_port_count'])+
          ' BITS='+str(evidence['expanded_port_count']),flush=True)
    print('PORTS_UNUSED_IN_BOTH='+json.dumps(evidence['unused_in_both']),flush=True)
    return evidence


def prefer_selected_resistor(work, trials):
    """Retry a previously solved point first, never reuse its DC verdict.

    Reorder complete tuples already accepted by this run's PDK check. A changed
    master, geometry or excluded point therefore falls back to normal search.
    """
    report = Path(work)/'reports/validation.txt'
    resolved = Path(work)/'analysis/resolved_parameters.json'
    if not report.is_file() or not resolved.is_file():
        return
    # A solved point is also available when final copying/materialization fails
    # before DC. These are all post-search stages of the existing materializer.
    if pairs(report).get('stage') not in (
            'validate_plan', 'copy_circuit', 'write_plan', 'execute_skill',
            'verify_source', 'regenerate_netlist', 'verify_roundtrip',
            'nominal_dc_check', 'pvt_check'):
        return
    try:
        operations = read_json(resolved)['operations']
        if len(operations) != 1:
            return
        saved = operations[0]
        if saved.get('status') != 'solved' or saved.get('selection',{}).get('dc_feasible') is not True:
            return
        rows = [line.split() for line in Path(trials).read_text().splitlines() if line.strip()]
        master = saved['sizing']['resistor_master']
        if not rows or any(len(row) != 3 or row[0] != master for row in rows):
            return
        columns = {row[1]:row[2].split(',') for row in rows}
        count = len(next(iter(columns.values())))
        if len(columns) != len(rows) or any(len(values) != count for values in columns.values()):
            return
        elements = [values for values in saved['sizing']['elements'].values()
                    if columns.keys() <= values.keys()]
        if len(elements) != 1:
            return
        from op_provider import parameter_value
        wanted = {name:parameter_value(elements[0][name],{}) for name in columns}
        matches = [i for i in range(count) if all(math.isclose(float(values[i]),wanted[name],
                   rel_tol=1e-12,abs_tol=0) for name,values in columns.items())]
        if len(matches) != 1:
            return
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        print('PREVIOUS_SELECTION_SEED_SKIPPED='+str(error),flush=True)
        return
    index = matches[0]
    order = [index]+[i for i in range(count) if i != index]
    Path(trials).write_text(''.join(master+'\t'+name+'\t'+','.join(values[i] for i in order)+'\n'
                                  for name,values in columns.items()))
    print('PREVIOUS_SELECTION_SEED_REUSED=true\nPREVIOUS_DC_VERDICT_REUSED=false',flush=True)
    print('FIRST_TRIAL_RESISTANCE_OHMS='+str(wanted[rows[0][1]]),flush=True)


def resume(candidate, timeout, runner=run_stage, upgrade_port_reader=False, reuse_verified_inputs=False,
           reference_resistor_scales=None, automatic_resistor_search=False, fresh_search=False,
           generate_current=False):
    if generate_current:
        # Edits/undo change the target set. Rebind cached source OP to the
        # current operations, never carry a previous target list or verdict.
        reuse_verified_inputs = True
        fresh_search = True
    if fresh_search:
        if reference_resistor_scales is not None:
            raise ValueError('--fresh-search uses automatic trials; omit --reference-resistor-scales')
        automatic_resistor_search=True
    candidate=Path(candidate).resolve();work=candidate/'work'
    status_path=candidate/'run_status.json'
    previous=list(candidate.glob('resume_generate_*/run_status.json'))
    if previous:status_path=latest(previous)
    previous_status=read_json(status_path)
    if generate_current:
        previous_status = {}
    if reference_resistor_scales is None and not automatic_resistor_search:
        reference_resistor_scales=previous_status.get('reference_resistor_scales')
    if not generate_current and (previous_status.get('failed_stage')!='generate' or previous_status.get('result')!='INCOMPLETE'):
        raise ValueError('latest attempt is not a failed generate; refusing to repeat other stages')
    if pairs(work/'session.conf').get('validation_scope')!='experimental_dc':
        raise ValueError('resume requires the existing experimental_dc session')
    if not list((work/'changes').glob('*.conf')):
        raise ValueError('confirmed operation missing; no automatic confirm')
    if generate_current:
        print('GENERATE_CURRENT_OPERATIONS=true\nPREVIOUS_TARGET_BINDINGS_REUSED=false',flush=True)
    original_path=work/'analysis/standalone_inputs/provider_inputs.json'
    manifest=read_json(original_path)
    original_digest=hashlib.sha256(original_path.read_bytes()).hexdigest()
    reuse=reuse_verified_inputs or bool(previous_status.get('reuse_manifest'))
    upgraded=reuse or upgrade_port_reader or bool(previous_status.get('provider_manifest'))
    receipt=None
    bundle_preflight=None
    if reuse:
        from experiment_reuse import prepare_receipt, check_files
        manifest,release=reuse_updated_inputs(manifest)
        if previous_status.get('reuse_manifest'):
            receipt_path=str(Path(previous_status['reuse_manifest']).resolve())
            prior=read_json(previous_status['provider_manifest'])
            for key in ('context','rules','tech'):
                if prior[key]!=manifest[key]:raise ValueError('cached circuit input path changed: '+key)
            cached=prior.get('file_sha256',{}).get(receipt_path)
            if cached and hashlib.sha256(Path(receipt_path).read_bytes()).hexdigest()!=cached:
                raise ValueError('cached baseline values changed')
            receipt=read_json(receipt_path)
            check_files(receipt['file_sha256'])
        else:
            receipt=prepare_receipt(candidate,manifest)
        # Check the selected Bench/models once, before candidate execution.
        bundle_path=read_json(manifest['rules']).get('validated_baseline_bundle')
        if bundle_path:
            from baseline_bundle import load_bundle
            from standalone import validate_bundle_profile
            accepted=load_bundle(bundle_path,runtime_inputs=manifest,verify_content=True)
            validate_bundle_profile(accepted,read_json(manifest['rules']))
            from cascode_runtime import candidate_launch_options
            launch_options=candidate_launch_options(accepted)
            print('CANDIDATE_LAUNCH_PREFLIGHT=PASS\nSPECTRE_LAUNCH_OPTIONS='+json.dumps(launch_options),flush=True)
            bundle_preflight=dict(bundle=accepted['_bundle_path'],bundle_sha256=accepted['_bundle_sha256'],
                tool_upgrades=accepted['_tool_upgrades'],native_executions=0)
            print('BASELINE_BUNDLE_PREFLIGHT=PASS\nBASELINE_INPUTS_MATCH=true',flush=True)
            for name,entry in accepted['_tool_upgrades'].items():
                print('BASELINE_TOOL_UPGRADE '+str(Path(name).relative_to(ROOT))+' '+
                      entry['before_sha256']+' -> '+entry['after_sha256'],flush=True)
        print('CODE_VERSION_GATE=false\nREPEATED_HISTORY_CHECKS=false\nOP_SCOPE=target_and_changed_devices',flush=True)
        print('REUSE_PREFLIGHT=PASS\nPDK_SCAN_REUSE_READY=true\nPORT_EVIDENCE_REUSED=true\nDEVICE_BINDINGS_REUSED=true',flush=True)
        print('BASELINE_DC_REUSE_READY='+str(bool(receipt['mos_rows'])).lower(),flush=True)
        print('BASELINE_REUSE_REASON='+receipt['baseline_reuse_reason'],flush=True)
        print('PRESERVED_RESISTOR_GROUPS='+str(len(receipt['preserved_resistors'])),flush=True)
    elif upgraded:
        manifest,release=port_updated_inputs(manifest)
        if previous_status.get('provider_manifest'):
            evidence=dict(reused_from=previous_status['provider_manifest'],native_executions=0)
        else:
            evidence=retained_port_preflight(candidate,manifest)
    else:
        verify_site_inputs(manifest)
    if not os.access(ROOT/'build/bin/st_circuit_tool',os.X_OK):
        raise ValueError('compiled tool missing; no automatic rebuild during resume')
    output=Path(tempfile.mkdtemp(prefix='resume_generate_',dir=str(candidate)))
    argv=[sys.executable,str(ROOT/'server/site/standalone.py'),'generate','--session',str(work)]
    status=dict(checker='cascode-experiment-resume-v3' if reuse else 'cascode-experiment-resume-v2',result='INCOMPLETE',
                candidate=str(candidate),experimental_dc_ready=False,ready_for_sizing=False,
                reliability_verified=False,published=False)
    env=None
    if upgraded:
        from standalone import environment
        active=original_path
        if reuse:
            if not previous_status.get('reuse_manifest'):
                receipt_path=output/'reuse_manifest.json'
                write_json(receipt_path,receipt)
                manifest['file_sha256'][str(receipt_path)]=hashlib.sha256(Path(receipt_path).read_bytes()).hexdigest()
                active=output/'provider_inputs.json'
                write_json(active,manifest)
            else:
                active=Path(previous_status['provider_manifest'])
        env=environment(manifest,active)
        if reuse:
            env['ST_EXPERIMENT_REUSE_MANIFEST']=str(receipt_path)
            status['reuse_manifest']=str(receipt_path)
        argv=[str(ROOT/'build/bin/st_circuit_tool'),'generate','--session',str(work)]
        status.update(provider_manifest=str(active),original_provider_manifest_sha256=original_digest)
        print('CURRENT_ENGINE_USED=true\nORIGINAL_INPUT_MANIFEST_UNCHANGED=true',flush=True)
    if reference_resistor_scales is not None or automatic_resistor_search:
        trials=resistor_trial_file(work,manifest,output,reference_resistor_scales)
        if automatic_resistor_search and not fresh_search:
            prefer_selected_resistor(work,trials)
        if fresh_search:
            print('FRESH_VBIAS_SEARCH=true\nPREVIOUS_SELECTION_SEED_REUSED=false\nPREVIOUS_DC_VERDICT_REUSED=false',flush=True)
        argv += ['--experimental-resistor-trials',str(trials)]
        status['reference_resistor_scales']=reference_resistor_scales
        status['automatic_resistor_search']=automatic_resistor_search
        status['fresh_search']=fresh_search
        if automatic_resistor_search:
            argv += ['--experimental-resistor-auto','true']
    write_json(output/'command.json',argv)
    print('CHECKER='+status['checker']+'\nCANDIDATE_DIR='+str(candidate)+'\nOUTPUT_DIR='+str(output),flush=True)
    print('RESUME_STAGE=generate\nREBUILD=false\nINSPECT_REUSED=true\nCONFIRM_REUSED=true',flush=True)
    trace_before = solver_trace_stamp(work)
    try:
        if upgraded:runner('generate',argv,output,timeout,env=env)
        else:runner('generate',argv,output,timeout)
        report=pairs(work/'reports/validation.txt');validate_result(report)
        status.update(completion_status(report))
    except StageFailure as error:
        status.update(issue=str(error),failed_stage='generate',native_exit_code=error.code)
        if error.log.is_file():
            for line in error.log.read_text(errors='replace').splitlines()[-24:]:print('STAGE_LOG '+line[:900])
        logs=sorted(work.rglob('*.log'),key=lambda p:p.stat().st_mtime_ns,reverse=True)
        for log in logs[:3]:
            print('DETAIL_LOG='+str(log))
            for line in log.read_text(errors='replace').splitlines()[-10:]:print('DETAIL '+line[:700])
    except (OSError,ValueError,KeyError,TypeError) as error:
        status.update(issue=str(error),failed_stage='generate')
    except KeyboardInterrupt:
        status.update(issue='interrupted; no automatic retry',failed_stage='generate')
    print_new_solver_result(work, trace_before)
    write_json(output/'run_status.json',status)
    print('DETAILS_FILE='+str(output/'run_status.json')+'\nRESULT='+status['result'])
    if status.get('issue'):print('ISSUE '+status['issue'])
    print('EXPERIMENTAL_DC_READY='+str(status['experimental_dc_ready']).lower())
    print_completion(status)
    print('READY_FOR_SIZING=false\nRELIABILITY_VERIFIED=false\nPUBLISHED=false')
    return 0 if status['experimental_dc_ready'] or status.get('optimization_candidate_ready') else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--batch',help='select the latest candidate from this batch')
    source.add_argument('--candidate',help='explicit candidate directory')
    parser.add_argument('--stage-timeout',type=int,default=3600)
    parser.add_argument('--show-last-result',action='store_true',
                        help='only print the existing solver trace; no generation or simulation')
    parser.add_argument('--generate-current',action='store_true',
                        help='generate the current confirmed operations after edits/undo, using cached source inputs')
    parser.add_argument('--reference-resistor-scales',
                        help='comma-separated finite scales of the measured resistor seed, e.g. 8,4,16')
    parser.add_argument('--upgrade-port-reader',action='store_true',
                        help='use the published bus-port runtime update with a separate input manifest')
    parser.add_argument('--reuse-verified-inputs',action='store_true',
                        help='reuse same-session verified source evidence and retain unchanged peripheral resistors')
    parser.add_argument('--fresh-search',action='store_true',
                        help='restart automatic DC search from device seeds, without preferring a previous selection')
    args=parser.parse_args()
    try:
        if args.stage_timeout<=0:raise ValueError('timeout must be positive')
        candidate=Path(args.candidate).resolve() if args.candidate else latest(Path(args.batch).resolve().glob('candidate_*/run_status.json')).parent
        if args.show_last_result:
            print('SPECTRE_RERUN=false\nNATIVE_EXECUTIONS=0')
            print_solver_result(candidate/'work')
            print('RESULT=SAVED_SOLVER_RESULT_READ_OK')
            return 0
        return resume(candidate,args.stage_timeout,upgrade_port_reader=args.upgrade_port_reader,
                      reuse_verified_inputs=args.reuse_verified_inputs,
                      reference_resistor_scales=args.reference_resistor_scales.split(',') if args.reference_resistor_scales else None,
                      automatic_resistor_search=not bool(args.reference_resistor_scales),
                      fresh_search=args.fresh_search,generate_current=args.generate_current)
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('CHECKER=cascode-experiment-resume-v3\nRESULT=INCOMPLETE\nISSUE '+str(error))
        print('EXPERIMENTAL_DC_READY=false\nPUBLISHED=false')
        return 2


if __name__=='__main__':raise SystemExit(main())
